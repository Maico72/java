package android.support.p001v4.app;

import androidx.core.app.RemoteActionCompat;

/* renamed from: android.support.v4.app.RemoteActionCompatParcelizer */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C0684fd fdVar) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(fdVar);
    }

    public static void write(RemoteActionCompat remoteActionCompat, C0684fd fdVar) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, fdVar);
    }
}
