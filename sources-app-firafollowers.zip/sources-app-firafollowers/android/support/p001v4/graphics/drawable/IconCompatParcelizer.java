package android.support.p001v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;

/* renamed from: android.support.v4.graphics.drawable.IconCompatParcelizer */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(C0684fd fdVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(fdVar);
    }

    public static void write(IconCompat iconCompat, C0684fd fdVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, fdVar);
    }
}
