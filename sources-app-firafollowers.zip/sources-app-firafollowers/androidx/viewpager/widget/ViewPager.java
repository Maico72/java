package androidx.viewpager.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;

public class ViewPager extends ViewGroup {

    /* renamed from: b0 */
    public static final int[] f1052b0 = {16842931};

    /* renamed from: c0 */
    public static final Comparator<C0206e> f1053c0 = new C0202a();

    /* renamed from: d0 */
    public static final Interpolator f1054d0 = new C0203b();

    /* renamed from: e0 */
    public static final C0213k f1055e0 = new C0213k();

    /* renamed from: A */
    public boolean f1056A;

    /* renamed from: B */
    public boolean f1057B;

    /* renamed from: C */
    public int f1058C;

    /* renamed from: D */
    public int f1059D;

    /* renamed from: E */
    public int f1060E;

    /* renamed from: F */
    public float f1061F;

    /* renamed from: G */
    public float f1062G;

    /* renamed from: H */
    public float f1063H;

    /* renamed from: I */
    public float f1064I;

    /* renamed from: J */
    public int f1065J = -1;

    /* renamed from: K */
    public VelocityTracker f1066K;

    /* renamed from: L */
    public int f1067L;

    /* renamed from: M */
    public int f1068M;

    /* renamed from: N */
    public int f1069N;

    /* renamed from: O */
    public int f1070O;

    /* renamed from: P */
    public EdgeEffect f1071P;

    /* renamed from: Q */
    public EdgeEffect f1072Q;

    /* renamed from: R */
    public boolean f1073R = true;

    /* renamed from: S */
    public boolean f1074S;

    /* renamed from: T */
    public int f1075T;

    /* renamed from: U */
    public List<C0209h> f1076U;

    /* renamed from: V */
    public C0209h f1077V;

    /* renamed from: W */
    public final Runnable f1078W = new C0204c();

    /* renamed from: a0 */
    public int f1079a0 = 0;

    /* renamed from: d */
    public int f1080d;

    /* renamed from: e */
    public final ArrayList<C0206e> f1081e = new ArrayList<>();

    /* renamed from: f */
    public final C0206e f1082f = new C0206e();

    /* renamed from: g */
    public final Rect f1083g = new Rect();

    /* renamed from: h */
    public C0885id f1084h;

    /* renamed from: i */
    public int f1085i;

    /* renamed from: j */
    public int f1086j = -1;

    /* renamed from: k */
    public Parcelable f1087k = null;

    /* renamed from: l */
    public ClassLoader f1088l = null;

    /* renamed from: m */
    public Scroller f1089m;

    /* renamed from: n */
    public boolean f1090n;

    /* renamed from: o */
    public C0210i f1091o;

    /* renamed from: p */
    public int f1092p;

    /* renamed from: q */
    public Drawable f1093q;

    /* renamed from: r */
    public int f1094r;

    /* renamed from: s */
    public int f1095s;

    /* renamed from: t */
    public float f1096t = -3.4028235E38f;

    /* renamed from: u */
    public float f1097u = Float.MAX_VALUE;

    /* renamed from: v */
    public int f1098v;

    /* renamed from: w */
    public boolean f1099w;

    /* renamed from: x */
    public boolean f1100x;

    /* renamed from: y */
    public boolean f1101y;

    /* renamed from: z */
    public int f1102z = 1;

    /* renamed from: androidx.viewpager.widget.ViewPager$a */
    public static class C0202a implements Comparator<C0206e> {
        public int compare(Object obj, Object obj2) {
            return ((C0206e) obj).f1105b - ((C0206e) obj2).f1105b;
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$b */
    public static class C0203b implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$c */
    public class C0204c implements Runnable {
        public C0204c() {
        }

        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager viewPager = ViewPager.this;
            viewPager.mo1402q(viewPager.f1085i);
        }
    }

    @Inherited
    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: androidx.viewpager.widget.ViewPager$d */
    public @interface C0205d {
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$e */
    public static class C0206e {

        /* renamed from: a */
        public Object f1104a;

        /* renamed from: b */
        public int f1105b;

        /* renamed from: c */
        public boolean f1106c;

        /* renamed from: d */
        public float f1107d;

        /* renamed from: e */
        public float f1108e;
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$f */
    public static class C0207f extends ViewGroup.LayoutParams {

        /* renamed from: a */
        public boolean f1109a;

        /* renamed from: b */
        public int f1110b;

        /* renamed from: c */
        public float f1111c = 0.0f;

        /* renamed from: d */
        public boolean f1112d;

        /* renamed from: e */
        public int f1113e;

        /* renamed from: f */
        public int f1114f;

        public C0207f() {
            super(-1, -1);
        }

        public C0207f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.f1052b0);
            this.f1110b = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$g */
    public class C0208g extends C1163m6 {
        public C0208g() {
        }

        /* renamed from: c */
        public void mo772c(View view, AccessibilityEvent accessibilityEvent) {
            C0885id idVar;
            this.f4001a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            C0885id idVar2 = ViewPager.this.f1084h;
            boolean z = true;
            if (idVar2 == null || idVar2.mo4027c() <= 1) {
                z = false;
            }
            accessibilityEvent.setScrollable(z);
            if (accessibilityEvent.getEventType() == 4096 && (idVar = ViewPager.this.f1084h) != null) {
                accessibilityEvent.setItemCount(idVar.mo4027c());
                accessibilityEvent.setFromIndex(ViewPager.this.f1085i);
                accessibilityEvent.setToIndex(ViewPager.this.f1085i);
            }
        }

        /* renamed from: d */
        public void mo773d(View view, C1226n7 n7Var) {
            this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
            n7Var.f4196a.setClassName(ViewPager.class.getName());
            C0885id idVar = ViewPager.this.f1084h;
            n7Var.f4196a.setScrollable(idVar != null && idVar.mo4027c() > 1);
            if (ViewPager.this.canScrollHorizontally(1)) {
                n7Var.f4196a.addAction(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                n7Var.f4196a.addAction(8192);
            }
        }

        /* renamed from: g */
        public boolean mo774g(View view, int i, Bundle bundle) {
            ViewPager viewPager;
            int i2;
            if (super.mo774g(view, i, bundle)) {
                return true;
            }
            if (i != 4096) {
                if (i != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                    return false;
                }
                viewPager = ViewPager.this;
                i2 = viewPager.f1085i - 1;
            } else if (!ViewPager.this.canScrollHorizontally(1)) {
                return false;
            } else {
                viewPager = ViewPager.this;
                i2 = viewPager.f1085i + 1;
            }
            viewPager.setCurrentItem(i2);
            return true;
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$h */
    public interface C0209h {
        /* renamed from: a */
        void mo124a(int i, float f, int i2);

        /* renamed from: b */
        void mo125b(int i);

        /* renamed from: c */
        void mo126c(int i);
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$i */
    public class C0210i extends DataSetObserver {
        public C0210i() {
        }

        public void onChanged() {
            ViewPager.this.mo1371e();
        }

        public void onInvalidated() {
            ViewPager.this.mo1371e();
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$j */
    public static class C0211j extends C0015a8 {
        public static final Parcelable.Creator<C0211j> CREATOR = new C0212a();

        /* renamed from: f */
        public int f1117f;

        /* renamed from: g */
        public Parcelable f1118g;

        /* renamed from: h */
        public ClassLoader f1119h;

        /* renamed from: androidx.viewpager.widget.ViewPager$j$a */
        public static class C0212a implements Parcelable.ClassLoaderCreator<C0211j> {
            public Object createFromParcel(Parcel parcel) {
                return new C0211j(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0211j[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0211j(parcel, classLoader);
            }
        }

        public C0211j(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? C0211j.class.getClassLoader() : classLoader;
            this.f1117f = parcel.readInt();
            this.f1118g = parcel.readParcelable(classLoader);
            this.f1119h = classLoader;
        }

        public C0211j(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("FragmentPager.SavedState{");
            d.append(Integer.toHexString(System.identityHashCode(this)));
            d.append(" position=");
            d.append(this.f1117f);
            d.append("}");
            return d.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeInt(this.f1117f);
            parcel.writeParcelable(this.f1118g, i);
        }
    }

    /* renamed from: androidx.viewpager.widget.ViewPager$k */
    public static class C0213k implements Comparator<View> {
        public int compare(Object obj, Object obj2) {
            C0207f fVar = (C0207f) ((View) obj).getLayoutParams();
            C0207f fVar2 = (C0207f) ((View) obj2).getLayoutParams();
            boolean z = fVar.f1109a;
            if (z != fVar2.f1109a) {
                return z ? 1 : -1;
            }
            return fVar.f1113e - fVar2.f1113e;
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context2 = getContext();
        this.f1089m = new Scroller(context2, f1054d0);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context2);
        float f = context2.getResources().getDisplayMetrics().density;
        this.f1060E = viewConfiguration.getScaledPagingTouchSlop();
        this.f1067L = (int) (400.0f * f);
        this.f1068M = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f1071P = new EdgeEffect(context2);
        this.f1072Q = new EdgeEffect(context2);
        this.f1069N = (int) (25.0f * f);
        this.f1070O = (int) (2.0f * f);
        this.f1058C = (int) (f * 16.0f);
        C0010a7.m43p(this, new C0208g());
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        C0010a7.m45r(this, new C0960jd(this));
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.f1100x != z) {
            this.f1100x = z;
        }
    }

    /* renamed from: a */
    public C0206e mo1357a(int i, int i2) {
        C0206e eVar = new C0206e();
        eVar.f1105b = i;
        eVar.f1104a = this.f1084h.mo4029e(this, i);
        Objects.requireNonNull(this.f1084h);
        eVar.f1107d = 1.0f;
        if (i2 < 0 || i2 >= this.f1081e.size()) {
            this.f1081e.add(eVar);
        } else {
            this.f1081e.add(i2, eVar);
        }
        return eVar;
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        C0206e h;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0 && (h = mo1382h(childAt)) != null && h.f1105b == this.f1085i) {
                    childAt.addFocusables(arrayList, i, i2);
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if ((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) {
            arrayList.add(this);
        }
    }

    public void addTouchables(ArrayList<View> arrayList) {
        C0206e h;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (h = mo1382h(childAt)) != null && h.f1105b == this.f1085i) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        C0207f fVar = (C0207f) layoutParams;
        boolean z = fVar.f1109a | (view.getClass().getAnnotation(C0205d.class) != null);
        fVar.f1109a = z;
        if (!this.f1099w) {
            super.addView(view, i, layoutParams);
        } else if (!z) {
            fVar.f1112d = true;
            addViewInLayout(view, i, layoutParams);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x00c5  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1361b(int r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.findFocus()
            r1 = 1
            r2 = 0
            r3 = 0
            if (r0 != r6) goto L_0x000a
            goto L_0x0063
        L_0x000a:
            if (r0 == 0) goto L_0x0064
            android.view.ViewParent r4 = r0.getParent()
        L_0x0010:
            boolean r5 = r4 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x001d
            if (r4 != r6) goto L_0x0018
            r4 = 1
            goto L_0x001e
        L_0x0018:
            android.view.ViewParent r4 = r4.getParent()
            goto L_0x0010
        L_0x001d:
            r4 = 0
        L_0x001e:
            if (r4 != 0) goto L_0x0064
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
        L_0x0034:
            boolean r5 = r0 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x004d
            java.lang.String r5 = " => "
            r4.append(r5)
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
            goto L_0x0034
        L_0x004d:
            java.lang.String r0 = "arrowScroll tried to find focus based on non-child current focused view "
            java.lang.StringBuilder r0 = p000.C1012kd.m3195d(r0)
            java.lang.String r4 = r4.toString()
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            java.lang.String r4 = "ViewPager"
            android.util.Log.e(r4, r0)
        L_0x0063:
            r0 = r3
        L_0x0064:
            android.view.FocusFinder r3 = android.view.FocusFinder.getInstance()
            android.view.View r3 = r3.findNextFocus(r6, r0, r7)
            r4 = 66
            r5 = 17
            if (r3 == 0) goto L_0x00b0
            if (r3 == r0) goto L_0x00b0
            if (r7 != r5) goto L_0x008f
            android.graphics.Rect r1 = r6.f1083g
            android.graphics.Rect r1 = r6.mo1373g(r1, r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f1083g
            android.graphics.Rect r2 = r6.mo1373g(r2, r0)
            int r2 = r2.left
            if (r0 == 0) goto L_0x00aa
            if (r1 < r2) goto L_0x00aa
            boolean r0 = r6.mo1387m()
            goto L_0x00ae
        L_0x008f:
            if (r7 != r4) goto L_0x00c3
            android.graphics.Rect r1 = r6.f1083g
            android.graphics.Rect r1 = r6.mo1373g(r1, r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f1083g
            android.graphics.Rect r2 = r6.mo1373g(r2, r0)
            int r2 = r2.left
            if (r0 == 0) goto L_0x00aa
            if (r1 > r2) goto L_0x00aa
            boolean r0 = r6.mo1388n()
            goto L_0x00ae
        L_0x00aa:
            boolean r0 = r3.requestFocus()
        L_0x00ae:
            r2 = r0
            goto L_0x00c3
        L_0x00b0:
            if (r7 == r5) goto L_0x00bf
            if (r7 != r1) goto L_0x00b5
            goto L_0x00bf
        L_0x00b5:
            if (r7 == r4) goto L_0x00ba
            r0 = 2
            if (r7 != r0) goto L_0x00c3
        L_0x00ba:
            boolean r2 = r6.mo1388n()
            goto L_0x00c3
        L_0x00bf:
            boolean r2 = r6.mo1387m()
        L_0x00c3:
            if (r2 == 0) goto L_0x00cc
            int r7 = android.view.SoundEffectConstants.getContantForFocusDirection(r7)
            r6.playSoundEffect(r7)
        L_0x00cc:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.mo1361b(int):boolean");
    }

    /* renamed from: c */
    public boolean mo1362c(View view, boolean z, int i, int i2, int i3) {
        int i4;
        View view2 = view;
        if (view2 instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view2;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i5 = i2 + scrollX;
                if (i5 >= childAt.getLeft() && i5 < childAt.getRight() && (i4 = i3 + scrollY) >= childAt.getTop() && i4 < childAt.getBottom()) {
                    if (mo1362c(childAt, true, i, i5 - childAt.getLeft(), i4 - childAt.getTop())) {
                        return true;
                    }
                }
            }
        }
        return z && view.canScrollHorizontally(-i);
    }

    public boolean canScrollHorizontally(int i) {
        if (this.f1084h == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        return i < 0 ? scrollX > ((int) (((float) clientWidth) * this.f1096t)) : i > 0 && scrollX < ((int) (((float) clientWidth) * this.f1097u));
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0207f) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        this.f1090n = true;
        if (this.f1089m.isFinished() || !this.f1089m.computeScrollOffset()) {
            mo1366d(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.f1089m.getCurrX();
        int currY = this.f1089m.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!mo1389o(currX)) {
                this.f1089m.abortAnimation();
                scrollTo(0, currY);
            }
        }
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        postInvalidateOnAnimation();
    }

    /* renamed from: d */
    public final void mo1366d(boolean z) {
        boolean z2 = this.f1079a0 == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.f1089m.isFinished()) {
                this.f1089m.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.f1089m.getCurrX();
                int currY = this.f1089m.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        mo1389o(currX);
                    }
                }
            }
        }
        this.f1101y = false;
        for (int i = 0; i < this.f1081e.size(); i++) {
            C0206e eVar = this.f1081e.get(i);
            if (eVar.f1106c) {
                eVar.f1106c = false;
                z2 = true;
            }
        }
        if (!z2) {
            return;
        }
        if (z) {
            Runnable runnable = this.f1078W;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postOnAnimation(runnable);
            return;
        }
        this.f1078W.run();
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x0059 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchKeyEvent(android.view.KeyEvent r6) {
        /*
            r5 = this;
            boolean r0 = super.dispatchKeyEvent(r6)
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x0059
            int r0 = r6.getAction()
            if (r0 != 0) goto L_0x0056
            int r0 = r6.getKeyCode()
            r3 = 21
            r4 = 2
            if (r0 == r3) goto L_0x0044
            r3 = 22
            if (r0 == r3) goto L_0x0036
            r3 = 61
            if (r0 == r3) goto L_0x0020
            goto L_0x0056
        L_0x0020:
            boolean r0 = r6.hasNoModifiers()
            if (r0 == 0) goto L_0x002b
            boolean r6 = r5.mo1361b(r4)
            goto L_0x0057
        L_0x002b:
            boolean r6 = r6.hasModifiers(r2)
            if (r6 == 0) goto L_0x0056
            boolean r6 = r5.mo1361b(r2)
            goto L_0x0057
        L_0x0036:
            boolean r6 = r6.hasModifiers(r4)
            if (r6 == 0) goto L_0x0041
            boolean r6 = r5.mo1388n()
            goto L_0x0057
        L_0x0041:
            r6 = 66
            goto L_0x0051
        L_0x0044:
            boolean r6 = r6.hasModifiers(r4)
            if (r6 == 0) goto L_0x004f
            boolean r6 = r5.mo1387m()
            goto L_0x0057
        L_0x004f:
            r6 = 17
        L_0x0051:
            boolean r6 = r5.mo1361b(r6)
            goto L_0x0057
        L_0x0056:
            r6 = 0
        L_0x0057:
            if (r6 == 0) goto L_0x005a
        L_0x0059:
            r1 = 1
        L_0x005a:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        C0206e h;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (h = mo1382h(childAt)) != null && h.f1105b == this.f1085i && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    public void draw(Canvas canvas) {
        C0885id idVar;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean z = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (idVar = this.f1084h) != null && idVar.mo4027c() > 1)) {
            if (!this.f1071P.isFinished()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) (getPaddingTop() + (-height)), this.f1096t * ((float) width));
                this.f1071P.setSize(height, width);
                z = false | this.f1071P.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.f1072Q.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f1097u + 1.0f)) * ((float) width2));
                this.f1072Q.setSize(height2, width2);
                z |= this.f1072Q.draw(canvas);
                canvas.restoreToCount(save2);
            }
        } else {
            this.f1071P.finish();
            this.f1072Q.finish();
        }
        if (z) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postInvalidateOnAnimation();
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1093q;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    /* renamed from: e */
    public void mo1371e() {
        int c = this.f1084h.mo4027c();
        this.f1080d = c;
        boolean z = this.f1081e.size() < (this.f1102z * 2) + 1 && this.f1081e.size() < c;
        int i = this.f1085i;
        for (int i2 = 0; i2 < this.f1081e.size(); i2++) {
            C0885id idVar = this.f1084h;
            Object obj = this.f1081e.get(i2).f1104a;
            Objects.requireNonNull(idVar);
        }
        Collections.sort(this.f1081e, f1053c0);
        if (z) {
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                C0207f fVar = (C0207f) getChildAt(i3).getLayoutParams();
                if (!fVar.f1109a) {
                    fVar.f1111c = 0.0f;
                }
            }
            mo1416v(i, false, true, 0);
            requestLayout();
        }
    }

    /* renamed from: f */
    public final void mo1372f(int i) {
        C0209h hVar = this.f1077V;
        if (hVar != null) {
            hVar.mo126c(i);
        }
        List<C0209h> list = this.f1076U;
        if (list != null) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0209h hVar2 = this.f1076U.get(i2);
                if (hVar2 != null) {
                    hVar2.mo126c(i);
                }
            }
        }
    }

    /* renamed from: g */
    public final Rect mo1373g(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left = viewGroup.getLeft() + rect.left;
            rect.right = viewGroup.getRight() + rect.right;
            rect.top = viewGroup.getTop() + rect.top;
            rect.bottom = viewGroup.getBottom() + rect.bottom;
            parent = viewGroup.getParent();
        }
        return rect;
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0207f();
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0207f(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public C0885id getAdapter() {
        return this.f1084h;
    }

    public int getChildDrawingOrder(int i, int i2) {
        throw null;
    }

    public int getCurrentItem() {
        return this.f1085i;
    }

    public int getOffscreenPageLimit() {
        return this.f1102z;
    }

    public int getPageMargin() {
        return this.f1092p;
    }

    /* renamed from: h */
    public C0206e mo1382h(View view) {
        for (int i = 0; i < this.f1081e.size(); i++) {
            C0206e eVar = this.f1081e.get(i);
            if (this.f1084h.mo4030f(view, eVar.f1104a)) {
                return eVar;
            }
        }
        return null;
    }

    /* renamed from: i */
    public final C0206e mo1383i() {
        int i;
        int clientWidth = getClientWidth();
        float f = 0.0f;
        float scrollX = clientWidth > 0 ? ((float) getScrollX()) / ((float) clientWidth) : 0.0f;
        float f2 = clientWidth > 0 ? ((float) this.f1092p) / ((float) clientWidth) : 0.0f;
        C0206e eVar = null;
        float f3 = 0.0f;
        int i2 = -1;
        int i3 = 0;
        boolean z = true;
        while (i3 < this.f1081e.size()) {
            C0206e eVar2 = this.f1081e.get(i3);
            if (!z && eVar2.f1105b != (i = i2 + 1)) {
                eVar2 = this.f1082f;
                eVar2.f1108e = f + f3 + f2;
                eVar2.f1105b = i;
                Objects.requireNonNull(this.f1084h);
                eVar2.f1107d = 1.0f;
                i3--;
            }
            f = eVar2.f1108e;
            float f4 = eVar2.f1107d + f + f2;
            if (!z && scrollX < f) {
                return eVar;
            }
            if (scrollX < f4 || i3 == this.f1081e.size() - 1) {
                return eVar2;
            }
            i2 = eVar2.f1105b;
            f3 = eVar2.f1107d;
            i3++;
            eVar = eVar2;
            z = false;
        }
        return eVar;
    }

    /* renamed from: j */
    public C0206e mo1384j(int i) {
        for (int i2 = 0; i2 < this.f1081e.size(); i2++) {
            C0206e eVar = this.f1081e.get(i2);
            if (eVar.f1105b == i) {
                return eVar;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0064  */
    /* renamed from: k */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1385k(int r13, float r14, int r15) {
        /*
            r12 = this;
            int r0 = r12.f1075T
            r1 = 0
            r2 = 1
            if (r0 <= 0) goto L_0x006b
            int r0 = r12.getScrollX()
            int r3 = r12.getPaddingLeft()
            int r4 = r12.getPaddingRight()
            int r5 = r12.getWidth()
            int r6 = r12.getChildCount()
            r7 = 0
        L_0x001b:
            if (r7 >= r6) goto L_0x006b
            android.view.View r8 = r12.getChildAt(r7)
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r9 = (androidx.viewpager.widget.ViewPager.C0207f) r9
            boolean r10 = r9.f1109a
            if (r10 != 0) goto L_0x002c
            goto L_0x0068
        L_0x002c:
            int r9 = r9.f1110b
            r9 = r9 & 7
            if (r9 == r2) goto L_0x004d
            r10 = 3
            if (r9 == r10) goto L_0x0047
            r10 = 5
            if (r9 == r10) goto L_0x003a
            r9 = r3
            goto L_0x005c
        L_0x003a:
            int r9 = r5 - r4
            int r10 = r8.getMeasuredWidth()
            int r9 = r9 - r10
            int r10 = r8.getMeasuredWidth()
            int r4 = r4 + r10
            goto L_0x0059
        L_0x0047:
            int r9 = r8.getWidth()
            int r9 = r9 + r3
            goto L_0x005c
        L_0x004d:
            int r9 = r8.getMeasuredWidth()
            int r9 = r5 - r9
            int r9 = r9 / 2
            int r9 = java.lang.Math.max(r9, r3)
        L_0x0059:
            r11 = r9
            r9 = r3
            r3 = r11
        L_0x005c:
            int r3 = r3 + r0
            int r10 = r8.getLeft()
            int r3 = r3 - r10
            if (r3 == 0) goto L_0x0067
            r8.offsetLeftAndRight(r3)
        L_0x0067:
            r3 = r9
        L_0x0068:
            int r7 = r7 + 1
            goto L_0x001b
        L_0x006b:
            androidx.viewpager.widget.ViewPager$h r0 = r12.f1077V
            if (r0 == 0) goto L_0x0072
            r0.mo124a(r13, r14, r15)
        L_0x0072:
            java.util.List<androidx.viewpager.widget.ViewPager$h> r0 = r12.f1076U
            if (r0 == 0) goto L_0x008c
            int r0 = r0.size()
        L_0x007a:
            if (r1 >= r0) goto L_0x008c
            java.util.List<androidx.viewpager.widget.ViewPager$h> r3 = r12.f1076U
            java.lang.Object r3 = r3.get(r1)
            androidx.viewpager.widget.ViewPager$h r3 = (androidx.viewpager.widget.ViewPager.C0209h) r3
            if (r3 == 0) goto L_0x0089
            r3.mo124a(r13, r14, r15)
        L_0x0089:
            int r1 = r1 + 1
            goto L_0x007a
        L_0x008c:
            r12.f1074S = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.mo1385k(int, float, int):void");
    }

    /* renamed from: l */
    public final void mo1386l(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1065J) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1061F = motionEvent.getX(i);
            this.f1065J = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f1066K;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* renamed from: m */
    public boolean mo1387m() {
        int i = this.f1085i;
        if (i <= 0) {
            return false;
        }
        this.f1101y = false;
        mo1416v(i - 1, true, false, 0);
        return true;
    }

    /* renamed from: n */
    public boolean mo1388n() {
        C0885id idVar = this.f1084h;
        if (idVar == null || this.f1085i >= idVar.mo4027c() - 1) {
            return false;
        }
        this.f1101y = false;
        mo1416v(this.f1085i + 1, true, false, 0);
        return true;
    }

    /* renamed from: o */
    public final boolean mo1389o(int i) {
        if (this.f1081e.size() != 0) {
            C0206e i2 = mo1383i();
            int clientWidth = getClientWidth();
            int i3 = this.f1092p;
            int i4 = clientWidth + i3;
            float f = (float) clientWidth;
            int i5 = i2.f1105b;
            float f2 = ((((float) i) / f) - i2.f1108e) / (i2.f1107d + (((float) i3) / f));
            this.f1074S = false;
            mo1385k(i5, f2, (int) (((float) i4) * f2));
            if (this.f1074S) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.f1073R) {
            return false;
        } else {
            this.f1074S = false;
            mo1385k(0, 0.0f, 0);
            if (this.f1074S) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1073R = true;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.f1078W);
        Scroller scroller = this.f1089m;
        if (scroller != null && !scroller.isFinished()) {
            this.f1089m.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0065  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(android.graphics.Canvas r18) {
        /*
            r17 = this;
            r0 = r17
            super.onDraw(r18)
            int r1 = r0.f1092p
            if (r1 <= 0) goto L_0x00ac
            android.graphics.drawable.Drawable r1 = r0.f1093q
            if (r1 == 0) goto L_0x00ac
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r1 = r0.f1081e
            int r1 = r1.size()
            if (r1 <= 0) goto L_0x00ac
            id r1 = r0.f1084h
            if (r1 == 0) goto L_0x00ac
            int r1 = r17.getScrollX()
            int r2 = r17.getWidth()
            int r3 = r0.f1092p
            float r3 = (float) r3
            float r4 = (float) r2
            float r3 = r3 / r4
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r5 = r0.f1081e
            r6 = 0
            java.lang.Object r5 = r5.get(r6)
            androidx.viewpager.widget.ViewPager$e r5 = (androidx.viewpager.widget.ViewPager.C0206e) r5
            float r7 = r5.f1108e
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r8 = r0.f1081e
            int r8 = r8.size()
            int r9 = r5.f1105b
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r10 = r0.f1081e
            int r11 = r8 + -1
            java.lang.Object r10 = r10.get(r11)
            androidx.viewpager.widget.ViewPager$e r10 = (androidx.viewpager.widget.ViewPager.C0206e) r10
            int r10 = r10.f1105b
        L_0x0045:
            if (r9 >= r10) goto L_0x00ac
        L_0x0047:
            int r11 = r5.f1105b
            if (r9 <= r11) goto L_0x0058
            if (r6 >= r8) goto L_0x0058
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r5 = r0.f1081e
            int r6 = r6 + 1
            java.lang.Object r5 = r5.get(r6)
            androidx.viewpager.widget.ViewPager$e r5 = (androidx.viewpager.widget.ViewPager.C0206e) r5
            goto L_0x0047
        L_0x0058:
            if (r9 != r11) goto L_0x0065
            float r7 = r5.f1108e
            float r11 = r5.f1107d
            float r12 = r7 + r11
            float r12 = r12 * r4
            float r7 = r7 + r11
            float r7 = r7 + r3
            goto L_0x0073
        L_0x0065:
            id r11 = r0.f1084h
            java.util.Objects.requireNonNull(r11)
            r11 = 1065353216(0x3f800000, float:1.0)
            float r12 = r7 + r11
            float r12 = r12 * r4
            float r11 = r11 + r3
            float r11 = r11 + r7
            r7 = r11
        L_0x0073:
            int r11 = r0.f1092p
            float r11 = (float) r11
            float r11 = r11 + r12
            float r13 = (float) r1
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 <= 0) goto L_0x009b
            android.graphics.drawable.Drawable r11 = r0.f1093q
            int r13 = java.lang.Math.round(r12)
            int r14 = r0.f1094r
            int r15 = r0.f1092p
            float r15 = (float) r15
            float r15 = r15 + r12
            int r15 = java.lang.Math.round(r15)
            r16 = r3
            int r3 = r0.f1095s
            r11.setBounds(r13, r14, r15, r3)
            android.graphics.drawable.Drawable r3 = r0.f1093q
            r11 = r18
            r3.draw(r11)
            goto L_0x009f
        L_0x009b:
            r11 = r18
            r16 = r3
        L_0x009f:
            int r3 = r1 + r2
            float r3 = (float) r3
            int r3 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r3 <= 0) goto L_0x00a7
            goto L_0x00ac
        L_0x00a7:
            int r9 = r9 + 1
            r3 = r16
            goto L_0x0045
        L_0x00ac:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onDraw(android.graphics.Canvas):void");
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            mo1414t();
            return false;
        }
        if (action != 0) {
            if (this.f1056A) {
                return true;
            }
            if (this.f1057B) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent.getX();
            this.f1063H = x;
            this.f1061F = x;
            float y = motionEvent.getY();
            this.f1064I = y;
            this.f1062G = y;
            this.f1065J = motionEvent2.getPointerId(0);
            this.f1057B = false;
            this.f1090n = true;
            this.f1089m.computeScrollOffset();
            if (this.f1079a0 != 2 || Math.abs(this.f1089m.getFinalX() - this.f1089m.getCurrX()) <= this.f1070O) {
                mo1366d(false);
                this.f1056A = false;
            } else {
                this.f1089m.abortAnimation();
                this.f1101y = false;
                mo1402q(this.f1085i);
                this.f1056A = true;
                mo1405s(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i = this.f1065J;
            if (i != -1) {
                int findPointerIndex = motionEvent2.findPointerIndex(i);
                float x2 = motionEvent2.getX(findPointerIndex);
                float f = x2 - this.f1061F;
                float abs = Math.abs(f);
                float y2 = motionEvent2.getY(findPointerIndex);
                float abs2 = Math.abs(y2 - this.f1064I);
                if (f != 0.0f) {
                    float f2 = this.f1061F;
                    if (!((f2 < ((float) this.f1059D) && f > 0.0f) || (f2 > ((float) (getWidth() - this.f1059D)) && f < 0.0f))) {
                        if (mo1362c(this, false, (int) f, (int) x2, (int) y2)) {
                            this.f1061F = x2;
                            this.f1062G = y2;
                            this.f1057B = true;
                            return false;
                        }
                    }
                }
                int i2 = this.f1060E;
                if (abs > ((float) i2) && abs * 0.5f > abs2) {
                    this.f1056A = true;
                    mo1405s(true);
                    setScrollState(1);
                    this.f1061F = f > 0.0f ? this.f1063H + ((float) this.f1060E) : this.f1063H - ((float) this.f1060E);
                    this.f1062G = y2;
                    setScrollingCacheEnabled(true);
                } else if (abs2 > ((float) i2)) {
                    this.f1057B = true;
                }
                if (this.f1056A && mo1401p(x2)) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    postInvalidateOnAnimation();
                }
            }
        } else if (action == 6) {
            mo1386l(motionEvent);
        }
        if (this.f1066K == null) {
            this.f1066K = VelocityTracker.obtain();
        }
        this.f1066K.addMovement(motionEvent2);
        return this.f1056A;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x008e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            r18 = this;
            r0 = r18
            int r1 = r18.getChildCount()
            int r2 = r22 - r20
            int r3 = r23 - r21
            int r4 = r18.getPaddingLeft()
            int r5 = r18.getPaddingTop()
            int r6 = r18.getPaddingRight()
            int r7 = r18.getPaddingBottom()
            int r8 = r18.getScrollX()
            r10 = 0
            r11 = 0
        L_0x0020:
            r12 = 8
            if (r10 >= r1) goto L_0x00b6
            android.view.View r13 = r0.getChildAt(r10)
            int r14 = r13.getVisibility()
            if (r14 == r12) goto L_0x00b2
            android.view.ViewGroup$LayoutParams r12 = r13.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r12 = (androidx.viewpager.widget.ViewPager.C0207f) r12
            boolean r14 = r12.f1109a
            if (r14 == 0) goto L_0x00b2
            int r12 = r12.f1110b
            r14 = r12 & 7
            r12 = r12 & 112(0x70, float:1.57E-43)
            r15 = 1
            if (r14 == r15) goto L_0x005c
            r15 = 3
            if (r14 == r15) goto L_0x0056
            r15 = 5
            if (r14 == r15) goto L_0x0049
            r14 = r4
            goto L_0x006d
        L_0x0049:
            int r14 = r2 - r6
            int r15 = r13.getMeasuredWidth()
            int r14 = r14 - r15
            int r15 = r13.getMeasuredWidth()
            int r6 = r6 + r15
            goto L_0x0068
        L_0x0056:
            int r14 = r13.getMeasuredWidth()
            int r14 = r14 + r4
            goto L_0x006d
        L_0x005c:
            int r14 = r13.getMeasuredWidth()
            int r14 = r2 - r14
            int r14 = r14 / 2
            int r14 = java.lang.Math.max(r14, r4)
        L_0x0068:
            r17 = r14
            r14 = r4
            r4 = r17
        L_0x006d:
            r15 = 16
            if (r12 == r15) goto L_0x008e
            r15 = 48
            if (r12 == r15) goto L_0x0088
            r15 = 80
            if (r12 == r15) goto L_0x007b
            r12 = r5
            goto L_0x009f
        L_0x007b:
            int r12 = r3 - r7
            int r15 = r13.getMeasuredHeight()
            int r12 = r12 - r15
            int r15 = r13.getMeasuredHeight()
            int r7 = r7 + r15
            goto L_0x009a
        L_0x0088:
            int r12 = r13.getMeasuredHeight()
            int r12 = r12 + r5
            goto L_0x009f
        L_0x008e:
            int r12 = r13.getMeasuredHeight()
            int r12 = r3 - r12
            int r12 = r12 / 2
            int r12 = java.lang.Math.max(r12, r5)
        L_0x009a:
            r17 = r12
            r12 = r5
            r5 = r17
        L_0x009f:
            int r4 = r4 + r8
            int r15 = r13.getMeasuredWidth()
            int r15 = r15 + r4
            int r16 = r13.getMeasuredHeight()
            int r9 = r16 + r5
            r13.layout(r4, r5, r15, r9)
            int r11 = r11 + 1
            r5 = r12
            r4 = r14
        L_0x00b2:
            int r10 = r10 + 1
            goto L_0x0020
        L_0x00b6:
            int r2 = r2 - r4
            int r2 = r2 - r6
            r6 = 0
        L_0x00b9:
            if (r6 >= r1) goto L_0x0108
            android.view.View r8 = r0.getChildAt(r6)
            int r9 = r8.getVisibility()
            if (r9 == r12) goto L_0x0105
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r9 = (androidx.viewpager.widget.ViewPager.C0207f) r9
            boolean r10 = r9.f1109a
            if (r10 != 0) goto L_0x0105
            androidx.viewpager.widget.ViewPager$e r10 = r0.mo1382h(r8)
            if (r10 == 0) goto L_0x0105
            float r13 = (float) r2
            float r10 = r10.f1108e
            float r10 = r10 * r13
            int r10 = (int) r10
            int r10 = r10 + r4
            boolean r14 = r9.f1112d
            if (r14 == 0) goto L_0x00f8
            r14 = 0
            r9.f1112d = r14
            float r9 = r9.f1111c
            float r13 = r13 * r9
            int r9 = (int) r13
            r13 = 1073741824(0x40000000, float:2.0)
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r13)
            int r14 = r3 - r5
            int r14 = r14 - r7
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r13)
            r8.measure(r9, r13)
        L_0x00f8:
            int r9 = r8.getMeasuredWidth()
            int r9 = r9 + r10
            int r13 = r8.getMeasuredHeight()
            int r13 = r13 + r5
            r8.layout(r10, r5, r9, r13)
        L_0x0105:
            int r6 = r6 + 1
            goto L_0x00b9
        L_0x0108:
            r0.f1094r = r5
            int r3 = r3 - r7
            r0.f1095s = r3
            r0.f1075T = r11
            boolean r1 = r0.f1073R
            if (r1 == 0) goto L_0x011a
            int r1 = r0.f1085i
            r2 = 0
            r0.mo1415u(r1, r2, r2, r2)
            goto L_0x011b
        L_0x011a:
            r2 = 0
        L_0x011b:
            r0.f1073R = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0089  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x008e  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0093  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00a8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r14, int r15) {
        /*
            r13 = this;
            r0 = 0
            int r14 = android.view.ViewGroup.getDefaultSize(r0, r14)
            int r15 = android.view.ViewGroup.getDefaultSize(r0, r15)
            r13.setMeasuredDimension(r14, r15)
            int r14 = r13.getMeasuredWidth()
            int r15 = r14 / 10
            int r1 = r13.f1058C
            int r15 = java.lang.Math.min(r15, r1)
            r13.f1059D = r15
            int r15 = r13.getPaddingLeft()
            int r14 = r14 - r15
            int r15 = r13.getPaddingRight()
            int r14 = r14 - r15
            int r15 = r13.getMeasuredHeight()
            int r1 = r13.getPaddingTop()
            int r15 = r15 - r1
            int r1 = r13.getPaddingBottom()
            int r15 = r15 - r1
            int r1 = r13.getChildCount()
            r2 = 0
        L_0x0037:
            r3 = 8
            r4 = 1
            r5 = 1073741824(0x40000000, float:2.0)
            if (r2 >= r1) goto L_0x00b2
            android.view.View r6 = r13.getChildAt(r2)
            int r7 = r6.getVisibility()
            if (r7 == r3) goto L_0x00af
            android.view.ViewGroup$LayoutParams r3 = r6.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r3 = (androidx.viewpager.widget.ViewPager.C0207f) r3
            if (r3 == 0) goto L_0x00af
            boolean r7 = r3.f1109a
            if (r7 == 0) goto L_0x00af
            int r7 = r3.f1110b
            r8 = r7 & 7
            r7 = r7 & 112(0x70, float:1.57E-43)
            r9 = 48
            if (r7 == r9) goto L_0x0065
            r9 = 80
            if (r7 != r9) goto L_0x0063
            goto L_0x0065
        L_0x0063:
            r7 = 0
            goto L_0x0066
        L_0x0065:
            r7 = 1
        L_0x0066:
            r9 = 3
            if (r8 == r9) goto L_0x006e
            r9 = 5
            if (r8 != r9) goto L_0x006d
            goto L_0x006e
        L_0x006d:
            r4 = 0
        L_0x006e:
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r7 == 0) goto L_0x0075
            r8 = 1073741824(0x40000000, float:2.0)
            goto L_0x007a
        L_0x0075:
            if (r4 == 0) goto L_0x007a
            r9 = 1073741824(0x40000000, float:2.0)
            goto L_0x007c
        L_0x007a:
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x007c:
            int r10 = r3.width
            r11 = -1
            r12 = -2
            if (r10 == r12) goto L_0x0089
            if (r10 == r11) goto L_0x0085
            goto L_0x0086
        L_0x0085:
            r10 = r14
        L_0x0086:
            r8 = 1073741824(0x40000000, float:2.0)
            goto L_0x008a
        L_0x0089:
            r10 = r14
        L_0x008a:
            int r3 = r3.height
            if (r3 == r12) goto L_0x0093
            if (r3 == r11) goto L_0x0091
            goto L_0x0095
        L_0x0091:
            r3 = r15
            goto L_0x0095
        L_0x0093:
            r3 = r15
            r5 = r9
        L_0x0095:
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r8)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r5)
            r6.measure(r8, r3)
            if (r7 == 0) goto L_0x00a8
            int r3 = r6.getMeasuredHeight()
            int r15 = r15 - r3
            goto L_0x00af
        L_0x00a8:
            if (r4 == 0) goto L_0x00af
            int r3 = r6.getMeasuredWidth()
            int r14 = r14 - r3
        L_0x00af:
            int r2 = r2 + 1
            goto L_0x0037
        L_0x00b2:
            android.view.View.MeasureSpec.makeMeasureSpec(r14, r5)
            int r15 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r5)
            r13.f1098v = r15
            r13.f1099w = r4
            int r15 = r13.f1085i
            r13.mo1402q(r15)
            r13.f1099w = r0
            int r15 = r13.getChildCount()
        L_0x00c8:
            if (r0 >= r15) goto L_0x00f2
            android.view.View r1 = r13.getChildAt(r0)
            int r2 = r1.getVisibility()
            if (r2 == r3) goto L_0x00ef
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r2 = (androidx.viewpager.widget.ViewPager.C0207f) r2
            if (r2 == 0) goto L_0x00e0
            boolean r4 = r2.f1109a
            if (r4 != 0) goto L_0x00ef
        L_0x00e0:
            float r4 = (float) r14
            float r2 = r2.f1111c
            float r4 = r4 * r2
            int r2 = (int) r4
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r5)
            int r4 = r13.f1098v
            r1.measure(r2, r4)
        L_0x00ef:
            int r0 = r0 + 1
            goto L_0x00c8
        L_0x00f2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onMeasure(int, int):void");
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        int i3;
        C0206e h;
        int childCount = getChildCount();
        int i4 = -1;
        if ((i & 2) != 0) {
            i4 = childCount;
            i3 = 0;
            i2 = 1;
        } else {
            i3 = childCount - 1;
            i2 = -1;
        }
        while (i3 != i4) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (h = mo1382h(childAt)) != null && h.f1105b == this.f1085i && childAt.requestFocus(i, rect)) {
                return true;
            }
            i3 += i2;
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0211j)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0211j jVar = (C0211j) parcelable;
        super.onRestoreInstanceState(jVar.f43d);
        C0885id idVar = this.f1084h;
        if (idVar != null) {
            idVar.mo4031g(jVar.f1118g, jVar.f1119h);
            mo1416v(jVar.f1117f, false, true, 0);
            return;
        }
        this.f1086j = jVar.f1117f;
        this.f1087k = jVar.f1118g;
        this.f1088l = jVar.f1119h;
    }

    public Parcelable onSaveInstanceState() {
        C0211j jVar = new C0211j(super.onSaveInstanceState());
        jVar.f1117f = this.f1085i;
        C0885id idVar = this.f1084h;
        if (idVar != null) {
            jVar.f1118g = idVar.mo4032h();
        }
        return jVar;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            int i5 = this.f1092p;
            mo1403r(i, i3, i5, i5);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:68:0x0198  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
            r9 = this;
            int r0 = r10.getAction()
            r1 = 0
            if (r0 != 0) goto L_0x000e
            int r0 = r10.getEdgeFlags()
            if (r0 == 0) goto L_0x000e
            return r1
        L_0x000e:
            id r0 = r9.f1084h
            if (r0 == 0) goto L_0x019e
            int r0 = r0.mo4027c()
            if (r0 != 0) goto L_0x001a
            goto L_0x019e
        L_0x001a:
            android.view.VelocityTracker r0 = r9.f1066K
            if (r0 != 0) goto L_0x0024
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r9.f1066K = r0
        L_0x0024:
            android.view.VelocityTracker r0 = r9.f1066K
            r0.addMovement(r10)
            int r0 = r10.getAction()
            r0 = r0 & 255(0xff, float:3.57E-43)
            r2 = 1
            if (r0 == 0) goto L_0x0174
            r3 = -1
            if (r0 == r2) goto L_0x00de
            r4 = 2
            if (r0 == r4) goto L_0x006f
            r3 = 3
            if (r0 == r3) goto L_0x0064
            r3 = 5
            if (r0 == r3) goto L_0x0054
            r3 = 6
            if (r0 == r3) goto L_0x0043
            goto L_0x0196
        L_0x0043:
            r9.mo1386l(r10)
            int r0 = r9.f1065J
            int r0 = r10.findPointerIndex(r0)
            float r10 = r10.getX(r0)
            r9.f1061F = r10
            goto L_0x0196
        L_0x0054:
            int r0 = r10.getActionIndex()
            float r3 = r10.getX(r0)
            r9.f1061F = r3
            int r10 = r10.getPointerId(r0)
            goto L_0x0194
        L_0x0064:
            boolean r10 = r9.f1056A
            if (r10 == 0) goto L_0x0196
            int r10 = r9.f1085i
            r9.mo1415u(r10, r2, r1, r1)
            goto L_0x016f
        L_0x006f:
            boolean r0 = r9.f1056A
            if (r0 != 0) goto L_0x00c9
            int r0 = r9.f1065J
            int r0 = r10.findPointerIndex(r0)
            if (r0 != r3) goto L_0x007d
            goto L_0x016f
        L_0x007d:
            float r3 = r10.getX(r0)
            float r4 = r9.f1061F
            float r4 = r3 - r4
            float r4 = java.lang.Math.abs(r4)
            float r0 = r10.getY(r0)
            float r5 = r9.f1062G
            float r5 = r0 - r5
            float r5 = java.lang.Math.abs(r5)
            int r6 = r9.f1060E
            float r6 = (float) r6
            int r6 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r6 <= 0) goto L_0x00c9
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 <= 0) goto L_0x00c9
            r9.f1056A = r2
            r9.mo1405s(r2)
            float r4 = r9.f1063H
            float r3 = r3 - r4
            r5 = 0
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 <= 0) goto L_0x00b2
            int r3 = r9.f1060E
            float r3 = (float) r3
            float r4 = r4 + r3
            goto L_0x00b6
        L_0x00b2:
            int r3 = r9.f1060E
            float r3 = (float) r3
            float r4 = r4 - r3
        L_0x00b6:
            r9.f1061F = r4
            r9.f1062G = r0
            r9.setScrollState(r2)
            r9.setScrollingCacheEnabled(r2)
            android.view.ViewParent r0 = r9.getParent()
            if (r0 == 0) goto L_0x00c9
            r0.requestDisallowInterceptTouchEvent(r2)
        L_0x00c9:
            boolean r0 = r9.f1056A
            if (r0 == 0) goto L_0x0196
            int r0 = r9.f1065J
            int r0 = r10.findPointerIndex(r0)
            float r10 = r10.getX(r0)
            boolean r10 = r9.mo1401p(r10)
            r1 = r1 | r10
            goto L_0x0196
        L_0x00de:
            boolean r0 = r9.f1056A
            if (r0 == 0) goto L_0x0196
            android.view.VelocityTracker r0 = r9.f1066K
            r4 = 1000(0x3e8, float:1.401E-42)
            int r5 = r9.f1068M
            float r5 = (float) r5
            r0.computeCurrentVelocity(r4, r5)
            int r4 = r9.f1065J
            float r0 = r0.getXVelocity(r4)
            int r0 = (int) r0
            r9.f1101y = r2
            int r4 = r9.getClientWidth()
            int r5 = r9.getScrollX()
            androidx.viewpager.widget.ViewPager$e r6 = r9.mo1383i()
            int r7 = r9.f1092p
            float r7 = (float) r7
            float r4 = (float) r4
            float r7 = r7 / r4
            int r8 = r6.f1105b
            float r5 = (float) r5
            float r5 = r5 / r4
            float r4 = r6.f1108e
            float r5 = r5 - r4
            float r4 = r6.f1107d
            float r4 = r4 + r7
            float r5 = r5 / r4
            int r4 = r9.f1065J
            int r4 = r10.findPointerIndex(r4)
            float r10 = r10.getX(r4)
            float r4 = r9.f1063H
            float r10 = r10 - r4
            int r10 = (int) r10
            int r10 = java.lang.Math.abs(r10)
            int r4 = r9.f1069N
            if (r10 <= r4) goto L_0x0135
            int r10 = java.lang.Math.abs(r0)
            int r4 = r9.f1067L
            if (r10 <= r4) goto L_0x0135
            if (r0 <= 0) goto L_0x0132
            goto L_0x0143
        L_0x0132:
            int r8 = r8 + 1
            goto L_0x0143
        L_0x0135:
            int r10 = r9.f1085i
            if (r8 < r10) goto L_0x013d
            r10 = 1053609165(0x3ecccccd, float:0.4)
            goto L_0x0140
        L_0x013d:
            r10 = 1058642330(0x3f19999a, float:0.6)
        L_0x0140:
            float r5 = r5 + r10
            int r10 = (int) r5
            int r8 = r8 + r10
        L_0x0143:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r10 = r9.f1081e
            int r10 = r10.size()
            if (r10 <= 0) goto L_0x016c
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r10 = r9.f1081e
            java.lang.Object r10 = r10.get(r1)
            androidx.viewpager.widget.ViewPager$e r10 = (androidx.viewpager.widget.ViewPager.C0206e) r10
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r1 = r9.f1081e
            int r4 = r1.size()
            int r4 = r4 + r3
            java.lang.Object r1 = r1.get(r4)
            androidx.viewpager.widget.ViewPager$e r1 = (androidx.viewpager.widget.ViewPager.C0206e) r1
            int r10 = r10.f1105b
            int r1 = r1.f1105b
            int r1 = java.lang.Math.min(r8, r1)
            int r8 = java.lang.Math.max(r10, r1)
        L_0x016c:
            r9.mo1416v(r8, r2, r2, r0)
        L_0x016f:
            boolean r1 = r9.mo1414t()
            goto L_0x0196
        L_0x0174:
            android.widget.Scroller r0 = r9.f1089m
            r0.abortAnimation()
            r9.f1101y = r1
            int r0 = r9.f1085i
            r9.mo1402q(r0)
            float r0 = r10.getX()
            r9.f1063H = r0
            r9.f1061F = r0
            float r0 = r10.getY()
            r9.f1064I = r0
            r9.f1062G = r0
            int r10 = r10.getPointerId(r1)
        L_0x0194:
            r9.f1065J = r10
        L_0x0196:
            if (r1 == 0) goto L_0x019d
            java.util.WeakHashMap<android.view.View, java.lang.String> r10 = p000.C0010a7.f28a
            r9.postInvalidateOnAnimation()
        L_0x019d:
            return r2
        L_0x019e:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public final boolean mo1401p(float f) {
        boolean z;
        boolean z2;
        float f2 = this.f1061F - f;
        this.f1061F = f;
        float scrollX = ((float) getScrollX()) + f2;
        float clientWidth = (float) getClientWidth();
        float f3 = this.f1096t * clientWidth;
        float f4 = this.f1097u * clientWidth;
        boolean z3 = false;
        C0206e eVar = this.f1081e.get(0);
        ArrayList<C0206e> arrayList = this.f1081e;
        C0206e eVar2 = arrayList.get(arrayList.size() - 1);
        if (eVar.f1105b != 0) {
            f3 = eVar.f1108e * clientWidth;
            z = false;
        } else {
            z = true;
        }
        if (eVar2.f1105b != this.f1084h.mo4027c() - 1) {
            f4 = eVar2.f1108e * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (scrollX < f3) {
            if (z) {
                this.f1071P.onPull(Math.abs(f3 - scrollX) / clientWidth);
                z3 = true;
            }
            scrollX = f3;
        } else if (scrollX > f4) {
            if (z2) {
                this.f1072Q.onPull(Math.abs(scrollX - f4) / clientWidth);
                z3 = true;
            }
            scrollX = f4;
        }
        int i = (int) scrollX;
        this.f1061F = (scrollX - ((float) i)) + this.f1061F;
        scrollTo(i, getScrollY());
        mo1389o(i);
        return z3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0056, code lost:
        if (r5 == r6) goto L_0x005d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00b6, code lost:
        if (r6 >= 0) goto L_0x00d4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00c4, code lost:
        if (r6 >= 0) goto L_0x00d4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00d2, code lost:
        if (r6 >= 0) goto L_0x00d4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00dd, code lost:
        r7 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0132, code lost:
        if (r10 < r14.f1081e.size()) goto L_0x015a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0146, code lost:
        if (r10 < r14.f1081e.size()) goto L_0x015a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x0158, code lost:
        if (r10 < r14.f1081e.size()) goto L_0x015a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x0163, code lost:
        r7 = null;
     */
    /* renamed from: q */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1402q(int r15) {
        /*
            r14 = this;
            int r0 = r14.f1085i
            if (r0 == r15) goto L_0x000b
            androidx.viewpager.widget.ViewPager$e r0 = r14.mo1384j(r0)
            r14.f1085i = r15
            goto L_0x000c
        L_0x000b:
            r0 = 0
        L_0x000c:
            id r15 = r14.f1084h
            if (r15 != 0) goto L_0x0011
            return
        L_0x0011:
            boolean r15 = r14.f1101y
            if (r15 == 0) goto L_0x0016
            return
        L_0x0016:
            android.os.IBinder r15 = r14.getWindowToken()
            if (r15 != 0) goto L_0x001d
            return
        L_0x001d:
            id r15 = r14.f1084h
            r15.mo4034j(r14)
            int r15 = r14.f1102z
            int r1 = r14.f1085i
            int r1 = r1 - r15
            r2 = 0
            int r1 = java.lang.Math.max(r2, r1)
            id r2 = r14.f1084h
            int r2 = r2.mo4027c()
            int r3 = r2 + -1
            int r4 = r14.f1085i
            int r4 = r4 + r15
            int r15 = java.lang.Math.min(r3, r4)
            int r3 = r14.f1080d
            if (r2 != r3) goto L_0x030e
            r3 = 0
        L_0x0040:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r4 = r14.f1081e
            int r4 = r4.size()
            if (r3 >= r4) goto L_0x005c
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r4 = r14.f1081e
            java.lang.Object r4 = r4.get(r3)
            androidx.viewpager.widget.ViewPager$e r4 = (androidx.viewpager.widget.ViewPager.C0206e) r4
            int r5 = r4.f1105b
            int r6 = r14.f1085i
            if (r5 < r6) goto L_0x0059
            if (r5 != r6) goto L_0x005c
            goto L_0x005d
        L_0x0059:
            int r3 = r3 + 1
            goto L_0x0040
        L_0x005c:
            r4 = 0
        L_0x005d:
            if (r4 != 0) goto L_0x0067
            if (r2 <= 0) goto L_0x0067
            int r4 = r14.f1085i
            androidx.viewpager.widget.ViewPager$e r4 = r14.mo1357a(r4, r3)
        L_0x0067:
            r5 = 0
            if (r4 == 0) goto L_0x028d
            int r6 = r3 + -1
            if (r6 < 0) goto L_0x0077
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            java.lang.Object r7 = r7.get(r6)
            androidx.viewpager.widget.ViewPager$e r7 = (androidx.viewpager.widget.ViewPager.C0206e) r7
            goto L_0x0078
        L_0x0077:
            r7 = 0
        L_0x0078:
            int r8 = r14.getClientWidth()
            r9 = 1073741824(0x40000000, float:2.0)
            if (r8 > 0) goto L_0x0082
            r10 = 0
            goto L_0x008e
        L_0x0082:
            float r10 = r4.f1107d
            float r10 = r9 - r10
            int r11 = r14.getPaddingLeft()
            float r11 = (float) r11
            float r12 = (float) r8
            float r11 = r11 / r12
            float r10 = r10 + r11
        L_0x008e:
            int r11 = r14.f1085i
            int r11 = r11 + -1
            r12 = 0
        L_0x0093:
            if (r11 < 0) goto L_0x00e1
            int r13 = (r12 > r10 ? 1 : (r12 == r10 ? 0 : -1))
            if (r13 < 0) goto L_0x00b9
            if (r11 >= r1) goto L_0x00b9
            if (r7 != 0) goto L_0x009e
            goto L_0x00e1
        L_0x009e:
            int r13 = r7.f1105b
            if (r11 != r13) goto L_0x00de
            boolean r13 = r7.f1106c
            if (r13 != 0) goto L_0x00de
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r13 = r14.f1081e
            r13.remove(r6)
            id r13 = r14.f1084h
            java.lang.Object r7 = r7.f1104a
            r13.mo4025a(r14, r11, r7)
            int r6 = r6 + -1
            int r3 = r3 + -1
            if (r6 < 0) goto L_0x00dd
            goto L_0x00d4
        L_0x00b9:
            if (r7 == 0) goto L_0x00c7
            int r13 = r7.f1105b
            if (r11 != r13) goto L_0x00c7
            float r7 = r7.f1107d
            float r12 = r12 + r7
            int r6 = r6 + -1
            if (r6 < 0) goto L_0x00dd
            goto L_0x00d4
        L_0x00c7:
            int r7 = r6 + 1
            androidx.viewpager.widget.ViewPager$e r7 = r14.mo1357a(r11, r7)
            float r7 = r7.f1107d
            float r12 = r12 + r7
            int r3 = r3 + 1
            if (r6 < 0) goto L_0x00dd
        L_0x00d4:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            java.lang.Object r7 = r7.get(r6)
            androidx.viewpager.widget.ViewPager$e r7 = (androidx.viewpager.widget.ViewPager.C0206e) r7
            goto L_0x00de
        L_0x00dd:
            r7 = 0
        L_0x00de:
            int r11 = r11 + -1
            goto L_0x0093
        L_0x00e1:
            float r1 = r4.f1107d
            int r6 = r3 + 1
            int r7 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r7 >= 0) goto L_0x0167
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            int r7 = r7.size()
            if (r6 >= r7) goto L_0x00fa
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            java.lang.Object r7 = r7.get(r6)
            androidx.viewpager.widget.ViewPager$e r7 = (androidx.viewpager.widget.ViewPager.C0206e) r7
            goto L_0x00fb
        L_0x00fa:
            r7 = 0
        L_0x00fb:
            if (r8 > 0) goto L_0x00ff
            r8 = 0
            goto L_0x0108
        L_0x00ff:
            int r10 = r14.getPaddingRight()
            float r10 = (float) r10
            float r8 = (float) r8
            float r10 = r10 / r8
            float r8 = r10 + r9
        L_0x0108:
            int r9 = r14.f1085i
            int r9 = r9 + 1
            r10 = r6
        L_0x010d:
            if (r9 >= r2) goto L_0x0167
            int r11 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r11 < 0) goto L_0x0135
            if (r9 <= r15) goto L_0x0135
            if (r7 != 0) goto L_0x0118
            goto L_0x0167
        L_0x0118:
            int r11 = r7.f1105b
            if (r9 != r11) goto L_0x0164
            boolean r11 = r7.f1106c
            if (r11 != 0) goto L_0x0164
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r11 = r14.f1081e
            r11.remove(r10)
            id r11 = r14.f1084h
            java.lang.Object r7 = r7.f1104a
            r11.mo4025a(r14, r9, r7)
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            int r7 = r7.size()
            if (r10 >= r7) goto L_0x0163
            goto L_0x015a
        L_0x0135:
            if (r7 == 0) goto L_0x0149
            int r11 = r7.f1105b
            if (r9 != r11) goto L_0x0149
            float r7 = r7.f1107d
            float r1 = r1 + r7
            int r10 = r10 + 1
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            int r7 = r7.size()
            if (r10 >= r7) goto L_0x0163
            goto L_0x015a
        L_0x0149:
            androidx.viewpager.widget.ViewPager$e r7 = r14.mo1357a(r9, r10)
            int r10 = r10 + 1
            float r7 = r7.f1107d
            float r1 = r1 + r7
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            int r7 = r7.size()
            if (r10 >= r7) goto L_0x0163
        L_0x015a:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r7 = r14.f1081e
            java.lang.Object r7 = r7.get(r10)
            androidx.viewpager.widget.ViewPager$e r7 = (androidx.viewpager.widget.ViewPager.C0206e) r7
            goto L_0x0164
        L_0x0163:
            r7 = 0
        L_0x0164:
            int r9 = r9 + 1
            goto L_0x010d
        L_0x0167:
            id r15 = r14.f1084h
            int r15 = r15.mo4027c()
            int r1 = r14.getClientWidth()
            if (r1 <= 0) goto L_0x0179
            int r2 = r14.f1092p
            float r2 = (float) r2
            float r1 = (float) r1
            float r2 = r2 / r1
            goto L_0x017a
        L_0x0179:
            r2 = 0
        L_0x017a:
            r1 = 1065353216(0x3f800000, float:1.0)
            if (r0 == 0) goto L_0x0203
            int r7 = r0.f1105b
            int r8 = r4.f1105b
            if (r7 >= r8) goto L_0x01c8
            float r8 = r0.f1108e
            float r0 = r0.f1107d
            float r8 = r8 + r0
            float r8 = r8 + r2
            r0 = 0
        L_0x018b:
            int r7 = r7 + 1
            int r9 = r4.f1105b
            if (r7 > r9) goto L_0x0203
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r9 = r14.f1081e
            int r9 = r9.size()
            if (r0 >= r9) goto L_0x0203
        L_0x0199:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r9 = r14.f1081e
            java.lang.Object r9 = r9.get(r0)
            androidx.viewpager.widget.ViewPager$e r9 = (androidx.viewpager.widget.ViewPager.C0206e) r9
            int r10 = r9.f1105b
            if (r7 <= r10) goto L_0x01b2
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r10 = r14.f1081e
            int r10 = r10.size()
            int r10 = r10 + -1
            if (r0 >= r10) goto L_0x01b2
            int r0 = r0 + 1
            goto L_0x0199
        L_0x01b2:
            int r10 = r9.f1105b
            if (r7 >= r10) goto L_0x01c1
            id r10 = r14.f1084h
            java.util.Objects.requireNonNull(r10)
            float r10 = r1 + r2
            float r8 = r8 + r10
            int r7 = r7 + 1
            goto L_0x01b2
        L_0x01c1:
            r9.f1108e = r8
            float r9 = r9.f1107d
            float r9 = r9 + r2
            float r8 = r8 + r9
            goto L_0x018b
        L_0x01c8:
            if (r7 <= r8) goto L_0x0203
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r8 = r14.f1081e
            int r8 = r8.size()
            int r8 = r8 + -1
            float r0 = r0.f1108e
        L_0x01d4:
            int r7 = r7 + -1
            int r9 = r4.f1105b
            if (r7 < r9) goto L_0x0203
            if (r8 < 0) goto L_0x0203
        L_0x01dc:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r9 = r14.f1081e
            java.lang.Object r9 = r9.get(r8)
            androidx.viewpager.widget.ViewPager$e r9 = (androidx.viewpager.widget.ViewPager.C0206e) r9
            int r10 = r9.f1105b
            if (r7 >= r10) goto L_0x01ed
            if (r8 <= 0) goto L_0x01ed
            int r8 = r8 + -1
            goto L_0x01dc
        L_0x01ed:
            int r10 = r9.f1105b
            if (r7 <= r10) goto L_0x01fc
            id r10 = r14.f1084h
            java.util.Objects.requireNonNull(r10)
            float r10 = r1 + r2
            float r0 = r0 - r10
            int r7 = r7 + -1
            goto L_0x01ed
        L_0x01fc:
            float r10 = r9.f1107d
            float r10 = r10 + r2
            float r0 = r0 - r10
            r9.f1108e = r0
            goto L_0x01d4
        L_0x0203:
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r0 = r14.f1081e
            int r0 = r0.size()
            float r7 = r4.f1108e
            int r8 = r4.f1105b
            int r9 = r8 + -1
            if (r8 != 0) goto L_0x0213
            r10 = r7
            goto L_0x0216
        L_0x0213:
            r10 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
        L_0x0216:
            r14.f1096t = r10
            int r15 = r15 + -1
            if (r8 != r15) goto L_0x0221
            float r8 = r4.f1107d
            float r8 = r8 + r7
            float r8 = r8 - r1
            goto L_0x0224
        L_0x0221:
            r8 = 2139095039(0x7f7fffff, float:3.4028235E38)
        L_0x0224:
            r14.f1097u = r8
            int r3 = r3 + -1
        L_0x0228:
            if (r3 < 0) goto L_0x0250
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r8 = r14.f1081e
            java.lang.Object r8 = r8.get(r3)
            androidx.viewpager.widget.ViewPager$e r8 = (androidx.viewpager.widget.ViewPager.C0206e) r8
        L_0x0232:
            int r10 = r8.f1105b
            if (r9 <= r10) goto L_0x0241
            id r10 = r14.f1084h
            int r9 = r9 + -1
            java.util.Objects.requireNonNull(r10)
            float r10 = r1 + r2
            float r7 = r7 - r10
            goto L_0x0232
        L_0x0241:
            float r11 = r8.f1107d
            float r11 = r11 + r2
            float r7 = r7 - r11
            r8.f1108e = r7
            if (r10 != 0) goto L_0x024b
            r14.f1096t = r7
        L_0x024b:
            int r3 = r3 + -1
            int r9 = r9 + -1
            goto L_0x0228
        L_0x0250:
            float r3 = r4.f1108e
            float r7 = r4.f1107d
            float r3 = r3 + r7
            float r3 = r3 + r2
            int r7 = r4.f1105b
        L_0x0258:
            int r7 = r7 + 1
            if (r6 >= r0) goto L_0x0284
            java.util.ArrayList<androidx.viewpager.widget.ViewPager$e> r8 = r14.f1081e
            java.lang.Object r8 = r8.get(r6)
            androidx.viewpager.widget.ViewPager$e r8 = (androidx.viewpager.widget.ViewPager.C0206e) r8
        L_0x0264:
            int r9 = r8.f1105b
            if (r7 >= r9) goto L_0x0273
            id r9 = r14.f1084h
            int r7 = r7 + 1
            java.util.Objects.requireNonNull(r9)
            float r9 = r1 + r2
            float r3 = r3 + r9
            goto L_0x0264
        L_0x0273:
            if (r9 != r15) goto L_0x027b
            float r9 = r8.f1107d
            float r9 = r9 + r3
            float r9 = r9 - r1
            r14.f1097u = r9
        L_0x027b:
            r8.f1108e = r3
            float r8 = r8.f1107d
            float r8 = r8 + r2
            float r3 = r3 + r8
            int r6 = r6 + 1
            goto L_0x0258
        L_0x0284:
            id r15 = r14.f1084h
            int r0 = r14.f1085i
            java.lang.Object r1 = r4.f1104a
            r15.mo4033i(r14, r0, r1)
        L_0x028d:
            id r15 = r14.f1084h
            r15.mo4026b(r14)
            int r15 = r14.getChildCount()
            r0 = 0
        L_0x0297:
            if (r0 >= r15) goto L_0x02c0
            android.view.View r1 = r14.getChildAt(r0)
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            androidx.viewpager.widget.ViewPager$f r2 = (androidx.viewpager.widget.ViewPager.C0207f) r2
            r2.f1114f = r0
            boolean r3 = r2.f1109a
            if (r3 != 0) goto L_0x02bd
            float r3 = r2.f1111c
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 != 0) goto L_0x02bd
            androidx.viewpager.widget.ViewPager$e r1 = r14.mo1382h(r1)
            if (r1 == 0) goto L_0x02bd
            float r3 = r1.f1107d
            r2.f1111c = r3
            int r1 = r1.f1105b
            r2.f1113e = r1
        L_0x02bd:
            int r0 = r0 + 1
            goto L_0x0297
        L_0x02c0:
            boolean r15 = r14.hasFocus()
            if (r15 == 0) goto L_0x030d
            android.view.View r15 = r14.findFocus()
            if (r15 == 0) goto L_0x02e2
        L_0x02cc:
            android.view.ViewParent r0 = r15.getParent()
            if (r0 == r14) goto L_0x02dd
            if (r0 == 0) goto L_0x02e2
            boolean r15 = r0 instanceof android.view.View
            if (r15 != 0) goto L_0x02d9
            goto L_0x02e2
        L_0x02d9:
            r15 = r0
            android.view.View r15 = (android.view.View) r15
            goto L_0x02cc
        L_0x02dd:
            androidx.viewpager.widget.ViewPager$e r15 = r14.mo1382h(r15)
            goto L_0x02e3
        L_0x02e2:
            r15 = 0
        L_0x02e3:
            if (r15 == 0) goto L_0x02eb
            int r15 = r15.f1105b
            int r0 = r14.f1085i
            if (r15 == r0) goto L_0x030d
        L_0x02eb:
            r15 = 0
        L_0x02ec:
            int r0 = r14.getChildCount()
            if (r15 >= r0) goto L_0x030d
            android.view.View r0 = r14.getChildAt(r15)
            androidx.viewpager.widget.ViewPager$e r1 = r14.mo1382h(r0)
            if (r1 == 0) goto L_0x030a
            int r1 = r1.f1105b
            int r2 = r14.f1085i
            if (r1 != r2) goto L_0x030a
            r1 = 2
            boolean r0 = r0.requestFocus(r1)
            if (r0 == 0) goto L_0x030a
            goto L_0x030d
        L_0x030a:
            int r15 = r15 + 1
            goto L_0x02ec
        L_0x030d:
            return
        L_0x030e:
            android.content.res.Resources r15 = r14.getResources()     // Catch:{ NotFoundException -> 0x031b }
            int r0 = r14.getId()     // Catch:{ NotFoundException -> 0x031b }
            java.lang.String r15 = r15.getResourceName(r0)     // Catch:{ NotFoundException -> 0x031b }
            goto L_0x0323
        L_0x031b:
            int r15 = r14.getId()
            java.lang.String r15 = java.lang.Integer.toHexString(r15)
        L_0x0323:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: "
            java.lang.StringBuilder r1 = p000.C1012kd.m3195d(r1)
            int r3 = r14.f1080d
            r1.append(r3)
            java.lang.String r3 = ", found: "
            r1.append(r3)
            r1.append(r2)
            java.lang.String r2 = " Pager id: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r15 = " Pager class: "
            r1.append(r15)
            java.lang.Class r15 = r14.getClass()
            r1.append(r15)
            java.lang.String r15 = " Problematic adapter: "
            r1.append(r15)
            id r15 = r14.f1084h
            java.lang.Class r15 = r15.getClass()
            r1.append(r15)
            java.lang.String r15 = r1.toString()
            r0.<init>(r15)
            goto L_0x0363
        L_0x0362:
            throw r0
        L_0x0363:
            goto L_0x0362
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.mo1402q(int):void");
    }

    /* renamed from: r */
    public final void mo1403r(int i, int i2, int i3, int i4) {
        int min;
        if (i2 <= 0 || this.f1081e.isEmpty()) {
            C0206e j = mo1384j(this.f1085i);
            min = (int) ((j != null ? Math.min(j.f1108e, this.f1097u) : 0.0f) * ((float) ((i - getPaddingLeft()) - getPaddingRight())));
            if (min != getScrollX()) {
                mo1366d(false);
            } else {
                return;
            }
        } else if (!this.f1089m.isFinished()) {
            this.f1089m.setFinalX(getCurrentItem() * getClientWidth());
            return;
        } else {
            min = (int) ((((float) getScrollX()) / ((float) (((i2 - getPaddingLeft()) - getPaddingRight()) + i4))) * ((float) (((i - getPaddingLeft()) - getPaddingRight()) + i3)));
        }
        scrollTo(min, getScrollY());
    }

    public void removeView(View view) {
        if (this.f1099w) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    /* renamed from: s */
    public final void mo1405s(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    public void setAdapter(C0885id idVar) {
        C0885id idVar2 = this.f1084h;
        if (idVar2 != null) {
            synchronized (idVar2) {
            }
            this.f1084h.mo4034j(this);
            for (int i = 0; i < this.f1081e.size(); i++) {
                C0206e eVar = this.f1081e.get(i);
                this.f1084h.mo4025a(this, eVar.f1105b, eVar.f1104a);
            }
            this.f1084h.mo4026b(this);
            this.f1081e.clear();
            int i2 = 0;
            while (i2 < getChildCount()) {
                if (!((C0207f) getChildAt(i2).getLayoutParams()).f1109a) {
                    removeViewAt(i2);
                    i2--;
                }
                i2++;
            }
            this.f1085i = 0;
            scrollTo(0, 0);
        }
        this.f1084h = idVar;
        this.f1080d = 0;
        if (idVar != null) {
            if (this.f1091o == null) {
                this.f1091o = new C0210i();
            }
            synchronized (this.f1084h) {
            }
            this.f1101y = false;
            boolean z = this.f1073R;
            this.f1073R = true;
            this.f1080d = this.f1084h.mo4027c();
            if (this.f1086j >= 0) {
                this.f1084h.mo4031g(this.f1087k, this.f1088l);
                mo1416v(this.f1086j, false, true, 0);
                this.f1086j = -1;
                this.f1087k = null;
                this.f1088l = null;
            } else if (!z) {
                mo1402q(this.f1085i);
            } else {
                requestLayout();
            }
        }
    }

    public void setCurrentItem(int i) {
        this.f1101y = false;
        mo1416v(i, !this.f1073R, false, 0);
    }

    public void setOffscreenPageLimit(int i) {
        if (i < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i + " too small; defaulting to " + 1);
            i = 1;
        }
        if (i != this.f1102z) {
            this.f1102z = i;
            mo1402q(this.f1085i);
        }
    }

    @Deprecated
    public void setOnPageChangeListener(C0209h hVar) {
        this.f1077V = hVar;
    }

    public void setPageMargin(int i) {
        int i2 = this.f1092p;
        this.f1092p = i;
        int width = getWidth();
        mo1403r(width, width, i, i2);
        requestLayout();
    }

    public void setPageMarginDrawable(int i) {
        setPageMarginDrawable(C1901v4.m5334c(getContext(), i));
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.f1093q = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setScrollState(int i) {
        if (this.f1079a0 != i) {
            this.f1079a0 = i;
            C0209h hVar = this.f1077V;
            if (hVar != null) {
                hVar.mo125b(i);
            }
            List<C0209h> list = this.f1076U;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    C0209h hVar2 = this.f1076U.get(i2);
                    if (hVar2 != null) {
                        hVar2.mo125b(i);
                    }
                }
            }
        }
    }

    /* renamed from: t */
    public final boolean mo1414t() {
        this.f1065J = -1;
        this.f1056A = false;
        this.f1057B = false;
        VelocityTracker velocityTracker = this.f1066K;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f1066K = null;
        }
        this.f1071P.onRelease();
        this.f1072Q.onRelease();
        if (this.f1071P.isFinished() || this.f1072Q.isFinished()) {
            return true;
        }
        return false;
    }

    /* renamed from: u */
    public final void mo1415u(int i, boolean z, int i2, boolean z2) {
        int i3;
        int i4;
        C0206e j = mo1384j(i);
        int max = j != null ? (int) (Math.max(this.f1096t, Math.min(j.f1108e, this.f1097u)) * ((float) getClientWidth())) : 0;
        if (z) {
            if (getChildCount() == 0) {
                setScrollingCacheEnabled(false);
            } else {
                Scroller scroller = this.f1089m;
                if (scroller != null && !scroller.isFinished()) {
                    i3 = this.f1090n ? this.f1089m.getCurrX() : this.f1089m.getStartX();
                    this.f1089m.abortAnimation();
                    setScrollingCacheEnabled(false);
                } else {
                    i3 = getScrollX();
                }
                int i5 = i3;
                int scrollY = getScrollY();
                int i6 = max - i5;
                int i7 = 0 - scrollY;
                if (i6 == 0 && i7 == 0) {
                    mo1366d(false);
                    mo1402q(this.f1085i);
                    setScrollState(0);
                } else {
                    setScrollingCacheEnabled(true);
                    setScrollState(2);
                    int clientWidth = getClientWidth();
                    int i8 = clientWidth / 2;
                    float f = (float) clientWidth;
                    float f2 = (float) i8;
                    float sin = (((float) Math.sin((double) ((Math.min(1.0f, (((float) Math.abs(i6)) * 1.0f) / f) - 0.5f) * 0.47123894f))) * f2) + f2;
                    int abs = Math.abs(i2);
                    if (abs > 0) {
                        i4 = Math.round(Math.abs(sin / ((float) abs)) * 1000.0f) * 4;
                    } else {
                        Objects.requireNonNull(this.f1084h);
                        i4 = (int) (((((float) Math.abs(i6)) / ((f * 1.0f) + ((float) this.f1092p))) + 1.0f) * 100.0f);
                    }
                    int min = Math.min(i4, 600);
                    this.f1090n = false;
                    this.f1089m.startScroll(i5, scrollY, i6, i7, min);
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    postInvalidateOnAnimation();
                }
            }
            if (z2) {
                mo1372f(i);
                return;
            }
            return;
        }
        if (z2) {
            mo1372f(i);
        }
        mo1366d(false);
        scrollTo(max, 0);
        mo1389o(max);
    }

    /* renamed from: v */
    public void mo1416v(int i, boolean z, boolean z2, int i2) {
        C0885id idVar = this.f1084h;
        boolean z3 = false;
        if (idVar == null || idVar.mo4027c() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (z2 || this.f1085i != i || this.f1081e.size() == 0) {
            if (i < 0) {
                i = 0;
            } else if (i >= this.f1084h.mo4027c()) {
                i = this.f1084h.mo4027c() - 1;
            }
            int i3 = this.f1102z;
            int i4 = this.f1085i;
            if (i > i4 + i3 || i < i4 - i3) {
                for (int i5 = 0; i5 < this.f1081e.size(); i5++) {
                    this.f1081e.get(i5).f1106c = true;
                }
            }
            if (this.f1085i != i) {
                z3 = true;
            }
            if (this.f1073R) {
                this.f1085i = i;
                if (z3) {
                    mo1372f(i);
                }
                requestLayout();
                return;
            }
            mo1402q(i);
            mo1415u(i, z, i2, z3);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1093q;
    }
}
