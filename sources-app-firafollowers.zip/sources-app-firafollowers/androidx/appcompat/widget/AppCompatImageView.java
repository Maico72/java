package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

public class AppCompatImageView extends ImageView implements C2195z6, C1983w7 {

    /* renamed from: d */
    public final C1056l1 f394d;

    /* renamed from: e */
    public final C1709s1 f395e;

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AppCompatImageView(Context context, AttributeSet attributeSet, int i) {
        super(C2182z2.m5945a(context), attributeSet, i);
        C2045x2.m5634a(this, getContext());
        C1056l1 l1Var = new C1056l1(this);
        this.f394d = l1Var;
        l1Var.mo4390d(attributeSet, i);
        C1709s1 s1Var = new C1709s1(this);
        this.f395e = s1Var;
        s1Var.mo5782c(attributeSet, i);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            l1Var.mo4387a();
        }
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5780a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            return l1Var.mo4388b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            return l1Var.mo4389c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        C0006a3 a3Var;
        C1709s1 s1Var = this.f395e;
        if (s1Var == null || (a3Var = s1Var.f5656b) == null) {
            return null;
        }
        return a3Var.f15a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        C0006a3 a3Var;
        C1709s1 s1Var = this.f395e;
        if (s1Var == null || (a3Var = s1Var.f5656b) == null) {
            return null;
        }
        return a3Var.f16b;
    }

    public boolean hasOverlappingRendering() {
        return this.f395e.mo5781b() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            l1Var.mo4391e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            l1Var.mo4392f(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5780a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5780a();
        }
    }

    public void setImageResource(int i) {
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5783d(i);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5780a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            l1Var.mo4394h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C1056l1 l1Var = this.f394d;
        if (l1Var != null) {
            l1Var.mo4395i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5784e(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C1709s1 s1Var = this.f395e;
        if (s1Var != null) {
            s1Var.mo5785f(mode);
        }
    }
}
