package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import p000.C1057l2;

public class FitWindowsFrameLayout extends FrameLayout implements C1057l2 {

    /* renamed from: d */
    public C1057l2.C1058a f406d;

    public FitWindowsFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean fitSystemWindows(Rect rect) {
        C1057l2.C1058a aVar = this.f406d;
        if (aVar != null) {
            rect.top = ((C1645r) aVar).f5365a.mo5127X((C0943j7) null, rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C1057l2.C1058a aVar) {
        this.f406d = aVar;
    }
}
