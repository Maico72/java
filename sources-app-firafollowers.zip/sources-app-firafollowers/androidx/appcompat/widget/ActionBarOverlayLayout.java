package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0003a1;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements C0805h2, C1903v6, C1780t6, C1846u6 {

    /* renamed from: I */
    public static final int[] f336I = {R.attr.actionBarSize, 16842841};

    /* renamed from: A */
    public C0943j7 f337A;

    /* renamed from: B */
    public C0082d f338B;

    /* renamed from: C */
    public OverScroller f339C;

    /* renamed from: D */
    public ViewPropertyAnimator f340D;

    /* renamed from: E */
    public final AnimatorListenerAdapter f341E;

    /* renamed from: F */
    public final Runnable f342F;

    /* renamed from: G */
    public final Runnable f343G;

    /* renamed from: H */
    public final C1982w6 f344H;

    /* renamed from: d */
    public int f345d;

    /* renamed from: e */
    public int f346e = 0;

    /* renamed from: f */
    public ContentFrameLayout f347f;

    /* renamed from: g */
    public ActionBarContainer f348g;

    /* renamed from: h */
    public C0864i2 f349h;

    /* renamed from: i */
    public Drawable f350i;

    /* renamed from: j */
    public boolean f351j;

    /* renamed from: k */
    public boolean f352k;

    /* renamed from: l */
    public boolean f353l;

    /* renamed from: m */
    public boolean f354m;

    /* renamed from: n */
    public boolean f355n;

    /* renamed from: o */
    public int f356o;

    /* renamed from: p */
    public int f357p;

    /* renamed from: q */
    public final Rect f358q = new Rect();

    /* renamed from: r */
    public final Rect f359r = new Rect();

    /* renamed from: s */
    public final Rect f360s = new Rect();

    /* renamed from: t */
    public final Rect f361t = new Rect();

    /* renamed from: u */
    public final Rect f362u = new Rect();

    /* renamed from: v */
    public final Rect f363v = new Rect();

    /* renamed from: w */
    public final Rect f364w = new Rect();

    /* renamed from: x */
    public C0943j7 f365x;

    /* renamed from: y */
    public C0943j7 f366y;

    /* renamed from: z */
    public C0943j7 f367z;

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$a */
    public class C0079a extends AnimatorListenerAdapter {
        public C0079a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f340D = null;
            actionBarOverlayLayout.f355n = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f340D = null;
            actionBarOverlayLayout.f355n = false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$b */
    public class C0080b implements Runnable {
        public C0080b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo285q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f340D = actionBarOverlayLayout.f348g.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f341E);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$c */
    public class C0081c implements Runnable {
        public C0081c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo285q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f340D = actionBarOverlayLayout.f348g.animate().translationY((float) (-ActionBarOverlayLayout.this.f348g.getHeight())).setListener(ActionBarOverlayLayout.this.f341E);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$d */
    public interface C0082d {
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$e */
    public static class C0083e extends ViewGroup.MarginLayoutParams {
        public C0083e(int i, int i2) {
            super(i, i2);
        }

        public C0083e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0083e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0943j7 j7Var = C0943j7.f3370b;
        this.f365x = j7Var;
        this.f366y = j7Var;
        this.f367z = j7Var;
        this.f337A = j7Var;
        this.f341E = new C0079a();
        this.f342F = new C0080b();
        this.f343G = new C0081c();
        mo286r(context);
        this.f344H = new C1982w6();
    }

    /* renamed from: a */
    public void mo246a(Menu menu, C0003a1.C0004a aVar) {
        mo287s();
        this.f349h.mo3232a(menu, aVar);
    }

    /* renamed from: b */
    public boolean mo247b() {
        mo287s();
        return this.f349h.mo3233b();
    }

    /* renamed from: c */
    public boolean mo248c() {
        mo287s();
        return this.f349h.mo3234c();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0083e;
    }

    /* renamed from: d */
    public boolean mo250d() {
        mo287s();
        return this.f349h.mo3236d();
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f350i != null && !this.f351j) {
            if (this.f348g.getVisibility() == 0) {
                i = (int) (this.f348g.getTranslationY() + ((float) this.f348g.getBottom()) + 0.5f);
            } else {
                i = 0;
            }
            this.f350i.setBounds(0, i, getWidth(), this.f350i.getIntrinsicHeight() + i);
            this.f350i.draw(canvas);
        }
    }

    /* renamed from: e */
    public boolean mo252e() {
        mo287s();
        return this.f349h.mo3237e();
    }

    /* renamed from: f */
    public void mo253f() {
        mo287s();
        this.f349h.mo3238f();
    }

    public boolean fitSystemWindows(Rect rect) {
        if (Build.VERSION.SDK_INT >= 21) {
            return super.fitSystemWindows(rect);
        }
        mo287s();
        boolean p = mo284p(this.f348g, rect, true, true, false, true);
        this.f361t.set(rect);
        C0869i3.m2743a(this, this.f361t, this.f358q);
        if (!this.f362u.equals(this.f361t)) {
            this.f362u.set(this.f361t);
            p = true;
        }
        if (!this.f359r.equals(this.f358q)) {
            this.f359r.set(this.f358q);
            p = true;
        }
        if (p) {
            requestLayout();
        }
        return true;
    }

    /* renamed from: g */
    public boolean mo255g() {
        mo287s();
        return this.f349h.mo3239g();
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0083e(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0083e(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0083e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f348g;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        return this.f344H.mo6429a();
    }

    public CharSequence getTitle() {
        mo287s();
        return this.f349h.getTitle();
    }

    /* renamed from: h */
    public void mo262h(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    /* renamed from: i */
    public void mo263i(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    /* renamed from: j */
    public void mo264j(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* renamed from: k */
    public void mo265k(int i) {
        mo287s();
        if (i == 2) {
            this.f349h.mo3251r();
        } else if (i == 5) {
            this.f349h.mo3257t();
        } else if (i == 109) {
            setOverlayMode(true);
        }
    }

    /* renamed from: l */
    public void mo266l() {
        mo287s();
        this.f349h.mo3241h();
    }

    /* renamed from: m */
    public void mo267m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: n */
    public void mo268n(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: o */
    public boolean mo269o(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        mo287s();
        Objects.requireNonNull(windowInsets);
        C0943j7 j7Var = new C0943j7(windowInsets);
        boolean p = mo284p(this.f348g, new Rect(j7Var.mo4126b(), j7Var.mo4128d(), j7Var.mo4127c(), j7Var.mo4125a()), true, true, false, true);
        Rect rect = this.f358q;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (Build.VERSION.SDK_INT >= 21) {
            WindowInsets i = j7Var.mo4134i();
            if (i != null) {
                C0943j7.m2927j(computeSystemWindowInsets(i, rect));
            } else {
                rect.setEmpty();
            }
        }
        Rect rect2 = this.f358q;
        C0943j7 g = j7Var.f3371a.mo4139g(rect2.left, rect2.top, rect2.right, rect2.bottom);
        this.f365x = g;
        boolean z = true;
        if (!this.f366y.equals(g)) {
            this.f366y = this.f365x;
            p = true;
        }
        if (!this.f359r.equals(this.f358q)) {
            this.f359r.set(this.f358q);
        } else {
            z = p;
        }
        if (z) {
            requestLayout();
        }
        return j7Var.f3371a.mo4145a().f3371a.mo4142c().f3371a.mo4141b().mo4134i();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        mo286r(getContext());
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (Build.VERSION.SDK_INT >= 20) {
            requestApplyInsets();
        } else {
            requestFitSystemWindows();
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo285q();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                C0083e eVar = (C0083e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = eVar.leftMargin + paddingLeft;
                int i7 = eVar.topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:39:0x0112  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x011c A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r13, int r14) {
        /*
            r12 = this;
            int r7 = android.os.Build.VERSION.SDK_INT
            r12.mo287s()
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f348g
            r3 = 0
            r5 = 0
            r0 = r12
            r2 = r13
            r4 = r14
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            androidx.appcompat.widget.ActionBarContainer r0 = r12.f348g
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            androidx.appcompat.widget.ActionBarOverlayLayout$e r0 = (androidx.appcompat.widget.ActionBarOverlayLayout.C0083e) r0
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f348g
            int r1 = r1.getMeasuredWidth()
            int r2 = r0.leftMargin
            int r1 = r1 + r2
            int r2 = r0.rightMargin
            int r1 = r1 + r2
            r2 = 0
            int r8 = java.lang.Math.max(r2, r1)
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f348g
            int r1 = r1.getMeasuredHeight()
            int r3 = r0.topMargin
            int r1 = r1 + r3
            int r0 = r0.bottomMargin
            int r1 = r1 + r0
            int r9 = java.lang.Math.max(r2, r1)
            androidx.appcompat.widget.ActionBarContainer r0 = r12.f348g
            int r0 = r0.getMeasuredState()
            int r10 = android.view.View.combineMeasuredStates(r2, r0)
            java.util.WeakHashMap<android.view.View, java.lang.String> r0 = p000.C0010a7.f28a
            int r0 = r12.getWindowSystemUiVisibility()
            r0 = r0 & 256(0x100, float:3.59E-43)
            if (r0 == 0) goto L_0x004e
            r0 = 1
            goto L_0x004f
        L_0x004e:
            r0 = 0
        L_0x004f:
            if (r0 == 0) goto L_0x0063
            int r1 = r12.f345d
            boolean r3 = r12.f353l
            if (r3 == 0) goto L_0x0075
            androidx.appcompat.widget.ActionBarContainer r3 = r12.f348g
            android.view.View r3 = r3.getTabContainer()
            if (r3 == 0) goto L_0x0075
            int r3 = r12.f345d
            int r1 = r1 + r3
            goto L_0x0075
        L_0x0063:
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f348g
            int r1 = r1.getVisibility()
            r3 = 8
            if (r1 == r3) goto L_0x0074
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f348g
            int r1 = r1.getMeasuredHeight()
            goto L_0x0075
        L_0x0074:
            r1 = 0
        L_0x0075:
            android.graphics.Rect r3 = r12.f360s
            android.graphics.Rect r4 = r12.f358q
            r3.set(r4)
            r11 = 21
            if (r7 < r11) goto L_0x0085
            j7 r3 = r12.f365x
            r12.f367z = r3
            goto L_0x008c
        L_0x0085:
            android.graphics.Rect r3 = r12.f363v
            android.graphics.Rect r4 = r12.f361t
            r3.set(r4)
        L_0x008c:
            boolean r3 = r12.f352k
            if (r3 != 0) goto L_0x00a9
            if (r0 != 0) goto L_0x00a9
            android.graphics.Rect r0 = r12.f360s
            int r3 = r0.top
            int r3 = r3 + r1
            r0.top = r3
            int r3 = r0.bottom
            int r3 = r3 + r2
            r0.bottom = r3
            if (r7 < r11) goto L_0x00fa
            j7 r0 = r12.f367z
            j7$h r0 = r0.f3371a
            j7 r0 = r0.mo4139g(r2, r1, r2, r2)
            goto L_0x00eb
        L_0x00a9:
            if (r7 < r11) goto L_0x00ee
            j7 r0 = r12.f367z
            int r0 = r0.mo4126b()
            j7 r3 = r12.f367z
            int r3 = r3.mo4128d()
            int r3 = r3 + r1
            j7 r1 = r12.f367z
            int r1 = r1.mo4127c()
            j7 r4 = r12.f367z
            int r4 = r4.mo4125a()
            int r4 = r4 + r2
            f5 r0 = p000.C0672f5.m2163a(r0, r3, r1, r4)
            j7 r1 = r12.f367z
            r2 = 29
            if (r7 < r2) goto L_0x00d5
            j7$b r2 = new j7$b
            r2.<init>(r1)
            goto L_0x00e4
        L_0x00d5:
            r2 = 20
            if (r7 < r2) goto L_0x00df
            j7$a r2 = new j7$a
            r2.<init>(r1)
            goto L_0x00e4
        L_0x00df:
            j7$c r2 = new j7$c
            r2.<init>(r1)
        L_0x00e4:
            r2.mo4136c(r0)
            j7 r0 = r2.mo4135a()
        L_0x00eb:
            r12.f367z = r0
            goto L_0x00fa
        L_0x00ee:
            android.graphics.Rect r0 = r12.f363v
            int r3 = r0.top
            int r3 = r3 + r1
            r0.top = r3
            int r1 = r0.bottom
            int r1 = r1 + r2
            r0.bottom = r1
        L_0x00fa:
            androidx.appcompat.widget.ContentFrameLayout r1 = r12.f347f
            android.graphics.Rect r2 = r12.f360s
            r3 = 1
            r4 = 1
            r5 = 1
            r6 = 1
            r0 = r12
            r0.mo284p(r1, r2, r3, r4, r5, r6)
            if (r7 < r11) goto L_0x011c
            j7 r0 = r12.f337A
            j7 r1 = r12.f367z
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x011c
            j7 r0 = r12.f367z
            r12.f337A = r0
            androidx.appcompat.widget.ContentFrameLayout r1 = r12.f347f
            p000.C0010a7.m31d(r1, r0)
            goto L_0x0136
        L_0x011c:
            if (r7 >= r11) goto L_0x0136
            android.graphics.Rect r0 = r12.f364w
            android.graphics.Rect r1 = r12.f363v
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0136
            android.graphics.Rect r0 = r12.f364w
            android.graphics.Rect r1 = r12.f363v
            r0.set(r1)
            androidx.appcompat.widget.ContentFrameLayout r0 = r12.f347f
            android.graphics.Rect r1 = r12.f363v
            r0.mo363a(r1)
        L_0x0136:
            androidx.appcompat.widget.ContentFrameLayout r1 = r12.f347f
            r3 = 0
            r5 = 0
            r0 = r12
            r2 = r13
            r4 = r14
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            androidx.appcompat.widget.ContentFrameLayout r0 = r12.f347f
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            androidx.appcompat.widget.ActionBarOverlayLayout$e r0 = (androidx.appcompat.widget.ActionBarOverlayLayout.C0083e) r0
            androidx.appcompat.widget.ContentFrameLayout r1 = r12.f347f
            int r1 = r1.getMeasuredWidth()
            int r2 = r0.leftMargin
            int r1 = r1 + r2
            int r2 = r0.rightMargin
            int r1 = r1 + r2
            int r1 = java.lang.Math.max(r8, r1)
            androidx.appcompat.widget.ContentFrameLayout r2 = r12.f347f
            int r2 = r2.getMeasuredHeight()
            int r3 = r0.topMargin
            int r2 = r2 + r3
            int r0 = r0.bottomMargin
            int r2 = r2 + r0
            int r0 = java.lang.Math.max(r9, r2)
            androidx.appcompat.widget.ContentFrameLayout r2 = r12.f347f
            int r2 = r2.getMeasuredState()
            int r2 = android.view.View.combineMeasuredStates(r10, r2)
            int r3 = r12.getPaddingLeft()
            int r4 = r12.getPaddingRight()
            int r4 = r4 + r3
            int r4 = r4 + r1
            int r1 = r12.getPaddingTop()
            int r3 = r12.getPaddingBottom()
            int r3 = r3 + r1
            int r3 = r3 + r0
            int r0 = r12.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r3, r0)
            int r1 = r12.getSuggestedMinimumWidth()
            int r1 = java.lang.Math.max(r4, r1)
            int r1 = android.view.View.resolveSizeAndState(r1, r13, r2)
            int r2 = r2 << 16
            int r0 = android.view.View.resolveSizeAndState(r0, r14, r2)
            r12.setMeasuredDimension(r1, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        boolean z2 = false;
        if (!this.f354m || !z) {
            return false;
        }
        this.f339C.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f339C.getFinalY() > this.f348g.getHeight()) {
            z2 = true;
        }
        if (z2) {
            mo285q();
            this.f343G.run();
        } else {
            mo285q();
            this.f342F.run();
        }
        this.f355n = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.f356o + i2;
        this.f356o = i5;
        setActionBarHideOffset(i5);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r1 = (p000.C2173z) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onNestedScrollAccepted(android.view.View r1, android.view.View r2, int r3) {
        /*
            r0 = this;
            w6 r1 = r0.f344H
            r1.f6579a = r3
            int r1 = r0.getActionBarHideOffset()
            r0.f356o = r1
            r0.mo285q()
            androidx.appcompat.widget.ActionBarOverlayLayout$d r1 = r0.f338B
            if (r1 == 0) goto L_0x001d
            z r1 = (p000.C2173z) r1
            m0 r2 = r1.f7009t
            if (r2 == 0) goto L_0x001d
            r2.mo4503a()
            r2 = 0
            r1.f7009t = r2
        L_0x001d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f348g.getVisibility() != 0) {
            return false;
        }
        return this.f354m;
    }

    public void onStopNestedScroll(View view) {
        if (this.f354m && !this.f355n) {
            if (this.f356o <= this.f348g.getHeight()) {
                mo285q();
                postDelayed(this.f342F, 600);
            } else {
                mo285q();
                postDelayed(this.f343G, 600);
            }
        }
        C0082d dVar = this.f338B;
        if (dVar != null) {
            Objects.requireNonNull((C2173z) dVar);
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        int i2 = Build.VERSION.SDK_INT;
        super.onWindowSystemUiVisibilityChanged(i);
        mo287s();
        int i3 = this.f357p ^ i;
        this.f357p = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & 256) != 0;
        C0082d dVar = this.f338B;
        if (dVar != null) {
            ((C2173z) dVar).f7005p = !z2;
            if (z || !z2) {
                C2173z zVar = (C2173z) dVar;
                if (zVar.f7006q) {
                    zVar.f7006q = false;
                    zVar.mo6721g(true);
                }
            } else {
                C2173z zVar2 = (C2173z) dVar;
                if (!zVar2.f7006q) {
                    zVar2.f7006q = true;
                    zVar2.mo6721g(true);
                }
            }
        }
        if ((i3 & 256) != 0 && this.f338B != null) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            if (i2 >= 20) {
                requestApplyInsets();
            } else {
                requestFitSystemWindows();
            }
        }
    }

    public void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f346e = i;
        C0082d dVar = this.f338B;
        if (dVar != null) {
            ((C2173z) dVar).f7004o = i;
        }
    }

    /* renamed from: p */
    public final boolean mo284p(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        int i;
        int i2;
        int i3;
        int i4;
        C0083e eVar = (C0083e) view.getLayoutParams();
        if (!z || eVar.leftMargin == (i4 = rect.left)) {
            z5 = false;
        } else {
            eVar.leftMargin = i4;
            z5 = true;
        }
        if (z2 && eVar.topMargin != (i3 = rect.top)) {
            eVar.topMargin = i3;
            z5 = true;
        }
        if (z4 && eVar.rightMargin != (i2 = rect.right)) {
            eVar.rightMargin = i2;
            z5 = true;
        }
        if (!z3 || eVar.bottomMargin == (i = rect.bottom)) {
            return z5;
        }
        eVar.bottomMargin = i;
        return true;
    }

    /* renamed from: q */
    public void mo285q() {
        removeCallbacks(this.f342F);
        removeCallbacks(this.f343G);
        ViewPropertyAnimator viewPropertyAnimator = this.f340D;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    /* renamed from: r */
    public final void mo286r(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f336I);
        boolean z = false;
        this.f345d = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f350i = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z = true;
        }
        this.f351j = z;
        this.f339C = new OverScroller(context);
    }

    /* renamed from: s */
    public void mo287s() {
        C0864i2 i2Var;
        if (this.f347f == null) {
            this.f347f = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f348g = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof C0864i2) {
                i2Var = (C0864i2) findViewById;
            } else if (findViewById instanceof Toolbar) {
                i2Var = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder d = C1012kd.m3195d("Can't make a decor toolbar out of ");
                d.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(d.toString());
            }
            this.f349h = i2Var;
        }
    }

    public void setActionBarHideOffset(int i) {
        mo285q();
        this.f348g.setTranslationY((float) (-Math.max(0, Math.min(i, this.f348g.getHeight()))));
    }

    public void setActionBarVisibilityCallback(C0082d dVar) {
        this.f338B = dVar;
        if (getWindowToken() != null) {
            ((C2173z) this.f338B).f7004o = this.f346e;
            int i = this.f357p;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (Build.VERSION.SDK_INT >= 20) {
                    requestApplyInsets();
                } else {
                    requestFitSystemWindows();
                }
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.f353l = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.f354m) {
            this.f354m = z;
            if (!z) {
                mo285q();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i) {
        mo287s();
        this.f349h.setIcon(i);
    }

    public void setIcon(Drawable drawable) {
        mo287s();
        this.f349h.setIcon(drawable);
    }

    public void setLogo(int i) {
        mo287s();
        this.f349h.mo3244k(i);
    }

    public void setOverlayMode(boolean z) {
        this.f352k = z;
        this.f351j = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    public void setWindowCallback(Window.Callback callback) {
        mo287s();
        this.f349h.setWindowCallback(callback);
    }

    public void setWindowTitle(CharSequence charSequence) {
        mo287s();
        this.f349h.setWindowTitle(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
