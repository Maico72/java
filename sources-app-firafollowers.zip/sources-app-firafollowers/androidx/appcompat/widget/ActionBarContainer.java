package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

public class ActionBarContainer extends FrameLayout {

    /* renamed from: d */
    public boolean f314d;

    /* renamed from: e */
    public View f315e;

    /* renamed from: f */
    public View f316f;

    /* renamed from: g */
    public View f317g;

    /* renamed from: h */
    public Drawable f318h;

    /* renamed from: i */
    public Drawable f319i;

    /* renamed from: j */
    public Drawable f320j;

    /* renamed from: k */
    public boolean f321k;

    /* renamed from: l */
    public boolean f322l;

    /* renamed from: m */
    public int f323m;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0863i1 i1Var = new C0863i1(this);
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        setBackground(i1Var);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0593e.f2371a);
        boolean z = false;
        this.f318h = obtainStyledAttributes.getDrawable(0);
        this.f319i = obtainStyledAttributes.getDrawable(2);
        this.f323m = obtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f321k = true;
            this.f320j = obtainStyledAttributes.getDrawable(1);
        }
        obtainStyledAttributes.recycle();
        if (!this.f321k ? this.f318h == null && this.f319i == null : this.f320j == null) {
            z = true;
        }
        setWillNotDraw(z);
    }

    /* renamed from: a */
    public final int mo205a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    /* renamed from: b */
    public final boolean mo206b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f318h;
        if (drawable != null && drawable.isStateful()) {
            this.f318h.setState(getDrawableState());
        }
        Drawable drawable2 = this.f319i;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f319i.setState(getDrawableState());
        }
        Drawable drawable3 = this.f320j;
        if (drawable3 != null && drawable3.isStateful()) {
            this.f320j.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return this.f315e;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f318h;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f319i;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f320j;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f316f = findViewById(R.id.action_bar);
        this.f317g = findViewById(R.id.action_context_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f314d || super.onInterceptTouchEvent(motionEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Drawable drawable;
        Drawable drawable2;
        int left;
        int top;
        int right;
        View view;
        super.onLayout(z, i, i2, i3, i4);
        View view2 = this.f315e;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = (view2 == null || view2.getVisibility() == 8) ? false : true;
        if (!(view2 == null || view2.getVisibility() == 8)) {
            int measuredHeight = getMeasuredHeight();
            int i5 = ((FrameLayout.LayoutParams) view2.getLayoutParams()).bottomMargin;
            view2.layout(i, (measuredHeight - view2.getMeasuredHeight()) - i5, i3, measuredHeight - i5);
        }
        if (this.f321k) {
            Drawable drawable3 = this.f320j;
            if (drawable3 != null) {
                drawable3.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.f318h != null) {
                if (this.f316f.getVisibility() == 0) {
                    drawable2 = this.f318h;
                    left = this.f316f.getLeft();
                    top = this.f316f.getTop();
                    right = this.f316f.getRight();
                    view = this.f316f;
                } else {
                    View view3 = this.f317g;
                    if (view3 == null || view3.getVisibility() != 0) {
                        this.f318h.setBounds(0, 0, 0, 0);
                        z3 = true;
                    } else {
                        drawable2 = this.f318h;
                        left = this.f317g.getLeft();
                        top = this.f317g.getTop();
                        right = this.f317g.getRight();
                        view = this.f317g;
                    }
                }
                drawable2.setBounds(left, top, right, view.getBottom());
                z3 = true;
            }
            this.f322l = z4;
            if (!z4 || (drawable = this.f319i) == null) {
                z2 = z3;
            } else {
                drawable.setBounds(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            }
        }
        if (z2) {
            invalidate();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0055  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            android.view.View r0 = r3.f316f
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 != 0) goto L_0x001c
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            if (r0 != r1) goto L_0x001c
            int r0 = r3.f323m
            if (r0 < 0) goto L_0x001c
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            int r5 = java.lang.Math.min(r0, r5)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r1)
        L_0x001c:
            super.onMeasure(r4, r5)
            android.view.View r4 = r3.f316f
            if (r4 != 0) goto L_0x0024
            return
        L_0x0024:
            int r4 = android.view.View.MeasureSpec.getMode(r5)
            android.view.View r0 = r3.f315e
            if (r0 == 0) goto L_0x006f
            int r0 = r0.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x006f
            r0 = 1073741824(0x40000000, float:2.0)
            if (r4 == r0) goto L_0x006f
            android.view.View r0 = r3.f316f
            boolean r0 = r3.mo206b(r0)
            if (r0 != 0) goto L_0x0047
            android.view.View r0 = r3.f316f
        L_0x0042:
            int r0 = r3.mo205a(r0)
            goto L_0x0053
        L_0x0047:
            android.view.View r0 = r3.f317g
            boolean r0 = r3.mo206b(r0)
            if (r0 != 0) goto L_0x0052
            android.view.View r0 = r3.f317g
            goto L_0x0042
        L_0x0052:
            r0 = 0
        L_0x0053:
            if (r4 != r1) goto L_0x005a
            int r4 = android.view.View.MeasureSpec.getSize(r5)
            goto L_0x005d
        L_0x005a:
            r4 = 2147483647(0x7fffffff, float:NaN)
        L_0x005d:
            int r5 = r3.getMeasuredWidth()
            android.view.View r1 = r3.f315e
            int r1 = r3.mo205a(r1)
            int r1 = r1 + r0
            int r4 = java.lang.Math.min(r1, r4)
            r3.setMeasuredDimension(r5, r4)
        L_0x006f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContainer.onMeasure(int, int):void");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f318h;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f318h);
        }
        this.f318h = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f316f;
            if (view != null) {
                this.f318h.setBounds(view.getLeft(), this.f316f.getTop(), this.f316f.getRight(), this.f316f.getBottom());
            }
        }
        boolean z = true;
        if (!this.f321k ? !(this.f318h == null && this.f319i == null) : this.f320j != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f320j;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f320j);
        }
        this.f320j = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f321k && (drawable2 = this.f320j) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f321k ? this.f318h == null && this.f319i == null : this.f320j == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f319i;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f319i);
        }
        this.f319i = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f322l && (drawable2 = this.f319i) != null) {
                drawable2.setBounds(this.f315e.getLeft(), this.f315e.getTop(), this.f315e.getRight(), this.f315e.getBottom());
            }
        }
        boolean z = true;
        if (!this.f321k ? !(this.f318h == null && this.f319i == null) : this.f320j != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setTabContainer(C1898v2 v2Var) {
        View view = this.f315e;
        if (view != null) {
            removeView(view);
        }
        this.f315e = v2Var;
        if (v2Var != null) {
            addView(v2Var);
            ViewGroup.LayoutParams layoutParams = v2Var.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            v2Var.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.f314d = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f318h;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.f319i;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.f320j;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f318h && !this.f321k) || (drawable == this.f319i && this.f322l) || ((drawable == this.f320j && this.f321k) || super.verifyDrawable(drawable));
    }
}
