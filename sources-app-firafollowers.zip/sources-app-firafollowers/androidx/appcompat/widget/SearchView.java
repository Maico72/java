package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

public class SearchView extends C1216n2 implements C0802h0 {

    /* renamed from: t0 */
    public static final C0104n f408t0 = (Build.VERSION.SDK_INT < 29 ? new C0104n() : null);

    /* renamed from: A */
    public final View f409A;

    /* renamed from: B */
    public C0107p f410B;

    /* renamed from: C */
    public Rect f411C;

    /* renamed from: D */
    public Rect f412D;

    /* renamed from: E */
    public int[] f413E;

    /* renamed from: F */
    public int[] f414F;

    /* renamed from: G */
    public final ImageView f415G;

    /* renamed from: H */
    public final Drawable f416H;

    /* renamed from: I */
    public final int f417I;

    /* renamed from: J */
    public final int f418J;

    /* renamed from: K */
    public final Intent f419K;

    /* renamed from: L */
    public final Intent f420L;

    /* renamed from: M */
    public final CharSequence f421M;

    /* renamed from: N */
    public C0102l f422N;

    /* renamed from: O */
    public C0101k f423O;

    /* renamed from: P */
    public View.OnFocusChangeListener f424P;

    /* renamed from: Q */
    public C0103m f425Q;

    /* renamed from: R */
    public View.OnClickListener f426R;

    /* renamed from: S */
    public boolean f427S;

    /* renamed from: T */
    public boolean f428T;

    /* renamed from: U */
    public C2053x7 f429U;

    /* renamed from: V */
    public boolean f430V;

    /* renamed from: W */
    public CharSequence f431W;

    /* renamed from: a0 */
    public boolean f432a0;

    /* renamed from: b0 */
    public boolean f433b0;

    /* renamed from: c0 */
    public int f434c0;

    /* renamed from: d0 */
    public boolean f435d0;

    /* renamed from: e0 */
    public CharSequence f436e0;

    /* renamed from: f0 */
    public CharSequence f437f0;

    /* renamed from: g0 */
    public boolean f438g0;

    /* renamed from: h0 */
    public int f439h0;

    /* renamed from: i0 */
    public SearchableInfo f440i0;

    /* renamed from: j0 */
    public Bundle f441j0;

    /* renamed from: k0 */
    public final Runnable f442k0;

    /* renamed from: l0 */
    public Runnable f443l0;

    /* renamed from: m0 */
    public final WeakHashMap<String, Drawable.ConstantState> f444m0;

    /* renamed from: n0 */
    public final View.OnClickListener f445n0;

    /* renamed from: o0 */
    public View.OnKeyListener f446o0;

    /* renamed from: p0 */
    public final TextView.OnEditorActionListener f447p0;

    /* renamed from: q0 */
    public final AdapterView.OnItemClickListener f448q0;

    /* renamed from: r0 */
    public final AdapterView.OnItemSelectedListener f449r0;

    /* renamed from: s */
    public final SearchAutoComplete f450s;

    /* renamed from: s0 */
    public TextWatcher f451s0;

    /* renamed from: t */
    public final View f452t;

    /* renamed from: u */
    public final View f453u;

    /* renamed from: v */
    public final View f454v;

    /* renamed from: w */
    public final ImageView f455w;

    /* renamed from: x */
    public final ImageView f456x;

    /* renamed from: y */
    public final ImageView f457y;

    /* renamed from: z */
    public final ImageView f458z;

    public static class SearchAutoComplete extends C0991k1 {

        /* renamed from: g */
        public int f459g = getThreshold();

        /* renamed from: h */
        public SearchView f460h;

        /* renamed from: i */
        public boolean f461i;

        /* renamed from: j */
        public final Runnable f462j = new C0090a();

        /* renamed from: androidx.appcompat.widget.SearchView$SearchAutoComplete$a */
        public class C0090a implements Runnable {
            public C0090a() {
            }

            public void run() {
                SearchAutoComplete searchAutoComplete = SearchAutoComplete.this;
                if (searchAutoComplete.f461i) {
                    ((InputMethodManager) searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchAutoComplete, 0);
                    searchAutoComplete.f461i = false;
                }
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        /* renamed from: a */
        public void mo427a() {
            if (Build.VERSION.SDK_INT >= 29) {
                setInputMethodMode(1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            C0104n nVar = SearchView.f408t0;
            Objects.requireNonNull(nVar);
            C0104n.m228a();
            Method method = nVar.f476c;
            if (method != null) {
                try {
                    method.invoke(this, new Object[]{Boolean.TRUE});
                } catch (Exception unused) {
                }
            }
        }

        public boolean enoughToFilter() {
            return this.f459g <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f461i) {
                removeCallbacks(this.f462j);
                post(this.f462j);
            }
            return onCreateInputConnection;
        }

        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            SearchView searchView = this.f460h;
            searchView.mo383G(searchView.f428T);
            searchView.post(searchView.f442k0);
            if (searchView.f450s.hasFocus()) {
                searchView.mo403s();
            }
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f460h.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f460h.hasFocus() && getVisibility() == 0) {
                boolean z2 = true;
                this.f461i = true;
                Context context = getContext();
                C0104n nVar = SearchView.f408t0;
                if (context.getResources().getConfiguration().orientation != 2) {
                    z2 = false;
                }
                if (z2) {
                    mo427a();
                }
            }
        }

        public void performCompletion() {
        }

        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f461i = false;
                removeCallbacks(this.f462j);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f461i = false;
                removeCallbacks(this.f462j);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f461i = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f460h = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f459g = i;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$a */
    public class C0091a implements TextWatcher {
        public C0091a() {
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchView searchView = SearchView.this;
            Editable text = searchView.f450s.getText();
            searchView.f437f0 = text;
            boolean z = !TextUtils.isEmpty(text);
            searchView.mo382F(z);
            searchView.mo384H(!z);
            searchView.mo378B();
            searchView.mo381E();
            if (searchView.f422N != null && !TextUtils.equals(charSequence, searchView.f436e0)) {
                searchView.f422N.mo454a(charSequence.toString());
            }
            searchView.f436e0 = charSequence.toString();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$b */
    public class C0092b implements Runnable {
        public C0092b() {
        }

        public void run() {
            SearchView.this.mo379C();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$c */
    public class C0093c implements Runnable {
        public C0093c() {
        }

        public void run() {
            C2053x7 x7Var = SearchView.this.f429U;
            if (x7Var instanceof C1970w2) {
                x7Var.mo6377b((Cursor) null);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$d */
    public class C0094d implements View.OnFocusChangeListener {
        public C0094d() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.f424P;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$e */
    public class C0095e implements View.OnLayoutChangeListener {
        public C0095e() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            SearchView searchView = SearchView.this;
            if (searchView.f409A.getWidth() > 1) {
                Resources resources = searchView.getContext().getResources();
                int paddingLeft = searchView.f453u.getPaddingLeft();
                Rect rect = new Rect();
                boolean b = C0869i3.m2744b(searchView);
                int dimensionPixelSize = searchView.f427S ? resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_icon_width) : 0;
                searchView.f450s.getDropDownBackground().getPadding(rect);
                searchView.f450s.setDropDownHorizontalOffset(b ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
                searchView.f450s.setDropDownWidth((((searchView.f409A.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$f */
    public class C0096f implements View.OnClickListener {
        public C0096f() {
        }

        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f455w) {
                searchView.mo425y();
            } else if (view == searchView.f457y) {
                searchView.mo421u();
            } else if (view == searchView.f456x) {
                searchView.mo426z();
            } else if (view == searchView.f458z) {
                SearchableInfo searchableInfo = searchView.f440i0;
                if (searchableInfo != null) {
                    try {
                        if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                            Intent intent = new Intent(searchView.f419K);
                            ComponentName searchActivity = searchableInfo.getSearchActivity();
                            intent.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
                            searchView.getContext().startActivity(intent);
                        } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                            searchView.getContext().startActivity(searchView.mo401r(searchView.f420L, searchableInfo));
                        }
                    } catch (ActivityNotFoundException unused) {
                        Log.w("SearchView", "Could not find voice search activity");
                    }
                }
            } else if (view == searchView.f450s) {
                searchView.mo403s();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$g */
    public class C0097g implements View.OnKeyListener {
        public C0097g() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.f440i0 == null) {
                return false;
            }
            if (searchView.f450s.isPopupShowing() && SearchView.this.f450s.getListSelection() != -1) {
                return SearchView.this.mo377A(i, keyEvent);
            }
            if ((TextUtils.getTrimmedLength(SearchView.this.f450s.getText()) == 0) || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.mo420t(0, (String) null, searchView2.f450s.getText().toString());
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$h */
    public class C0098h implements TextView.OnEditorActionListener {
        public C0098h() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            SearchView.this.mo426z();
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$i */
    public class C0099i implements AdapterView.OnItemClickListener {
        public C0099i() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo422v(i);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$j */
    public class C0100j implements AdapterView.OnItemSelectedListener {
        public C0100j() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo423w(i);
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$k */
    public interface C0101k {
        /* renamed from: a */
        boolean mo453a();
    }

    /* renamed from: androidx.appcompat.widget.SearchView$l */
    public interface C0102l {
        /* renamed from: a */
        boolean mo454a(String str);

        /* renamed from: b */
        boolean mo455b(String str);
    }

    /* renamed from: androidx.appcompat.widget.SearchView$m */
    public interface C0103m {
        /* renamed from: a */
        boolean mo456a(int i);

        /* renamed from: b */
        boolean mo457b(int i);
    }

    /* renamed from: androidx.appcompat.widget.SearchView$n */
    public static class C0104n {

        /* renamed from: a */
        public Method f474a = null;

        /* renamed from: b */
        public Method f475b = null;

        /* renamed from: c */
        public Method f476c = null;

        @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
        public C0104n() {
            m228a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f474a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f475b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            try {
                Method method = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f476c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        /* renamed from: a */
        public static void m228a() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$o */
    public static class C0105o extends C0015a8 {
        public static final Parcelable.Creator<C0105o> CREATOR = new C0106a();

        /* renamed from: f */
        public boolean f477f;

        /* renamed from: androidx.appcompat.widget.SearchView$o$a */
        public class C0106a implements Parcelable.ClassLoaderCreator<C0105o> {
            public Object createFromParcel(Parcel parcel) {
                return new C0105o(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0105o[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0105o(parcel, classLoader);
            }
        }

        public C0105o(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f477f = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        public C0105o(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("SearchView.SavedState{");
            d.append(Integer.toHexString(System.identityHashCode(this)));
            d.append(" isIconified=");
            d.append(this.f477f);
            d.append("}");
            return d.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeValue(Boolean.valueOf(this.f477f));
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$p */
    public static class C0107p extends TouchDelegate {

        /* renamed from: a */
        public final View f478a;

        /* renamed from: b */
        public final Rect f479b = new Rect();

        /* renamed from: c */
        public final Rect f480c = new Rect();

        /* renamed from: d */
        public final Rect f481d = new Rect();

        /* renamed from: e */
        public final int f482e;

        /* renamed from: f */
        public boolean f483f;

        public C0107p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f482e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            mo462a(rect, rect2);
            this.f478a = view;
        }

        /* renamed from: a */
        public void mo462a(Rect rect, Rect rect2) {
            this.f479b.set(rect);
            this.f481d.set(rect);
            Rect rect3 = this.f481d;
            int i = this.f482e;
            rect3.inset(-i, -i);
            this.f480c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:19:0x0041  */
        /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r8) {
            /*
                r7 = this;
                float r0 = r8.getX()
                int r0 = (int) r0
                float r1 = r8.getY()
                int r1 = (int) r1
                int r2 = r8.getAction()
                r3 = 2
                r4 = 1
                r5 = 0
                if (r2 == 0) goto L_0x0032
                if (r2 == r4) goto L_0x0020
                if (r2 == r3) goto L_0x0020
                r6 = 3
                if (r2 == r6) goto L_0x001b
                goto L_0x003d
            L_0x001b:
                boolean r2 = r7.f483f
                r7.f483f = r5
                goto L_0x002f
            L_0x0020:
                boolean r2 = r7.f483f
                if (r2 == 0) goto L_0x002f
                android.graphics.Rect r6 = r7.f481d
                boolean r6 = r6.contains(r0, r1)
                if (r6 != 0) goto L_0x002f
                r4 = r2
                r2 = 0
                goto L_0x003f
            L_0x002f:
                r4 = r2
            L_0x0030:
                r2 = 1
                goto L_0x003f
            L_0x0032:
                android.graphics.Rect r2 = r7.f479b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x003d
                r7.f483f = r4
                goto L_0x0030
            L_0x003d:
                r2 = 1
                r4 = 0
            L_0x003f:
                if (r4 == 0) goto L_0x006e
                if (r2 == 0) goto L_0x005b
                android.graphics.Rect r2 = r7.f480c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x005b
                android.view.View r0 = r7.f478a
                int r0 = r0.getWidth()
                int r0 = r0 / r3
                float r0 = (float) r0
                android.view.View r1 = r7.f478a
                int r1 = r1.getHeight()
                int r1 = r1 / r3
                goto L_0x0064
            L_0x005b:
                android.graphics.Rect r2 = r7.f480c
                int r3 = r2.left
                int r0 = r0 - r3
                float r0 = (float) r0
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x0064:
                float r1 = (float) r1
                r8.setLocation(r0, r1)
                android.view.View r0 = r7.f478a
                boolean r5 = r0.dispatchTouchEvent(r8)
            L_0x006e:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.C0107p.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Context context2 = context;
        this.f411C = new Rect();
        this.f412D = new Rect();
        this.f413E = new int[2];
        this.f414F = new int[2];
        this.f442k0 = new C0092b();
        this.f443l0 = new C0093c();
        this.f444m0 = new WeakHashMap<>();
        C0096f fVar = new C0096f();
        this.f445n0 = fVar;
        this.f446o0 = new C0097g();
        C0098h hVar = new C0098h();
        this.f447p0 = hVar;
        C0099i iVar = new C0099i();
        this.f448q0 = iVar;
        C0100j jVar = new C0100j();
        this.f449r0 = jVar;
        this.f451s0 = new C0091a();
        C0327c3 c3Var = new C0327c3(context2, context2.obtainStyledAttributes(attributeSet, C0593e.f2391u, i, 0));
        LayoutInflater.from(context).inflate(c3Var.mo1836m(9, R.layout.abc_search_view), this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f450s = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f452t = findViewById(R.id.search_edit_frame);
        View findViewById = findViewById(R.id.search_plate);
        this.f453u = findViewById;
        View findViewById2 = findViewById(R.id.submit_area);
        this.f454v = findViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f455w = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f456x = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f457y = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f458z = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.f415G = imageView5;
        Drawable g = c3Var.mo1830g(10);
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        findViewById.setBackground(g);
        findViewById2.setBackground(c3Var.mo1830g(14));
        imageView.setImageDrawable(c3Var.mo1830g(13));
        imageView2.setImageDrawable(c3Var.mo1830g(7));
        imageView3.setImageDrawable(c3Var.mo1830g(4));
        imageView4.setImageDrawable(c3Var.mo1830g(16));
        imageView5.setImageDrawable(c3Var.mo1830g(13));
        this.f416H = c3Var.mo1830g(12);
        C0520d.m1654c(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.f417I = c3Var.mo1836m(15, R.layout.abc_search_dropdown_item_icons_2line);
        this.f418J = c3Var.mo1836m(5, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(this.f451s0);
        searchAutoComplete.setOnEditorActionListener(hVar);
        searchAutoComplete.setOnItemClickListener(iVar);
        searchAutoComplete.setOnItemSelectedListener(jVar);
        searchAutoComplete.setOnKeyListener(this.f446o0);
        searchAutoComplete.setOnFocusChangeListener(new C0094d());
        setIconifiedByDefault(c3Var.mo1824a(8, true));
        int f = c3Var.mo1829f(1, -1);
        if (f != -1) {
            setMaxWidth(f);
        }
        this.f421M = c3Var.mo1838o(6);
        this.f431W = c3Var.mo1838o(11);
        int k = c3Var.mo1834k(3, -1);
        if (k != -1) {
            setImeOptions(k);
        }
        int k2 = c3Var.mo1834k(2, -1);
        if (k2 != -1) {
            setInputType(k2);
        }
        setFocusable(c3Var.mo1824a(0, true));
        c3Var.f1430b.recycle();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f419K = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f420L = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f409A = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new C0095e());
        }
        mo383G(this.f427S);
        mo380D();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        this.f450s.setText(charSequence);
        this.f450s.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    /* renamed from: A */
    public boolean mo377A(int i, KeyEvent keyEvent) {
        if (this.f440i0 != null && this.f429U != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i == 66 || i == 84 || i == 61) {
                return mo422v(this.f450s.getListSelection());
            }
            if (i == 21 || i == 22) {
                this.f450s.setSelection(i == 21 ? 0 : this.f450s.length());
                this.f450s.setListSelection(0);
                this.f450s.clearListSelection();
                this.f450s.mo427a();
                return true;
            } else if (i != 19 || this.f450s.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    /* renamed from: B */
    public final void mo378B() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f450s.getText());
        int i = 0;
        if (!z2 && (!this.f427S || this.f438g0)) {
            z = false;
        }
        ImageView imageView = this.f457y;
        if (!z) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.f457y.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    /* renamed from: C */
    public void mo379C() {
        int[] iArr = this.f450s.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f453u.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f454v.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    /* renamed from: D */
    public final void mo380D() {
        SpannableStringBuilder queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f450s;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.f427S && this.f416H != null) {
            double textSize = (double) searchAutoComplete.getTextSize();
            Double.isNaN(textSize);
            Double.isNaN(textSize);
            int i = (int) (textSize * 1.25d);
            this.f416H.setBounds(0, 0, i, i);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.f416H), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    /* renamed from: E */
    public final void mo381E() {
        int i = 0;
        if (!((this.f430V || this.f435d0) && !this.f428T) || !(this.f456x.getVisibility() == 0 || this.f458z.getVisibility() == 0)) {
            i = 8;
        }
        this.f454v.setVisibility(i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001e, code lost:
        if (r2.f435d0 == false) goto L_0x0023;
     */
    /* renamed from: F */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo382F(boolean r3) {
        /*
            r2 = this;
            boolean r0 = r2.f430V
            r1 = 0
            if (r0 == 0) goto L_0x0021
            if (r0 != 0) goto L_0x000b
            boolean r0 = r2.f435d0
            if (r0 == 0) goto L_0x0011
        L_0x000b:
            boolean r0 = r2.f428T
            if (r0 != 0) goto L_0x0011
            r0 = 1
            goto L_0x0012
        L_0x0011:
            r0 = 0
        L_0x0012:
            if (r0 == 0) goto L_0x0021
            boolean r0 = r2.hasFocus()
            if (r0 == 0) goto L_0x0021
            if (r3 != 0) goto L_0x0023
            boolean r3 = r2.f435d0
            if (r3 != 0) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            r1 = 8
        L_0x0023:
            android.widget.ImageView r3 = r2.f456x
            r3.setVisibility(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.mo382F(boolean):void");
    }

    /* renamed from: G */
    public final void mo383G(boolean z) {
        this.f428T = z;
        int i = 0;
        int i2 = z ? 0 : 8;
        boolean z2 = !TextUtils.isEmpty(this.f450s.getText());
        this.f455w.setVisibility(i2);
        mo382F(z2);
        this.f452t.setVisibility(z ? 8 : 0);
        if (this.f415G.getDrawable() == null || this.f427S) {
            i = 8;
        }
        this.f415G.setVisibility(i);
        mo378B();
        mo384H(!z2);
        mo381E();
    }

    /* renamed from: H */
    public final void mo384H(boolean z) {
        int i = 8;
        if (this.f435d0 && !this.f428T && z) {
            this.f456x.setVisibility(8);
            i = 0;
        }
        this.f458z.setVisibility(i);
    }

    /* renamed from: c */
    public void mo385c() {
        if (!this.f438g0) {
            this.f438g0 = true;
            int imeOptions = this.f450s.getImeOptions();
            this.f439h0 = imeOptions;
            this.f450s.setImeOptions(imeOptions | 33554432);
            this.f450s.setText("");
            setIconified(false);
        }
    }

    public void clearFocus() {
        this.f433b0 = true;
        super.clearFocus();
        this.f450s.clearFocus();
        this.f450s.setImeVisibility(false);
        this.f433b0 = false;
    }

    /* renamed from: e */
    public void mo387e() {
        this.f450s.setText("");
        SearchAutoComplete searchAutoComplete = this.f450s;
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f437f0 = "";
        clearFocus();
        mo383G(true);
        this.f450s.setImeOptions(this.f439h0);
        this.f438g0 = false;
    }

    public int getImeOptions() {
        return this.f450s.getImeOptions();
    }

    public int getInputType() {
        return this.f450s.getInputType();
    }

    public int getMaxWidth() {
        return this.f434c0;
    }

    public CharSequence getQuery() {
        return this.f450s.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f431W;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f440i0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f421M : getContext().getText(this.f440i0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f418J;
    }

    public int getSuggestionRowLayout() {
        return this.f417I;
    }

    public C2053x7 getSuggestionsAdapter() {
        return this.f429U;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.f442k0);
        post(this.f443l0);
        super.onDetachedFromWindow();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            SearchAutoComplete searchAutoComplete = this.f450s;
            Rect rect = this.f411C;
            searchAutoComplete.getLocationInWindow(this.f413E);
            getLocationInWindow(this.f414F);
            int[] iArr = this.f413E;
            int i5 = iArr[1];
            int[] iArr2 = this.f414F;
            int i6 = i5 - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            rect.set(i7, i6, searchAutoComplete.getWidth() + i7, searchAutoComplete.getHeight() + i6);
            Rect rect2 = this.f412D;
            Rect rect3 = this.f411C;
            rect2.set(rect3.left, 0, rect3.right, i4 - i2);
            C0107p pVar = this.f410B;
            if (pVar == null) {
                C0107p pVar2 = new C0107p(this.f412D, this.f411C, this.f450s);
                this.f410B = pVar2;
                setTouchDelegate(pVar2);
                return;
            }
            pVar.mo462a(this.f412D, this.f411C);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001d, code lost:
        if (r0 <= 0) goto L_0x0037;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0049  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.f428T
            if (r0 == 0) goto L_0x0008
            super.onMeasure(r4, r5)
            return
        L_0x0008:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x002a
            if (r0 == 0) goto L_0x0020
            if (r0 == r2) goto L_0x001b
            goto L_0x0037
        L_0x001b:
            int r0 = r3.f434c0
            if (r0 <= 0) goto L_0x0037
            goto L_0x002e
        L_0x0020:
            int r4 = r3.f434c0
            if (r4 <= 0) goto L_0x0025
            goto L_0x0037
        L_0x0025:
            int r4 = r3.getPreferredWidth()
            goto L_0x0037
        L_0x002a:
            int r0 = r3.f434c0
            if (r0 <= 0) goto L_0x002f
        L_0x002e:
            goto L_0x0033
        L_0x002f:
            int r0 = r3.getPreferredWidth()
        L_0x0033:
            int r4 = java.lang.Math.min(r0, r4)
        L_0x0037:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x0049
            if (r0 == 0) goto L_0x0044
            goto L_0x0051
        L_0x0044:
            int r5 = r3.getPreferredHeight()
            goto L_0x0051
        L_0x0049:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x0051:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0105o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0105o oVar = (C0105o) parcelable;
        super.onRestoreInstanceState(oVar.f43d);
        mo383G(oVar.f477f);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0105o oVar = new C0105o(super.onSaveInstanceState());
        oVar.f477f = this.f428T;
        return oVar;
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        post(this.f442k0);
    }

    /* renamed from: q */
    public final Intent mo400q(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f437f0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f441j0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f440i0.getSearchActivity());
        return intent;
    }

    /* renamed from: r */
    public final Intent mo401r(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f441j0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        int i = 1;
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.f433b0 || !isFocusable()) {
            return false;
        }
        if (this.f428T) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f450s.requestFocus(i, rect);
        if (requestFocus) {
            mo383G(false);
        }
        return requestFocus;
    }

    /* renamed from: s */
    public void mo403s() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.f450s.refreshAutoCompleteResults();
            return;
        }
        C0104n nVar = f408t0;
        SearchAutoComplete searchAutoComplete = this.f450s;
        Objects.requireNonNull(nVar);
        C0104n.m228a();
        Method method = nVar.f474a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused) {
            }
        }
        C0104n nVar2 = f408t0;
        SearchAutoComplete searchAutoComplete2 = this.f450s;
        Objects.requireNonNull(nVar2);
        C0104n.m228a();
        Method method2 = nVar2.f475b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete2, new Object[0]);
            } catch (Exception unused2) {
            }
        }
    }

    public void setAppSearchData(Bundle bundle) {
        this.f441j0 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            mo421u();
        } else {
            mo425y();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.f427S != z) {
            this.f427S = z;
            mo383G(z);
            mo380D();
        }
    }

    public void setImeOptions(int i) {
        this.f450s.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.f450s.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.f434c0 = i;
        requestLayout();
    }

    public void setOnCloseListener(C0101k kVar) {
        this.f423O = kVar;
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f424P = onFocusChangeListener;
    }

    public void setOnQueryTextListener(C0102l lVar) {
        this.f422N = lVar;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f426R = onClickListener;
    }

    public void setOnSuggestionListener(C0103m mVar) {
        this.f425Q = mVar;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f431W = charSequence;
        mo380D();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.f432a0 = z;
        C2053x7 x7Var = this.f429U;
        if (x7Var instanceof C1970w2) {
            ((C1970w2) x7Var).f6505t = z ? 2 : 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009c, code lost:
        if (getContext().getPackageManager().resolveActivity(r2, 65536) != null) goto L_0x00a0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.f440i0 = r7
            r0 = 1
            r1 = 65536(0x10000, float:9.18355E-41)
            r2 = 0
            if (r7 == 0) goto L_0x006e
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f450s
            int r7 = r7.getSuggestThreshold()
            r3.setThreshold(r7)
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f450s
            android.app.SearchableInfo r3 = r6.f440i0
            int r3 = r3.getImeOptions()
            r7.setImeOptions(r3)
            android.app.SearchableInfo r7 = r6.f440i0
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r0) goto L_0x0036
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.f440i0
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L_0x0036
            r7 = r7 | r1
            r3 = 524288(0x80000, float:7.34684E-40)
            r7 = r7 | r3
        L_0x0036:
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f450s
            r3.setInputType(r7)
            x7 r7 = r6.f429U
            if (r7 == 0) goto L_0x0042
            r7.mo6377b(r2)
        L_0x0042:
            android.app.SearchableInfo r7 = r6.f440i0
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L_0x006b
            w2 r7 = new w2
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.f440i0
            java.util.WeakHashMap<java.lang.String, android.graphics.drawable.Drawable$ConstantState> r5 = r6.f444m0
            r7.<init>(r3, r6, r4, r5)
            r6.f429U = r7
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f450s
            r3.setAdapter(r7)
            x7 r7 = r6.f429U
            w2 r7 = (p000.C1970w2) r7
            boolean r3 = r6.f432a0
            if (r3 == 0) goto L_0x0068
            r3 = 2
            goto L_0x0069
        L_0x0068:
            r3 = 1
        L_0x0069:
            r7.f6505t = r3
        L_0x006b:
            r6.mo380D()
        L_0x006e:
            android.app.SearchableInfo r7 = r6.f440i0
            r3 = 0
            if (r7 == 0) goto L_0x009f
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L_0x009f
            android.app.SearchableInfo r7 = r6.f440i0
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L_0x0084
            android.content.Intent r2 = r6.f419K
            goto L_0x008e
        L_0x0084:
            android.app.SearchableInfo r7 = r6.f440i0
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L_0x008e
            android.content.Intent r2 = r6.f420L
        L_0x008e:
            if (r2 == 0) goto L_0x009f
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r2, r1)
            if (r7 == 0) goto L_0x009f
            goto L_0x00a0
        L_0x009f:
            r0 = 0
        L_0x00a0:
            r6.f435d0 = r0
            if (r0 == 0) goto L_0x00ab
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f450s
            java.lang.String r0 = "nm"
            r7.setPrivateImeOptions(r0)
        L_0x00ab:
            boolean r7 = r6.f428T
            r6.mo383G(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.f430V = z;
        mo383G(this.f428T);
    }

    public void setSuggestionsAdapter(C2053x7 x7Var) {
        this.f429U = x7Var;
        this.f450s.setAdapter(x7Var);
    }

    /* renamed from: t */
    public void mo420t(int i, String str, String str2) {
        getContext().startActivity(mo400q("android.intent.action.SEARCH", (Uri) null, (String) null, str2, i, (String) null));
    }

    /* renamed from: u */
    public void mo421u() {
        if (!TextUtils.isEmpty(this.f450s.getText())) {
            this.f450s.setText("");
            this.f450s.requestFocus();
            this.f450s.setImeVisibility(true);
        } else if (this.f427S) {
            C0101k kVar = this.f423O;
            if (kVar == null || !kVar.mo453a()) {
                clearFocus();
                mo383G(true);
            }
        }
    }

    /* renamed from: v */
    public boolean mo422v(int i) {
        int i2;
        String h;
        C0103m mVar = this.f425Q;
        if (mVar != null && mVar.mo457b(i)) {
            return false;
        }
        Cursor cursor = this.f429U.f6739f;
        if (cursor != null && cursor.moveToPosition(i)) {
            Intent intent = null;
            try {
                int i3 = C1970w2.f6498B;
                String h2 = C1970w2.m5491h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (h2 == null) {
                    h2 = this.f440i0.getSuggestIntentAction();
                }
                if (h2 == null) {
                    h2 = "android.intent.action.SEARCH";
                }
                String str = h2;
                String h3 = C1970w2.m5491h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (h3 == null) {
                    h3 = this.f440i0.getSuggestIntentData();
                }
                if (!(h3 == null || (h = C1970w2.m5491h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) == null)) {
                    h3 = h3 + "/" + Uri.encode(h);
                }
                intent = mo400q(str, h3 == null ? null : Uri.parse(h3), C1970w2.m5491h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), C1970w2.m5491h(cursor, cursor.getColumnIndex("suggest_intent_query")), 0, (String) null);
            } catch (RuntimeException e) {
                try {
                    i2 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i2 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i2 + " returned exception.", e);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e2) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e2);
                }
            }
        }
        this.f450s.setImeVisibility(false);
        this.f450s.dismissDropDown();
        return true;
    }

    /* renamed from: w */
    public boolean mo423w(int i) {
        CharSequence c;
        C0103m mVar = this.f425Q;
        if (mVar != null && mVar.mo456a(i)) {
            return false;
        }
        Editable text = this.f450s.getText();
        Cursor cursor = this.f429U.f6739f;
        if (cursor == null) {
            return true;
        }
        if (!cursor.moveToPosition(i) || (c = this.f429U.mo6378c(cursor)) == null) {
            setQuery(text);
            return true;
        }
        setQuery(c);
        return true;
    }

    /* renamed from: x */
    public void mo424x(CharSequence charSequence) {
        setQuery(charSequence);
    }

    /* renamed from: y */
    public void mo425y() {
        mo383G(false);
        this.f450s.requestFocus();
        this.f450s.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f426R;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    /* renamed from: z */
    public void mo426z() {
        Editable text = this.f450s.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            C0102l lVar = this.f422N;
            if (lVar == null || !lVar.mo455b(text.toString())) {
                if (this.f440i0 != null) {
                    mo420t(0, (String) null, text.toString());
                }
                this.f450s.setImeVisibility(false);
                this.f450s.dismissDropDown();
            }
        }
    }
}
