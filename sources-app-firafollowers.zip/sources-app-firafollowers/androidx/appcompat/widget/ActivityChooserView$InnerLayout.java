package androidx.appcompat.widget;

import android.widget.LinearLayout;

public class ActivityChooserView$InnerLayout extends LinearLayout {

    /* renamed from: d */
    public static final int[] f390d = {16842964};

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0010, code lost:
        r1 = r4.getResourceId(0, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActivityChooserView$InnerLayout(android.content.Context r3, android.util.AttributeSet r4) {
        /*
            r2 = this;
            r2.<init>(r3, r4)
            int[] r0 = f390d
            android.content.res.TypedArray r4 = r3.obtainStyledAttributes(r4, r0)
            r0 = 0
            boolean r1 = r4.hasValue(r0)
            if (r1 == 0) goto L_0x001b
            int r1 = r4.getResourceId(r0, r0)
            if (r1 == 0) goto L_0x001b
            android.graphics.drawable.Drawable r3 = p000.C0001a0.m1b(r3, r1)
            goto L_0x001f
        L_0x001b:
            android.graphics.drawable.Drawable r3 = r4.getDrawable(r0)
        L_0x001f:
            r2.setBackgroundDrawable(r3)
            r4.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActivityChooserView$InnerLayout.<init>(android.content.Context, android.util.AttributeSet):void");
    }
}
