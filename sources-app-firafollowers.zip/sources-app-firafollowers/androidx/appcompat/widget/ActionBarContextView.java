package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.fasaroid.fira.R;

public class ActionBarContextView extends C0803h1 {

    /* renamed from: l */
    public CharSequence f324l;

    /* renamed from: m */
    public CharSequence f325m;

    /* renamed from: n */
    public View f326n;

    /* renamed from: o */
    public View f327o;

    /* renamed from: p */
    public LinearLayout f328p;

    /* renamed from: q */
    public TextView f329q;

    /* renamed from: r */
    public TextView f330r;

    /* renamed from: s */
    public int f331s;

    /* renamed from: t */
    public int f332t;

    /* renamed from: u */
    public boolean f333u;

    /* renamed from: v */
    public int f334v;

    /* renamed from: androidx.appcompat.widget.ActionBarContextView$a */
    public class C0078a implements View.OnClickListener {

        /* renamed from: d */
        public final /* synthetic */ C0727g0 f335d;

        public C0078a(ActionBarContextView actionBarContextView, C0727g0 g0Var) {
            this.f335d = g0Var;
        }

        public void onClick(View view) {
            this.f335d.mo3675c();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0013, code lost:
        r0 = r5.getResourceId(0, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActionBarContextView(android.content.Context r4, android.util.AttributeSet r5) {
        /*
            r3 = this;
            r0 = 2130903067(0x7f03001b, float:1.7412942E38)
            r3.<init>(r4, r5, r0)
            int[] r1 = p000.C0593e.f2374d
            r2 = 0
            android.content.res.TypedArray r5 = r4.obtainStyledAttributes(r5, r1, r0, r2)
            boolean r0 = r5.hasValue(r2)
            if (r0 == 0) goto L_0x001e
            int r0 = r5.getResourceId(r2, r2)
            if (r0 == 0) goto L_0x001e
            android.graphics.drawable.Drawable r4 = p000.C0001a0.m1b(r4, r0)
            goto L_0x0022
        L_0x001e:
            android.graphics.drawable.Drawable r4 = r5.getDrawable(r2)
        L_0x0022:
            java.util.WeakHashMap<android.view.View, java.lang.String> r0 = p000.C0010a7.f28a
            r3.setBackground(r4)
            r4 = 5
            int r4 = r5.getResourceId(r4, r2)
            r3.f331s = r4
            r4 = 4
            int r4 = r5.getResourceId(r4, r2)
            r3.f332t = r4
            r4 = 3
            int r4 = r5.getLayoutDimension(r4, r2)
            r3.f3003h = r4
            r4 = 2
            r0 = 2131492869(0x7f0c0005, float:1.8609202E38)
            int r4 = r5.getResourceId(r4, r0)
            r3.f334v = r4
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0063  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x007b  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x003c  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo225f(p000.C0727g0 r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.f326n
            r1 = 0
            if (r0 != 0) goto L_0x0016
            android.content.Context r0 = r6.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r2 = r6.f334v
            android.view.View r0 = r0.inflate(r2, r6, r1)
            r6.f326n = r0
            goto L_0x001e
        L_0x0016:
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0021
            android.view.View r0 = r6.f326n
        L_0x001e:
            r6.addView(r0)
        L_0x0021:
            android.view.View r0 = r6.f326n
            r2 = 2131296313(0x7f090039, float:1.821054E38)
            android.view.View r0 = r0.findViewById(r2)
            androidx.appcompat.widget.ActionBarContextView$a r2 = new androidx.appcompat.widget.ActionBarContextView$a
            r2.<init>(r6, r7)
            r0.setOnClickListener(r2)
            android.view.Menu r7 = r7.mo3677e()
            u0 r7 = (p000.C1838u0) r7
            j1 r0 = r6.f3002g
            if (r0 == 0) goto L_0x003f
            r0.mo4109b()
        L_0x003f:
            j1 r0 = new j1
            android.content.Context r2 = r6.getContext()
            r0.<init>(r2)
            r6.f3002g = r0
            r2 = 1
            r0.f3333o = r2
            r0.f3334p = r2
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r3 = -2
            r4 = -1
            r0.<init>(r3, r4)
            j1 r3 = r6.f3002g
            android.content.Context r4 = r6.f3000e
            r7.mo6066b(r3, r4)
            j1 r7 = r6.f3002g
            b1 r3 = r7.f4720k
            if (r3 != 0) goto L_0x0077
            android.view.LayoutInflater r4 = r7.f4716g
            int r5 = r7.f4718i
            android.view.View r1 = r4.inflate(r5, r6, r1)
            b1 r1 = (p000.C0243b1) r1
            r7.f4720k = r1
            u0 r4 = r7.f4715f
            r1.mo189b(r4)
            r7.mo13j(r2)
        L_0x0077:
            b1 r1 = r7.f4720k
            if (r3 == r1) goto L_0x0081
            r2 = r1
            androidx.appcompat.widget.ActionMenuView r2 = (androidx.appcompat.widget.ActionMenuView) r2
            r2.setPresenter(r7)
        L_0x0081:
            androidx.appcompat.widget.ActionMenuView r1 = (androidx.appcompat.widget.ActionMenuView) r1
            r6.f3001f = r1
            r7 = 0
            java.util.WeakHashMap<android.view.View, java.lang.String> r2 = p000.C0010a7.f28a
            r1.setBackground(r7)
            androidx.appcompat.widget.ActionMenuView r7 = r6.f3001f
            r6.addView(r7, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.mo225f(g0):void");
    }

    /* renamed from: g */
    public final void mo226g() {
        if (this.f328p == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f328p = linearLayout;
            this.f329q = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f330r = (TextView) this.f328p.findViewById(R.id.action_bar_subtitle);
            if (this.f331s != 0) {
                this.f329q.setTextAppearance(getContext(), this.f331s);
            }
            if (this.f332t != 0) {
                this.f330r.setTextAppearance(getContext(), this.f332t);
            }
        }
        this.f329q.setText(this.f324l);
        this.f330r.setText(this.f325m);
        boolean z = !TextUtils.isEmpty(this.f324l);
        boolean z2 = !TextUtils.isEmpty(this.f325m);
        int i = 0;
        this.f330r.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout2 = this.f328p;
        if (!z && !z2) {
            i = 8;
        }
        linearLayout2.setVisibility(i);
        if (this.f328p.getParent() == null) {
            addView(this.f328p);
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f325m;
    }

    public CharSequence getTitle() {
        return this.f324l;
    }

    /* renamed from: h */
    public void mo233h() {
        removeAllViews();
        this.f327o = null;
        this.f3001f = null;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0928j1 j1Var = this.f3002g;
        if (j1Var != null) {
            j1Var.mo4111k();
            this.f3002g.mo4112l();
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f324l);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean b = C0869i3.m2744b(this);
        int paddingRight = b ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.f326n;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f326n.getLayoutParams();
            int i5 = b ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = b ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i7 = b ? paddingRight - i5 : paddingRight + i5;
            int d = i7 + mo3849d(this.f326n, i7, paddingTop, paddingTop2, b);
            paddingRight = b ? d - i6 : d + i6;
        }
        int i8 = paddingRight;
        LinearLayout linearLayout = this.f328p;
        if (!(linearLayout == null || this.f327o != null || linearLayout.getVisibility() == 8)) {
            i8 += mo3849d(this.f328p, i8, paddingTop, paddingTop2, b);
        }
        int i9 = i8;
        View view2 = this.f327o;
        if (view2 != null) {
            mo3849d(view2, i9, paddingTop, paddingTop2, b);
        }
        int paddingLeft = b ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f3001f;
        if (actionMenuView != null) {
            mo3849d(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b);
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (View.MeasureSpec.getMode(i2) != 0) {
            int size = View.MeasureSpec.getSize(i);
            int i4 = this.f3003h;
            if (i4 <= 0) {
                i4 = View.MeasureSpec.getSize(i2);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = i4 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, Integer.MIN_VALUE);
            View view = this.f326n;
            if (view != null) {
                int c = mo3848c(view, paddingLeft, makeMeasureSpec, 0);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f326n.getLayoutParams();
                paddingLeft = c - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f3001f;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = mo3848c(this.f3001f, paddingLeft, makeMeasureSpec, 0);
            }
            LinearLayout linearLayout = this.f328p;
            if (linearLayout != null && this.f327o == null) {
                if (this.f333u) {
                    this.f328p.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f328p.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f328p.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = mo3848c(linearLayout, paddingLeft, makeMeasureSpec, 0);
                }
            }
            View view2 = this.f327o;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i6 = layoutParams.width;
                int i7 = i6 != -2 ? 1073741824 : Integer.MIN_VALUE;
                if (i6 >= 0) {
                    paddingLeft = Math.min(i6, paddingLeft);
                }
                int i8 = layoutParams.height;
                if (i8 == -2) {
                    i3 = Integer.MIN_VALUE;
                }
                if (i8 >= 0) {
                    i5 = Math.min(i8, i5);
                }
                this.f327o.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i7), View.MeasureSpec.makeMeasureSpec(i5, i3));
            }
            if (this.f3003h <= 0) {
                int childCount = getChildCount();
                i4 = 0;
                for (int i9 = 0; i9 < childCount; i9++) {
                    int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i4) {
                        i4 = measuredHeight;
                    }
                }
            }
            setMeasuredDimension(size, i4);
        } else {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
    }

    public void setContentHeight(int i) {
        this.f3003h = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f327o;
        if (view2 != null) {
            removeView(view2);
        }
        this.f327o = view;
        if (!(view == null || (linearLayout = this.f328p) == null)) {
            removeView(linearLayout);
            this.f328p = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f325m = charSequence;
        mo226g();
    }

    public void setTitle(CharSequence charSequence) {
        this.f324l = charSequence;
        mo226g();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.f333u) {
            requestLayout();
        }
        this.f333u = z;
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
