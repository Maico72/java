package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import p000.C1057l2;

public class FitWindowsLinearLayout extends LinearLayout implements C1057l2 {

    /* renamed from: d */
    public C1057l2.C1058a f407d;

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean fitSystemWindows(Rect rect) {
        C1057l2.C1058a aVar = this.f407d;
        if (aVar != null) {
            rect.top = ((C1645r) aVar).f5365a.mo5127X((C0943j7) null, rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C1057l2.C1058a aVar) {
        this.f407d = aVar;
    }
}
