package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import com.roughike.bottombar.C0446R;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0657f;

public class Toolbar extends ViewGroup {

    /* renamed from: A */
    public CharSequence f484A;

    /* renamed from: B */
    public CharSequence f485B;

    /* renamed from: C */
    public ColorStateList f486C;

    /* renamed from: D */
    public ColorStateList f487D;

    /* renamed from: E */
    public boolean f488E;

    /* renamed from: F */
    public boolean f489F;

    /* renamed from: G */
    public final ArrayList<View> f490G = new ArrayList<>();

    /* renamed from: H */
    public final ArrayList<View> f491H = new ArrayList<>();

    /* renamed from: I */
    public final int[] f492I = new int[2];

    /* renamed from: J */
    public C0113f f493J;

    /* renamed from: K */
    public final ActionMenuView.C0088e f494K = new C0108a();

    /* renamed from: L */
    public C0600e3 f495L;

    /* renamed from: M */
    public C0928j1 f496M;

    /* renamed from: N */
    public C0111d f497N;

    /* renamed from: O */
    public boolean f498O;

    /* renamed from: P */
    public final Runnable f499P = new C0109b();

    /* renamed from: d */
    public ActionMenuView f500d;

    /* renamed from: e */
    public TextView f501e;

    /* renamed from: f */
    public TextView f502f;

    /* renamed from: g */
    public ImageButton f503g;

    /* renamed from: h */
    public ImageView f504h;

    /* renamed from: i */
    public Drawable f505i;

    /* renamed from: j */
    public CharSequence f506j;

    /* renamed from: k */
    public ImageButton f507k;

    /* renamed from: l */
    public View f508l;

    /* renamed from: m */
    public Context f509m;

    /* renamed from: n */
    public int f510n;

    /* renamed from: o */
    public int f511o;

    /* renamed from: p */
    public int f512p;

    /* renamed from: q */
    public int f513q;

    /* renamed from: r */
    public int f514r;

    /* renamed from: s */
    public int f515s;

    /* renamed from: t */
    public int f516t;

    /* renamed from: u */
    public int f517u;

    /* renamed from: v */
    public int f518v;

    /* renamed from: w */
    public C1842u2 f519w;

    /* renamed from: x */
    public int f520x;

    /* renamed from: y */
    public int f521y;

    /* renamed from: z */
    public int f522z = 8388627;

    /* renamed from: androidx.appcompat.widget.Toolbar$a */
    public class C0108a implements ActionMenuView.C0088e {
        public C0108a() {
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$b */
    public class C0109b implements Runnable {
        public C0109b() {
        }

        public void run() {
            Toolbar.this.mo557u();
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$c */
    public class C0110c implements View.OnClickListener {
        public C0110c() {
        }

        public void onClick(View view) {
            C0111d dVar = Toolbar.this.f497N;
            C1967w0 w0Var = dVar == null ? null : dVar.f527e;
            if (w0Var != null) {
                w0Var.collapseActionView();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$d */
    public class C0111d implements C0003a1 {

        /* renamed from: d */
        public C1838u0 f526d;

        /* renamed from: e */
        public C1967w0 f527e;

        public C0111d() {
        }

        /* renamed from: a */
        public void mo6a(C1838u0 u0Var, boolean z) {
        }

        /* renamed from: c */
        public boolean mo7c() {
            return false;
        }

        /* renamed from: d */
        public void mo8d(Context context, C1838u0 u0Var) {
            C1967w0 w0Var;
            C1838u0 u0Var2 = this.f526d;
            if (!(u0Var2 == null || (w0Var = this.f527e) == null)) {
                u0Var2.mo3431d(w0Var);
            }
            this.f526d = u0Var;
        }

        /* renamed from: e */
        public boolean mo9e(C1838u0 u0Var, C1967w0 w0Var) {
            View view = Toolbar.this.f508l;
            if (view instanceof C0802h0) {
                ((C0802h0) view).mo387e();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f508l);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f507k);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f508l = null;
            int size = toolbar3.f491H.size();
            while (true) {
                size--;
                if (size >= 0) {
                    toolbar3.addView(toolbar3.f491H.get(size));
                } else {
                    toolbar3.f491H.clear();
                    this.f527e = null;
                    Toolbar.this.requestLayout();
                    w0Var.f6459C = false;
                    w0Var.f6474n.mo6082q(false);
                    return true;
                }
            }
        }

        /* renamed from: g */
        public boolean mo10g(C1838u0 u0Var, C1967w0 w0Var) {
            Toolbar.this.mo466c();
            ViewParent parent = Toolbar.this.f507k.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f507k);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f507k);
            }
            Toolbar.this.f508l = w0Var.getActionView();
            this.f527e = w0Var;
            ViewParent parent2 = Toolbar.this.f508l.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f508l);
                }
                C0112e h = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                h.f2620a = 8388611 | (toolbar4.f513q & C0446R.styleable.AppCompatTheme_tooltipForegroundColor);
                h.f529b = 2;
                toolbar4.f508l.setLayoutParams(h);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f508l);
            }
            Toolbar toolbar6 = Toolbar.this;
            int childCount = toolbar6.getChildCount();
            while (true) {
                childCount--;
                if (childCount < 0) {
                    break;
                }
                View childAt = toolbar6.getChildAt(childCount);
                if (!(((C0112e) childAt.getLayoutParams()).f529b == 2 || childAt == toolbar6.f500d)) {
                    toolbar6.removeViewAt(childCount);
                    toolbar6.f491H.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            w0Var.f6459C = true;
            w0Var.f6474n.mo6082q(false);
            View view = Toolbar.this.f508l;
            if (view instanceof C0802h0) {
                ((C0802h0) view).mo385c();
            }
            return true;
        }

        /* renamed from: i */
        public boolean mo12i(C0662f1 f1Var) {
            return false;
        }

        /* renamed from: j */
        public void mo13j(boolean z) {
            if (this.f527e != null) {
                C1838u0 u0Var = this.f526d;
                boolean z2 = false;
                if (u0Var != null) {
                    int size = u0Var.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        } else if (this.f526d.getItem(i) == this.f527e) {
                            z2 = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                if (!z2) {
                    mo9e(this.f526d, this.f527e);
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$e */
    public static class C0112e extends C0657f.C0658a {

        /* renamed from: b */
        public int f529b = 0;

        public C0112e(int i, int i2) {
            super(i, i2);
            this.f2620a = 8388627;
        }

        public C0112e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0112e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0112e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super((ViewGroup.LayoutParams) marginLayoutParams);
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }

        public C0112e(C0112e eVar) {
            super((C0657f.C0658a) eVar);
            this.f529b = eVar.f529b;
        }

        public C0112e(C0657f.C0658a aVar) {
            super(aVar);
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$f */
    public interface C0113f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$g */
    public static class C0114g extends C0015a8 {
        public static final Parcelable.Creator<C0114g> CREATOR = new C0115a();

        /* renamed from: f */
        public int f530f;

        /* renamed from: g */
        public boolean f531g;

        /* renamed from: androidx.appcompat.widget.Toolbar$g$a */
        public class C0115a implements Parcelable.ClassLoaderCreator<C0114g> {
            public Object createFromParcel(Parcel parcel) {
                return new C0114g(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0114g[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0114g(parcel, classLoader);
            }
        }

        public C0114g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f530f = parcel.readInt();
            this.f531g = parcel.readInt() != 0;
        }

        public C0114g(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeInt(this.f530f);
            parcel.writeInt(this.f531g ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        Context context2 = getContext();
        int[] iArr = C0593e.f2394x;
        C0327c3 s = C0327c3.m1245s(context2, attributeSet, iArr, R.attr.toolbarStyle, 0);
        C0010a7.m42o(this, context, iArr, attributeSet, s.f1430b, R.attr.toolbarStyle, 0);
        this.f511o = s.mo1836m(28, 0);
        this.f512p = s.mo1836m(19, 0);
        this.f522z = s.f1430b.getInteger(0, this.f522z);
        this.f513q = s.f1430b.getInteger(2, 48);
        int e = s.mo1828e(22, 0);
        e = s.mo1839p(27) ? s.mo1828e(27, e) : e;
        this.f518v = e;
        this.f517u = e;
        this.f516t = e;
        this.f515s = e;
        int e2 = s.mo1828e(25, -1);
        if (e2 >= 0) {
            this.f515s = e2;
        }
        int e3 = s.mo1828e(24, -1);
        if (e3 >= 0) {
            this.f516t = e3;
        }
        int e4 = s.mo1828e(26, -1);
        if (e4 >= 0) {
            this.f517u = e4;
        }
        int e5 = s.mo1828e(23, -1);
        if (e5 >= 0) {
            this.f518v = e5;
        }
        this.f514r = s.mo1829f(13, -1);
        int e6 = s.mo1828e(9, Integer.MIN_VALUE);
        int e7 = s.mo1828e(5, Integer.MIN_VALUE);
        int f = s.mo1829f(7, 0);
        int f2 = s.mo1829f(8, 0);
        mo468d();
        C1842u2 u2Var = this.f519w;
        u2Var.f6114h = false;
        if (f != Integer.MIN_VALUE) {
            u2Var.f6111e = f;
            u2Var.f6107a = f;
        }
        if (f2 != Integer.MIN_VALUE) {
            u2Var.f6112f = f2;
            u2Var.f6108b = f2;
        }
        if (!(e6 == Integer.MIN_VALUE && e7 == Integer.MIN_VALUE)) {
            u2Var.mo6102a(e6, e7);
        }
        this.f520x = s.mo1828e(10, Integer.MIN_VALUE);
        this.f521y = s.mo1828e(6, Integer.MIN_VALUE);
        this.f505i = s.mo1830g(4);
        this.f506j = s.mo1838o(3);
        CharSequence o = s.mo1838o(21);
        if (!TextUtils.isEmpty(o)) {
            setTitle(o);
        }
        CharSequence o2 = s.mo1838o(18);
        if (!TextUtils.isEmpty(o2)) {
            setSubtitle(o2);
        }
        this.f509m = getContext();
        setPopupTheme(s.mo1836m(17, 0));
        Drawable g = s.mo1830g(16);
        if (g != null) {
            setNavigationIcon(g);
        }
        CharSequence o3 = s.mo1838o(15);
        if (!TextUtils.isEmpty(o3)) {
            setNavigationContentDescription(o3);
        }
        Drawable g2 = s.mo1830g(11);
        if (g2 != null) {
            setLogo(g2);
        }
        CharSequence o4 = s.mo1838o(12);
        if (!TextUtils.isEmpty(o4)) {
            setLogoDescription(o4);
        }
        if (s.mo1839p(29)) {
            setTitleTextColor(s.mo1826c(29));
        }
        if (s.mo1839p(20)) {
            setSubtitleTextColor(s.mo1826c(20));
        }
        if (s.mo1839p(14)) {
            getMenuInflater().inflate(s.mo1836m(14, 0), getMenu());
        }
        s.f1430b.recycle();
    }

    private MenuInflater getMenuInflater() {
        return new C1053l0(getContext());
    }

    /* renamed from: a */
    public final void mo464a(List<View> list, int i) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        boolean z = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        list.clear();
        if (z) {
            for (int i2 = childCount - 1; i2 >= 0; i2--) {
                View childAt = getChildAt(i2);
                C0112e eVar = (C0112e) childAt.getLayoutParams();
                if (eVar.f529b == 0 && mo556t(childAt) && mo507j(eVar.f2620a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = getChildAt(i3);
            C0112e eVar2 = (C0112e) childAt2.getLayoutParams();
            if (eVar2.f529b == 0 && mo556t(childAt2) && mo507j(eVar2.f2620a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    /* renamed from: b */
    public final void mo465b(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        C0112e h = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (C0112e) layoutParams;
        h.f529b = 1;
        if (!z || this.f508l == null) {
            addView(view, h);
            return;
        }
        view.setLayoutParams(h);
        this.f491H.add(view);
    }

    /* renamed from: c */
    public void mo466c() {
        if (this.f507k == null) {
            C1652r1 r1Var = new C1652r1(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            this.f507k = r1Var;
            r1Var.setImageDrawable(this.f505i);
            this.f507k.setContentDescription(this.f506j);
            C0112e h = generateDefaultLayoutParams();
            h.f2620a = 8388611 | (this.f513q & C0446R.styleable.AppCompatTheme_tooltipForegroundColor);
            h.f529b = 2;
            this.f507k.setLayoutParams(h);
            this.f507k.setOnClickListener(new C0110c());
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof C0112e);
    }

    /* renamed from: d */
    public final void mo468d() {
        if (this.f519w == null) {
            this.f519w = new C1842u2();
        }
    }

    /* renamed from: e */
    public final void mo469e() {
        mo470f();
        ActionMenuView actionMenuView = this.f500d;
        if (actionMenuView.f375s == null) {
            C1838u0 u0Var = (C1838u0) actionMenuView.getMenu();
            if (this.f497N == null) {
                this.f497N = new C0111d();
            }
            this.f500d.setExpandedActionViewsExclusive(true);
            u0Var.mo6066b(this.f497N, this.f509m);
        }
    }

    /* renamed from: f */
    public final void mo470f() {
        if (this.f500d == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f500d = actionMenuView;
            actionMenuView.setPopupTheme(this.f510n);
            this.f500d.setOnMenuItemClickListener(this.f494K);
            ActionMenuView actionMenuView2 = this.f500d;
            actionMenuView2.f380x = null;
            actionMenuView2.f381y = null;
            C0112e h = generateDefaultLayoutParams();
            h.f2620a = 8388613 | (this.f513q & C0446R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.f500d.setLayoutParams(h);
            mo465b(this.f500d, false);
        }
    }

    /* renamed from: g */
    public final void mo471g() {
        if (this.f503g == null) {
            this.f503g = new C1652r1(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            C0112e h = generateDefaultLayoutParams();
            h.f2620a = 8388611 | (this.f513q & C0446R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.f503g.setLayoutParams(h);
        }
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0112e(getContext(), attributeSet);
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.f507k;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.f507k;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        C1842u2 u2Var = this.f519w;
        if (u2Var != null) {
            return u2Var.f6113g ? u2Var.f6107a : u2Var.f6108b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.f521y;
        return i != Integer.MIN_VALUE ? i : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        C1842u2 u2Var = this.f519w;
        if (u2Var != null) {
            return u2Var.f6107a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        C1842u2 u2Var = this.f519w;
        if (u2Var != null) {
            return u2Var.f6108b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        C1842u2 u2Var = this.f519w;
        if (u2Var != null) {
            return u2Var.f6113g ? u2Var.f6108b : u2Var.f6107a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.f520x;
        return i != Integer.MIN_VALUE ? i : getContentInsetStart();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0005, code lost:
        r0 = r0.f375s;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getCurrentContentInsetEnd() {
        /*
            r3 = this;
            androidx.appcompat.widget.ActionMenuView r0 = r3.f500d
            r1 = 0
            if (r0 == 0) goto L_0x0011
            u0 r0 = r0.f375s
            if (r0 == 0) goto L_0x0011
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0011
            r0 = 1
            goto L_0x0012
        L_0x0011:
            r0 = 0
        L_0x0012:
            if (r0 == 0) goto L_0x0023
            int r0 = r3.getContentInsetEnd()
            int r2 = r3.f521y
            int r1 = java.lang.Math.max(r2, r1)
            int r0 = java.lang.Math.max(r0, r1)
            goto L_0x0027
        L_0x0023:
            int r0 = r3.getContentInsetEnd()
        L_0x0027:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.getCurrentContentInsetEnd():int");
    }

    public int getCurrentContentInsetLeft() {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f520x, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f504h;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f504h;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        mo469e();
        return this.f500d.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f503g;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f503g;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public C0928j1 getOuterActionMenuPresenter() {
        return this.f496M;
    }

    public Drawable getOverflowIcon() {
        mo469e();
        return this.f500d.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f509m;
    }

    public int getPopupTheme() {
        return this.f510n;
    }

    public CharSequence getSubtitle() {
        return this.f485B;
    }

    public final TextView getSubtitleTextView() {
        return this.f502f;
    }

    public CharSequence getTitle() {
        return this.f484A;
    }

    public int getTitleMarginBottom() {
        return this.f518v;
    }

    public int getTitleMarginEnd() {
        return this.f516t;
    }

    public int getTitleMarginStart() {
        return this.f515s;
    }

    public int getTitleMarginTop() {
        return this.f517u;
    }

    public final TextView getTitleTextView() {
        return this.f501e;
    }

    public C0864i2 getWrapper() {
        if (this.f495L == null) {
            this.f495L = new C0600e3(this, true);
        }
        return this.f495L;
    }

    /* renamed from: h */
    public C0112e generateDefaultLayoutParams() {
        return new C0112e(-2, -2);
    }

    /* renamed from: i */
    public C0112e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0112e ? new C0112e((C0112e) layoutParams) : layoutParams instanceof C0657f.C0658a ? new C0112e((C0657f.C0658a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0112e((ViewGroup.MarginLayoutParams) layoutParams) : new C0112e(layoutParams);
    }

    /* renamed from: j */
    public final int mo507j(int i) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int layoutDirection = getLayoutDirection();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, layoutDirection) & 7;
        if (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) {
            return absoluteGravity;
        }
        return layoutDirection == 1 ? 5 : 3;
    }

    /* renamed from: k */
    public final int mo508k(View view, int i) {
        C0112e eVar = (C0112e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i3 = eVar.f2620a & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
        if (!(i3 == 16 || i3 == 48 || i3 == 80)) {
            i3 = this.f522z & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
        }
        if (i3 == 48) {
            return getPaddingTop() - i2;
        }
        if (i3 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - eVar.bottomMargin) - i2;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = eVar.topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = eVar.bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    /* renamed from: l */
    public final int mo509l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    /* renamed from: m */
    public final int mo510m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    /* renamed from: n */
    public final boolean mo511n(View view) {
        return view.getParent() == this || this.f491H.contains(view);
    }

    /* renamed from: o */
    public boolean mo512o() {
        ActionMenuView actionMenuView = this.f500d;
        if (actionMenuView != null) {
            C0928j1 j1Var = actionMenuView.f379w;
            if (j1Var != null && j1Var.mo4113m()) {
                return true;
            }
        }
        return false;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f499P);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f489F = false;
        }
        if (!this.f489F) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f489F = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f489F = false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:107:0x0297 A[LOOP:0: B:106:0x0295->B:107:0x0297, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x02b9 A[LOOP:1: B:109:0x02b7->B:110:0x02b9, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x02de A[LOOP:2: B:112:0x02dc->B:113:0x02de, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x031f  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x0330 A[LOOP:3: B:120:0x032e->B:121:0x0330, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00df  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00fd  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0115  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0124  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0127  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x012b  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x015f  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01ae  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x021d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            r19 = this;
            r0 = r19
            java.util.WeakHashMap<android.view.View, java.lang.String> r1 = p000.C0010a7.f28a
            int r1 = r19.getLayoutDirection()
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000e
            r1 = 1
            goto L_0x000f
        L_0x000e:
            r1 = 0
        L_0x000f:
            int r4 = r19.getWidth()
            int r5 = r19.getHeight()
            int r6 = r19.getPaddingLeft()
            int r7 = r19.getPaddingRight()
            int r8 = r19.getPaddingTop()
            int r9 = r19.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f492I
            r11[r2] = r3
            r11[r3] = r3
            int r12 = r19.getMinimumHeight()
            if (r12 < 0) goto L_0x003c
            int r13 = r24 - r22
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003d
        L_0x003c:
            r12 = 0
        L_0x003d:
            android.widget.ImageButton r13 = r0.f503g
            boolean r13 = r0.mo556t(r13)
            if (r13 == 0) goto L_0x0055
            android.widget.ImageButton r13 = r0.f503g
            if (r1 == 0) goto L_0x0050
            int r13 = r0.mo522q(r13, r10, r11, r12)
            r14 = r13
            r13 = r6
            goto L_0x0057
        L_0x0050:
            int r13 = r0.mo521p(r13, r6, r11, r12)
            goto L_0x0056
        L_0x0055:
            r13 = r6
        L_0x0056:
            r14 = r10
        L_0x0057:
            android.widget.ImageButton r15 = r0.f507k
            boolean r15 = r0.mo556t(r15)
            if (r15 == 0) goto L_0x006c
            android.widget.ImageButton r15 = r0.f507k
            if (r1 == 0) goto L_0x0068
            int r14 = r0.mo522q(r15, r14, r11, r12)
            goto L_0x006c
        L_0x0068:
            int r13 = r0.mo521p(r15, r13, r11, r12)
        L_0x006c:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f500d
            boolean r15 = r0.mo556t(r15)
            if (r15 == 0) goto L_0x0081
            androidx.appcompat.widget.ActionMenuView r15 = r0.f500d
            if (r1 == 0) goto L_0x007d
            int r13 = r0.mo521p(r15, r13, r11, r12)
            goto L_0x0081
        L_0x007d:
            int r14 = r0.mo522q(r15, r14, r11, r12)
        L_0x0081:
            int r15 = r19.getCurrentContentInsetLeft()
            int r16 = r19.getCurrentContentInsetRight()
            int r2 = r15 - r13
            int r2 = java.lang.Math.max(r3, r2)
            r11[r3] = r2
            int r2 = r10 - r14
            int r2 = r16 - r2
            int r2 = java.lang.Math.max(r3, r2)
            r17 = 1
            r11[r17] = r2
            int r2 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.f508l
            boolean r13 = r0.mo556t(r13)
            if (r13 == 0) goto L_0x00bc
            android.view.View r13 = r0.f508l
            if (r1 == 0) goto L_0x00b8
            int r10 = r0.mo522q(r13, r10, r11, r12)
            goto L_0x00bc
        L_0x00b8:
            int r2 = r0.mo521p(r13, r2, r11, r12)
        L_0x00bc:
            android.widget.ImageView r13 = r0.f504h
            boolean r13 = r0.mo556t(r13)
            if (r13 == 0) goto L_0x00d1
            android.widget.ImageView r13 = r0.f504h
            if (r1 == 0) goto L_0x00cd
            int r10 = r0.mo522q(r13, r10, r11, r12)
            goto L_0x00d1
        L_0x00cd:
            int r2 = r0.mo521p(r13, r2, r11, r12)
        L_0x00d1:
            android.widget.TextView r13 = r0.f501e
            boolean r13 = r0.mo556t(r13)
            android.widget.TextView r14 = r0.f502f
            boolean r14 = r0.mo556t(r14)
            if (r13 == 0) goto L_0x00f8
            android.widget.TextView r15 = r0.f501e
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r15 = (androidx.appcompat.widget.Toolbar.C0112e) r15
            int r3 = r15.topMargin
            r23 = r7
            android.widget.TextView r7 = r0.f501e
            int r7 = r7.getMeasuredHeight()
            int r7 = r7 + r3
            int r3 = r15.bottomMargin
            int r7 = r7 + r3
            r3 = 0
            int r7 = r7 + r3
            goto L_0x00fb
        L_0x00f8:
            r23 = r7
            r7 = 0
        L_0x00fb:
            if (r14 == 0) goto L_0x0115
            android.widget.TextView r3 = r0.f502f
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r3 = (androidx.appcompat.widget.Toolbar.C0112e) r3
            int r15 = r3.topMargin
            r16 = r4
            android.widget.TextView r4 = r0.f502f
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r15
            int r3 = r3.bottomMargin
            int r4 = r4 + r3
            int r7 = r7 + r4
            goto L_0x0117
        L_0x0115:
            r16 = r4
        L_0x0117:
            if (r13 != 0) goto L_0x0122
            if (r14 == 0) goto L_0x011c
            goto L_0x0122
        L_0x011c:
            r18 = r6
            r22 = r12
            goto L_0x0287
        L_0x0122:
            if (r13 == 0) goto L_0x0127
            android.widget.TextView r3 = r0.f501e
            goto L_0x0129
        L_0x0127:
            android.widget.TextView r3 = r0.f502f
        L_0x0129:
            if (r14 == 0) goto L_0x012e
            android.widget.TextView r4 = r0.f502f
            goto L_0x0130
        L_0x012e:
            android.widget.TextView r4 = r0.f501e
        L_0x0130:
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r3 = (androidx.appcompat.widget.Toolbar.C0112e) r3
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r4 = (androidx.appcompat.widget.Toolbar.C0112e) r4
            if (r13 == 0) goto L_0x0146
            android.widget.TextView r15 = r0.f501e
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x0150
        L_0x0146:
            if (r14 == 0) goto L_0x0153
            android.widget.TextView r15 = r0.f502f
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x0153
        L_0x0150:
            r17 = 1
            goto L_0x0155
        L_0x0153:
            r17 = 0
        L_0x0155:
            int r15 = r0.f522z
            r15 = r15 & 112(0x70, float:1.57E-43)
            r18 = r6
            r6 = 48
            if (r15 == r6) goto L_0x019d
            r6 = 80
            if (r15 == r6) goto L_0x018f
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r7
            int r6 = r6 / 2
            int r15 = r3.topMargin
            r22 = r12
            int r12 = r0.f517u
            r24 = r2
            int r2 = r15 + r12
            if (r6 >= r2) goto L_0x0178
            int r6 = r15 + r12
            goto L_0x018d
        L_0x0178:
            int r5 = r5 - r9
            int r5 = r5 - r7
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r3.bottomMargin
            int r3 = r0.f518v
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x018d
            int r2 = r4.bottomMargin
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x018d:
            int r8 = r8 + r6
            goto L_0x01ac
        L_0x018f:
            r24 = r2
            r22 = r12
            int r5 = r5 - r9
            int r2 = r4.bottomMargin
            int r5 = r5 - r2
            int r2 = r0.f518v
            int r5 = r5 - r2
            int r8 = r5 - r7
            goto L_0x01ac
        L_0x019d:
            r24 = r2
            r22 = r12
            int r2 = r19.getPaddingTop()
            int r3 = r3.topMargin
            int r2 = r2 + r3
            int r3 = r0.f517u
            int r8 = r2 + r3
        L_0x01ac:
            if (r1 == 0) goto L_0x021d
            if (r17 == 0) goto L_0x01b3
            int r1 = r0.f515s
            goto L_0x01b4
        L_0x01b3:
            r1 = 0
        L_0x01b4:
            r2 = 1
            r3 = r11[r2]
            int r1 = r1 - r3
            r3 = 0
            int r4 = java.lang.Math.max(r3, r1)
            int r10 = r10 - r4
            int r1 = -r1
            int r1 = java.lang.Math.max(r3, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x01eb
            android.widget.TextView r1 = r0.f501e
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0112e) r1
            android.widget.TextView r2 = r0.f501e
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            android.widget.TextView r3 = r0.f501e
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f501e
            r4.layout(r2, r8, r10, r3)
            int r4 = r0.f516t
            int r2 = r2 - r4
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01ec
        L_0x01eb:
            r2 = r10
        L_0x01ec:
            if (r14 == 0) goto L_0x0212
            android.widget.TextView r1 = r0.f502f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0112e) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f502f
            int r1 = r1.getMeasuredWidth()
            int r1 = r10 - r1
            android.widget.TextView r3 = r0.f502f
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f502f
            r4.layout(r1, r8, r10, r3)
            int r1 = r0.f516t
            int r1 = r10 - r1
            goto L_0x0213
        L_0x0212:
            r1 = r10
        L_0x0213:
            if (r17 == 0) goto L_0x021a
            int r1 = java.lang.Math.min(r2, r1)
            r10 = r1
        L_0x021a:
            r2 = r24
            goto L_0x0287
        L_0x021d:
            if (r17 == 0) goto L_0x0222
            int r1 = r0.f515s
            goto L_0x0223
        L_0x0222:
            r1 = 0
        L_0x0223:
            r2 = 0
            r3 = r11[r2]
            int r1 = r1 - r3
            int r3 = java.lang.Math.max(r2, r1)
            int r3 = r3 + r24
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x0259
            android.widget.TextView r1 = r0.f501e
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0112e) r1
            android.widget.TextView r2 = r0.f501e
            int r2 = r2.getMeasuredWidth()
            int r2 = r2 + r3
            android.widget.TextView r4 = r0.f501e
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f501e
            r5.layout(r3, r8, r2, r4)
            int r5 = r0.f516t
            int r2 = r2 + r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x025a
        L_0x0259:
            r2 = r3
        L_0x025a:
            if (r14 == 0) goto L_0x027e
            android.widget.TextView r1 = r0.f502f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0112e) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f502f
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r3
            android.widget.TextView r4 = r0.f502f
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f502f
            r5.layout(r3, r8, r1, r4)
            int r4 = r0.f516t
            int r1 = r1 + r4
            goto L_0x027f
        L_0x027e:
            r1 = r3
        L_0x027f:
            if (r17 == 0) goto L_0x0286
            int r2 = java.lang.Math.max(r2, r1)
            goto L_0x0287
        L_0x0286:
            r2 = r3
        L_0x0287:
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            r3 = 3
            r0.mo464a(r1, r3)
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            int r1 = r1.size()
            r3 = r2
            r2 = 0
        L_0x0295:
            if (r2 >= r1) goto L_0x02a8
            java.util.ArrayList<android.view.View> r4 = r0.f490G
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            r12 = r22
            int r3 = r0.mo521p(r4, r3, r11, r12)
            int r2 = r2 + 1
            goto L_0x0295
        L_0x02a8:
            r12 = r22
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            r2 = 5
            r0.mo464a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            int r1 = r1.size()
            r2 = 0
        L_0x02b7:
            if (r2 >= r1) goto L_0x02c8
            java.util.ArrayList<android.view.View> r4 = r0.f490G
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            int r10 = r0.mo522q(r4, r10, r11, r12)
            int r2 = r2 + 1
            goto L_0x02b7
        L_0x02c8:
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            r2 = 1
            r0.mo464a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            r4 = 0
            r5 = r11[r4]
            r2 = r11[r2]
            int r4 = r1.size()
            r7 = r5
            r5 = 0
            r6 = 0
        L_0x02dc:
            if (r5 >= r4) goto L_0x030f
            java.lang.Object r8 = r1.get(r5)
            android.view.View r8 = (android.view.View) r8
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r9 = (androidx.appcompat.widget.Toolbar.C0112e) r9
            int r13 = r9.leftMargin
            int r13 = r13 - r7
            int r7 = r9.rightMargin
            int r7 = r7 - r2
            r2 = 0
            int r9 = java.lang.Math.max(r2, r13)
            int r14 = java.lang.Math.max(r2, r7)
            int r13 = -r13
            int r13 = java.lang.Math.max(r2, r13)
            int r7 = -r7
            int r7 = java.lang.Math.max(r2, r7)
            int r8 = r8.getMeasuredWidth()
            int r8 = r8 + r9
            int r8 = r8 + r14
            int r6 = r6 + r8
            int r5 = r5 + 1
            r2 = r7
            r7 = r13
            goto L_0x02dc
        L_0x030f:
            r2 = 0
            int r4 = r16 - r18
            int r4 = r4 - r23
            int r4 = r4 / 2
            int r4 = r4 + r18
            int r1 = r6 / 2
            int r4 = r4 - r1
            int r6 = r6 + r4
            if (r4 >= r3) goto L_0x031f
            goto L_0x0326
        L_0x031f:
            if (r6 <= r10) goto L_0x0325
            int r6 = r6 - r10
            int r3 = r4 - r6
            goto L_0x0326
        L_0x0325:
            r3 = r4
        L_0x0326:
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            int r1 = r1.size()
            r2 = r3
            r3 = 0
        L_0x032e:
            if (r3 >= r1) goto L_0x033f
            java.util.ArrayList<android.view.View> r4 = r0.f490G
            java.lang.Object r4 = r4.get(r3)
            android.view.View r4 = (android.view.View) r4
            int r2 = r0.mo521p(r4, r2, r11, r12)
            int r3 = r3 + 1
            goto L_0x032e
        L_0x033f:
            java.util.ArrayList<android.view.View> r1 = r0.f490G
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i, int i2) {
        char c;
        char c2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int[] iArr = this.f492I;
        boolean z = true;
        int i10 = 0;
        if (C0869i3.m2744b(this)) {
            c2 = 1;
            c = 0;
        } else {
            c2 = 0;
            c = 1;
        }
        if (mo556t(this.f503g)) {
            mo524s(this.f503g, i, 0, i2, 0, this.f514r);
            i5 = mo509l(this.f503g) + this.f503g.getMeasuredWidth();
            i4 = Math.max(0, mo510m(this.f503g) + this.f503g.getMeasuredHeight());
            i3 = View.combineMeasuredStates(0, this.f503g.getMeasuredState());
        } else {
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (mo556t(this.f507k)) {
            mo524s(this.f507k, i, 0, i2, 0, this.f514r);
            i5 = mo509l(this.f507k) + this.f507k.getMeasuredWidth();
            i4 = Math.max(i4, mo510m(this.f507k) + this.f507k.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f507k.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i5) + 0;
        iArr[c2] = Math.max(0, currentContentInsetStart - i5);
        if (mo556t(this.f500d)) {
            mo524s(this.f500d, i, max, i2, 0, this.f514r);
            i6 = mo509l(this.f500d) + this.f500d.getMeasuredWidth();
            i4 = Math.max(i4, mo510m(this.f500d) + this.f500d.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f500d.getMeasuredState());
        } else {
            i6 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = Math.max(currentContentInsetEnd, i6) + max;
        iArr[c] = Math.max(0, currentContentInsetEnd - i6);
        if (mo556t(this.f508l)) {
            max2 += mo523r(this.f508l, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, mo510m(this.f508l) + this.f508l.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f508l.getMeasuredState());
        }
        if (mo556t(this.f504h)) {
            max2 += mo523r(this.f504h, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, mo510m(this.f504h) + this.f504h.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f504h.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((C0112e) childAt.getLayoutParams()).f529b == 0 && mo556t(childAt)) {
                View view = childAt;
                max2 += mo523r(childAt, i, max2, i2, 0, iArr);
                View view2 = view;
                i4 = Math.max(i4, mo510m(view2) + view.getMeasuredHeight());
                i3 = View.combineMeasuredStates(i3, view2.getMeasuredState());
            }
        }
        int i12 = this.f517u + this.f518v;
        int i13 = this.f515s + this.f516t;
        if (mo556t(this.f501e)) {
            mo523r(this.f501e, i, max2 + i13, i2, i12, iArr);
            int l = mo509l(this.f501e) + this.f501e.getMeasuredWidth();
            i7 = mo510m(this.f501e) + this.f501e.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i3, this.f501e.getMeasuredState());
            i8 = l;
        } else {
            i9 = i3;
            i8 = 0;
            i7 = 0;
        }
        if (mo556t(this.f502f)) {
            int i14 = i7 + i12;
            i8 = Math.max(i8, mo523r(this.f502f, i, max2 + i13, i2, i14, iArr));
            i7 = mo510m(this.f502f) + this.f502f.getMeasuredHeight() + i7;
            i9 = View.combineMeasuredStates(i9, this.f502f.getMeasuredState());
        } else {
            int i15 = i9;
        }
        int max3 = Math.max(i4, i7);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max3;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max2 + i8, getSuggestedMinimumWidth()), i, -16777216 & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i2, i9 << 16);
        if (this.f498O) {
            int childCount2 = getChildCount();
            int i16 = 0;
            while (true) {
                if (i16 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i16);
                if (mo556t(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i16++;
            }
        }
        z = false;
        if (!z) {
            i10 = resolveSizeAndState2;
        }
        setMeasuredDimension(resolveSizeAndState, i10);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof C0114g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0114g gVar = (C0114g) parcelable;
        super.onRestoreInstanceState(gVar.f43d);
        ActionMenuView actionMenuView = this.f500d;
        C1838u0 u0Var = actionMenuView != null ? actionMenuView.f375s : null;
        int i = gVar.f530f;
        if (!(i == 0 || this.f497N == null || u0Var == null || (findItem = u0Var.findItem(i)) == null)) {
            findItem.expandActionView();
        }
        if (gVar.f531g) {
            removeCallbacks(this.f499P);
            post(this.f499P);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x003e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0035, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x003e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onRtlPropertiesChanged(int r3) {
        /*
            r2 = this;
            super.onRtlPropertiesChanged(r3)
            r2.mo468d()
            u2 r0 = r2.f519w
            r1 = 1
            if (r3 != r1) goto L_0x000c
            goto L_0x000d
        L_0x000c:
            r1 = 0
        L_0x000d:
            boolean r3 = r0.f6113g
            if (r1 != r3) goto L_0x0012
            goto L_0x0040
        L_0x0012:
            r0.f6113g = r1
            boolean r3 = r0.f6114h
            if (r3 == 0) goto L_0x0038
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x002a
            int r1 = r0.f6110d
            if (r1 == r3) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            int r1 = r0.f6111e
        L_0x0023:
            r0.f6107a = r1
            int r1 = r0.f6109c
            if (r1 == r3) goto L_0x003c
            goto L_0x003e
        L_0x002a:
            int r1 = r0.f6109c
            if (r1 == r3) goto L_0x002f
            goto L_0x0031
        L_0x002f:
            int r1 = r0.f6111e
        L_0x0031:
            r0.f6107a = r1
            int r1 = r0.f6110d
            if (r1 == r3) goto L_0x003c
            goto L_0x003e
        L_0x0038:
            int r3 = r0.f6111e
            r0.f6107a = r3
        L_0x003c:
            int r1 = r0.f6112f
        L_0x003e:
            r0.f6108b = r1
        L_0x0040:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onRtlPropertiesChanged(int):void");
    }

    public Parcelable onSaveInstanceState() {
        C1967w0 w0Var;
        C0114g gVar = new C0114g(super.onSaveInstanceState());
        C0111d dVar = this.f497N;
        if (!(dVar == null || (w0Var = dVar.f527e) == null)) {
            gVar.f530f = w0Var.f6461a;
        }
        gVar.f531g = mo512o();
        return gVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f488E = false;
        }
        if (!this.f488E) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f488E = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f488E = false;
        }
        return true;
    }

    /* renamed from: p */
    public final int mo521p(View view, int i, int[] iArr, int i2) {
        C0112e eVar = (C0112e) view.getLayoutParams();
        int i3 = eVar.leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        int k = mo508k(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, k, max + measuredWidth, view.getMeasuredHeight() + k);
        return measuredWidth + eVar.rightMargin + max;
    }

    /* renamed from: q */
    public final int mo522q(View view, int i, int[] iArr, int i2) {
        C0112e eVar = (C0112e) view.getLayoutParams();
        int i3 = eVar.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int k = mo508k(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, k, max, view.getMeasuredHeight() + k);
        return max - (measuredWidth + eVar.leftMargin);
    }

    /* renamed from: r */
    public final int mo523r(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i5);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + max + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    /* renamed from: s */
    public final void mo524s(View view, int i, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            mo466c();
        }
        ImageButton imageButton = this.f507k;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(C0001a0.m1b(getContext(), i));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            mo466c();
            this.f507k.setImageDrawable(drawable);
            return;
        }
        ImageButton imageButton = this.f507k;
        if (imageButton != null) {
            imageButton.setImageDrawable(this.f505i);
        }
    }

    public void setCollapsible(boolean z) {
        this.f498O = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f521y) {
            this.f521y = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f520x) {
            this.f520x = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(C0001a0.m1b(getContext(), i));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f504h == null) {
                this.f504h = new AppCompatImageView(getContext(), (AttributeSet) null);
            }
            if (!mo511n(this.f504h)) {
                mo465b(this.f504h, true);
            }
        } else {
            ImageView imageView = this.f504h;
            if (imageView != null && mo511n(imageView)) {
                removeView(this.f504h);
                this.f491H.remove(this.f504h);
            }
        }
        ImageView imageView2 = this.f504h;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f504h == null) {
            this.f504h = new AppCompatImageView(getContext(), (AttributeSet) null);
        }
        ImageView imageView = this.f504h;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            mo471g();
        }
        ImageButton imageButton = this.f503g;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(C0001a0.m1b(getContext(), i));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            mo471g();
            if (!mo511n(this.f503g)) {
                mo465b(this.f503g, true);
            }
        } else {
            ImageButton imageButton = this.f503g;
            if (imageButton != null && mo511n(imageButton)) {
                removeView(this.f503g);
                this.f491H.remove(this.f503g);
            }
        }
        ImageButton imageButton2 = this.f503g;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        mo471g();
        this.f503g.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(C0113f fVar) {
        this.f493J = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        mo469e();
        this.f500d.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.f510n != i) {
            this.f510n = i;
            if (i == 0) {
                this.f509m = getContext();
            } else {
                this.f509m = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f502f == null) {
                Context context = getContext();
                C0599e2 e2Var = new C0599e2(context, (AttributeSet) null);
                this.f502f = e2Var;
                e2Var.setSingleLine();
                this.f502f.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f512p;
                if (i != 0) {
                    this.f502f.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f487D;
                if (colorStateList != null) {
                    this.f502f.setTextColor(colorStateList);
                }
            }
            if (!mo511n(this.f502f)) {
                mo465b(this.f502f, true);
            }
        } else {
            TextView textView = this.f502f;
            if (textView != null && mo511n(textView)) {
                removeView(this.f502f);
                this.f491H.remove(this.f502f);
            }
        }
        TextView textView2 = this.f502f;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f485B = charSequence;
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f487D = colorStateList;
        TextView textView = this.f502f;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f501e == null) {
                Context context = getContext();
                C0599e2 e2Var = new C0599e2(context, (AttributeSet) null);
                this.f501e = e2Var;
                e2Var.setSingleLine();
                this.f501e.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f511o;
                if (i != 0) {
                    this.f501e.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f486C;
                if (colorStateList != null) {
                    this.f501e.setTextColor(colorStateList);
                }
            }
            if (!mo511n(this.f501e)) {
                mo465b(this.f501e, true);
            }
        } else {
            TextView textView = this.f501e;
            if (textView != null && mo511n(textView)) {
                removeView(this.f501e);
                this.f491H.remove(this.f501e);
            }
        }
        TextView textView2 = this.f501e;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f484A = charSequence;
    }

    public void setTitleMarginBottom(int i) {
        this.f518v = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.f516t = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.f515s = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.f517u = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f486C = colorStateList;
        TextView textView = this.f501e;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    /* renamed from: t */
    public final boolean mo556t(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* renamed from: u */
    public boolean mo557u() {
        ActionMenuView actionMenuView = this.f500d;
        if (actionMenuView != null) {
            C0928j1 j1Var = actionMenuView.f379w;
            if (j1Var != null && j1Var.mo4114n()) {
                return true;
            }
        }
        return false;
    }
}
