package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.Toolbar;
import p000.C0003a1;
import p000.C0928j1;
import p000.C1216n2;
import p000.C1838u0;

public class ActionMenuView extends C1216n2 implements C1838u0.C1840b, C0243b1 {

    /* renamed from: A */
    public int f371A;

    /* renamed from: B */
    public int f372B;

    /* renamed from: C */
    public int f373C;

    /* renamed from: D */
    public C0088e f374D;

    /* renamed from: s */
    public C1838u0 f375s;

    /* renamed from: t */
    public Context f376t;

    /* renamed from: u */
    public int f377u = 0;

    /* renamed from: v */
    public boolean f378v;

    /* renamed from: w */
    public C0928j1 f379w;

    /* renamed from: x */
    public C0003a1.C0004a f380x;

    /* renamed from: y */
    public C1838u0.C1839a f381y;

    /* renamed from: z */
    public boolean f382z;

    /* renamed from: androidx.appcompat.widget.ActionMenuView$a */
    public interface C0084a {
        /* renamed from: a */
        boolean mo168a();

        /* renamed from: b */
        boolean mo169b();
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$b */
    public static class C0085b implements C0003a1.C0004a {
        /* renamed from: a */
        public void mo14a(C1838u0 u0Var, boolean z) {
        }

        /* renamed from: b */
        public boolean mo15b(C1838u0 u0Var) {
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$c */
    public static class C0086c extends C1216n2.C1217a {
        @ViewDebug.ExportedProperty

        /* renamed from: c */
        public boolean f383c;
        @ViewDebug.ExportedProperty

        /* renamed from: d */
        public int f384d;
        @ViewDebug.ExportedProperty

        /* renamed from: e */
        public int f385e;
        @ViewDebug.ExportedProperty

        /* renamed from: f */
        public boolean f386f;
        @ViewDebug.ExportedProperty

        /* renamed from: g */
        public boolean f387g;

        /* renamed from: h */
        public boolean f388h;

        public C0086c(int i, int i2) {
            super(i, i2);
            this.f383c = false;
        }

        public C0086c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0086c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0086c(C0086c cVar) {
            super(cVar);
            this.f383c = cVar.f383c;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$d */
    public class C0087d implements C1838u0.C1839a {
        public C0087d() {
        }

        /* renamed from: a */
        public boolean mo330a(C1838u0 u0Var, MenuItem menuItem) {
            C0088e eVar = ActionMenuView.this.f374D;
            if (eVar == null) {
                return false;
            }
            Toolbar.C0113f fVar = Toolbar.this.f493J;
            return fVar != null ? fVar.onMenuItemClick(menuItem) : false;
        }

        /* renamed from: b */
        public void mo331b(C1838u0 u0Var) {
            C1838u0.C1839a aVar = ActionMenuView.this.f381y;
            if (aVar != null) {
                aVar.mo331b(u0Var);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$e */
    public interface C0088e {
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f372B = (int) (56.0f * f);
        this.f373C = (int) (f * 4.0f);
        this.f376t = context;
    }

    /* renamed from: t */
    public static int m183t(View view, int i, int i2, int i3, int i4) {
        C0086c cVar = (C0086c) view.getLayoutParams();
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3) - i4, View.MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z = false;
        boolean z2 = actionMenuItemView != null && actionMenuItemView.mo170c();
        int i5 = 2;
        if (i2 <= 0 || (z2 && i2 < 2)) {
            i5 = 0;
        } else {
            view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i, Integer.MIN_VALUE), makeMeasureSpec);
            int measuredWidth = view.getMeasuredWidth();
            int i6 = measuredWidth / i;
            if (measuredWidth % i != 0) {
                i6++;
            }
            if (!z2 || i6 >= 2) {
                i5 = i6;
            }
        }
        if (!cVar.f383c && z2) {
            z = true;
        }
        cVar.f386f = z;
        cVar.f384d = i5;
        view.measure(View.MeasureSpec.makeMeasureSpec(i * i5, 1073741824), makeMeasureSpec);
        return i5;
    }

    /* renamed from: a */
    public boolean mo188a(C1967w0 w0Var) {
        return this.f375s.mo6086s(w0Var, (C0003a1) null, 0);
    }

    /* renamed from: b */
    public void mo189b(C1838u0 u0Var) {
        this.f375s = u0Var;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0086c;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0086c(getContext(), attributeSet);
    }

    public Menu getMenu() {
        if (this.f375s == null) {
            Context context = getContext();
            C1838u0 u0Var = new C1838u0(context);
            this.f375s = u0Var;
            u0Var.f6080e = new C0087d();
            C0928j1 j1Var = new C0928j1(context);
            this.f379w = j1Var;
            j1Var.f3333o = true;
            j1Var.f3334p = true;
            C0003a1.C0004a aVar = this.f380x;
            if (aVar == null) {
                aVar = new C0085b();
            }
            j1Var.f4717h = aVar;
            this.f375s.mo6066b(j1Var, this.f376t);
            C0928j1 j1Var2 = this.f379w;
            j1Var2.f4720k = this;
            this.f375s = j1Var2.f4715f;
        }
        return this.f375s;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0928j1 j1Var = this.f379w;
        C0928j1.C0932d dVar = j1Var.f3330l;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (j1Var.f3332n) {
            return j1Var.f3331m;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f377u;
    }

    public int getWindowAnimations() {
        return 0;
    }

    /* renamed from: i */
    public C1216n2.C1217a mo315i(AttributeSet attributeSet) {
        return new C0086c(getContext(), attributeSet);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0928j1 j1Var = this.f379w;
        if (j1Var != null) {
            j1Var.mo13j(false);
            if (this.f379w.mo4113m()) {
                this.f379w.mo4111k();
                this.f379w.mo4114n();
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0928j1 j1Var = this.f379w;
        if (j1Var != null) {
            j1Var.mo4109b();
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        if (!this.f382z) {
            super.onLayout(z, i, i2, i3, i4);
            return;
        }
        int childCount = getChildCount();
        int i7 = (i4 - i2) / 2;
        int dividerWidth = getDividerWidth();
        int i8 = i3 - i;
        int paddingRight = (i8 - getPaddingRight()) - getPaddingLeft();
        boolean b = C0869i3.m2744b(this);
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (childAt.getVisibility() != 8) {
                C0086c cVar = (C0086c) childAt.getLayoutParams();
                if (cVar.f383c) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (mo323s(i11)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (b) {
                        i5 = getPaddingLeft() + cVar.leftMargin;
                        i6 = i5 + measuredWidth;
                    } else {
                        i6 = (getWidth() - getPaddingRight()) - cVar.rightMargin;
                        i5 = i6 - measuredWidth;
                    }
                    int i12 = i7 - (measuredHeight / 2);
                    childAt.layout(i5, i12, i6, measuredHeight + i12);
                    paddingRight -= measuredWidth;
                    i9 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + cVar.leftMargin) + cVar.rightMargin;
                    mo323s(i11);
                    i10++;
                }
            }
        }
        if (childCount == 1 && i9 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i13 = (i8 / 2) - (measuredWidth2 / 2);
            int i14 = i7 - (measuredHeight2 / 2);
            childAt2.layout(i13, i14, measuredWidth2 + i13, measuredHeight2 + i14);
            return;
        }
        int i15 = i10 - (i9 ^ 1);
        int max = Math.max(0, i15 > 0 ? paddingRight / i15 : 0);
        if (b) {
            int width = getWidth() - getPaddingRight();
            for (int i16 = 0; i16 < childCount; i16++) {
                View childAt3 = getChildAt(i16);
                C0086c cVar2 = (C0086c) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !cVar2.f383c) {
                    int i17 = width - cVar2.rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i18 = i7 - (measuredHeight3 / 2);
                    childAt3.layout(i17 - measuredWidth3, i18, i17, measuredHeight3 + i18);
                    width = i17 - ((measuredWidth3 + cVar2.leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i19 = 0; i19 < childCount; i19++) {
            View childAt4 = getChildAt(i19);
            C0086c cVar3 = (C0086c) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !cVar3.f383c) {
                int i20 = paddingLeft + cVar3.leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i21 = i7 - (measuredHeight4 / 2);
                childAt4.layout(i20, i21, i20 + measuredWidth4, measuredHeight4 + i21);
                paddingLeft = measuredWidth4 + cVar3.rightMargin + max + i20;
            }
        }
    }

    public void onMeasure(int i, int i2) {
        int i3;
        boolean z;
        int i4;
        int i5;
        boolean z2;
        int i6;
        boolean z3;
        C1838u0 u0Var;
        boolean z4 = this.f382z;
        boolean z5 = View.MeasureSpec.getMode(i) == 1073741824;
        this.f382z = z5;
        if (z4 != z5) {
            this.f371A = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (!(!this.f382z || (u0Var = this.f375s) == null || size == this.f371A)) {
            this.f371A = size;
            u0Var.mo6082q(true);
        }
        int childCount = getChildCount();
        if (!this.f382z || childCount <= 0) {
            int i7 = i2;
            for (int i8 = 0; i8 < childCount; i8++) {
                C0086c cVar = (C0086c) getChildAt(i8).getLayoutParams();
                cVar.rightMargin = 0;
                cVar.leftMargin = 0;
            }
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i);
        int size3 = View.MeasureSpec.getSize(i2);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingBottom, -2);
        int i9 = size2 - paddingRight;
        int i10 = this.f372B;
        int i11 = i9 / i10;
        int i12 = i9 % i10;
        if (i11 == 0) {
            setMeasuredDimension(i9, 0);
            return;
        }
        int i13 = (i12 / i11) + i10;
        int childCount2 = getChildCount();
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        boolean z6 = false;
        long j = 0;
        while (i18 < childCount2) {
            View childAt = getChildAt(i18);
            int i19 = size3;
            int i20 = i9;
            if (childAt.getVisibility() != 8) {
                boolean z7 = childAt instanceof ActionMenuItemView;
                int i21 = i14 + 1;
                if (z7) {
                    int i22 = this.f373C;
                    i6 = i21;
                    z3 = false;
                    childAt.setPadding(i22, 0, i22, 0);
                } else {
                    i6 = i21;
                    z3 = false;
                }
                C0086c cVar2 = (C0086c) childAt.getLayoutParams();
                cVar2.f388h = z3;
                cVar2.f385e = z3 ? 1 : 0;
                cVar2.f384d = z3;
                cVar2.f386f = z3;
                cVar2.leftMargin = z3;
                cVar2.rightMargin = z3;
                cVar2.f387g = z7 && ((ActionMenuItemView) childAt).mo170c();
                int t = m183t(childAt, i13, cVar2.f383c ? 1 : i11, childMeasureSpec, paddingBottom);
                i16 = Math.max(i16, t);
                if (cVar2.f386f) {
                    i17++;
                }
                if (cVar2.f383c) {
                    z6 = true;
                }
                i11 -= t;
                i15 = Math.max(i15, childAt.getMeasuredHeight());
                if (t == 1) {
                    j |= (long) (1 << i18);
                }
                i14 = i6;
            }
            i18++;
            size3 = i19;
            i9 = i20;
        }
        int i23 = i9;
        int i24 = size3;
        boolean z8 = z6 && i14 == 2;
        boolean z9 = false;
        while (true) {
            if (i17 <= 0 || i11 <= 0) {
                i3 = i15;
                z = z9;
            } else {
                int i25 = Integer.MAX_VALUE;
                int i26 = 0;
                int i27 = 0;
                long j2 = 0;
                while (i26 < childCount2) {
                    int i28 = i15;
                    C0086c cVar3 = (C0086c) getChildAt(i26).getLayoutParams();
                    boolean z10 = z9;
                    if (cVar3.f386f) {
                        int i29 = cVar3.f384d;
                        if (i29 < i25) {
                            j2 = 1 << i26;
                            i25 = i29;
                            i27 = 1;
                        } else if (i29 == i25) {
                            i27++;
                            j2 |= 1 << i26;
                        }
                    }
                    i26++;
                    z9 = z10;
                    i15 = i28;
                }
                i3 = i15;
                z = z9;
                j |= j2;
                if (i27 > i11) {
                    break;
                }
                int i30 = i25 + 1;
                int i31 = 0;
                while (i31 < childCount2) {
                    View childAt2 = getChildAt(i31);
                    C0086c cVar4 = (C0086c) childAt2.getLayoutParams();
                    int i32 = i17;
                    long j3 = (long) (1 << i31);
                    if ((j2 & j3) == 0) {
                        if (cVar4.f384d == i30) {
                            j |= j3;
                        }
                        z2 = z8;
                    } else {
                        if (!z8 || !cVar4.f387g || i11 != 1) {
                            z2 = z8;
                        } else {
                            int i33 = this.f373C;
                            z2 = z8;
                            childAt2.setPadding(i33 + i13, 0, i33, 0);
                        }
                        cVar4.f384d++;
                        cVar4.f388h = true;
                        i11--;
                    }
                    i31++;
                    i17 = i32;
                    z8 = z2;
                }
                i15 = i3;
                z9 = true;
            }
        }
        i3 = i15;
        z = z9;
        boolean z11 = !z6 && i14 == 1;
        if (i11 > 0 && j != 0 && (i11 < i14 - 1 || z11 || i16 > 1)) {
            float bitCount = (float) Long.bitCount(j);
            if (!z11) {
                if ((j & 1) != 0 && !((C0086c) getChildAt(0).getLayoutParams()).f387g) {
                    bitCount -= 0.5f;
                }
                int i34 = childCount2 - 1;
                if ((j & ((long) (1 << i34))) != 0 && !((C0086c) getChildAt(i34).getLayoutParams()).f387g) {
                    bitCount -= 0.5f;
                }
            }
            int i35 = bitCount > 0.0f ? (int) (((float) (i11 * i13)) / bitCount) : 0;
            for (int i36 = 0; i36 < childCount2; i36++) {
                if ((j & ((long) (1 << i36))) != 0) {
                    View childAt3 = getChildAt(i36);
                    C0086c cVar5 = (C0086c) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        cVar5.f385e = i35;
                        cVar5.f388h = true;
                        if (i36 == 0 && !cVar5.f387g) {
                            cVar5.leftMargin = (-i35) / 2;
                        }
                    } else if (cVar5.f383c) {
                        cVar5.f385e = i35;
                        cVar5.f388h = true;
                        cVar5.rightMargin = (-i35) / 2;
                    } else {
                        if (i36 != 0) {
                            cVar5.leftMargin = i35 / 2;
                        }
                        if (i36 != childCount2 - 1) {
                            cVar5.rightMargin = i35 / 2;
                        }
                    }
                    z = true;
                }
            }
        }
        if (z) {
            for (int i37 = 0; i37 < childCount2; i37++) {
                View childAt4 = getChildAt(i37);
                C0086c cVar6 = (C0086c) childAt4.getLayoutParams();
                if (cVar6.f388h) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((cVar6.f384d * i13) + cVar6.f385e, 1073741824), childMeasureSpec);
                }
            }
        }
        if (mode != 1073741824) {
            i5 = i23;
            i4 = i3;
        } else {
            i4 = i24;
            i5 = i23;
        }
        setMeasuredDimension(i5, i4);
    }

    /* renamed from: q */
    public C0086c mo314h() {
        C0086c cVar = new C0086c(-2, -2);
        cVar.f4178b = 16;
        return cVar;
    }

    /* renamed from: r */
    public C0086c mo316j(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return mo314h();
        }
        C0086c cVar = layoutParams instanceof C0086c ? new C0086c((C0086c) layoutParams) : new C0086c(layoutParams);
        if (cVar.f4178b <= 0) {
            cVar.f4178b = 16;
        }
        return cVar;
    }

    /* renamed from: s */
    public boolean mo323s(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof C0084a)) {
            z = false | ((C0084a) childAt).mo168a();
        }
        return (i <= 0 || !(childAt2 instanceof C0084a)) ? z : z | ((C0084a) childAt2).mo169b();
    }

    public void setExpandedActionViewsExclusive(boolean z) {
        this.f379w.f3338t = z;
    }

    public void setOnMenuItemClickListener(C0088e eVar) {
        this.f374D = eVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0928j1 j1Var = this.f379w;
        C0928j1.C0932d dVar = j1Var.f3330l;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        j1Var.f3332n = true;
        j1Var.f3331m = drawable;
    }

    public void setOverflowReserved(boolean z) {
        this.f378v = z;
    }

    public void setPopupTheme(int i) {
        if (this.f377u != i) {
            this.f377u = i;
            if (i == 0) {
                this.f376t = getContext();
            } else {
                this.f376t = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0928j1 j1Var) {
        this.f379w = j1Var;
        j1Var.f4720k = this;
        this.f375s = j1Var.f4715f;
    }
}
