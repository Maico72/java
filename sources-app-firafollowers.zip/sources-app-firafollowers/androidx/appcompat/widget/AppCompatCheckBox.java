package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckBox;
import org.fasaroid.fira.R;

public class AppCompatCheckBox extends CheckBox implements C1847u7, C2195z6 {

    /* renamed from: d */
    public final C1287o1 f391d;

    /* renamed from: e */
    public final C1056l1 f392e;

    /* renamed from: f */
    public final C0523d2 f393f;

    public AppCompatCheckBox(Context context, AttributeSet attributeSet) {
        super(C2182z2.m5945a(context), attributeSet, R.attr.checkboxStyle);
        C2045x2.m5634a(this, getContext());
        C1287o1 o1Var = new C1287o1(this);
        this.f391d = o1Var;
        o1Var.mo4970b(attributeSet, R.attr.checkboxStyle);
        C1056l1 l1Var = new C1056l1(this);
        this.f392e = l1Var;
        l1Var.mo4390d(attributeSet, R.attr.checkboxStyle);
        C0523d2 d2Var = new C0523d2(this);
        this.f393f = d2Var;
        d2Var.mo2865e(attributeSet, R.attr.checkboxStyle);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            l1Var.mo4387a();
        }
        C0523d2 d2Var = this.f393f;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        C1287o1 o1Var = this.f391d;
        return compoundPaddingLeft;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            return l1Var.mo4388b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            return l1Var.mo4389c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        C1287o1 o1Var = this.f391d;
        if (o1Var != null) {
            return o1Var.f4402b;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C1287o1 o1Var = this.f391d;
        if (o1Var != null) {
            return o1Var.f4403c;
        }
        return null;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            l1Var.mo4391e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            l1Var.mo4392f(i);
        }
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(C0001a0.m1b(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C1287o1 o1Var = this.f391d;
        if (o1Var == null) {
            return;
        }
        if (o1Var.f4406f) {
            o1Var.f4406f = false;
            return;
        }
        o1Var.f4406f = true;
        o1Var.mo4969a();
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            l1Var.mo4394h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C1056l1 l1Var = this.f392e;
        if (l1Var != null) {
            l1Var.mo4395i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C1287o1 o1Var = this.f391d;
        if (o1Var != null) {
            o1Var.f4402b = colorStateList;
            o1Var.f4404d = true;
            o1Var.mo4969a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C1287o1 o1Var = this.f391d;
        if (o1Var != null) {
            o1Var.f4403c = mode;
            o1Var.f4405e = true;
            o1Var.mo4969a();
        }
    }
}
