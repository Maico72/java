package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;
import org.fasaroid.fira.R;

public class AlertController {

    /* renamed from: A */
    public NestedScrollView f218A;

    /* renamed from: B */
    public int f219B = 0;

    /* renamed from: C */
    public Drawable f220C;

    /* renamed from: D */
    public ImageView f221D;

    /* renamed from: E */
    public TextView f222E;

    /* renamed from: F */
    public TextView f223F;

    /* renamed from: G */
    public View f224G;

    /* renamed from: H */
    public ListAdapter f225H;

    /* renamed from: I */
    public int f226I = -1;

    /* renamed from: J */
    public int f227J;

    /* renamed from: K */
    public int f228K;

    /* renamed from: L */
    public int f229L;

    /* renamed from: M */
    public int f230M;

    /* renamed from: N */
    public int f231N;

    /* renamed from: O */
    public int f232O;

    /* renamed from: P */
    public boolean f233P;

    /* renamed from: Q */
    public Handler f234Q;

    /* renamed from: R */
    public final View.OnClickListener f235R = new C0072a();

    /* renamed from: a */
    public final Context f236a;

    /* renamed from: b */
    public final C1894v f237b;

    /* renamed from: c */
    public final Window f238c;

    /* renamed from: d */
    public final int f239d;

    /* renamed from: e */
    public CharSequence f240e;

    /* renamed from: f */
    public CharSequence f241f;

    /* renamed from: g */
    public ListView f242g;

    /* renamed from: h */
    public View f243h;

    /* renamed from: i */
    public int f244i;

    /* renamed from: j */
    public int f245j;

    /* renamed from: k */
    public int f246k;

    /* renamed from: l */
    public int f247l;

    /* renamed from: m */
    public int f248m;

    /* renamed from: n */
    public boolean f249n = false;

    /* renamed from: o */
    public Button f250o;

    /* renamed from: p */
    public CharSequence f251p;

    /* renamed from: q */
    public Message f252q;

    /* renamed from: r */
    public Drawable f253r;

    /* renamed from: s */
    public Button f254s;

    /* renamed from: t */
    public CharSequence f255t;

    /* renamed from: u */
    public Message f256u;

    /* renamed from: v */
    public Drawable f257v;

    /* renamed from: w */
    public Button f258w;

    /* renamed from: x */
    public CharSequence f259x;

    /* renamed from: y */
    public Message f260y;

    /* renamed from: z */
    public Drawable f261z;

    public static class RecycleListView extends ListView {

        /* renamed from: d */
        public final int f262d;

        /* renamed from: e */
        public final int f263e;

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0593e.f2390t);
            this.f263e = obtainStyledAttributes.getDimensionPixelOffset(0, -1);
            this.f262d = obtainStyledAttributes.getDimensionPixelOffset(1, -1);
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$a */
    public class C0072a implements View.OnClickListener {
        public C0072a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x001c, code lost:
            r3 = r0.f260y;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onClick(android.view.View r3) {
            /*
                r2 = this;
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f250o
                if (r3 != r1) goto L_0x000f
                android.os.Message r1 = r0.f252q
                if (r1 == 0) goto L_0x000f
            L_0x000a:
                android.os.Message r3 = android.os.Message.obtain(r1)
                goto L_0x0026
            L_0x000f:
                android.widget.Button r1 = r0.f254s
                if (r3 != r1) goto L_0x0018
                android.os.Message r1 = r0.f256u
                if (r1 == 0) goto L_0x0018
                goto L_0x000a
            L_0x0018:
                android.widget.Button r1 = r0.f258w
                if (r3 != r1) goto L_0x0025
                android.os.Message r3 = r0.f260y
                if (r3 == 0) goto L_0x0025
                android.os.Message r3 = android.os.Message.obtain(r3)
                goto L_0x0026
            L_0x0025:
                r3 = 0
            L_0x0026:
                if (r3 == 0) goto L_0x002b
                r3.sendToTarget()
            L_0x002b:
                androidx.appcompat.app.AlertController r3 = androidx.appcompat.app.AlertController.this
                android.os.Handler r0 = r3.f234Q
                r1 = 1
                v r3 = r3.f237b
                android.os.Message r3 = r0.obtainMessage(r1, r3)
                r3.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.C0072a.onClick(android.view.View):void");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$b */
    public static class C0073b {

        /* renamed from: a */
        public final Context f265a;

        /* renamed from: b */
        public final LayoutInflater f266b;

        /* renamed from: c */
        public Drawable f267c;

        /* renamed from: d */
        public CharSequence f268d;

        /* renamed from: e */
        public View f269e;

        /* renamed from: f */
        public CharSequence f270f;

        /* renamed from: g */
        public CharSequence f271g;

        /* renamed from: h */
        public DialogInterface.OnClickListener f272h;

        /* renamed from: i */
        public CharSequence f273i;

        /* renamed from: j */
        public DialogInterface.OnClickListener f274j;

        /* renamed from: k */
        public boolean f275k;

        /* renamed from: l */
        public DialogInterface.OnKeyListener f276l;

        /* renamed from: m */
        public ListAdapter f277m;

        /* renamed from: n */
        public DialogInterface.OnClickListener f278n;

        /* renamed from: o */
        public View f279o;

        /* renamed from: p */
        public boolean f280p;

        /* renamed from: q */
        public int f281q = -1;

        public C0073b(Context context) {
            this.f265a = context;
            this.f275k = true;
            this.f266b = (LayoutInflater) context.getSystemService("layout_inflater");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$c */
    public static final class C0074c extends Handler {

        /* renamed from: a */
        public WeakReference<DialogInterface> f282a;

        public C0074c(DialogInterface dialogInterface) {
            this.f282a = new WeakReference<>(dialogInterface);
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i == -3 || i == -2 || i == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f282a.get(), message.what);
            } else if (i == 1) {
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$d */
    public static class C0075d extends ArrayAdapter<CharSequence> {
        public C0075d(Context context, int i, int i2, CharSequence[] charSequenceArr) {
            super(context, i, i2, (Object[]) null);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, C1894v vVar, Window window) {
        this.f236a = context;
        this.f237b = vVar;
        this.f238c = window;
        this.f234Q = new C0074c(vVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, C0593e.f2375e, R.attr.alertDialogStyle, 0);
        this.f227J = obtainStyledAttributes.getResourceId(0, 0);
        this.f228K = obtainStyledAttributes.getResourceId(2, 0);
        this.f229L = obtainStyledAttributes.getResourceId(4, 0);
        this.f230M = obtainStyledAttributes.getResourceId(5, 0);
        this.f231N = obtainStyledAttributes.getResourceId(7, 0);
        this.f232O = obtainStyledAttributes.getResourceId(3, 0);
        this.f233P = obtainStyledAttributes.getBoolean(6, true);
        this.f239d = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        vVar.mo6155a().mo4906t(1);
    }

    /* renamed from: a */
    public static boolean m140a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (m140a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: c */
    public static void m141c(View view, View view2, View view3) {
        int i = 4;
        if (view2 != null) {
            view2.setVisibility(view.canScrollVertically(-1) ? 0 : 4);
        }
        if (view3 != null) {
            if (view.canScrollVertically(1)) {
                i = 0;
            }
            view3.setVisibility(i);
        }
    }

    /* renamed from: b */
    public final void mo161b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    /* renamed from: d */
    public final ViewGroup mo162d(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    /* renamed from: e */
    public void mo163e(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        Message obtainMessage = onClickListener != null ? this.f234Q.obtainMessage(i, onClickListener) : null;
        if (i == -3) {
            this.f259x = charSequence;
            this.f260y = obtainMessage;
            this.f261z = null;
        } else if (i == -2) {
            this.f255t = charSequence;
            this.f256u = obtainMessage;
            this.f257v = null;
        } else if (i == -1) {
            this.f251p = charSequence;
            this.f252q = obtainMessage;
            this.f253r = null;
        } else {
            throw new IllegalArgumentException("Button does not exist");
        }
    }
}
