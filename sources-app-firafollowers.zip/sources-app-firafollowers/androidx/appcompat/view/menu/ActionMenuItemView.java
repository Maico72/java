package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import p000.C0243b1;
import p000.C0928j1;
import p000.C1838u0;

public class ActionMenuItemView extends C0599e2 implements C0243b1.C0244a, View.OnClickListener, ActionMenuView.C0084a {

    /* renamed from: h */
    public C1967w0 f283h;

    /* renamed from: i */
    public CharSequence f284i;

    /* renamed from: j */
    public Drawable f285j;

    /* renamed from: k */
    public C1838u0.C1840b f286k;

    /* renamed from: l */
    public C1156m2 f287l;

    /* renamed from: m */
    public C0077b f288m;

    /* renamed from: n */
    public boolean f289n = mo172e();

    /* renamed from: o */
    public boolean f290o;

    /* renamed from: p */
    public int f291p;

    /* renamed from: q */
    public int f292q;

    /* renamed from: r */
    public int f293r;

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$a */
    public class C0076a extends C1156m2 {
        public C0076a() {
            super(ActionMenuItemView.this);
        }

        /* renamed from: b */
        public C0522d1 mo18b() {
            C0928j1.C0929a aVar;
            C0077b bVar = ActionMenuItemView.this.f288m;
            if (bVar == null || (aVar = C0928j1.this.f3342x) == null) {
                return null;
            }
            return aVar.mo6722a();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
            r0 = mo18b();
         */
        /* renamed from: c */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo19c() {
            /*
                r3 = this;
                androidx.appcompat.view.menu.ActionMenuItemView r0 = androidx.appcompat.view.menu.ActionMenuItemView.this
                u0$b r1 = r0.f286k
                r2 = 0
                if (r1 == 0) goto L_0x001c
                w0 r0 = r0.f283h
                boolean r0 = r1.mo188a(r0)
                if (r0 == 0) goto L_0x001c
                d1 r0 = r3.mo18b()
                if (r0 == 0) goto L_0x001c
                boolean r0 = r0.mo2858b()
                if (r0 == 0) goto L_0x001c
                r2 = 1
            L_0x001c:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ActionMenuItemView.C0076a.mo19c():boolean");
        }
    }

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$b */
    public static abstract class C0077b {
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0593e.f2373c, 0, 0);
        this.f291p = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f293r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f292q = -1;
        setSaveEnabled(false);
    }

    /* renamed from: a */
    public boolean mo168a() {
        return mo170c();
    }

    /* renamed from: b */
    public boolean mo169b() {
        return mo170c() && this.f283h.getIcon() == null;
    }

    /* renamed from: c */
    public boolean mo170c() {
        return !TextUtils.isEmpty(getText());
    }

    /* renamed from: d */
    public void mo171d(C1967w0 w0Var, int i) {
        this.f283h = w0Var;
        setIcon(w0Var.getIcon());
        setTitle(w0Var.getTitleCondensed());
        setId(w0Var.f6461a);
        setVisibility(w0Var.isVisible() ? 0 : 8);
        setEnabled(w0Var.isEnabled());
        if (w0Var.hasSubMenu() && this.f287l == null) {
            this.f287l = new C0076a();
        }
    }

    /* renamed from: e */
    public final boolean mo172e() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    /* renamed from: f */
    public final void mo173f() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f284i);
        if (this.f285j != null) {
            if (!((this.f283h.f6485y & 4) == 4) || (!this.f289n && !this.f290o)) {
                z = false;
            }
        }
        boolean z3 = z2 & z;
        CharSequence charSequence = null;
        setText(z3 ? this.f284i : null);
        CharSequence charSequence2 = this.f283h.f6477q;
        if (TextUtils.isEmpty(charSequence2)) {
            if (z3) {
                charSequence2 = null;
            } else {
                charSequence2 = this.f283h.f6465e;
            }
        }
        setContentDescription(charSequence2);
        CharSequence charSequence3 = this.f283h.f6478r;
        if (TextUtils.isEmpty(charSequence3)) {
            if (!z3) {
                charSequence = this.f283h.f6465e;
            }
            C0520d.m1654c(this, charSequence);
            return;
        }
        C0520d.m1654c(this, charSequence3);
    }

    public C1967w0 getItemData() {
        return this.f283h;
    }

    public void onClick(View view) {
        C1838u0.C1840b bVar = this.f286k;
        if (bVar != null) {
            bVar.mo188a(this.f283h);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f289n = mo172e();
        mo173f();
    }

    public void onMeasure(int i, int i2) {
        int i3;
        boolean c = mo170c();
        if (c && (i3 = this.f292q) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int min = mode == Integer.MIN_VALUE ? Math.min(size, this.f291p) : this.f291p;
        if (mode != 1073741824 && this.f291p > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i2);
        }
        if (!c && this.f285j != null) {
            super.setPadding((getMeasuredWidth() - this.f285j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C1156m2 m2Var;
        if (!this.f283h.hasSubMenu() || (m2Var = this.f287l) == null || !m2Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.f290o != z) {
            this.f290o = z;
            C1967w0 w0Var = this.f283h;
            if (w0Var != null) {
                w0Var.f6474n.mo6079p();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f285j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f293r;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i) / ((float) intrinsicWidth)));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i) / ((float) intrinsicHeight)));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        mo173f();
    }

    public void setItemInvoker(C1838u0.C1840b bVar) {
        this.f286k = bVar;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f292q = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(C0077b bVar) {
        this.f288m = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f284i = charSequence;
        mo173f();
    }
}
