package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0243b1;

public class ListMenuItemView extends LinearLayout implements C0243b1.C0244a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: d */
    public C1967w0 f297d;

    /* renamed from: e */
    public ImageView f298e;

    /* renamed from: f */
    public RadioButton f299f;

    /* renamed from: g */
    public TextView f300g;

    /* renamed from: h */
    public CheckBox f301h;

    /* renamed from: i */
    public TextView f302i;

    /* renamed from: j */
    public ImageView f303j;

    /* renamed from: k */
    public ImageView f304k;

    /* renamed from: l */
    public LinearLayout f305l;

    /* renamed from: m */
    public Drawable f306m;

    /* renamed from: n */
    public int f307n;

    /* renamed from: o */
    public Context f308o;

    /* renamed from: p */
    public boolean f309p;

    /* renamed from: q */
    public Drawable f310q;

    /* renamed from: r */
    public boolean f311r;

    /* renamed from: s */
    public LayoutInflater f312s;

    /* renamed from: t */
    public boolean f313t;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0327c3 s = C0327c3.m1245s(getContext(), attributeSet, C0593e.f2388r, R.attr.listMenuViewStyle, 0);
        this.f306m = s.mo1830g(5);
        this.f307n = s.mo1836m(1, -1);
        this.f309p = s.mo1824a(7, false);
        this.f308o = context;
        this.f310q = s.mo1830g(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.f311r = obtainStyledAttributes.hasValue(0);
        s.f1430b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f312s == null) {
            this.f312s = LayoutInflater.from(getContext());
        }
        return this.f312s;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.f303j;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: a */
    public final void mo193a() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
        this.f301h = checkBox;
        LinearLayout linearLayout = this.f305l;
        if (linearLayout != null) {
            linearLayout.addView(checkBox, -1);
        } else {
            addView(checkBox, -1);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f304k;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f304k.getLayoutParams();
            rect.top = this.f304k.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* renamed from: b */
    public final void mo195b() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
        this.f299f = radioButton;
        LinearLayout linearLayout = this.f305l;
        if (linearLayout != null) {
            linearLayout.addView(radioButton, -1);
        } else {
            addView(radioButton, -1);
        }
    }

    /* renamed from: c */
    public void mo196c(boolean z) {
        String str;
        int i;
        int i2 = (!z || !this.f297d.mo6343m()) ? 8 : 0;
        if (i2 == 0) {
            TextView textView = this.f302i;
            C1967w0 w0Var = this.f297d;
            char e = w0Var.mo6318e();
            if (e == 0) {
                str = "";
            } else {
                Resources resources = w0Var.f6474n.f6076a.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(w0Var.f6474n.f6076a).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i3 = w0Var.f6474n.mo3438n() ? w0Var.f6471k : w0Var.f6469i;
                C1967w0.m5476c(sb, i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                C1967w0.m5476c(sb, i3, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                C1967w0.m5476c(sb, i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                C1967w0.m5476c(sb, i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                C1967w0.m5476c(sb, i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                C1967w0.m5476c(sb, i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                if (e == 8) {
                    i = R.string.abc_menu_delete_shortcut_label;
                } else if (e == 10) {
                    i = R.string.abc_menu_enter_shortcut_label;
                } else if (e != ' ') {
                    sb.append(e);
                    str = sb.toString();
                } else {
                    i = R.string.abc_menu_space_shortcut_label;
                }
                sb.append(resources.getString(i));
                str = sb.toString();
            }
            textView.setText(str);
        }
        if (this.f302i.getVisibility() != i2) {
            this.f302i.setVisibility(i2);
        }
    }

    /* renamed from: d */
    public void mo171d(C1967w0 w0Var, int i) {
        this.f297d = w0Var;
        setVisibility(w0Var.isVisible() ? 0 : 8);
        setTitle(w0Var.f6465e);
        setCheckable(w0Var.isCheckable());
        boolean m = w0Var.mo6343m();
        w0Var.mo6318e();
        mo196c(m);
        setIcon(w0Var.getIcon());
        setEnabled(w0Var.isEnabled());
        setSubMenuArrowVisible(w0Var.hasSubMenu());
        setContentDescription(w0Var.f6477q);
    }

    public C1967w0 getItemData() {
        return this.f297d;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        Drawable drawable = this.f306m;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        setBackground(drawable);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f300g = textView;
        int i = this.f307n;
        if (i != -1) {
            textView.setTextAppearance(this.f308o, i);
        }
        this.f302i = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f303j = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f310q);
        }
        this.f304k = (ImageView) findViewById(R.id.group_divider);
        this.f305l = (LinearLayout) findViewById(R.id.content);
    }

    public void onMeasure(int i, int i2) {
        if (this.f298e != null && this.f309p) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f298e.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.f299f != null || this.f301h != null) {
            if (this.f297d.mo6333h()) {
                if (this.f299f == null) {
                    mo195b();
                }
                compoundButton2 = this.f299f;
                compoundButton = this.f301h;
            } else {
                if (this.f301h == null) {
                    mo193a();
                }
                compoundButton2 = this.f301h;
                compoundButton = this.f299f;
            }
            if (z) {
                compoundButton2.setChecked(this.f297d.isChecked());
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (compoundButton != null && compoundButton.getVisibility() != 8) {
                    compoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.f301h;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.f299f;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f297d.mo6333h()) {
            if (this.f299f == null) {
                mo195b();
            }
            compoundButton = this.f299f;
        } else {
            if (this.f301h == null) {
                mo193a();
            }
            compoundButton = this.f301h;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.f313t = z;
        this.f309p = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.f304k;
        if (imageView != null) {
            imageView.setVisibility((this.f311r || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        Objects.requireNonNull(this.f297d.f6474n);
        boolean z = this.f313t;
        if (z || this.f309p) {
            ImageView imageView = this.f298e;
            if (imageView != null || drawable != null || this.f309p) {
                if (imageView == null) {
                    ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, this, false);
                    this.f298e = imageView2;
                    LinearLayout linearLayout = this.f305l;
                    if (linearLayout != null) {
                        linearLayout.addView(imageView2, 0);
                    } else {
                        addView(imageView2, 0);
                    }
                }
                if (drawable != null || this.f309p) {
                    ImageView imageView3 = this.f298e;
                    if (!z) {
                        drawable = null;
                    }
                    imageView3.setImageDrawable(drawable);
                    if (this.f298e.getVisibility() != 0) {
                        this.f298e.setVisibility(0);
                        return;
                    }
                    return;
                }
                this.f298e.setVisibility(8);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView;
        int i;
        if (charSequence != null) {
            this.f300g.setText(charSequence);
            if (this.f300g.getVisibility() != 0) {
                textView = this.f300g;
                i = 0;
            } else {
                return;
            }
        } else {
            i = 8;
            if (this.f300g.getVisibility() != 8) {
                textView = this.f300g;
            } else {
                return;
            }
        }
        textView.setVisibility(i);
    }
}
