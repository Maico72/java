package androidx.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import p000.C1409p9;

public class ComponentActivity extends C1477q4 implements C1725s9, C0681fa, C1324ob, C0320c {

    /* renamed from: e */
    public final C1785t9 f197e;

    /* renamed from: f */
    public final C1243nb f198f = new C1243nb(this);

    /* renamed from: g */
    public C0615ea f199g;

    /* renamed from: h */
    public final OnBackPressedDispatcher f200h = new OnBackPressedDispatcher(new C0069a());

    /* renamed from: androidx.activity.ComponentActivity$a */
    public class C0069a implements Runnable {
        public C0069a() {
        }

        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$b */
    public static final class C0070b {

        /* renamed from: a */
        public C0615ea f204a;
    }

    public ComponentActivity() {
        C1785t9 t9Var = new C1785t9(this);
        this.f197e = t9Var;
        int i = Build.VERSION.SDK_INT;
        t9Var.mo5201a(new C1491q9() {
            /* renamed from: d */
            public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
                if (aVar == C1409p9.C1410a.ON_STOP) {
                    Window window = ComponentActivity.this.getWindow();
                    View peekDecorView = window != null ? window.peekDecorView() : null;
                    if (peekDecorView != null) {
                        peekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        t9Var.mo5201a(new C1491q9() {
            /* renamed from: d */
            public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
                if (aVar == C1409p9.C1410a.ON_DESTROY && !ComponentActivity.this.isChangingConfigurations()) {
                    ComponentActivity.this.mo153g().mo3304a();
                }
            }
        });
        if (i <= 23) {
            t9Var.mo5201a(new ImmLeaksCleaner(this));
        }
    }

    /* renamed from: a */
    public C1409p9 mo150a() {
        return this.f197e;
    }

    /* renamed from: c */
    public final OnBackPressedDispatcher mo151c() {
        return this.f200h;
    }

    /* renamed from: d */
    public final C1171mb mo152d() {
        return this.f198f.f4259b;
    }

    /* renamed from: g */
    public C0615ea mo153g() {
        if (getApplication() != null) {
            if (this.f199g == null) {
                C0070b bVar = (C0070b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.f199g = bVar.f204a;
                }
                if (this.f199g == null) {
                    this.f199g = new C0615ea();
                }
            }
            return this.f199g;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public void onBackPressed() {
        this.f200h.mo160a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f198f.mo4823a(bundle);
        C0020aa.m68b(this);
    }

    public final Object onRetainNonConfigurationInstance() {
        C0070b bVar;
        C0615ea eaVar = this.f199g;
        if (eaVar == null && (bVar = (C0070b) getLastNonConfigurationInstance()) != null) {
            eaVar = bVar.f204a;
        }
        if (eaVar == null) {
            return null;
        }
        C0070b bVar2 = new C0070b();
        bVar2.f204a = eaVar;
        return bVar2;
    }

    public void onSaveInstanceState(Bundle bundle) {
        C1785t9 t9Var = this.f197e;
        if (t9Var instanceof C1785t9) {
            t9Var.mo5980f(C1409p9.C1411b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f198f.mo4824b(bundle);
    }
}
