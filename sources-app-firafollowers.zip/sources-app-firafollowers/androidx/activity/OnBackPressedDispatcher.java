package androidx.activity;

import java.util.ArrayDeque;
import java.util.Iterator;
import p000.C1409p9;

public final class OnBackPressedDispatcher {

    /* renamed from: a */
    public final Runnable f210a;

    /* renamed from: b */
    public final ArrayDeque<C0234b> f211b = new ArrayDeque<>();

    public class LifecycleOnBackPressedCancellable implements C1491q9, C0000a {

        /* renamed from: a */
        public final C1409p9 f212a;

        /* renamed from: b */
        public final C0234b f213b;

        /* renamed from: c */
        public C0000a f214c;

        public LifecycleOnBackPressedCancellable(C1409p9 p9Var, C0234b bVar) {
            this.f212a = p9Var;
            this.f213b = bVar;
            p9Var.mo5201a(this);
        }

        public void cancel() {
            ((C1785t9) this.f212a).f5890a.mo4711d(this);
            this.f213b.f1161b.remove(this);
            C0000a aVar = this.f214c;
            if (aVar != null) {
                aVar.cancel();
                this.f214c = null;
            }
        }

        /* renamed from: d */
        public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
            if (aVar == C1409p9.C1410a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                C0234b bVar = this.f213b;
                onBackPressedDispatcher.f211b.add(bVar);
                C0071a aVar2 = new C0071a(bVar);
                bVar.f1161b.add(aVar2);
                this.f214c = aVar2;
            } else if (aVar == C1409p9.C1410a.ON_STOP) {
                C0000a aVar3 = this.f214c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            } else if (aVar == C1409p9.C1410a.ON_DESTROY) {
                cancel();
            }
        }
    }

    /* renamed from: androidx.activity.OnBackPressedDispatcher$a */
    public class C0071a implements C0000a {

        /* renamed from: a */
        public final C0234b f216a;

        public C0071a(C0234b bVar) {
            this.f216a = bVar;
        }

        public void cancel() {
            OnBackPressedDispatcher.this.f211b.remove(this.f216a);
            this.f216a.f1161b.remove(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f210a = runnable;
    }

    /* renamed from: a */
    public void mo160a() {
        Iterator<C0234b> descendingIterator = this.f211b.descendingIterator();
        while (descendingIterator.hasNext()) {
            C0234b next = descendingIterator.next();
            if (next.f1160a) {
                next.mo1490a();
                return;
            }
        }
        Runnable runnable = this.f210a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
