package androidx.swiperefreshlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.AbsListView;
import android.widget.ListView;
import java.util.Objects;
import p000.C1791tb;

public class SwipeRefreshLayout extends ViewGroup implements C1846u6, C1780t6, C1486q6, C1903v6, C1659r6 {

    /* renamed from: O */
    public static final String f1003O = SwipeRefreshLayout.class.getSimpleName();

    /* renamed from: P */
    public static final int[] f1004P = {16842766};

    /* renamed from: A */
    public int f1005A;

    /* renamed from: B */
    public int f1006B;

    /* renamed from: C */
    public C1791tb f1007C;

    /* renamed from: D */
    public Animation f1008D;

    /* renamed from: E */
    public Animation f1009E;

    /* renamed from: F */
    public Animation f1010F;

    /* renamed from: G */
    public Animation f1011G;

    /* renamed from: H */
    public boolean f1012H;

    /* renamed from: I */
    public int f1013I;

    /* renamed from: J */
    public C0197g f1014J;

    /* renamed from: K */
    public boolean f1015K;

    /* renamed from: L */
    public Animation.AnimationListener f1016L = new C0191a();

    /* renamed from: M */
    public final Animation f1017M = new C0195e();

    /* renamed from: N */
    public final Animation f1018N = new C0196f();

    /* renamed from: d */
    public View f1019d;

    /* renamed from: e */
    public C0198h f1020e;

    /* renamed from: f */
    public boolean f1021f = false;

    /* renamed from: g */
    public int f1022g;

    /* renamed from: h */
    public float f1023h = -1.0f;

    /* renamed from: i */
    public float f1024i;

    /* renamed from: j */
    public final C1982w6 f1025j;

    /* renamed from: k */
    public final C1720s6 f1026k;

    /* renamed from: l */
    public final int[] f1027l = new int[2];

    /* renamed from: m */
    public final int[] f1028m = new int[2];

    /* renamed from: n */
    public final int[] f1029n = new int[2];

    /* renamed from: o */
    public boolean f1030o;

    /* renamed from: p */
    public int f1031p;

    /* renamed from: q */
    public int f1032q;

    /* renamed from: r */
    public float f1033r;

    /* renamed from: s */
    public float f1034s;

    /* renamed from: t */
    public boolean f1035t;

    /* renamed from: u */
    public int f1036u = -1;

    /* renamed from: v */
    public final DecelerateInterpolator f1037v;

    /* renamed from: w */
    public C1601qb f1038w;

    /* renamed from: x */
    public int f1039x = -1;

    /* renamed from: y */
    public int f1040y;

    /* renamed from: z */
    public int f1041z;

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$a */
    public class C0191a implements Animation.AnimationListener {
        public C0191a() {
        }

        public void onAnimationEnd(Animation animation) {
            C0198h hVar;
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (swipeRefreshLayout.f1021f) {
                swipeRefreshLayout.f1007C.setAlpha(255);
                SwipeRefreshLayout.this.f1007C.start();
                SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
                if (swipeRefreshLayout2.f1012H && (hVar = swipeRefreshLayout2.f1020e) != null) {
                    hVar.mo1349a();
                }
                SwipeRefreshLayout swipeRefreshLayout3 = SwipeRefreshLayout.this;
                swipeRefreshLayout3.f1032q = swipeRefreshLayout3.f1038w.getTop();
                return;
            }
            swipeRefreshLayout.mo1307l();
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$b */
    public class C0192b extends Animation {
        public C0192b() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(1.0f - f);
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$c */
    public class C0193c extends Animation {

        /* renamed from: d */
        public final /* synthetic */ int f1044d;

        /* renamed from: e */
        public final /* synthetic */ int f1045e;

        public C0193c(int i, int i2) {
            this.f1044d = i;
            this.f1045e = i2;
        }

        public void applyTransformation(float f, Transformation transformation) {
            C1791tb tbVar = SwipeRefreshLayout.this.f1007C;
            int i = this.f1044d;
            tbVar.setAlpha((int) ((((float) (this.f1045e - i)) * f) + ((float) i)));
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$d */
    public class C0194d implements Animation.AnimationListener {
        public C0194d() {
        }

        public void onAnimationEnd(Animation animation) {
            Objects.requireNonNull(SwipeRefreshLayout.this);
            SwipeRefreshLayout.this.mo1319s((Animation.AnimationListener) null);
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$e */
    public class C0195e extends Animation {
        public C0195e() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            Objects.requireNonNull(SwipeRefreshLayout.this);
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            int abs = swipeRefreshLayout.f1005A - Math.abs(swipeRefreshLayout.f1041z);
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            int i = swipeRefreshLayout2.f1040y;
            SwipeRefreshLayout.this.setTargetOffsetTopAndBottom((i + ((int) (((float) (abs - i)) * f))) - swipeRefreshLayout2.f1038w.getTop());
            C1791tb tbVar = SwipeRefreshLayout.this.f1007C;
            float f2 = 1.0f - f;
            C1791tb.C1792a aVar = tbVar.f5911d;
            if (f2 != aVar.f5932p) {
                aVar.f5932p = f2;
            }
            tbVar.invalidateSelf();
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$f */
    public class C0196f extends Animation {
        public C0196f() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.mo1299g(f);
        }
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$g */
    public interface C0197g {
        /* renamed from: a */
        boolean mo1348a(SwipeRefreshLayout swipeRefreshLayout, View view);
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$h */
    public interface C0198h {
        /* renamed from: a */
        void mo1349a();
    }

    /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$i */
    public static class C0199i extends View.BaseSavedState {
        public static final Parcelable.Creator<C0199i> CREATOR = new C0200a();

        /* renamed from: d */
        public final boolean f1050d;

        /* renamed from: androidx.swiperefreshlayout.widget.SwipeRefreshLayout$i$a */
        public class C0200a implements Parcelable.Creator<C0199i> {
            public Object createFromParcel(Parcel parcel) {
                return new C0199i(parcel);
            }

            public Object[] newArray(int i) {
                return new C0199i[i];
            }
        }

        public C0199i(Parcel parcel) {
            super(parcel);
            this.f1050d = parcel.readByte() != 0;
        }

        public C0199i(Parcelable parcelable, boolean z) {
            super(parcelable);
            this.f1050d = z;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.f1050d ? (byte) 1 : 0);
        }
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1022g = ViewConfiguration.get(context).getScaledTouchSlop();
        this.f1031p = getResources().getInteger(17694721);
        setWillNotDraw(false);
        this.f1037v = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.f1013I = (int) (displayMetrics.density * 40.0f);
        this.f1038w = new C1601qb(getContext());
        C1791tb tbVar = new C1791tb(getContext());
        this.f1007C = tbVar;
        tbVar.mo5992c(1);
        this.f1038w.setImageDrawable(this.f1007C);
        this.f1038w.setVisibility(8);
        addView(this.f1038w);
        setChildrenDrawingOrderEnabled(true);
        int i = (int) (displayMetrics.density * 64.0f);
        this.f1005A = i;
        this.f1023h = (float) i;
        this.f1025j = new C1982w6();
        this.f1026k = new C1720s6(this);
        setNestedScrollingEnabled(true);
        int i2 = -this.f1013I;
        this.f1032q = i2;
        this.f1041z = i2;
        mo1299g(1.0f);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1004P);
        setEnabled(obtainStyledAttributes.getBoolean(0, true));
        obtainStyledAttributes.recycle();
    }

    private void setColorViewAlpha(int i) {
        this.f1038w.getBackground().setAlpha(i);
        C1791tb tbVar = this.f1007C;
        tbVar.f5911d.f5936t = i;
        tbVar.invalidateSelf();
    }

    /* renamed from: a */
    public void mo704a(int i) {
        if (i == 0) {
            stopNestedScroll();
        }
    }

    /* renamed from: b */
    public boolean mo1290b() {
        C0197g gVar = this.f1014J;
        if (gVar != null) {
            return gVar.mo1348a(this, this.f1019d);
        }
        View view = this.f1019d;
        if (view instanceof ListView) {
            return ((ListView) view).canScrollList(-1);
        }
        return view.canScrollVertically(-1);
    }

    /* renamed from: c */
    public final void mo1291c() {
        if (this.f1019d == null) {
            for (int i = 0; i < getChildCount(); i++) {
                View childAt = getChildAt(i);
                if (!childAt.equals(this.f1038w)) {
                    this.f1019d = childAt;
                    return;
                }
            }
        }
    }

    /* renamed from: d */
    public final void mo1292d(float f) {
        if (f > this.f1023h) {
            mo1315p(true, true);
            return;
        }
        this.f1021f = false;
        C1791tb tbVar = this.f1007C;
        C1791tb.C1792a aVar = tbVar.f5911d;
        aVar.f5921e = 0.0f;
        aVar.f5922f = 0.0f;
        tbVar.invalidateSelf();
        C0194d dVar = new C0194d();
        this.f1040y = this.f1032q;
        this.f1018N.reset();
        this.f1018N.setDuration(200);
        this.f1018N.setInterpolator(this.f1037v);
        C1601qb qbVar = this.f1038w;
        qbVar.f5291d = dVar;
        qbVar.clearAnimation();
        this.f1038w.startAnimation(this.f1018N);
        C1791tb tbVar2 = this.f1007C;
        C1791tb.C1792a aVar2 = tbVar2.f5911d;
        if (aVar2.f5930n) {
            aVar2.f5930n = false;
        }
        tbVar2.invalidateSelf();
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f1026k.mo5809a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f1026k.mo5810b(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.f1026k.mo5811c(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f1026k.mo5813e(i, i2, i3, i4, iArr);
    }

    /* renamed from: e */
    public final boolean mo1297e(Animation animation) {
        return animation != null && animation.hasStarted() && !animation.hasEnded();
    }

    /* renamed from: f */
    public final void mo1298f(float f) {
        C1791tb tbVar = this.f1007C;
        C1791tb.C1792a aVar = tbVar.f5911d;
        if (!aVar.f5930n) {
            aVar.f5930n = true;
        }
        tbVar.invalidateSelf();
        float min = Math.min(1.0f, Math.abs(f / this.f1023h));
        double d = (double) min;
        Double.isNaN(d);
        Double.isNaN(d);
        float max = (((float) Math.max(d - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float abs = Math.abs(f) - this.f1023h;
        int i = this.f1006B;
        if (i <= 0) {
            i = this.f1005A;
        }
        float f2 = (float) i;
        double max2 = (double) (Math.max(0.0f, Math.min(abs, f2 * 2.0f) / f2) / 4.0f);
        double pow = Math.pow(max2, 2.0d);
        Double.isNaN(max2);
        Double.isNaN(max2);
        float f3 = ((float) (max2 - pow)) * 2.0f;
        int i2 = this.f1041z + ((int) ((f2 * min) + (f2 * f3 * 2.0f)));
        if (this.f1038w.getVisibility() != 0) {
            this.f1038w.setVisibility(0);
        }
        this.f1038w.setScaleX(1.0f);
        this.f1038w.setScaleY(1.0f);
        if (f < this.f1023h) {
            if (this.f1007C.f5911d.f5936t > 76 && !mo1297e(this.f1010F)) {
                this.f1010F = mo1316q(this.f1007C.f5911d.f5936t, 76);
            }
        } else if (this.f1007C.f5911d.f5936t < 255 && !mo1297e(this.f1011G)) {
            this.f1011G = mo1316q(this.f1007C.f5911d.f5936t, 255);
        }
        C1791tb tbVar2 = this.f1007C;
        float min2 = Math.min(0.8f, max * 0.8f);
        C1791tb.C1792a aVar2 = tbVar2.f5911d;
        aVar2.f5921e = 0.0f;
        aVar2.f5922f = min2;
        tbVar2.invalidateSelf();
        C1791tb tbVar3 = this.f1007C;
        float min3 = Math.min(1.0f, max);
        C1791tb.C1792a aVar3 = tbVar3.f5911d;
        if (min3 != aVar3.f5932p) {
            aVar3.f5932p = min3;
        }
        tbVar3.invalidateSelf();
        C1791tb tbVar4 = this.f1007C;
        tbVar4.f5911d.f5923g = ((f3 * 2.0f) + ((max * 0.4f) - 16.0f)) * 0.5f;
        tbVar4.invalidateSelf();
        setTargetOffsetTopAndBottom(i2 - this.f1032q);
    }

    /* renamed from: g */
    public void mo1299g(float f) {
        int i = this.f1040y;
        setTargetOffsetTopAndBottom((i + ((int) (((float) (this.f1041z - i)) * f))) - this.f1038w.getTop());
    }

    public int getChildDrawingOrder(int i, int i2) {
        int i3 = this.f1039x;
        return i3 < 0 ? i2 : i2 == i + -1 ? i3 : i2 >= i3 ? i2 + 1 : i2;
    }

    public int getNestedScrollAxes() {
        return this.f1025j.mo6429a();
    }

    public int getProgressCircleDiameter() {
        return this.f1013I;
    }

    public int getProgressViewEndOffset() {
        return this.f1005A;
    }

    public int getProgressViewStartOffset() {
        return this.f1041z;
    }

    /* renamed from: h */
    public void mo262h(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    public boolean hasNestedScrollingParent() {
        return this.f1026k.mo5816h(0);
    }

    /* renamed from: i */
    public void mo263i(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    public boolean isNestedScrollingEnabled() {
        return this.f1026k.f5679d;
    }

    /* renamed from: j */
    public void mo264j(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* renamed from: k */
    public final void mo1306k(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1036u) {
            this.f1036u = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
        }
    }

    /* renamed from: l */
    public void mo1307l() {
        this.f1038w.clearAnimation();
        this.f1007C.stop();
        this.f1038w.setVisibility(8);
        setColorViewAlpha(255);
        setTargetOffsetTopAndBottom(this.f1041z - this.f1032q);
        this.f1032q = this.f1038w.getTop();
    }

    /* renamed from: m */
    public void mo267m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 == 0) {
            int i6 = iArr[1];
            int[] iArr2 = this.f1028m;
            if (i5 == 0) {
                this.f1026k.mo5812d(i, i2, i3, i4, iArr2, i5, iArr);
            }
            int i7 = i4 - (iArr[1] - i6);
            int i8 = i7 == 0 ? i4 + this.f1028m[1] : i7;
            if (i8 < 0 && !mo1290b()) {
                float abs = this.f1024i + ((float) Math.abs(i8));
                this.f1024i = abs;
                mo1298f(abs);
                iArr[1] = iArr[1] + i7;
            }
        }
    }

    /* renamed from: n */
    public void mo268n(View view, int i, int i2, int i3, int i4, int i5) {
        mo267m(view, i, i2, i3, i4, i5, this.f1029n);
    }

    /* renamed from: o */
    public boolean mo269o(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            return onStartNestedScroll(view, view2, i);
        }
        return false;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo1307l();
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        mo1291c();
        int actionMasked = motionEvent.getActionMasked();
        if (!isEnabled() || mo1290b() || this.f1021f || this.f1030o) {
            return false;
        }
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    int i = this.f1036u;
                    if (i == -1) {
                        Log.e(f1003O, "Got ACTION_MOVE event but don't have an active pointer id.");
                        return false;
                    }
                    int findPointerIndex = motionEvent.findPointerIndex(i);
                    if (findPointerIndex < 0) {
                        return false;
                    }
                    mo1317r(motionEvent.getY(findPointerIndex));
                } else if (actionMasked != 3) {
                    if (actionMasked == 6) {
                        mo1306k(motionEvent);
                    }
                }
            }
            this.f1035t = false;
            this.f1036u = -1;
        } else {
            setTargetOffsetTopAndBottom(this.f1041z - this.f1038w.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.f1036u = pointerId;
            this.f1035t = false;
            int findPointerIndex2 = motionEvent.findPointerIndex(pointerId);
            if (findPointerIndex2 < 0) {
                return false;
            }
            this.f1034s = motionEvent.getY(findPointerIndex2);
        }
        return this.f1035t;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() != 0) {
            if (this.f1019d == null) {
                mo1291c();
            }
            View view = this.f1019d;
            if (view != null) {
                int paddingLeft = getPaddingLeft();
                int paddingTop = getPaddingTop();
                view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
                int measuredWidth2 = this.f1038w.getMeasuredWidth();
                int measuredHeight2 = this.f1038w.getMeasuredHeight();
                int i5 = measuredWidth / 2;
                int i6 = measuredWidth2 / 2;
                int i7 = this.f1032q;
                this.f1038w.layout(i5 - i6, i7, i5 + i6, measuredHeight2 + i7);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1019d == null) {
            mo1291c();
        }
        View view = this.f1019d;
        if (view != null) {
            view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
            this.f1038w.measure(View.MeasureSpec.makeMeasureSpec(this.f1013I, 1073741824), View.MeasureSpec.makeMeasureSpec(this.f1013I, 1073741824));
            this.f1039x = -1;
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                if (getChildAt(i3) == this.f1038w) {
                    this.f1039x = i3;
                    return;
                }
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        return dispatchNestedFling(f, f2, z);
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        if (i2 > 0) {
            float f = this.f1024i;
            if (f > 0.0f) {
                float f2 = (float) i2;
                if (f2 > f) {
                    iArr[1] = (int) f;
                    this.f1024i = 0.0f;
                } else {
                    this.f1024i = f - f2;
                    iArr[1] = i2;
                }
                mo1298f(this.f1024i);
            }
        }
        int[] iArr2 = this.f1027l;
        if (dispatchNestedPreScroll(i - iArr[0], i2 - iArr[1], iArr2, (int[]) null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo267m(view, i, i2, i3, i4, 0, this.f1029n);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f1025j.f6579a = i;
        startNestedScroll(i & 2);
        this.f1024i = 0.0f;
        this.f1030o = true;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        C0199i iVar = (C0199i) parcelable;
        super.onRestoreInstanceState(iVar.getSuperState());
        setRefreshing(iVar.f1050d);
    }

    public Parcelable onSaveInstanceState() {
        return new C0199i(super.onSaveInstanceState(), this.f1021f);
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return isEnabled() && !this.f1021f && (i & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.f1025j.mo6430b(0);
        this.f1030o = false;
        float f = this.f1024i;
        if (f > 0.0f) {
            mo1292d(f);
            this.f1024i = 0.0f;
        }
        stopNestedScroll();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        String str = f1003O;
        int actionMasked = motionEvent.getActionMasked();
        if (!isEnabled() || mo1290b() || this.f1021f || this.f1030o) {
            return false;
        }
        if (actionMasked == 0) {
            this.f1036u = motionEvent.getPointerId(0);
            this.f1035t = false;
        } else if (actionMasked == 1) {
            int findPointerIndex = motionEvent.findPointerIndex(this.f1036u);
            if (findPointerIndex < 0) {
                Log.e(str, "Got ACTION_UP event but don't have an active pointer id.");
                return false;
            }
            if (this.f1035t) {
                this.f1035t = false;
                mo1292d((motionEvent.getY(findPointerIndex) - this.f1033r) * 0.5f);
            }
            this.f1036u = -1;
            return false;
        } else if (actionMasked == 2) {
            int findPointerIndex2 = motionEvent.findPointerIndex(this.f1036u);
            if (findPointerIndex2 < 0) {
                Log.e(str, "Got ACTION_MOVE event but have an invalid active pointer id.");
                return false;
            }
            float y = motionEvent.getY(findPointerIndex2);
            mo1317r(y);
            if (this.f1035t) {
                float f = (y - this.f1033r) * 0.5f;
                if (f <= 0.0f) {
                    return false;
                }
                getParent().requestDisallowInterceptTouchEvent(true);
                mo1298f(f);
            }
        } else if (actionMasked == 3) {
            return false;
        } else {
            if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                if (actionIndex < 0) {
                    Log.e(str, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                    return false;
                }
                this.f1036u = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                mo1306k(motionEvent);
            }
        }
        return true;
    }

    /* renamed from: p */
    public final void mo1315p(boolean z, boolean z2) {
        if (this.f1021f != z) {
            this.f1012H = z2;
            mo1291c();
            this.f1021f = z;
            if (z) {
                int i = this.f1032q;
                Animation.AnimationListener animationListener = this.f1016L;
                this.f1040y = i;
                this.f1017M.reset();
                this.f1017M.setDuration(200);
                this.f1017M.setInterpolator(this.f1037v);
                if (animationListener != null) {
                    this.f1038w.f5291d = animationListener;
                }
                this.f1038w.clearAnimation();
                this.f1038w.startAnimation(this.f1017M);
                return;
            }
            mo1319s(this.f1016L);
        }
    }

    /* renamed from: q */
    public final Animation mo1316q(int i, int i2) {
        C0193c cVar = new C0193c(i, i2);
        cVar.setDuration(300);
        C1601qb qbVar = this.f1038w;
        qbVar.f5291d = null;
        qbVar.clearAnimation();
        this.f1038w.startAnimation(cVar);
        return cVar;
    }

    /* renamed from: r */
    public final void mo1317r(float f) {
        float f2 = this.f1034s;
        int i = this.f1022g;
        if (f - f2 > ((float) i) && !this.f1035t) {
            this.f1033r = f2 + ((float) i);
            this.f1035t = true;
            this.f1007C.setAlpha(76);
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        ViewParent parent;
        View view;
        if ((Build.VERSION.SDK_INT >= 21 || !(this.f1019d instanceof AbsListView)) && ((view = this.f1019d) == null || C0010a7.m37j(view))) {
            super.requestDisallowInterceptTouchEvent(z);
        } else if (!this.f1015K && (parent = getParent()) != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    /* renamed from: s */
    public void mo1319s(Animation.AnimationListener animationListener) {
        C0192b bVar = new C0192b();
        this.f1009E = bVar;
        bVar.setDuration(150);
        C1601qb qbVar = this.f1038w;
        qbVar.f5291d = animationListener;
        qbVar.clearAnimation();
        this.f1038w.startAnimation(this.f1009E);
    }

    public void setAnimationProgress(float f) {
        this.f1038w.setScaleX(f);
        this.f1038w.setScaleY(f);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        mo1291c();
        C1791tb tbVar = this.f1007C;
        C1791tb.C1792a aVar = tbVar.f5911d;
        aVar.f5925i = iArr;
        aVar.mo6002a(0);
        tbVar.f5911d.mo6002a(0);
        tbVar.invalidateSelf();
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i = 0; i < iArr.length; i++) {
            iArr2[i] = C1901v4.m5333b(context, iArr[i]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i) {
        this.f1023h = (float) i;
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (!z) {
            mo1307l();
        }
    }

    @Deprecated
    public void setLegacyRequestDisallowInterceptTouchEventEnabled(boolean z) {
        this.f1015K = z;
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f1026k.mo5817i(z);
    }

    public void setOnChildScrollUpCallback(C0197g gVar) {
        this.f1014J = gVar;
    }

    public void setOnRefreshListener(C0198h hVar) {
        this.f1020e = hVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i) {
        setProgressBackgroundColorSchemeResource(i);
    }

    public void setProgressBackgroundColorSchemeColor(int i) {
        this.f1038w.setBackgroundColor(i);
    }

    public void setProgressBackgroundColorSchemeResource(int i) {
        setProgressBackgroundColorSchemeColor(C1901v4.m5333b(getContext(), i));
    }

    public void setRefreshing(boolean z) {
        if (!z || this.f1021f == z) {
            mo1315p(z, false);
            return;
        }
        this.f1021f = z;
        setTargetOffsetTopAndBottom((this.f1005A + this.f1041z) - this.f1032q);
        this.f1012H = false;
        Animation.AnimationListener animationListener = this.f1016L;
        this.f1038w.setVisibility(0);
        this.f1007C.setAlpha(255);
        C1852ub ubVar = new C1852ub(this);
        this.f1008D = ubVar;
        ubVar.setDuration((long) this.f1031p);
        if (animationListener != null) {
            this.f1038w.f5291d = animationListener;
        }
        this.f1038w.clearAnimation();
        this.f1038w.startAnimation(this.f1008D);
    }

    public void setSize(int i) {
        if (i == 0 || i == 1) {
            this.f1013I = (int) (getResources().getDisplayMetrics().density * (i == 0 ? 56.0f : 40.0f));
            this.f1038w.setImageDrawable((Drawable) null);
            this.f1007C.mo5992c(i);
            this.f1038w.setImageDrawable(this.f1007C);
        }
    }

    public void setSlingshotDistance(int i) {
        this.f1006B = i;
    }

    public void setTargetOffsetTopAndBottom(int i) {
        this.f1038w.bringToFront();
        C0010a7.m39l(this.f1038w, i);
        this.f1032q = this.f1038w.getTop();
    }

    public boolean startNestedScroll(int i) {
        return this.f1026k.mo5818j(i, 0);
    }

    public void stopNestedScroll() {
        this.f1026k.mo5819k(0);
    }
}
