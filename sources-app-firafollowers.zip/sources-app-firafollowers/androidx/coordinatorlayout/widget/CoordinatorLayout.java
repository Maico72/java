package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import com.roughike.bottombar.C0446R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

public class CoordinatorLayout extends ViewGroup implements C1780t6 {

    /* renamed from: A */
    public static final C0940j6<Rect> f548A = new C1063l6(12);

    /* renamed from: w */
    public static final String f549w;

    /* renamed from: x */
    public static final Class<?>[] f550x = {Context.class, AttributeSet.class};

    /* renamed from: y */
    public static final ThreadLocal<Map<String, Constructor<C0120c>>> f551y = new ThreadLocal<>();

    /* renamed from: z */
    public static final Comparator<View> f552z;

    /* renamed from: d */
    public final List<View> f553d = new ArrayList();

    /* renamed from: e */
    public final C0807h4<View> f554e = new C0807h4<>();

    /* renamed from: f */
    public final List<View> f555f = new ArrayList();

    /* renamed from: g */
    public final List<View> f556g = new ArrayList();

    /* renamed from: h */
    public final int[] f557h = new int[2];

    /* renamed from: i */
    public Paint f558i;

    /* renamed from: j */
    public boolean f559j;

    /* renamed from: k */
    public boolean f560k;

    /* renamed from: l */
    public int[] f561l;

    /* renamed from: m */
    public View f562m;

    /* renamed from: n */
    public View f563n;

    /* renamed from: o */
    public C0124g f564o;

    /* renamed from: p */
    public boolean f565p;

    /* renamed from: q */
    public C0943j7 f566q;

    /* renamed from: r */
    public boolean f567r;

    /* renamed from: s */
    public Drawable f568s;

    /* renamed from: t */
    public ViewGroup.OnHierarchyChangeListener f569t;

    /* renamed from: u */
    public C2052x6 f570u;

    /* renamed from: v */
    public final C1982w6 f571v = new C1982w6();

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$a */
    public class C0118a implements C2052x6 {
        public C0118a() {
        }

        /* renamed from: a */
        public C0943j7 mo650a(View view, C0943j7 j7Var) {
            C0120c cVar;
            CoordinatorLayout coordinatorLayout = CoordinatorLayout.this;
            if (!Objects.equals(coordinatorLayout.f566q, j7Var)) {
                coordinatorLayout.f566q = j7Var;
                boolean z = true;
                boolean z2 = j7Var.mo4128d() > 0;
                coordinatorLayout.f567r = z2;
                if (z2 || coordinatorLayout.getBackground() != null) {
                    z = false;
                }
                coordinatorLayout.setWillNotDraw(z);
                if (!j7Var.mo4131g()) {
                    int childCount = coordinatorLayout.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        View childAt = coordinatorLayout.getChildAt(i);
                        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                        if (childAt.getFitsSystemWindows() && (cVar = ((C0123f) childAt.getLayoutParams()).f574a) != null) {
                            j7Var = cVar.onApplyWindowInsets(coordinatorLayout, childAt, j7Var);
                            if (j7Var.mo4131g()) {
                                break;
                            }
                        }
                    }
                }
                coordinatorLayout.requestLayout();
            }
            return j7Var;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$b */
    public interface C0119b {
        C0120c getBehavior();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$c */
    public static abstract class C0120c<V extends View> {
        public C0120c() {
        }

        public C0120c(Context context, AttributeSet attributeSet) {
        }

        public static Object getTag(View view) {
            return ((C0123f) view.getLayoutParams()).f591r;
        }

        public static void setTag(View view, Object obj) {
            ((C0123f) view.getLayoutParams()).f591r = obj;
        }

        public boolean blocksInteractionBelow(CoordinatorLayout coordinatorLayout, V v) {
            return getScrimOpacity(coordinatorLayout, v) > 0.0f;
        }

        public boolean getInsetDodgeRect(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }

        public int getScrimColor(CoordinatorLayout coordinatorLayout, V v) {
            return -16777216;
        }

        public float getScrimOpacity(CoordinatorLayout coordinatorLayout, V v) {
            return 0.0f;
        }

        public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public C0943j7 onApplyWindowInsets(CoordinatorLayout coordinatorLayout, V v, C0943j7 j7Var) {
            return j7Var;
        }

        public void onAttachedToLayoutParams(C0123f fVar) {
        }

        public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public void onDependentViewRemoved(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public void onDetachedFromLayoutParams() {
        }

        public boolean onInterceptTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, V v, int i) {
            return false;
        }

        public boolean onMeasureChild(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
            return false;
        }

        public boolean onNestedFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, boolean z) {
            return false;
        }

        public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        @Deprecated
        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr) {
        }

        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
            if (i3 == 0) {
                onNestedPreScroll(coordinatorLayout, v, view, i, i2, iArr);
            }
        }

        @Deprecated
        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        }

        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5) {
            if (i5 == 0) {
                onNestedScroll(coordinatorLayout, v, view, i, i2, i3, i4);
            }
        }

        @Deprecated
        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        }

        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                onNestedScrollAccepted(coordinatorLayout, v, view, view2, i);
            }
        }

        public boolean onRequestChildRectangleOnScreen(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
            return false;
        }

        public void onRestoreInstanceState(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, V v) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
            return false;
        }

        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                return onStartNestedScroll(coordinatorLayout, v, view, view2, i);
            }
            return false;
        }

        @Deprecated
        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
            if (i == 0) {
                onStopNestedScroll(coordinatorLayout, v, view);
            }
        }

        public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }
    }

    @Deprecated
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$d */
    public @interface C0121d {
        Class<? extends C0120c> value();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$e */
    public class C0122e implements ViewGroup.OnHierarchyChangeListener {
        public C0122e() {
        }

        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f569t;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.mo632r(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f569t;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$f */
    public static class C0123f extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public C0120c f574a;

        /* renamed from: b */
        public boolean f575b = false;

        /* renamed from: c */
        public int f576c = 0;

        /* renamed from: d */
        public int f577d = 0;

        /* renamed from: e */
        public int f578e = -1;

        /* renamed from: f */
        public int f579f = -1;

        /* renamed from: g */
        public int f580g = 0;

        /* renamed from: h */
        public int f581h = 0;

        /* renamed from: i */
        public int f582i;

        /* renamed from: j */
        public int f583j;

        /* renamed from: k */
        public View f584k;

        /* renamed from: l */
        public View f585l;

        /* renamed from: m */
        public boolean f586m;

        /* renamed from: n */
        public boolean f587n;

        /* renamed from: o */
        public boolean f588o;

        /* renamed from: p */
        public boolean f589p;

        /* renamed from: q */
        public final Rect f590q = new Rect();

        /* renamed from: r */
        public Object f591r;

        public C0123f(int i, int i2) {
            super(i, i2);
        }

        public C0123f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            C0120c cVar;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0733g4.f2830b);
            this.f576c = obtainStyledAttributes.getInteger(0, 0);
            this.f579f = obtainStyledAttributes.getResourceId(1, -1);
            this.f577d = obtainStyledAttributes.getInteger(2, 0);
            this.f578e = obtainStyledAttributes.getInteger(6, -1);
            this.f580g = obtainStyledAttributes.getInt(5, 0);
            this.f581h = obtainStyledAttributes.getInt(4, 0);
            boolean hasValue = obtainStyledAttributes.hasValue(3);
            this.f575b = hasValue;
            if (hasValue) {
                String string = obtainStyledAttributes.getString(3);
                String str = CoordinatorLayout.f549w;
                if (TextUtils.isEmpty(string)) {
                    cVar = null;
                } else {
                    if (string.startsWith(".")) {
                        string = context.getPackageName() + string;
                    } else if (string.indexOf(46) < 0) {
                        String str2 = CoordinatorLayout.f549w;
                        if (!TextUtils.isEmpty(str2)) {
                            string = str2 + '.' + string;
                        }
                    }
                    try {
                        ThreadLocal<Map<String, Constructor<C0120c>>> threadLocal = CoordinatorLayout.f551y;
                        Map map = threadLocal.get();
                        if (map == null) {
                            map = new HashMap();
                            threadLocal.set(map);
                        }
                        Constructor<?> constructor = (Constructor) map.get(string);
                        if (constructor == null) {
                            constructor = context.getClassLoader().loadClass(string).getConstructor(CoordinatorLayout.f550x);
                            constructor.setAccessible(true);
                            map.put(string, constructor);
                        }
                        cVar = (C0120c) constructor.newInstance(new Object[]{context, attributeSet});
                    } catch (Exception e) {
                        throw new RuntimeException(C1012kd.m3202k("Could not inflate Behavior subclass ", string), e);
                    }
                }
                this.f574a = cVar;
            }
            obtainStyledAttributes.recycle();
            C0120c cVar2 = this.f574a;
            if (cVar2 != null) {
                cVar2.onAttachedToLayoutParams(this);
            }
        }

        public C0123f(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0123f(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0123f(C0123f fVar) {
            super(fVar);
        }

        /* renamed from: a */
        public boolean mo683a(int i) {
            if (i == 0) {
                return this.f587n;
            }
            if (i != 1) {
                return false;
            }
            return this.f588o;
        }

        /* renamed from: b */
        public void mo684b(C0120c cVar) {
            C0120c cVar2 = this.f574a;
            if (cVar2 != cVar) {
                if (cVar2 != null) {
                    cVar2.onDetachedFromLayoutParams();
                }
                this.f574a = cVar;
                this.f591r = null;
                this.f575b = true;
                if (cVar != null) {
                    cVar.onAttachedToLayoutParams(this);
                }
            }
        }

        /* renamed from: c */
        public void mo685c(int i, boolean z) {
            if (i == 0) {
                this.f587n = z;
            } else if (i == 1) {
                this.f588o = z;
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$g */
    public class C0124g implements ViewTreeObserver.OnPreDrawListener {
        public C0124g() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.mo632r(0);
            return true;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h */
    public static class C0125h extends C0015a8 {
        public static final Parcelable.Creator<C0125h> CREATOR = new C0126a();

        /* renamed from: f */
        public SparseArray<Parcelable> f593f;

        /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h$a */
        public static class C0126a implements Parcelable.ClassLoaderCreator<C0125h> {
            public Object createFromParcel(Parcel parcel) {
                return new C0125h(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0125h[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0125h(parcel, classLoader);
            }
        }

        public C0125h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f593f = new SparseArray<>(readInt);
            for (int i = 0; i < readInt; i++) {
                this.f593f.append(iArr[i], readParcelableArray[i]);
            }
        }

        public C0125h(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            SparseArray<Parcelable> sparseArray = this.f593f;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i2 = 0; i2 < size; i2++) {
                iArr[i2] = this.f593f.keyAt(i2);
                parcelableArr[i2] = this.f593f.valueAt(i2);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$i */
    public static class C0127i implements Comparator<View> {
        public int compare(Object obj, Object obj2) {
            View view = (View) obj;
            View view2 = (View) obj2;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            int i = Build.VERSION.SDK_INT;
            float f = 0.0f;
            float z = i >= 21 ? view.getZ() : 0.0f;
            if (i >= 21) {
                f = view2.getZ();
            }
            if (z > f) {
                return -1;
            }
            return z < f ? 1 : 0;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.Class<androidx.coordinatorlayout.widget.CoordinatorLayout> r0 = androidx.coordinatorlayout.widget.CoordinatorLayout.class
            java.lang.Package r0 = r0.getPackage()
            r1 = 0
            if (r0 == 0) goto L_0x000e
            java.lang.String r0 = r0.getName()
            goto L_0x000f
        L_0x000e:
            r0 = r1
        L_0x000f:
            f549w = r0
            int r0 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r0 < r2) goto L_0x001f
            androidx.coordinatorlayout.widget.CoordinatorLayout$i r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$i
            r0.<init>()
            f552z = r0
            goto L_0x0021
        L_0x001f:
            f552z = r1
        L_0x0021:
            r0 = 2
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r1 = 0
            java.lang.Class<android.content.Context> r2 = android.content.Context.class
            r0[r1] = r2
            r1 = 1
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r0[r1] = r2
            f550x = r0
            java.lang.ThreadLocal r0 = new java.lang.ThreadLocal
            r0.<init>()
            f551y = r0
            l6 r0 = new l6
            r1 = 12
            r0.<init>(r1)
            f548A = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.<clinit>():void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        int[] iArr = C0733g4.f2829a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f561l = resources.getIntArray(resourceId);
            float f = resources.getDisplayMetrics().density;
            int length = this.f561l.length;
            for (int i = 0; i < length; i++) {
                int[] iArr2 = this.f561l;
                iArr2[i] = (int) (((float) iArr2[i]) * f);
            }
        }
        this.f568s = obtainStyledAttributes.getDrawable(1);
        obtainStyledAttributes.recycle();
        mo649z();
        super.setOnHierarchyChangeListener(new C0122e());
    }

    /* renamed from: a */
    public static Rect m265a() {
        Rect b = f548A.mo4124b();
        return b == null ? new Rect() : b;
    }

    /* renamed from: b */
    public final void mo601b(C0123f fVar, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + fVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - fVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + fVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - fVar.bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    /* renamed from: c */
    public void mo602c(View view) {
        List orDefault = this.f554e.f3029b.getOrDefault(view, null);
        if (orDefault != null && !orDefault.isEmpty()) {
            for (int i = 0; i < orDefault.size(); i++) {
                View view2 = (View) orDefault.get(i);
                C0120c cVar = ((C0123f) view2.getLayoutParams()).f574a;
                if (cVar != null) {
                    cVar.onDependentViewChanged(this, view2, view);
                }
            }
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0123f) && super.checkLayoutParams(layoutParams);
    }

    /* renamed from: d */
    public void mo604d(View view, boolean z, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z) {
            mo609g(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        C0123f fVar = (C0123f) view.getLayoutParams();
        C0120c cVar = fVar.f574a;
        if (cVar != null) {
            float scrimOpacity = cVar.getScrimOpacity(this, view);
            if (scrimOpacity > 0.0f) {
                if (this.f558i == null) {
                    this.f558i = new Paint();
                }
                this.f558i.setColor(fVar.f574a.getScrimColor(this, view));
                Paint paint = this.f558i;
                int round = Math.round(scrimOpacity * 255.0f);
                if (round < 0) {
                    round = 0;
                } else if (round > 255) {
                    round = 255;
                }
                paint.setAlpha(round);
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f558i);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f568s;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* renamed from: e */
    public List<View> mo607e(View view) {
        C0807h4<View> h4Var = this.f554e;
        int i = h4Var.f3029b.f2478f;
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < i; i2++) {
            ArrayList l = h4Var.f3029b.mo3284l(i2);
            if (l != null && l.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(h4Var.f3029b.mo3278h(i2));
            }
        }
        this.f556g.clear();
        if (arrayList != null) {
            this.f556g.addAll(arrayList);
        }
        return this.f556g;
    }

    /* renamed from: f */
    public List<View> mo608f(View view) {
        List orDefault = this.f554e.f3029b.getOrDefault(view, null);
        this.f556g.clear();
        if (orDefault != null) {
            this.f556g.addAll(orDefault);
        }
        return this.f556g;
    }

    /* renamed from: g */
    public void mo609g(View view, Rect rect) {
        ThreadLocal<Matrix> threadLocal = C0870i4.f3212a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal<Matrix> threadLocal2 = C0870i4.f3212a;
        Matrix matrix = threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        C0870i4.m2748a(this, view, matrix);
        ThreadLocal<RectF> threadLocal3 = C0870i4.f3213b;
        RectF rectF = threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0123f(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0123f(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        mo644v();
        return Collections.unmodifiableList(this.f553d);
    }

    public final C0943j7 getLastWindowInsets() {
        return this.f566q;
    }

    public int getNestedScrollAxes() {
        return this.f571v.mo6429a();
    }

    public Drawable getStatusBarBackground() {
        return this.f568s;
    }

    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    /* renamed from: h */
    public void mo262h(View view, View view2, int i, int i2) {
        C0120c cVar;
        C1982w6 w6Var = this.f571v;
        if (i2 == 1) {
            w6Var.f6580b = i;
        } else {
            w6Var.f6579a = i;
        }
        this.f563n = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            C0123f fVar = (C0123f) childAt.getLayoutParams();
            if (fVar.mo683a(i2) && (cVar = fVar.f574a) != null) {
                cVar.onNestedScrollAccepted(this, childAt, view, view2, i, i2);
            }
        }
    }

    /* renamed from: i */
    public void mo263i(View view, int i) {
        C1982w6 w6Var = this.f571v;
        if (i == 1) {
            w6Var.f6580b = 0;
        } else {
            w6Var.f6579a = 0;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0123f fVar = (C0123f) childAt.getLayoutParams();
            if (fVar.mo683a(i)) {
                C0120c cVar = fVar.f574a;
                if (cVar != null) {
                    cVar.onStopNestedScroll(this, childAt, view, i);
                }
                fVar.mo685c(i, false);
                fVar.f589p = false;
            }
        }
        this.f563n = null;
    }

    /* renamed from: j */
    public void mo264j(View view, int i, int i2, int[] iArr, int i3) {
        C0120c cVar;
        int childCount = getChildCount();
        boolean z = false;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() == 8) {
                int i7 = i3;
            } else {
                C0123f fVar = (C0123f) childAt.getLayoutParams();
                if (fVar.mo683a(i3) && (cVar = fVar.f574a) != null) {
                    int[] iArr2 = this.f557h;
                    iArr2[1] = 0;
                    iArr2[0] = 0;
                    cVar.onNestedPreScroll(this, childAt, view, i, i2, iArr2, i3);
                    int[] iArr3 = this.f557h;
                    i4 = i > 0 ? Math.max(i4, iArr3[0]) : Math.min(i4, iArr3[0]);
                    int[] iArr4 = this.f557h;
                    i5 = i2 > 0 ? Math.max(i5, iArr4[1]) : Math.min(i5, iArr4[1]);
                    z = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z) {
            mo632r(1);
        }
    }

    /* renamed from: k */
    public final void mo619k(int i, Rect rect, Rect rect2, C0123f fVar, int i2, int i3) {
        int i4 = fVar.f576c;
        if (i4 == 0) {
            i4 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
        int i5 = fVar.f577d;
        if ((i5 & 7) == 0) {
            i5 |= 8388611;
        }
        if ((i5 & C0446R.styleable.AppCompatTheme_tooltipForegroundColor) == 0) {
            i5 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i5, i);
        int i6 = absoluteGravity & 7;
        int i7 = absoluteGravity & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
        int i8 = absoluteGravity2 & 7;
        int i9 = absoluteGravity2 & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
        int width = i8 != 1 ? i8 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int height = i9 != 16 ? i9 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i6 == 1) {
            width -= i2 / 2;
        } else if (i6 != 5) {
            width -= i2;
        }
        if (i7 == 16) {
            height -= i3 / 2;
        } else if (i7 != 80) {
            height -= i3;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    /* renamed from: l */
    public final int mo620l(int i) {
        StringBuilder sb;
        int[] iArr = this.f561l;
        if (iArr == null) {
            sb = new StringBuilder();
            sb.append("No keylines defined for ");
            sb.append(this);
            sb.append(" - attempted index lookup ");
            sb.append(i);
        } else if (i >= 0 && i < iArr.length) {
            return iArr[i];
        } else {
            sb = new StringBuilder();
            sb.append("Keyline index ");
            sb.append(i);
            sb.append(" out of range for ");
            sb.append(this);
        }
        Log.e("CoordinatorLayout", sb.toString());
        return 0;
    }

    /* renamed from: n */
    public void mo268n(View view, int i, int i2, int i3, int i4, int i5) {
        C0120c cVar;
        int childCount = getChildCount();
        boolean z = false;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() == 8) {
                int i7 = i5;
            } else {
                C0123f fVar = (C0123f) childAt.getLayoutParams();
                if (fVar.mo683a(i5) && (cVar = fVar.f574a) != null) {
                    cVar.onNestedScroll(this, childAt, view, i, i2, i3, i4, i5);
                    z = true;
                }
            }
        }
        if (z) {
            mo632r(1);
        }
    }

    /* renamed from: o */
    public boolean mo269o(View view, View view2, int i, int i2) {
        int i3 = i2;
        int childCount = getChildCount();
        int i4 = 0;
        boolean z = false;
        while (true) {
            if (i4 >= childCount) {
                return z;
            }
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                C0123f fVar = (C0123f) childAt.getLayoutParams();
                C0120c cVar = fVar.f574a;
                if (cVar != null) {
                    boolean onStartNestedScroll = cVar.onStartNestedScroll(this, childAt, view, view2, i, i2);
                    z |= onStartNestedScroll;
                    fVar.mo685c(i3, onStartNestedScroll);
                } else {
                    fVar.mo685c(i3, false);
                }
            }
            i4++;
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        mo646w(false);
        if (this.f565p) {
            if (this.f564o == null) {
                this.f564o = new C0124g();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f564o);
        }
        if (this.f566q == null) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            if (getFitsSystemWindows()) {
                if (Build.VERSION.SDK_INT >= 20) {
                    requestApplyInsets();
                } else {
                    requestFitSystemWindows();
                }
            }
        }
        this.f560k = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo646w(false);
        if (this.f565p && this.f564o != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f564o);
        }
        View view = this.f563n;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f560k = false;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f567r && this.f568s != null) {
            C0943j7 j7Var = this.f566q;
            int d = j7Var != null ? j7Var.mo4128d() : 0;
            if (d > 0) {
                this.f568s.setBounds(0, 0, getWidth(), d);
                this.f568s.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            mo646w(true);
        }
        boolean u = mo643u(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            mo646w(true);
        }
        return u;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        C0120c cVar;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int layoutDirection = getLayoutDirection();
        int size = this.f553d.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = this.f553d.get(i5);
            if (view.getVisibility() != 8 && ((cVar = ((C0123f) view.getLayoutParams()).f574a) == null || !cVar.onLayoutChild(this, view, layoutDirection))) {
                mo635s(view, layoutDirection);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0180, code lost:
        if (r0.onMeasureChild(r30, r20, r8, r21, r23, 0) == false) goto L_0x0190;
     */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0159  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0161  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x0183  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r7 = r30
            r30.mo644v()
            int r0 = r30.getChildCount()
            r8 = 0
            r1 = 0
        L_0x000b:
            r2 = 1
            if (r1 >= r0) goto L_0x0038
            android.view.View r3 = r7.getChildAt(r1)
            h4<android.view.View> r4 = r7.f554e
            e4<T, java.util.ArrayList<T>> r5 = r4.f3029b
            int r5 = r5.f2478f
            r6 = 0
        L_0x0019:
            if (r6 >= r5) goto L_0x0030
            e4<T, java.util.ArrayList<T>> r9 = r4.f3029b
            java.lang.Object r9 = r9.mo3284l(r6)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 == 0) goto L_0x002d
            boolean r9 = r9.contains(r3)
            if (r9 == 0) goto L_0x002d
            r3 = 1
            goto L_0x0031
        L_0x002d:
            int r6 = r6 + 1
            goto L_0x0019
        L_0x0030:
            r3 = 0
        L_0x0031:
            if (r3 == 0) goto L_0x0035
            r0 = 1
            goto L_0x0039
        L_0x0035:
            int r1 = r1 + 1
            goto L_0x000b
        L_0x0038:
            r0 = 0
        L_0x0039:
            boolean r1 = r7.f565p
            if (r0 == r1) goto L_0x006d
            if (r0 == 0) goto L_0x005a
            boolean r0 = r7.f560k
            if (r0 == 0) goto L_0x0057
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = r7.f564o
            if (r0 != 0) goto L_0x004e
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$g
            r0.<init>()
            r7.f564o = r0
        L_0x004e:
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r1 = r7.f564o
            r0.addOnPreDrawListener(r1)
        L_0x0057:
            r7.f565p = r2
            goto L_0x006d
        L_0x005a:
            boolean r0 = r7.f560k
            if (r0 == 0) goto L_0x006b
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = r7.f564o
            if (r0 == 0) goto L_0x006b
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r1 = r7.f564o
            r0.removeOnPreDrawListener(r1)
        L_0x006b:
            r7.f565p = r8
        L_0x006d:
            int r9 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r10 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            java.util.WeakHashMap<android.view.View, java.lang.String> r3 = p000.C0010a7.f28a
            int r11 = r30.getLayoutDirection()
            if (r11 != r2) goto L_0x0087
            r12 = 1
            goto L_0x0088
        L_0x0087:
            r12 = 0
        L_0x0088:
            int r13 = android.view.View.MeasureSpec.getMode(r31)
            int r14 = android.view.View.MeasureSpec.getSize(r31)
            int r15 = android.view.View.MeasureSpec.getMode(r32)
            int r16 = android.view.View.MeasureSpec.getSize(r32)
            int r17 = r9 + r10
            int r18 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            j7 r3 = r7.f566q
            if (r3 == 0) goto L_0x00b1
            boolean r3 = r30.getFitsSystemWindows()
            if (r3 == 0) goto L_0x00b1
            r19 = 1
            goto L_0x00b3
        L_0x00b1:
            r19 = 0
        L_0x00b3:
            java.util.List<android.view.View> r2 = r7.f553d
            int r6 = r2.size()
            r5 = r0
            r4 = r1
            r2 = 0
            r3 = 0
        L_0x00bd:
            if (r3 >= r6) goto L_0x01d6
            java.util.List<android.view.View> r0 = r7.f553d
            java.lang.Object r0 = r0.get(r3)
            r20 = r0
            android.view.View r20 = (android.view.View) r20
            int r0 = r20.getVisibility()
            r1 = 8
            if (r0 != r1) goto L_0x00d9
            r22 = r3
            r29 = r6
            r28 = r9
            goto L_0x01cd
        L_0x00d9:
            android.view.ViewGroup$LayoutParams r0 = r20.getLayoutParams()
            r1 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r1 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0123f) r1
            int r0 = r1.f578e
            if (r0 < 0) goto L_0x0123
            if (r13 == 0) goto L_0x0123
            int r0 = r7.mo620l(r0)
            int r8 = r1.f576c
            if (r8 != 0) goto L_0x00f1
            r8 = 8388661(0x800035, float:1.1755018E-38)
        L_0x00f1:
            int r8 = android.view.Gravity.getAbsoluteGravity(r8, r11)
            r8 = r8 & 7
            r22 = r2
            r2 = 3
            if (r8 != r2) goto L_0x00fe
            if (r12 == 0) goto L_0x0103
        L_0x00fe:
            r2 = 5
            if (r8 != r2) goto L_0x010f
            if (r12 == 0) goto L_0x010f
        L_0x0103:
            int r2 = r14 - r10
            int r2 = r2 - r0
            r0 = 0
            int r2 = java.lang.Math.max(r0, r2)
            r21 = r2
            r8 = 0
            goto L_0x0127
        L_0x010f:
            if (r8 != r2) goto L_0x0113
            if (r12 == 0) goto L_0x0118
        L_0x0113:
            r2 = 3
            if (r8 != r2) goto L_0x0121
            if (r12 == 0) goto L_0x0121
        L_0x0118:
            int r0 = r0 - r9
            r8 = 0
            int r0 = java.lang.Math.max(r8, r0)
            r21 = r0
            goto L_0x0127
        L_0x0121:
            r8 = 0
            goto L_0x0125
        L_0x0123:
            r22 = r2
        L_0x0125:
            r21 = 0
        L_0x0127:
            if (r19 == 0) goto L_0x0159
            boolean r0 = r20.getFitsSystemWindows()
            if (r0 != 0) goto L_0x0159
            j7 r0 = r7.f566q
            int r0 = r0.mo4126b()
            j7 r2 = r7.f566q
            int r2 = r2.mo4127c()
            int r2 = r2 + r0
            j7 r0 = r7.f566q
            int r0 = r0.mo4128d()
            j7 r8 = r7.f566q
            int r8 = r8.mo4125a()
            int r8 = r8 + r0
            int r0 = r14 - r2
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r13)
            int r2 = r16 - r8
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r15)
            r8 = r0
            r23 = r2
            goto L_0x015d
        L_0x0159:
            r8 = r31
            r23 = r32
        L_0x015d:
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r0 = r1.f574a
            if (r0 == 0) goto L_0x0183
            r24 = 0
            r2 = r1
            r1 = r30
            r26 = r2
            r25 = r22
            r2 = r20
            r22 = r3
            r3 = r8
            r27 = r4
            r4 = r21
            r28 = r9
            r9 = r5
            r5 = r23
            r29 = r6
            r6 = r24
            boolean r0 = r0.onMeasureChild(r1, r2, r3, r4, r5, r6)
            if (r0 != 0) goto L_0x019d
            goto L_0x0190
        L_0x0183:
            r26 = r1
            r27 = r4
            r29 = r6
            r28 = r9
            r25 = r22
            r22 = r3
            r9 = r5
        L_0x0190:
            r5 = 0
            r0 = r30
            r1 = r20
            r2 = r8
            r3 = r21
            r4 = r23
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
        L_0x019d:
            int r0 = r20.getMeasuredWidth()
            int r0 = r0 + r17
            r1 = r26
            int r2 = r1.leftMargin
            int r0 = r0 + r2
            int r2 = r1.rightMargin
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r9, r0)
            int r2 = r20.getMeasuredHeight()
            int r2 = r2 + r18
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r1 = r1.bottomMargin
            int r2 = r2 + r1
            r1 = r27
            int r1 = java.lang.Math.max(r1, r2)
            int r2 = r20.getMeasuredState()
            r8 = r25
            int r2 = android.view.View.combineMeasuredStates(r8, r2)
            r5 = r0
            r4 = r1
        L_0x01cd:
            int r3 = r22 + 1
            r9 = r28
            r6 = r29
            r8 = 0
            goto L_0x00bd
        L_0x01d6:
            r8 = r2
            r1 = r4
            r9 = r5
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r8
            r2 = r31
            int r0 = android.view.View.resolveSizeAndState(r9, r2, r0)
            int r2 = r8 << 16
            r3 = r32
            int r1 = android.view.View.resolveSizeAndState(r1, r3, r2)
            r7.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        C0120c cVar;
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0123f fVar = (C0123f) childAt.getLayoutParams();
                if (fVar.mo683a(0) && (cVar = fVar.f574a) != null) {
                    z2 |= cVar.onNestedFling(this, childAt, view, f, f2, z);
                }
            }
        }
        if (z2) {
            mo632r(1);
        }
        return z2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        C0120c cVar;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0123f fVar = (C0123f) childAt.getLayoutParams();
                if (fVar.mo683a(0) && (cVar = fVar.f574a) != null) {
                    z |= cVar.onNestedPreFling(this, childAt, view, f, f2);
                }
            }
        }
        return z;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo264j(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo268n(view, i, i2, i3, i4, 0);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo262h(view, view2, i, 0);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof C0125h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0125h hVar = (C0125h) parcelable;
        super.onRestoreInstanceState(hVar.f43d);
        SparseArray<Parcelable> sparseArray = hVar.f593f;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0120c cVar = mo630p(childAt).f574a;
            if (!(id == -1 || cVar == null || (parcelable2 = sparseArray.get(id)) == null)) {
                cVar.onRestoreInstanceState(this, childAt, parcelable2);
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState;
        C0125h hVar = new C0125h(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0120c cVar = ((C0123f) childAt.getLayoutParams()).f574a;
            if (!(id == -1 || cVar == null || (onSaveInstanceState = cVar.onSaveInstanceState(this, childAt)) == null)) {
                sparseArray.append(id, onSaveInstanceState);
            }
        }
        hVar.f593f = sparseArray;
        return hVar;
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo269o(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo263i(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0016;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f562m
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0015
            boolean r3 = r0.mo643u(r1, r4)
            if (r3 == 0) goto L_0x0029
            goto L_0x0016
        L_0x0015:
            r3 = 0
        L_0x0016:
            android.view.View r6 = r0.f562m
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0123f) r6
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r6 = r6.f574a
            if (r6 == 0) goto L_0x0029
            android.view.View r7 = r0.f562m
            boolean r6 = r6.onTouchEvent(r0, r7, r1)
            goto L_0x002a
        L_0x0029:
            r6 = 0
        L_0x002a:
            android.view.View r7 = r0.f562m
            r8 = 0
            if (r7 != 0) goto L_0x0035
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x0048
        L_0x0035:
            if (r3 == 0) goto L_0x0048
            long r11 = android.os.SystemClock.uptimeMillis()
            r13 = 3
            r14 = 0
            r15 = 0
            r16 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x0048:
            if (r8 == 0) goto L_0x004d
            r8.recycle()
        L_0x004d:
            if (r2 == r4) goto L_0x0052
            r1 = 3
            if (r2 != r1) goto L_0x0055
        L_0x0052:
            r0.mo646w(r5)
        L_0x0055:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public C0123f mo630p(View view) {
        C0123f fVar = (C0123f) view.getLayoutParams();
        if (!fVar.f575b) {
            if (view instanceof C0119b) {
                C0120c behavior = ((C0119b) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                fVar.mo684b(behavior);
            } else {
                C0121d dVar = null;
                for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    dVar = (C0121d) cls.getAnnotation(C0121d.class);
                    if (dVar != null) {
                        break;
                    }
                }
                if (dVar != null) {
                    try {
                        fVar.mo684b((C0120c) dVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
                    } catch (Exception e) {
                        StringBuilder d = C1012kd.m3195d("Default behavior class ");
                        d.append(dVar.value().getName());
                        d.append(" could not be instantiated. Did you forget");
                        d.append(" a default constructor?");
                        Log.e("CoordinatorLayout", d.toString(), e);
                    }
                }
            }
            fVar.f575b = true;
        }
        return fVar;
    }

    /* renamed from: q */
    public boolean mo631q(View view, int i, int i2) {
        Rect a = m265a();
        mo609g(view, a);
        try {
            return a.contains(i, i2);
        } finally {
            a.setEmpty();
            f548A.mo4123a(a);
        }
    }

    /* renamed from: r */
    public final void mo632r(int i) {
        int i2;
        Rect rect;
        int i3;
        boolean z;
        boolean z2;
        boolean z3;
        int width;
        int i4;
        int i5;
        int i6;
        int height;
        int i7;
        int i8;
        int i9;
        Rect rect2;
        int i10;
        int i11;
        int i12;
        C0123f fVar;
        C0120c cVar;
        int i13 = i;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int layoutDirection = getLayoutDirection();
        int size = this.f553d.size();
        Rect a = m265a();
        Rect a2 = m265a();
        Rect a3 = m265a();
        int i14 = 0;
        while (i14 < size) {
            View view = this.f553d.get(i14);
            C0123f fVar2 = (C0123f) view.getLayoutParams();
            if (i13 == 0 && view.getVisibility() == 8) {
                i3 = size;
                rect = a3;
                i2 = i14;
            } else {
                int i15 = 0;
                while (i15 < i14) {
                    if (fVar2.f585l == this.f553d.get(i15)) {
                        C0123f fVar3 = (C0123f) view.getLayoutParams();
                        if (fVar3.f584k != null) {
                            Rect a4 = m265a();
                            Rect a5 = m265a();
                            Rect a6 = m265a();
                            mo609g(fVar3.f584k, a4);
                            mo604d(view, false, a5);
                            int measuredWidth = view.getMeasuredWidth();
                            i12 = size;
                            int measuredHeight = view.getMeasuredHeight();
                            int i16 = measuredWidth;
                            Rect rect3 = a6;
                            i11 = i14;
                            Rect rect4 = a5;
                            Rect rect5 = a4;
                            C0123f fVar4 = fVar3;
                            i10 = i15;
                            rect2 = a3;
                            fVar = fVar2;
                            mo619k(layoutDirection, a4, rect3, fVar3, i16, measuredHeight);
                            Rect rect6 = rect3;
                            boolean z4 = (rect6.left == rect4.left && rect6.top == rect4.top) ? false : true;
                            C0123f fVar5 = fVar4;
                            mo601b(fVar5, rect6, i16, measuredHeight);
                            int i17 = rect6.left - rect4.left;
                            int i18 = rect6.top - rect4.top;
                            if (i17 != 0) {
                                C0010a7.m38k(view, i17);
                            }
                            if (i18 != 0) {
                                C0010a7.m39l(view, i18);
                            }
                            if (z4 && (cVar = fVar5.f574a) != null) {
                                cVar.onDependentViewChanged(this, view, fVar5.f584k);
                            }
                            rect5.setEmpty();
                            C0940j6<Rect> j6Var = f548A;
                            j6Var.mo4123a(rect5);
                            rect4.setEmpty();
                            j6Var.mo4123a(rect4);
                            rect6.setEmpty();
                            j6Var.mo4123a(rect6);
                            i15 = i10 + 1;
                            fVar2 = fVar;
                            size = i12;
                            i14 = i11;
                            a3 = rect2;
                        }
                    }
                    i10 = i15;
                    i12 = size;
                    rect2 = a3;
                    i11 = i14;
                    fVar = fVar2;
                    i15 = i10 + 1;
                    fVar2 = fVar;
                    size = i12;
                    i14 = i11;
                    a3 = rect2;
                }
                int i19 = size;
                Rect rect7 = a3;
                i2 = i14;
                C0123f fVar6 = fVar2;
                mo604d(view, true, a2);
                if (fVar6.f580g != 0 && !a2.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(fVar6.f580g, layoutDirection);
                    int i20 = absoluteGravity & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
                    if (i20 == 48) {
                        a.top = Math.max(a.top, a2.bottom);
                    } else if (i20 == 80) {
                        a.bottom = Math.max(a.bottom, getHeight() - a2.top);
                    }
                    int i21 = absoluteGravity & 7;
                    if (i21 == 3) {
                        a.left = Math.max(a.left, a2.right);
                    } else if (i21 == 5) {
                        a.right = Math.max(a.right, getWidth() - a2.left);
                    }
                }
                if (fVar6.f581h != 0 && view.getVisibility() == 0) {
                    WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                    if (view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                        C0123f fVar7 = (C0123f) view.getLayoutParams();
                        C0120c cVar2 = fVar7.f574a;
                        Rect a7 = m265a();
                        Rect a8 = m265a();
                        a8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                        if (cVar2 == null || !cVar2.getInsetDodgeRect(this, view, a7)) {
                            a7.set(a8);
                        } else if (!a8.contains(a7)) {
                            StringBuilder d = C1012kd.m3195d("Rect should be within the child's bounds. Rect:");
                            d.append(a7.toShortString());
                            d.append(" | Bounds:");
                            d.append(a8.toShortString());
                            throw new IllegalArgumentException(d.toString());
                        }
                        a8.setEmpty();
                        C0940j6<Rect> j6Var2 = f548A;
                        j6Var2.mo4123a(a8);
                        if (!a7.isEmpty()) {
                            int absoluteGravity2 = Gravity.getAbsoluteGravity(fVar7.f581h, layoutDirection);
                            if ((absoluteGravity2 & 48) != 48 || (i8 = (a7.top - fVar7.topMargin) - fVar7.f583j) >= (i9 = a.top)) {
                                z2 = false;
                            } else {
                                mo648y(view, i9 - i8);
                                z2 = true;
                            }
                            if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - a7.bottom) - fVar7.bottomMargin) + fVar7.f583j) < (i7 = a.bottom)) {
                                mo648y(view, height - i7);
                                z2 = true;
                            }
                            if (!z2) {
                                mo648y(view, 0);
                            }
                            if ((absoluteGravity2 & 3) != 3 || (i5 = (a7.left - fVar7.leftMargin) - fVar7.f582i) >= (i6 = a.left)) {
                                z3 = false;
                            } else {
                                mo647x(view, i6 - i5);
                                z3 = true;
                            }
                            if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - a7.right) - fVar7.rightMargin) + fVar7.f582i) < (i4 = a.right)) {
                                mo647x(view, width - i4);
                                z3 = true;
                            }
                            if (!z3) {
                                mo647x(view, 0);
                            }
                        }
                        a7.setEmpty();
                        j6Var2.mo4123a(a7);
                    }
                }
                if (i13 != 2) {
                    rect = rect7;
                    rect.set(((C0123f) view.getLayoutParams()).f590q);
                    if (rect.equals(a2)) {
                        i3 = i19;
                    } else {
                        ((C0123f) view.getLayoutParams()).f590q.set(a2);
                    }
                } else {
                    rect = rect7;
                }
                i3 = i19;
                for (int i22 = i2 + 1; i22 < i3; i22++) {
                    View view2 = this.f553d.get(i22);
                    C0123f fVar8 = (C0123f) view2.getLayoutParams();
                    C0120c cVar3 = fVar8.f574a;
                    if (cVar3 != null && cVar3.layoutDependsOn(this, view2, view)) {
                        if (i13 != 0 || !fVar8.f589p) {
                            if (i13 != 2) {
                                z = cVar3.onDependentViewChanged(this, view2, view);
                            } else {
                                cVar3.onDependentViewRemoved(this, view2, view);
                                z = true;
                            }
                            if (i13 == 1) {
                                fVar8.f589p = z;
                            }
                        } else {
                            fVar8.f589p = false;
                        }
                    }
                }
            }
            i14 = i2 + 1;
            size = i3;
            a3 = rect;
        }
        Rect rect8 = a3;
        a.setEmpty();
        C0940j6<Rect> j6Var3 = f548A;
        j6Var3.mo4123a(a);
        a2.setEmpty();
        j6Var3.mo4123a(a2);
        rect8.setEmpty();
        j6Var3.mo4123a(rect8);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        C0120c cVar = ((C0123f) view.getLayoutParams()).f574a;
        if (cVar == null || !cVar.onRequestChildRectangleOnScreen(this, view, rect, z)) {
            return super.requestChildRectangleOnScreen(view, rect, z);
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.f559j) {
            mo646w(false);
            this.f559j = true;
        }
    }

    /* renamed from: s */
    public void mo635s(View view, int i) {
        C0123f fVar = (C0123f) view.getLayoutParams();
        View view2 = fVar.f584k;
        int i2 = 0;
        if (view2 == null && fVar.f579f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        } else if (view2 != null) {
            Rect a = m265a();
            Rect a2 = m265a();
            try {
                mo609g(view2, a);
                C0123f fVar2 = (C0123f) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                mo619k(i, a, a2, fVar2, measuredWidth, measuredHeight);
                mo601b(fVar2, a2, measuredWidth, measuredHeight);
                view.layout(a2.left, a2.top, a2.right, a2.bottom);
            } finally {
                a.setEmpty();
                C0940j6<Rect> j6Var = f548A;
                j6Var.mo4123a(a);
                a2.setEmpty();
                j6Var.mo4123a(a2);
            }
        } else {
            int i3 = fVar.f578e;
            if (i3 >= 0) {
                C0123f fVar3 = (C0123f) view.getLayoutParams();
                int i4 = fVar3.f576c;
                if (i4 == 0) {
                    i4 = 8388661;
                }
                int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
                int i5 = absoluteGravity & 7;
                int i6 = absoluteGravity & C0446R.styleable.AppCompatTheme_tooltipForegroundColor;
                int width = getWidth();
                int height = getHeight();
                int measuredWidth2 = view.getMeasuredWidth();
                int measuredHeight2 = view.getMeasuredHeight();
                if (i == 1) {
                    i3 = width - i3;
                }
                int l = mo620l(i3) - measuredWidth2;
                if (i5 == 1) {
                    l += measuredWidth2 / 2;
                } else if (i5 == 5) {
                    l += measuredWidth2;
                }
                if (i6 == 16) {
                    i2 = 0 + (measuredHeight2 / 2);
                } else if (i6 == 80) {
                    i2 = measuredHeight2 + 0;
                }
                int max = Math.max(getPaddingLeft() + fVar3.leftMargin, Math.min(l, ((width - getPaddingRight()) - measuredWidth2) - fVar3.rightMargin));
                int max2 = Math.max(getPaddingTop() + fVar3.topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight2) - fVar3.bottomMargin));
                view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
                return;
            }
            C0123f fVar4 = (C0123f) view.getLayoutParams();
            Rect a3 = m265a();
            a3.set(getPaddingLeft() + fVar4.leftMargin, getPaddingTop() + fVar4.topMargin, (getWidth() - getPaddingRight()) - fVar4.rightMargin, (getHeight() - getPaddingBottom()) - fVar4.bottomMargin);
            if (this.f566q != null) {
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                    a3.left = this.f566q.mo4126b() + a3.left;
                    a3.top = this.f566q.mo4128d() + a3.top;
                    a3.right -= this.f566q.mo4127c();
                    a3.bottom -= this.f566q.mo4125a();
                }
            }
            Rect a4 = m265a();
            int i7 = fVar4.f576c;
            if ((i7 & 7) == 0) {
                i7 |= 8388611;
            }
            if ((i7 & C0446R.styleable.AppCompatTheme_tooltipForegroundColor) == 0) {
                i7 |= 48;
            }
            Gravity.apply(i7, view.getMeasuredWidth(), view.getMeasuredHeight(), a3, a4, i);
            view.layout(a4.left, a4.top, a4.right, a4.bottom);
            a3.setEmpty();
            C0940j6<Rect> j6Var2 = f548A;
            j6Var2.mo4123a(a3);
            a4.setEmpty();
            j6Var2.mo4123a(a4);
        }
    }

    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        mo649z();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f569t = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f568s;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f568s = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.f568s.setState(getDrawableState());
                }
                Drawable drawable4 = this.f568s;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                C1401p4.m4355c0(drawable4, getLayoutDirection());
                this.f568s.setVisible(getVisibility() == 0, false);
                this.f568s.setCallback(this);
            }
            WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
            postInvalidateOnAnimation();
        }
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        setStatusBarBackground(i != 0 ? C1901v4.m5334c(getContext(), i) : null);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f568s;
        if (drawable != null && drawable.isVisible() != z) {
            this.f568s.setVisible(z, false);
        }
    }

    /* renamed from: t */
    public void mo642t(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    /* renamed from: u */
    public final boolean mo643u(MotionEvent motionEvent, int i) {
        boolean z;
        MotionEvent motionEvent2 = motionEvent;
        int i2 = i;
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f555f;
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            list.add(getChildAt(isChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i3) : i3));
        }
        Comparator<View> comparator = f552z;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
        int size = list.size();
        MotionEvent motionEvent3 = null;
        boolean z2 = false;
        boolean z3 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = list.get(i4);
            C0123f fVar = (C0123f) view.getLayoutParams();
            C0120c cVar = fVar.f574a;
            boolean z4 = true;
            if ((!z2 && !z3) || actionMasked == 0) {
                if (!z2 && cVar != null) {
                    if (i2 == 0) {
                        z2 = cVar.onInterceptTouchEvent(this, view, motionEvent2);
                    } else if (i2 == 1) {
                        z2 = cVar.onTouchEvent(this, view, motionEvent2);
                    }
                    if (z2) {
                        this.f562m = view;
                    }
                }
                C0120c cVar2 = fVar.f574a;
                if (cVar2 == null) {
                    fVar.f586m = false;
                }
                boolean z5 = fVar.f586m;
                if (z5) {
                    z = true;
                } else {
                    z = (cVar2 != null ? cVar2.blocksInteractionBelow(this, view) : false) | z5;
                    fVar.f586m = z;
                }
                if (!z || z5) {
                    z4 = false;
                }
                if (z && !z4) {
                    break;
                }
                z3 = z4;
            } else if (cVar != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i2 == 0) {
                    cVar.onInterceptTouchEvent(this, view, motionEvent3);
                } else if (i2 == 1) {
                    cVar.onTouchEvent(this, view, motionEvent3);
                }
            }
        }
        list.clear();
        return z2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0073, code lost:
        if (r5 != false) goto L_0x00c2;
     */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0162 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0108  */
    /* renamed from: v */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo644v() {
        /*
            r11 = this;
            java.util.List<android.view.View> r0 = r11.f553d
            r0.clear()
            h4<android.view.View> r0 = r11.f554e
            e4<T, java.util.ArrayList<T>> r1 = r0.f3029b
            int r1 = r1.f2478f
            r2 = 0
            r3 = 0
        L_0x000d:
            if (r3 >= r1) goto L_0x0024
            e4<T, java.util.ArrayList<T>> r4 = r0.f3029b
            java.lang.Object r4 = r4.mo3284l(r3)
            java.util.ArrayList r4 = (java.util.ArrayList) r4
            if (r4 == 0) goto L_0x0021
            r4.clear()
            j6<java.util.ArrayList<T>> r5 = r0.f3028a
            r5.mo4123a(r4)
        L_0x0021:
            int r3 = r3 + 1
            goto L_0x000d
        L_0x0024:
            e4<T, java.util.ArrayList<T>> r0 = r0.f3029b
            r0.clear()
            int r0 = r11.getChildCount()
            r1 = 0
        L_0x002e:
            if (r1 >= r0) goto L_0x018f
            android.view.View r3 = r11.getChildAt(r1)
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r4 = r11.mo630p(r3)
            int r5 = r4.f579f
            r6 = -1
            r7 = 0
            if (r5 != r6) goto L_0x0044
            r4.f585l = r7
            r4.f584k = r7
            goto L_0x00c2
        L_0x0044:
            android.view.View r5 = r4.f584k
            if (r5 == 0) goto L_0x0075
            int r5 = r5.getId()
            int r6 = r4.f579f
            if (r5 == r6) goto L_0x0051
            goto L_0x006e
        L_0x0051:
            android.view.View r5 = r4.f584k
            android.view.ViewParent r6 = r5.getParent()
        L_0x0057:
            if (r6 == r11) goto L_0x0070
            if (r6 == 0) goto L_0x006a
            if (r6 != r3) goto L_0x005e
            goto L_0x006a
        L_0x005e:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x0065
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x0065:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0057
        L_0x006a:
            r4.f585l = r7
            r4.f584k = r7
        L_0x006e:
            r5 = 0
            goto L_0x0073
        L_0x0070:
            r4.f585l = r5
            r5 = 1
        L_0x0073:
            if (r5 != 0) goto L_0x00c2
        L_0x0075:
            int r5 = r4.f579f
            android.view.View r5 = r11.findViewById(r5)
            r4.f584k = r5
            if (r5 == 0) goto L_0x00b8
            if (r5 != r11) goto L_0x0090
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x0088
            goto L_0x00be
        L_0x0088:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "View can not be anchored to the the parent CoordinatorLayout"
            r0.<init>(r1)
            throw r0
        L_0x0090:
            android.view.ViewParent r6 = r5.getParent()
        L_0x0094:
            if (r6 == r11) goto L_0x00b5
            if (r6 == 0) goto L_0x00b5
            if (r6 != r3) goto L_0x00a9
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x00a1
            goto L_0x00be
        L_0x00a1:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Anchor must not be a descendant of the anchored view"
            r0.<init>(r1)
            throw r0
        L_0x00a9:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x00b0
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x00b0:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0094
        L_0x00b5:
            r4.f585l = r5
            goto L_0x00c2
        L_0x00b8:
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x016a
        L_0x00be:
            r4.f585l = r7
            r4.f584k = r7
        L_0x00c2:
            h4<android.view.View> r5 = r11.f554e
            r5.mo3857a(r3)
            r5 = 0
        L_0x00c8:
            if (r5 >= r0) goto L_0x0166
            if (r5 != r1) goto L_0x00ce
            goto L_0x0162
        L_0x00ce:
            android.view.View r6 = r11.getChildAt(r5)
            android.view.View r8 = r4.f585l
            if (r6 == r8) goto L_0x0105
            java.util.WeakHashMap<android.view.View, java.lang.String> r8 = p000.C0010a7.f28a
            int r8 = r11.getLayoutDirection()
            android.view.ViewGroup$LayoutParams r9 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r9 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0123f) r9
            int r9 = r9.f580g
            int r9 = android.view.Gravity.getAbsoluteGravity(r9, r8)
            if (r9 == 0) goto L_0x00f5
            int r10 = r4.f581h
            int r8 = android.view.Gravity.getAbsoluteGravity(r10, r8)
            r8 = r8 & r9
            if (r8 != r9) goto L_0x00f5
            r8 = 1
            goto L_0x00f6
        L_0x00f5:
            r8 = 0
        L_0x00f6:
            if (r8 != 0) goto L_0x0105
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r8 = r4.f574a
            if (r8 == 0) goto L_0x0103
            boolean r8 = r8.layoutDependsOn(r11, r3, r6)
            if (r8 == 0) goto L_0x0103
            goto L_0x0105
        L_0x0103:
            r8 = 0
            goto L_0x0106
        L_0x0105:
            r8 = 1
        L_0x0106:
            if (r8 == 0) goto L_0x0162
            h4<android.view.View> r8 = r11.f554e
            e4<T, java.util.ArrayList<T>> r8 = r8.f3029b
            int r8 = r8.mo3272e(r6)
            if (r8 < 0) goto L_0x0114
            r8 = 1
            goto L_0x0115
        L_0x0114:
            r8 = 0
        L_0x0115:
            if (r8 != 0) goto L_0x011c
            h4<android.view.View> r8 = r11.f554e
            r8.mo3857a(r6)
        L_0x011c:
            h4<android.view.View> r8 = r11.f554e
            e4<T, java.util.ArrayList<T>> r9 = r8.f3029b
            int r9 = r9.mo3272e(r6)
            if (r9 < 0) goto L_0x0128
            r9 = 1
            goto L_0x0129
        L_0x0128:
            r9 = 0
        L_0x0129:
            if (r9 == 0) goto L_0x015a
            e4<T, java.util.ArrayList<T>> r9 = r8.f3029b
            int r9 = r9.mo3272e(r3)
            if (r9 < 0) goto L_0x0135
            r9 = 1
            goto L_0x0136
        L_0x0135:
            r9 = 0
        L_0x0136:
            if (r9 == 0) goto L_0x015a
            e4<T, java.util.ArrayList<T>> r9 = r8.f3029b
            java.lang.Object r9 = r9.getOrDefault(r6, r7)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x0156
            j6<java.util.ArrayList<T>> r9 = r8.f3028a
            java.lang.Object r9 = r9.mo4124b()
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x0151
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
        L_0x0151:
            e4<T, java.util.ArrayList<T>> r8 = r8.f3029b
            r8.put(r6, r9)
        L_0x0156:
            r9.add(r3)
            goto L_0x0162
        L_0x015a:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "All nodes must be present in the graph before being added as an edge"
            r0.<init>(r1)
            throw r0
        L_0x0162:
            int r5 = r5 + 1
            goto L_0x00c8
        L_0x0166:
            int r1 = r1 + 1
            goto L_0x002e
        L_0x016a:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Could not find CoordinatorLayout descendant view with id "
            java.lang.StringBuilder r1 = p000.C1012kd.m3195d(r1)
            android.content.res.Resources r2 = r11.getResources()
            int r4 = r4.f579f
            java.lang.String r2 = r2.getResourceName(r4)
            r1.append(r2)
            java.lang.String r2 = " to anchor view "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x018f:
            java.util.List<android.view.View> r0 = r11.f553d
            h4<android.view.View> r1 = r11.f554e
            java.util.ArrayList<T> r3 = r1.f3030c
            r3.clear()
            java.util.HashSet<T> r3 = r1.f3031d
            r3.clear()
            e4<T, java.util.ArrayList<T>> r3 = r1.f3029b
            int r3 = r3.f2478f
        L_0x01a1:
            if (r2 >= r3) goto L_0x01b3
            e4<T, java.util.ArrayList<T>> r4 = r1.f3029b
            java.lang.Object r4 = r4.mo3278h(r2)
            java.util.ArrayList<T> r5 = r1.f3030c
            java.util.HashSet<T> r6 = r1.f3031d
            r1.mo3858b(r4, r5, r6)
            int r2 = r2 + 1
            goto L_0x01a1
        L_0x01b3:
            java.util.ArrayList<T> r1 = r1.f3030c
            r0.addAll(r1)
            java.util.List<android.view.View> r0 = r11.f553d
            java.util.Collections.reverse(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.mo644v():void");
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f568s;
    }

    /* renamed from: w */
    public final void mo646w(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            C0120c cVar = ((C0123f) childAt.getLayoutParams()).f574a;
            if (cVar != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z) {
                    cVar.onInterceptTouchEvent(this, childAt, obtain);
                } else {
                    cVar.onTouchEvent(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i2 = 0; i2 < childCount; i2++) {
            ((C0123f) getChildAt(i2).getLayoutParams()).f586m = false;
        }
        this.f562m = null;
        this.f559j = false;
    }

    /* renamed from: x */
    public final void mo647x(View view, int i) {
        C0123f fVar = (C0123f) view.getLayoutParams();
        int i2 = fVar.f582i;
        if (i2 != i) {
            C0010a7.m38k(view, i - i2);
            fVar.f582i = i;
        }
    }

    /* renamed from: y */
    public final void mo648y(View view, int i) {
        C0123f fVar = (C0123f) view.getLayoutParams();
        int i2 = fVar.f583j;
        if (i2 != i) {
            C0010a7.m39l(view, i - i2);
            fVar.f583j = i;
        }
    }

    /* renamed from: z */
    public final void mo649z() {
        if (Build.VERSION.SDK_INT >= 21) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            if (getFitsSystemWindows()) {
                if (this.f570u == null) {
                    this.f570u = new C0118a();
                }
                C0010a7.m45r(this, this.f570u);
                setSystemUiVisibility(1280);
                return;
            }
            C0010a7.m45r(this, (C2052x6) null);
        }
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof C0123f) {
            return new C0123f((C0123f) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0123f((ViewGroup.MarginLayoutParams) layoutParams) : new C0123f(layoutParams);
    }
}
