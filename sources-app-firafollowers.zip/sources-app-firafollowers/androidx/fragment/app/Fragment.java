package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import java.util.Objects;
import java.util.UUID;
import p000.C1230n8;
import p000.C1409p9;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, C1725s9, C0681fa, C1324ob {

    /* renamed from: W */
    public static final Object f639W = new Object();

    /* renamed from: A */
    public String f640A;

    /* renamed from: B */
    public boolean f641B;

    /* renamed from: C */
    public boolean f642C;

    /* renamed from: D */
    public boolean f643D;

    /* renamed from: E */
    public boolean f644E = true;

    /* renamed from: F */
    public boolean f645F;

    /* renamed from: G */
    public ViewGroup f646G;

    /* renamed from: H */
    public View f647H;

    /* renamed from: I */
    public View f648I;

    /* renamed from: J */
    public boolean f649J;

    /* renamed from: K */
    public boolean f650K = true;

    /* renamed from: L */
    public C0134a f651L;

    /* renamed from: M */
    public boolean f652M;

    /* renamed from: N */
    public boolean f653N;

    /* renamed from: O */
    public float f654O;

    /* renamed from: P */
    public LayoutInflater f655P;

    /* renamed from: Q */
    public boolean f656Q;

    /* renamed from: R */
    public C1409p9.C1411b f657R = C1409p9.C1411b.RESUMED;

    /* renamed from: S */
    public C1785t9 f658S;

    /* renamed from: T */
    public C0740g9 f659T;

    /* renamed from: U */
    public C2057x9<C1725s9> f660U = new C2057x9<>();

    /* renamed from: V */
    public C1243nb f661V;

    /* renamed from: d */
    public int f662d = 0;

    /* renamed from: e */
    public Bundle f663e;

    /* renamed from: f */
    public SparseArray<Parcelable> f664f;

    /* renamed from: g */
    public Boolean f665g;

    /* renamed from: h */
    public String f666h = UUID.randomUUID().toString();

    /* renamed from: i */
    public Bundle f667i;

    /* renamed from: j */
    public Fragment f668j;

    /* renamed from: k */
    public String f669k = null;

    /* renamed from: l */
    public int f670l;

    /* renamed from: m */
    public Boolean f671m = null;

    /* renamed from: n */
    public boolean f672n;

    /* renamed from: o */
    public boolean f673o;

    /* renamed from: p */
    public boolean f674p;

    /* renamed from: q */
    public boolean f675q;

    /* renamed from: r */
    public boolean f676r;

    /* renamed from: s */
    public boolean f677s;

    /* renamed from: t */
    public int f678t;

    /* renamed from: u */
    public C1230n8 f679u;

    /* renamed from: v */
    public C1097l8 f680v;

    /* renamed from: w */
    public C1230n8 f681w = new C1230n8();

    /* renamed from: x */
    public Fragment f682x;

    /* renamed from: y */
    public int f683y;

    /* renamed from: z */
    public int f684z;

    /* renamed from: androidx.fragment.app.Fragment$a */
    public static class C0134a {

        /* renamed from: a */
        public View f686a;

        /* renamed from: b */
        public Animator f687b;

        /* renamed from: c */
        public int f688c;

        /* renamed from: d */
        public int f689d;

        /* renamed from: e */
        public int f690e;

        /* renamed from: f */
        public int f691f;

        /* renamed from: g */
        public Object f692g;

        /* renamed from: h */
        public Object f693h;

        /* renamed from: i */
        public Object f694i;

        /* renamed from: j */
        public C0136c f695j;

        /* renamed from: k */
        public boolean f696k;

        public C0134a() {
            Object obj = Fragment.f639W;
            this.f692g = obj;
            this.f693h = obj;
            this.f694i = obj;
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$b */
    public static class C0135b extends RuntimeException {
        public C0135b(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$c */
    public interface C0136c {
    }

    public Fragment() {
        mo779A();
    }

    /* renamed from: A */
    public final void mo779A() {
        this.f658S = new C1785t9(this);
        this.f661V = new C1243nb(this);
        this.f658S.mo5201a(new C1491q9() {
            /* renamed from: d */
            public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
                View view;
                if (aVar == C1409p9.C1410a.ON_STOP && (view = Fragment.this.f647H) != null) {
                    view.cancelPendingInputEvents();
                }
            }
        });
    }

    /* renamed from: B */
    public final boolean mo780B() {
        return this.f680v != null && this.f672n;
    }

    /* renamed from: C */
    public boolean mo781C() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return false;
        }
        return aVar.f696k;
    }

    /* renamed from: D */
    public final boolean mo782D() {
        return this.f678t > 0;
    }

    /* renamed from: E */
    public void mo783E(Bundle bundle) {
        this.f645F = true;
    }

    /* renamed from: F */
    public void mo784F(Context context) {
        this.f645F = true;
        C1097l8 l8Var = this.f680v;
        if ((l8Var == null ? null : l8Var.f3847d) != null) {
            this.f645F = false;
            this.f645F = true;
        }
    }

    /* renamed from: G */
    public void mo785G(Bundle bundle) {
        Parcelable parcelable;
        boolean z = true;
        this.f645F = true;
        if (!(bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null)) {
            this.f681w.mo4787m0(parcelable);
            this.f681w.mo4794p();
        }
        C1230n8 n8Var = this.f681w;
        if (n8Var.f4229r < 1) {
            z = false;
        }
        if (!z) {
            n8Var.mo4794p();
        }
    }

    /* renamed from: H */
    public View mo85H(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    /* renamed from: I */
    public void mo786I() {
        this.f645F = true;
    }

    /* renamed from: J */
    public void mo787J() {
        this.f645F = true;
    }

    /* renamed from: K */
    public void mo788K() {
        this.f645F = true;
    }

    /* renamed from: L */
    public LayoutInflater mo789L(Bundle bundle) {
        C1097l8 l8Var = this.f680v;
        if (l8Var != null) {
            LayoutInflater j = l8Var.mo3901j();
            C1230n8 n8Var = this.f681w;
            Objects.requireNonNull(n8Var);
            C1401p4.m4347X(j, n8Var);
            return j;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    /* renamed from: M */
    public void mo790M(AttributeSet attributeSet, Bundle bundle) {
        this.f645F = true;
        C1097l8 l8Var = this.f680v;
        if ((l8Var == null ? null : l8Var.f3847d) != null) {
            this.f645F = false;
            this.f645F = true;
        }
    }

    /* renamed from: N */
    public void mo86N(int i, String[] strArr, int[] iArr) {
    }

    /* renamed from: O */
    public void mo791O(Bundle bundle) {
    }

    /* renamed from: P */
    public void mo792P() {
        this.f645F = true;
    }

    /* renamed from: Q */
    public void mo793Q() {
        this.f645F = true;
    }

    /* renamed from: R */
    public void mo87R(View view, Bundle bundle) {
    }

    /* renamed from: S */
    public void mo794S(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f681w.mo4777h0();
        boolean z = true;
        this.f677s = true;
        this.f659T = new C0740g9();
        View H = mo85H(layoutInflater, viewGroup, bundle);
        this.f647H = H;
        if (H != null) {
            C0740g9 g9Var = this.f659T;
            if (g9Var.f2852d == null) {
                g9Var.f2852d = new C1785t9(g9Var);
            }
            this.f660U.mo3912g(this.f659T);
            return;
        }
        if (this.f659T.f2852d == null) {
            z = false;
        }
        if (!z) {
            this.f659T = null;
            return;
        }
        throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    }

    /* renamed from: T */
    public LayoutInflater mo795T(Bundle bundle) {
        LayoutInflater L = mo789L(bundle);
        this.f655P = L;
        return L;
    }

    /* renamed from: U */
    public void mo796U() {
        this.f645F = true;
        this.f681w.mo4800s();
    }

    /* renamed from: V */
    public boolean mo797V(Menu menu) {
        if (!this.f641B) {
            return false | this.f681w.mo4753M(menu);
        }
        return false;
    }

    /* renamed from: W */
    public final Context mo798W() {
        Context l = mo817l();
        if (l != null) {
            return l;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " not attached to a context."));
    }

    /* renamed from: X */
    public final C1166m8 mo799X() {
        C1230n8 n8Var = this.f679u;
        if (n8Var != null) {
            return n8Var;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " not associated with a fragment manager."));
    }

    /* renamed from: Y */
    public final View mo800Y() {
        View view = this.f647H;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    /* renamed from: Z */
    public void mo801Z(View view) {
        mo808f().f686a = view;
    }

    /* renamed from: a */
    public C1409p9 mo150a() {
        return this.f658S;
    }

    /* renamed from: a0 */
    public void mo802a0(Animator animator) {
        mo808f().f687b = animator;
    }

    /* renamed from: b0 */
    public void mo803b0(Bundle bundle) {
        C1230n8 n8Var = this.f679u;
        if (n8Var != null) {
            if (n8Var == null ? false : n8Var.mo4767a0()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f667i = bundle;
    }

    /* renamed from: c0 */
    public void mo804c0(boolean z) {
        mo808f().f696k = z;
    }

    /* renamed from: d */
    public final C1171mb mo152d() {
        return this.f661V.f4259b;
    }

    /* renamed from: d0 */
    public void mo805d0(boolean z) {
        if (this.f644E != z) {
            this.f644E = z;
        }
    }

    /* renamed from: e0 */
    public void mo806e0(int i) {
        if (this.f651L != null || i != 0) {
            mo808f().f689d = i;
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /* renamed from: f */
    public final C0134a mo808f() {
        if (this.f651L == null) {
            this.f651L = new C0134a();
        }
        return this.f651L;
    }

    /* renamed from: f0 */
    public void mo809f0(C0136c cVar) {
        mo808f();
        C0136c cVar2 = this.f651L.f695j;
        if (cVar != cVar2) {
            if (cVar != null && cVar2 != null) {
                throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
            } else if (cVar != null) {
                ((C1230n8.C1240j) cVar).f4254c++;
            }
        }
    }

    /* renamed from: g */
    public C0615ea mo153g() {
        C1230n8 n8Var = this.f679u;
        if (n8Var != null) {
            C1723s8 s8Var = n8Var.f4215H;
            C0615ea eaVar = s8Var.f5692d.get(this.f666h);
            if (eaVar != null) {
                return eaVar;
            }
            C0615ea eaVar2 = new C0615ea();
            s8Var.f5692d.put(this.f666h, eaVar2);
            return eaVar2;
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    @Deprecated
    /* renamed from: g0 */
    public void mo810g0(boolean z) {
        if (!this.f650K && z && this.f662d < 3 && this.f679u != null && mo780B() && this.f656Q) {
            this.f679u.mo4779i0(this);
        }
        this.f650K = z;
        this.f649J = this.f662d < 3 && !z;
        if (this.f663e != null) {
            this.f665g = Boolean.valueOf(z);
        }
    }

    /* renamed from: h */
    public final C0816h8 mo811h() {
        C1097l8 l8Var = this.f680v;
        if (l8Var == null) {
            return null;
        }
        return (C0816h8) l8Var.f3847d;
    }

    /* renamed from: h0 */
    public void mo812h0(@SuppressLint({"UnknownNullness"}) Intent intent) {
        C1097l8 l8Var = this.f680v;
        if (l8Var != null) {
            l8Var.mo3906o(this, intent, -1, (Bundle) null);
            return;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " not attached to Activity"));
    }

    public final int hashCode() {
        return super.hashCode();
    }

    /* renamed from: i */
    public View mo814i() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        return aVar.f686a;
    }

    /* renamed from: j */
    public Animator mo815j() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        return aVar.f687b;
    }

    /* renamed from: k */
    public final C1166m8 mo816k() {
        if (this.f680v != null) {
            return this.f681w;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " has not been attached yet."));
    }

    /* renamed from: l */
    public Context mo817l() {
        C1097l8 l8Var = this.f680v;
        if (l8Var == null) {
            return null;
        }
        return l8Var.f3848e;
    }

    /* renamed from: m */
    public Object mo818m() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    /* renamed from: n */
    public void mo819n() {
        C0134a aVar = this.f651L;
        if (aVar != null) {
            Objects.requireNonNull(aVar);
        }
    }

    /* renamed from: o */
    public Object mo820o() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f645F = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        C0816h8 h = mo811h();
        if (h != null) {
            h.onCreateContextMenu(contextMenu, view, contextMenuInfo);
            return;
        }
        throw new IllegalStateException(C1012kd.m3201j("Fragment ", this, " not attached to an activity."));
    }

    public void onLowMemory() {
        this.f645F = true;
    }

    /* renamed from: p */
    public final LayoutInflater mo824p() {
        LayoutInflater layoutInflater = this.f655P;
        return layoutInflater == null ? mo795T((Bundle) null) : layoutInflater;
    }

    /* renamed from: q */
    public int mo825q() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f689d;
    }

    /* renamed from: r */
    public int mo826r() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f690e;
    }

    /* renamed from: s */
    public int mo827s() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f691f;
    }

    /* renamed from: t */
    public Object mo828t() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f693h;
        if (obj != f639W) {
            return obj;
        }
        mo820o();
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        C1401p4.m4350a(this, sb);
        sb.append(" (");
        sb.append(this.f666h);
        sb.append(")");
        if (this.f683y != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f683y));
        }
        if (this.f640A != null) {
            sb.append(" ");
            sb.append(this.f640A);
        }
        sb.append('}');
        return sb.toString();
    }

    /* renamed from: u */
    public final Resources mo830u() {
        return mo798W().getResources();
    }

    /* renamed from: v */
    public Object mo831v() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f692g;
        if (obj != f639W) {
            return obj;
        }
        mo818m();
        return null;
    }

    /* renamed from: w */
    public Object mo832w() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    /* renamed from: x */
    public Object mo833x() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f694i;
        if (obj != f639W) {
            return obj;
        }
        mo832w();
        return null;
    }

    /* renamed from: y */
    public int mo834y() {
        C0134a aVar = this.f651L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f688c;
    }

    /* renamed from: z */
    public final String mo835z(int i) {
        return mo830u().getString(i);
    }
}
