package androidx.savedstate;

import java.util.Objects;
import p000.C1409p9;

public class SavedStateRegistry$1 implements C1491q9 {

    /* renamed from: a */
    public final /* synthetic */ C1171mb f1002a;

    public SavedStateRegistry$1(C1171mb mbVar) {
        this.f1002a = mbVar;
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        if (aVar == C1409p9.C1410a.ON_START || aVar == C1409p9.C1410a.ON_STOP) {
            Objects.requireNonNull(this.f1002a);
        }
    }
}
