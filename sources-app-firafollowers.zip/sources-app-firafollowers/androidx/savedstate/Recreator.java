package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import p000.C1171mb;
import p000.C1409p9;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements C1491q9 {

    /* renamed from: a */
    public final C1324ob f1001a;

    public Recreator(C1324ob obVar) {
        this.f1001a = obVar;
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        if (aVar == C1409p9.C1410a.ON_CREATE) {
            ((C1785t9) s9Var.mo150a()).f5890a.mo4711d(this);
            C1171mb d = this.f1001a.mo152d();
            if (d.f4023c) {
                Bundle bundle = d.f4022b;
                Bundle bundle2 = null;
                if (bundle != null) {
                    Bundle bundle3 = bundle.getBundle("androidx.savedstate.Restarter");
                    d.f4022b.remove("androidx.savedstate.Restarter");
                    if (d.f4022b.isEmpty()) {
                        d.f4022b = null;
                    }
                    bundle2 = bundle3;
                }
                if (bundle2 != null) {
                    ArrayList<String> stringArrayList = bundle2.getStringArrayList("classes_to_restore");
                    if (stringArrayList != null) {
                        Iterator<String> it = stringArrayList.iterator();
                        while (it.hasNext()) {
                            String next = it.next();
                            try {
                                Class<? extends U> asSubclass = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(C1171mb.C1172a.class);
                                try {
                                    Constructor<? extends U> declaredConstructor = asSubclass.getDeclaredConstructor(new Class[0]);
                                    declaredConstructor.setAccessible(true);
                                    try {
                                        ((C1171mb.C1172a) declaredConstructor.newInstance(new Object[0])).mo4603a(this.f1001a);
                                    } catch (Exception e) {
                                        throw new RuntimeException(C1012kd.m3202k("Failed to instantiate ", next), e);
                                    }
                                } catch (NoSuchMethodException e2) {
                                    StringBuilder d2 = C1012kd.m3195d("Class");
                                    d2.append(asSubclass.getSimpleName());
                                    d2.append(" must have default constructor in order to be automatically recreated");
                                    throw new IllegalStateException(d2.toString(), e2);
                                }
                            } catch (ClassNotFoundException e3) {
                                throw new RuntimeException(C1012kd.m3203l("Class ", next, " wasn't found"), e3);
                            }
                        }
                        return;
                    }
                    throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
                }
                return;
            }
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
