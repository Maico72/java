package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import java.util.Objects;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C0684fd fdVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f594a;
        if (fdVar.mo3562i(1)) {
            obj = fdVar.mo3568o();
        }
        remoteActionCompat.f594a = (IconCompat) obj;
        CharSequence charSequence = remoteActionCompat.f595b;
        if (fdVar.mo3562i(2)) {
            charSequence = fdVar.mo3561h();
        }
        remoteActionCompat.f595b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f596c;
        if (fdVar.mo3562i(3)) {
            charSequence2 = fdVar.mo3561h();
        }
        remoteActionCompat.f596c = charSequence2;
        remoteActionCompat.f597d = (PendingIntent) fdVar.mo3566m(remoteActionCompat.f597d, 4);
        boolean z = remoteActionCompat.f598e;
        if (fdVar.mo3562i(5)) {
            z = fdVar.mo3559f();
        }
        remoteActionCompat.f598e = z;
        boolean z2 = remoteActionCompat.f599f;
        if (fdVar.mo3562i(6)) {
            z2 = fdVar.mo3559f();
        }
        remoteActionCompat.f599f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, C0684fd fdVar) {
        Objects.requireNonNull(fdVar);
        IconCompat iconCompat = remoteActionCompat.f594a;
        fdVar.mo3569p(1);
        fdVar.mo3576w(iconCompat);
        CharSequence charSequence = remoteActionCompat.f595b;
        fdVar.mo3569p(2);
        fdVar.mo3572s(charSequence);
        CharSequence charSequence2 = remoteActionCompat.f596c;
        fdVar.mo3569p(3);
        fdVar.mo3572s(charSequence2);
        PendingIntent pendingIntent = remoteActionCompat.f597d;
        fdVar.mo3569p(4);
        fdVar.mo3574u(pendingIntent);
        boolean z = remoteActionCompat.f598e;
        fdVar.mo3569p(5);
        fdVar.mo3570q(z);
        boolean z2 = remoteActionCompat.f599f;
        fdVar.mo3569p(6);
        fdVar.mo3570q(z2);
    }
}
