package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements C0828hd {

    /* renamed from: a */
    public IconCompat f594a;

    /* renamed from: b */
    public CharSequence f595b;

    /* renamed from: c */
    public CharSequence f596c;

    /* renamed from: d */
    public PendingIntent f597d;

    /* renamed from: e */
    public boolean f598e;

    /* renamed from: f */
    public boolean f599f;
}
