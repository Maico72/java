package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import java.nio.charset.Charset;
import java.util.Objects;
import p002io.github.inflationx.calligraphy3.CalligraphyConfig;

public class IconCompatParcelizer {
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static androidx.core.graphics.drawable.IconCompat read(p000.C0684fd r4) {
        /*
            androidx.core.graphics.drawable.IconCompat r0 = new androidx.core.graphics.drawable.IconCompat
            r0.<init>()
            int r1 = r0.f601a
            r2 = 1
            int r1 = r4.mo3564k(r1, r2)
            r0.f601a = r1
            byte[] r1 = r0.f603c
            r2 = 2
            boolean r2 = r4.mo3562i(r2)
            if (r2 != 0) goto L_0x0018
            goto L_0x001c
        L_0x0018:
            byte[] r1 = r4.mo3560g()
        L_0x001c:
            r0.f603c = r1
            android.os.Parcelable r1 = r0.f604d
            r2 = 3
            android.os.Parcelable r1 = r4.mo3566m(r1, r2)
            r0.f604d = r1
            int r1 = r0.f605e
            r3 = 4
            int r1 = r4.mo3564k(r1, r3)
            r0.f605e = r1
            int r1 = r0.f606f
            r3 = 5
            int r1 = r4.mo3564k(r1, r3)
            r0.f606f = r1
            android.content.res.ColorStateList r1 = r0.f607g
            r3 = 6
            android.os.Parcelable r1 = r4.mo3566m(r1, r3)
            android.content.res.ColorStateList r1 = (android.content.res.ColorStateList) r1
            r0.f607g = r1
            java.lang.String r1 = r0.f609i
            r3 = 7
            boolean r3 = r4.mo3562i(r3)
            if (r3 != 0) goto L_0x004e
            goto L_0x0052
        L_0x004e:
            java.lang.String r1 = r4.mo3567n()
        L_0x0052:
            r0.f609i = r1
            android.graphics.PorterDuff$Mode r4 = android.graphics.PorterDuff.Mode.valueOf(r1)
            r0.f608h = r4
            int r4 = r0.f601a
            switch(r4) {
                case -1: goto L_0x0087;
                case 0: goto L_0x005f;
                case 1: goto L_0x0075;
                case 2: goto L_0x0065;
                case 3: goto L_0x0060;
                case 4: goto L_0x0065;
                case 5: goto L_0x0075;
                case 6: goto L_0x0065;
                default: goto L_0x005f;
            }
        L_0x005f:
            goto L_0x0096
        L_0x0060:
            byte[] r4 = r0.f603c
            r0.f602b = r4
            goto L_0x0096
        L_0x0065:
            java.lang.String r4 = new java.lang.String
            byte[] r1 = r0.f603c
            java.lang.String r2 = "UTF-16"
            java.nio.charset.Charset r2 = java.nio.charset.Charset.forName(r2)
            r4.<init>(r1, r2)
            r0.f602b = r4
            goto L_0x0096
        L_0x0075:
            android.os.Parcelable r4 = r0.f604d
            if (r4 == 0) goto L_0x007a
            goto L_0x008b
        L_0x007a:
            byte[] r4 = r0.f603c
            r0.f602b = r4
            r0.f601a = r2
            r1 = 0
            r0.f605e = r1
            int r4 = r4.length
            r0.f606f = r4
            goto L_0x0096
        L_0x0087:
            android.os.Parcelable r4 = r0.f604d
            if (r4 == 0) goto L_0x008e
        L_0x008b:
            r0.f602b = r4
            goto L_0x0096
        L_0x008e:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Invalid icon"
            r4.<init>(r0)
            throw r4
        L_0x0096:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.read(fd):androidx.core.graphics.drawable.IconCompat");
    }

    public static void write(IconCompat iconCompat, C0684fd fdVar) {
        Objects.requireNonNull(fdVar);
        iconCompat.f609i = iconCompat.f608h.name();
        switch (iconCompat.f601a) {
            case CalligraphyConfig.Builder.INVALID_ATTR_ID /*-1*/:
            case 1:
            case 5:
                iconCompat.f604d = (Parcelable) iconCompat.f602b;
                break;
            case 2:
                iconCompat.f603c = ((String) iconCompat.f602b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f603c = (byte[]) iconCompat.f602b;
                break;
            case 4:
            case 6:
                iconCompat.f603c = iconCompat.f602b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f601a;
        if (-1 != i) {
            fdVar.mo3569p(1);
            fdVar.mo3573t(i);
        }
        byte[] bArr = iconCompat.f603c;
        if (bArr != null) {
            fdVar.mo3569p(2);
            fdVar.mo3571r(bArr);
        }
        Parcelable parcelable = iconCompat.f604d;
        if (parcelable != null) {
            fdVar.mo3569p(3);
            fdVar.mo3574u(parcelable);
        }
        int i2 = iconCompat.f605e;
        if (i2 != 0) {
            fdVar.mo3569p(4);
            fdVar.mo3573t(i2);
        }
        int i3 = iconCompat.f606f;
        if (i3 != 0) {
            fdVar.mo3569p(5);
            fdVar.mo3573t(i3);
        }
        ColorStateList colorStateList = iconCompat.f607g;
        if (colorStateList != null) {
            fdVar.mo3569p(6);
            fdVar.mo3574u(colorStateList);
        }
        String str = iconCompat.f609i;
        if (str != null) {
            fdVar.mo3569p(7);
            fdVar.mo3575v(str);
        }
    }
}
