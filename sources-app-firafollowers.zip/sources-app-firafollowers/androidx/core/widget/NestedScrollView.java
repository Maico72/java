package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p000.C1226n7;

public class NestedScrollView extends FrameLayout implements C1846u6, C1486q6 {

    /* renamed from: D */
    public static final C0129a f610D = new C0129a();

    /* renamed from: E */
    public static final int[] f611E = {16843130};

    /* renamed from: A */
    public final C1720s6 f612A;

    /* renamed from: B */
    public float f613B;

    /* renamed from: C */
    public C0130b f614C;

    /* renamed from: d */
    public long f615d;

    /* renamed from: e */
    public final Rect f616e = new Rect();

    /* renamed from: f */
    public OverScroller f617f = new OverScroller(getContext());

    /* renamed from: g */
    public EdgeEffect f618g;

    /* renamed from: h */
    public EdgeEffect f619h;

    /* renamed from: i */
    public int f620i;

    /* renamed from: j */
    public boolean f621j = true;

    /* renamed from: k */
    public boolean f622k = false;

    /* renamed from: l */
    public View f623l = null;

    /* renamed from: m */
    public boolean f624m = false;

    /* renamed from: n */
    public VelocityTracker f625n;

    /* renamed from: o */
    public boolean f626o;

    /* renamed from: p */
    public boolean f627p = true;

    /* renamed from: q */
    public int f628q;

    /* renamed from: r */
    public int f629r;

    /* renamed from: s */
    public int f630s;

    /* renamed from: t */
    public int f631t = -1;

    /* renamed from: u */
    public final int[] f632u = new int[2];

    /* renamed from: v */
    public final int[] f633v = new int[2];

    /* renamed from: w */
    public int f634w;

    /* renamed from: x */
    public int f635x;

    /* renamed from: y */
    public C0131c f636y;

    /* renamed from: z */
    public final C1982w6 f637z;

    /* renamed from: androidx.core.widget.NestedScrollView$a */
    public static class C0129a extends C1163m6 {
        /* renamed from: c */
        public void mo772c(View view, AccessibilityEvent accessibilityEvent) {
            this.f4001a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            accessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
        }

        /* renamed from: d */
        public void mo773d(View view, C1226n7 n7Var) {
            int scrollRange;
            this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            n7Var.f4196a.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                n7Var.f4196a.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    n7Var.mo4732a(C1226n7.C1227a.f4198e);
                    n7Var.mo4732a(C1226n7.C1227a.f4199f);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    n7Var.mo4732a(C1226n7.C1227a.f4197d);
                    n7Var.mo4732a(C1226n7.C1227a.f4200g);
                }
            }
        }

        /* renamed from: g */
        public boolean mo774g(View view, int i, Bundle bundle) {
            int min;
            if (super.mo774g(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i != 4096) {
                if (i == 8192 || i == 16908344) {
                    min = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (min == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.mo702C(0 - nestedScrollView.getScrollX(), min - nestedScrollView.getScrollY(), 250, true);
                    return true;
                } else if (i != 16908346) {
                    return false;
                }
            }
            min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (min == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.mo702C(0 - nestedScrollView.getScrollX(), min - nestedScrollView.getScrollY(), 250, true);
            return true;
        }
    }

    /* renamed from: androidx.core.widget.NestedScrollView$b */
    public interface C0130b {
    }

    /* renamed from: androidx.core.widget.NestedScrollView$c */
    public static class C0131c extends View.BaseSavedState {
        public static final Parcelable.Creator<C0131c> CREATOR = new C0132a();

        /* renamed from: d */
        public int f638d;

        /* renamed from: androidx.core.widget.NestedScrollView$c$a */
        public class C0132a implements Parcelable.Creator<C0131c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0131c(parcel);
            }

            public Object[] newArray(int i) {
                return new C0131c[i];
            }
        }

        public C0131c(Parcel parcel) {
            super(parcel);
            this.f638d = parcel.readInt();
        }

        public C0131c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("HorizontalScrollView.SavedState{");
            d.append(Integer.toHexString(System.identityHashCode(this)));
            d.append(" scrollPosition=");
            d.append(this.f638d);
            d.append("}");
            return d.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f638d);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f628q = viewConfiguration.getScaledTouchSlop();
        this.f629r = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f630s = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f611E, 0, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f637z = new C1982w6();
        this.f612A = new C1720s6(this);
        setNestedScrollingEnabled(true);
        C0010a7.m43p(this, f610D);
    }

    /* renamed from: d */
    public static int m298d(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f613B == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f613B = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f613B;
    }

    /* renamed from: t */
    public static boolean m299t(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m299t((View) parent, view2);
    }

    /* renamed from: A */
    public final boolean mo700A(int i, int i2, int i3) {
        boolean z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        int height = getHeight();
        int scrollY = getScrollY();
        int i7 = height + scrollY;
        boolean z2 = i4 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i8 = 0; i8 < size; i8++) {
            View view2 = (View) focusables.get(i8);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i5 < bottom && top < i6) {
                boolean z4 = i5 < top && bottom < i6;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i5 < scrollY || i6 > i7) {
            mo726g(z2 ? i5 - scrollY : i6 - i7);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i4);
        }
        return z;
    }

    /* renamed from: B */
    public final void mo701B(View view) {
        view.getDrawingRect(this.f616e);
        offsetDescendantRectToMyCoords(view, this.f616e);
        int e = mo724e(this.f616e);
        if (e != 0) {
            scrollBy(0, e);
        }
    }

    /* renamed from: C */
    public final void mo702C(int i, int i2, int i3, boolean z) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f615d > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f617f;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, i3);
                mo771z(z);
            } else {
                if (!this.f617f.isFinished()) {
                    mo709b();
                }
                scrollBy(i, i2);
            }
            this.f615d = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: D */
    public boolean mo703D(int i, int i2) {
        return this.f612A.mo5818j(i, i2);
    }

    /* renamed from: a */
    public void mo704a(int i) {
        this.f612A.mo5819k(i);
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    /* renamed from: b */
    public final void mo709b() {
        this.f617f.abortAnimation();
        this.f612A.mo5819k(1);
    }

    /* renamed from: c */
    public boolean mo710c(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !mo766u(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            mo726g(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.f616e);
            offsetDescendantRectToMyCoords(findNextFocus, this.f616e);
            mo726g(mo724e(this.f616e));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && (!mo766u(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.f617f.isFinished()) {
            this.f617f.computeScrollOffset();
            int currY = this.f617f.getCurrY();
            int i = currY - this.f635x;
            this.f635x = currY;
            int[] iArr = this.f633v;
            boolean z = false;
            iArr[1] = 0;
            mo725f(0, i, iArr, (int[]) null, 1);
            int i2 = i - this.f633v[1];
            int scrollRange = getScrollRange();
            if (i2 != 0) {
                int scrollY = getScrollY();
                mo769x(0, i2, getScrollX(), scrollY, 0, scrollRange, 0, 0);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i2 - scrollY2;
                int[] iArr2 = this.f633v;
                iArr2[1] = 0;
                this.f612A.mo5814f(0, scrollY2, 0, i3, this.f632u, 1, iArr2);
                i2 = i3 - this.f633v[1];
            }
            if (i2 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    z = true;
                }
                if (z) {
                    mo735l();
                    if (i2 < 0) {
                        if (this.f618g.isFinished()) {
                            edgeEffect = this.f618g;
                        }
                    } else if (this.f619h.isFinished()) {
                        edgeEffect = this.f619h;
                    }
                    edgeEffect.onAbsorb((int) this.f617f.getCurrVelocity());
                }
                mo709b();
            }
            if (!this.f617f.isFinished()) {
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                postInvalidateOnAnimation();
                return;
            }
            this.f612A.mo5819k(1);
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo750p(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f612A.mo5809a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f612A.mo5810b(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return mo725f(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f612A.mo5813e(i, i2, i3, i4, iArr);
    }

    public void draw(Canvas canvas) {
        int i;
        int i2 = Build.VERSION.SDK_INT;
        super.draw(canvas);
        if (this.f618g != null) {
            int scrollY = getScrollY();
            int i3 = 0;
            if (!this.f618g.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (i2 < 21 || getClipToPadding()) {
                    width -= getPaddingRight() + getPaddingLeft();
                    i = getPaddingLeft() + 0;
                } else {
                    i = 0;
                }
                if (i2 >= 21 && getClipToPadding()) {
                    height -= getPaddingBottom() + getPaddingTop();
                    min += getPaddingTop();
                }
                canvas.translate((float) i, (float) min);
                this.f618g.setSize(width, height);
                if (this.f618g.draw(canvas)) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    postInvalidateOnAnimation();
                }
                canvas.restoreToCount(save);
            }
            if (!this.f619h.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(getScrollRange(), scrollY) + height2;
                if (i2 < 21 || getClipToPadding()) {
                    width2 -= getPaddingRight() + getPaddingLeft();
                    i3 = 0 + getPaddingLeft();
                }
                if (i2 >= 21 && getClipToPadding()) {
                    height2 -= getPaddingBottom() + getPaddingTop();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i3 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f619h.setSize(width2, height2);
                if (this.f619h.draw(canvas)) {
                    WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                    postInvalidateOnAnimation();
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public int mo724e(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i3 = rect.bottom;
        if (i3 > i2 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i2) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        } else if (rect.top >= scrollY || i3 >= i2) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    /* renamed from: f */
    public boolean mo725f(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.f612A.mo5811c(i, i2, iArr, iArr2, i3);
    }

    /* renamed from: g */
    public final void mo726g(int i) {
        if (i == 0) {
            return;
        }
        if (this.f627p) {
            mo702C(0, i, 250, false);
        } else {
            scrollBy(0, i);
        }
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        return this.f637z.mo6429a();
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    /* renamed from: h */
    public void mo262h(View view, View view2, int i, int i2) {
        C1982w6 w6Var = this.f637z;
        if (i2 == 1) {
            w6Var.f6580b = i;
        } else {
            w6Var.f6579a = i;
        }
        mo703D(2, i2);
    }

    public boolean hasNestedScrollingParent() {
        return mo757s(0);
    }

    /* renamed from: i */
    public void mo263i(View view, int i) {
        C1982w6 w6Var = this.f637z;
        if (i == 1) {
            w6Var.f6580b = 0;
        } else {
            w6Var.f6579a = 0;
        }
        mo704a(i);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f612A.f5679d;
    }

    /* renamed from: j */
    public void mo264j(View view, int i, int i2, int[] iArr, int i3) {
        mo725f(i, i2, iArr, (int[]) null, i3);
    }

    /* renamed from: k */
    public final void mo734k() {
        this.f624m = false;
        mo770y();
        this.f612A.mo5819k(0);
        EdgeEffect edgeEffect = this.f618g;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            this.f619h.onRelease();
        }
    }

    /* renamed from: l */
    public final void mo735l() {
        if (getOverScrollMode() == 2) {
            this.f618g = null;
            this.f619h = null;
        } else if (this.f618g == null) {
            Context context = getContext();
            this.f618g = new EdgeEffect(context);
            this.f619h = new EdgeEffect(context);
        }
    }

    /* renamed from: m */
    public void mo267m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        mo767v(i4, i5, iArr);
    }

    public void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    /* renamed from: n */
    public void mo268n(View view, int i, int i2, int i3, int i4, int i5) {
        mo767v(i4, i5, (int[]) null);
    }

    /* renamed from: o */
    public boolean mo269o(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f622k = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.f624m) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    scrollRange = 0;
                } else if (verticalScrollFactorCompat <= scrollRange) {
                    scrollRange = verticalScrollFactorCompat;
                }
                if (scrollRange != scrollY) {
                    super.scrollTo(getScrollX(), scrollRange);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00eb  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            r1 = 1
            r2 = 2
            if (r0 != r2) goto L_0x000d
            boolean r3 = r11.f624m
            if (r3 == 0) goto L_0x000d
            return r1
        L_0x000d:
            r0 = r0 & 255(0xff, float:3.57E-43)
            r3 = 0
            if (r0 == 0) goto L_0x00ae
            r4 = -1
            if (r0 == r1) goto L_0x0085
            if (r0 == r2) goto L_0x0024
            r1 = 3
            if (r0 == r1) goto L_0x0085
            r1 = 6
            if (r0 == r1) goto L_0x001f
            goto L_0x0117
        L_0x001f:
            r11.mo768w(r12)
            goto L_0x0117
        L_0x0024:
            int r0 = r11.f631t
            if (r0 != r4) goto L_0x002a
            goto L_0x0117
        L_0x002a:
            int r5 = r12.findPointerIndex(r0)
            if (r5 != r4) goto L_0x004d
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r1 = "Invalid pointerId="
            r12.append(r1)
            r12.append(r0)
            java.lang.String r0 = " in onInterceptTouchEvent"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r12)
            goto L_0x0117
        L_0x004d:
            float r0 = r12.getY(r5)
            int r0 = (int) r0
            int r4 = r11.f620i
            int r4 = r0 - r4
            int r4 = java.lang.Math.abs(r4)
            int r5 = r11.f628q
            if (r4 <= r5) goto L_0x0117
            int r4 = r11.getNestedScrollAxes()
            r2 = r2 & r4
            if (r2 != 0) goto L_0x0117
            r11.f624m = r1
            r11.f620i = r0
            android.view.VelocityTracker r0 = r11.f625n
            if (r0 != 0) goto L_0x0073
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f625n = r0
        L_0x0073:
            android.view.VelocityTracker r0 = r11.f625n
            r0.addMovement(r12)
            r11.f634w = r3
            android.view.ViewParent r12 = r11.getParent()
            if (r12 == 0) goto L_0x0117
            r12.requestDisallowInterceptTouchEvent(r1)
            goto L_0x0117
        L_0x0085:
            r11.f624m = r3
            r11.f631t = r4
            r11.mo770y()
            android.widget.OverScroller r4 = r11.f617f
            int r5 = r11.getScrollX()
            int r6 = r11.getScrollY()
            r7 = 0
            r8 = 0
            r9 = 0
            int r10 = r11.getScrollRange()
            boolean r12 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r12 == 0) goto L_0x00a8
            java.util.WeakHashMap<android.view.View, java.lang.String> r12 = p000.C0010a7.f28a
            r11.postInvalidateOnAnimation()
        L_0x00a8:
            s6 r12 = r11.f612A
            r12.mo5819k(r3)
            goto L_0x0117
        L_0x00ae:
            float r0 = r12.getY()
            int r0 = (int) r0
            float r4 = r12.getX()
            int r4 = (int) r4
            int r5 = r11.getChildCount()
            if (r5 <= 0) goto L_0x00e2
            int r5 = r11.getScrollY()
            android.view.View r6 = r11.getChildAt(r3)
            int r7 = r6.getTop()
            int r7 = r7 - r5
            if (r0 < r7) goto L_0x00e2
            int r7 = r6.getBottom()
            int r7 = r7 - r5
            if (r0 >= r7) goto L_0x00e2
            int r5 = r6.getLeft()
            if (r4 < r5) goto L_0x00e2
            int r5 = r6.getRight()
            if (r4 >= r5) goto L_0x00e2
            r4 = 1
            goto L_0x00e3
        L_0x00e2:
            r4 = 0
        L_0x00e3:
            if (r4 != 0) goto L_0x00eb
            r11.f624m = r3
            r11.mo770y()
            goto L_0x0117
        L_0x00eb:
            r11.f620i = r0
            int r0 = r12.getPointerId(r3)
            r11.f631t = r0
            android.view.VelocityTracker r0 = r11.f625n
            if (r0 != 0) goto L_0x00fe
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f625n = r0
            goto L_0x0101
        L_0x00fe:
            r0.clear()
        L_0x0101:
            android.view.VelocityTracker r0 = r11.f625n
            r0.addMovement(r12)
            android.widget.OverScroller r12 = r11.f617f
            r12.computeScrollOffset()
            android.widget.OverScroller r12 = r11.f617f
            boolean r12 = r12.isFinished()
            r12 = r12 ^ r1
            r11.f624m = r12
            r11.mo703D(r2, r3)
        L_0x0117:
            boolean r12 = r11.f624m
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.f621j = false;
        View view = this.f623l;
        if (view != null && m299t(view, this)) {
            mo701B(this.f623l);
        }
        this.f623l = null;
        if (!this.f622k) {
            if (this.f636y != null) {
                scrollTo(getScrollX(), this.f636y.f638d);
                this.f636y = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int d = m298d(scrollY, paddingTop, i5);
            if (d != scrollY) {
                scrollTo(getScrollX(), d);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f622k = true;
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f626o && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        mo751q((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo725f(i, i2, iArr, (int[]) null, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo767v(i4, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f637z.f6579a = i;
        mo703D(2, 0);
    }

    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        View findNextFocus = rect == null ? instance.findNextFocus(this, (View) null, i) : instance.findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !(true ^ mo766u(findNextFocus, 0, getHeight()))) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0131c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0131c cVar = (C0131c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.f636y = cVar;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0131c cVar = new C0131c(super.onSaveInstanceState());
        cVar.f638d = getScrollY();
        return cVar;
    }

    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        C0130b bVar = this.f614C;
        if (bVar != null) {
            C0726g gVar = (C0726g) bVar;
            AlertController.m141c(this, gVar.f2803a, gVar.f2804b);
        }
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && mo766u(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f616e);
            offsetDescendantRectToMyCoords(findFocus, this.f616e);
            mo726g(mo724e(this.f616e));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.f637z.f6579a = 0;
        mo704a(0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x007d, code lost:
        if (r9.f617f.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x020b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0209, code lost:
        if (r9.f617f.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x020b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            r22 = this;
            r9 = r22
            r10 = r23
            android.view.VelocityTracker r0 = r9.f625n
            if (r0 != 0) goto L_0x000e
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r9.f625n = r0
        L_0x000e:
            int r0 = r23.getActionMasked()
            r11 = 0
            if (r0 != 0) goto L_0x0017
            r9.f634w = r11
        L_0x0017:
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r23)
            int r1 = r9.f634w
            float r1 = (float) r1
            r2 = 0
            r12.offsetLocation(r2, r1)
            r1 = 2
            r13 = 1
            if (r0 == 0) goto L_0x0216
            r3 = -1
            if (r0 == r13) goto L_0x01c9
            if (r0 == r1) goto L_0x0081
            r1 = 3
            if (r0 == r1) goto L_0x005b
            r1 = 5
            if (r0 == r1) goto L_0x0048
            r1 = 6
            if (r0 == r1) goto L_0x0036
            goto L_0x024c
        L_0x0036:
            r22.mo768w(r23)
            int r0 = r9.f631t
            int r0 = r10.findPointerIndex(r0)
            float r0 = r10.getY(r0)
            int r0 = (int) r0
            r9.f620i = r0
            goto L_0x024c
        L_0x0048:
            int r0 = r23.getActionIndex()
            float r1 = r10.getY(r0)
            int r1 = (int) r1
            r9.f620i = r1
            int r0 = r10.getPointerId(r0)
            r9.f631t = r0
            goto L_0x024c
        L_0x005b:
            boolean r0 = r9.f624m
            if (r0 == 0) goto L_0x0210
            int r0 = r22.getChildCount()
            if (r0 <= 0) goto L_0x0210
            android.widget.OverScroller r14 = r9.f617f
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x0210
            goto L_0x020b
        L_0x0081:
            int r0 = r9.f631t
            int r14 = r10.findPointerIndex(r0)
            if (r14 != r3) goto L_0x00a4
            java.lang.String r0 = "Invalid pointerId="
            java.lang.StringBuilder r0 = p000.C1012kd.m3195d(r0)
            int r1 = r9.f631t
            r0.append(r1)
            java.lang.String r1 = " in onTouchEvent"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "NestedScrollView"
            android.util.Log.e(r1, r0)
            goto L_0x024c
        L_0x00a4:
            float r0 = r10.getY(r14)
            int r6 = (int) r0
            int r0 = r9.f620i
            int r0 = r0 - r6
            boolean r1 = r9.f624m
            if (r1 != 0) goto L_0x00ca
            int r1 = java.lang.Math.abs(r0)
            int r2 = r9.f628q
            if (r1 <= r2) goto L_0x00ca
            android.view.ViewParent r1 = r22.getParent()
            if (r1 == 0) goto L_0x00c1
            r1.requestDisallowInterceptTouchEvent(r13)
        L_0x00c1:
            r9.f624m = r13
            int r1 = r9.f628q
            if (r0 <= 0) goto L_0x00c9
            int r0 = r0 - r1
            goto L_0x00ca
        L_0x00c9:
            int r0 = r0 + r1
        L_0x00ca:
            r7 = r0
            boolean r0 = r9.f624m
            if (r0 == 0) goto L_0x024c
            r1 = 0
            int[] r3 = r9.f633v
            int[] r4 = r9.f632u
            r5 = 0
            r0 = r22
            r2 = r7
            boolean r0 = r0.mo725f(r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x00ec
            int[] r0 = r9.f633v
            r0 = r0[r13]
            int r7 = r7 - r0
            int r0 = r9.f634w
            int[] r1 = r9.f632u
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f634w = r0
        L_0x00ec:
            r15 = r7
            int[] r0 = r9.f632u
            r0 = r0[r13]
            int r6 = r6 - r0
            r9.f620i = r6
            int r16 = r22.getScrollY()
            int r8 = r22.getScrollRange()
            int r0 = r22.getOverScrollMode()
            if (r0 == 0) goto L_0x010b
            if (r0 != r13) goto L_0x0107
            if (r8 <= 0) goto L_0x0107
            goto L_0x010b
        L_0x0107:
            r0 = 0
            r17 = 0
            goto L_0x010e
        L_0x010b:
            r0 = 1
            r17 = 1
        L_0x010e:
            r1 = 0
            r3 = 0
            int r4 = r22.getScrollY()
            r5 = 0
            r7 = 0
            r18 = 0
            r0 = r22
            r2 = r15
            r6 = r8
            r21 = r8
            r8 = r18
            boolean r0 = r0.mo769x(r1, r2, r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x0131
            boolean r0 = r9.mo757s(r11)
            if (r0 != 0) goto L_0x0131
            android.view.VelocityTracker r0 = r9.f625n
            r0.clear()
        L_0x0131:
            int r0 = r22.getScrollY()
            int r3 = r0 - r16
            int r5 = r15 - r3
            int[] r8 = r9.f633v
            r8[r13] = r11
            r2 = 0
            r4 = 0
            int[] r6 = r9.f632u
            r7 = 0
            s6 r1 = r9.f612A
            r1.mo5814f(r2, r3, r4, r5, r6, r7, r8)
            int r0 = r9.f620i
            int[] r1 = r9.f632u
            r2 = r1[r13]
            int r0 = r0 - r2
            r9.f620i = r0
            int r0 = r9.f634w
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f634w = r0
            if (r17 == 0) goto L_0x024c
            int[] r0 = r9.f633v
            r0 = r0[r13]
            int r15 = r15 - r0
            r22.mo735l()
            int r0 = r16 + r15
            if (r0 >= 0) goto L_0x0186
            android.widget.EdgeEffect r0 = r9.f618g
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = r10.getX(r14)
            int r3 = r22.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            p000.C1401p4.m4340Q(r0, r1, r2)
            android.widget.EdgeEffect r0 = r9.f619h
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f619h
            goto L_0x01ad
        L_0x0186:
            r1 = r21
            if (r0 <= r1) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f619h
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            r2 = 1065353216(0x3f800000, float:1.0)
            float r3 = r10.getX(r14)
            int r4 = r22.getWidth()
            float r4 = (float) r4
            float r3 = r3 / r4
            float r2 = r2 - r3
            p000.C1401p4.m4340Q(r0, r1, r2)
            android.widget.EdgeEffect r0 = r9.f618g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f618g
        L_0x01ad:
            r0.onRelease()
        L_0x01b0:
            android.widget.EdgeEffect r0 = r9.f618g
            if (r0 == 0) goto L_0x024c
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01c2
            android.widget.EdgeEffect r0 = r9.f619h
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x024c
        L_0x01c2:
            java.util.WeakHashMap<android.view.View, java.lang.String> r0 = p000.C0010a7.f28a
            r22.postInvalidateOnAnimation()
            goto L_0x024c
        L_0x01c9:
            android.view.VelocityTracker r0 = r9.f625n
            r1 = 1000(0x3e8, float:1.401E-42)
            int r4 = r9.f630s
            float r4 = (float) r4
            r0.computeCurrentVelocity(r1, r4)
            int r1 = r9.f631t
            float r0 = r0.getYVelocity(r1)
            int r0 = (int) r0
            int r1 = java.lang.Math.abs(r0)
            int r4 = r9.f629r
            if (r1 < r4) goto L_0x01f1
            int r0 = -r0
            float r1 = (float) r0
            boolean r4 = r9.dispatchNestedPreFling(r2, r1)
            if (r4 != 0) goto L_0x0210
            r9.dispatchNestedFling(r2, r1, r13)
            r9.mo751q(r0)
            goto L_0x0210
        L_0x01f1:
            android.widget.OverScroller r14 = r9.f617f
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x0210
        L_0x020b:
            java.util.WeakHashMap<android.view.View, java.lang.String> r0 = p000.C0010a7.f28a
            r22.postInvalidateOnAnimation()
        L_0x0210:
            r9.f631t = r3
            r22.mo734k()
            goto L_0x024c
        L_0x0216:
            int r0 = r22.getChildCount()
            if (r0 != 0) goto L_0x021d
            return r11
        L_0x021d:
            android.widget.OverScroller r0 = r9.f617f
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r13
            r9.f624m = r0
            if (r0 == 0) goto L_0x0231
            android.view.ViewParent r0 = r22.getParent()
            if (r0 == 0) goto L_0x0231
            r0.requestDisallowInterceptTouchEvent(r13)
        L_0x0231:
            android.widget.OverScroller r0 = r9.f617f
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x023c
            r22.mo709b()
        L_0x023c:
            float r0 = r23.getY()
            int r0 = (int) r0
            r9.f620i = r0
            int r0 = r10.getPointerId(r11)
            r9.f631t = r0
            r9.mo703D(r1, r11)
        L_0x024c:
            android.view.VelocityTracker r0 = r9.f625n
            if (r0 == 0) goto L_0x0253
            r0.addMovement(r12)
        L_0x0253:
            r12.recycle()
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    /* renamed from: p */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo750p(android.view.KeyEvent r7) {
        /*
            r6 = this;
            android.graphics.Rect r0 = r6.f616e
            r0.setEmpty()
            int r0 = r6.getChildCount()
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x0033
            android.view.View r0 = r6.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r3 = (android.widget.FrameLayout.LayoutParams) r3
            int r0 = r0.getHeight()
            int r4 = r3.topMargin
            int r0 = r0 + r4
            int r3 = r3.bottomMargin
            int r0 = r0 + r3
            int r3 = r6.getHeight()
            int r4 = r6.getPaddingTop()
            int r3 = r3 - r4
            int r4 = r6.getPaddingBottom()
            int r3 = r3 - r4
            if (r0 <= r3) goto L_0x0033
            r0 = 1
            goto L_0x0034
        L_0x0033:
            r0 = 0
        L_0x0034:
            r3 = 130(0x82, float:1.82E-43)
            if (r0 != 0) goto L_0x0062
            boolean r0 = r6.isFocused()
            if (r0 == 0) goto L_0x0061
            int r7 = r7.getKeyCode()
            r0 = 4
            if (r7 == r0) goto L_0x0061
            android.view.View r7 = r6.findFocus()
            if (r7 != r6) goto L_0x004c
            r7 = 0
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r7 = r0.findNextFocus(r6, r7, r3)
            if (r7 == 0) goto L_0x005f
            if (r7 == r6) goto L_0x005f
            boolean r7 = r7.requestFocus(r3)
            if (r7 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r1 = 0
        L_0x0060:
            return r1
        L_0x0061:
            return r2
        L_0x0062:
            int r0 = r7.getAction()
            if (r0 != 0) goto L_0x00fb
            int r0 = r7.getKeyCode()
            r4 = 19
            r5 = 33
            if (r0 == r4) goto L_0x00ec
            r4 = 20
            if (r0 == r4) goto L_0x00dc
            r4 = 62
            if (r0 == r4) goto L_0x007c
            goto L_0x00fb
        L_0x007c:
            boolean r7 = r7.isShiftPressed()
            if (r7 == 0) goto L_0x0083
            goto L_0x0085
        L_0x0083:
            r5 = 130(0x82, float:1.82E-43)
        L_0x0085:
            if (r5 != r3) goto L_0x0089
            r7 = 1
            goto L_0x008a
        L_0x0089:
            r7 = 0
        L_0x008a:
            int r0 = r6.getHeight()
            if (r7 == 0) goto L_0x00bf
            android.graphics.Rect r7 = r6.f616e
            int r3 = r6.getScrollY()
            int r3 = r3 + r0
            r7.top = r3
            int r7 = r6.getChildCount()
            if (r7 <= 0) goto L_0x00d1
            int r7 = r7 - r1
            android.view.View r7 = r6.getChildAt(r7)
            android.view.ViewGroup$LayoutParams r1 = r7.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r7 = r7.getBottom()
            int r1 = r1.bottomMargin
            int r7 = r7 + r1
            int r1 = r6.getPaddingBottom()
            int r1 = r1 + r7
            android.graphics.Rect r7 = r6.f616e
            int r3 = r7.top
            int r3 = r3 + r0
            if (r3 <= r1) goto L_0x00d1
            int r1 = r1 - r0
            goto L_0x00cf
        L_0x00bf:
            android.graphics.Rect r7 = r6.f616e
            int r1 = r6.getScrollY()
            int r1 = r1 - r0
            r7.top = r1
            android.graphics.Rect r7 = r6.f616e
            int r1 = r7.top
            if (r1 >= 0) goto L_0x00d1
            r1 = 0
        L_0x00cf:
            r7.top = r1
        L_0x00d1:
            android.graphics.Rect r7 = r6.f616e
            int r1 = r7.top
            int r0 = r0 + r1
            r7.bottom = r0
            r6.mo700A(r5, r1, r0)
            goto L_0x00fb
        L_0x00dc:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00e7
            boolean r2 = r6.mo710c(r3)
            goto L_0x00fb
        L_0x00e7:
            boolean r2 = r6.mo752r(r3)
            goto L_0x00fb
        L_0x00ec:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00f7
            boolean r2 = r6.mo710c(r5)
            goto L_0x00fb
        L_0x00f7:
            boolean r2 = r6.mo752r(r5)
        L_0x00fb:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo750p(android.view.KeyEvent):boolean");
    }

    /* renamed from: q */
    public void mo751q(int i) {
        if (getChildCount() > 0) {
            this.f617f.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            mo771z(true);
        }
    }

    /* renamed from: r */
    public boolean mo752r(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f616e;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f616e.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.f616e;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f616e;
        return mo700A(i, rect3.top, rect3.bottom);
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f621j) {
            mo701B(view2);
        } else {
            this.f623l = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int e = mo724e(rect);
        boolean z2 = e != 0;
        if (z2) {
            if (z) {
                scrollBy(0, e);
            } else {
                mo702C(0, e, 250, false);
            }
        }
        return z2;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            mo770y();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f621j = true;
        super.requestLayout();
    }

    /* renamed from: s */
    public boolean mo757s(int i) {
        return this.f612A.mo5815g(i) != null;
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int d = m298d(i, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int d2 = m298d(i2, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (d != getScrollX() || d2 != getScrollY()) {
                super.scrollTo(d, d2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.f626o) {
            this.f626o = z;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f612A.mo5817i(z);
    }

    public void setOnScrollChangeListener(C0130b bVar) {
        this.f614C = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f627p = z;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return this.f612A.mo5818j(i, 0);
    }

    public void stopNestedScroll() {
        this.f612A.mo5819k(0);
    }

    /* renamed from: u */
    public final boolean mo766u(View view, int i, int i2) {
        view.getDrawingRect(this.f616e);
        offsetDescendantRectToMyCoords(view, this.f616e);
        return this.f616e.bottom + i >= getScrollY() && this.f616e.top - i <= getScrollY() + i2;
    }

    /* renamed from: v */
    public final void mo767v(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f612A.mo5812d(0, scrollY2, 0, i - scrollY2, (int[]) null, i2, iArr);
    }

    /* renamed from: w */
    public final void mo768w(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f631t) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f620i = (int) motionEvent.getY(i);
            this.f631t = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f625n;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0083 A[ADDED_TO_REGION] */
    /* renamed from: x */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo769x(int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20) {
        /*
            r12 = this;
            r0 = r12
            int r1 = r12.getOverScrollMode()
            int r2 = r12.computeHorizontalScrollRange()
            int r3 = r12.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0013
            r2 = 1
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            int r3 = r12.computeVerticalScrollRange()
            int r6 = r12.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = 0
        L_0x0021:
            if (r1 == 0) goto L_0x002a
            if (r1 != r5) goto L_0x0028
            if (r2 == 0) goto L_0x0028
            goto L_0x002a
        L_0x0028:
            r2 = 0
            goto L_0x002b
        L_0x002a:
            r2 = 1
        L_0x002b:
            if (r1 == 0) goto L_0x0034
            if (r1 != r5) goto L_0x0032
            if (r3 == 0) goto L_0x0032
            goto L_0x0034
        L_0x0032:
            r1 = 0
            goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            int r3 = r15 + r13
            if (r2 != 0) goto L_0x003b
            r2 = 0
            goto L_0x003d
        L_0x003b:
            r2 = r19
        L_0x003d:
            int r6 = r16 + r14
            if (r1 != 0) goto L_0x0043
            r1 = 0
            goto L_0x0045
        L_0x0043:
            r1 = r20
        L_0x0045:
            int r7 = -r2
            int r2 = r2 + r17
            int r8 = -r1
            int r1 = r1 + r18
            if (r3 <= r2) goto L_0x0050
            r3 = r2
        L_0x004e:
            r2 = 1
            goto L_0x0055
        L_0x0050:
            if (r3 >= r7) goto L_0x0054
            r3 = r7
            goto L_0x004e
        L_0x0054:
            r2 = 0
        L_0x0055:
            if (r6 <= r1) goto L_0x005a
            r6 = r1
        L_0x0058:
            r1 = 1
            goto L_0x005f
        L_0x005a:
            if (r6 >= r8) goto L_0x005e
            r6 = r8
            goto L_0x0058
        L_0x005e:
            r1 = 0
        L_0x005f:
            if (r1 == 0) goto L_0x007e
            boolean r7 = r12.mo757s(r5)
            if (r7 != 0) goto L_0x007e
            android.widget.OverScroller r7 = r0.f617f
            r8 = 0
            r9 = 0
            r10 = 0
            int r11 = r12.getScrollRange()
            r13 = r7
            r14 = r3
            r15 = r6
            r16 = r8
            r17 = r9
            r18 = r10
            r19 = r11
            r13.springBack(r14, r15, r16, r17, r18, r19)
        L_0x007e:
            r12.onOverScrolled(r3, r6, r2, r1)
            if (r2 != 0) goto L_0x0085
            if (r1 == 0) goto L_0x0086
        L_0x0085:
            r4 = 1
        L_0x0086:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo769x(int, int, int, int, int, int, int, int):boolean");
    }

    /* renamed from: y */
    public final void mo770y() {
        VelocityTracker velocityTracker = this.f625n;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f625n = null;
        }
    }

    /* renamed from: z */
    public final void mo771z(boolean z) {
        if (z) {
            mo703D(2, 1);
        } else {
            this.f612A.mo5819k(1);
        }
        this.f635x = getScrollY();
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        postInvalidateOnAnimation();
    }
}
