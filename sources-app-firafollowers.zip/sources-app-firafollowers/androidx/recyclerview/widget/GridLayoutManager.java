package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Arrays;
import java.util.Objects;
import p000.C0021ab;
import p000.C1226n7;

public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: F */
    public boolean f718F = false;

    /* renamed from: G */
    public int f719G = -1;

    /* renamed from: H */
    public int[] f720H;

    /* renamed from: I */
    public View[] f721I;

    /* renamed from: J */
    public final SparseIntArray f722J = new SparseIntArray();

    /* renamed from: K */
    public final SparseIntArray f723K = new SparseIntArray();

    /* renamed from: L */
    public C0140c f724L = new C0138a();

    /* renamed from: M */
    public final Rect f725M = new Rect();

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$a */
    public static final class C0138a extends C0140c {
    }

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$b */
    public static class C0139b extends RecyclerView.C0167n {

        /* renamed from: h */
        public int f726h = -1;

        /* renamed from: i */
        public int f727i = 0;

        public C0139b(int i, int i2) {
            super(i, i2);
        }

        public C0139b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0139b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0139b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$c */
    public static abstract class C0140c {

        /* renamed from: a */
        public final SparseIntArray f728a = new SparseIntArray();

        /* renamed from: b */
        public final SparseIntArray f729b = new SparseIntArray();

        /* renamed from: a */
        public int mo885a(int i, int i2) {
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                i3++;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = 1;
                }
            }
            return i3 + 1 > i2 ? i4 + 1 : i4;
        }
    }

    public GridLayoutManager(Context context, int i) {
        super(1, false);
        mo857N1(i);
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        mo857N1(RecyclerView.C0162m.m601T(context, attributeSet, i, i2).f884b);
    }

    /* renamed from: B */
    public int mo847B(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (this.f735q == 1) {
            return this.f719G;
        }
        if (wVar.mo1202b() < 1) {
            return 0;
        }
        return mo852I1(sVar, wVar, wVar.mo1202b() - 1) + 1;
    }

    /* renamed from: B1 */
    public void mo848B1(boolean z) {
        if (!z) {
            mo896c((String) null);
            if (this.f741w) {
                this.f741w = false;
                mo1129N0();
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    /* renamed from: F1 */
    public final void mo849F1(int i) {
        int i2;
        int[] iArr = this.f720H;
        int i3 = this.f719G;
        if (!(iArr != null && iArr.length == i3 + 1 && iArr[iArr.length - 1] == i)) {
            iArr = new int[(i3 + 1)];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 <= 0 || i3 - i4 >= i6) {
                i2 = i5;
            } else {
                i2 = i5 + 1;
                i4 -= i3;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.f720H = iArr;
    }

    /* renamed from: G1 */
    public final void mo850G1() {
        View[] viewArr = this.f721I;
        if (viewArr == null || viewArr.length != this.f719G) {
            this.f721I = new View[this.f719G];
        }
    }

    /* renamed from: H1 */
    public int mo851H1(int i, int i2) {
        if (this.f735q != 1 || !mo920s1()) {
            int[] iArr = this.f720H;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.f720H;
        int i3 = this.f719G;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    /* renamed from: I1 */
    public final int mo852I1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, int i) {
        if (!wVar.f912f) {
            return this.f724L.mo885a(i, this.f719G);
        }
        int c = sVar.mo1184c(i);
        if (c != -1) {
            return this.f724L.mo885a(c, this.f719G);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    /* renamed from: J1 */
    public final int mo853J1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, int i) {
        if (!wVar.f912f) {
            C0140c cVar = this.f724L;
            int i2 = this.f719G;
            Objects.requireNonNull(cVar);
            return i % i2;
        }
        int i3 = this.f723K.get(i, -1);
        if (i3 != -1) {
            return i3;
        }
        int c = sVar.mo1184c(i);
        if (c == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 0;
        }
        C0140c cVar2 = this.f724L;
        int i4 = this.f719G;
        Objects.requireNonNull(cVar2);
        return c % i4;
    }

    /* renamed from: K1 */
    public final int mo854K1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, int i) {
        if (!wVar.f912f) {
            Objects.requireNonNull(this.f724L);
            return 1;
        }
        int i2 = this.f722J.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        if (sVar.mo1184c(i) == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 1;
        }
        Objects.requireNonNull(this.f724L);
        return 1;
    }

    /* renamed from: L1 */
    public final void mo855L1(View view, int i, boolean z) {
        int i2;
        int i3;
        C0139b bVar = (C0139b) view.getLayoutParams();
        Rect rect = bVar.f888e;
        int i4 = rect.top + rect.bottom + bVar.topMargin + bVar.bottomMargin;
        int i5 = rect.left + rect.right + bVar.leftMargin + bVar.rightMargin;
        int H1 = mo851H1(bVar.f726h, bVar.f727i);
        if (this.f735q == 1) {
            i2 = RecyclerView.C0162m.m600A(H1, i, i5, bVar.width, false);
            i3 = RecyclerView.C0162m.m600A(this.f737s.mo2981l(), this.f878n, i4, bVar.height, true);
        } else {
            int A = RecyclerView.C0162m.m600A(H1, i, i4, bVar.height, false);
            int A2 = RecyclerView.C0162m.m600A(this.f737s.mo2981l(), this.f877m, i5, bVar.width, true);
            i3 = A;
            i2 = A2;
        }
        mo856M1(view, i2, i3, z);
    }

    /* renamed from: M1 */
    public final void mo856M1(View view, int i, int i2, boolean z) {
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
        if (z ? mo1144Y0(view, i, i2, nVar) : mo1141W0(view, i, i2, nVar)) {
            view.measure(i, i2);
        }
    }

    /* renamed from: N1 */
    public void mo857N1(int i) {
        if (i != this.f719G) {
            this.f718F = true;
            if (i >= 1) {
                this.f719G = i;
                this.f724L.f728a.clear();
                mo1129N0();
                return;
            }
            throw new IllegalArgumentException(C1012kd.m3199h("Span count should be at least 1. Provided ", i));
        }
    }

    /* renamed from: O0 */
    public int mo858O0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        mo859O1();
        mo850G1();
        if (this.f735q == 1) {
            return 0;
        }
        return mo926z1(i, sVar, wVar);
    }

    /* renamed from: O1 */
    public final void mo859O1() {
        int i;
        int i2;
        if (this.f735q == 1) {
            i2 = this.f879o - mo1132Q();
            i = mo1131P();
        } else {
            i2 = this.f880p - mo1130O();
            i = mo1133R();
        }
        mo849F1(i2 - i);
    }

    /* renamed from: Q0 */
    public int mo860Q0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        mo859O1();
        mo850G1();
        if (this.f735q == 0) {
            return 0;
        }
        return mo926z1(i, sVar, wVar);
    }

    /* renamed from: T0 */
    public void mo861T0(Rect rect, int i, int i2) {
        int i3;
        int i4;
        if (this.f720H == null) {
            super.mo861T0(rect, i, i2);
        }
        int Q = mo1132Q() + mo1131P();
        int O = mo1130O() + mo1133R();
        if (this.f735q == 1) {
            i4 = RecyclerView.C0162m.m603h(i2, rect.height() + O, mo1126M());
            int[] iArr = this.f720H;
            i3 = RecyclerView.C0162m.m603h(i, iArr[iArr.length - 1] + Q, mo1128N());
        } else {
            i3 = RecyclerView.C0162m.m603h(i, rect.width() + Q, mo1128N());
            int[] iArr2 = this.f720H;
            i4 = RecyclerView.C0162m.m603h(i2, iArr2[iArr2.length - 1] + O, mo1126M());
        }
        this.f866b.setMeasuredDimension(i3, i4);
    }

    /* renamed from: V */
    public int mo862V(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (this.f735q == 0) {
            return this.f719G;
        }
        if (wVar.mo1202b() < 1) {
            return 0;
        }
        return mo852I1(sVar, wVar, wVar.mo1202b() - 1) + 1;
    }

    /* renamed from: Z0 */
    public boolean mo863Z0() {
        return this.f730A == null && !this.f718F;
    }

    /* renamed from: a1 */
    public void mo864a1(RecyclerView.C0178w wVar, LinearLayoutManager.C0143c cVar, RecyclerView.C0162m.C0165c cVar2) {
        int i = this.f719G;
        for (int i2 = 0; i2 < this.f719G && cVar.mo933b(wVar) && i > 0; i2++) {
            ((C0021ab.C0023b) cVar2).mo73a(cVar.f757d, Math.max(0, cVar.f760g));
            Objects.requireNonNull(this.f724L);
            i--;
            cVar.f757d += cVar.f758e;
        }
    }

    /* renamed from: g */
    public boolean mo865g(RecyclerView.C0167n nVar) {
        return nVar instanceof C0139b;
    }

    /* renamed from: l */
    public int mo866l(RecyclerView.C0178w wVar) {
        return mo897c1(wVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00ca, code lost:
        if (r13 == (r2 > r15)) goto L_0x00cc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x00e6, code lost:
        if (r13 == (r2 > r8)) goto L_0x00e8;
     */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x00f0  */
    /* renamed from: l0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo867l0(android.view.View r23, int r24, androidx.recyclerview.widget.RecyclerView.C0173s r25, androidx.recyclerview.widget.RecyclerView.C0178w r26) {
        /*
            r22 = this;
            r0 = r22
            r1 = r25
            r2 = r26
            android.view.View r3 = r22.mo1162s(r23)
            r4 = 0
            if (r3 != 0) goto L_0x000e
            return r4
        L_0x000e:
            android.view.ViewGroup$LayoutParams r5 = r3.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r5 = (androidx.recyclerview.widget.GridLayoutManager.C0139b) r5
            int r6 = r5.f726h
            int r5 = r5.f727i
            int r5 = r5 + r6
            android.view.View r7 = super.mo867l0(r23, r24, r25, r26)
            if (r7 != 0) goto L_0x0020
            return r4
        L_0x0020:
            r7 = r24
            int r7 = r0.mo900e1(r7)
            r8 = 1
            if (r7 != r8) goto L_0x002b
            r7 = 1
            goto L_0x002c
        L_0x002b:
            r7 = 0
        L_0x002c:
            boolean r10 = r0.f740v
            if (r7 == r10) goto L_0x0032
            r7 = 1
            goto L_0x0033
        L_0x0032:
            r7 = 0
        L_0x0033:
            r10 = -1
            if (r7 == 0) goto L_0x003e
            int r7 = r22.mo1166z()
            int r7 = r7 - r8
            r11 = -1
            r12 = -1
            goto L_0x0045
        L_0x003e:
            int r7 = r22.mo1166z()
            r11 = r7
            r7 = 0
            r12 = 1
        L_0x0045:
            int r13 = r0.f735q
            if (r13 != r8) goto L_0x0051
            boolean r13 = r22.mo920s1()
            if (r13 == 0) goto L_0x0051
            r13 = 1
            goto L_0x0052
        L_0x0051:
            r13 = 0
        L_0x0052:
            int r14 = r0.mo852I1(r1, r2, r7)
            r10 = r7
            r16 = r12
            r8 = -1
            r9 = 0
            r12 = 0
            r15 = -1
            r7 = r4
        L_0x005e:
            if (r10 == r11) goto L_0x0128
            r17 = r11
            int r11 = r0.mo852I1(r1, r2, r10)
            android.view.View r1 = r0.mo1165y(r10)
            if (r1 != r3) goto L_0x006e
            goto L_0x0128
        L_0x006e:
            boolean r18 = r1.hasFocusable()
            if (r18 == 0) goto L_0x0083
            if (r11 == r14) goto L_0x0083
            if (r4 == 0) goto L_0x007a
            goto L_0x0128
        L_0x007a:
            r18 = r3
            r21 = r7
            r19 = r9
            r9 = 0
            goto L_0x0118
        L_0x0083:
            android.view.ViewGroup$LayoutParams r11 = r1.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r11 = (androidx.recyclerview.widget.GridLayoutManager.C0139b) r11
            int r2 = r11.f726h
            r18 = r3
            int r3 = r11.f727i
            int r3 = r3 + r2
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x009b
            if (r2 != r6) goto L_0x009b
            if (r3 != r5) goto L_0x009b
            return r1
        L_0x009b:
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00a3
            if (r4 == 0) goto L_0x00ab
        L_0x00a3:
            boolean r19 = r1.hasFocusable()
            if (r19 != 0) goto L_0x00ae
            if (r7 != 0) goto L_0x00ae
        L_0x00ab:
            r21 = r7
            goto L_0x00cc
        L_0x00ae:
            int r19 = java.lang.Math.max(r2, r6)
            int r20 = java.lang.Math.min(r3, r5)
            r21 = r7
            int r7 = r20 - r19
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00d1
            if (r7 <= r9) goto L_0x00c3
            goto L_0x00cc
        L_0x00c3:
            if (r7 != r9) goto L_0x00ea
            if (r2 <= r15) goto L_0x00c9
            r7 = 1
            goto L_0x00ca
        L_0x00c9:
            r7 = 0
        L_0x00ca:
            if (r13 != r7) goto L_0x00ea
        L_0x00cc:
            r19 = r9
            r7 = 1
            r9 = 0
            goto L_0x00ee
        L_0x00d1:
            if (r4 != 0) goto L_0x00ea
            r19 = r9
            r9 = 0
            boolean r20 = r0.mo1148c0(r1, r9)
            if (r20 == 0) goto L_0x00ed
            if (r7 <= r12) goto L_0x00df
            goto L_0x00e8
        L_0x00df:
            if (r7 != r12) goto L_0x00ed
            if (r2 <= r8) goto L_0x00e5
            r7 = 1
            goto L_0x00e6
        L_0x00e5:
            r7 = 0
        L_0x00e6:
            if (r13 != r7) goto L_0x00ed
        L_0x00e8:
            r7 = 1
            goto L_0x00ee
        L_0x00ea:
            r19 = r9
            r9 = 0
        L_0x00ed:
            r7 = 0
        L_0x00ee:
            if (r7 == 0) goto L_0x0118
            boolean r7 = r1.hasFocusable()
            if (r7 == 0) goto L_0x0109
            int r4 = r11.f726h
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r2 = r3 - r2
            r19 = r2
            r15 = r4
            r7 = r21
            r4 = r1
            goto L_0x011a
        L_0x0109:
            int r7 = r11.f726h
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r12 = r3 - r2
            r8 = r7
            r7 = r1
            goto L_0x011a
        L_0x0118:
            r7 = r21
        L_0x011a:
            int r10 = r10 + r16
            r1 = r25
            r2 = r26
            r11 = r17
            r3 = r18
            r9 = r19
            goto L_0x005e
        L_0x0128:
            r21 = r7
            if (r4 == 0) goto L_0x012d
            goto L_0x012f
        L_0x012d:
            r4 = r21
        L_0x012f:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.mo867l0(android.view.View, int, androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w):android.view.View");
    }

    /* renamed from: m */
    public int mo868m(RecyclerView.C0178w wVar) {
        return mo898d1(wVar);
    }

    /* renamed from: n1 */
    public View mo869n1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, int i, int i2, int i3) {
        mo902f1();
        int k = this.f737s.mo2980k();
        int g = this.f737s.mo2976g();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View y = mo1165y(i);
            int S = mo1135S(y);
            if (S >= 0 && S < i3 && mo853J1(sVar, wVar, S) == 0) {
                if (((RecyclerView.C0167n) y.getLayoutParams()).mo1175t()) {
                    if (view2 == null) {
                        view2 = y;
                    }
                } else if (this.f737s.mo2974e(y) < g && this.f737s.mo2971b(y) >= k) {
                    return y;
                } else {
                    if (view == null) {
                        view = y;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: o */
    public int mo870o(RecyclerView.C0178w wVar) {
        return mo897c1(wVar);
    }

    /* renamed from: p */
    public int mo871p(RecyclerView.C0178w wVar) {
        return mo898d1(wVar);
    }

    /* renamed from: p0 */
    public void mo872p0(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, View view, C1226n7 n7Var) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        int i3;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0139b)) {
            mo1158o0(view, n7Var);
            return;
        }
        C0139b bVar = (C0139b) layoutParams;
        int I1 = mo852I1(sVar, wVar, bVar.mo1173r());
        if (this.f735q == 0) {
            i4 = bVar.f726h;
            i3 = bVar.f727i;
            i = 1;
            z2 = false;
            z = false;
            i2 = I1;
        } else {
            i3 = 1;
            i2 = bVar.f726h;
            i = bVar.f727i;
            z2 = false;
            z = false;
            i4 = I1;
        }
        n7Var.f4196a.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo) C1226n7.C1229c.m3870a(i4, i3, i2, i, z2, z).f4205a);
    }

    /* renamed from: r0 */
    public void mo873r0(RecyclerView recyclerView, int i, int i2) {
        this.f724L.f728a.clear();
        this.f724L.f729b.clear();
    }

    /* renamed from: s0 */
    public void mo874s0(RecyclerView recyclerView) {
        this.f724L.f728a.clear();
        this.f724L.f729b.clear();
    }

    /* renamed from: t0 */
    public void mo875t0(RecyclerView recyclerView, int i, int i2, int i3) {
        this.f724L.f728a.clear();
        this.f724L.f729b.clear();
    }

    /* renamed from: t1 */
    public void mo876t1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, LinearLayoutManager.C0143c cVar, LinearLayoutManager.C0142b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        View c;
        RecyclerView.C0173s sVar2 = sVar;
        RecyclerView.C0178w wVar2 = wVar;
        LinearLayoutManager.C0143c cVar2 = cVar;
        LinearLayoutManager.C0142b bVar2 = bVar;
        int j = this.f737s.mo2979j();
        boolean z = j != 1073741824;
        int i20 = mo1166z() > 0 ? this.f720H[this.f719G] : 0;
        if (z) {
            mo859O1();
        }
        boolean z2 = cVar2.f758e == 1;
        int i21 = this.f719G;
        if (!z2) {
            i21 = mo853J1(sVar2, wVar2, cVar2.f757d) + mo854K1(sVar2, wVar2, cVar2.f757d);
        }
        int i22 = 0;
        while (i22 < this.f719G && cVar2.mo933b(wVar2) && i21 > 0) {
            int i23 = cVar2.f757d;
            int K1 = mo854K1(sVar2, wVar2, i23);
            if (K1 <= this.f719G) {
                i21 -= K1;
                if (i21 < 0 || (c = cVar2.mo934c(sVar2)) == null) {
                    break;
                }
                this.f721I[i22] = c;
                i22++;
            } else {
                throw new IllegalArgumentException("Item at position " + i23 + " requires " + K1 + " spans but GridLayoutManager has only " + this.f719G + " spans.");
            }
        }
        if (i22 == 0) {
            bVar2.f751b = true;
            return;
        }
        if (z2) {
            i3 = i22;
            i4 = 0;
            i2 = 0;
            i = 1;
        } else {
            i4 = i22 - 1;
            i3 = -1;
            i2 = 0;
            i = -1;
        }
        while (i4 != i3) {
            View view = this.f721I[i4];
            C0139b bVar3 = (C0139b) view.getLayoutParams();
            int K12 = mo854K1(sVar2, wVar2, mo1135S(view));
            bVar3.f727i = K12;
            bVar3.f726h = i2;
            i2 += K12;
            i4 += i;
        }
        float f = 0.0f;
        int i24 = 0;
        for (int i25 = 0; i25 < i22; i25++) {
            View view2 = this.f721I[i25];
            if (cVar2.f764k == null) {
                if (z2) {
                    mo1145a(view2);
                } else {
                    mo1147b(view2, 0, false);
                }
            } else if (z2) {
                mo1147b(view2, -1, true);
            } else {
                mo1147b(view2, 0, true);
            }
            mo1149d(view2, this.f725M);
            mo855L1(view2, j, false);
            int c2 = this.f737s.mo2972c(view2);
            if (c2 > i24) {
                i24 = c2;
            }
            float d = (((float) this.f737s.mo2973d(view2)) * 1.0f) / ((float) ((C0139b) view2.getLayoutParams()).f727i);
            if (d > f) {
                f = d;
            }
        }
        if (z) {
            mo849F1(Math.max(Math.round(f * ((float) this.f719G)), i20));
            i24 = 0;
            for (int i26 = 0; i26 < i22; i26++) {
                View view3 = this.f721I[i26];
                mo855L1(view3, 1073741824, true);
                int c3 = this.f737s.mo2972c(view3);
                if (c3 > i24) {
                    i24 = c3;
                }
            }
        }
        for (int i27 = 0; i27 < i22; i27++) {
            View view4 = this.f721I[i27];
            if (this.f737s.mo2972c(view4) != i24) {
                C0139b bVar4 = (C0139b) view4.getLayoutParams();
                Rect rect = bVar4.f888e;
                int i28 = rect.top + rect.bottom + bVar4.topMargin + bVar4.bottomMargin;
                int i29 = rect.left + rect.right + bVar4.leftMargin + bVar4.rightMargin;
                int H1 = mo851H1(bVar4.f726h, bVar4.f727i);
                if (this.f735q == 1) {
                    i19 = RecyclerView.C0162m.m600A(H1, 1073741824, i29, bVar4.width, false);
                    i18 = View.MeasureSpec.makeMeasureSpec(i24 - i28, 1073741824);
                } else {
                    int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i24 - i29, 1073741824);
                    i18 = RecyclerView.C0162m.m600A(H1, 1073741824, i28, bVar4.height, false);
                    i19 = makeMeasureSpec;
                }
                mo856M1(view4, i19, i18, true);
            }
        }
        bVar2.f750a = i24;
        if (this.f735q == 1) {
            if (cVar2.f759f == -1) {
                i8 = cVar2.f755b;
                i17 = i8 - i24;
            } else {
                i17 = cVar2.f755b;
                i8 = i24 + i17;
            }
            i5 = i17;
            i7 = 0;
            i6 = 0;
        } else {
            if (cVar2.f759f == -1) {
                i16 = cVar2.f755b;
                i15 = i16 - i24;
            } else {
                i15 = cVar2.f755b;
                i16 = i24 + i15;
            }
            i6 = i15;
            i5 = 0;
            i7 = i16;
            i8 = 0;
        }
        int i30 = 0;
        while (i30 < i22) {
            View view5 = this.f721I[i30];
            C0139b bVar5 = (C0139b) view5.getLayoutParams();
            if (this.f735q == 1) {
                if (mo920s1()) {
                    i14 = mo1131P() + this.f720H[this.f719G - bVar5.f726h];
                    i13 = i14 - this.f737s.mo2973d(view5);
                } else {
                    i13 = this.f720H[bVar5.f726h] + mo1131P();
                    i14 = this.f737s.mo2973d(view5) + i13;
                }
                i12 = i8;
                i11 = i14;
                i10 = i13;
                i9 = i5;
            } else {
                int R = mo1133R() + this.f720H[bVar5.f726h];
                i9 = R;
                i11 = i7;
                i10 = i6;
                i12 = this.f737s.mo2973d(view5) + R;
            }
            mo1150d0(view5, i10, i9, i11, i12);
            if (bVar5.mo1175t() || bVar5.mo1174s()) {
                bVar2.f752c = true;
            }
            bVar2.f753d |= view5.hasFocusable();
            i30++;
            i8 = i12;
            i7 = i11;
            i6 = i10;
            i5 = i9;
        }
        Arrays.fill(this.f721I, (Object) null);
    }

    /* renamed from: u */
    public RecyclerView.C0167n mo877u() {
        return this.f735q == 0 ? new C0139b(-2, -1) : new C0139b(-1, -2);
    }

    /* renamed from: u0 */
    public void mo878u0(RecyclerView recyclerView, int i, int i2) {
        this.f724L.f728a.clear();
        this.f724L.f729b.clear();
    }

    /* renamed from: u1 */
    public void mo879u1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, LinearLayoutManager.C0141a aVar, int i) {
        mo859O1();
        if (wVar.mo1202b() > 0 && !wVar.f912f) {
            boolean z = i == 1;
            int J1 = mo853J1(sVar, wVar, aVar.f746b);
            if (z) {
                while (J1 > 0) {
                    int i2 = aVar.f746b;
                    if (i2 <= 0) {
                        break;
                    }
                    int i3 = i2 - 1;
                    aVar.f746b = i3;
                    J1 = mo853J1(sVar, wVar, i3);
                }
            } else {
                int b = wVar.mo1202b() - 1;
                int i4 = aVar.f746b;
                while (i4 < b) {
                    int i5 = i4 + 1;
                    int J12 = mo853J1(sVar, wVar, i5);
                    if (J12 <= J1) {
                        break;
                    }
                    i4 = i5;
                    J1 = J12;
                }
                aVar.f746b = i4;
            }
        }
        mo850G1();
    }

    /* renamed from: v */
    public RecyclerView.C0167n mo880v(Context context, AttributeSet attributeSet) {
        return new C0139b(context, attributeSet);
    }

    /* renamed from: w */
    public RecyclerView.C0167n mo881w(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0139b((ViewGroup.MarginLayoutParams) layoutParams) : new C0139b(layoutParams);
    }

    /* renamed from: w0 */
    public void mo882w0(RecyclerView recyclerView, int i, int i2, Object obj) {
        this.f724L.f728a.clear();
        this.f724L.f729b.clear();
    }

    /* renamed from: x0 */
    public void mo883x0(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (wVar.f912f) {
            int z = mo1166z();
            for (int i = 0; i < z; i++) {
                C0139b bVar = (C0139b) mo1165y(i).getLayoutParams();
                int r = bVar.mo1173r();
                this.f722J.put(r, bVar.f727i);
                this.f723K.put(r, bVar.f726h);
            }
        }
        super.mo883x0(sVar, wVar);
        this.f722J.clear();
        this.f723K.clear();
    }

    /* renamed from: y0 */
    public void mo884y0(RecyclerView.C0178w wVar) {
        this.f730A = null;
        this.f743y = -1;
        this.f744z = Integer.MIN_VALUE;
        this.f731B.mo930d();
        this.f718F = false;
    }
}
