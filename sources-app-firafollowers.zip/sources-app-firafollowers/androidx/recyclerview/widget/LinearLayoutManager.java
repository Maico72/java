package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Objects;
import p000.C0021ab;

public class LinearLayoutManager extends RecyclerView.C0162m {

    /* renamed from: A */
    public C0144d f730A = null;

    /* renamed from: B */
    public final C0141a f731B = new C0141a();

    /* renamed from: C */
    public final C0142b f732C = new C0142b();

    /* renamed from: D */
    public int f733D = 2;

    /* renamed from: E */
    public int[] f734E = new int[2];

    /* renamed from: q */
    public int f735q = 1;

    /* renamed from: r */
    public C0143c f736r;

    /* renamed from: s */
    public C0682fb f737s;

    /* renamed from: t */
    public boolean f738t;

    /* renamed from: u */
    public boolean f739u = false;

    /* renamed from: v */
    public boolean f740v = false;

    /* renamed from: w */
    public boolean f741w = false;

    /* renamed from: x */
    public boolean f742x = true;

    /* renamed from: y */
    public int f743y = -1;

    /* renamed from: z */
    public int f744z = Integer.MIN_VALUE;

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$a */
    public static class C0141a {

        /* renamed from: a */
        public C0682fb f745a;

        /* renamed from: b */
        public int f746b;

        /* renamed from: c */
        public int f747c;

        /* renamed from: d */
        public boolean f748d;

        /* renamed from: e */
        public boolean f749e;

        public C0141a() {
            mo930d();
        }

        /* renamed from: a */
        public void mo927a() {
            this.f747c = this.f748d ? this.f745a.mo2976g() : this.f745a.mo2980k();
        }

        /* renamed from: b */
        public void mo928b(View view, int i) {
            if (this.f748d) {
                this.f747c = this.f745a.mo3550m() + this.f745a.mo2971b(view);
            } else {
                this.f747c = this.f745a.mo2974e(view);
            }
            this.f746b = i;
        }

        /* renamed from: c */
        public void mo929c(View view, int i) {
            int i2;
            int m = this.f745a.mo3550m();
            if (m >= 0) {
                mo928b(view, i);
                return;
            }
            this.f746b = i;
            if (this.f748d) {
                int g = (this.f745a.mo2976g() - m) - this.f745a.mo2971b(view);
                this.f747c = this.f745a.mo2976g() - g;
                if (g > 0) {
                    int c = this.f747c - this.f745a.mo2972c(view);
                    int k = this.f745a.mo2980k();
                    int min = c - (Math.min(this.f745a.mo2974e(view) - k, 0) + k);
                    if (min < 0) {
                        i2 = Math.min(g, -min) + this.f747c;
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                int e = this.f745a.mo2974e(view);
                int k2 = e - this.f745a.mo2980k();
                this.f747c = e;
                if (k2 > 0) {
                    int g2 = (this.f745a.mo2976g() - Math.min(0, (this.f745a.mo2976g() - m) - this.f745a.mo2971b(view))) - (this.f745a.mo2972c(view) + e);
                    if (g2 < 0) {
                        i2 = this.f747c - Math.min(k2, -g2);
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f747c = i2;
        }

        /* renamed from: d */
        public void mo930d() {
            this.f746b = -1;
            this.f747c = Integer.MIN_VALUE;
            this.f748d = false;
            this.f749e = false;
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("AnchorInfo{mPosition=");
            d.append(this.f746b);
            d.append(", mCoordinate=");
            d.append(this.f747c);
            d.append(", mLayoutFromEnd=");
            d.append(this.f748d);
            d.append(", mValid=");
            d.append(this.f749e);
            d.append('}');
            return d.toString();
        }
    }

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$b */
    public static class C0142b {

        /* renamed from: a */
        public int f750a;

        /* renamed from: b */
        public boolean f751b;

        /* renamed from: c */
        public boolean f752c;

        /* renamed from: d */
        public boolean f753d;
    }

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$c */
    public static class C0143c {

        /* renamed from: a */
        public boolean f754a = true;

        /* renamed from: b */
        public int f755b;

        /* renamed from: c */
        public int f756c;

        /* renamed from: d */
        public int f757d;

        /* renamed from: e */
        public int f758e;

        /* renamed from: f */
        public int f759f;

        /* renamed from: g */
        public int f760g;

        /* renamed from: h */
        public int f761h = 0;

        /* renamed from: i */
        public int f762i = 0;

        /* renamed from: j */
        public int f763j;

        /* renamed from: k */
        public List<RecyclerView.C0181z> f764k = null;

        /* renamed from: l */
        public boolean f765l;

        /* renamed from: a */
        public void mo932a(View view) {
            int i;
            int r;
            int size = this.f764k.size();
            View view2 = null;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.f764k.get(i3).f928a;
                RecyclerView.C0167n nVar = (RecyclerView.C0167n) view3.getLayoutParams();
                if (view3 != view && !nVar.mo1175t() && (r = (nVar.mo1173r() - this.f757d) * this.f758e) >= 0 && r < i2) {
                    view2 = view3;
                    if (r == 0) {
                        break;
                    }
                    i2 = r;
                }
            }
            if (view2 == null) {
                i = -1;
            } else {
                i = ((RecyclerView.C0167n) view2.getLayoutParams()).mo1173r();
            }
            this.f757d = i;
        }

        /* renamed from: b */
        public boolean mo933b(RecyclerView.C0178w wVar) {
            int i = this.f757d;
            return i >= 0 && i < wVar.mo1202b();
        }

        /* renamed from: c */
        public View mo934c(RecyclerView.C0173s sVar) {
            List<RecyclerView.C0181z> list = this.f764k;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    View view = this.f764k.get(i).f928a;
                    RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
                    if (!nVar.mo1175t() && this.f757d == nVar.mo1173r()) {
                        mo932a(view);
                        return view;
                    }
                }
                return null;
            }
            View e = sVar.mo1186e(this.f757d);
            this.f757d += this.f758e;
            return e;
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$d */
    public static class C0144d implements Parcelable {
        public static final Parcelable.Creator<C0144d> CREATOR = new C0145a();

        /* renamed from: d */
        public int f766d;

        /* renamed from: e */
        public int f767e;

        /* renamed from: f */
        public boolean f768f;

        /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$d$a */
        public class C0145a implements Parcelable.Creator<C0144d> {
            public Object createFromParcel(Parcel parcel) {
                return new C0144d(parcel);
            }

            public Object[] newArray(int i) {
                return new C0144d[i];
            }
        }

        public C0144d() {
        }

        public C0144d(Parcel parcel) {
            this.f766d = parcel.readInt();
            this.f767e = parcel.readInt();
            this.f768f = parcel.readInt() != 1 ? false : true;
        }

        public C0144d(C0144d dVar) {
            this.f766d = dVar.f766d;
            this.f767e = dVar.f767e;
            this.f768f = dVar.f768f;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: r */
        public boolean mo936r() {
            return this.f766d >= 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f766d);
            parcel.writeInt(this.f767e);
            parcel.writeInt(this.f768f ? 1 : 0);
        }
    }

    public LinearLayoutManager(int i, boolean z) {
        mo886A1(i);
        mo896c((String) null);
        if (z != this.f739u) {
            this.f739u = z;
            mo1129N0();
        }
    }

    /* renamed from: A1 */
    public void mo886A1(int i) {
        if (i == 0 || i == 1) {
            mo896c((String) null);
            if (i != this.f735q || this.f737s == null) {
                C0682fb a = C0682fb.m2213a(this, i);
                this.f737s = a;
                this.f731B.f745a = a;
                this.f735q = i;
                mo1129N0();
                return;
            }
            return;
        }
        throw new IllegalArgumentException(C1012kd.m3199h("invalid orientation:", i));
    }

    /* renamed from: B1 */
    public void mo848B1(boolean z) {
        mo896c((String) null);
        if (this.f741w != z) {
            this.f741w = z;
            mo1129N0();
        }
    }

    /* renamed from: C0 */
    public void mo887C0(Parcelable parcelable) {
        if (parcelable instanceof C0144d) {
            C0144d dVar = (C0144d) parcelable;
            this.f730A = dVar;
            if (this.f743y != -1) {
                dVar.f766d = -1;
            }
            mo1129N0();
        }
    }

    /* renamed from: C1 */
    public final void mo888C1(int i, int i2, boolean z, RecyclerView.C0178w wVar) {
        int i3;
        this.f736r.f765l = mo924x1();
        this.f736r.f759f = i;
        int[] iArr = this.f734E;
        boolean z2 = false;
        iArr[0] = 0;
        int i4 = 1;
        iArr[1] = 0;
        Objects.requireNonNull(wVar);
        int i5 = this.f736r.f759f;
        iArr[0] = 0;
        iArr[1] = 0;
        int max = Math.max(0, this.f734E[0]);
        int max2 = Math.max(0, this.f734E[1]);
        if (i == 1) {
            z2 = true;
        }
        C0143c cVar = this.f736r;
        int i6 = z2 ? max2 : max;
        cVar.f761h = i6;
        if (!z2) {
            max = max2;
        }
        cVar.f762i = max;
        if (z2) {
            cVar.f761h = this.f737s.mo2977h() + i6;
            View q1 = mo918q1();
            C0143c cVar2 = this.f736r;
            if (this.f740v) {
                i4 = -1;
            }
            cVar2.f758e = i4;
            int S = mo1135S(q1);
            C0143c cVar3 = this.f736r;
            cVar2.f757d = S + cVar3.f758e;
            cVar3.f755b = this.f737s.mo2971b(q1);
            i3 = this.f737s.mo2971b(q1) - this.f737s.mo2976g();
        } else {
            View r1 = mo919r1();
            C0143c cVar4 = this.f736r;
            cVar4.f761h = this.f737s.mo2980k() + cVar4.f761h;
            C0143c cVar5 = this.f736r;
            if (!this.f740v) {
                i4 = -1;
            }
            cVar5.f758e = i4;
            int S2 = mo1135S(r1);
            C0143c cVar6 = this.f736r;
            cVar5.f757d = S2 + cVar6.f758e;
            cVar6.f755b = this.f737s.mo2974e(r1);
            i3 = (-this.f737s.mo2974e(r1)) + this.f737s.mo2980k();
        }
        C0143c cVar7 = this.f736r;
        cVar7.f756c = i2;
        if (z) {
            cVar7.f756c = i2 - i3;
        }
        cVar7.f760g = i3;
    }

    /* renamed from: D0 */
    public Parcelable mo889D0() {
        C0144d dVar = this.f730A;
        if (dVar != null) {
            return new C0144d(dVar);
        }
        C0144d dVar2 = new C0144d();
        if (mo1166z() > 0) {
            mo902f1();
            boolean z = this.f738t ^ this.f740v;
            dVar2.f768f = z;
            if (z) {
                View q1 = mo918q1();
                dVar2.f767e = this.f737s.mo2976g() - this.f737s.mo2971b(q1);
                dVar2.f766d = mo1135S(q1);
            } else {
                View r1 = mo919r1();
                dVar2.f766d = mo1135S(r1);
                dVar2.f767e = this.f737s.mo2974e(r1) - this.f737s.mo2980k();
            }
        } else {
            dVar2.f766d = -1;
        }
        return dVar2;
    }

    /* renamed from: D1 */
    public final void mo890D1(int i, int i2) {
        this.f736r.f756c = this.f737s.mo2976g() - i2;
        C0143c cVar = this.f736r;
        cVar.f758e = this.f740v ? -1 : 1;
        cVar.f757d = i;
        cVar.f759f = 1;
        cVar.f755b = i2;
        cVar.f760g = Integer.MIN_VALUE;
    }

    /* renamed from: E1 */
    public final void mo891E1(int i, int i2) {
        this.f736r.f756c = i2 - this.f737s.mo2980k();
        C0143c cVar = this.f736r;
        cVar.f757d = i;
        cVar.f758e = this.f740v ? 1 : -1;
        cVar.f759f = -1;
        cVar.f755b = i2;
        cVar.f760g = Integer.MIN_VALUE;
    }

    /* renamed from: O0 */
    public int mo858O0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (this.f735q == 1) {
            return 0;
        }
        return mo926z1(i, sVar, wVar);
    }

    /* renamed from: P0 */
    public void mo892P0(int i) {
        this.f743y = i;
        this.f744z = Integer.MIN_VALUE;
        C0144d dVar = this.f730A;
        if (dVar != null) {
            dVar.f766d = -1;
        }
        mo1129N0();
    }

    /* renamed from: Q0 */
    public int mo860Q0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (this.f735q == 0) {
            return 0;
        }
        return mo926z1(i, sVar, wVar);
    }

    /* renamed from: X0 */
    public boolean mo893X0() {
        boolean z;
        if (!(this.f878n == 1073741824 || this.f877m == 1073741824)) {
            int z2 = mo1166z();
            int i = 0;
            while (true) {
                if (i >= z2) {
                    z = false;
                    break;
                }
                ViewGroup.LayoutParams layoutParams = mo1165y(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    z = true;
                    break;
                }
                i++;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: Z */
    public boolean mo894Z() {
        return true;
    }

    /* renamed from: Z0 */
    public boolean mo863Z0() {
        return this.f730A == null && this.f738t == this.f741w;
    }

    /* renamed from: a1 */
    public void mo864a1(RecyclerView.C0178w wVar, C0143c cVar, RecyclerView.C0162m.C0165c cVar2) {
        int i = cVar.f757d;
        if (i >= 0 && i < wVar.mo1202b()) {
            ((C0021ab.C0023b) cVar2).mo73a(i, Math.max(0, cVar.f760g));
        }
    }

    /* renamed from: b1 */
    public final int mo895b1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        mo902f1();
        C0682fb fbVar = this.f737s;
        View j1 = mo908j1(!this.f742x, true);
        return C1401p4.m4366i(wVar, fbVar, j1, mo906i1(!this.f742x, true), this, this.f742x);
    }

    /* renamed from: c */
    public void mo896c(String str) {
        RecyclerView recyclerView;
        if (this.f730A == null && (recyclerView = this.f866b) != null) {
            recyclerView.mo1013i(str);
        }
    }

    /* renamed from: c1 */
    public final int mo897c1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        mo902f1();
        C0682fb fbVar = this.f737s;
        View j1 = mo908j1(!this.f742x, true);
        return C1401p4.m4368j(wVar, fbVar, j1, mo906i1(!this.f742x, true), this, this.f742x, this.f740v);
    }

    /* renamed from: d1 */
    public final int mo898d1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        mo902f1();
        C0682fb fbVar = this.f737s;
        View j1 = mo908j1(!this.f742x, true);
        return C1401p4.m4370k(wVar, fbVar, j1, mo906i1(!this.f742x, true), this, this.f742x);
    }

    /* renamed from: e */
    public boolean mo899e() {
        return this.f735q == 0;
    }

    /* renamed from: e1 */
    public int mo900e1(int i) {
        return i != 1 ? i != 2 ? i != 17 ? i != 33 ? i != 66 ? (i == 130 && this.f735q == 1) ? 1 : Integer.MIN_VALUE : this.f735q == 0 ? 1 : Integer.MIN_VALUE : this.f735q == 1 ? -1 : Integer.MIN_VALUE : this.f735q == 0 ? -1 : Integer.MIN_VALUE : (this.f735q != 1 && mo920s1()) ? -1 : 1 : (this.f735q != 1 && mo920s1()) ? 1 : -1;
    }

    /* renamed from: f */
    public boolean mo901f() {
        return this.f735q == 1;
    }

    /* renamed from: f1 */
    public void mo902f1() {
        if (this.f736r == null) {
            this.f736r = new C0143c();
        }
    }

    /* renamed from: g1 */
    public int mo903g1(RecyclerView.C0173s sVar, C0143c cVar, RecyclerView.C0178w wVar, boolean z) {
        int i = cVar.f756c;
        int i2 = cVar.f760g;
        if (i2 != Integer.MIN_VALUE) {
            if (i < 0) {
                cVar.f760g = i2 + i;
            }
            mo922v1(sVar, cVar);
        }
        int i3 = cVar.f756c + cVar.f761h;
        C0142b bVar = this.f732C;
        while (true) {
            if ((!cVar.f765l && i3 <= 0) || !cVar.mo933b(wVar)) {
                break;
            }
            bVar.f750a = 0;
            bVar.f751b = false;
            bVar.f752c = false;
            bVar.f753d = false;
            mo876t1(sVar, wVar, cVar, bVar);
            if (!bVar.f751b) {
                int i4 = cVar.f755b;
                int i5 = bVar.f750a;
                cVar.f755b = (cVar.f759f * i5) + i4;
                if (!bVar.f752c || cVar.f764k != null || !wVar.f912f) {
                    cVar.f756c -= i5;
                    i3 -= i5;
                }
                int i6 = cVar.f760g;
                if (i6 != Integer.MIN_VALUE) {
                    int i7 = i6 + i5;
                    cVar.f760g = i7;
                    int i8 = cVar.f756c;
                    if (i8 < 0) {
                        cVar.f760g = i7 + i8;
                    }
                    mo922v1(sVar, cVar);
                }
                if (z && bVar.f753d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - cVar.f756c;
    }

    /* renamed from: h1 */
    public final View mo904h1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        return mo869n1(sVar, wVar, 0, mo1166z(), wVar.mo1202b());
    }

    /* renamed from: i */
    public void mo905i(int i, int i2, RecyclerView.C0178w wVar, RecyclerView.C0162m.C0165c cVar) {
        if (this.f735q != 0) {
            i = i2;
        }
        if (mo1166z() != 0 && i != 0) {
            mo902f1();
            mo888C1(i > 0 ? 1 : -1, Math.abs(i), true, wVar);
            mo864a1(wVar, this.f736r, cVar);
        }
    }

    /* renamed from: i1 */
    public View mo906i1(boolean z, boolean z2) {
        int z3;
        int i;
        if (this.f740v) {
            z3 = 0;
            i = mo1166z();
        } else {
            z3 = mo1166z() - 1;
            i = -1;
        }
        return mo914m1(z3, i, z, z2);
    }

    /* renamed from: j */
    public void mo907j(int i, RecyclerView.C0162m.C0165c cVar) {
        boolean z;
        int i2;
        C0144d dVar = this.f730A;
        int i3 = -1;
        if (dVar == null || !dVar.mo936r()) {
            mo925y1();
            z = this.f740v;
            i2 = this.f743y;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        } else {
            C0144d dVar2 = this.f730A;
            z = dVar2.f768f;
            i2 = dVar2.f766d;
        }
        if (!z) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.f733D && i2 >= 0 && i2 < i; i4++) {
            ((C0021ab.C0023b) cVar).mo73a(i2, 0);
            i2 += i3;
        }
    }

    /* renamed from: j1 */
    public View mo908j1(boolean z, boolean z2) {
        int i;
        int z3;
        if (this.f740v) {
            i = mo1166z() - 1;
            z3 = -1;
        } else {
            i = 0;
            z3 = mo1166z();
        }
        return mo914m1(i, z3, z, z2);
    }

    /* renamed from: k */
    public int mo909k(RecyclerView.C0178w wVar) {
        return mo895b1(wVar);
    }

    /* renamed from: k0 */
    public void mo910k0(RecyclerView recyclerView, RecyclerView.C0173s sVar) {
        mo1156j0();
    }

    /* renamed from: k1 */
    public final View mo911k1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        return mo869n1(sVar, wVar, mo1166z() - 1, -1, wVar.mo1202b());
    }

    /* renamed from: l */
    public int mo866l(RecyclerView.C0178w wVar) {
        return mo897c1(wVar);
    }

    /* renamed from: l0 */
    public View mo867l0(View view, int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        int e1;
        View view2;
        mo925y1();
        if (mo1166z() == 0 || (e1 = mo900e1(i)) == Integer.MIN_VALUE) {
            return null;
        }
        mo902f1();
        mo888C1(e1, (int) (((float) this.f737s.mo2981l()) * 0.33333334f), false, wVar);
        C0143c cVar = this.f736r;
        cVar.f760g = Integer.MIN_VALUE;
        cVar.f754a = false;
        mo903g1(sVar, cVar, wVar, true);
        if (e1 == -1) {
            if (this.f740v) {
                view2 = mo912l1(mo1166z() - 1, -1);
            } else {
                view2 = mo912l1(0, mo1166z());
            }
        } else if (this.f740v) {
            view2 = mo912l1(0, mo1166z());
        } else {
            view2 = mo912l1(mo1166z() - 1, -1);
        }
        View r1 = e1 == -1 ? mo919r1() : mo918q1();
        if (!r1.hasFocusable()) {
            return view2;
        }
        if (view2 == null) {
            return null;
        }
        return r1;
    }

    /* renamed from: l1 */
    public View mo912l1(int i, int i2) {
        int i3;
        int i4;
        mo902f1();
        if ((i2 > i ? 1 : i2 < i ? (char) 65535 : 0) == 0) {
            return mo1165y(i);
        }
        if (this.f737s.mo2974e(mo1165y(i)) < this.f737s.mo2980k()) {
            i4 = 16644;
            i3 = 16388;
        } else {
            i4 = 4161;
            i3 = 4097;
        }
        return (this.f735q == 0 ? this.f869e : this.f870f).mo4267a(i, i2, i4, i3);
    }

    /* renamed from: m */
    public int mo868m(RecyclerView.C0178w wVar) {
        return mo898d1(wVar);
    }

    /* renamed from: m0 */
    public void mo913m0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.C0173s sVar = this.f866b.f804e;
        mo1157n0(accessibilityEvent);
        if (mo1166z() > 0) {
            View m1 = mo914m1(0, mo1166z(), false, true);
            int i = -1;
            accessibilityEvent.setFromIndex(m1 == null ? -1 : mo1135S(m1));
            View m12 = mo914m1(mo1166z() - 1, -1, false, true);
            if (m12 != null) {
                i = mo1135S(m12);
            }
            accessibilityEvent.setToIndex(i);
        }
    }

    /* renamed from: m1 */
    public View mo914m1(int i, int i2, boolean z, boolean z2) {
        mo902f1();
        int i3 = 320;
        int i4 = z ? 24579 : 320;
        if (!z2) {
            i3 = 0;
        }
        return (this.f735q == 0 ? this.f869e : this.f870f).mo4267a(i, i2, i4, i3);
    }

    /* renamed from: n */
    public int mo915n(RecyclerView.C0178w wVar) {
        return mo895b1(wVar);
    }

    /* renamed from: n1 */
    public View mo869n1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, int i, int i2, int i3) {
        mo902f1();
        int k = this.f737s.mo2980k();
        int g = this.f737s.mo2976g();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View y = mo1165y(i);
            int S = mo1135S(y);
            int e = this.f737s.mo2974e(y);
            int b = this.f737s.mo2971b(y);
            if (S >= 0 && S < i3) {
                if (((RecyclerView.C0167n) y.getLayoutParams()).mo1175t()) {
                    if (view2 == null) {
                        view2 = y;
                    }
                } else if ((e < g || b <= g) && (b > k || e >= k)) {
                    return y;
                } else {
                    if (view == null) {
                        view = y;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: o */
    public int mo870o(RecyclerView.C0178w wVar) {
        return mo897c1(wVar);
    }

    /* renamed from: o1 */
    public final int mo916o1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int g;
        int g2 = this.f737s.mo2976g() - i;
        if (g2 <= 0) {
            return 0;
        }
        int i2 = -mo926z1(-g2, sVar, wVar);
        int i3 = i + i2;
        if (!z || (g = this.f737s.mo2976g() - i3) <= 0) {
            return i2;
        }
        this.f737s.mo2984p(g);
        return g + i2;
    }

    /* renamed from: p */
    public int mo871p(RecyclerView.C0178w wVar) {
        return mo898d1(wVar);
    }

    /* renamed from: p1 */
    public final int mo917p1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int k;
        int k2 = i - this.f737s.mo2980k();
        if (k2 <= 0) {
            return 0;
        }
        int i2 = -mo926z1(k2, sVar, wVar);
        int i3 = i + i2;
        if (!z || (k = i3 - this.f737s.mo2980k()) <= 0) {
            return i2;
        }
        this.f737s.mo2984p(-k);
        return i2 - k;
    }

    /* renamed from: q1 */
    public final View mo918q1() {
        return mo1165y(this.f740v ? 0 : mo1166z() - 1);
    }

    /* renamed from: r1 */
    public final View mo919r1() {
        return mo1165y(this.f740v ? mo1166z() - 1 : 0);
    }

    /* renamed from: s1 */
    public boolean mo920s1() {
        return mo1122K() == 1;
    }

    /* renamed from: t */
    public View mo921t(int i) {
        int z = mo1166z();
        if (z == 0) {
            return null;
        }
        int S = i - mo1135S(mo1165y(0));
        if (S >= 0 && S < z) {
            View y = mo1165y(S);
            if (mo1135S(y) == i) {
                return y;
            }
        }
        return super.mo921t(i);
    }

    /* renamed from: t1 */
    public void mo876t1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, C0143c cVar, C0142b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        View c = cVar.mo934c(sVar);
        if (c == null) {
            bVar.f751b = true;
            return;
        }
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) c.getLayoutParams();
        if (cVar.f764k == null) {
            if (this.f740v == (cVar.f759f == -1)) {
                mo1147b(c, -1, false);
            } else {
                mo1147b(c, 0, false);
            }
        } else {
            if (this.f740v == (cVar.f759f == -1)) {
                mo1147b(c, -1, true);
            } else {
                mo1147b(c, 0, true);
            }
        }
        RecyclerView.C0167n nVar2 = (RecyclerView.C0167n) c.getLayoutParams();
        Rect L = this.f866b.mo949L(c);
        int A = RecyclerView.C0162m.m600A(this.f879o, this.f877m, mo1132Q() + mo1131P() + nVar2.leftMargin + nVar2.rightMargin + L.left + L.right + 0, nVar2.width, mo899e());
        int A2 = RecyclerView.C0162m.m600A(this.f880p, this.f878n, mo1130O() + mo1133R() + nVar2.topMargin + nVar2.bottomMargin + L.top + L.bottom + 0, nVar2.height, mo901f());
        if (mo1141W0(c, A, A2, nVar2)) {
            c.measure(A, A2);
        }
        bVar.f750a = this.f737s.mo2972c(c);
        if (this.f735q == 1) {
            if (mo920s1()) {
                i5 = this.f879o - mo1132Q();
                i4 = i5 - this.f737s.mo2973d(c);
            } else {
                i4 = mo1131P();
                i5 = this.f737s.mo2973d(c) + i4;
            }
            int i6 = cVar.f759f;
            int i7 = cVar.f755b;
            if (i6 == -1) {
                i = i7;
                i2 = i5;
                i3 = i7 - bVar.f750a;
            } else {
                i3 = i7;
                i2 = i5;
                i = bVar.f750a + i7;
            }
        } else {
            int R = mo1133R();
            int d = this.f737s.mo2973d(c) + R;
            int i8 = cVar.f759f;
            int i9 = cVar.f755b;
            if (i8 == -1) {
                i2 = i9;
                i3 = R;
                i = d;
                i4 = i9 - bVar.f750a;
            } else {
                i3 = R;
                i2 = bVar.f750a + i9;
                i = d;
                i4 = i9;
            }
        }
        mo1150d0(c, i4, i3, i2, i);
        if (nVar.mo1175t() || nVar.mo1174s()) {
            bVar.f752c = true;
        }
        bVar.f753d = c.hasFocusable();
    }

    /* renamed from: u */
    public RecyclerView.C0167n mo877u() {
        return new RecyclerView.C0167n(-2, -2);
    }

    /* renamed from: u1 */
    public void mo879u1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, C0141a aVar, int i) {
    }

    /* renamed from: v1 */
    public final void mo922v1(RecyclerView.C0173s sVar, C0143c cVar) {
        if (cVar.f754a && !cVar.f765l) {
            int i = cVar.f760g;
            int i2 = cVar.f762i;
            if (cVar.f759f == -1) {
                int z = mo1166z();
                if (i >= 0) {
                    int f = (this.f737s.mo2975f() - i) + i2;
                    if (this.f740v) {
                        for (int i3 = 0; i3 < z; i3++) {
                            View y = mo1165y(i3);
                            if (this.f737s.mo2974e(y) < f || this.f737s.mo2983o(y) < f) {
                                mo923w1(sVar, 0, i3);
                                return;
                            }
                        }
                        return;
                    }
                    int i4 = z - 1;
                    for (int i5 = i4; i5 >= 0; i5--) {
                        View y2 = mo1165y(i5);
                        if (this.f737s.mo2974e(y2) < f || this.f737s.mo2983o(y2) < f) {
                            mo923w1(sVar, i4, i5);
                            return;
                        }
                    }
                }
            } else if (i >= 0) {
                int i6 = i - i2;
                int z2 = mo1166z();
                if (this.f740v) {
                    int i7 = z2 - 1;
                    for (int i8 = i7; i8 >= 0; i8--) {
                        View y3 = mo1165y(i8);
                        if (this.f737s.mo2971b(y3) > i6 || this.f737s.mo2982n(y3) > i6) {
                            mo923w1(sVar, i7, i8);
                            return;
                        }
                    }
                    return;
                }
                for (int i9 = 0; i9 < z2; i9++) {
                    View y4 = mo1165y(i9);
                    if (this.f737s.mo2971b(y4) > i6 || this.f737s.mo2982n(y4) > i6) {
                        mo923w1(sVar, 0, i9);
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: w1 */
    public final void mo923w1(RecyclerView.C0173s sVar, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                for (int i3 = i2 - 1; i3 >= i; i3--) {
                    mo1125L0(i3, sVar);
                }
                return;
            }
            while (i > i2) {
                mo1125L0(i, sVar);
                i--;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:126:0x0218  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0175  */
    /* renamed from: x0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo883x0(androidx.recyclerview.widget.RecyclerView.C0173s r17, androidx.recyclerview.widget.RecyclerView.C0178w r18) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            r2 = r18
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f730A
            r4 = -1
            if (r3 != 0) goto L_0x000f
            int r3 = r0.f743y
            if (r3 == r4) goto L_0x0019
        L_0x000f:
            int r3 = r18.mo1202b()
            if (r3 != 0) goto L_0x0019
            r16.mo1119I0(r17)
            return
        L_0x0019:
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f730A
            if (r3 == 0) goto L_0x0029
            boolean r3 = r3.mo936r()
            if (r3 == 0) goto L_0x0029
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f730A
            int r3 = r3.f766d
            r0.f743y = r3
        L_0x0029:
            r16.mo902f1()
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r5 = 0
            r3.f754a = r5
            r16.mo925y1()
            android.view.View r3 = r16.mo1120J()
            androidx.recyclerview.widget.LinearLayoutManager$a r6 = r0.f731B
            boolean r7 = r6.f749e
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            r9 = 1
            if (r7 == 0) goto L_0x0073
            int r7 = r0.f743y
            if (r7 != r4) goto L_0x0073
            androidx.recyclerview.widget.LinearLayoutManager$d r7 = r0.f730A
            if (r7 == 0) goto L_0x004a
            goto L_0x0073
        L_0x004a:
            if (r3 == 0) goto L_0x022c
            fb r6 = r0.f737s
            int r6 = r6.mo2974e(r3)
            fb r7 = r0.f737s
            int r7 = r7.mo2976g()
            if (r6 >= r7) goto L_0x0068
            fb r6 = r0.f737s
            int r6 = r6.mo2971b(r3)
            fb r7 = r0.f737s
            int r7 = r7.mo2980k()
            if (r6 > r7) goto L_0x022c
        L_0x0068:
            androidx.recyclerview.widget.LinearLayoutManager$a r6 = r0.f731B
            int r7 = r0.mo1135S(r3)
            r6.mo929c(r3, r7)
            goto L_0x022c
        L_0x0073:
            r6.mo930d()
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            boolean r6 = r0.f740v
            boolean r7 = r0.f741w
            r6 = r6 ^ r7
            r3.f748d = r6
            boolean r6 = r2.f912f
            if (r6 != 0) goto L_0x0170
            int r6 = r0.f743y
            if (r6 != r4) goto L_0x0089
            goto L_0x0170
        L_0x0089:
            if (r6 < 0) goto L_0x016c
            int r7 = r18.mo1202b()
            if (r6 < r7) goto L_0x0093
            goto L_0x016c
        L_0x0093:
            int r6 = r0.f743y
            r3.f746b = r6
            androidx.recyclerview.widget.LinearLayoutManager$d r6 = r0.f730A
            if (r6 == 0) goto L_0x00c1
            boolean r6 = r6.mo936r()
            if (r6 == 0) goto L_0x00c1
            androidx.recyclerview.widget.LinearLayoutManager$d r6 = r0.f730A
            boolean r6 = r6.f768f
            r3.f748d = r6
            if (r6 == 0) goto L_0x00b5
            fb r6 = r0.f737s
            int r6 = r6.mo2976g()
            androidx.recyclerview.widget.LinearLayoutManager$d r7 = r0.f730A
            int r7 = r7.f767e
            goto L_0x015d
        L_0x00b5:
            fb r6 = r0.f737s
            int r6 = r6.mo2980k()
            androidx.recyclerview.widget.LinearLayoutManager$d r7 = r0.f730A
            int r7 = r7.f767e
            goto L_0x0167
        L_0x00c1:
            int r6 = r0.f744z
            if (r6 != r8) goto L_0x014f
            int r6 = r0.f743y
            android.view.View r6 = r0.mo921t(r6)
            if (r6 == 0) goto L_0x012d
            fb r7 = r0.f737s
            int r7 = r7.mo2972c(r6)
            fb r10 = r0.f737s
            int r10 = r10.mo2981l()
            if (r7 <= r10) goto L_0x00dd
            goto L_0x014b
        L_0x00dd:
            fb r7 = r0.f737s
            int r7 = r7.mo2974e(r6)
            fb r10 = r0.f737s
            int r10 = r10.mo2980k()
            int r7 = r7 - r10
            if (r7 >= 0) goto L_0x00f8
            fb r6 = r0.f737s
            int r6 = r6.mo2980k()
            r3.f747c = r6
            r3.f748d = r5
            goto L_0x016a
        L_0x00f8:
            fb r7 = r0.f737s
            int r7 = r7.mo2976g()
            fb r10 = r0.f737s
            int r10 = r10.mo2971b(r6)
            int r7 = r7 - r10
            if (r7 >= 0) goto L_0x0112
            fb r6 = r0.f737s
            int r6 = r6.mo2976g()
            r3.f747c = r6
            r3.f748d = r9
            goto L_0x016a
        L_0x0112:
            boolean r7 = r3.f748d
            if (r7 == 0) goto L_0x0124
            fb r7 = r0.f737s
            int r6 = r7.mo2971b(r6)
            fb r7 = r0.f737s
            int r7 = r7.mo3550m()
            int r7 = r7 + r6
            goto L_0x012a
        L_0x0124:
            fb r7 = r0.f737s
            int r7 = r7.mo2974e(r6)
        L_0x012a:
            r3.f747c = r7
            goto L_0x016a
        L_0x012d:
            int r6 = r16.mo1166z()
            if (r6 <= 0) goto L_0x014b
            android.view.View r6 = r0.mo1165y(r5)
            int r6 = r0.mo1135S(r6)
            int r7 = r0.f743y
            if (r7 >= r6) goto L_0x0141
            r6 = 1
            goto L_0x0142
        L_0x0141:
            r6 = 0
        L_0x0142:
            boolean r7 = r0.f740v
            if (r6 != r7) goto L_0x0148
            r6 = 1
            goto L_0x0149
        L_0x0148:
            r6 = 0
        L_0x0149:
            r3.f748d = r6
        L_0x014b:
            r3.mo927a()
            goto L_0x016a
        L_0x014f:
            boolean r6 = r0.f740v
            r3.f748d = r6
            if (r6 == 0) goto L_0x015f
            fb r6 = r0.f737s
            int r6 = r6.mo2976g()
            int r7 = r0.f744z
        L_0x015d:
            int r6 = r6 - r7
            goto L_0x0168
        L_0x015f:
            fb r6 = r0.f737s
            int r6 = r6.mo2980k()
            int r7 = r0.f744z
        L_0x0167:
            int r6 = r6 + r7
        L_0x0168:
            r3.f747c = r6
        L_0x016a:
            r6 = 1
            goto L_0x0171
        L_0x016c:
            r0.f743y = r4
            r0.f744z = r8
        L_0x0170:
            r6 = 0
        L_0x0171:
            if (r6 == 0) goto L_0x0175
            goto L_0x0228
        L_0x0175:
            int r6 = r16.mo1166z()
            if (r6 != 0) goto L_0x017d
            goto L_0x0214
        L_0x017d:
            android.view.View r6 = r16.mo1120J()
            if (r6 == 0) goto L_0x01ad
            android.view.ViewGroup$LayoutParams r7 = r6.getLayoutParams()
            androidx.recyclerview.widget.RecyclerView$n r7 = (androidx.recyclerview.widget.RecyclerView.C0167n) r7
            boolean r10 = r7.mo1175t()
            if (r10 != 0) goto L_0x01a1
            int r10 = r7.mo1173r()
            if (r10 < 0) goto L_0x01a1
            int r7 = r7.mo1173r()
            int r10 = r18.mo1202b()
            if (r7 >= r10) goto L_0x01a1
            r7 = 1
            goto L_0x01a2
        L_0x01a1:
            r7 = 0
        L_0x01a2:
            if (r7 == 0) goto L_0x01ad
            int r7 = r0.mo1135S(r6)
            r3.mo929c(r6, r7)
            goto L_0x0212
        L_0x01ad:
            boolean r6 = r0.f738t
            boolean r7 = r0.f741w
            if (r6 == r7) goto L_0x01b4
            goto L_0x0214
        L_0x01b4:
            boolean r6 = r3.f748d
            if (r6 == 0) goto L_0x01c6
            boolean r6 = r0.f740v
            if (r6 == 0) goto L_0x01c1
            android.view.View r6 = r16.mo904h1(r17, r18)
            goto L_0x01d3
        L_0x01c1:
            android.view.View r6 = r16.mo911k1(r17, r18)
            goto L_0x01d3
        L_0x01c6:
            boolean r6 = r0.f740v
            if (r6 == 0) goto L_0x01cf
            android.view.View r6 = r16.mo911k1(r17, r18)
            goto L_0x01d3
        L_0x01cf:
            android.view.View r6 = r16.mo904h1(r17, r18)
        L_0x01d3:
            if (r6 == 0) goto L_0x0214
            int r7 = r0.mo1135S(r6)
            r3.mo928b(r6, r7)
            boolean r7 = r2.f912f
            if (r7 != 0) goto L_0x0212
            boolean r7 = r16.mo863Z0()
            if (r7 == 0) goto L_0x0212
            fb r7 = r0.f737s
            int r7 = r7.mo2974e(r6)
            fb r10 = r0.f737s
            int r6 = r10.mo2971b(r6)
            fb r10 = r0.f737s
            int r10 = r10.mo2980k()
            fb r11 = r0.f737s
            int r11 = r11.mo2976g()
            if (r7 < r11) goto L_0x0202
            if (r6 > r11) goto L_0x0206
        L_0x0202:
            if (r6 > r10) goto L_0x0208
            if (r7 >= r10) goto L_0x0208
        L_0x0206:
            r6 = 1
            goto L_0x0209
        L_0x0208:
            r6 = 0
        L_0x0209:
            if (r6 == 0) goto L_0x0212
            boolean r6 = r3.f748d
            if (r6 == 0) goto L_0x0210
            r10 = r11
        L_0x0210:
            r3.f747c = r10
        L_0x0212:
            r6 = 1
            goto L_0x0215
        L_0x0214:
            r6 = 0
        L_0x0215:
            if (r6 == 0) goto L_0x0218
            goto L_0x0228
        L_0x0218:
            r3.mo927a()
            boolean r6 = r0.f741w
            if (r6 == 0) goto L_0x0225
            int r6 = r18.mo1202b()
            int r6 = r6 + r4
            goto L_0x0226
        L_0x0225:
            r6 = 0
        L_0x0226:
            r3.f746b = r6
        L_0x0228:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            r3.f749e = r9
        L_0x022c:
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r6 = r3.f763j
            if (r6 < 0) goto L_0x0234
            r6 = 1
            goto L_0x0235
        L_0x0234:
            r6 = -1
        L_0x0235:
            r3.f759f = r6
            int[] r3 = r0.f734E
            r3[r5] = r5
            r3[r9] = r5
            java.util.Objects.requireNonNull(r18)
            androidx.recyclerview.widget.LinearLayoutManager$c r6 = r0.f736r
            int r6 = r6.f759f
            r3[r5] = r5
            r3[r9] = r5
            int[] r3 = r0.f734E
            r3 = r3[r5]
            int r3 = java.lang.Math.max(r5, r3)
            fb r6 = r0.f737s
            int r6 = r6.mo2980k()
            int r6 = r6 + r3
            int[] r3 = r0.f734E
            r3 = r3[r9]
            int r3 = java.lang.Math.max(r5, r3)
            fb r7 = r0.f737s
            int r7 = r7.mo2977h()
            int r7 = r7 + r3
            boolean r3 = r2.f912f
            if (r3 == 0) goto L_0x02a1
            int r3 = r0.f743y
            if (r3 == r4) goto L_0x02a1
            int r10 = r0.f744z
            if (r10 == r8) goto L_0x02a1
            android.view.View r3 = r0.mo921t(r3)
            if (r3 == 0) goto L_0x02a1
            boolean r8 = r0.f740v
            if (r8 == 0) goto L_0x028c
            fb r8 = r0.f737s
            int r8 = r8.mo2976g()
            fb r10 = r0.f737s
            int r3 = r10.mo2971b(r3)
            int r8 = r8 - r3
            int r3 = r0.f744z
            goto L_0x029b
        L_0x028c:
            fb r8 = r0.f737s
            int r3 = r8.mo2974e(r3)
            fb r8 = r0.f737s
            int r8 = r8.mo2980k()
            int r3 = r3 - r8
            int r8 = r0.f744z
        L_0x029b:
            int r8 = r8 - r3
            if (r8 <= 0) goto L_0x02a0
            int r6 = r6 + r8
            goto L_0x02a1
        L_0x02a0:
            int r7 = r7 - r8
        L_0x02a1:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            boolean r8 = r3.f748d
            if (r8 == 0) goto L_0x02ac
            boolean r8 = r0.f740v
            if (r8 == 0) goto L_0x02b0
            goto L_0x02b2
        L_0x02ac:
            boolean r8 = r0.f740v
            if (r8 == 0) goto L_0x02b2
        L_0x02b0:
            r8 = -1
            goto L_0x02b3
        L_0x02b2:
            r8 = 1
        L_0x02b3:
            r0.mo879u1(r1, r2, r3, r8)
            r16.mo1159q(r17)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            boolean r8 = r16.mo924x1()
            r3.f765l = r8
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            java.util.Objects.requireNonNull(r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r3.f762i = r5
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            boolean r8 = r3.f748d
            if (r8 == 0) goto L_0x0317
            int r8 = r3.f746b
            int r3 = r3.f747c
            r0.mo891E1(r8, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r3.f761h = r6
            r0.mo903g1(r1, r3, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r6 = r3.f755b
            int r8 = r3.f757d
            int r3 = r3.f756c
            if (r3 <= 0) goto L_0x02e9
            int r7 = r7 + r3
        L_0x02e9:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            int r10 = r3.f746b
            int r3 = r3.f747c
            r0.mo890D1(r10, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r3.f761h = r7
            int r7 = r3.f757d
            int r10 = r3.f758e
            int r7 = r7 + r10
            r3.f757d = r7
            r0.mo903g1(r1, r3, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r7 = r3.f755b
            int r3 = r3.f756c
            if (r3 <= 0) goto L_0x035d
            r0.mo891E1(r8, r6)
            androidx.recyclerview.widget.LinearLayoutManager$c r6 = r0.f736r
            r6.f761h = r3
            r0.mo903g1(r1, r6, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r6 = r3.f755b
            goto L_0x035d
        L_0x0317:
            int r8 = r3.f746b
            int r3 = r3.f747c
            r0.mo890D1(r8, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r3.f761h = r7
            r0.mo903g1(r1, r3, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r7 = r3.f755b
            int r8 = r3.f757d
            int r3 = r3.f756c
            if (r3 <= 0) goto L_0x0330
            int r6 = r6 + r3
        L_0x0330:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f731B
            int r10 = r3.f746b
            int r3 = r3.f747c
            r0.mo891E1(r10, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            r3.f761h = r6
            int r6 = r3.f757d
            int r10 = r3.f758e
            int r6 = r6 + r10
            r3.f757d = r6
            r0.mo903g1(r1, r3, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r6 = r3.f755b
            int r3 = r3.f756c
            if (r3 <= 0) goto L_0x035d
            r0.mo890D1(r8, r7)
            androidx.recyclerview.widget.LinearLayoutManager$c r7 = r0.f736r
            r7.f761h = r3
            r0.mo903g1(r1, r7, r2, r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f736r
            int r7 = r3.f755b
        L_0x035d:
            int r3 = r16.mo1166z()
            if (r3 <= 0) goto L_0x0381
            boolean r3 = r0.f740v
            boolean r8 = r0.f741w
            r3 = r3 ^ r8
            if (r3 == 0) goto L_0x0375
            int r3 = r0.mo916o1(r7, r1, r2, r9)
            int r6 = r6 + r3
            int r7 = r7 + r3
            int r3 = r0.mo917p1(r6, r1, r2, r5)
            goto L_0x037f
        L_0x0375:
            int r3 = r0.mo917p1(r6, r1, r2, r9)
            int r6 = r6 + r3
            int r7 = r7 + r3
            int r3 = r0.mo916o1(r7, r1, r2, r5)
        L_0x037f:
            int r6 = r6 + r3
            int r7 = r7 + r3
        L_0x0381:
            boolean r3 = r2.f916j
            if (r3 == 0) goto L_0x0417
            int r3 = r16.mo1166z()
            if (r3 == 0) goto L_0x0417
            boolean r3 = r2.f912f
            if (r3 != 0) goto L_0x0417
            boolean r3 = r16.mo863Z0()
            if (r3 != 0) goto L_0x0397
            goto L_0x0417
        L_0x0397:
            java.util.List<androidx.recyclerview.widget.RecyclerView$z> r3 = r1.f900d
            int r8 = r3.size()
            android.view.View r10 = r0.mo1165y(r5)
            int r10 = r0.mo1135S(r10)
            r11 = 0
            r12 = 0
            r13 = 0
        L_0x03a8:
            if (r11 >= r8) goto L_0x03d8
            java.lang.Object r14 = r3.get(r11)
            androidx.recyclerview.widget.RecyclerView$z r14 = (androidx.recyclerview.widget.RecyclerView.C0181z) r14
            boolean r15 = r14.mo1217l()
            if (r15 == 0) goto L_0x03b7
            goto L_0x03d4
        L_0x03b7:
            int r15 = r14.mo1210e()
            if (r15 >= r10) goto L_0x03bf
            r15 = 1
            goto L_0x03c0
        L_0x03bf:
            r15 = 0
        L_0x03c0:
            boolean r9 = r0.f740v
            if (r15 == r9) goto L_0x03c6
            r9 = -1
            goto L_0x03c7
        L_0x03c6:
            r9 = 1
        L_0x03c7:
            fb r15 = r0.f737s
            android.view.View r14 = r14.f928a
            int r14 = r15.mo2972c(r14)
            if (r9 != r4) goto L_0x03d3
            int r12 = r12 + r14
            goto L_0x03d4
        L_0x03d3:
            int r13 = r13 + r14
        L_0x03d4:
            int r11 = r11 + 1
            r9 = 1
            goto L_0x03a8
        L_0x03d8:
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f736r
            r4.f764k = r3
            r3 = 0
            if (r12 <= 0) goto L_0x03f8
            android.view.View r4 = r16.mo919r1()
            int r4 = r0.mo1135S(r4)
            r0.mo891E1(r4, r6)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f736r
            r4.f761h = r12
            r4.f756c = r5
            r4.mo932a(r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f736r
            r0.mo903g1(r1, r4, r2, r5)
        L_0x03f8:
            if (r13 <= 0) goto L_0x0413
            android.view.View r4 = r16.mo918q1()
            int r4 = r0.mo1135S(r4)
            r0.mo890D1(r4, r7)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f736r
            r4.f761h = r13
            r4.f756c = r5
            r4.mo932a(r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f736r
            r0.mo903g1(r1, r4, r2, r5)
        L_0x0413:
            androidx.recyclerview.widget.LinearLayoutManager$c r1 = r0.f736r
            r1.f764k = r3
        L_0x0417:
            boolean r1 = r2.f912f
            if (r1 != 0) goto L_0x0424
            fb r1 = r0.f737s
            int r2 = r1.mo2981l()
            r1.f2725b = r2
            goto L_0x0429
        L_0x0424:
            androidx.recyclerview.widget.LinearLayoutManager$a r1 = r0.f731B
            r1.mo930d()
        L_0x0429:
            boolean r1 = r0.f741w
            r0.f738t = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.mo883x0(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w):void");
    }

    /* renamed from: x1 */
    public boolean mo924x1() {
        return this.f737s.mo2978i() == 0 && this.f737s.mo2975f() == 0;
    }

    /* renamed from: y0 */
    public void mo884y0(RecyclerView.C0178w wVar) {
        this.f730A = null;
        this.f743y = -1;
        this.f744z = Integer.MIN_VALUE;
        this.f731B.mo930d();
    }

    /* renamed from: y1 */
    public final void mo925y1() {
        this.f740v = (this.f735q == 1 || !mo920s1()) ? this.f739u : !this.f739u;
    }

    /* renamed from: z1 */
    public int mo926z1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (mo1166z() == 0 || i == 0) {
            return 0;
        }
        mo902f1();
        this.f736r.f754a = true;
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        mo888C1(i2, abs, true, wVar);
        C0143c cVar = this.f736r;
        int g1 = mo903g1(sVar, cVar, wVar, false) + cVar.f760g;
        if (g1 < 0) {
            return 0;
        }
        if (abs > g1) {
            i = i2 * g1;
        }
        this.f737s.mo2984p(-i);
        this.f736r.f763j = i;
        return i;
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        RecyclerView.C0162m.C0166d T = RecyclerView.C0162m.m601T(context, attributeSet, i, i2);
        mo886A1(T.f883a);
        boolean z = T.f885c;
        mo896c((String) null);
        if (z != this.f739u) {
            this.f739u = z;
            mo1129N0();
        }
        mo848B1(T.f886d);
    }
}
