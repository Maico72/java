package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0021ab;
import p000.C0882ib;
import p000.C1006kb;
import p000.C1101lb;
import p000.C1321oa;
import p000.C1412pa;
import p000.C2130ya;

public class RecyclerView extends ViewGroup implements C1486q6 {

    /* renamed from: A0 */
    public static final boolean f769A0;

    /* renamed from: B0 */
    public static final boolean f770B0;

    /* renamed from: C0 */
    public static final boolean f771C0 = true;

    /* renamed from: D0 */
    public static final boolean f772D0;

    /* renamed from: E0 */
    public static final Class<?>[] f773E0;

    /* renamed from: F0 */
    public static final Interpolator f774F0 = new C0148c();

    /* renamed from: z0 */
    public static final int[] f775z0 = {16843830};

    /* renamed from: A */
    public boolean f776A;

    /* renamed from: B */
    public boolean f777B;

    /* renamed from: C */
    public int f778C;

    /* renamed from: D */
    public boolean f779D;

    /* renamed from: E */
    public final AccessibilityManager f780E;

    /* renamed from: F */
    public boolean f781F;

    /* renamed from: G */
    public boolean f782G;

    /* renamed from: H */
    public int f783H;

    /* renamed from: I */
    public int f784I;

    /* renamed from: J */
    public C0155i f785J;

    /* renamed from: K */
    public EdgeEffect f786K;

    /* renamed from: L */
    public EdgeEffect f787L;

    /* renamed from: M */
    public EdgeEffect f788M;

    /* renamed from: N */
    public EdgeEffect f789N;

    /* renamed from: O */
    public C0156j f790O;

    /* renamed from: P */
    public int f791P;

    /* renamed from: Q */
    public int f792Q;

    /* renamed from: R */
    public VelocityTracker f793R;

    /* renamed from: S */
    public int f794S;

    /* renamed from: T */
    public int f795T;

    /* renamed from: U */
    public int f796U;

    /* renamed from: V */
    public int f797V;

    /* renamed from: W */
    public int f798W;

    /* renamed from: a0 */
    public final int f799a0;

    /* renamed from: b0 */
    public final int f800b0;

    /* renamed from: c0 */
    public float f801c0;

    /* renamed from: d */
    public final C0175u f802d;

    /* renamed from: d0 */
    public float f803d0;

    /* renamed from: e */
    public final C0173s f804e;

    /* renamed from: e0 */
    public boolean f805e0;

    /* renamed from: f */
    public C0176v f806f;

    /* renamed from: f0 */
    public final C0180y f807f0;

    /* renamed from: g */
    public C1321oa f808g;

    /* renamed from: g0 */
    public C0021ab f809g0;

    /* renamed from: h */
    public C1412pa f810h;

    /* renamed from: h0 */
    public C0021ab.C0023b f811h0;

    /* renamed from: i */
    public final C1101lb f812i;

    /* renamed from: i0 */
    public final C0178w f813i0;

    /* renamed from: j */
    public boolean f814j;

    /* renamed from: j0 */
    public C0170q f815j0;

    /* renamed from: k */
    public final Runnable f816k;

    /* renamed from: k0 */
    public List<C0170q> f817k0;

    /* renamed from: l */
    public final Rect f818l;

    /* renamed from: l0 */
    public boolean f819l0;

    /* renamed from: m */
    public final Rect f820m;

    /* renamed from: m0 */
    public boolean f821m0;

    /* renamed from: n */
    public final RectF f822n;

    /* renamed from: n0 */
    public C0156j.C0158b f823n0;

    /* renamed from: o */
    public C0150e f824o;

    /* renamed from: o0 */
    public boolean f825o0;

    /* renamed from: p */
    public C0162m f826p;

    /* renamed from: p0 */
    public C0882ib f827p0;

    /* renamed from: q */
    public C0174t f828q;

    /* renamed from: q0 */
    public C0154h f829q0;

    /* renamed from: r */
    public final ArrayList<C0161l> f830r;

    /* renamed from: r0 */
    public final int[] f831r0;

    /* renamed from: s */
    public final ArrayList<C0169p> f832s;

    /* renamed from: s0 */
    public C1720s6 f833s0;

    /* renamed from: t */
    public C0169p f834t;

    /* renamed from: t0 */
    public final int[] f835t0;

    /* renamed from: u */
    public boolean f836u;

    /* renamed from: u0 */
    public final int[] f837u0;

    /* renamed from: v */
    public boolean f838v;

    /* renamed from: v0 */
    public final int[] f839v0;

    /* renamed from: w */
    public boolean f840w;

    /* renamed from: w0 */
    public final List<C0181z> f841w0;

    /* renamed from: x */
    public boolean f842x;

    /* renamed from: x0 */
    public Runnable f843x0;

    /* renamed from: y */
    public int f844y;

    /* renamed from: y0 */
    public final C1101lb.C1103b f845y0;

    /* renamed from: z */
    public boolean f846z;

    /* renamed from: androidx.recyclerview.widget.RecyclerView$a */
    public class C0146a implements Runnable {
        public C0146a() {
        }

        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f842x && !recyclerView.isLayoutRequested()) {
                RecyclerView recyclerView2 = RecyclerView.this;
                if (!recyclerView2.f836u) {
                    recyclerView2.requestLayout();
                } else if (recyclerView2.f776A) {
                    recyclerView2.f846z = true;
                } else {
                    recyclerView2.mo1024n();
                }
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$b */
    public class C0147b implements Runnable {
        public C0147b() {
        }

        public void run() {
            C0156j jVar = RecyclerView.this.f790O;
            if (jVar != null) {
                C2130ya yaVar = (C2130ya) jVar;
                boolean z = !yaVar.f6882h.isEmpty();
                boolean z2 = !yaVar.f6884j.isEmpty();
                boolean z3 = !yaVar.f6885k.isEmpty();
                boolean z4 = !yaVar.f6883i.isEmpty();
                if (z || z2 || z4 || z3) {
                    Iterator<C0181z> it = yaVar.f6882h.iterator();
                    while (it.hasNext()) {
                        C0181z next = it.next();
                        View view = next.f928a;
                        ViewPropertyAnimator animate = view.animate();
                        yaVar.f6891q.add(next);
                        animate.setDuration(yaVar.f859d).alpha(0.0f).setListener(new C1787ta(yaVar, next, animate, view)).start();
                    }
                    yaVar.f6882h.clear();
                    if (z2) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.addAll(yaVar.f6884j);
                        yaVar.f6887m.add(arrayList);
                        yaVar.f6884j.clear();
                        C1492qa qaVar = new C1492qa(yaVar, arrayList);
                        if (z) {
                            View view2 = ((C2130ya.C2132b) arrayList.get(0)).f6899a.f928a;
                            long j = yaVar.f859d;
                            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                            view2.postOnAnimationDelayed(qaVar, j);
                        } else {
                            qaVar.run();
                        }
                    }
                    if (z3) {
                        ArrayList arrayList2 = new ArrayList();
                        arrayList2.addAll(yaVar.f6885k);
                        yaVar.f6888n.add(arrayList2);
                        yaVar.f6885k.clear();
                        C1664ra raVar = new C1664ra(yaVar, arrayList2);
                        if (z) {
                            View view3 = ((C2130ya.C2131a) arrayList2.get(0)).f6893a.f928a;
                            long j2 = yaVar.f859d;
                            WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                            view3.postOnAnimationDelayed(raVar, j2);
                        } else {
                            raVar.run();
                        }
                    }
                    if (z4) {
                        ArrayList arrayList3 = new ArrayList();
                        arrayList3.addAll(yaVar.f6883i);
                        yaVar.f6886l.add(arrayList3);
                        yaVar.f6883i.clear();
                        C1726sa saVar = new C1726sa(yaVar, arrayList3);
                        if (z || z2 || z3) {
                            long j3 = 0;
                            long j4 = z ? yaVar.f859d : 0;
                            long j5 = z2 ? yaVar.f860e : 0;
                            if (z3) {
                                j3 = yaVar.f861f;
                            }
                            View view4 = ((C0181z) arrayList3.get(0)).f928a;
                            WeakHashMap<View, String> weakHashMap3 = C0010a7.f28a;
                            view4.postOnAnimationDelayed(saVar, Math.max(j5, j3) + j4);
                        } else {
                            saVar.run();
                        }
                    }
                }
            }
            RecyclerView.this.f825o0 = false;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$c */
    public class C0148c implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$d */
    public class C0149d implements C1101lb.C1103b {
        public C0149d() {
        }

        /* renamed from: a */
        public void mo1083a(C0181z zVar, C0156j.C0159c cVar, C0156j.C0159c cVar2) {
            boolean z;
            int i;
            int i2;
            RecyclerView recyclerView = RecyclerView.this;
            Objects.requireNonNull(recyclerView);
            zVar.mo1224s(false);
            C0956jb jbVar = (C0956jb) recyclerView.f790O;
            Objects.requireNonNull(jbVar);
            if (cVar == null || ((i = cVar.f862a) == (i2 = cVar2.f862a) && cVar.f863b == cVar2.f863b)) {
                C2130ya yaVar = (C2130ya) jbVar;
                yaVar.mo6682n(zVar);
                zVar.f928a.setAlpha(0.0f);
                yaVar.f6883i.add(zVar);
                z = true;
            } else {
                z = jbVar.mo4153i(zVar, i, cVar.f863b, i2, cVar2.f863b);
            }
            if (z) {
                recyclerView.mo962Y();
            }
        }

        /* renamed from: b */
        public void mo1084b(C0181z zVar, C0156j.C0159c cVar, C0156j.C0159c cVar2) {
            boolean z;
            RecyclerView.this.f804e.mo1194m(zVar);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.mo988g(zVar);
            zVar.mo1224s(false);
            C0956jb jbVar = (C0956jb) recyclerView.f790O;
            Objects.requireNonNull(jbVar);
            int i = cVar.f862a;
            int i2 = cVar.f863b;
            View view = zVar.f928a;
            int left = cVar2 == null ? view.getLeft() : cVar2.f862a;
            int top = cVar2 == null ? view.getTop() : cVar2.f863b;
            if (zVar.mo1217l() || (i == left && i2 == top)) {
                C2130ya yaVar = (C2130ya) jbVar;
                yaVar.mo6682n(zVar);
                yaVar.f6882h.add(zVar);
                z = true;
            } else {
                view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                z = jbVar.mo4153i(zVar, i, i2, left, top);
            }
            if (z) {
                recyclerView.mo962Y();
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$e */
    public static abstract class C0150e<VH extends C0181z> {

        /* renamed from: a */
        public final C0152f f850a = new C0152f();

        /* renamed from: b */
        public C0151a f851b = C0151a.ALLOW;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$e$a */
        public enum C0151a {
            ALLOW,
            PREVENT_WHEN_EMPTY,
            PREVENT
        }

        /* renamed from: a */
        public abstract int mo1085a();

        /* renamed from: b */
        public int mo1086b(int i) {
            return 0;
        }

        /* renamed from: c */
        public abstract void mo1087c(VH vh, int i);

        /* renamed from: d */
        public abstract VH mo1088d(ViewGroup viewGroup, int i);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$f */
    public static class C0152f extends Observable<C0153g> {
        /* renamed from: a */
        public void mo1089a() {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0153g) this.mObservers.get(size)).mo1092a();
            }
        }

        /* renamed from: b */
        public void mo1090b(int i, int i2) {
            int size = this.mObservers.size();
            while (true) {
                size--;
                if (size >= 0) {
                    ((C0153g) this.mObservers.get(size)).mo1093b(i, i2, (Object) null);
                } else {
                    return;
                }
            }
        }

        /* renamed from: c */
        public void mo1091c(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0153g) this.mObservers.get(size)).mo1094c(i, i2);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$g */
    public static abstract class C0153g {
        /* renamed from: a */
        public void mo1092a() {
        }

        /* renamed from: b */
        public void mo1093b(int i, int i2, Object obj) {
        }

        /* renamed from: c */
        public void mo1094c(int i, int i2) {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$h */
    public interface C0154h {
        /* renamed from: a */
        int mo1095a(int i, int i2);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$i */
    public static class C0155i {
        /* renamed from: a */
        public EdgeEffect mo1096a(RecyclerView recyclerView) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$j */
    public static abstract class C0156j {

        /* renamed from: a */
        public C0158b f856a = null;

        /* renamed from: b */
        public ArrayList<C0157a> f857b = new ArrayList<>();

        /* renamed from: c */
        public long f858c = 120;

        /* renamed from: d */
        public long f859d = 120;

        /* renamed from: e */
        public long f860e = 250;

        /* renamed from: f */
        public long f861f = 250;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$j$a */
        public interface C0157a {
            /* renamed from: a */
            void mo1104a();
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$j$b */
        public interface C0158b {
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$j$c */
        public static class C0159c {

            /* renamed from: a */
            public int f862a;

            /* renamed from: b */
            public int f863b;
        }

        /* renamed from: b */
        public static int m590b(C0181z zVar) {
            int i = zVar.f937j & 14;
            if (zVar.mo1215j()) {
                return 4;
            }
            if ((i & 4) != 0) {
                return i;
            }
            int i2 = zVar.f931d;
            RecyclerView recyclerView = zVar.f945r;
            int H = recyclerView == null ? -1 : recyclerView.mo946H(zVar);
            return (i2 == -1 || H == -1 || i2 == H) ? i : i | 2048;
        }

        /* renamed from: a */
        public abstract boolean mo1097a(C0181z zVar, C0181z zVar2, C0159c cVar, C0159c cVar2);

        /* renamed from: c */
        public final void mo1098c(C0181z zVar) {
            C0158b bVar = this.f856a;
            if (bVar != null) {
                C0160k kVar = (C0160k) bVar;
                Objects.requireNonNull(kVar);
                boolean z = true;
                zVar.mo1224s(true);
                if (zVar.f935h != null && zVar.f936i == null) {
                    zVar.f935h = null;
                }
                zVar.f936i = null;
                if (!((zVar.f937j & 16) != 0)) {
                    RecyclerView recyclerView = RecyclerView.this;
                    View view = zVar.f928a;
                    recyclerView.mo1019k0();
                    C1412pa paVar = recyclerView.f810h;
                    int indexOfChild = ((C0742gb) paVar.f4813a).f2853a.indexOfChild(view);
                    if (indexOfChild == -1) {
                        paVar.mo5214m(view);
                    } else if (paVar.f4814b.mo5219d(indexOfChild)) {
                        paVar.f4814b.mo5221f(indexOfChild);
                        paVar.mo5214m(view);
                        ((C0742gb) paVar.f4813a).mo3770c(indexOfChild);
                    } else {
                        z = false;
                    }
                    if (z) {
                        C0181z K = RecyclerView.m512K(view);
                        recyclerView.f804e.mo1194m(K);
                        recyclerView.f804e.mo1191j(K);
                    }
                    recyclerView.mo1023m0(!z);
                    if (!z && zVar.mo1219n()) {
                        RecyclerView.this.removeDetachedView(zVar.f928a, false);
                    }
                }
            }
        }

        /* renamed from: d */
        public final void mo1099d() {
            int size = this.f857b.size();
            for (int i = 0; i < size; i++) {
                this.f857b.get(i).mo1104a();
            }
            this.f857b.clear();
        }

        /* renamed from: e */
        public abstract void mo1100e(C0181z zVar);

        /* renamed from: f */
        public abstract void mo1101f();

        /* renamed from: g */
        public abstract boolean mo1102g();

        /* renamed from: h */
        public C0159c mo1103h(C0181z zVar) {
            C0159c cVar = new C0159c();
            View view = zVar.f928a;
            cVar.f862a = view.getLeft();
            cVar.f863b = view.getTop();
            view.getRight();
            view.getBottom();
            return cVar;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$k */
    public class C0160k implements C0156j.C0158b {
        public C0160k() {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$l */
    public static abstract class C0161l {
        /* renamed from: d */
        public void mo1105d(Canvas canvas, RecyclerView recyclerView, C0178w wVar) {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$m */
    public static abstract class C0162m {

        /* renamed from: a */
        public C1412pa f865a;

        /* renamed from: b */
        public RecyclerView f866b;

        /* renamed from: c */
        public final C1006kb.C1008b f867c;

        /* renamed from: d */
        public final C1006kb.C1008b f868d;

        /* renamed from: e */
        public C1006kb f869e;

        /* renamed from: f */
        public C1006kb f870f;

        /* renamed from: g */
        public boolean f871g = false;

        /* renamed from: h */
        public boolean f872h = false;

        /* renamed from: i */
        public boolean f873i = true;

        /* renamed from: j */
        public boolean f874j = true;

        /* renamed from: k */
        public int f875k;

        /* renamed from: l */
        public boolean f876l;

        /* renamed from: m */
        public int f877m;

        /* renamed from: n */
        public int f878n;

        /* renamed from: o */
        public int f879o;

        /* renamed from: p */
        public int f880p;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$m$a */
        public class C0163a implements C1006kb.C1008b {
            public C0163a() {
            }

            /* renamed from: a */
            public View mo1168a(int i) {
                return C0162m.this.mo1165y(i);
            }

            /* renamed from: b */
            public int mo1169b() {
                C0162m mVar = C0162m.this;
                return mVar.f879o - mVar.mo1132Q();
            }

            /* renamed from: c */
            public int mo1170c() {
                return C0162m.this.mo1131P();
            }

            /* renamed from: d */
            public int mo1171d(View view) {
                return C0162m.this.mo1116H(view) + ((C0167n) view.getLayoutParams()).rightMargin;
            }

            /* renamed from: e */
            public int mo1172e(View view) {
                return C0162m.this.mo1110E(view) - ((C0167n) view.getLayoutParams()).leftMargin;
            }
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$m$b */
        public class C0164b implements C1006kb.C1008b {
            public C0164b() {
            }

            /* renamed from: a */
            public View mo1168a(int i) {
                return C0162m.this.mo1165y(i);
            }

            /* renamed from: b */
            public int mo1169b() {
                C0162m mVar = C0162m.this;
                return mVar.f880p - mVar.mo1130O();
            }

            /* renamed from: c */
            public int mo1170c() {
                return C0162m.this.mo1133R();
            }

            /* renamed from: d */
            public int mo1171d(View view) {
                return C0162m.this.mo1108C(view) + ((C0167n) view.getLayoutParams()).bottomMargin;
            }

            /* renamed from: e */
            public int mo1172e(View view) {
                return C0162m.this.mo1118I(view) - ((C0167n) view.getLayoutParams()).topMargin;
            }
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$m$c */
        public interface C0165c {
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$m$d */
        public static class C0166d {

            /* renamed from: a */
            public int f883a;

            /* renamed from: b */
            public int f884b;

            /* renamed from: c */
            public boolean f885c;

            /* renamed from: d */
            public boolean f886d;
        }

        public C0162m() {
            C0163a aVar = new C0163a();
            this.f867c = aVar;
            C0164b bVar = new C0164b();
            this.f868d = bVar;
            this.f869e = new C1006kb(aVar);
            this.f870f = new C1006kb(bVar);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0017, code lost:
            if (r5 == 1073741824) goto L_0x0021;
         */
        /* renamed from: A */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static int m600A(int r4, int r5, int r6, int r7, boolean r8) {
            /*
                int r4 = r4 - r6
                r6 = 0
                int r4 = java.lang.Math.max(r6, r4)
                r0 = -2
                r1 = -1
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = 1073741824(0x40000000, float:2.0)
                if (r8 == 0) goto L_0x001a
                if (r7 < 0) goto L_0x0011
                goto L_0x001c
            L_0x0011:
                if (r7 != r1) goto L_0x002f
                if (r5 == r2) goto L_0x0021
                if (r5 == 0) goto L_0x002f
                if (r5 == r3) goto L_0x0021
                goto L_0x002f
            L_0x001a:
                if (r7 < 0) goto L_0x001f
            L_0x001c:
                r5 = 1073741824(0x40000000, float:2.0)
                goto L_0x0031
            L_0x001f:
                if (r7 != r1) goto L_0x0023
            L_0x0021:
                r7 = r4
                goto L_0x0031
            L_0x0023:
                if (r7 != r0) goto L_0x002f
                if (r5 == r2) goto L_0x002c
                if (r5 != r3) goto L_0x002a
                goto L_0x002c
            L_0x002a:
                r5 = 0
                goto L_0x0021
            L_0x002c:
                r5 = -2147483648(0xffffffff80000000, float:-0.0)
                goto L_0x0021
            L_0x002f:
                r5 = 0
                r7 = 0
            L_0x0031:
                int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r5)
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0162m.m600A(int, int, int, int, boolean):int");
        }

        /* renamed from: T */
        public static C0166d m601T(Context context, AttributeSet attributeSet, int i, int i2) {
            C0166d dVar = new C0166d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1242na.f4257a, i, i2);
            dVar.f883a = obtainStyledAttributes.getInt(0, 1);
            dVar.f884b = obtainStyledAttributes.getInt(10, 1);
            dVar.f885c = obtainStyledAttributes.getBoolean(9, false);
            dVar.f886d = obtainStyledAttributes.getBoolean(11, false);
            obtainStyledAttributes.recycle();
            return dVar;
        }

        /* renamed from: b0 */
        public static boolean m602b0(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (i3 > 0 && i != i3) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i;
            }
            return true;
        }

        /* renamed from: h */
        public static int m603h(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i2, i3) : size : Math.min(size, Math.max(i2, i3));
        }

        @Deprecated
        /* renamed from: A0 */
        public boolean mo1106A0(RecyclerView recyclerView) {
            return recyclerView.mo952O();
        }

        /* renamed from: B */
        public int mo847B(C0173s sVar, C0178w wVar) {
            return -1;
        }

        /* renamed from: B0 */
        public boolean mo1107B0(RecyclerView recyclerView, View view, View view2) {
            return mo1106A0(recyclerView);
        }

        /* renamed from: C */
        public int mo1108C(View view) {
            return mo1164x(view) + view.getBottom();
        }

        /* renamed from: C0 */
        public void mo887C0(Parcelable parcelable) {
        }

        /* renamed from: D */
        public void mo1109D(View view, Rect rect) {
            int[] iArr = RecyclerView.f775z0;
            C0167n nVar = (C0167n) view.getLayoutParams();
            Rect rect2 = nVar.f888e;
            rect.set((view.getLeft() - rect2.left) - nVar.leftMargin, (view.getTop() - rect2.top) - nVar.topMargin, view.getRight() + rect2.right + nVar.rightMargin, view.getBottom() + rect2.bottom + nVar.bottomMargin);
        }

        /* renamed from: D0 */
        public Parcelable mo889D0() {
            return null;
        }

        /* renamed from: E */
        public int mo1110E(View view) {
            return view.getLeft() - mo1124L(view);
        }

        /* renamed from: E0 */
        public void mo1111E0(int i) {
        }

        /* renamed from: F */
        public int mo1112F(View view) {
            Rect rect = ((C0167n) view.getLayoutParams()).f888e;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        /* JADX WARNING: Removed duplicated region for block: B:25:0x006e A[ADDED_TO_REGION] */
        /* renamed from: F0 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1113F0(int r11) {
            /*
                r10 = this;
                androidx.recyclerview.widget.RecyclerView r0 = r10.f866b
                r1 = 0
                if (r0 != 0) goto L_0x0006
                return r1
            L_0x0006:
                r2 = 4096(0x1000, float:5.74E-42)
                r3 = 1
                if (r11 == r2) goto L_0x003e
                r2 = 8192(0x2000, float:1.14794E-41)
                if (r11 == r2) goto L_0x0012
                r5 = 0
                r6 = 0
                goto L_0x006c
            L_0x0012:
                r11 = -1
                boolean r0 = r0.canScrollVertically(r11)
                if (r0 == 0) goto L_0x0027
                int r0 = r10.f880p
                int r2 = r10.mo1133R()
                int r0 = r0 - r2
                int r2 = r10.mo1130O()
                int r0 = r0 - r2
                int r0 = -r0
                goto L_0x0028
            L_0x0027:
                r0 = 0
            L_0x0028:
                androidx.recyclerview.widget.RecyclerView r2 = r10.f866b
                boolean r11 = r2.canScrollHorizontally(r11)
                if (r11 == 0) goto L_0x006a
                int r11 = r10.f879o
                int r2 = r10.mo1131P()
                int r11 = r11 - r2
                int r2 = r10.mo1132Q()
                int r11 = r11 - r2
                int r11 = -r11
                goto L_0x0067
            L_0x003e:
                boolean r11 = r0.canScrollVertically(r3)
                if (r11 == 0) goto L_0x0052
                int r11 = r10.f880p
                int r0 = r10.mo1133R()
                int r11 = r11 - r0
                int r0 = r10.mo1130O()
                int r11 = r11 - r0
                r0 = r11
                goto L_0x0053
            L_0x0052:
                r0 = 0
            L_0x0053:
                androidx.recyclerview.widget.RecyclerView r11 = r10.f866b
                boolean r11 = r11.canScrollHorizontally(r3)
                if (r11 == 0) goto L_0x006a
                int r11 = r10.f879o
                int r2 = r10.mo1131P()
                int r11 = r11 - r2
                int r2 = r10.mo1132Q()
                int r11 = r11 - r2
            L_0x0067:
                r5 = r11
                r6 = r0
                goto L_0x006c
            L_0x006a:
                r6 = r0
                r5 = 0
            L_0x006c:
                if (r6 != 0) goto L_0x0071
                if (r5 != 0) goto L_0x0071
                return r1
            L_0x0071:
                androidx.recyclerview.widget.RecyclerView r4 = r10.f866b
                r7 = 0
                r8 = -2147483648(0xffffffff80000000, float:-0.0)
                r9 = 1
                r4.mo1018j0(r5, r6, r7, r8, r9)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0162m.mo1113F0(int):boolean");
        }

        /* renamed from: G */
        public int mo1114G(View view) {
            Rect rect = ((C0167n) view.getLayoutParams()).f888e;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        /* renamed from: G0 */
        public boolean mo1115G0() {
            return false;
        }

        /* renamed from: H */
        public int mo1116H(View view) {
            return mo1137U(view) + view.getRight();
        }

        /* renamed from: H0 */
        public void mo1117H0() {
            int z = mo1166z();
            while (true) {
                z--;
                if (z >= 0) {
                    this.f865a.mo5213l(z);
                } else {
                    return;
                }
            }
        }

        /* renamed from: I */
        public int mo1118I(View view) {
            return view.getTop() - mo1142X(view);
        }

        /* renamed from: I0 */
        public void mo1119I0(C0173s sVar) {
            for (int z = mo1166z() - 1; z >= 0; z--) {
                if (!RecyclerView.m512K(mo1165y(z)).mo1225t()) {
                    mo1125L0(z, sVar);
                }
            }
        }

        /* renamed from: J */
        public View mo1120J() {
            View focusedChild;
            RecyclerView recyclerView = this.f866b;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.f865a.f4815c.contains(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        /* renamed from: J0 */
        public void mo1121J0(C0173s sVar) {
            int size = sVar.f897a.size();
            for (int i = size - 1; i >= 0; i--) {
                View view = sVar.f897a.get(i).f928a;
                C0181z K = RecyclerView.m512K(view);
                if (!K.mo1225t()) {
                    K.mo1224s(false);
                    if (K.mo1219n()) {
                        this.f866b.removeDetachedView(view, false);
                    }
                    C0156j jVar = this.f866b.f790O;
                    if (jVar != null) {
                        jVar.mo1100e(K);
                    }
                    K.mo1224s(true);
                    C0181z K2 = RecyclerView.m512K(view);
                    K2.f941n = null;
                    K2.f942o = false;
                    K2.mo1209d();
                    sVar.mo1191j(K2);
                }
            }
            sVar.f897a.clear();
            ArrayList<C0181z> arrayList = sVar.f898b;
            if (arrayList != null) {
                arrayList.clear();
            }
            if (size > 0) {
                this.f866b.invalidate();
            }
        }

        /* renamed from: K */
        public int mo1122K() {
            RecyclerView recyclerView = this.f866b;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            return recyclerView.getLayoutDirection();
        }

        /* renamed from: K0 */
        public void mo1123K0(View view, C0173s sVar) {
            C1412pa paVar = this.f865a;
            int indexOfChild = ((C0742gb) paVar.f4813a).f2853a.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (paVar.f4814b.mo5221f(indexOfChild)) {
                    paVar.mo5214m(view);
                }
                ((C0742gb) paVar.f4813a).mo3770c(indexOfChild);
            }
            sVar.mo1190i(view);
        }

        /* renamed from: L */
        public int mo1124L(View view) {
            return ((C0167n) view.getLayoutParams()).f888e.left;
        }

        /* renamed from: L0 */
        public void mo1125L0(int i, C0173s sVar) {
            View y = mo1165y(i);
            if (mo1165y(i) != null) {
                this.f865a.mo5213l(i);
            }
            sVar.mo1190i(y);
        }

        /* renamed from: M */
        public int mo1126M() {
            RecyclerView recyclerView = this.f866b;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            return recyclerView.getMinimumHeight();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:23:0x00b7, code lost:
            if (r1 == false) goto L_0x00be;
         */
        /* renamed from: M0 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1127M0(androidx.recyclerview.widget.RecyclerView r19, android.view.View r20, android.graphics.Rect r21, boolean r22, boolean r23) {
            /*
                r18 = this;
                r0 = r18
                r1 = r21
                r2 = 2
                int[] r2 = new int[r2]
                int r3 = r18.mo1131P()
                int r4 = r18.mo1133R()
                int r5 = r0.f879o
                int r6 = r18.mo1132Q()
                int r5 = r5 - r6
                int r6 = r0.f880p
                int r7 = r18.mo1130O()
                int r6 = r6 - r7
                int r7 = r20.getLeft()
                int r8 = r1.left
                int r7 = r7 + r8
                int r8 = r20.getScrollX()
                int r7 = r7 - r8
                int r8 = r20.getTop()
                int r9 = r1.top
                int r8 = r8 + r9
                int r9 = r20.getScrollY()
                int r8 = r8 - r9
                int r9 = r21.width()
                int r9 = r9 + r7
                int r1 = r21.height()
                int r1 = r1 + r8
                int r7 = r7 - r3
                r3 = 0
                int r10 = java.lang.Math.min(r3, r7)
                int r8 = r8 - r4
                int r4 = java.lang.Math.min(r3, r8)
                int r9 = r9 - r5
                int r5 = java.lang.Math.max(r3, r9)
                int r1 = r1 - r6
                int r1 = java.lang.Math.max(r3, r1)
                int r6 = r18.mo1122K()
                r11 = 1
                if (r6 != r11) goto L_0x0063
                if (r5 == 0) goto L_0x005e
                goto L_0x006b
            L_0x005e:
                int r5 = java.lang.Math.max(r10, r9)
                goto L_0x006b
            L_0x0063:
                if (r10 == 0) goto L_0x0066
                goto L_0x006a
            L_0x0066:
                int r10 = java.lang.Math.min(r7, r5)
            L_0x006a:
                r5 = r10
            L_0x006b:
                if (r4 == 0) goto L_0x006e
                goto L_0x0072
            L_0x006e:
                int r4 = java.lang.Math.min(r8, r1)
            L_0x0072:
                r2[r3] = r5
                r2[r11] = r4
                r13 = r2[r3]
                r14 = r2[r11]
                if (r23 == 0) goto L_0x00b9
                android.view.View r1 = r19.getFocusedChild()
                if (r1 != 0) goto L_0x0084
            L_0x0082:
                r1 = 0
                goto L_0x00b7
            L_0x0084:
                int r2 = r18.mo1131P()
                int r4 = r18.mo1133R()
                int r5 = r0.f879o
                int r6 = r18.mo1132Q()
                int r5 = r5 - r6
                int r6 = r0.f880p
                int r7 = r18.mo1130O()
                int r6 = r6 - r7
                androidx.recyclerview.widget.RecyclerView r7 = r0.f866b
                android.graphics.Rect r7 = r7.f818l
                r0.mo1109D(r1, r7)
                int r1 = r7.left
                int r1 = r1 - r13
                if (r1 >= r5) goto L_0x0082
                int r1 = r7.right
                int r1 = r1 - r13
                if (r1 <= r2) goto L_0x0082
                int r1 = r7.top
                int r1 = r1 - r14
                if (r1 >= r6) goto L_0x0082
                int r1 = r7.bottom
                int r1 = r1 - r14
                if (r1 > r4) goto L_0x00b6
                goto L_0x0082
            L_0x00b6:
                r1 = 1
            L_0x00b7:
                if (r1 == 0) goto L_0x00be
            L_0x00b9:
                if (r13 != 0) goto L_0x00bf
                if (r14 == 0) goto L_0x00be
                goto L_0x00bf
            L_0x00be:
                return r3
            L_0x00bf:
                r1 = r19
                if (r22 == 0) goto L_0x00c7
                r1.scrollBy(r13, r14)
                goto L_0x00d1
            L_0x00c7:
                r17 = 0
                r16 = -2147483648(0xffffffff80000000, float:-0.0)
                r15 = 0
                r12 = r19
                r12.mo1018j0(r13, r14, r15, r16, r17)
            L_0x00d1:
                return r11
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0162m.mo1127M0(androidx.recyclerview.widget.RecyclerView, android.view.View, android.graphics.Rect, boolean, boolean):boolean");
        }

        /* renamed from: N */
        public int mo1128N() {
            RecyclerView recyclerView = this.f866b;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            return recyclerView.getMinimumWidth();
        }

        /* renamed from: N0 */
        public void mo1129N0() {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        /* renamed from: O */
        public int mo1130O() {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        /* renamed from: O0 */
        public int mo858O0(int i, C0173s sVar, C0178w wVar) {
            return 0;
        }

        /* renamed from: P */
        public int mo1131P() {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        /* renamed from: P0 */
        public void mo892P0(int i) {
        }

        /* renamed from: Q */
        public int mo1132Q() {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        /* renamed from: Q0 */
        public int mo860Q0(int i, C0173s sVar, C0178w wVar) {
            return 0;
        }

        /* renamed from: R */
        public int mo1133R() {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        /* renamed from: R0 */
        public void mo1134R0(RecyclerView recyclerView) {
            mo1136S0(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }

        /* renamed from: S */
        public int mo1135S(View view) {
            return ((C0167n) view.getLayoutParams()).mo1173r();
        }

        /* renamed from: S0 */
        public void mo1136S0(int i, int i2) {
            this.f879o = View.MeasureSpec.getSize(i);
            int mode = View.MeasureSpec.getMode(i);
            this.f877m = mode;
            if (mode == 0 && !RecyclerView.f770B0) {
                this.f879o = 0;
            }
            this.f880p = View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.f878n = mode2;
            if (mode2 == 0 && !RecyclerView.f770B0) {
                this.f880p = 0;
            }
        }

        /* renamed from: T0 */
        public void mo861T0(Rect rect, int i, int i2) {
            int Q = mo1132Q() + mo1131P() + rect.width();
            int O = mo1130O() + mo1133R() + rect.height();
            this.f866b.setMeasuredDimension(m603h(i, Q, mo1128N()), m603h(i2, O, mo1126M()));
        }

        /* renamed from: U */
        public int mo1137U(View view) {
            return ((C0167n) view.getLayoutParams()).f888e.right;
        }

        /* renamed from: U0 */
        public void mo1138U0(int i, int i2) {
            int z = mo1166z();
            if (z == 0) {
                this.f866b.mo1026o(i, i2);
                return;
            }
            int i3 = Integer.MIN_VALUE;
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MAX_VALUE;
            int i6 = Integer.MAX_VALUE;
            for (int i7 = 0; i7 < z; i7++) {
                View y = mo1165y(i7);
                Rect rect = this.f866b.f818l;
                mo1109D(y, rect);
                int i8 = rect.left;
                if (i8 < i5) {
                    i5 = i8;
                }
                int i9 = rect.right;
                if (i9 > i3) {
                    i3 = i9;
                }
                int i10 = rect.top;
                if (i10 < i6) {
                    i6 = i10;
                }
                int i11 = rect.bottom;
                if (i11 > i4) {
                    i4 = i11;
                }
            }
            this.f866b.f818l.set(i5, i6, i3, i4);
            mo861T0(this.f866b.f818l, i, i2);
        }

        /* renamed from: V */
        public int mo862V(C0173s sVar, C0178w wVar) {
            return -1;
        }

        /* renamed from: V0 */
        public void mo1139V0(RecyclerView recyclerView) {
            int i;
            if (recyclerView == null) {
                this.f866b = null;
                this.f865a = null;
                i = 0;
                this.f879o = 0;
            } else {
                this.f866b = recyclerView;
                this.f865a = recyclerView.f810h;
                this.f879o = recyclerView.getWidth();
                i = recyclerView.getHeight();
            }
            this.f880p = i;
            this.f877m = 1073741824;
            this.f878n = 1073741824;
        }

        /* renamed from: W */
        public int mo1140W() {
            return 0;
        }

        /* renamed from: W0 */
        public boolean mo1141W0(View view, int i, int i2, C0167n nVar) {
            return view.isLayoutRequested() || !this.f873i || !m602b0(view.getWidth(), i, nVar.width) || !m602b0(view.getHeight(), i2, nVar.height);
        }

        /* renamed from: X */
        public int mo1142X(View view) {
            return ((C0167n) view.getLayoutParams()).f888e.top;
        }

        /* renamed from: X0 */
        public boolean mo893X0() {
            return false;
        }

        /* renamed from: Y */
        public void mo1143Y(View view, boolean z, Rect rect) {
            Matrix matrix;
            if (z) {
                Rect rect2 = ((C0167n) view.getLayoutParams()).f888e;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (!(this.f866b == null || (matrix = view.getMatrix()) == null || matrix.isIdentity())) {
                RectF rectF = this.f866b.f822n;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        /* renamed from: Y0 */
        public boolean mo1144Y0(View view, int i, int i2, C0167n nVar) {
            return !this.f873i || !m602b0(view.getMeasuredWidth(), i, nVar.width) || !m602b0(view.getMeasuredHeight(), i2, nVar.height);
        }

        /* renamed from: Z */
        public boolean mo894Z() {
            return false;
        }

        /* renamed from: Z0 */
        public boolean mo863Z0() {
            return false;
        }

        /* renamed from: a */
        public void mo1145a(View view) {
            mo1147b(view, -1, false);
        }

        /* renamed from: a0 */
        public boolean mo1146a0() {
            return false;
        }

        /* renamed from: b */
        public final void mo1147b(View view, int i, boolean z) {
            C0181z K = RecyclerView.m512K(view);
            if (z || K.mo1217l()) {
                this.f866b.f812i.mo4412a(K);
            } else {
                this.f866b.f812i.mo4417f(K);
            }
            C0167n nVar = (C0167n) view.getLayoutParams();
            if (K.mo1227u() || K.mo1218m()) {
                if (K.mo1218m()) {
                    K.f941n.mo1194m(K);
                } else {
                    K.mo1209d();
                }
                this.f865a.mo5203b(view, i, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f866b) {
                int j = this.f865a.mo5211j(view);
                if (i == -1) {
                    i = this.f865a.mo5206e();
                }
                if (j == -1) {
                    StringBuilder d = C1012kd.m3195d("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                    d.append(this.f866b.indexOfChild(view));
                    throw new IllegalStateException(C1012kd.m3197f(this.f866b, d));
                } else if (j != i) {
                    C0162m mVar = this.f866b.f826p;
                    View y = mVar.mo1165y(j);
                    if (y != null) {
                        mVar.mo1165y(j);
                        mVar.mo1161r(j);
                        C0167n nVar2 = (C0167n) y.getLayoutParams();
                        C0181z K2 = RecyclerView.m512K(y);
                        if (K2.mo1217l()) {
                            mVar.f866b.f812i.mo4412a(K2);
                        } else {
                            mVar.f866b.f812i.mo4417f(K2);
                        }
                        mVar.f865a.mo5203b(y, i, nVar2, K2.mo1217l());
                    } else {
                        throw new IllegalArgumentException("Cannot move a child from non-existing index:" + j + mVar.f866b.toString());
                    }
                }
            } else {
                this.f865a.mo5202a(view, i, false);
                nVar.f889f = true;
            }
            if (nVar.f890g) {
                K.f928a.invalidate();
                nVar.f890g = false;
            }
        }

        /* renamed from: c */
        public void mo896c(String str) {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                recyclerView.mo1013i(str);
            }
        }

        /* renamed from: c0 */
        public boolean mo1148c0(View view, boolean z) {
            boolean z2 = this.f869e.mo4268b(view, 24579) && this.f870f.mo4268b(view, 24579);
            return z ? z2 : !z2;
        }

        /* renamed from: d */
        public void mo1149d(View view, Rect rect) {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.mo949L(view));
            }
        }

        /* renamed from: d0 */
        public void mo1150d0(View view, int i, int i2, int i3, int i4) {
            C0167n nVar = (C0167n) view.getLayoutParams();
            Rect rect = nVar.f888e;
            view.layout(i + rect.left + nVar.leftMargin, i2 + rect.top + nVar.topMargin, (i3 - rect.right) - nVar.rightMargin, (i4 - rect.bottom) - nVar.bottomMargin);
        }

        /* renamed from: e */
        public boolean mo899e() {
            return false;
        }

        /* renamed from: e0 */
        public void mo1151e0(int i) {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                int e = recyclerView.f810h.mo5206e();
                for (int i2 = 0; i2 < e; i2++) {
                    recyclerView.f810h.mo5205d(i2).offsetLeftAndRight(i);
                }
            }
        }

        /* renamed from: f */
        public boolean mo901f() {
            return false;
        }

        /* renamed from: f0 */
        public void mo1152f0(int i) {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null) {
                int e = recyclerView.f810h.mo5206e();
                for (int i2 = 0; i2 < e; i2++) {
                    recyclerView.f810h.mo5205d(i2).offsetTopAndBottom(i);
                }
            }
        }

        /* renamed from: g */
        public boolean mo865g(C0167n nVar) {
            return nVar != null;
        }

        /* renamed from: g0 */
        public void mo1153g0(C0150e eVar, C0150e eVar2) {
        }

        /* renamed from: h0 */
        public boolean mo1154h0() {
            return false;
        }

        /* renamed from: i */
        public void mo905i(int i, int i2, C0178w wVar, C0165c cVar) {
        }

        /* renamed from: i0 */
        public void mo1155i0(RecyclerView recyclerView) {
        }

        /* renamed from: j */
        public void mo907j(int i, C0165c cVar) {
        }

        @Deprecated
        /* renamed from: j0 */
        public void mo1156j0() {
        }

        /* renamed from: k */
        public int mo909k(C0178w wVar) {
            return 0;
        }

        /* renamed from: k0 */
        public void mo910k0(RecyclerView recyclerView, C0173s sVar) {
            mo1156j0();
        }

        /* renamed from: l */
        public int mo866l(C0178w wVar) {
            return 0;
        }

        /* renamed from: l0 */
        public View mo867l0(View view, int i, C0173s sVar, C0178w wVar) {
            return null;
        }

        /* renamed from: m */
        public int mo868m(C0178w wVar) {
            return 0;
        }

        /* renamed from: m0 */
        public void mo913m0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f866b;
            C0173s sVar = recyclerView.f804e;
            C0178w wVar = recyclerView.f813i0;
            mo1157n0(accessibilityEvent);
        }

        /* renamed from: n */
        public int mo915n(C0178w wVar) {
            return 0;
        }

        /* renamed from: n0 */
        public void mo1157n0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f866b;
            if (recyclerView != null && accessibilityEvent != null) {
                boolean z = true;
                if (!recyclerView.canScrollVertically(1) && !this.f866b.canScrollVertically(-1) && !this.f866b.canScrollHorizontally(-1) && !this.f866b.canScrollHorizontally(1)) {
                    z = false;
                }
                accessibilityEvent.setScrollable(z);
                C0150e eVar = this.f866b.f824o;
                if (eVar != null) {
                    accessibilityEvent.setItemCount(eVar.mo1085a());
                }
            }
        }

        /* renamed from: o */
        public int mo870o(C0178w wVar) {
            return 0;
        }

        /* renamed from: o0 */
        public void mo1158o0(View view, C1226n7 n7Var) {
            C0181z K = RecyclerView.m512K(view);
            if (K != null && !K.mo1217l() && !this.f865a.mo5212k(K.f928a)) {
                RecyclerView recyclerView = this.f866b;
                mo872p0(recyclerView.f804e, recyclerView.f813i0, view, n7Var);
            }
        }

        /* renamed from: p */
        public int mo871p(C0178w wVar) {
            return 0;
        }

        /* renamed from: p0 */
        public void mo872p0(C0173s sVar, C0178w wVar, View view, C1226n7 n7Var) {
        }

        /* renamed from: q */
        public void mo1159q(C0173s sVar) {
            for (int z = mo1166z() - 1; z >= 0; z--) {
                View y = mo1165y(z);
                C0181z K = RecyclerView.m512K(y);
                if (!K.mo1225t()) {
                    if (!K.mo1215j() || K.mo1217l()) {
                        mo1165y(z);
                        mo1161r(z);
                        sVar.mo1192k(y);
                        this.f866b.f812i.mo4417f(K);
                    } else {
                        Objects.requireNonNull(this.f866b.f824o);
                        if (mo1165y(z) != null) {
                            this.f865a.mo5213l(z);
                        }
                        sVar.mo1191j(K);
                    }
                }
            }
        }

        /* renamed from: q0 */
        public View mo1160q0() {
            return null;
        }

        /* renamed from: r */
        public final void mo1161r(int i) {
            this.f865a.mo5204c(i);
        }

        /* renamed from: r0 */
        public void mo873r0(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: s */
        public View mo1162s(View view) {
            View C;
            RecyclerView recyclerView = this.f866b;
            if (recyclerView == null || (C = recyclerView.mo942C(view)) == null || this.f865a.f4815c.contains(C)) {
                return null;
            }
            return C;
        }

        /* renamed from: s0 */
        public void mo874s0(RecyclerView recyclerView) {
        }

        /* renamed from: t */
        public View mo921t(int i) {
            int z = mo1166z();
            for (int i2 = 0; i2 < z; i2++) {
                View y = mo1165y(i2);
                C0181z K = RecyclerView.m512K(y);
                if (K != null && K.mo1210e() == i && !K.mo1225t() && (this.f866b.f813i0.f912f || !K.mo1217l())) {
                    return y;
                }
            }
            return null;
        }

        /* renamed from: t0 */
        public void mo875t0(RecyclerView recyclerView, int i, int i2, int i3) {
        }

        /* renamed from: u */
        public abstract C0167n mo877u();

        /* renamed from: u0 */
        public void mo878u0(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: v */
        public C0167n mo880v(Context context, AttributeSet attributeSet) {
            return new C0167n(context, attributeSet);
        }

        /* renamed from: v0 */
        public void mo1163v0(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: w */
        public C0167n mo881w(ViewGroup.LayoutParams layoutParams) {
            return layoutParams instanceof C0167n ? new C0167n((C0167n) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0167n((ViewGroup.MarginLayoutParams) layoutParams) : new C0167n(layoutParams);
        }

        /* renamed from: w0 */
        public void mo882w0(RecyclerView recyclerView, int i, int i2, Object obj) {
            mo1163v0(recyclerView, i, i2);
        }

        /* renamed from: x */
        public int mo1164x(View view) {
            return ((C0167n) view.getLayoutParams()).f888e.bottom;
        }

        /* renamed from: x0 */
        public void mo883x0(C0173s sVar, C0178w wVar) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        /* renamed from: y */
        public View mo1165y(int i) {
            C1412pa paVar = this.f865a;
            if (paVar == null) {
                return null;
            }
            return ((C0742gb) paVar.f4813a).mo3768a(paVar.mo5207f(i));
        }

        /* renamed from: y0 */
        public void mo884y0(C0178w wVar) {
        }

        /* renamed from: z */
        public int mo1166z() {
            C1412pa paVar = this.f865a;
            if (paVar != null) {
                return paVar.mo5206e();
            }
            return 0;
        }

        /* renamed from: z0 */
        public void mo1167z0(int i, int i2) {
            this.f866b.mo1026o(i, i2);
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$n */
    public static class C0167n extends ViewGroup.MarginLayoutParams {

        /* renamed from: d */
        public C0181z f887d;

        /* renamed from: e */
        public final Rect f888e = new Rect();

        /* renamed from: f */
        public boolean f889f = true;

        /* renamed from: g */
        public boolean f890g = false;

        public C0167n(int i, int i2) {
            super(i, i2);
        }

        public C0167n(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0167n(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0167n(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0167n(C0167n nVar) {
            super(nVar);
        }

        /* renamed from: r */
        public int mo1173r() {
            return this.f887d.mo1210e();
        }

        /* renamed from: s */
        public boolean mo1174s() {
            return this.f887d.mo1220o();
        }

        /* renamed from: t */
        public boolean mo1175t() {
            return this.f887d.mo1217l();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$o */
    public static abstract class C0168o {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$p */
    public interface C0169p {
        /* renamed from: a */
        boolean mo1176a(RecyclerView recyclerView, MotionEvent motionEvent);

        /* renamed from: b */
        void mo1177b(RecyclerView recyclerView, MotionEvent motionEvent);

        /* renamed from: c */
        void mo1178c(boolean z);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$q */
    public static abstract class C0170q {
        /* renamed from: a */
        public void mo1179a(RecyclerView recyclerView, int i, int i2) {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$r */
    public static class C0171r {

        /* renamed from: a */
        public SparseArray<C0172a> f891a = new SparseArray<>();

        /* renamed from: b */
        public int f892b = 0;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$r$a */
        public static class C0172a {

            /* renamed from: a */
            public final ArrayList<C0181z> f893a = new ArrayList<>();

            /* renamed from: b */
            public int f894b = 5;

            /* renamed from: c */
            public long f895c = 0;

            /* renamed from: d */
            public long f896d = 0;
        }

        /* renamed from: a */
        public final C0172a mo1180a(int i) {
            C0172a aVar = this.f891a.get(i);
            if (aVar != null) {
                return aVar;
            }
            C0172a aVar2 = new C0172a();
            this.f891a.put(i, aVar2);
            return aVar2;
        }

        /* renamed from: b */
        public long mo1181b(long j, long j2) {
            if (j == 0) {
                return j2;
            }
            return (j2 / 4) + ((j / 4) * 3);
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$s */
    public final class C0173s {

        /* renamed from: a */
        public final ArrayList<C0181z> f897a;

        /* renamed from: b */
        public ArrayList<C0181z> f898b = null;

        /* renamed from: c */
        public final ArrayList<C0181z> f899c = new ArrayList<>();

        /* renamed from: d */
        public final List<C0181z> f900d;

        /* renamed from: e */
        public int f901e;

        /* renamed from: f */
        public int f902f;

        /* renamed from: g */
        public C0171r f903g;

        public C0173s() {
            ArrayList<C0181z> arrayList = new ArrayList<>();
            this.f897a = arrayList;
            this.f900d = Collections.unmodifiableList(arrayList);
            this.f901e = 2;
            this.f902f = 2;
        }

        /* renamed from: a */
        public void mo1182a(C0181z zVar, boolean z) {
            RecyclerView.m517k(zVar);
            View view = zVar.f928a;
            C0882ib ibVar = RecyclerView.this.f827p0;
            if (ibVar != null) {
                C0882ib.C0883a aVar = ibVar.f3244e;
                C0010a7.m43p(view, aVar instanceof C0882ib.C0883a ? aVar.f3246e.remove(view) : null);
            }
            if (z) {
                C0174t tVar = RecyclerView.this.f828q;
                if (tVar != null) {
                    tVar.mo1196a(zVar);
                }
                RecyclerView recyclerView = RecyclerView.this;
                C0150e eVar = recyclerView.f824o;
                if (recyclerView.f813i0 != null) {
                    recyclerView.f812i.mo4418g(zVar);
                }
            }
            zVar.f946s = null;
            zVar.f945r = null;
            C0171r d = mo1185d();
            Objects.requireNonNull(d);
            int i = zVar.f933f;
            ArrayList<C0181z> arrayList = d.mo1180a(i).f893a;
            if (d.f891a.get(i).f894b > arrayList.size()) {
                zVar.mo1222q();
                arrayList.add(zVar);
            }
        }

        /* renamed from: b */
        public void mo1183b() {
            this.f897a.clear();
            mo1188g();
        }

        /* renamed from: c */
        public int mo1184c(int i) {
            if (i < 0 || i >= RecyclerView.this.f813i0.mo1202b()) {
                StringBuilder sb = new StringBuilder();
                sb.append("invalid position ");
                sb.append(i);
                sb.append(". State item count is ");
                sb.append(RecyclerView.this.f813i0.mo1202b());
                throw new IndexOutOfBoundsException(C1012kd.m3197f(RecyclerView.this, sb));
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.f813i0.f912f) {
                return i;
            }
            return recyclerView.f808g.mo5029f(i, 0);
        }

        /* renamed from: d */
        public C0171r mo1185d() {
            if (this.f903g == null) {
                this.f903g = new C0171r();
            }
            return this.f903g;
        }

        /* renamed from: e */
        public View mo1186e(int i) {
            return mo1193l(i, false, Long.MAX_VALUE).f928a;
        }

        /* renamed from: f */
        public final void mo1187f(ViewGroup viewGroup, boolean z) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    mo1187f((ViewGroup) childAt, true);
                }
            }
            if (z) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                    return;
                }
                int visibility = viewGroup.getVisibility();
                viewGroup.setVisibility(4);
                viewGroup.setVisibility(visibility);
            }
        }

        /* renamed from: g */
        public void mo1188g() {
            for (int size = this.f899c.size() - 1; size >= 0; size--) {
                mo1189h(size);
            }
            this.f899c.clear();
            if (RecyclerView.f772D0) {
                C0021ab.C0023b bVar = RecyclerView.this.f811h0;
                int[] iArr = bVar.f68c;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                bVar.f69d = 0;
            }
        }

        /* renamed from: h */
        public void mo1189h(int i) {
            mo1182a(this.f899c.get(i), true);
            this.f899c.remove(i);
        }

        /* renamed from: i */
        public void mo1190i(View view) {
            C0181z K = RecyclerView.m512K(view);
            if (K.mo1219n()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (K.mo1218m()) {
                K.f941n.mo1194m(K);
            } else if (K.mo1227u()) {
                K.mo1209d();
            }
            mo1191j(K);
            if (RecyclerView.this.f790O != null && !K.mo1216k()) {
                RecyclerView.this.f790O.mo1100e(K);
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:20:0x0042  */
        /* JADX WARNING: Removed duplicated region for block: B:45:0x00a2 A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:60:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
        /* renamed from: j */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1191j(androidx.recyclerview.widget.RecyclerView.C0181z r6) {
            /*
                r5 = this;
                boolean r0 = r6.mo1218m()
                r1 = 0
                r2 = 1
                if (r0 != 0) goto L_0x00d7
                android.view.View r0 = r6.f928a
                android.view.ViewParent r0 = r0.getParent()
                if (r0 == 0) goto L_0x0012
                goto L_0x00d7
            L_0x0012:
                boolean r0 = r6.mo1219n()
                if (r0 != 0) goto L_0x00be
                boolean r0 = r6.mo1225t()
                if (r0 != 0) goto L_0x00ac
                int r0 = r6.f937j
                r0 = r0 & 16
                if (r0 != 0) goto L_0x0030
                android.view.View r0 = r6.f928a
                java.util.WeakHashMap<android.view.View, java.lang.String> r3 = p000.C0010a7.f28a
                boolean r0 = r0.hasTransientState()
                if (r0 == 0) goto L_0x0030
                r0 = 1
                goto L_0x0031
            L_0x0030:
                r0 = 0
            L_0x0031:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r3 = r3.f824o
                if (r3 == 0) goto L_0x003c
                if (r0 == 0) goto L_0x003c
                java.util.Objects.requireNonNull(r3)
            L_0x003c:
                boolean r3 = r6.mo1216k()
                if (r3 == 0) goto L_0x0098
                int r3 = r5.f902f
                if (r3 <= 0) goto L_0x0091
                r3 = 526(0x20e, float:7.37E-43)
                boolean r3 = r6.mo1212g(r3)
                if (r3 != 0) goto L_0x0091
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r3 = r5.f899c
                int r3 = r3.size()
                int r4 = r5.f902f
                if (r3 < r4) goto L_0x005f
                if (r3 <= 0) goto L_0x005f
                r5.mo1189h(r1)
                int r3 = r3 + -1
            L_0x005f:
                boolean r1 = androidx.recyclerview.widget.RecyclerView.f772D0
                if (r1 == 0) goto L_0x008a
                if (r3 <= 0) goto L_0x008a
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                ab$b r1 = r1.f811h0
                int r4 = r6.f930c
                boolean r1 = r1.mo75c(r4)
                if (r1 != 0) goto L_0x008a
            L_0x0071:
                int r3 = r3 + -1
                if (r3 < 0) goto L_0x0089
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r1 = r5.f899c
                java.lang.Object r1 = r1.get(r3)
                androidx.recyclerview.widget.RecyclerView$z r1 = (androidx.recyclerview.widget.RecyclerView.C0181z) r1
                int r1 = r1.f930c
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                ab$b r4 = r4.f811h0
                boolean r1 = r4.mo75c(r1)
                if (r1 != 0) goto L_0x0071
            L_0x0089:
                int r3 = r3 + r2
            L_0x008a:
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r1 = r5.f899c
                r1.add(r3, r6)
                r1 = 1
                goto L_0x0092
            L_0x0091:
                r1 = 0
            L_0x0092:
                if (r1 != 0) goto L_0x0098
                r5.mo1182a(r6, r2)
                goto L_0x0099
            L_0x0098:
                r2 = 0
            L_0x0099:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                lb r3 = r3.f812i
                r3.mo4418g(r6)
                if (r1 != 0) goto L_0x00ab
                if (r2 != 0) goto L_0x00ab
                if (r0 == 0) goto L_0x00ab
                r0 = 0
                r6.f946s = r0
                r6.f945r = r0
            L_0x00ab:
                return
            L_0x00ac:
                java.lang.IllegalArgumentException r6 = new java.lang.IllegalArgumentException
                java.lang.String r0 = "Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle."
                java.lang.StringBuilder r0 = p000.C1012kd.m3195d(r0)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r0 = p000.C1012kd.m3197f(r1, r0)
                r6.<init>(r0)
                throw r6
            L_0x00be:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "Tmp detached view should be removed from RecyclerView before it can be recycled: "
                r1.append(r2)
                r1.append(r6)
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r6 = p000.C1012kd.m3197f(r6, r1)
                r0.<init>(r6)
                throw r0
            L_0x00d7:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.String r2 = "Scrapped or attached views may not be recycled. isScrap:"
                java.lang.StringBuilder r2 = p000.C1012kd.m3195d(r2)
                boolean r3 = r6.mo1218m()
                r2.append(r3)
                java.lang.String r3 = " isAttached:"
                r2.append(r3)
                android.view.View r6 = r6.f928a
                android.view.ViewParent r6 = r6.getParent()
                if (r6 == 0) goto L_0x00f4
                r1 = 1
            L_0x00f4:
                r2.append(r1)
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r6 = p000.C1012kd.m3197f(r6, r2)
                r0.<init>(r6)
                goto L_0x0102
            L_0x0101:
                throw r0
            L_0x0102:
                goto L_0x0101
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0173s.mo1191j(androidx.recyclerview.widget.RecyclerView$z):void");
        }

        /* JADX WARNING: Removed duplicated region for block: B:18:0x003d  */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x0043  */
        /* renamed from: k */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1192k(android.view.View r5) {
            /*
                r4 = this;
                androidx.recyclerview.widget.RecyclerView$z r5 = androidx.recyclerview.widget.RecyclerView.m512K(r5)
                r0 = 12
                boolean r0 = r5.mo1212g(r0)
                r1 = 0
                if (r0 != 0) goto L_0x0055
                boolean r0 = r5.mo1220o()
                if (r0 == 0) goto L_0x0055
                androidx.recyclerview.widget.RecyclerView r0 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$j r0 = r0.f790O
                r2 = 1
                if (r0 == 0) goto L_0x003f
                java.util.List r3 = r5.mo1211f()
                ya r0 = (p000.C2130ya) r0
                boolean r3 = r3.isEmpty()
                if (r3 == 0) goto L_0x0039
                boolean r0 = r0.f3391g
                if (r0 == 0) goto L_0x0033
                boolean r0 = r5.mo1215j()
                if (r0 == 0) goto L_0x0031
                goto L_0x0033
            L_0x0031:
                r0 = 0
                goto L_0x0034
            L_0x0033:
                r0 = 1
            L_0x0034:
                if (r0 == 0) goto L_0x0037
                goto L_0x0039
            L_0x0037:
                r0 = 0
                goto L_0x003a
            L_0x0039:
                r0 = 1
            L_0x003a:
                if (r0 == 0) goto L_0x003d
                goto L_0x003f
            L_0x003d:
                r0 = 0
                goto L_0x0040
            L_0x003f:
                r0 = 1
            L_0x0040:
                if (r0 == 0) goto L_0x0043
                goto L_0x0055
            L_0x0043:
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r0 = r4.f898b
                if (r0 != 0) goto L_0x004e
                java.util.ArrayList r0 = new java.util.ArrayList
                r0.<init>()
                r4.f898b = r0
            L_0x004e:
                r5.f941n = r4
                r5.f942o = r2
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r0 = r4.f898b
                goto L_0x0081
            L_0x0055:
                boolean r0 = r5.mo1215j()
                if (r0 == 0) goto L_0x007b
                boolean r0 = r5.mo1217l()
                if (r0 == 0) goto L_0x0062
                goto L_0x007b
            L_0x0062:
                androidx.recyclerview.widget.RecyclerView r5 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r5 = r5.f824o
                java.util.Objects.requireNonNull(r5)
                java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
                java.lang.String r0 = "Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool."
                java.lang.StringBuilder r0 = p000.C1012kd.m3195d(r0)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r0 = p000.C1012kd.m3197f(r1, r0)
                r5.<init>(r0)
                throw r5
            L_0x007b:
                r5.f941n = r4
                r5.f942o = r1
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r0 = r4.f897a
            L_0x0081:
                r0.add(r5)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0173s.mo1192k(android.view.View):void");
        }

        /* JADX WARNING: Code restructure failed: missing block: B:181:0x037d, code lost:
            if (r7.mo1215j() == false) goto L_0x03ae;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:190:0x03ac, code lost:
            if ((r10 == 0 || r10 + r13 < r19) == false) goto L_0x03ae;
         */
        /* JADX WARNING: Removed duplicated region for block: B:107:0x020a  */
        /* JADX WARNING: Removed duplicated region for block: B:167:0x0344  */
        /* JADX WARNING: Removed duplicated region for block: B:172:0x0365  */
        /* JADX WARNING: Removed duplicated region for block: B:173:0x0368  */
        /* JADX WARNING: Removed duplicated region for block: B:237:0x0475  */
        /* JADX WARNING: Removed duplicated region for block: B:238:0x047c  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x0056  */
        /* renamed from: l */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public androidx.recyclerview.widget.RecyclerView.C0181z mo1193l(int r17, boolean r18, long r19) {
            /*
                r16 = this;
                r1 = r16
                r0 = r17
                if (r0 < 0) goto L_0x049e
                androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r2 = r2.f813i0
                int r2 = r2.mo1202b()
                if (r0 >= r2) goto L_0x049e
                androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r2 = r2.f813i0
                boolean r2 = r2.f912f
                r3 = 32
                r4 = 0
                r5 = 0
                if (r2 == 0) goto L_0x0051
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r2 = r1.f898b
                if (r2 == 0) goto L_0x004c
                int r2 = r2.size()
                if (r2 != 0) goto L_0x0027
                goto L_0x004c
            L_0x0027:
                r6 = 0
            L_0x0028:
                if (r6 >= r2) goto L_0x0045
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r7 = r1.f898b
                java.lang.Object r7 = r7.get(r6)
                androidx.recyclerview.widget.RecyclerView$z r7 = (androidx.recyclerview.widget.RecyclerView.C0181z) r7
                boolean r8 = r7.mo1227u()
                if (r8 != 0) goto L_0x0042
                int r8 = r7.mo1210e()
                if (r8 != r0) goto L_0x0042
                r7.mo1207b(r3)
                goto L_0x004d
            L_0x0042:
                int r6 = r6 + 1
                goto L_0x0028
            L_0x0045:
                androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r2 = r2.f824o
                java.util.Objects.requireNonNull(r2)
            L_0x004c:
                r7 = r4
            L_0x004d:
                if (r7 == 0) goto L_0x0052
                r2 = 1
                goto L_0x0053
            L_0x0051:
                r7 = r4
            L_0x0052:
                r2 = 0
            L_0x0053:
                r6 = -1
                if (r7 != 0) goto L_0x0201
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r7 = r1.f897a
                int r7 = r7.size()
                r8 = 0
            L_0x005d:
                if (r8 >= r7) goto L_0x0090
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r9 = r1.f897a
                java.lang.Object r9 = r9.get(r8)
                androidx.recyclerview.widget.RecyclerView$z r9 = (androidx.recyclerview.widget.RecyclerView.C0181z) r9
                boolean r10 = r9.mo1227u()
                if (r10 != 0) goto L_0x008d
                int r10 = r9.mo1210e()
                if (r10 != r0) goto L_0x008d
                boolean r10 = r9.mo1215j()
                if (r10 != 0) goto L_0x008d
                androidx.recyclerview.widget.RecyclerView r10 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r10 = r10.f813i0
                boolean r10 = r10.f912f
                if (r10 != 0) goto L_0x0087
                boolean r10 = r9.mo1217l()
                if (r10 != 0) goto L_0x008d
            L_0x0087:
                r9.mo1207b(r3)
                r7 = r9
                goto L_0x0182
            L_0x008d:
                int r8 = r8 + 1
                goto L_0x005d
            L_0x0090:
                if (r18 != 0) goto L_0x0152
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                pa r3 = r3.f810h
                java.util.List<android.view.View> r7 = r3.f4815c
                int r7 = r7.size()
                r8 = 0
            L_0x009d:
                if (r8 >= r7) goto L_0x00c8
                java.util.List<android.view.View> r9 = r3.f4815c
                java.lang.Object r9 = r9.get(r8)
                android.view.View r9 = (android.view.View) r9
                pa$b r10 = r3.f4813a
                gb r10 = (p000.C0742gb) r10
                java.util.Objects.requireNonNull(r10)
                androidx.recyclerview.widget.RecyclerView$z r10 = androidx.recyclerview.widget.RecyclerView.m512K(r9)
                int r11 = r10.mo1210e()
                if (r11 != r0) goto L_0x00c5
                boolean r11 = r10.mo1215j()
                if (r11 != 0) goto L_0x00c5
                boolean r10 = r10.mo1217l()
                if (r10 != 0) goto L_0x00c5
                goto L_0x00c9
            L_0x00c5:
                int r8 = r8 + 1
                goto L_0x009d
            L_0x00c8:
                r9 = r4
            L_0x00c9:
                if (r9 == 0) goto L_0x0152
                androidx.recyclerview.widget.RecyclerView$z r3 = androidx.recyclerview.widget.RecyclerView.m512K(r9)
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                pa r7 = r7.f810h
                pa$b r8 = r7.f4813a
                gb r8 = (p000.C0742gb) r8
                androidx.recyclerview.widget.RecyclerView r8 = r8.f2853a
                int r8 = r8.indexOfChild(r9)
                if (r8 < 0) goto L_0x013b
                pa$a r10 = r7.f4814b
                boolean r10 = r10.mo5219d(r8)
                if (r10 == 0) goto L_0x0124
                pa$a r10 = r7.f4814b
                r10.mo5216a(r8)
                r7.mo5214m(r9)
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                pa r7 = r7.f810h
                int r7 = r7.mo5211j(r9)
                if (r7 == r6) goto L_0x010b
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                pa r8 = r8.f810h
                r8.mo5204c(r7)
                r1.mo1192k(r9)
                r7 = 8224(0x2020, float:1.1524E-41)
                r3.mo1207b(r7)
                r7 = r3
                goto L_0x0182
            L_0x010b:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r4 = "layout index should not be -1 after unhiding a view:"
                r2.append(r4)
                r2.append(r3)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r2 = p000.C1012kd.m3197f(r3, r2)
                r0.<init>(r2)
                throw r0
            L_0x0124:
                java.lang.RuntimeException r0 = new java.lang.RuntimeException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "trying to unhide a view that was not hidden"
                r2.append(r3)
                r2.append(r9)
                java.lang.String r2 = r2.toString()
                r0.<init>(r2)
                throw r0
            L_0x013b:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "view is not a child, cannot hide "
                r2.append(r3)
                r2.append(r9)
                java.lang.String r2 = r2.toString()
                r0.<init>(r2)
                throw r0
            L_0x0152:
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r3 = r1.f899c
                int r3 = r3.size()
                r7 = 0
            L_0x0159:
                if (r7 >= r3) goto L_0x0181
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r8 = r1.f899c
                java.lang.Object r8 = r8.get(r7)
                androidx.recyclerview.widget.RecyclerView$z r8 = (androidx.recyclerview.widget.RecyclerView.C0181z) r8
                boolean r9 = r8.mo1215j()
                if (r9 != 0) goto L_0x017e
                int r9 = r8.mo1210e()
                if (r9 != r0) goto L_0x017e
                boolean r9 = r8.mo1213h()
                if (r9 != 0) goto L_0x017e
                if (r18 != 0) goto L_0x017c
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r3 = r1.f899c
                r3.remove(r7)
            L_0x017c:
                r7 = r8
                goto L_0x0182
            L_0x017e:
                int r7 = r7 + 1
                goto L_0x0159
            L_0x0181:
                r7 = r4
            L_0x0182:
                if (r7 == 0) goto L_0x0201
                boolean r3 = r7.mo1217l()
                if (r3 == 0) goto L_0x0191
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r3 = r3.f813i0
                boolean r3 = r3.f912f
                goto L_0x01bd
            L_0x0191:
                int r3 = r7.f930c
                if (r3 < 0) goto L_0x01e8
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r8 = r8.f824o
                int r8 = r8.mo1085a()
                if (r3 >= r8) goto L_0x01e8
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r8 = r3.f813i0
                boolean r8 = r8.f912f
                if (r8 != 0) goto L_0x01b5
                androidx.recyclerview.widget.RecyclerView$e r3 = r3.f824o
                int r8 = r7.f930c
                int r3 = r3.mo1086b(r8)
                int r8 = r7.f933f
                if (r3 == r8) goto L_0x01b5
                r3 = 0
                goto L_0x01bd
            L_0x01b5:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r3 = r3.f824o
                java.util.Objects.requireNonNull(r3)
                r3 = 1
            L_0x01bd:
                if (r3 != 0) goto L_0x01e6
                if (r18 != 0) goto L_0x01e4
                r3 = 4
                r7.mo1207b(r3)
                boolean r3 = r7.mo1218m()
                if (r3 == 0) goto L_0x01d8
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                android.view.View r8 = r7.f928a
                r3.removeDetachedView(r8, r5)
                androidx.recyclerview.widget.RecyclerView$s r3 = r7.f941n
                r3.mo1194m(r7)
                goto L_0x01e1
            L_0x01d8:
                boolean r3 = r7.mo1227u()
                if (r3 == 0) goto L_0x01e1
                r7.mo1209d()
            L_0x01e1:
                r1.mo1191j(r7)
            L_0x01e4:
                r7 = r4
                goto L_0x0201
            L_0x01e6:
                r2 = 1
                goto L_0x0201
            L_0x01e8:
                java.lang.IndexOutOfBoundsException r0 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "Inconsistency detected. Invalid view holder adapter position"
                r2.append(r3)
                r2.append(r7)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r2 = p000.C1012kd.m3197f(r3, r2)
                r0.<init>(r2)
                throw r0
            L_0x0201:
                r8 = 0
                r10 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
                if (r7 != 0) goto L_0x0327
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                oa r3 = r3.f808g
                int r3 = r3.mo5029f(r0, r5)
                if (r3 < 0) goto L_0x02f6
                androidx.recyclerview.widget.RecyclerView r12 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r12 = r12.f824o
                int r12 = r12.mo1085a()
                if (r3 >= r12) goto L_0x02f6
                androidx.recyclerview.widget.RecyclerView r12 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r12 = r12.f824o
                int r3 = r12.mo1086b(r3)
                androidx.recyclerview.widget.RecyclerView r12 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r12 = r12.f824o
                java.util.Objects.requireNonNull(r12)
                if (r7 != 0) goto L_0x027a
                androidx.recyclerview.widget.RecyclerView$r r7 = r16.mo1185d()
                android.util.SparseArray<androidx.recyclerview.widget.RecyclerView$r$a> r7 = r7.f891a
                java.lang.Object r7 = r7.get(r3)
                androidx.recyclerview.widget.RecyclerView$r$a r7 = (androidx.recyclerview.widget.RecyclerView.C0171r.C0172a) r7
                if (r7 == 0) goto L_0x0265
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r12 = r7.f893a
                boolean r12 = r12.isEmpty()
                if (r12 != 0) goto L_0x0265
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r7 = r7.f893a
                int r12 = r7.size()
                int r12 = r12 + r6
            L_0x024c:
                if (r12 < 0) goto L_0x0265
                java.lang.Object r6 = r7.get(r12)
                androidx.recyclerview.widget.RecyclerView$z r6 = (androidx.recyclerview.widget.RecyclerView.C0181z) r6
                boolean r6 = r6.mo1213h()
                if (r6 != 0) goto L_0x0262
                java.lang.Object r6 = r7.remove(r12)
                androidx.recyclerview.widget.RecyclerView$z r6 = (androidx.recyclerview.widget.RecyclerView.C0181z) r6
                r7 = r6
                goto L_0x0266
            L_0x0262:
                int r12 = r12 + -1
                goto L_0x024c
            L_0x0265:
                r7 = r4
            L_0x0266:
                if (r7 == 0) goto L_0x027a
                r7.mo1222q()
                boolean r6 = androidx.recyclerview.widget.RecyclerView.f769A0
                if (r6 == 0) goto L_0x027a
                android.view.View r6 = r7.f928a
                boolean r12 = r6 instanceof android.view.ViewGroup
                if (r12 == 0) goto L_0x027a
                android.view.ViewGroup r6 = (android.view.ViewGroup) r6
                r1.mo1187f(r6, r5)
            L_0x027a:
                if (r7 != 0) goto L_0x0327
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                long r6 = r6.getNanoTime()
                int r12 = (r19 > r10 ? 1 : (r19 == r10 ? 0 : -1))
                if (r12 == 0) goto L_0x029e
                androidx.recyclerview.widget.RecyclerView$r r12 = r1.f903g
                androidx.recyclerview.widget.RecyclerView$r$a r12 = r12.mo1180a(r3)
                long r12 = r12.f895c
                int r14 = (r12 > r8 ? 1 : (r12 == r8 ? 0 : -1))
                if (r14 == 0) goto L_0x029a
                long r12 = r12 + r6
                int r14 = (r12 > r19 ? 1 : (r12 == r19 ? 0 : -1))
                if (r14 >= 0) goto L_0x0298
                goto L_0x029a
            L_0x0298:
                r12 = 0
                goto L_0x029b
            L_0x029a:
                r12 = 1
            L_0x029b:
                if (r12 != 0) goto L_0x029e
                return r4
            L_0x029e:
                androidx.recyclerview.widget.RecyclerView r12 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r13 = r12.f824o
                java.util.Objects.requireNonNull(r13)
                java.lang.String r14 = "RV CreateView"
                int r15 = p000.C2050x5.f6724a     // Catch:{ all -> 0x02ef }
                android.os.Trace.beginSection(r14)     // Catch:{ all -> 0x02ef }
                androidx.recyclerview.widget.RecyclerView$z r12 = r13.mo1088d(r12, r3)     // Catch:{ all -> 0x02ef }
                android.view.View r13 = r12.f928a     // Catch:{ all -> 0x02ef }
                android.view.ViewParent r13 = r13.getParent()     // Catch:{ all -> 0x02ef }
                if (r13 != 0) goto L_0x02e7
                r12.f933f = r3     // Catch:{ all -> 0x02ef }
                android.os.Trace.endSection()
                boolean r13 = androidx.recyclerview.widget.RecyclerView.f772D0
                if (r13 == 0) goto L_0x02d0
                android.view.View r13 = r12.f928a
                androidx.recyclerview.widget.RecyclerView r13 = androidx.recyclerview.widget.RecyclerView.m511F(r13)
                if (r13 == 0) goto L_0x02d0
                java.lang.ref.WeakReference r14 = new java.lang.ref.WeakReference
                r14.<init>(r13)
                r12.f929b = r14
            L_0x02d0:
                androidx.recyclerview.widget.RecyclerView r13 = androidx.recyclerview.widget.RecyclerView.this
                long r13 = r13.getNanoTime()
                androidx.recyclerview.widget.RecyclerView$r r15 = r1.f903g
                long r13 = r13 - r6
                androidx.recyclerview.widget.RecyclerView$r$a r3 = r15.mo1180a(r3)
                long r6 = r3.f895c
                long r6 = r15.mo1181b(r6, r13)
                r3.f895c = r6
                r7 = r12
                goto L_0x0327
            L_0x02e7:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x02ef }
                java.lang.String r2 = "ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)"
                r0.<init>(r2)     // Catch:{ all -> 0x02ef }
                throw r0     // Catch:{ all -> 0x02ef }
            L_0x02ef:
                r0 = move-exception
                int r2 = p000.C2050x5.f6724a
                android.os.Trace.endSection()
                throw r0
            L_0x02f6:
                java.lang.IndexOutOfBoundsException r2 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r4 = new java.lang.StringBuilder
                r4.<init>()
                java.lang.String r5 = "Inconsistency detected. Invalid item position "
                r4.append(r5)
                r4.append(r0)
                java.lang.String r0 = "(offset:"
                r4.append(r0)
                r4.append(r3)
                java.lang.String r0 = ").state:"
                r4.append(r0)
                androidx.recyclerview.widget.RecyclerView r0 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r0 = r0.f813i0
                int r0 = r0.mo1202b()
                r4.append(r0)
                androidx.recyclerview.widget.RecyclerView r0 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r0 = p000.C1012kd.m3197f(r0, r4)
                r2.<init>(r0)
                throw r2
            L_0x0327:
                if (r2 == 0) goto L_0x0357
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r3 = r3.f813i0
                boolean r3 = r3.f912f
                if (r3 != 0) goto L_0x0357
                r3 = 8192(0x2000, float:1.14794E-41)
                boolean r6 = r7.mo1212g(r3)
                if (r6 == 0) goto L_0x0357
                r7.mo1223r(r5, r3)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r3 = r3.f813i0
                boolean r3 = r3.f915i
                if (r3 == 0) goto L_0x0357
                androidx.recyclerview.widget.RecyclerView.C0156j.m590b(r7)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$j r3 = r3.f790O
                r7.mo1211f()
                androidx.recyclerview.widget.RecyclerView$j$c r3 = r3.mo1103h(r7)
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                r6.mo966b0(r7, r3)
            L_0x0357:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r3 = r3.f813i0
                boolean r3 = r3.f912f
                if (r3 == 0) goto L_0x0368
                boolean r3 = r7.mo1214i()
                if (r3 == 0) goto L_0x0368
                r7.f934g = r0
                goto L_0x03ae
            L_0x0368:
                boolean r3 = r7.mo1214i()
                if (r3 == 0) goto L_0x037f
                int r3 = r7.f937j
                r3 = r3 & 2
                if (r3 == 0) goto L_0x0376
                r3 = 1
                goto L_0x0377
            L_0x0376:
                r3 = 0
            L_0x0377:
                if (r3 != 0) goto L_0x037f
                boolean r3 = r7.mo1215j()
                if (r3 == 0) goto L_0x03ae
            L_0x037f:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                oa r3 = r3.f808g
                int r3 = r3.mo5029f(r0, r5)
                r7.f946s = r4
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                r7.f945r = r6
                int r12 = r7.f933f
                long r13 = r6.getNanoTime()
                int r6 = (r19 > r10 ? 1 : (r19 == r10 ? 0 : -1))
                if (r6 == 0) goto L_0x03b1
                androidx.recyclerview.widget.RecyclerView$r r6 = r1.f903g
                androidx.recyclerview.widget.RecyclerView$r$a r6 = r6.mo1180a(r12)
                long r10 = r6.f896d
                int r6 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
                if (r6 == 0) goto L_0x03ab
                long r10 = r10 + r13
                int r6 = (r10 > r19 ? 1 : (r10 == r19 ? 0 : -1))
                if (r6 >= 0) goto L_0x03a9
                goto L_0x03ab
            L_0x03a9:
                r6 = 0
                goto L_0x03ac
            L_0x03ab:
                r6 = 1
            L_0x03ac:
                if (r6 != 0) goto L_0x03b1
            L_0x03ae:
                r0 = 0
                goto L_0x046d
            L_0x03b1:
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$e r6 = r6.f824o
                java.util.Objects.requireNonNull(r6)
                androidx.recyclerview.widget.RecyclerView$e<? extends androidx.recyclerview.widget.RecyclerView$z> r8 = r7.f946s
                if (r8 != 0) goto L_0x03be
                r8 = 1
                goto L_0x03bf
            L_0x03be:
                r8 = 0
            L_0x03bf:
                if (r8 == 0) goto L_0x03d0
                r7.f930c = r3
                r9 = 519(0x207, float:7.27E-43)
                r10 = 1
                r7.mo1223r(r10, r9)
                int r9 = p000.C2050x5.f6724a
                java.lang.String r9 = "RV OnBindView"
                android.os.Trace.beginSection(r9)
            L_0x03d0:
                r7.f946s = r6
                r7.mo1211f()
                r6.mo1087c(r7, r3)
                if (r8 == 0) goto L_0x03fb
                java.util.List<java.lang.Object> r3 = r7.f938k
                if (r3 == 0) goto L_0x03e1
                r3.clear()
            L_0x03e1:
                int r3 = r7.f937j
                r3 = r3 & -1025(0xfffffffffffffbff, float:NaN)
                r7.f937j = r3
                android.view.View r3 = r7.f928a
                android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
                boolean r6 = r3 instanceof androidx.recyclerview.widget.RecyclerView.C0167n
                if (r6 == 0) goto L_0x03f6
                androidx.recyclerview.widget.RecyclerView$n r3 = (androidx.recyclerview.widget.RecyclerView.C0167n) r3
                r6 = 1
                r3.f889f = r6
            L_0x03f6:
                int r3 = p000.C2050x5.f6724a
                android.os.Trace.endSection()
            L_0x03fb:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                long r8 = r3.getNanoTime()
                androidx.recyclerview.widget.RecyclerView$r r3 = r1.f903g
                int r6 = r7.f933f
                long r8 = r8 - r13
                androidx.recyclerview.widget.RecyclerView$r$a r6 = r3.mo1180a(r6)
                long r10 = r6.f896d
                long r8 = r3.mo1181b(r10, r8)
                r6.f896d = r8
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                android.view.accessibility.AccessibilityManager r3 = r3.f780E
                if (r3 == 0) goto L_0x0420
                boolean r3 = r3.isEnabled()
                if (r3 == 0) goto L_0x0420
                r3 = 1
                goto L_0x0421
            L_0x0420:
                r3 = 0
            L_0x0421:
                if (r3 == 0) goto L_0x0462
                android.view.View r3 = r7.f928a
                java.util.WeakHashMap<android.view.View, java.lang.String> r6 = p000.C0010a7.f28a
                int r6 = r3.getImportantForAccessibility()
                r8 = 1
                if (r6 != 0) goto L_0x0431
                r3.setImportantForAccessibility(r8)
            L_0x0431:
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                ib r6 = r6.f827p0
                if (r6 != 0) goto L_0x0438
                goto L_0x0462
            L_0x0438:
                ib$a r6 = r6.f3244e
                boolean r8 = r6 instanceof p000.C0882ib.C0883a
                if (r8 == 0) goto L_0x045f
                java.util.Objects.requireNonNull(r6)
                android.view.View$AccessibilityDelegate r8 = p000.C0010a7.m33f(r3)
                if (r8 != 0) goto L_0x0448
                goto L_0x0456
            L_0x0448:
                boolean r4 = r8 instanceof p000.C1163m6.C1164a
                if (r4 == 0) goto L_0x0451
                m6$a r8 = (p000.C1163m6.C1164a) r8
                m6 r4 = r8.f4003a
                goto L_0x0456
            L_0x0451:
                m6 r4 = new m6
                r4.<init>(r8)
            L_0x0456:
                if (r4 == 0) goto L_0x045f
                if (r4 == r6) goto L_0x045f
                java.util.Map<android.view.View, m6> r8 = r6.f3246e
                r8.put(r3, r4)
            L_0x045f:
                p000.C0010a7.m43p(r3, r6)
            L_0x0462:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r3 = r3.f813i0
                boolean r3 = r3.f912f
                if (r3 == 0) goto L_0x046c
                r7.f934g = r0
            L_0x046c:
                r0 = 1
            L_0x046d:
                android.view.View r3 = r7.f928a
                android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
                if (r3 != 0) goto L_0x047c
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                android.view.ViewGroup$LayoutParams r3 = r3.generateDefaultLayoutParams()
                goto L_0x048a
            L_0x047c:
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                boolean r4 = r4.checkLayoutParams(r3)
                if (r4 != 0) goto L_0x0492
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                android.view.ViewGroup$LayoutParams r3 = r4.generateLayoutParams((android.view.ViewGroup.LayoutParams) r3)
            L_0x048a:
                androidx.recyclerview.widget.RecyclerView$n r3 = (androidx.recyclerview.widget.RecyclerView.C0167n) r3
                android.view.View r4 = r7.f928a
                r4.setLayoutParams(r3)
                goto L_0x0494
            L_0x0492:
                androidx.recyclerview.widget.RecyclerView$n r3 = (androidx.recyclerview.widget.RecyclerView.C0167n) r3
            L_0x0494:
                r3.f887d = r7
                if (r2 == 0) goto L_0x049b
                if (r0 == 0) goto L_0x049b
                r5 = 1
            L_0x049b:
                r3.f890g = r5
                return r7
            L_0x049e:
                java.lang.IndexOutOfBoundsException r2 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                java.lang.String r4 = "Invalid item position "
                r3.append(r4)
                r3.append(r0)
                java.lang.String r4 = "("
                r3.append(r4)
                r3.append(r0)
                java.lang.String r0 = "). Item count:"
                r3.append(r0)
                androidx.recyclerview.widget.RecyclerView r0 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$w r0 = r0.f813i0
                int r0 = r0.mo1202b()
                r3.append(r0)
                androidx.recyclerview.widget.RecyclerView r0 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r0 = p000.C1012kd.m3197f(r0, r3)
                r2.<init>(r0)
                goto L_0x04d0
            L_0x04cf:
                throw r2
            L_0x04d0:
                goto L_0x04cf
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0173s.mo1193l(int, boolean, long):androidx.recyclerview.widget.RecyclerView$z");
        }

        /* renamed from: m */
        public void mo1194m(C0181z zVar) {
            (zVar.f942o ? this.f898b : this.f897a).remove(zVar);
            zVar.f941n = null;
            zVar.f942o = false;
            zVar.mo1209d();
        }

        /* renamed from: n */
        public void mo1195n() {
            C0162m mVar = RecyclerView.this.f826p;
            this.f902f = this.f901e + (mVar != null ? mVar.f875k : 0);
            for (int size = this.f899c.size() - 1; size >= 0 && this.f899c.size() > this.f902f; size--) {
                mo1189h(size);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$t */
    public interface C0174t {
        /* renamed from: a */
        void mo1196a(C0181z zVar);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$u */
    public class C0175u extends C0153g {
        public C0175u() {
        }

        /* renamed from: a */
        public void mo1092a() {
            RecyclerView.this.mo1013i((String) null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f813i0.f911e = true;
            recyclerView.mo964a0(true);
            if (!RecyclerView.this.f808g.mo5030g()) {
                RecyclerView.this.requestLayout();
            }
        }

        /* renamed from: b */
        public void mo1093b(int i, int i2, Object obj) {
            RecyclerView.this.mo1013i((String) null);
            C1321oa oaVar = RecyclerView.this.f808g;
            Objects.requireNonNull(oaVar);
            boolean z = false;
            if (i2 >= 1) {
                oaVar.f4483b.add(oaVar.mo5031h(4, i, i2, obj));
                oaVar.f4487f |= 4;
                if (oaVar.f4483b.size() == 1) {
                    z = true;
                }
            }
            if (z) {
                mo1197d();
            }
        }

        /* renamed from: c */
        public void mo1094c(int i, int i2) {
            RecyclerView.this.mo1013i((String) null);
            C1321oa oaVar = RecyclerView.this.f808g;
            Objects.requireNonNull(oaVar);
            boolean z = false;
            if (i2 >= 1) {
                oaVar.f4483b.add(oaVar.mo5031h(2, i, i2, (Object) null));
                oaVar.f4487f |= 2;
                if (oaVar.f4483b.size() == 1) {
                    z = true;
                }
            }
            if (z) {
                mo1197d();
            }
        }

        /* renamed from: d */
        public void mo1197d() {
            if (RecyclerView.f771C0) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.f838v && recyclerView.f836u) {
                    Runnable runnable = recyclerView.f816k;
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    recyclerView.postOnAnimation(runnable);
                    return;
                }
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            recyclerView2.f779D = true;
            recyclerView2.requestLayout();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$v */
    public static class C0176v extends C0015a8 {
        public static final Parcelable.Creator<C0176v> CREATOR = new C0177a();

        /* renamed from: f */
        public Parcelable f906f;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$v$a */
        public class C0177a implements Parcelable.ClassLoaderCreator<C0176v> {
            public Object createFromParcel(Parcel parcel) {
                return new C0176v(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0176v[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0176v(parcel, classLoader);
            }
        }

        public C0176v(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f906f = parcel.readParcelable(classLoader == null ? C0162m.class.getClassLoader() : classLoader);
        }

        public C0176v(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeParcelable(this.f906f, 0);
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$w */
    public static class C0178w {

        /* renamed from: a */
        public int f907a = 0;

        /* renamed from: b */
        public int f908b = 0;

        /* renamed from: c */
        public int f909c = 1;

        /* renamed from: d */
        public int f910d = 0;

        /* renamed from: e */
        public boolean f911e = false;

        /* renamed from: f */
        public boolean f912f = false;

        /* renamed from: g */
        public boolean f913g = false;

        /* renamed from: h */
        public boolean f914h = false;

        /* renamed from: i */
        public boolean f915i = false;

        /* renamed from: j */
        public boolean f916j = false;

        /* renamed from: k */
        public int f917k;

        /* renamed from: l */
        public long f918l;

        /* renamed from: m */
        public int f919m;

        /* renamed from: a */
        public void mo1201a(int i) {
            if ((this.f909c & i) == 0) {
                StringBuilder d = C1012kd.m3195d("Layout state should be one of ");
                d.append(Integer.toBinaryString(i));
                d.append(" but it is ");
                d.append(Integer.toBinaryString(this.f909c));
                throw new IllegalStateException(d.toString());
            }
        }

        /* renamed from: b */
        public int mo1202b() {
            return this.f912f ? this.f907a - this.f908b : this.f910d;
        }

        public String toString() {
            return "State{mTargetPosition=" + -1 + ", mData=" + null + ", mItemCount=" + this.f910d + ", mIsMeasuring=" + this.f914h + ", mPreviousLayoutItemCount=" + this.f907a + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.f908b + ", mStructureChanged=" + this.f911e + ", mInPreLayout=" + this.f912f + ", mRunSimpleAnimations=" + this.f915i + ", mRunPredictiveAnimations=" + this.f916j + '}';
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$x */
    public static abstract class C0179x {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$y */
    public class C0180y implements Runnable {

        /* renamed from: d */
        public int f920d;

        /* renamed from: e */
        public int f921e;

        /* renamed from: f */
        public OverScroller f922f;

        /* renamed from: g */
        public Interpolator f923g;

        /* renamed from: h */
        public boolean f924h = false;

        /* renamed from: i */
        public boolean f925i = false;

        public C0180y() {
            Interpolator interpolator = RecyclerView.f774F0;
            this.f923g = interpolator;
            this.f922f = new OverScroller(RecyclerView.this.getContext(), interpolator);
        }

        /* renamed from: a */
        public void mo1204a() {
            if (this.f924h) {
                this.f925i = true;
                return;
            }
            RecyclerView.this.removeCallbacks(this);
            RecyclerView recyclerView = RecyclerView.this;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            recyclerView.postOnAnimation(this);
        }

        public void run() {
            int i;
            int i2;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f826p == null) {
                recyclerView.removeCallbacks(this);
                this.f922f.abortAnimation();
                return;
            }
            this.f925i = false;
            this.f924h = true;
            recyclerView.mo1024n();
            OverScroller overScroller = this.f922f;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i3 = currX - this.f920d;
                int i4 = currY - this.f921e;
                this.f920d = currX;
                this.f921e = currY;
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.f839v0;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.mo1073t(i3, i4, iArr, (int[]) null, 1)) {
                    int[] iArr2 = RecyclerView.this.f839v0;
                    i3 -= iArr2[0];
                    i4 -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.mo1022m(i3, i4);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.f824o != null) {
                    int[] iArr3 = recyclerView3.f839v0;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.mo989g0(i3, i4, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.f839v0;
                    i = iArr4[0];
                    i2 = iArr4[1];
                    i3 -= i;
                    i4 -= i2;
                    Objects.requireNonNull(recyclerView4.f826p);
                } else {
                    i2 = 0;
                    i = 0;
                }
                if (!RecyclerView.this.f830r.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.f839v0;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.mo1074u(i, i2, i3, i4, (int[]) null, 1, iArr5);
                RecyclerView recyclerView6 = RecyclerView.this;
                int[] iArr6 = recyclerView6.f839v0;
                int i5 = i3 - iArr6[0];
                int i6 = i4 - iArr6[1];
                if (!(i == 0 && i2 == 0)) {
                    recyclerView6.mo1075v(i, i2);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i5 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i6 != 0));
                Objects.requireNonNull(RecyclerView.this.f826p);
                if (z) {
                    if (RecyclerView.this.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        int i7 = i5 < 0 ? -currVelocity : i5 > 0 ? currVelocity : 0;
                        if (i6 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i6 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView recyclerView7 = RecyclerView.this;
                        Objects.requireNonNull(recyclerView7);
                        if (i7 < 0) {
                            recyclerView7.mo1077x();
                            if (recyclerView7.f786K.isFinished()) {
                                recyclerView7.f786K.onAbsorb(-i7);
                            }
                        } else if (i7 > 0) {
                            recyclerView7.mo1078y();
                            if (recyclerView7.f788M.isFinished()) {
                                recyclerView7.f788M.onAbsorb(i7);
                            }
                        }
                        if (currVelocity < 0) {
                            recyclerView7.mo1079z();
                            if (recyclerView7.f787L.isFinished()) {
                                recyclerView7.f787L.onAbsorb(-currVelocity);
                            }
                        } else if (currVelocity > 0) {
                            recyclerView7.mo1076w();
                            if (recyclerView7.f789N.isFinished()) {
                                recyclerView7.f789N.onAbsorb(currVelocity);
                            }
                        }
                        if (!(i7 == 0 && currVelocity == 0)) {
                            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                            recyclerView7.postInvalidateOnAnimation();
                        }
                    }
                    if (RecyclerView.f772D0) {
                        C0021ab.C0023b bVar = RecyclerView.this.f811h0;
                        int[] iArr7 = bVar.f68c;
                        if (iArr7 != null) {
                            Arrays.fill(iArr7, -1);
                        }
                        bVar.f69d = 0;
                    }
                } else {
                    mo1204a();
                    RecyclerView recyclerView8 = RecyclerView.this;
                    C0021ab abVar = recyclerView8.f809g0;
                    if (abVar != null) {
                        abVar.mo68a(recyclerView8, i, i2);
                    }
                }
            }
            Objects.requireNonNull(RecyclerView.this.f826p);
            this.f924h = false;
            if (this.f925i) {
                RecyclerView.this.removeCallbacks(this);
                RecyclerView recyclerView9 = RecyclerView.this;
                WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                recyclerView9.postOnAnimation(this);
                return;
            }
            RecyclerView.this.setScrollState(0);
            RecyclerView.this.mo704a(1);
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$z */
    public static abstract class C0181z {

        /* renamed from: t */
        public static final List<Object> f927t = Collections.emptyList();

        /* renamed from: a */
        public final View f928a;

        /* renamed from: b */
        public WeakReference<RecyclerView> f929b;

        /* renamed from: c */
        public int f930c = -1;

        /* renamed from: d */
        public int f931d = -1;

        /* renamed from: e */
        public long f932e = -1;

        /* renamed from: f */
        public int f933f = -1;

        /* renamed from: g */
        public int f934g = -1;

        /* renamed from: h */
        public C0181z f935h = null;

        /* renamed from: i */
        public C0181z f936i = null;

        /* renamed from: j */
        public int f937j;

        /* renamed from: k */
        public List<Object> f938k = null;

        /* renamed from: l */
        public List<Object> f939l = null;

        /* renamed from: m */
        public int f940m = 0;

        /* renamed from: n */
        public C0173s f941n = null;

        /* renamed from: o */
        public boolean f942o = false;

        /* renamed from: p */
        public int f943p = 0;

        /* renamed from: q */
        public int f944q = -1;

        /* renamed from: r */
        public RecyclerView f945r;

        /* renamed from: s */
        public C0150e<? extends C0181z> f946s;

        public C0181z(View view) {
            if (view != null) {
                this.f928a = view;
                return;
            }
            throw new IllegalArgumentException("itemView may not be null");
        }

        /* renamed from: a */
        public void mo1206a(Object obj) {
            if (obj == null) {
                mo1207b(1024);
            } else if ((1024 & this.f937j) == 0) {
                if (this.f938k == null) {
                    ArrayList arrayList = new ArrayList();
                    this.f938k = arrayList;
                    this.f939l = Collections.unmodifiableList(arrayList);
                }
                this.f938k.add(obj);
            }
        }

        /* renamed from: b */
        public void mo1207b(int i) {
            this.f937j = i | this.f937j;
        }

        /* renamed from: c */
        public void mo1208c() {
            this.f931d = -1;
            this.f934g = -1;
        }

        /* renamed from: d */
        public void mo1209d() {
            this.f937j &= -33;
        }

        /* renamed from: e */
        public final int mo1210e() {
            int i = this.f934g;
            return i == -1 ? this.f930c : i;
        }

        /* renamed from: f */
        public List<Object> mo1211f() {
            if ((this.f937j & 1024) != 0) {
                return f927t;
            }
            List<Object> list = this.f938k;
            return (list == null || list.size() == 0) ? f927t : this.f939l;
        }

        /* renamed from: g */
        public boolean mo1212g(int i) {
            return (i & this.f937j) != 0;
        }

        /* renamed from: h */
        public boolean mo1213h() {
            return (this.f928a.getParent() == null || this.f928a.getParent() == this.f945r) ? false : true;
        }

        /* renamed from: i */
        public boolean mo1214i() {
            return (this.f937j & 1) != 0;
        }

        /* renamed from: j */
        public boolean mo1215j() {
            return (this.f937j & 4) != 0;
        }

        /* renamed from: k */
        public final boolean mo1216k() {
            if ((this.f937j & 16) == 0) {
                View view = this.f928a;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (!view.hasTransientState()) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: l */
        public boolean mo1217l() {
            return (this.f937j & 8) != 0;
        }

        /* renamed from: m */
        public boolean mo1218m() {
            return this.f941n != null;
        }

        /* renamed from: n */
        public boolean mo1219n() {
            return (this.f937j & 256) != 0;
        }

        /* renamed from: o */
        public boolean mo1220o() {
            return (this.f937j & 2) != 0;
        }

        /* renamed from: p */
        public void mo1221p(int i, boolean z) {
            if (this.f931d == -1) {
                this.f931d = this.f930c;
            }
            if (this.f934g == -1) {
                this.f934g = this.f930c;
            }
            if (z) {
                this.f934g += i;
            }
            this.f930c += i;
            if (this.f928a.getLayoutParams() != null) {
                ((C0167n) this.f928a.getLayoutParams()).f889f = true;
            }
        }

        /* renamed from: q */
        public void mo1222q() {
            this.f937j = 0;
            this.f930c = -1;
            this.f931d = -1;
            this.f932e = -1;
            this.f934g = -1;
            this.f940m = 0;
            this.f935h = null;
            this.f936i = null;
            List<Object> list = this.f938k;
            if (list != null) {
                list.clear();
            }
            this.f937j &= -1025;
            this.f943p = 0;
            this.f944q = -1;
            RecyclerView.m517k(this);
        }

        /* renamed from: r */
        public void mo1223r(int i, int i2) {
            this.f937j = (i & i2) | (this.f937j & (i2 ^ -1));
        }

        /* renamed from: s */
        public final void mo1224s(boolean z) {
            int i;
            int i2 = this.f940m;
            int i3 = z ? i2 - 1 : i2 + 1;
            this.f940m = i3;
            if (i3 < 0) {
                this.f940m = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                return;
            }
            if (!z && i3 == 1) {
                i = this.f937j | 16;
            } else if (z && i3 == 0) {
                i = this.f937j & -17;
            } else {
                return;
            }
            this.f937j = i;
        }

        /* renamed from: t */
        public boolean mo1225t() {
            return (this.f937j & 128) != 0;
        }

        public String toString() {
            String simpleName = getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName();
            StringBuilder sb = new StringBuilder(simpleName + "{" + Integer.toHexString(hashCode()) + " position=" + this.f930c + " id=" + this.f932e + ", oldPos=" + this.f931d + ", pLpos:" + this.f934g);
            if (mo1218m()) {
                sb.append(" scrap ");
                sb.append(this.f942o ? "[changeScrap]" : "[attachedScrap]");
            }
            if (mo1215j()) {
                sb.append(" invalid");
            }
            if (!mo1214i()) {
                sb.append(" unbound");
            }
            boolean z = false;
            if ((this.f937j & 2) != 0) {
                sb.append(" update");
            }
            if (mo1217l()) {
                sb.append(" removed");
            }
            if (mo1225t()) {
                sb.append(" ignored");
            }
            if (mo1219n()) {
                sb.append(" tmpDetached");
            }
            if (!mo1216k()) {
                StringBuilder d = C1012kd.m3195d(" not recyclable(");
                d.append(this.f940m);
                d.append(")");
                sb.append(d.toString());
            }
            if ((this.f937j & 512) != 0 || mo1215j()) {
                z = true;
            }
            if (z) {
                sb.append(" undefined adapter position");
            }
            if (this.f928a.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        /* renamed from: u */
        public boolean mo1227u() {
            return (this.f937j & 32) != 0;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            r0 = 1
            int[] r1 = new int[r0]
            r2 = 0
            r3 = 16843830(0x1010436, float:2.369658E-38)
            r1[r2] = r3
            f775z0 = r1
            int r1 = android.os.Build.VERSION.SDK_INT
            r3 = 19
            if (r1 == r3) goto L_0x0018
            r3 = 20
            if (r1 != r3) goto L_0x0016
            goto L_0x0018
        L_0x0016:
            r3 = 0
            goto L_0x0019
        L_0x0018:
            r3 = 1
        L_0x0019:
            f769A0 = r3
            r3 = 23
            if (r1 < r3) goto L_0x0021
            r3 = 1
            goto L_0x0022
        L_0x0021:
            r3 = 0
        L_0x0022:
            f770B0 = r3
            f771C0 = r0
            r3 = 21
            if (r1 < r3) goto L_0x002c
            r1 = 1
            goto L_0x002d
        L_0x002c:
            r1 = 0
        L_0x002d:
            f772D0 = r1
            r1 = 4
            java.lang.Class[] r1 = new java.lang.Class[r1]
            java.lang.Class<android.content.Context> r3 = android.content.Context.class
            r1[r2] = r3
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r1[r0] = r2
            r0 = 2
            java.lang.Class r2 = java.lang.Integer.TYPE
            r1[r0] = r2
            r0 = 3
            r1[r0] = r2
            f773E0 = r1
            androidx.recyclerview.widget.RecyclerView$c r0 = new androidx.recyclerview.widget.RecyclerView$c
            r0.<init>()
            f774F0 = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.<clinit>():void");
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.recyclerViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        char c;
        boolean z;
        StringBuilder sb;
        Object[] objArr;
        Constructor<? extends U> constructor;
        NoSuchMethodException noSuchMethodException;
        Context context2 = context;
        AttributeSet attributeSet2 = attributeSet;
        int i2 = i;
        int i3 = Build.VERSION.SDK_INT;
        this.f802d = new C0175u();
        this.f804e = new C0173s();
        this.f812i = new C1101lb();
        this.f816k = new C0146a();
        this.f818l = new Rect();
        this.f820m = new Rect();
        this.f822n = new RectF();
        this.f830r = new ArrayList<>();
        this.f832s = new ArrayList<>();
        this.f844y = 0;
        this.f781F = false;
        this.f782G = false;
        this.f783H = 0;
        this.f784I = 0;
        this.f785J = new C0155i();
        this.f790O = new C2130ya();
        this.f791P = 0;
        this.f792Q = -1;
        this.f801c0 = Float.MIN_VALUE;
        this.f803d0 = Float.MIN_VALUE;
        this.f805e0 = true;
        this.f807f0 = new C0180y();
        this.f811h0 = f772D0 ? new C0021ab.C0023b() : null;
        this.f813i0 = new C0178w();
        this.f819l0 = false;
        this.f821m0 = false;
        this.f823n0 = new C0160k();
        this.f825o0 = false;
        this.f831r0 = new int[2];
        this.f835t0 = new int[2];
        this.f837u0 = new int[2];
        this.f839v0 = new int[2];
        this.f841w0 = new ArrayList();
        this.f843x0 = new C0147b();
        this.f845y0 = new C0149d();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f798W = viewConfiguration.getScaledTouchSlop();
        Method method = C0611e7.f2493a;
        this.f801c0 = i3 >= 26 ? viewConfiguration.getScaledHorizontalScrollFactor() : C0611e7.m1993a(viewConfiguration, context2);
        this.f803d0 = i3 >= 26 ? viewConfiguration.getScaledVerticalScrollFactor() : C0611e7.m1993a(viewConfiguration, context2);
        this.f799a0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f800b0 = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.f790O.f856a = this.f823n0;
        this.f808g = new C1321oa(new C0824hb(this));
        this.f810h = new C1412pa(new C0742gb(this));
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if ((i3 >= 26 ? getImportantForAutofill() : 0) == 0 && i3 >= 26) {
            setImportantForAutofill(8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f780E = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new C0882ib(this));
        int[] iArr = C1242na.f4257a;
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet2, iArr, i2, 0);
        C0010a7.m42o(this, context, iArr, attributeSet, obtainStyledAttributes, i, 0);
        String string = obtainStyledAttributes.getString(8);
        if (obtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.f814j = obtainStyledAttributes.getBoolean(1, true);
        boolean z2 = obtainStyledAttributes.getBoolean(3, false);
        this.f840w = z2;
        if (z2) {
            StateListDrawable stateListDrawable = (StateListDrawable) obtainStyledAttributes.getDrawable(6);
            Drawable drawable = obtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) obtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = obtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                throw new IllegalArgumentException(C1012kd.m3197f(this, C1012kd.m3195d("Trying to set fast scroller without both required drawables.")));
            }
            Resources resources = getContext().getResources();
            c = 2;
            new C2199za(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(R.dimen.fastscroll_margin));
        } else {
            c = 2;
        }
        obtainStyledAttributes.recycle();
        if (string != null) {
            String trim = string.trim();
            if (!trim.isEmpty()) {
                if (trim.charAt(0) == '.') {
                    sb = new StringBuilder();
                    sb.append(context.getPackageName());
                    sb.append(trim);
                    trim = sb.toString();
                } else if (!trim.contains(".")) {
                    sb = new StringBuilder();
                    sb.append(RecyclerView.class.getPackage().getName());
                    sb.append('.');
                    sb.append(trim);
                    trim = sb.toString();
                }
                String str = trim;
                try {
                    Class<? extends U> asSubclass = Class.forName(str, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(C0162m.class);
                    try {
                        constructor = asSubclass.getConstructor(f773E0);
                        Object[] objArr2 = new Object[4];
                        objArr2[0] = context2;
                        objArr2[1] = attributeSet2;
                        objArr2[c] = Integer.valueOf(i);
                        objArr2[3] = 0;
                        objArr = objArr2;
                    } catch (NoSuchMethodException e) {
                        noSuchMethodException = e;
                        constructor = asSubclass.getConstructor(new Class[0]);
                        objArr = null;
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((C0162m) constructor.newInstance(objArr));
                } catch (NoSuchMethodException e2) {
                    e2.initCause(noSuchMethodException);
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e2);
                } catch (ClassNotFoundException e3) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e3);
                } catch (InvocationTargetException e4) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e4);
                } catch (InstantiationException e5) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e5);
                } catch (IllegalAccessException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e6);
                } catch (ClassCastException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e7);
                }
            }
        }
        if (i3 >= 21) {
            int[] iArr2 = f775z0;
            TypedArray obtainStyledAttributes2 = context2.obtainStyledAttributes(attributeSet2, iArr2, i2, 0);
            C0010a7.m42o(this, context, iArr2, attributeSet, obtainStyledAttributes2, i, 0);
            z = obtainStyledAttributes2.getBoolean(0, true);
            obtainStyledAttributes2.recycle();
        } else {
            z = true;
        }
        setNestedScrollingEnabled(z);
    }

    /* renamed from: F */
    public static RecyclerView m511F(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView F = m511F(viewGroup.getChildAt(i));
            if (F != null) {
                return F;
            }
        }
        return null;
    }

    /* renamed from: K */
    public static C0181z m512K(View view) {
        if (view == null) {
            return null;
        }
        return ((C0167n) view.getLayoutParams()).f887d;
    }

    private C1720s6 getScrollingChildHelper() {
        if (this.f833s0 == null) {
            this.f833s0 = new C1720s6(this);
        }
        return this.f833s0;
    }

    /* renamed from: k */
    public static void m517k(C0181z zVar) {
        WeakReference<RecyclerView> weakReference = zVar.f929b;
        if (weakReference != null) {
            Object obj = weakReference.get();
            while (true) {
                View view = (View) obj;
                while (true) {
                    if (view == null) {
                        zVar.f929b = null;
                        return;
                    } else if (view != zVar.f928a) {
                        obj = view.getParent();
                        if (!(obj instanceof View)) {
                            view = null;
                        }
                    } else {
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: A */
    public String mo940A() {
        StringBuilder d = C1012kd.m3195d(" ");
        d.append(super.toString());
        d.append(", adapter:");
        d.append(this.f824o);
        d.append(", layout:");
        d.append(this.f826p);
        d.append(", context:");
        d.append(getContext());
        return d.toString();
    }

    /* renamed from: B */
    public final void mo941B(C0178w wVar) {
        if (getScrollState() == 2) {
            OverScroller overScroller = this.f807f0.f922f;
            overScroller.getFinalX();
            overScroller.getCurrX();
            Objects.requireNonNull(wVar);
            overScroller.getFinalY();
            overScroller.getCurrY();
            return;
        }
        Objects.requireNonNull(wVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:7:0x0013 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* renamed from: C */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo942C(android.view.View r3) {
        /*
            r2 = this;
        L_0x0000:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L_0x0010
            if (r0 == r2) goto L_0x0010
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L_0x0010
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L_0x0000
        L_0x0010:
            if (r0 != r2) goto L_0x0013
            goto L_0x0014
        L_0x0013:
            r3 = 0
        L_0x0014:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.mo942C(android.view.View):android.view.View");
    }

    /* renamed from: D */
    public final boolean mo943D(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.f832s.size();
        int i = 0;
        while (i < size) {
            C0169p pVar = this.f832s.get(i);
            if (!pVar.mo1176a(this, motionEvent) || action == 3) {
                i++;
            } else {
                this.f834t = pVar;
                return true;
            }
        }
        return false;
    }

    /* renamed from: E */
    public final void mo944E(int[] iArr) {
        int e = this.f810h.mo5206e();
        if (e == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MAX_VALUE;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = 0; i3 < e; i3++) {
            C0181z K = m512K(this.f810h.mo5205d(i3));
            if (!K.mo1225t()) {
                int e2 = K.mo1210e();
                if (e2 < i) {
                    i = e2;
                }
                if (e2 > i2) {
                    i2 = e2;
                }
            }
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    /* renamed from: G */
    public C0181z mo945G(int i) {
        C0181z zVar = null;
        if (this.f781F) {
            return null;
        }
        int h = this.f810h.mo5209h();
        for (int i2 = 0; i2 < h; i2++) {
            C0181z K = m512K(this.f810h.mo5208g(i2));
            if (K != null && !K.mo1217l() && mo946H(K) == i) {
                if (!this.f810h.mo5212k(K.f928a)) {
                    return K;
                }
                zVar = K;
            }
        }
        return zVar;
    }

    /* renamed from: H */
    public int mo946H(C0181z zVar) {
        if (zVar.mo1212g(524) || !zVar.mo1214i()) {
            return -1;
        }
        C1321oa oaVar = this.f808g;
        int i = zVar.f930c;
        int size = oaVar.f4483b.size();
        for (int i2 = 0; i2 < size; i2++) {
            C1321oa.C1323b bVar = oaVar.f4483b.get(i2);
            int i3 = bVar.f4488a;
            if (i3 != 1) {
                if (i3 == 2) {
                    int i4 = bVar.f4489b;
                    if (i4 <= i) {
                        int i5 = bVar.f4491d;
                        if (i4 + i5 > i) {
                            return -1;
                        }
                        i -= i5;
                    } else {
                        continue;
                    }
                } else if (i3 == 8) {
                    int i6 = bVar.f4489b;
                    if (i6 == i) {
                        i = bVar.f4491d;
                    } else {
                        if (i6 < i) {
                            i--;
                        }
                        if (bVar.f4491d <= i) {
                            i++;
                        }
                    }
                }
            } else if (bVar.f4489b <= i) {
                i += bVar.f4491d;
            }
        }
        return i;
    }

    /* renamed from: I */
    public long mo947I(C0181z zVar) {
        Objects.requireNonNull(this.f824o);
        return (long) zVar.f930c;
    }

    /* renamed from: J */
    public C0181z mo948J(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return m512K(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    /* renamed from: L */
    public Rect mo949L(View view) {
        C0167n nVar = (C0167n) view.getLayoutParams();
        if (!nVar.f889f) {
            return nVar.f888e;
        }
        if (this.f813i0.f912f && (nVar.mo1174s() || nVar.f887d.mo1215j())) {
            return nVar.f888e;
        }
        Rect rect = nVar.f888e;
        rect.set(0, 0, 0, 0);
        int size = this.f830r.size();
        for (int i = 0; i < size; i++) {
            this.f818l.set(0, 0, 0, 0);
            Rect rect2 = this.f818l;
            Objects.requireNonNull(this.f830r.get(i));
            ((C0167n) view.getLayoutParams()).mo1173r();
            rect2.set(0, 0, 0, 0);
            int i2 = rect.left;
            Rect rect3 = this.f818l;
            rect.left = i2 + rect3.left;
            rect.top += rect3.top;
            rect.right += rect3.right;
            rect.bottom += rect3.bottom;
        }
        nVar.f889f = false;
        return rect;
    }

    /* renamed from: M */
    public boolean mo950M() {
        return !this.f842x || this.f781F || this.f808g.mo5030g();
    }

    /* renamed from: N */
    public void mo951N() {
        this.f789N = null;
        this.f787L = null;
        this.f788M = null;
        this.f786K = null;
    }

    /* renamed from: O */
    public boolean mo952O() {
        return this.f783H > 0;
    }

    /* renamed from: P */
    public void mo953P() {
        int h = this.f810h.mo5209h();
        for (int i = 0; i < h; i++) {
            ((C0167n) this.f810h.mo5208g(i).getLayoutParams()).f889f = true;
        }
        C0173s sVar = this.f804e;
        int size = sVar.f899c.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0167n nVar = (C0167n) sVar.f899c.get(i2).f928a.getLayoutParams();
            if (nVar != null) {
                nVar.f889f = true;
            }
        }
    }

    /* renamed from: Q */
    public void mo954Q(int i, int i2, boolean z) {
        int i3 = i + i2;
        int h = this.f810h.mo5209h();
        for (int i4 = 0; i4 < h; i4++) {
            C0181z K = m512K(this.f810h.mo5208g(i4));
            if (K != null && !K.mo1225t()) {
                int i5 = K.f930c;
                if (i5 >= i3) {
                    K.mo1221p(-i2, z);
                } else if (i5 >= i) {
                    K.mo1207b(8);
                    K.mo1221p(-i2, z);
                    K.f930c = i - 1;
                }
                this.f813i0.f911e = true;
            }
        }
        C0173s sVar = this.f804e;
        int size = sVar.f899c.size();
        while (true) {
            size--;
            if (size >= 0) {
                C0181z zVar = sVar.f899c.get(size);
                if (zVar != null) {
                    int i6 = zVar.f930c;
                    if (i6 >= i3) {
                        zVar.mo1221p(-i2, z);
                    } else if (i6 >= i) {
                        zVar.mo1207b(8);
                        sVar.mo1189h(size);
                    }
                }
            } else {
                requestLayout();
                return;
            }
        }
    }

    /* renamed from: R */
    public void mo955R() {
    }

    /* renamed from: S */
    public void mo956S() {
    }

    /* renamed from: T */
    public void mo957T() {
        this.f783H++;
    }

    /* renamed from: U */
    public void mo958U(boolean z) {
        int i;
        boolean z2 = true;
        int i2 = this.f783H - 1;
        this.f783H = i2;
        if (i2 < 1) {
            this.f783H = 0;
            if (z) {
                int i3 = this.f778C;
                this.f778C = 0;
                if (i3 != 0) {
                    AccessibilityManager accessibilityManager = this.f780E;
                    if (accessibilityManager == null || !accessibilityManager.isEnabled()) {
                        z2 = false;
                    }
                    if (z2) {
                        AccessibilityEvent obtain = AccessibilityEvent.obtain();
                        obtain.setEventType(2048);
                        obtain.setContentChangeTypes(i3);
                        sendAccessibilityEventUnchecked(obtain);
                    }
                }
                for (int size = this.f841w0.size() - 1; size >= 0; size--) {
                    C0181z zVar = this.f841w0.get(size);
                    if (zVar.f928a.getParent() == this && !zVar.mo1225t() && (i = zVar.f944q) != -1) {
                        View view = zVar.f928a;
                        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                        view.setImportantForAccessibility(i);
                        zVar.f944q = -1;
                    }
                }
                this.f841w0.clear();
            }
        }
    }

    /* renamed from: V */
    public final void mo959V(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f792Q) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f792Q = motionEvent.getPointerId(i);
            int x = (int) (motionEvent.getX(i) + 0.5f);
            this.f796U = x;
            this.f794S = x;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.f797V = y;
            this.f795T = y;
        }
    }

    /* renamed from: W */
    public void mo960W() {
    }

    /* renamed from: X */
    public void mo961X() {
    }

    /* renamed from: Y */
    public void mo962Y() {
        if (!this.f825o0 && this.f836u) {
            Runnable runnable = this.f843x0;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postOnAnimation(runnable);
            this.f825o0 = true;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:42:0x0080  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0085  */
    /* renamed from: Z */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo963Z() {
        /*
            r6 = this;
            boolean r0 = r6.f781F
            r1 = 0
            if (r0 == 0) goto L_0x001c
            oa r0 = r6.f808g
            java.util.ArrayList<oa$b> r2 = r0.f4483b
            r0.mo5035l(r2)
            java.util.ArrayList<oa$b> r2 = r0.f4484c
            r0.mo5035l(r2)
            r0.f4487f = r1
            boolean r0 = r6.f782G
            if (r0 == 0) goto L_0x001c
            androidx.recyclerview.widget.RecyclerView$m r0 = r6.f826p
            r0.mo874s0(r6)
        L_0x001c:
            androidx.recyclerview.widget.RecyclerView$j r0 = r6.f790O
            r2 = 1
            if (r0 == 0) goto L_0x002b
            androidx.recyclerview.widget.RecyclerView$m r0 = r6.f826p
            boolean r0 = r0.mo863Z0()
            if (r0 == 0) goto L_0x002b
            r0 = 1
            goto L_0x002c
        L_0x002b:
            r0 = 0
        L_0x002c:
            if (r0 == 0) goto L_0x0034
            oa r0 = r6.f808g
            r0.mo5033j()
            goto L_0x0039
        L_0x0034:
            oa r0 = r6.f808g
            r0.mo5026c()
        L_0x0039:
            boolean r0 = r6.f819l0
            if (r0 != 0) goto L_0x0044
            boolean r0 = r6.f821m0
            if (r0 == 0) goto L_0x0042
            goto L_0x0044
        L_0x0042:
            r0 = 0
            goto L_0x0045
        L_0x0044:
            r0 = 1
        L_0x0045:
            androidx.recyclerview.widget.RecyclerView$w r3 = r6.f813i0
            boolean r4 = r6.f842x
            if (r4 == 0) goto L_0x0065
            androidx.recyclerview.widget.RecyclerView$j r4 = r6.f790O
            if (r4 == 0) goto L_0x0065
            boolean r4 = r6.f781F
            if (r4 != 0) goto L_0x005b
            if (r0 != 0) goto L_0x005b
            androidx.recyclerview.widget.RecyclerView$m r5 = r6.f826p
            boolean r5 = r5.f871g
            if (r5 == 0) goto L_0x0065
        L_0x005b:
            if (r4 == 0) goto L_0x0063
            androidx.recyclerview.widget.RecyclerView$e r4 = r6.f824o
            java.util.Objects.requireNonNull(r4)
            goto L_0x0065
        L_0x0063:
            r4 = 1
            goto L_0x0066
        L_0x0065:
            r4 = 0
        L_0x0066:
            r3.f915i = r4
            androidx.recyclerview.widget.RecyclerView$w r3 = r6.f813i0
            boolean r4 = r3.f915i
            if (r4 == 0) goto L_0x0086
            if (r0 == 0) goto L_0x0086
            boolean r0 = r6.f781F
            if (r0 != 0) goto L_0x0086
            androidx.recyclerview.widget.RecyclerView$j r0 = r6.f790O
            if (r0 == 0) goto L_0x0082
            androidx.recyclerview.widget.RecyclerView$m r0 = r6.f826p
            boolean r0 = r0.mo863Z0()
            if (r0 == 0) goto L_0x0082
            r0 = 1
            goto L_0x0083
        L_0x0082:
            r0 = 0
        L_0x0083:
            if (r0 == 0) goto L_0x0086
            r1 = 1
        L_0x0086:
            r3.f916j = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.mo963Z():void");
    }

    /* renamed from: a */
    public void mo704a(int i) {
        getScrollingChildHelper().mo5819k(i);
    }

    /* renamed from: a0 */
    public void mo964a0(boolean z) {
        this.f782G = z | this.f782G;
        this.f781F = true;
        int h = this.f810h.mo5209h();
        for (int i = 0; i < h; i++) {
            C0181z K = m512K(this.f810h.mo5208g(i));
            if (K != null && !K.mo1225t()) {
                K.mo1207b(6);
            }
        }
        mo953P();
        C0173s sVar = this.f804e;
        int size = sVar.f899c.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0181z zVar = sVar.f899c.get(i2);
            if (zVar != null) {
                zVar.mo1207b(6);
                zVar.mo1206a((Object) null);
            }
        }
        C0150e eVar = RecyclerView.this.f824o;
        sVar.mo1188g();
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        C0162m mVar = this.f826p;
        if (mVar == null || !mVar.mo1154h0()) {
            super.addFocusables(arrayList, i, i2);
        }
    }

    /* renamed from: b0 */
    public void mo966b0(C0181z zVar, C0156j.C0159c cVar) {
        zVar.mo1223r(0, 8192);
        if (this.f813i0.f913g && zVar.mo1220o() && !zVar.mo1217l() && !zVar.mo1225t()) {
            Objects.requireNonNull(this.f824o);
            this.f812i.f3862b.mo1591g((long) zVar.f930c, zVar);
        }
        this.f812i.mo4414c(zVar, cVar);
    }

    /* renamed from: c0 */
    public void mo967c0() {
        C0156j jVar = this.f790O;
        if (jVar != null) {
            jVar.mo1101f();
        }
        C0162m mVar = this.f826p;
        if (mVar != null) {
            mVar.mo1119I0(this.f804e);
            this.f826p.mo1121J0(this.f804e);
        }
        this.f804e.mo1183b();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0167n) && this.f826p.mo865g((C0167n) layoutParams);
    }

    public int computeHorizontalScrollExtent() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo899e()) {
            return this.f826p.mo909k(this.f813i0);
        }
        return 0;
    }

    public int computeHorizontalScrollOffset() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo899e()) {
            return this.f826p.mo866l(this.f813i0);
        }
        return 0;
    }

    public int computeHorizontalScrollRange() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo899e()) {
            return this.f826p.mo868m(this.f813i0);
        }
        return 0;
    }

    public int computeVerticalScrollExtent() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo901f()) {
            return this.f826p.mo915n(this.f813i0);
        }
        return 0;
    }

    public int computeVerticalScrollOffset() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo901f()) {
            return this.f826p.mo870o(this.f813i0);
        }
        return 0;
    }

    public int computeVerticalScrollRange() {
        C0162m mVar = this.f826p;
        if (mVar != null && mVar.mo901f()) {
            return this.f826p.mo871p(this.f813i0);
        }
        return 0;
    }

    /* renamed from: d0 */
    public final void mo975d0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.f818l.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof C0167n) {
            C0167n nVar = (C0167n) layoutParams;
            if (!nVar.f889f) {
                Rect rect = nVar.f888e;
                Rect rect2 = this.f818l;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.f818l);
            offsetRectIntoDescendantCoords(view, this.f818l);
        }
        this.f826p.mo1127M0(this, view, this.f818l, !this.f842x, view2 == null);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return getScrollingChildHelper().mo5809a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().mo5810b(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().mo5811c(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return getScrollingChildHelper().mo5813e(i, i2, i3, i4, iArr);
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    public void draw(Canvas canvas) {
        boolean z;
        float f;
        float f2;
        super.draw(canvas);
        int size = this.f830r.size();
        boolean z2 = false;
        for (int i = 0; i < size; i++) {
            this.f830r.get(i).mo1105d(canvas, this, this.f813i0);
        }
        EdgeEffect edgeEffect = this.f786K;
        boolean z3 = true;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f814j ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((float) ((-getHeight()) + paddingBottom), 0.0f);
            EdgeEffect edgeEffect2 = this.f786K;
            z = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.f787L;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.f814j) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f787L;
            z |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.f788M;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f814j ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate((float) (-paddingTop), (float) (-width));
            EdgeEffect edgeEffect6 = this.f788M;
            z |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.f789N;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f814j) {
                f2 = (float) (getPaddingRight() + (-getWidth()));
                f = (float) (getPaddingBottom() + (-getHeight()));
            } else {
                f2 = (float) (-getWidth());
                f = (float) (-getHeight());
            }
            canvas.translate(f2, f);
            EdgeEffect edgeEffect8 = this.f789N;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z2 = true;
            }
            z |= z2;
            canvas.restoreToCount(save4);
        }
        if (z || this.f790O == null || this.f830r.size() <= 0 || !this.f790O.mo1102g()) {
            z3 = z;
        }
        if (z3) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postInvalidateOnAnimation();
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    /* renamed from: e0 */
    public final void mo985e0() {
        VelocityTracker velocityTracker = this.f793R;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z = false;
        mo704a(0);
        EdgeEffect edgeEffect = this.f786K;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z = this.f786K.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f787L;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z |= this.f787L.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f788M;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z |= this.f788M.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f789N;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z |= this.f789N.isFinished();
        }
        if (z) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00f3  */
    /* renamed from: f0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo986f0(int r18, int r19, android.view.MotionEvent r20) {
        /*
            r17 = this;
            r8 = r17
            r9 = r18
            r10 = r19
            r17.mo1024n()
            androidx.recyclerview.widget.RecyclerView$e r0 = r8.f824o
            r11 = 1
            r12 = 0
            if (r0 == 0) goto L_0x0028
            int[] r0 = r8.f839v0
            r0[r12] = r12
            r0[r11] = r12
            r8.mo989g0(r9, r10, r0)
            int[] r0 = r8.f839v0
            r1 = r0[r12]
            r0 = r0[r11]
            int r2 = r9 - r1
            int r3 = r10 - r0
            r13 = r0
            r14 = r1
            r15 = r2
            r16 = r3
            goto L_0x002d
        L_0x0028:
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
        L_0x002d:
            java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$l> r0 = r8.f830r
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x0038
            r17.invalidate()
        L_0x0038:
            int[] r7 = r8.f839v0
            r7[r12] = r12
            r7[r11] = r12
            int[] r5 = r8.f835t0
            r6 = 0
            r0 = r17
            r1 = r14
            r2 = r13
            r3 = r15
            r4 = r16
            r0.mo1074u(r1, r2, r3, r4, r5, r6, r7)
            int[] r0 = r8.f839v0
            r1 = r0[r12]
            int r15 = r15 - r1
            r1 = r0[r11]
            int r1 = r16 - r1
            r2 = r0[r12]
            if (r2 != 0) goto L_0x005f
            r0 = r0[r11]
            if (r0 == 0) goto L_0x005d
            goto L_0x005f
        L_0x005d:
            r0 = 0
            goto L_0x0060
        L_0x005f:
            r0 = 1
        L_0x0060:
            int r2 = r8.f796U
            int[] r3 = r8.f835t0
            r4 = r3[r12]
            int r2 = r2 - r4
            r8.f796U = r2
            int r2 = r8.f797V
            r4 = r3[r11]
            int r2 = r2 - r4
            r8.f797V = r2
            int[] r2 = r8.f837u0
            r4 = r2[r12]
            r5 = r3[r12]
            int r4 = r4 + r5
            r2[r12] = r4
            r4 = r2[r11]
            r3 = r3[r11]
            int r4 = r4 + r3
            r2[r11] = r4
            int r2 = r17.getOverScrollMode()
            r3 = 2
            if (r2 == r3) goto L_0x0120
            if (r20 == 0) goto L_0x011d
            r2 = 8194(0x2002, float:1.1482E-41)
            int r3 = r20.getSource()
            r3 = r3 & r2
            if (r3 != r2) goto L_0x0094
            r2 = 1
            goto L_0x0095
        L_0x0094:
            r2 = 0
        L_0x0095:
            if (r2 != 0) goto L_0x011d
            float r2 = r20.getX()
            float r3 = (float) r15
            float r4 = r20.getY()
            float r1 = (float) r1
            r5 = 1065353216(0x3f800000, float:1.0)
            r6 = 0
            int r7 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
            if (r7 >= 0) goto L_0x00bd
            r17.mo1077x()
            android.widget.EdgeEffect r7 = r8.f786K
            float r15 = -r3
            int r11 = r17.getWidth()
            float r11 = (float) r11
            float r15 = r15 / r11
            int r11 = r17.getHeight()
            float r11 = (float) r11
            float r4 = r4 / r11
            float r4 = r5 - r4
            goto L_0x00d3
        L_0x00bd:
            int r7 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
            if (r7 <= 0) goto L_0x00d8
            r17.mo1078y()
            android.widget.EdgeEffect r7 = r8.f788M
            int r11 = r17.getWidth()
            float r11 = (float) r11
            float r15 = r3 / r11
            int r11 = r17.getHeight()
            float r11 = (float) r11
            float r4 = r4 / r11
        L_0x00d3:
            p000.C1401p4.m4340Q(r7, r15, r4)
            r4 = 1
            goto L_0x00d9
        L_0x00d8:
            r4 = 0
        L_0x00d9:
            int r7 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r7 >= 0) goto L_0x00f3
            r17.mo1079z()
            android.widget.EdgeEffect r4 = r8.f787L
            float r5 = -r1
            int r7 = r17.getHeight()
            float r7 = (float) r7
            float r5 = r5 / r7
            int r7 = r17.getWidth()
            float r7 = (float) r7
            float r2 = r2 / r7
            p000.C1401p4.m4340Q(r4, r5, r2)
            goto L_0x010d
        L_0x00f3:
            int r7 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r7 <= 0) goto L_0x010e
            r17.mo1076w()
            android.widget.EdgeEffect r4 = r8.f789N
            int r7 = r17.getHeight()
            float r7 = (float) r7
            float r7 = r1 / r7
            int r11 = r17.getWidth()
            float r11 = (float) r11
            float r2 = r2 / r11
            float r5 = r5 - r2
            p000.C1401p4.m4340Q(r4, r7, r5)
        L_0x010d:
            r4 = 1
        L_0x010e:
            if (r4 != 0) goto L_0x0118
            int r2 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
            if (r2 != 0) goto L_0x0118
            int r1 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r1 == 0) goto L_0x011d
        L_0x0118:
            java.util.WeakHashMap<android.view.View, java.lang.String> r1 = p000.C0010a7.f28a
            r17.postInvalidateOnAnimation()
        L_0x011d:
            r17.mo1022m(r18, r19)
        L_0x0120:
            if (r14 != 0) goto L_0x0124
            if (r13 == 0) goto L_0x0127
        L_0x0124:
            r8.mo1075v(r14, r13)
        L_0x0127:
            boolean r1 = r17.awakenScrollBars()
            if (r1 != 0) goto L_0x0130
            r17.invalidate()
        L_0x0130:
            if (r0 != 0) goto L_0x0139
            if (r14 != 0) goto L_0x0139
            if (r13 == 0) goto L_0x0137
            goto L_0x0139
        L_0x0137:
            r11 = 0
            goto L_0x013a
        L_0x0139:
            r11 = 1
        L_0x013a:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.mo986f0(int, int, android.view.MotionEvent):boolean");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:112:0x0169, code lost:
        if (r3 > 0) goto L_0x019d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x0183, code lost:
        if (r6 > 0) goto L_0x019d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x0186, code lost:
        if (r3 < 0) goto L_0x019d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0189, code lost:
        if (r6 < 0) goto L_0x019d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x0192, code lost:
        if ((r6 * r1) < 0) goto L_0x019f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x019b, code lost:
        if ((r6 * r1) > 0) goto L_0x019f;
     */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x01a3  */
    /* JADX WARNING: Removed duplicated region for block: B:131:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0075  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View focusSearch(android.view.View r14, int r15) {
        /*
            r13 = this;
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            android.view.View r0 = r0.mo1160q0()
            if (r0 == 0) goto L_0x0009
            return r0
        L_0x0009:
            androidx.recyclerview.widget.RecyclerView$e r0 = r13.f824o
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x001f
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            if (r0 == 0) goto L_0x001f
            boolean r0 = r13.mo952O()
            if (r0 != 0) goto L_0x001f
            boolean r0 = r13.f776A
            if (r0 != 0) goto L_0x001f
            r0 = 1
            goto L_0x0020
        L_0x001f:
            r0 = 0
        L_0x0020:
            android.view.FocusFinder r3 = android.view.FocusFinder.getInstance()
            r4 = 33
            r5 = 17
            r6 = 0
            r7 = 2
            if (r0 == 0) goto L_0x0093
            if (r15 == r7) goto L_0x0030
            if (r15 != r2) goto L_0x0093
        L_0x0030:
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            boolean r0 = r0.mo901f()
            if (r0 == 0) goto L_0x0047
            if (r15 != r7) goto L_0x003d
            r0 = 130(0x82, float:1.82E-43)
            goto L_0x003f
        L_0x003d:
            r0 = 33
        L_0x003f:
            android.view.View r0 = r3.findNextFocus(r13, r14, r0)
            if (r0 != 0) goto L_0x0047
            r0 = 1
            goto L_0x0048
        L_0x0047:
            r0 = 0
        L_0x0048:
            if (r0 != 0) goto L_0x0073
            androidx.recyclerview.widget.RecyclerView$m r8 = r13.f826p
            boolean r8 = r8.mo899e()
            if (r8 == 0) goto L_0x0073
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            int r0 = r0.mo1122K()
            if (r0 != r2) goto L_0x005c
            r0 = 1
            goto L_0x005d
        L_0x005c:
            r0 = 0
        L_0x005d:
            if (r15 != r7) goto L_0x0061
            r8 = 1
            goto L_0x0062
        L_0x0061:
            r8 = 0
        L_0x0062:
            r0 = r0 ^ r8
            if (r0 == 0) goto L_0x0068
            r0 = 66
            goto L_0x006a
        L_0x0068:
            r0 = 17
        L_0x006a:
            android.view.View r0 = r3.findNextFocus(r13, r14, r0)
            if (r0 != 0) goto L_0x0072
            r0 = 1
            goto L_0x0073
        L_0x0072:
            r0 = 0
        L_0x0073:
            if (r0 == 0) goto L_0x008e
            r13.mo1024n()
            android.view.View r0 = r13.mo942C(r14)
            if (r0 != 0) goto L_0x007f
            return r6
        L_0x007f:
            r13.mo1019k0()
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            androidx.recyclerview.widget.RecyclerView$s r8 = r13.f804e
            androidx.recyclerview.widget.RecyclerView$w r9 = r13.f813i0
            r0.mo867l0(r14, r15, r8, r9)
            r13.mo1023m0(r1)
        L_0x008e:
            android.view.View r0 = r3.findNextFocus(r13, r14, r15)
            goto L_0x00b7
        L_0x0093:
            android.view.View r3 = r3.findNextFocus(r13, r14, r15)
            if (r3 != 0) goto L_0x00b6
            if (r0 == 0) goto L_0x00b6
            r13.mo1024n()
            android.view.View r0 = r13.mo942C(r14)
            if (r0 != 0) goto L_0x00a5
            return r6
        L_0x00a5:
            r13.mo1019k0()
            androidx.recyclerview.widget.RecyclerView$m r0 = r13.f826p
            androidx.recyclerview.widget.RecyclerView$s r3 = r13.f804e
            androidx.recyclerview.widget.RecyclerView$w r8 = r13.f813i0
            android.view.View r0 = r0.mo867l0(r14, r15, r3, r8)
            r13.mo1023m0(r1)
            goto L_0x00b7
        L_0x00b6:
            r0 = r3
        L_0x00b7:
            if (r0 == 0) goto L_0x00ce
            boolean r3 = r0.hasFocusable()
            if (r3 != 0) goto L_0x00ce
            android.view.View r1 = r13.getFocusedChild()
            if (r1 != 0) goto L_0x00ca
            android.view.View r14 = super.focusSearch(r14, r15)
            return r14
        L_0x00ca:
            r13.mo975d0(r0, r6)
            return r14
        L_0x00ce:
            if (r0 == 0) goto L_0x019f
            if (r0 != r13) goto L_0x00d4
            goto L_0x019f
        L_0x00d4:
            android.view.View r3 = r13.mo942C(r0)
            if (r3 != 0) goto L_0x00dc
            goto L_0x01a0
        L_0x00dc:
            if (r14 != 0) goto L_0x00e0
            goto L_0x019d
        L_0x00e0:
            android.view.View r3 = r13.mo942C(r14)
            if (r3 != 0) goto L_0x00e8
            goto L_0x019d
        L_0x00e8:
            android.graphics.Rect r3 = r13.f818l
            int r6 = r14.getWidth()
            int r8 = r14.getHeight()
            r3.set(r1, r1, r6, r8)
            android.graphics.Rect r3 = r13.f820m
            int r6 = r0.getWidth()
            int r8 = r0.getHeight()
            r3.set(r1, r1, r6, r8)
            android.graphics.Rect r1 = r13.f818l
            r13.offsetDescendantRectToMyCoords(r14, r1)
            android.graphics.Rect r1 = r13.f820m
            r13.offsetDescendantRectToMyCoords(r0, r1)
            androidx.recyclerview.widget.RecyclerView$m r1 = r13.f826p
            int r1 = r1.mo1122K()
            if (r1 != r2) goto L_0x0116
            r1 = -1
            goto L_0x0117
        L_0x0116:
            r1 = 1
        L_0x0117:
            android.graphics.Rect r3 = r13.f818l
            int r6 = r3.left
            android.graphics.Rect r8 = r13.f820m
            int r9 = r8.left
            if (r6 < r9) goto L_0x0125
            int r10 = r3.right
            if (r10 > r9) goto L_0x012d
        L_0x0125:
            int r10 = r3.right
            int r11 = r8.right
            if (r10 >= r11) goto L_0x012d
            r6 = 1
            goto L_0x013a
        L_0x012d:
            int r10 = r3.right
            int r11 = r8.right
            if (r10 > r11) goto L_0x0135
            if (r6 < r11) goto L_0x0139
        L_0x0135:
            if (r6 <= r9) goto L_0x0139
            r6 = -1
            goto L_0x013a
        L_0x0139:
            r6 = 0
        L_0x013a:
            int r9 = r3.top
            int r10 = r8.top
            if (r9 < r10) goto L_0x0144
            int r11 = r3.bottom
            if (r11 > r10) goto L_0x014c
        L_0x0144:
            int r11 = r3.bottom
            int r12 = r8.bottom
            if (r11 >= r12) goto L_0x014c
            r3 = 1
            goto L_0x0159
        L_0x014c:
            int r3 = r3.bottom
            int r8 = r8.bottom
            if (r3 > r8) goto L_0x0154
            if (r9 < r8) goto L_0x0158
        L_0x0154:
            if (r9 <= r10) goto L_0x0158
            r3 = -1
            goto L_0x0159
        L_0x0158:
            r3 = 0
        L_0x0159:
            if (r15 == r2) goto L_0x0195
            if (r15 == r7) goto L_0x018c
            if (r15 == r5) goto L_0x0189
            if (r15 == r4) goto L_0x0186
            r1 = 66
            if (r15 == r1) goto L_0x0183
            r1 = 130(0x82, float:1.82E-43)
            if (r15 != r1) goto L_0x016c
            if (r3 <= 0) goto L_0x019f
            goto L_0x019d
        L_0x016c:
            java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Invalid direction: "
            r0.append(r1)
            r0.append(r15)
            java.lang.String r15 = p000.C1012kd.m3197f(r13, r0)
            r14.<init>(r15)
            throw r14
        L_0x0183:
            if (r6 <= 0) goto L_0x019f
            goto L_0x019d
        L_0x0186:
            if (r3 >= 0) goto L_0x019f
            goto L_0x019d
        L_0x0189:
            if (r6 >= 0) goto L_0x019f
            goto L_0x019d
        L_0x018c:
            if (r3 > 0) goto L_0x019d
            if (r3 != 0) goto L_0x019f
            int r6 = r6 * r1
            if (r6 < 0) goto L_0x019f
            goto L_0x019d
        L_0x0195:
            if (r3 < 0) goto L_0x019d
            if (r3 != 0) goto L_0x019f
            int r6 = r6 * r1
            if (r6 > 0) goto L_0x019f
        L_0x019d:
            r1 = 1
            goto L_0x01a0
        L_0x019f:
            r1 = 0
        L_0x01a0:
            if (r1 == 0) goto L_0x01a3
            goto L_0x01a7
        L_0x01a3:
            android.view.View r0 = super.focusSearch(r14, r15)
        L_0x01a7:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.focusSearch(android.view.View, int):android.view.View");
    }

    /* renamed from: g */
    public final void mo988g(C0181z zVar) {
        View view = zVar.f928a;
        boolean z = view.getParent() == this;
        this.f804e.mo1194m(mo948J(view));
        if (zVar.mo1219n()) {
            this.f810h.mo5203b(view, -1, view.getLayoutParams(), true);
            return;
        }
        C1412pa paVar = this.f810h;
        if (!z) {
            paVar.mo5202a(view, -1, true);
            return;
        }
        int indexOfChild = ((C0742gb) paVar.f4813a).f2853a.indexOfChild(view);
        if (indexOfChild >= 0) {
            paVar.f4814b.mo5223h(indexOfChild);
            paVar.mo5210i(view);
            return;
        }
        throw new IllegalArgumentException("view is not a child, cannot hide " + view);
    }

    /* renamed from: g0 */
    public void mo989g0(int i, int i2, int[] iArr) {
        C0181z zVar;
        mo1019k0();
        mo957T();
        int i3 = C2050x5.f6724a;
        Trace.beginSection("RV Scroll");
        mo941B(this.f813i0);
        int O0 = i != 0 ? this.f826p.mo858O0(i, this.f804e, this.f813i0) : 0;
        int Q0 = i2 != 0 ? this.f826p.mo860Q0(i2, this.f804e, this.f813i0) : 0;
        Trace.endSection();
        int e = this.f810h.mo5206e();
        for (int i4 = 0; i4 < e; i4++) {
            View d = this.f810h.mo5205d(i4);
            C0181z J = mo948J(d);
            if (!(J == null || (zVar = J.f936i) == null)) {
                View view = zVar.f928a;
                int left = d.getLeft();
                int top = d.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        mo958U(true);
        mo1023m0(false);
        if (iArr != null) {
            iArr[0] = O0;
            iArr[1] = Q0;
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        C0162m mVar = this.f826p;
        if (mVar != null) {
            return mVar.mo877u();
        }
        throw new IllegalStateException(C1012kd.m3197f(this, C1012kd.m3195d("RecyclerView has no LayoutManager")));
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        C0162m mVar = this.f826p;
        if (mVar != null) {
            return mVar.mo880v(getContext(), attributeSet);
        }
        throw new IllegalStateException(C1012kd.m3197f(this, C1012kd.m3195d("RecyclerView has no LayoutManager")));
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        C0162m mVar = this.f826p;
        if (mVar != null) {
            return mVar.mo881w(layoutParams);
        }
        throw new IllegalStateException(C1012kd.m3197f(this, C1012kd.m3195d("RecyclerView has no LayoutManager")));
    }

    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public C0150e getAdapter() {
        return this.f824o;
    }

    public int getBaseline() {
        C0162m mVar = this.f826p;
        if (mVar == null) {
            return super.getBaseline();
        }
        Objects.requireNonNull(mVar);
        return -1;
    }

    public int getChildDrawingOrder(int i, int i2) {
        C0154h hVar = this.f829q0;
        return hVar == null ? super.getChildDrawingOrder(i, i2) : hVar.mo1095a(i, i2);
    }

    public boolean getClipToPadding() {
        return this.f814j;
    }

    public C0882ib getCompatAccessibilityDelegate() {
        return this.f827p0;
    }

    public C0155i getEdgeEffectFactory() {
        return this.f785J;
    }

    public C0156j getItemAnimator() {
        return this.f790O;
    }

    public int getItemDecorationCount() {
        return this.f830r.size();
    }

    public C0162m getLayoutManager() {
        return this.f826p;
    }

    public int getMaxFlingVelocity() {
        return this.f800b0;
    }

    public int getMinFlingVelocity() {
        return this.f799a0;
    }

    public long getNanoTime() {
        if (f772D0) {
            return System.nanoTime();
        }
        return 0;
    }

    public C0168o getOnFlingListener() {
        return null;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f805e0;
    }

    public C0171r getRecycledViewPool() {
        return this.f804e.mo1185d();
    }

    public int getScrollState() {
        return this.f791P;
    }

    /* renamed from: h */
    public void mo1010h(C0170q qVar) {
        if (this.f817k0 == null) {
            this.f817k0 = new ArrayList();
        }
        this.f817k0.add(qVar);
    }

    /* renamed from: h0 */
    public void mo1011h0(int i) {
        if (!this.f776A) {
            mo1025n0();
            C0162m mVar = this.f826p;
            if (mVar == null) {
                Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
                return;
            }
            mVar.mo892P0(i);
            awakenScrollBars();
        }
    }

    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().mo5816h(0);
    }

    /* renamed from: i */
    public void mo1013i(String str) {
        if (mo952O()) {
            if (str == null) {
                throw new IllegalStateException(C1012kd.m3197f(this, C1012kd.m3195d("Cannot call this method while RecyclerView is computing a layout or scrolling")));
            }
            throw new IllegalStateException(str);
        } else if (this.f784I > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(C1012kd.m3197f(this, C1012kd.m3195d(""))));
        }
    }

    /* renamed from: i0 */
    public boolean mo1014i0(C0181z zVar, int i) {
        if (mo952O()) {
            zVar.f944q = i;
            this.f841w0.add(zVar);
            return false;
        }
        View view = zVar.f928a;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        view.setImportantForAccessibility(i);
        return true;
    }

    public boolean isAttachedToWindow() {
        return this.f836u;
    }

    public final boolean isLayoutSuppressed() {
        return this.f776A;
    }

    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f5679d;
    }

    /* renamed from: j */
    public final void mo1017j() {
        mo985e0();
        setScrollState(0);
    }

    /* renamed from: j0 */
    public void mo1018j0(int i, int i2, Interpolator interpolator, int i3, boolean z) {
        int i4;
        C0162m mVar = this.f826p;
        if (mVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f776A) {
            int i5 = !mVar.mo899e() ? 0 : i;
            int i6 = !this.f826p.mo901f() ? 0 : i2;
            if (i5 != 0 || i6 != 0) {
                boolean z2 = true;
                if (i3 == Integer.MIN_VALUE || i3 > 0) {
                    if (z) {
                        int i7 = i5 != 0 ? 1 : 0;
                        if (i6 != 0) {
                            i7 |= 2;
                        }
                        mo1021l0(i7, 1);
                    }
                    C0180y yVar = this.f807f0;
                    Objects.requireNonNull(yVar);
                    if (i3 == Integer.MIN_VALUE) {
                        int abs = Math.abs(i5);
                        int abs2 = Math.abs(i6);
                        if (abs <= abs2) {
                            z2 = false;
                        }
                        int sqrt = (int) Math.sqrt((double) 0);
                        int sqrt2 = (int) Math.sqrt((double) ((i6 * i6) + (i5 * i5)));
                        RecyclerView recyclerView = RecyclerView.this;
                        int width = z2 ? recyclerView.getWidth() : recyclerView.getHeight();
                        int i8 = width / 2;
                        float f = (float) width;
                        float f2 = (float) i8;
                        float sin = (((float) Math.sin((double) ((Math.min(1.0f, (((float) sqrt2) * 1.0f) / f) - 0.5f) * 0.47123894f))) * f2) + f2;
                        if (sqrt > 0) {
                            i4 = Math.round(Math.abs(sin / ((float) sqrt)) * 1000.0f) * 4;
                        } else {
                            if (!z2) {
                                abs = abs2;
                            }
                            i4 = (int) (((((float) abs) / f) + 1.0f) * 300.0f);
                        }
                        i3 = Math.min(i4, 2000);
                    }
                    int i9 = i3;
                    if (interpolator == null) {
                        interpolator = f774F0;
                    }
                    if (yVar.f923g != interpolator) {
                        yVar.f923g = interpolator;
                        yVar.f922f = new OverScroller(RecyclerView.this.getContext(), interpolator);
                    }
                    yVar.f921e = 0;
                    yVar.f920d = 0;
                    RecyclerView.this.setScrollState(2);
                    yVar.f922f.startScroll(0, 0, i5, i6, i9);
                    if (Build.VERSION.SDK_INT < 23) {
                        yVar.f922f.computeScrollOffset();
                    }
                    yVar.mo1204a();
                    return;
                }
                scrollBy(i5, i6);
            }
        }
    }

    /* renamed from: k0 */
    public void mo1019k0() {
        int i = this.f844y + 1;
        this.f844y = i;
        if (i == 1 && !this.f776A) {
            this.f846z = false;
        }
    }

    /* renamed from: l */
    public void mo1020l() {
        int h = this.f810h.mo5209h();
        for (int i = 0; i < h; i++) {
            C0181z K = m512K(this.f810h.mo5208g(i));
            if (!K.mo1225t()) {
                K.mo1208c();
            }
        }
        C0173s sVar = this.f804e;
        int size = sVar.f899c.size();
        for (int i2 = 0; i2 < size; i2++) {
            sVar.f899c.get(i2).mo1208c();
        }
        int size2 = sVar.f897a.size();
        for (int i3 = 0; i3 < size2; i3++) {
            sVar.f897a.get(i3).mo1208c();
        }
        ArrayList<C0181z> arrayList = sVar.f898b;
        if (arrayList != null) {
            int size3 = arrayList.size();
            for (int i4 = 0; i4 < size3; i4++) {
                sVar.f898b.get(i4).mo1208c();
            }
        }
    }

    /* renamed from: l0 */
    public boolean mo1021l0(int i, int i2) {
        return getScrollingChildHelper().mo5818j(i, i2);
    }

    /* renamed from: m */
    public void mo1022m(int i, int i2) {
        boolean z;
        EdgeEffect edgeEffect = this.f786K;
        if (edgeEffect == null || edgeEffect.isFinished() || i <= 0) {
            z = false;
        } else {
            this.f786K.onRelease();
            z = this.f786K.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f788M;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.f788M.onRelease();
            z |= this.f788M.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f787L;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i2 > 0) {
            this.f787L.onRelease();
            z |= this.f787L.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f789N;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i2 < 0) {
            this.f789N.onRelease();
            z |= this.f789N.isFinished();
        }
        if (z) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            postInvalidateOnAnimation();
        }
    }

    /* renamed from: m0 */
    public void mo1023m0(boolean z) {
        if (this.f844y < 1) {
            this.f844y = 1;
        }
        if (!z && !this.f776A) {
            this.f846z = false;
        }
        if (this.f844y == 1) {
            if (z && this.f846z && !this.f776A && this.f826p != null && this.f824o != null) {
                mo1040q();
            }
            if (!this.f776A) {
                this.f846z = false;
            }
        }
        this.f844y--;
    }

    /* renamed from: n */
    public void mo1024n() {
        if (!this.f842x || this.f781F) {
            int i = C2050x5.f6724a;
            Trace.beginSection("RV FullInvalidate");
            mo1040q();
            Trace.endSection();
        } else if (this.f808g.mo5030g()) {
            C1321oa oaVar = this.f808g;
            int i2 = oaVar.f4487f;
            boolean z = false;
            if ((i2 & 4) != 0) {
                if (!((i2 & 11) != 0)) {
                    int i3 = C2050x5.f6724a;
                    Trace.beginSection("RV PartialInvalidate");
                    mo1019k0();
                    mo957T();
                    this.f808g.mo5033j();
                    if (!this.f846z) {
                        int e = this.f810h.mo5206e();
                        int i4 = 0;
                        while (true) {
                            if (i4 < e) {
                                C0181z K = m512K(this.f810h.mo5205d(i4));
                                if (K != null && !K.mo1225t() && K.mo1220o()) {
                                    z = true;
                                    break;
                                }
                                i4++;
                            } else {
                                break;
                            }
                        }
                        if (z) {
                            mo1040q();
                        } else {
                            this.f808g.mo5025b();
                        }
                    }
                    mo1023m0(true);
                    mo958U(true);
                    Trace.endSection();
                }
            }
            if (oaVar.mo5030g()) {
                int i5 = C2050x5.f6724a;
                Trace.beginSection("RV FullInvalidate");
                mo1040q();
                Trace.endSection();
            }
        }
    }

    /* renamed from: n0 */
    public void mo1025n0() {
        setScrollState(0);
        C0180y yVar = this.f807f0;
        RecyclerView.this.removeCallbacks(yVar);
        yVar.f922f.abortAnimation();
    }

    /* renamed from: o */
    public void mo1026o(int i, int i2) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        setMeasuredDimension(C0162m.m603h(i, paddingRight, getMinimumWidth()), C0162m.m603h(i2, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f783H = 0;
        this.f836u = true;
        this.f842x = this.f842x && !isLayoutRequested();
        C0162m mVar = this.f826p;
        if (mVar != null) {
            mVar.f872h = true;
            mVar.mo1155i0(this);
        }
        this.f825o0 = false;
        if (f772D0) {
            ThreadLocal<C0021ab> threadLocal = C0021ab.f60h;
            C0021ab abVar = threadLocal.get();
            this.f809g0 = abVar;
            if (abVar == null) {
                this.f809g0 = new C0021ab();
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                Display display = getDisplay();
                float f = 60.0f;
                if (!isInEditMode() && display != null) {
                    float refreshRate = display.getRefreshRate();
                    if (refreshRate >= 30.0f) {
                        f = refreshRate;
                    }
                }
                C0021ab abVar2 = this.f809g0;
                abVar2.f64f = (long) (1.0E9f / f);
                threadLocal.set(abVar2);
            }
            this.f809g0.f62d.add(this);
        }
    }

    public void onDetachedFromWindow() {
        C0021ab abVar;
        super.onDetachedFromWindow();
        C0156j jVar = this.f790O;
        if (jVar != null) {
            jVar.mo1101f();
        }
        mo1025n0();
        this.f836u = false;
        C0162m mVar = this.f826p;
        if (mVar != null) {
            C0173s sVar = this.f804e;
            mVar.f872h = false;
            mVar.mo910k0(this, sVar);
        }
        this.f841w0.clear();
        removeCallbacks(this.f843x0);
        Objects.requireNonNull(this.f812i);
        do {
        } while (C1101lb.C1102a.f3863d.mo4124b() != null);
        if (f772D0 && (abVar = this.f809g0) != null) {
            abVar.f62d.remove(this);
            this.f809g0 = null;
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.f830r.size();
        for (int i = 0; i < size; i++) {
            Objects.requireNonNull(this.f830r.get(i));
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float f2;
        if (this.f826p != null && !this.f776A && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.f826p.mo901f() ? -motionEvent.getAxisValue(9) : 0.0f;
                if (this.f826p.mo899e()) {
                    f = motionEvent.getAxisValue(10);
                    if (!(f2 == 0.0f && f == 0.0f)) {
                        mo986f0((int) (f * this.f801c0), (int) (f2 * this.f803d0), motionEvent);
                    }
                }
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.f826p.mo901f()) {
                        f2 = -axisValue;
                    } else if (this.f826p.mo899e()) {
                        f = axisValue;
                        f2 = 0.0f;
                        mo986f0((int) (f * this.f801c0), (int) (f2 * this.f803d0), motionEvent);
                    }
                }
                f2 = 0.0f;
            }
            f = 0.0f;
            mo986f0((int) (f * this.f801c0), (int) (f2 * this.f803d0), motionEvent);
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        if (this.f776A) {
            return false;
        }
        this.f834t = null;
        if (mo943D(motionEvent)) {
            mo1017j();
            return true;
        }
        C0162m mVar = this.f826p;
        if (mVar == null) {
            return false;
        }
        boolean e = mVar.mo899e();
        boolean f = this.f826p.mo901f();
        if (this.f793R == null) {
            this.f793R = VelocityTracker.obtain();
        }
        this.f793R.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f777B) {
                this.f777B = false;
            }
            this.f792Q = motionEvent.getPointerId(0);
            int x = (int) (motionEvent.getX() + 0.5f);
            this.f796U = x;
            this.f794S = x;
            int y = (int) (motionEvent.getY() + 0.5f);
            this.f797V = y;
            this.f795T = y;
            if (this.f791P == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                mo704a(1);
            }
            int[] iArr = this.f837u0;
            iArr[1] = 0;
            iArr[0] = 0;
            if (f) {
                e |= true;
            }
            mo1021l0(e ? 1 : 0, 0);
        } else if (actionMasked == 1) {
            this.f793R.clear();
            mo704a(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.f792Q);
            if (findPointerIndex < 0) {
                StringBuilder d = C1012kd.m3195d("Error processing scroll; pointer index for id ");
                d.append(this.f792Q);
                d.append(" not found. Did any MotionEvents get skipped?");
                Log.e("RecyclerView", d.toString());
                return false;
            }
            int x2 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y2 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.f791P != 1) {
                int i = x2 - this.f794S;
                int i2 = y2 - this.f795T;
                if (!e || Math.abs(i) <= this.f798W) {
                    z = false;
                } else {
                    this.f796U = x2;
                    z = true;
                }
                if (f && Math.abs(i2) > this.f798W) {
                    this.f797V = y2;
                    z = true;
                }
                if (z) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            mo1017j();
        } else if (actionMasked == 5) {
            this.f792Q = motionEvent.getPointerId(actionIndex);
            int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.f796U = x3;
            this.f794S = x3;
            int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.f797V = y3;
            this.f795T = y3;
        } else if (actionMasked == 6) {
            mo959V(motionEvent);
        }
        return this.f791P == 1;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = C2050x5.f6724a;
        Trace.beginSection("RV OnLayout");
        mo1040q();
        Trace.endSection();
        this.f842x = true;
    }

    public void onMeasure(int i, int i2) {
        C0162m mVar = this.f826p;
        if (mVar == null) {
            mo1026o(i, i2);
            return;
        }
        boolean z = false;
        if (mVar.mo894Z()) {
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.f826p.mo1167z0(i, i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z = true;
            }
            if (!z && this.f824o != null) {
                if (this.f813i0.f909c == 1) {
                    mo1041r();
                }
                this.f826p.mo1136S0(i, i2);
                this.f813i0.f914h = true;
                mo1047s();
                this.f826p.mo1138U0(i, i2);
                if (this.f826p.mo893X0()) {
                    this.f826p.mo1136S0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                    this.f813i0.f914h = true;
                    mo1047s();
                    this.f826p.mo1138U0(i, i2);
                }
            }
        } else if (this.f838v) {
            this.f826p.mo1167z0(i, i2);
        } else {
            if (this.f779D) {
                mo1019k0();
                mo957T();
                mo963Z();
                mo958U(true);
                C0178w wVar = this.f813i0;
                if (wVar.f916j) {
                    wVar.f912f = true;
                } else {
                    this.f808g.mo5026c();
                    this.f813i0.f912f = false;
                }
                this.f779D = false;
                mo1023m0(false);
            } else if (this.f813i0.f916j) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            C0150e eVar = this.f824o;
            if (eVar != null) {
                this.f813i0.f910d = eVar.mo1085a();
            } else {
                this.f813i0.f910d = 0;
            }
            mo1019k0();
            this.f826p.mo1167z0(i, i2);
            mo1023m0(false);
            this.f813i0.f912f = false;
        }
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (mo952O()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0176v)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0176v vVar = (C0176v) parcelable;
        this.f806f = vVar;
        super.onRestoreInstanceState(vVar.f43d);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0176v vVar = new C0176v(super.onSaveInstanceState());
        C0176v vVar2 = this.f806f;
        if (vVar2 != null) {
            vVar.f906f = vVar2.f906f;
        } else {
            C0162m mVar = this.f826p;
            vVar.f906f = mVar != null ? mVar.mo889D0() : null;
        }
        return vVar;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            mo951N();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:132:0x0259, code lost:
        if (r1 != false) goto L_0x025e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x010c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            r22 = this;
            r0 = r22
            r1 = r23
            boolean r2 = r0.f776A
            r3 = 0
            if (r2 != 0) goto L_0x028f
            boolean r2 = r0.f777B
            if (r2 == 0) goto L_0x000f
            goto L_0x028f
        L_0x000f:
            androidx.recyclerview.widget.RecyclerView$p r2 = r0.f834t
            r4 = 3
            r5 = 1
            if (r2 != 0) goto L_0x0022
            int r2 = r23.getAction()
            if (r2 != 0) goto L_0x001d
            r2 = 0
            goto L_0x0031
        L_0x001d:
            boolean r2 = r22.mo943D(r23)
            goto L_0x0031
        L_0x0022:
            r2.mo1177b(r0, r1)
            int r2 = r23.getAction()
            if (r2 == r4) goto L_0x002d
            if (r2 != r5) goto L_0x0030
        L_0x002d:
            r2 = 0
            r0.f834t = r2
        L_0x0030:
            r2 = 1
        L_0x0031:
            if (r2 == 0) goto L_0x0037
            r22.mo1017j()
            return r5
        L_0x0037:
            androidx.recyclerview.widget.RecyclerView$m r2 = r0.f826p
            if (r2 != 0) goto L_0x003c
            return r3
        L_0x003c:
            boolean r2 = r2.mo899e()
            androidx.recyclerview.widget.RecyclerView$m r6 = r0.f826p
            boolean r6 = r6.mo901f()
            android.view.VelocityTracker r7 = r0.f793R
            if (r7 != 0) goto L_0x0050
            android.view.VelocityTracker r7 = android.view.VelocityTracker.obtain()
            r0.f793R = r7
        L_0x0050:
            int r7 = r23.getActionMasked()
            int r8 = r23.getActionIndex()
            if (r7 != 0) goto L_0x0060
            int[] r9 = r0.f837u0
            r9[r5] = r3
            r9[r3] = r3
        L_0x0060:
            android.view.MotionEvent r9 = android.view.MotionEvent.obtain(r23)
            int[] r10 = r0.f837u0
            r11 = r10[r3]
            float r11 = (float) r11
            r10 = r10[r5]
            float r10 = (float) r10
            r9.offsetLocation(r11, r10)
            r10 = 1056964608(0x3f000000, float:0.5)
            if (r7 == 0) goto L_0x0263
            java.lang.String r11 = "RecyclerView"
            r12 = 2
            if (r7 == r5) goto L_0x0186
            if (r7 == r12) goto L_0x00aa
            if (r7 == r4) goto L_0x00a5
            r2 = 5
            if (r7 == r2) goto L_0x0089
            r2 = 6
            if (r7 == r2) goto L_0x0084
            goto L_0x0284
        L_0x0084:
            r22.mo959V(r23)
            goto L_0x0284
        L_0x0089:
            int r2 = r1.getPointerId(r8)
            r0.f792Q = r2
            float r2 = r1.getX(r8)
            float r2 = r2 + r10
            int r2 = (int) r2
            r0.f796U = r2
            r0.f794S = r2
            float r1 = r1.getY(r8)
            float r1 = r1 + r10
            int r1 = (int) r1
            r0.f797V = r1
            r0.f795T = r1
            goto L_0x0284
        L_0x00a5:
            r22.mo1017j()
            goto L_0x0284
        L_0x00aa:
            int r4 = r0.f792Q
            int r4 = r1.findPointerIndex(r4)
            if (r4 >= 0) goto L_0x00ca
            java.lang.String r1 = "Error processing scroll; pointer index for id "
            java.lang.StringBuilder r1 = p000.C1012kd.m3195d(r1)
            int r2 = r0.f792Q
            r1.append(r2)
            java.lang.String r2 = " not found. Did any MotionEvents get skipped?"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r11, r1)
            return r3
        L_0x00ca:
            float r7 = r1.getX(r4)
            float r7 = r7 + r10
            int r7 = (int) r7
            float r4 = r1.getY(r4)
            float r4 = r4 + r10
            int r4 = (int) r4
            int r8 = r0.f796U
            int r8 = r8 - r7
            int r10 = r0.f797V
            int r10 = r10 - r4
            int r11 = r0.f791P
            if (r11 == r5) goto L_0x010f
            if (r2 == 0) goto L_0x00f5
            int r11 = r0.f798W
            if (r8 <= 0) goto L_0x00ec
            int r8 = r8 - r11
            int r8 = java.lang.Math.max(r3, r8)
            goto L_0x00f1
        L_0x00ec:
            int r8 = r8 + r11
            int r8 = java.lang.Math.min(r3, r8)
        L_0x00f1:
            if (r8 == 0) goto L_0x00f5
            r11 = 1
            goto L_0x00f6
        L_0x00f5:
            r11 = 0
        L_0x00f6:
            if (r6 == 0) goto L_0x010a
            int r12 = r0.f798W
            if (r10 <= 0) goto L_0x0102
            int r10 = r10 - r12
            int r10 = java.lang.Math.max(r3, r10)
            goto L_0x0107
        L_0x0102:
            int r10 = r10 + r12
            int r10 = java.lang.Math.min(r3, r10)
        L_0x0107:
            if (r10 == 0) goto L_0x010a
            r11 = 1
        L_0x010a:
            if (r11 == 0) goto L_0x010f
            r0.setScrollState(r5)
        L_0x010f:
            int r11 = r0.f791P
            if (r11 != r5) goto L_0x0284
            int[] r15 = r0.f839v0
            r15[r3] = r3
            r15[r5] = r3
            if (r2 == 0) goto L_0x011d
            r13 = r8
            goto L_0x011f
        L_0x011d:
            r11 = 0
            r13 = 0
        L_0x011f:
            if (r6 == 0) goto L_0x0123
            r14 = r10
            goto L_0x0125
        L_0x0123:
            r11 = 0
            r14 = 0
        L_0x0125:
            int[] r11 = r0.f835t0
            r17 = 0
            s6 r12 = r22.getScrollingChildHelper()
            r16 = r11
            boolean r11 = r12.mo5811c(r13, r14, r15, r16, r17)
            if (r11 == 0) goto L_0x0156
            int[] r11 = r0.f839v0
            r12 = r11[r3]
            int r8 = r8 - r12
            r11 = r11[r5]
            int r10 = r10 - r11
            int[] r11 = r0.f837u0
            r12 = r11[r3]
            int[] r13 = r0.f835t0
            r14 = r13[r3]
            int r12 = r12 + r14
            r11[r3] = r12
            r12 = r11[r5]
            r13 = r13[r5]
            int r12 = r12 + r13
            r11[r5] = r12
            android.view.ViewParent r11 = r22.getParent()
            r11.requestDisallowInterceptTouchEvent(r5)
        L_0x0156:
            int[] r11 = r0.f835t0
            r12 = r11[r3]
            int r7 = r7 - r12
            r0.f796U = r7
            r7 = r11[r5]
            int r4 = r4 - r7
            r0.f797V = r4
            if (r2 == 0) goto L_0x0166
            r2 = r8
            goto L_0x0167
        L_0x0166:
            r2 = 0
        L_0x0167:
            if (r6 == 0) goto L_0x016b
            r4 = r10
            goto L_0x016c
        L_0x016b:
            r4 = 0
        L_0x016c:
            boolean r1 = r0.mo986f0(r2, r4, r1)
            if (r1 == 0) goto L_0x0179
            android.view.ViewParent r1 = r22.getParent()
            r1.requestDisallowInterceptTouchEvent(r5)
        L_0x0179:
            ab r1 = r0.f809g0
            if (r1 == 0) goto L_0x0284
            if (r8 != 0) goto L_0x0181
            if (r10 == 0) goto L_0x0284
        L_0x0181:
            r1.mo68a(r0, r8, r10)
            goto L_0x0284
        L_0x0186:
            android.view.VelocityTracker r1 = r0.f793R
            r1.addMovement(r9)
            android.view.VelocityTracker r1 = r0.f793R
            r4 = 1000(0x3e8, float:1.401E-42)
            int r7 = r0.f800b0
            float r7 = (float) r7
            r1.computeCurrentVelocity(r4, r7)
            r1 = 0
            if (r2 == 0) goto L_0x01a2
            android.view.VelocityTracker r2 = r0.f793R
            int r4 = r0.f792Q
            float r2 = r2.getXVelocity(r4)
            float r2 = -r2
            goto L_0x01a3
        L_0x01a2:
            r2 = 0
        L_0x01a3:
            if (r6 == 0) goto L_0x01af
            android.view.VelocityTracker r4 = r0.f793R
            int r6 = r0.f792Q
            float r4 = r4.getYVelocity(r6)
            float r4 = -r4
            goto L_0x01b0
        L_0x01af:
            r4 = 0
        L_0x01b0:
            int r6 = (r2 > r1 ? 1 : (r2 == r1 ? 0 : -1))
            if (r6 != 0) goto L_0x01b8
            int r1 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1))
            if (r1 == 0) goto L_0x025b
        L_0x01b8:
            int r1 = (int) r2
            int r2 = (int) r4
            androidx.recyclerview.widget.RecyclerView$m r4 = r0.f826p
            if (r4 != 0) goto L_0x01c5
            java.lang.String r1 = "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument."
            android.util.Log.e(r11, r1)
            goto L_0x0258
        L_0x01c5:
            boolean r6 = r0.f776A
            if (r6 == 0) goto L_0x01cb
            goto L_0x0258
        L_0x01cb:
            boolean r4 = r4.mo899e()
            androidx.recyclerview.widget.RecyclerView$m r6 = r0.f826p
            boolean r6 = r6.mo901f()
            if (r4 == 0) goto L_0x01df
            int r7 = java.lang.Math.abs(r1)
            int r8 = r0.f799a0
            if (r7 >= r8) goto L_0x01e0
        L_0x01df:
            r1 = 0
        L_0x01e0:
            if (r6 == 0) goto L_0x01ea
            int r7 = java.lang.Math.abs(r2)
            int r8 = r0.f799a0
            if (r7 >= r8) goto L_0x01eb
        L_0x01ea:
            r2 = 0
        L_0x01eb:
            if (r1 != 0) goto L_0x01f0
            if (r2 != 0) goto L_0x01f0
            goto L_0x0258
        L_0x01f0:
            float r7 = (float) r1
            float r8 = (float) r2
            boolean r10 = r0.dispatchNestedPreFling(r7, r8)
            if (r10 != 0) goto L_0x0258
            if (r4 != 0) goto L_0x01ff
            if (r6 == 0) goto L_0x01fd
            goto L_0x01ff
        L_0x01fd:
            r10 = 0
            goto L_0x0200
        L_0x01ff:
            r10 = 1
        L_0x0200:
            r0.dispatchNestedFling(r7, r8, r10)
            if (r10 == 0) goto L_0x0258
            if (r6 == 0) goto L_0x0209
            r4 = r4 | 2
        L_0x0209:
            r0.mo1021l0(r4, r5)
            int r4 = r0.f800b0
            int r6 = -r4
            int r1 = java.lang.Math.min(r1, r4)
            int r16 = java.lang.Math.max(r6, r1)
            int r1 = r0.f800b0
            int r4 = -r1
            int r1 = java.lang.Math.min(r2, r1)
            int r17 = java.lang.Math.max(r4, r1)
            androidx.recyclerview.widget.RecyclerView$y r1 = r0.f807f0
            androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
            r2.setScrollState(r12)
            r1.f921e = r3
            r1.f920d = r3
            android.view.animation.Interpolator r2 = r1.f923g
            android.view.animation.Interpolator r4 = f774F0
            if (r2 == r4) goto L_0x0242
            r1.f923g = r4
            android.widget.OverScroller r2 = new android.widget.OverScroller
            androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
            android.content.Context r6 = r6.getContext()
            r2.<init>(r6, r4)
            r1.f922f = r2
        L_0x0242:
            android.widget.OverScroller r13 = r1.f922f
            r14 = 0
            r15 = 0
            r18 = -2147483648(0xffffffff80000000, float:-0.0)
            r19 = 2147483647(0x7fffffff, float:NaN)
            r20 = -2147483648(0xffffffff80000000, float:-0.0)
            r21 = 2147483647(0x7fffffff, float:NaN)
            r13.fling(r14, r15, r16, r17, r18, r19, r20, r21)
            r1.mo1204a()
            r1 = 1
            goto L_0x0259
        L_0x0258:
            r1 = 0
        L_0x0259:
            if (r1 != 0) goto L_0x025e
        L_0x025b:
            r0.setScrollState(r3)
        L_0x025e:
            r22.mo985e0()
            r3 = 1
            goto L_0x0284
        L_0x0263:
            int r4 = r1.getPointerId(r3)
            r0.f792Q = r4
            float r4 = r23.getX()
            float r4 = r4 + r10
            int r4 = (int) r4
            r0.f796U = r4
            r0.f794S = r4
            float r1 = r23.getY()
            float r1 = r1 + r10
            int r1 = (int) r1
            r0.f797V = r1
            r0.f795T = r1
            if (r6 == 0) goto L_0x0281
            r2 = r2 | 2
        L_0x0281:
            r0.mo1021l0(r2, r3)
        L_0x0284:
            if (r3 != 0) goto L_0x028b
            android.view.VelocityTracker r1 = r0.f793R
            r1.addMovement(r9)
        L_0x028b:
            r9.recycle()
            return r5
        L_0x028f:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public void mo1039p(View view) {
        C0181z K = m512K(view);
        mo956S();
        C0150e eVar = this.f824o;
        if (eVar != null && K != null) {
            Objects.requireNonNull(eVar);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:124:0x02d4, code lost:
        if (r15.f810h.mo5212k(getFocusedChild()) == false) goto L_0x0347;
     */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x0299  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x02ca  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x02e0  */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x02ed  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x032e  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x0257  */
    /* renamed from: q */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1040q() {
        /*
            r15 = this;
            androidx.recyclerview.widget.RecyclerView$e r0 = r15.f824o
            java.lang.String r1 = "RecyclerView"
            if (r0 != 0) goto L_0x0009
            java.lang.String r0 = "No adapter attached; skipping layout"
            goto L_0x000f
        L_0x0009:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            if (r0 != 0) goto L_0x0013
            java.lang.String r0 = "No layout manager attached; skipping layout"
        L_0x000f:
            android.util.Log.e(r1, r0)
            return
        L_0x0013:
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            r2 = 0
            r0.f914h = r2
            int r0 = r0.f909c
            r3 = 1
            if (r0 != r3) goto L_0x0021
            r15.mo1041r()
            goto L_0x0053
        L_0x0021:
            oa r0 = r15.f808g
            java.util.ArrayList<oa$b> r4 = r0.f4484c
            boolean r4 = r4.isEmpty()
            if (r4 != 0) goto L_0x0035
            java.util.ArrayList<oa$b> r0 = r0.f4483b
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x0035
            r0 = 1
            goto L_0x0036
        L_0x0035:
            r0 = 0
        L_0x0036:
            if (r0 != 0) goto L_0x0053
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            int r0 = r0.f879o
            int r4 = r15.getWidth()
            if (r0 != r4) goto L_0x0053
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            int r0 = r0.f880p
            int r4 = r15.getHeight()
            if (r0 == r4) goto L_0x004d
            goto L_0x0053
        L_0x004d:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            r0.mo1134R0(r15)
            goto L_0x005b
        L_0x0053:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            r0.mo1134R0(r15)
            r15.mo1047s()
        L_0x005b:
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            r4 = 4
            r0.mo1201a(r4)
            r15.mo1019k0()
            r15.mo957T()
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            r0.f909c = r3
            boolean r0 = r0.f915i
            r5 = 0
            if (r0 == 0) goto L_0x0238
            pa r0 = r15.f810h
            int r0 = r0.mo5206e()
            int r0 = r0 - r3
        L_0x0077:
            if (r0 < 0) goto L_0x0182
            pa r6 = r15.f810h
            android.view.View r6 = r6.mo5205d(r0)
            androidx.recyclerview.widget.RecyclerView$z r6 = m512K(r6)
            boolean r7 = r6.mo1225t()
            if (r7 == 0) goto L_0x008b
            goto L_0x017d
        L_0x008b:
            androidx.recyclerview.widget.RecyclerView$e r7 = r15.f824o
            java.util.Objects.requireNonNull(r7)
            int r7 = r6.f930c
            long r7 = (long) r7
            androidx.recyclerview.widget.RecyclerView$j r9 = r15.f790O
            java.util.Objects.requireNonNull(r9)
            androidx.recyclerview.widget.RecyclerView$j$c r9 = new androidx.recyclerview.widget.RecyclerView$j$c
            r9.<init>()
            android.view.View r10 = r6.f928a
            int r11 = r10.getLeft()
            r9.f862a = r11
            int r11 = r10.getTop()
            r9.f863b = r11
            r10.getRight()
            r10.getBottom()
            lb r10 = r15.f812i
            b4<androidx.recyclerview.widget.RecyclerView$z> r10 = r10.f3862b
            java.lang.Object r10 = r10.mo1590f(r7, r5)
            androidx.recyclerview.widget.RecyclerView$z r10 = (androidx.recyclerview.widget.RecyclerView.C0181z) r10
            if (r10 == 0) goto L_0x0178
            boolean r11 = r10.mo1225t()
            if (r11 != 0) goto L_0x0178
            lb r11 = r15.f812i
            boolean r11 = r11.mo4415d(r10)
            lb r12 = r15.f812i
            boolean r12 = r12.mo4415d(r6)
            if (r11 == 0) goto L_0x00d5
            if (r10 != r6) goto L_0x00d5
            goto L_0x0178
        L_0x00d5:
            lb r13 = r15.f812i
            androidx.recyclerview.widget.RecyclerView$j$c r4 = r13.mo4416e(r10, r4)
            lb r13 = r15.f812i
            r13.mo4413b(r6, r9)
            lb r9 = r15.f812i
            r13 = 8
            androidx.recyclerview.widget.RecyclerView$j$c r9 = r9.mo4416e(r6, r13)
            if (r4 != 0) goto L_0x014e
            pa r4 = r15.f810h
            int r4 = r4.mo5206e()
            r9 = 0
        L_0x00f1:
            if (r9 >= r4) goto L_0x012a
            pa r11 = r15.f810h
            android.view.View r11 = r11.mo5205d(r9)
            androidx.recyclerview.widget.RecyclerView$z r11 = m512K(r11)
            if (r11 != r6) goto L_0x0100
            goto L_0x0108
        L_0x0100:
            long r12 = r15.mo947I(r11)
            int r14 = (r12 > r7 ? 1 : (r12 == r7 ? 0 : -1))
            if (r14 == 0) goto L_0x010b
        L_0x0108:
            int r9 = r9 + 1
            goto L_0x00f1
        L_0x010b:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:"
            r1.append(r2)
            r1.append(r11)
            java.lang.String r2 = " \n View Holder 2:"
            r1.append(r2)
            r1.append(r6)
            java.lang.String r1 = p000.C1012kd.m3197f(r15, r1)
            r0.<init>(r1)
            throw r0
        L_0x012a:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r7 = "Problem while matching changed view holders with the newones. The pre-layout information for the change holder "
            r4.append(r7)
            r4.append(r10)
            java.lang.String r7 = " cannot be found but it is necessary for "
            r4.append(r7)
            r4.append(r6)
            java.lang.String r6 = r15.mo940A()
            r4.append(r6)
            java.lang.String r4 = r4.toString()
            android.util.Log.e(r1, r4)
            goto L_0x017d
        L_0x014e:
            r10.mo1224s(r2)
            if (r11 == 0) goto L_0x0156
            r15.mo988g(r10)
        L_0x0156:
            if (r10 == r6) goto L_0x016c
            if (r12 == 0) goto L_0x015d
            r15.mo988g(r6)
        L_0x015d:
            r10.f935h = r6
            r15.mo988g(r10)
            androidx.recyclerview.widget.RecyclerView$s r7 = r15.f804e
            r7.mo1194m(r10)
            r6.mo1224s(r2)
            r6.f936i = r10
        L_0x016c:
            androidx.recyclerview.widget.RecyclerView$j r7 = r15.f790O
            boolean r4 = r7.mo1097a(r10, r6, r4, r9)
            if (r4 == 0) goto L_0x017d
            r15.mo962Y()
            goto L_0x017d
        L_0x0178:
            lb r4 = r15.f812i
            r4.mo4413b(r6, r9)
        L_0x017d:
            int r0 = r0 + -1
            r4 = 4
            goto L_0x0077
        L_0x0182:
            lb r0 = r15.f812i
            lb$b r1 = r15.f845y0
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r4 = r0.f3861a
            int r4 = r4.f2478f
        L_0x018a:
            int r4 = r4 + -1
            if (r4 < 0) goto L_0x0238
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r5 = r0.f3861a
            java.lang.Object r5 = r5.mo3278h(r4)
            r7 = r5
            androidx.recyclerview.widget.RecyclerView$z r7 = (androidx.recyclerview.widget.RecyclerView.C0181z) r7
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r5 = r0.f3861a
            java.lang.Object r5 = r5.mo3282j(r4)
            lb$a r5 = (p000.C1101lb.C1102a) r5
            int r6 = r5.f3864a
            r8 = r6 & 3
            r9 = 3
            if (r8 != r9) goto L_0x01a7
            goto L_0x01af
        L_0x01a7:
            r8 = r6 & 1
            if (r8 == 0) goto L_0x01c2
            androidx.recyclerview.widget.RecyclerView$j$c r6 = r5.f3865b
            if (r6 != 0) goto L_0x01bf
        L_0x01af:
            r6 = r1
            androidx.recyclerview.widget.RecyclerView$d r6 = (androidx.recyclerview.widget.RecyclerView.C0149d) r6
            androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
            androidx.recyclerview.widget.RecyclerView$m r8 = r6.f826p
            android.view.View r7 = r7.f928a
            androidx.recyclerview.widget.RecyclerView$s r6 = r6.f804e
            r8.mo1123K0(r7, r6)
            goto L_0x0233
        L_0x01bf:
            androidx.recyclerview.widget.RecyclerView$j$c r8 = r5.f3866c
            goto L_0x021e
        L_0x01c2:
            r8 = r6 & 14
            r9 = 14
            if (r8 != r9) goto L_0x01c9
            goto L_0x0229
        L_0x01c9:
            r8 = r6 & 12
            r9 = 12
            if (r8 != r9) goto L_0x0217
            androidx.recyclerview.widget.RecyclerView$j$c r6 = r5.f3865b
            androidx.recyclerview.widget.RecyclerView$j$c r8 = r5.f3866c
            r12 = r1
            androidx.recyclerview.widget.RecyclerView$d r12 = (androidx.recyclerview.widget.RecyclerView.C0149d) r12
            java.util.Objects.requireNonNull(r12)
            r7.mo1224s(r2)
            androidx.recyclerview.widget.RecyclerView r9 = androidx.recyclerview.widget.RecyclerView.this
            boolean r10 = r9.f781F
            androidx.recyclerview.widget.RecyclerView$j r9 = r9.f790O
            if (r10 == 0) goto L_0x01eb
            boolean r6 = r9.mo1097a(r7, r7, r6, r8)
            if (r6 == 0) goto L_0x0233
            goto L_0x0211
        L_0x01eb:
            jb r9 = (p000.C0956jb) r9
            java.util.Objects.requireNonNull(r9)
            int r10 = r6.f862a
            int r11 = r8.f862a
            if (r10 != r11) goto L_0x0202
            int r13 = r6.f863b
            int r14 = r8.f863b
            if (r13 == r14) goto L_0x01fd
            goto L_0x0202
        L_0x01fd:
            r9.mo1098c(r7)
            r6 = 0
            goto L_0x020f
        L_0x0202:
            int r13 = r6.f863b
            int r14 = r8.f863b
            r6 = r9
            r8 = r10
            r9 = r13
            r10 = r11
            r11 = r14
            boolean r6 = r6.mo4153i(r7, r8, r9, r10, r11)
        L_0x020f:
            if (r6 == 0) goto L_0x0233
        L_0x0211:
            androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
            r6.mo962Y()
            goto L_0x0233
        L_0x0217:
            r8 = r6 & 4
            if (r8 == 0) goto L_0x0225
            androidx.recyclerview.widget.RecyclerView$j$c r6 = r5.f3865b
            r8 = 0
        L_0x021e:
            r9 = r1
            androidx.recyclerview.widget.RecyclerView$d r9 = (androidx.recyclerview.widget.RecyclerView.C0149d) r9
            r9.mo1084b(r7, r6, r8)
            goto L_0x0233
        L_0x0225:
            r6 = r6 & 8
            if (r6 == 0) goto L_0x0233
        L_0x0229:
            androidx.recyclerview.widget.RecyclerView$j$c r6 = r5.f3865b
            androidx.recyclerview.widget.RecyclerView$j$c r8 = r5.f3866c
            r9 = r1
            androidx.recyclerview.widget.RecyclerView$d r9 = (androidx.recyclerview.widget.RecyclerView.C0149d) r9
            r9.mo1083a(r7, r6, r8)
        L_0x0233:
            p000.C1101lb.C1102a.m3490b(r5)
            goto L_0x018a
        L_0x0238:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            androidx.recyclerview.widget.RecyclerView$s r1 = r15.f804e
            r0.mo1121J0(r1)
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            int r1 = r0.f910d
            r0.f907a = r1
            r15.f781F = r2
            r15.f782G = r2
            r0.f915i = r2
            r0.f916j = r2
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            r0.f871g = r2
            androidx.recyclerview.widget.RecyclerView$s r0 = r15.f804e
            java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$z> r0 = r0.f898b
            if (r0 == 0) goto L_0x025a
            r0.clear()
        L_0x025a:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            boolean r1 = r0.f876l
            if (r1 == 0) goto L_0x0269
            r0.f875k = r2
            r0.f876l = r2
            androidx.recyclerview.widget.RecyclerView$s r0 = r15.f804e
            r0.mo1195n()
        L_0x0269:
            androidx.recyclerview.widget.RecyclerView$m r0 = r15.f826p
            androidx.recyclerview.widget.RecyclerView$w r1 = r15.f813i0
            r0.mo884y0(r1)
            r15.mo958U(r3)
            r15.mo1023m0(r2)
            lb r0 = r15.f812i
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r1 = r0.f3861a
            r1.clear()
            b4<androidx.recyclerview.widget.RecyclerView$z> r0 = r0.f3862b
            r0.mo1585b()
            int[] r0 = r15.f831r0
            r1 = r0[r2]
            r4 = r0[r3]
            r15.mo944E(r0)
            int[] r0 = r15.f831r0
            r5 = r0[r2]
            if (r5 != r1) goto L_0x0297
            r0 = r0[r3]
            if (r0 == r4) goto L_0x0296
            goto L_0x0297
        L_0x0296:
            r3 = 0
        L_0x0297:
            if (r3 == 0) goto L_0x029c
            r15.mo1075v(r2, r2)
        L_0x029c:
            boolean r0 = r15.f805e0
            r3 = -1
            if (r0 == 0) goto L_0x0347
            androidx.recyclerview.widget.RecyclerView$e r0 = r15.f824o
            if (r0 == 0) goto L_0x0347
            boolean r0 = r15.hasFocus()
            if (r0 == 0) goto L_0x0347
            int r0 = r15.getDescendantFocusability()
            r1 = 393216(0x60000, float:5.51013E-40)
            if (r0 == r1) goto L_0x0347
            int r0 = r15.getDescendantFocusability()
            r1 = 131072(0x20000, float:1.83671E-40)
            if (r0 != r1) goto L_0x02c4
            boolean r0 = r15.isFocused()
            if (r0 == 0) goto L_0x02c4
            goto L_0x0347
        L_0x02c4:
            boolean r0 = r15.isFocused()
            if (r0 != 0) goto L_0x02d8
            android.view.View r0 = r15.getFocusedChild()
            pa r1 = r15.f810h
            boolean r0 = r1.mo5212k(r0)
            if (r0 != 0) goto L_0x02d8
            goto L_0x0347
        L_0x02d8:
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            long r0 = r0.f918l
            int r5 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r5 == 0) goto L_0x02e5
            androidx.recyclerview.widget.RecyclerView$e r0 = r15.f824o
            java.util.Objects.requireNonNull(r0)
        L_0x02e5:
            pa r0 = r15.f810h
            int r0 = r0.mo5206e()
            if (r0 <= 0) goto L_0x032b
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            int r1 = r0.f917k
            r5 = -1
            if (r1 == r5) goto L_0x02f5
            r2 = r1
        L_0x02f5:
            int r0 = r0.mo1202b()
            r1 = r2
        L_0x02fa:
            if (r1 >= r0) goto L_0x0311
            androidx.recyclerview.widget.RecyclerView$z r5 = r15.mo945G(r1)
            if (r5 != 0) goto L_0x0303
            goto L_0x0311
        L_0x0303:
            android.view.View r6 = r5.f928a
            boolean r6 = r6.hasFocusable()
            if (r6 == 0) goto L_0x030e
            android.view.View r0 = r5.f928a
            goto L_0x032c
        L_0x030e:
            int r1 = r1 + 1
            goto L_0x02fa
        L_0x0311:
            int r0 = java.lang.Math.min(r0, r2)
        L_0x0315:
            int r0 = r0 + -1
            if (r0 < 0) goto L_0x032b
            androidx.recyclerview.widget.RecyclerView$z r1 = r15.mo945G(r0)
            if (r1 != 0) goto L_0x0320
            goto L_0x032b
        L_0x0320:
            android.view.View r2 = r1.f928a
            boolean r2 = r2.hasFocusable()
            if (r2 == 0) goto L_0x0315
            android.view.View r0 = r1.f928a
            goto L_0x032c
        L_0x032b:
            r0 = 0
        L_0x032c:
            if (r0 == 0) goto L_0x0347
            androidx.recyclerview.widget.RecyclerView$w r1 = r15.f813i0
            int r1 = r1.f919m
            long r5 = (long) r1
            int r2 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
            if (r2 == 0) goto L_0x0344
            android.view.View r1 = r0.findViewById(r1)
            if (r1 == 0) goto L_0x0344
            boolean r2 = r1.isFocusable()
            if (r2 == 0) goto L_0x0344
            r0 = r1
        L_0x0344:
            r0.requestFocus()
        L_0x0347:
            androidx.recyclerview.widget.RecyclerView$w r0 = r15.f813i0
            r0.f918l = r3
            r1 = -1
            r0.f917k = r1
            r0.f919m = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.mo1040q():void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0094  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00a1 A[EDGE_INSN: B:95:0x00a1->B:35:0x00a1 ?: BREAK  
    EDGE_INSN: B:96:0x00a1->B:35:0x00a1 ?: BREAK  
    EDGE_INSN: B:97:0x00a1->B:35:0x00a1 ?: BREAK  ] */
    /* renamed from: r */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1041r() {
        /*
            r10 = this;
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r1 = 1
            r0.mo1201a(r1)
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r10.mo941B(r0)
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r2 = 0
            r0.f914h = r2
            r10.mo1019k0()
            lb r0 = r10.f812i
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r3 = r0.f3861a
            r3.clear()
            b4<androidx.recyclerview.widget.RecyclerView$z> r0 = r0.f3862b
            r0.mo1585b()
            r10.mo957T()
            r10.mo963Z()
            boolean r0 = r10.f805e0
            r3 = 0
            if (r0 == 0) goto L_0x0039
            boolean r0 = r10.hasFocus()
            if (r0 == 0) goto L_0x0039
            androidx.recyclerview.widget.RecyclerView$e r0 = r10.f824o
            if (r0 == 0) goto L_0x0039
            android.view.View r0 = r10.getFocusedChild()
            goto L_0x003a
        L_0x0039:
            r0 = r3
        L_0x003a:
            if (r0 != 0) goto L_0x003d
            goto L_0x0043
        L_0x003d:
            android.view.View r0 = r10.mo942C(r0)
            if (r0 != 0) goto L_0x0045
        L_0x0043:
            r0 = r3
            goto L_0x0049
        L_0x0045:
            androidx.recyclerview.widget.RecyclerView$z r0 = r10.mo948J(r0)
        L_0x0049:
            r4 = -1
            r6 = -1
            if (r0 != 0) goto L_0x0057
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r0.f918l = r4
            r0.f917k = r6
            r0.f919m = r6
            goto L_0x00a3
        L_0x0057:
            androidx.recyclerview.widget.RecyclerView$w r7 = r10.f813i0
            androidx.recyclerview.widget.RecyclerView$e r8 = r10.f824o
            java.util.Objects.requireNonNull(r8)
            r7.f918l = r4
            androidx.recyclerview.widget.RecyclerView$w r4 = r10.f813i0
            boolean r5 = r10.f781F
            if (r5 == 0) goto L_0x0067
            goto L_0x0074
        L_0x0067:
            boolean r5 = r0.mo1217l()
            if (r5 == 0) goto L_0x0070
            int r5 = r0.f931d
            goto L_0x007a
        L_0x0070:
            androidx.recyclerview.widget.RecyclerView r5 = r0.f945r
            if (r5 != 0) goto L_0x0076
        L_0x0074:
            r5 = -1
            goto L_0x007a
        L_0x0076:
            int r5 = r5.mo946H(r0)
        L_0x007a:
            r4.f917k = r5
            androidx.recyclerview.widget.RecyclerView$w r4 = r10.f813i0
            android.view.View r0 = r0.f928a
        L_0x0080:
            int r5 = r0.getId()
        L_0x0084:
            boolean r7 = r0.isFocused()
            if (r7 != 0) goto L_0x00a1
            boolean r7 = r0 instanceof android.view.ViewGroup
            if (r7 == 0) goto L_0x00a1
            boolean r7 = r0.hasFocus()
            if (r7 == 0) goto L_0x00a1
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            android.view.View r0 = r0.getFocusedChild()
            int r7 = r0.getId()
            if (r7 == r6) goto L_0x0084
            goto L_0x0080
        L_0x00a1:
            r4.f919m = r5
        L_0x00a3:
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            boolean r4 = r0.f915i
            if (r4 == 0) goto L_0x00af
            boolean r4 = r10.f821m0
            if (r4 == 0) goto L_0x00af
            r4 = 1
            goto L_0x00b0
        L_0x00af:
            r4 = 0
        L_0x00b0:
            r0.f913g = r4
            r10.f821m0 = r2
            r10.f819l0 = r2
            boolean r4 = r0.f916j
            r0.f912f = r4
            androidx.recyclerview.widget.RecyclerView$e r4 = r10.f824o
            int r4 = r4.mo1085a()
            r0.f910d = r4
            int[] r0 = r10.f831r0
            r10.mo944E(r0)
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            boolean r0 = r0.f915i
            if (r0 == 0) goto L_0x0133
            pa r0 = r10.f810h
            int r0 = r0.mo5206e()
            r4 = 0
        L_0x00d4:
            if (r4 >= r0) goto L_0x0133
            pa r5 = r10.f810h
            android.view.View r5 = r5.mo5205d(r4)
            androidx.recyclerview.widget.RecyclerView$z r5 = m512K(r5)
            boolean r7 = r5.mo1225t()
            if (r7 != 0) goto L_0x0130
            boolean r7 = r5.mo1215j()
            if (r7 == 0) goto L_0x00f2
            androidx.recyclerview.widget.RecyclerView$e r5 = r10.f824o
            java.util.Objects.requireNonNull(r5)
            goto L_0x0130
        L_0x00f2:
            androidx.recyclerview.widget.RecyclerView$j r7 = r10.f790O
            androidx.recyclerview.widget.RecyclerView.C0156j.m590b(r5)
            r5.mo1211f()
            androidx.recyclerview.widget.RecyclerView$j$c r7 = r7.mo1103h(r5)
            lb r8 = r10.f812i
            r8.mo4414c(r5, r7)
            androidx.recyclerview.widget.RecyclerView$w r7 = r10.f813i0
            boolean r7 = r7.f913g
            if (r7 == 0) goto L_0x0130
            boolean r7 = r5.mo1220o()
            if (r7 == 0) goto L_0x0130
            boolean r7 = r5.mo1217l()
            if (r7 != 0) goto L_0x0130
            boolean r7 = r5.mo1225t()
            if (r7 != 0) goto L_0x0130
            boolean r7 = r5.mo1215j()
            if (r7 != 0) goto L_0x0130
            androidx.recyclerview.widget.RecyclerView$e r7 = r10.f824o
            java.util.Objects.requireNonNull(r7)
            int r7 = r5.f930c
            long r7 = (long) r7
            lb r9 = r10.f812i
            b4<androidx.recyclerview.widget.RecyclerView$z> r9 = r9.f3862b
            r9.mo1591g(r7, r5)
        L_0x0130:
            int r4 = r4 + 1
            goto L_0x00d4
        L_0x0133:
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            boolean r0 = r0.f916j
            r4 = 2
            if (r0 == 0) goto L_0x01d7
            pa r0 = r10.f810h
            int r0 = r0.mo5209h()
            r5 = 0
        L_0x0141:
            if (r5 >= r0) goto L_0x015e
            pa r7 = r10.f810h
            android.view.View r7 = r7.mo5208g(r5)
            androidx.recyclerview.widget.RecyclerView$z r7 = m512K(r7)
            boolean r8 = r7.mo1225t()
            if (r8 != 0) goto L_0x015b
            int r8 = r7.f931d
            if (r8 != r6) goto L_0x015b
            int r8 = r7.f930c
            r7.f931d = r8
        L_0x015b:
            int r5 = r5 + 1
            goto L_0x0141
        L_0x015e:
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            boolean r5 = r0.f911e
            r0.f911e = r2
            androidx.recyclerview.widget.RecyclerView$m r6 = r10.f826p
            androidx.recyclerview.widget.RecyclerView$s r7 = r10.f804e
            r6.mo883x0(r7, r0)
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r0.f911e = r5
            r0 = 0
        L_0x0170:
            pa r5 = r10.f810h
            int r5 = r5.mo5206e()
            if (r0 >= r5) goto L_0x01d7
            pa r5 = r10.f810h
            android.view.View r5 = r5.mo5205d(r0)
            androidx.recyclerview.widget.RecyclerView$z r5 = m512K(r5)
            boolean r6 = r5.mo1225t()
            if (r6 == 0) goto L_0x0189
            goto L_0x01d4
        L_0x0189:
            lb r6 = r10.f812i
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r6 = r6.f3861a
            java.lang.Object r6 = r6.getOrDefault(r5, r3)
            lb$a r6 = (p000.C1101lb.C1102a) r6
            if (r6 == 0) goto L_0x019d
            int r6 = r6.f3864a
            r6 = r6 & 4
            if (r6 == 0) goto L_0x019d
            r6 = 1
            goto L_0x019e
        L_0x019d:
            r6 = 0
        L_0x019e:
            if (r6 != 0) goto L_0x01d4
            androidx.recyclerview.widget.RecyclerView.C0156j.m590b(r5)
            r6 = 8192(0x2000, float:1.14794E-41)
            boolean r6 = r5.mo1212g(r6)
            androidx.recyclerview.widget.RecyclerView$j r7 = r10.f790O
            r5.mo1211f()
            androidx.recyclerview.widget.RecyclerView$j$c r7 = r7.mo1103h(r5)
            if (r6 == 0) goto L_0x01b8
            r10.mo966b0(r5, r7)
            goto L_0x01d4
        L_0x01b8:
            lb r6 = r10.f812i
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r8 = r6.f3861a
            java.lang.Object r8 = r8.getOrDefault(r5, r3)
            lb$a r8 = (p000.C1101lb.C1102a) r8
            if (r8 != 0) goto L_0x01cd
            lb$a r8 = p000.C1101lb.C1102a.m3489a()
            e4<androidx.recyclerview.widget.RecyclerView$z, lb$a> r6 = r6.f3861a
            r6.put(r5, r8)
        L_0x01cd:
            int r5 = r8.f3864a
            r5 = r5 | r4
            r8.f3864a = r5
            r8.f3865b = r7
        L_0x01d4:
            int r0 = r0 + 1
            goto L_0x0170
        L_0x01d7:
            r10.mo1020l()
            r10.mo958U(r1)
            r10.mo1023m0(r2)
            androidx.recyclerview.widget.RecyclerView$w r0 = r10.f813i0
            r0.f909c = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.mo1041r():void");
    }

    public void removeDetachedView(View view, boolean z) {
        C0181z K = m512K(view);
        if (K != null) {
            if (K.mo1219n()) {
                K.f937j &= -257;
            } else if (!K.mo1225t()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(K);
                throw new IllegalArgumentException(C1012kd.m3197f(this, sb));
            }
        }
        view.clearAnimation();
        mo1039p(view);
        super.removeDetachedView(view, z);
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f826p.mo1107B0(this, view, view2) && view2 != null) {
            mo975d0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.f826p.mo1127M0(this, view, rect, z, false);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.f832s.size();
        for (int i = 0; i < size; i++) {
            this.f832s.get(i).mo1178c(z);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        if (this.f844y != 0 || this.f776A) {
            this.f846z = true;
        } else {
            super.requestLayout();
        }
    }

    /* renamed from: s */
    public final void mo1047s() {
        mo1019k0();
        mo957T();
        this.f813i0.mo1201a(6);
        this.f808g.mo5026c();
        this.f813i0.f910d = this.f824o.mo1085a();
        this.f813i0.f908b = 0;
        if (this.f806f != null) {
            C0150e eVar = this.f824o;
            int ordinal = eVar.f851b.ordinal();
            if (ordinal == 1 ? eVar.mo1085a() > 0 : ordinal != 2) {
                Parcelable parcelable = this.f806f.f906f;
                if (parcelable != null) {
                    this.f826p.mo887C0(parcelable);
                }
                this.f806f = null;
            }
        }
        C0178w wVar = this.f813i0;
        wVar.f912f = false;
        this.f826p.mo883x0(this.f804e, wVar);
        C0178w wVar2 = this.f813i0;
        wVar2.f911e = false;
        wVar2.f915i = wVar2.f915i && this.f790O != null;
        wVar2.f909c = 4;
        mo958U(true);
        mo1023m0(false);
    }

    public void scrollBy(int i, int i2) {
        C0162m mVar = this.f826p;
        if (mVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f776A) {
            boolean e = mVar.mo899e();
            boolean f = this.f826p.mo901f();
            if (e || f) {
                if (!e) {
                    i = 0;
                }
                if (!f) {
                    i2 = 0;
                }
                mo986f0(i, i2, (MotionEvent) null);
            }
        }
    }

    public void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        int i = 0;
        if (mo952O()) {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            if (contentChangeTypes != 0) {
                i = contentChangeTypes;
            }
            this.f778C |= i;
            i = 1;
        }
        if (i == 0) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        }
    }

    public void setAccessibilityDelegateCompat(C0882ib ibVar) {
        this.f827p0 = ibVar;
        C0010a7.m43p(this, ibVar);
    }

    public void setAdapter(C0150e eVar) {
        setLayoutFrozen(false);
        C0150e eVar2 = this.f824o;
        if (eVar2 != null) {
            eVar2.f850a.unregisterObserver(this.f802d);
            Objects.requireNonNull(this.f824o);
        }
        mo967c0();
        C1321oa oaVar = this.f808g;
        oaVar.mo5035l(oaVar.f4483b);
        oaVar.mo5035l(oaVar.f4484c);
        oaVar.f4487f = 0;
        C0150e eVar3 = this.f824o;
        this.f824o = eVar;
        if (eVar != null) {
            eVar.f850a.registerObserver(this.f802d);
        }
        C0162m mVar = this.f826p;
        if (mVar != null) {
            mVar.mo1153g0(eVar3, this.f824o);
        }
        C0173s sVar = this.f804e;
        C0150e eVar4 = this.f824o;
        sVar.mo1183b();
        C0171r d = sVar.mo1185d();
        Objects.requireNonNull(d);
        if (eVar3 != null) {
            d.f892b--;
        }
        if (d.f892b == 0) {
            for (int i = 0; i < d.f891a.size(); i++) {
                d.f891a.valueAt(i).f893a.clear();
            }
        }
        if (eVar4 != null) {
            d.f892b++;
        }
        this.f813i0.f911e = true;
        mo964a0(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(C0154h hVar) {
        if (hVar != this.f829q0) {
            this.f829q0 = hVar;
            setChildrenDrawingOrderEnabled(hVar != null);
        }
    }

    public void setClipToPadding(boolean z) {
        if (z != this.f814j) {
            mo951N();
        }
        this.f814j = z;
        super.setClipToPadding(z);
        if (this.f842x) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(C0155i iVar) {
        Objects.requireNonNull(iVar);
        this.f785J = iVar;
        mo951N();
    }

    public void setHasFixedSize(boolean z) {
        this.f838v = z;
    }

    public void setItemAnimator(C0156j jVar) {
        C0156j jVar2 = this.f790O;
        if (jVar2 != null) {
            jVar2.mo1101f();
            this.f790O.f856a = null;
        }
        this.f790O = jVar;
        if (jVar != null) {
            jVar.f856a = this.f823n0;
        }
    }

    public void setItemViewCacheSize(int i) {
        C0173s sVar = this.f804e;
        sVar.f901e = i;
        sVar.mo1195n();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z) {
        suppressLayout(z);
    }

    public void setLayoutManager(C0162m mVar) {
        if (mVar != this.f826p) {
            mo1025n0();
            if (this.f826p != null) {
                C0156j jVar = this.f790O;
                if (jVar != null) {
                    jVar.mo1101f();
                }
                this.f826p.mo1119I0(this.f804e);
                this.f826p.mo1121J0(this.f804e);
                this.f804e.mo1183b();
                if (this.f836u) {
                    C0162m mVar2 = this.f826p;
                    C0173s sVar = this.f804e;
                    mVar2.f872h = false;
                    mVar2.mo910k0(this, sVar);
                }
                this.f826p.mo1139V0((RecyclerView) null);
                this.f826p = null;
            } else {
                this.f804e.mo1183b();
            }
            C1412pa paVar = this.f810h;
            C1412pa.C1413a aVar = paVar.f4814b;
            aVar.f4816a = 0;
            C1412pa.C1413a aVar2 = aVar.f4817b;
            if (aVar2 != null) {
                aVar2.mo5222g();
            }
            int size = paVar.f4815c.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                }
                C0742gb gbVar = (C0742gb) paVar.f4813a;
                Objects.requireNonNull(gbVar);
                C0181z K = m512K(paVar.f4815c.get(size));
                if (K != null) {
                    gbVar.f2853a.mo1014i0(K, K.f943p);
                    K.f943p = 0;
                }
                paVar.f4815c.remove(size);
            }
            C0742gb gbVar2 = (C0742gb) paVar.f4813a;
            int b = gbVar2.mo3769b();
            for (int i = 0; i < b; i++) {
                View a = gbVar2.mo3768a(i);
                gbVar2.f2853a.mo1039p(a);
                a.clearAnimation();
            }
            gbVar2.f2853a.removeAllViews();
            this.f826p = mVar;
            if (mVar != null) {
                if (mVar.f866b == null) {
                    mVar.mo1139V0(this);
                    if (this.f836u) {
                        C0162m mVar3 = this.f826p;
                        mVar3.f872h = true;
                        mVar3.mo1155i0(this);
                    }
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("LayoutManager ");
                    sb.append(mVar);
                    sb.append(" is already attached to a RecyclerView:");
                    throw new IllegalArgumentException(C1012kd.m3197f(mVar.f866b, sb));
                }
            }
            this.f804e.mo1195n();
            requestLayout();
        }
    }

    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition((LayoutTransition) null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    public void setNestedScrollingEnabled(boolean z) {
        getScrollingChildHelper().mo5817i(z);
    }

    public void setOnFlingListener(C0168o oVar) {
    }

    @Deprecated
    public void setOnScrollListener(C0170q qVar) {
        this.f815j0 = qVar;
    }

    public void setPreserveFocusAfterLayout(boolean z) {
        this.f805e0 = z;
    }

    public void setRecycledViewPool(C0171r rVar) {
        C0173s sVar = this.f804e;
        C0171r rVar2 = sVar.f903g;
        if (rVar2 != null) {
            rVar2.f892b--;
        }
        sVar.f903g = rVar;
        if (rVar != null && RecyclerView.this.getAdapter() != null) {
            sVar.f903g.f892b++;
        }
    }

    public void setRecyclerListener(C0174t tVar) {
        this.f828q = tVar;
    }

    public void setScrollState(int i) {
        if (i != this.f791P) {
            this.f791P = i;
            if (i != 2) {
                C0180y yVar = this.f807f0;
                RecyclerView.this.removeCallbacks(yVar);
                yVar.f922f.abortAnimation();
            }
            C0162m mVar = this.f826p;
            if (mVar != null) {
                mVar.mo1111E0(i);
            }
            mo960W();
            List<C0170q> list = this.f817k0;
            if (list != null) {
                int size = list.size();
                while (true) {
                    size--;
                    if (size >= 0) {
                        Objects.requireNonNull(this.f817k0.get(size));
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public void setScrollingTouchSlop(int i) {
        int i2;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i != 0) {
            if (i != 1) {
                Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i + "; using default value");
            } else {
                i2 = viewConfiguration.getScaledPagingTouchSlop();
                this.f798W = i2;
            }
        }
        i2 = viewConfiguration.getScaledTouchSlop();
        this.f798W = i2;
    }

    public void setViewCacheExtension(C0179x xVar) {
        Objects.requireNonNull(this.f804e);
    }

    public boolean startNestedScroll(int i) {
        return getScrollingChildHelper().mo5818j(i, 0);
    }

    public void stopNestedScroll() {
        getScrollingChildHelper().mo5819k(0);
    }

    public final void suppressLayout(boolean z) {
        if (z != this.f776A) {
            mo1013i("Do not suppressLayout in layout or scroll");
            if (!z) {
                this.f776A = false;
                if (!(!this.f846z || this.f826p == null || this.f824o == null)) {
                    requestLayout();
                }
                this.f846z = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f776A = true;
            this.f777B = true;
            mo1025n0();
        }
    }

    /* renamed from: t */
    public boolean mo1073t(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return getScrollingChildHelper().mo5811c(i, i2, iArr, (int[]) null, i3);
    }

    /* renamed from: u */
    public final void mo1074u(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        getScrollingChildHelper().mo5814f(i, i2, i3, i4, iArr, i5, iArr2);
    }

    /* renamed from: v */
    public void mo1075v(int i, int i2) {
        this.f784I++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        mo961X();
        C0170q qVar = this.f815j0;
        if (qVar != null) {
            qVar.mo1179a(this, i, i2);
        }
        List<C0170q> list = this.f817k0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f817k0.get(size).mo1179a(this, i, i2);
            }
        }
        this.f784I--;
    }

    /* renamed from: w */
    public void mo1076w() {
        int i;
        int i2;
        if (this.f789N == null) {
            EdgeEffect a = this.f785J.mo1096a(this);
            this.f789N = a;
            if (this.f814j) {
                i2 = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                i = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                i2 = getMeasuredWidth();
                i = getMeasuredHeight();
            }
            a.setSize(i2, i);
        }
    }

    /* renamed from: x */
    public void mo1077x() {
        int i;
        int i2;
        if (this.f786K == null) {
            EdgeEffect a = this.f785J.mo1096a(this);
            this.f786K = a;
            if (this.f814j) {
                i2 = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                i = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                i2 = getMeasuredHeight();
                i = getMeasuredWidth();
            }
            a.setSize(i2, i);
        }
    }

    /* renamed from: y */
    public void mo1078y() {
        int i;
        int i2;
        if (this.f788M == null) {
            EdgeEffect a = this.f785J.mo1096a(this);
            this.f788M = a;
            if (this.f814j) {
                i2 = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                i = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                i2 = getMeasuredHeight();
                i = getMeasuredWidth();
            }
            a.setSize(i2, i);
        }
    }

    /* renamed from: z */
    public void mo1079z() {
        int i;
        int i2;
        if (this.f787L == null) {
            EdgeEffect a = this.f785J.mo1096a(this);
            this.f787L = a;
            if (this.f814j) {
                i2 = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                i = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                i2 = getMeasuredWidth();
                i = getMeasuredHeight();
            }
            a.setSize(i2, i);
        }
    }
}
