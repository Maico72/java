package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;
import p000.C0021ab;

public class StaggeredGridLayoutManager extends RecyclerView.C0162m {

    /* renamed from: A */
    public int f947A;

    /* renamed from: B */
    public int f948B;

    /* renamed from: C */
    public C0185d f949C;

    /* renamed from: D */
    public int f950D;

    /* renamed from: E */
    public boolean f951E;

    /* renamed from: F */
    public boolean f952F;

    /* renamed from: G */
    public C0188e f953G;

    /* renamed from: H */
    public int f954H;

    /* renamed from: I */
    public final Rect f955I;

    /* renamed from: J */
    public final C0183b f956J;

    /* renamed from: K */
    public boolean f957K;

    /* renamed from: L */
    public int[] f958L;

    /* renamed from: M */
    public final Runnable f959M;

    /* renamed from: q */
    public int f960q = -1;

    /* renamed from: r */
    public C0190f[] f961r;

    /* renamed from: s */
    public C0682fb f962s;

    /* renamed from: t */
    public C0682fb f963t;

    /* renamed from: u */
    public int f964u;

    /* renamed from: v */
    public int f965v;

    /* renamed from: w */
    public final C0274bb f966w;

    /* renamed from: x */
    public boolean f967x;

    /* renamed from: y */
    public boolean f968y;

    /* renamed from: z */
    public BitSet f969z;

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$a */
    public class C0182a implements Runnable {
        public C0182a() {
        }

        public void run() {
            StaggeredGridLayoutManager.this.mo1232a1();
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$b */
    public class C0183b {

        /* renamed from: a */
        public int f971a;

        /* renamed from: b */
        public int f972b;

        /* renamed from: c */
        public boolean f973c;

        /* renamed from: d */
        public boolean f974d;

        /* renamed from: e */
        public boolean f975e;

        /* renamed from: f */
        public int[] f976f;

        public C0183b() {
            mo1260b();
        }

        /* renamed from: a */
        public void mo1259a() {
            this.f972b = this.f973c ? StaggeredGridLayoutManager.this.f962s.mo2976g() : StaggeredGridLayoutManager.this.f962s.mo2980k();
        }

        /* renamed from: b */
        public void mo1260b() {
            this.f971a = -1;
            this.f972b = Integer.MIN_VALUE;
            this.f973c = false;
            this.f974d = false;
            this.f975e = false;
            int[] iArr = this.f976f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$c */
    public static class C0184c extends RecyclerView.C0167n {

        /* renamed from: h */
        public C0190f f978h;

        public C0184c(int i, int i2) {
            super(i, i2);
        }

        public C0184c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0184c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0184c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d */
    public static class C0185d {

        /* renamed from: a */
        public int[] f979a;

        /* renamed from: b */
        public List<C0186a> f980b;

        @SuppressLint({"BanParcelableUsage"})
        /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a */
        public static class C0186a implements Parcelable {
            public static final Parcelable.Creator<C0186a> CREATOR = new C0187a();

            /* renamed from: d */
            public int f981d;

            /* renamed from: e */
            public int f982e;

            /* renamed from: f */
            public int[] f983f;

            /* renamed from: g */
            public boolean f984g;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a */
            public class C0187a implements Parcelable.Creator<C0186a> {
                public Object createFromParcel(Parcel parcel) {
                    return new C0186a(parcel);
                }

                public Object[] newArray(int i) {
                    return new C0186a[i];
                }
            }

            public C0186a() {
            }

            public C0186a(Parcel parcel) {
                this.f981d = parcel.readInt();
                this.f982e = parcel.readInt();
                this.f984g = parcel.readInt() != 1 ? false : true;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.f983f = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder d = C1012kd.m3195d("FullSpanItem{mPosition=");
                d.append(this.f981d);
                d.append(", mGapDir=");
                d.append(this.f982e);
                d.append(", mHasUnwantedGapAfter=");
                d.append(this.f984g);
                d.append(", mGapPerSpan=");
                d.append(Arrays.toString(this.f983f));
                d.append('}');
                return d.toString();
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.f981d);
                parcel.writeInt(this.f982e);
                parcel.writeInt(this.f984g ? 1 : 0);
                int[] iArr = this.f983f;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                    return;
                }
                parcel.writeInt(iArr.length);
                parcel.writeIntArray(this.f983f);
            }
        }

        /* renamed from: a */
        public void mo1261a() {
            int[] iArr = this.f979a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f980b = null;
        }

        /* renamed from: b */
        public void mo1262b(int i) {
            int[] iArr = this.f979a;
            if (iArr == null) {
                int[] iArr2 = new int[(Math.max(i, 10) + 1)];
                this.f979a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i >= iArr.length) {
                int length = iArr.length;
                while (length <= i) {
                    length *= 2;
                }
                int[] iArr3 = new int[length];
                this.f979a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.f979a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        /* renamed from: c */
        public C0186a mo1263c(int i) {
            List<C0186a> list = this.f980b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                C0186a aVar = this.f980b.get(size);
                if (aVar.f981d == i) {
                    return aVar;
                }
            }
            return null;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0048  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0052  */
        /* renamed from: d */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo1264d(int r5) {
            /*
                r4 = this;
                int[] r0 = r4.f979a
                r1 = -1
                if (r0 != 0) goto L_0x0006
                return r1
            L_0x0006:
                int r0 = r0.length
                if (r5 < r0) goto L_0x000a
                return r1
            L_0x000a:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f980b
                if (r0 != 0) goto L_0x0010
            L_0x000e:
                r0 = -1
                goto L_0x0046
            L_0x0010:
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = r4.mo1263c(r5)
                if (r0 == 0) goto L_0x001b
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r2 = r4.f980b
                r2.remove(r0)
            L_0x001b:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f980b
                int r0 = r0.size()
                r2 = 0
            L_0x0022:
                if (r2 >= r0) goto L_0x0034
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f980b
                java.lang.Object r3 = r3.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r3 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0185d.C0186a) r3
                int r3 = r3.f981d
                if (r3 < r5) goto L_0x0031
                goto L_0x0035
            L_0x0031:
                int r2 = r2 + 1
                goto L_0x0022
            L_0x0034:
                r2 = -1
            L_0x0035:
                if (r2 == r1) goto L_0x000e
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f980b
                java.lang.Object r0 = r0.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0185d.C0186a) r0
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f980b
                r3.remove(r2)
                int r0 = r0.f981d
            L_0x0046:
                if (r0 != r1) goto L_0x0052
                int[] r0 = r4.f979a
                int r2 = r0.length
                java.util.Arrays.fill(r0, r5, r2, r1)
                int[] r5 = r4.f979a
                int r5 = r5.length
                return r5
            L_0x0052:
                int[] r2 = r4.f979a
                int r0 = r0 + 1
                java.util.Arrays.fill(r2, r5, r0, r1)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.C0185d.mo1264d(int):int");
        }

        /* renamed from: e */
        public void mo1265e(int i, int i2) {
            int[] iArr = this.f979a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                mo1262b(i3);
                int[] iArr2 = this.f979a;
                System.arraycopy(iArr2, i, iArr2, i3, (iArr2.length - i) - i2);
                Arrays.fill(this.f979a, i, i3, -1);
                List<C0186a> list = this.f980b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        C0186a aVar = this.f980b.get(size);
                        int i4 = aVar.f981d;
                        if (i4 >= i) {
                            aVar.f981d = i4 + i2;
                        }
                    }
                }
            }
        }

        /* renamed from: f */
        public void mo1266f(int i, int i2) {
            int[] iArr = this.f979a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                mo1262b(i3);
                int[] iArr2 = this.f979a;
                System.arraycopy(iArr2, i3, iArr2, i, (iArr2.length - i) - i2);
                int[] iArr3 = this.f979a;
                Arrays.fill(iArr3, iArr3.length - i2, iArr3.length, -1);
                List<C0186a> list = this.f980b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        C0186a aVar = this.f980b.get(size);
                        int i4 = aVar.f981d;
                        if (i4 >= i) {
                            if (i4 < i3) {
                                this.f980b.remove(size);
                            } else {
                                aVar.f981d = i4 - i2;
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$e */
    public static class C0188e implements Parcelable {
        public static final Parcelable.Creator<C0188e> CREATOR = new C0189a();

        /* renamed from: d */
        public int f985d;

        /* renamed from: e */
        public int f986e;

        /* renamed from: f */
        public int f987f;

        /* renamed from: g */
        public int[] f988g;

        /* renamed from: h */
        public int f989h;

        /* renamed from: i */
        public int[] f990i;

        /* renamed from: j */
        public List<C0185d.C0186a> f991j;

        /* renamed from: k */
        public boolean f992k;

        /* renamed from: l */
        public boolean f993l;

        /* renamed from: m */
        public boolean f994m;

        /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$e$a */
        public class C0189a implements Parcelable.Creator<C0188e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0188e(parcel);
            }

            public Object[] newArray(int i) {
                return new C0188e[i];
            }
        }

        public C0188e() {
        }

        public C0188e(Parcel parcel) {
            this.f985d = parcel.readInt();
            this.f986e = parcel.readInt();
            int readInt = parcel.readInt();
            this.f987f = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.f988g = iArr;
                parcel.readIntArray(iArr);
            }
            int readInt2 = parcel.readInt();
            this.f989h = readInt2;
            if (readInt2 > 0) {
                int[] iArr2 = new int[readInt2];
                this.f990i = iArr2;
                parcel.readIntArray(iArr2);
            }
            boolean z = false;
            this.f992k = parcel.readInt() == 1;
            this.f993l = parcel.readInt() == 1;
            this.f994m = parcel.readInt() == 1 ? true : z;
            this.f991j = parcel.readArrayList(C0185d.C0186a.class.getClassLoader());
        }

        public C0188e(C0188e eVar) {
            this.f987f = eVar.f987f;
            this.f985d = eVar.f985d;
            this.f986e = eVar.f986e;
            this.f988g = eVar.f988g;
            this.f989h = eVar.f989h;
            this.f990i = eVar.f990i;
            this.f992k = eVar.f992k;
            this.f993l = eVar.f993l;
            this.f994m = eVar.f994m;
            this.f991j = eVar.f991j;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f985d);
            parcel.writeInt(this.f986e);
            parcel.writeInt(this.f987f);
            if (this.f987f > 0) {
                parcel.writeIntArray(this.f988g);
            }
            parcel.writeInt(this.f989h);
            if (this.f989h > 0) {
                parcel.writeIntArray(this.f990i);
            }
            parcel.writeInt(this.f992k ? 1 : 0);
            parcel.writeInt(this.f993l ? 1 : 0);
            parcel.writeInt(this.f994m ? 1 : 0);
            parcel.writeList(this.f991j);
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$f */
    public class C0190f {

        /* renamed from: a */
        public ArrayList<View> f995a = new ArrayList<>();

        /* renamed from: b */
        public int f996b = Integer.MIN_VALUE;

        /* renamed from: c */
        public int f997c = Integer.MIN_VALUE;

        /* renamed from: d */
        public int f998d = 0;

        /* renamed from: e */
        public final int f999e;

        public C0190f(int i) {
            this.f999e = i;
        }

        /* renamed from: a */
        public void mo1276a(View view) {
            C0184c j = mo1285j(view);
            j.f978h = this;
            this.f995a.add(view);
            this.f997c = Integer.MIN_VALUE;
            if (this.f995a.size() == 1) {
                this.f996b = Integer.MIN_VALUE;
            }
            if (j.mo1175t() || j.mo1174s()) {
                this.f998d = StaggeredGridLayoutManager.this.f962s.mo2972c(view) + this.f998d;
            }
        }

        /* renamed from: b */
        public void mo1277b() {
            ArrayList<View> arrayList = this.f995a;
            View view = arrayList.get(arrayList.size() - 1);
            C0184c j = mo1285j(view);
            this.f997c = StaggeredGridLayoutManager.this.f962s.mo2971b(view);
            Objects.requireNonNull(j);
        }

        /* renamed from: c */
        public void mo1278c() {
            View view = this.f995a.get(0);
            C0184c j = mo1285j(view);
            this.f996b = StaggeredGridLayoutManager.this.f962s.mo2974e(view);
            Objects.requireNonNull(j);
        }

        /* renamed from: d */
        public void mo1279d() {
            this.f995a.clear();
            this.f996b = Integer.MIN_VALUE;
            this.f997c = Integer.MIN_VALUE;
            this.f998d = 0;
        }

        /* renamed from: e */
        public int mo1280e() {
            int i;
            int i2;
            if (StaggeredGridLayoutManager.this.f967x) {
                i2 = this.f995a.size() - 1;
                i = -1;
            } else {
                i2 = 0;
                i = this.f995a.size();
            }
            return mo1282g(i2, i, true);
        }

        /* renamed from: f */
        public int mo1281f() {
            int i;
            int i2;
            if (StaggeredGridLayoutManager.this.f967x) {
                i2 = 0;
                i = this.f995a.size();
            } else {
                i2 = this.f995a.size() - 1;
                i = -1;
            }
            return mo1282g(i2, i, true);
        }

        /* renamed from: g */
        public int mo1282g(int i, int i2, boolean z) {
            int k = StaggeredGridLayoutManager.this.f962s.mo2980k();
            int g = StaggeredGridLayoutManager.this.f962s.mo2976g();
            int i3 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = this.f995a.get(i);
                int e = StaggeredGridLayoutManager.this.f962s.mo2974e(view);
                int b = StaggeredGridLayoutManager.this.f962s.mo2971b(view);
                boolean z2 = false;
                boolean z3 = !z ? e < g : e <= g;
                if (!z ? b > k : b >= k) {
                    z2 = true;
                }
                if (z3 && z2 && (e < k || b > g)) {
                    return StaggeredGridLayoutManager.this.mo1135S(view);
                }
                i += i3;
            }
            return -1;
        }

        /* renamed from: h */
        public int mo1283h(int i) {
            int i2 = this.f997c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f995a.size() == 0) {
                return i;
            }
            mo1277b();
            return this.f997c;
        }

        /* renamed from: i */
        public View mo1284i(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.f995a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f995a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.f967x && staggeredGridLayoutManager.mo1135S(view2) >= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.f967x && staggeredGridLayoutManager2.mo1135S(view2) <= i) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f995a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = this.f995a.get(i3);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.f967x && staggeredGridLayoutManager3.mo1135S(view3) <= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.f967x && staggeredGridLayoutManager4.mo1135S(view3) >= i) || !view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                }
            }
            return view;
        }

        /* renamed from: j */
        public C0184c mo1285j(View view) {
            return (C0184c) view.getLayoutParams();
        }

        /* renamed from: k */
        public int mo1286k(int i) {
            int i2 = this.f996b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f995a.size() == 0) {
                return i;
            }
            mo1278c();
            return this.f996b;
        }

        /* renamed from: l */
        public void mo1287l() {
            int size = this.f995a.size();
            View remove = this.f995a.remove(size - 1);
            C0184c j = mo1285j(remove);
            j.f978h = null;
            if (j.mo1175t() || j.mo1174s()) {
                this.f998d -= StaggeredGridLayoutManager.this.f962s.mo2972c(remove);
            }
            if (size == 1) {
                this.f996b = Integer.MIN_VALUE;
            }
            this.f997c = Integer.MIN_VALUE;
        }

        /* renamed from: m */
        public void mo1288m() {
            View remove = this.f995a.remove(0);
            C0184c j = mo1285j(remove);
            j.f978h = null;
            if (this.f995a.size() == 0) {
                this.f997c = Integer.MIN_VALUE;
            }
            if (j.mo1175t() || j.mo1174s()) {
                this.f998d -= StaggeredGridLayoutManager.this.f962s.mo2972c(remove);
            }
            this.f996b = Integer.MIN_VALUE;
        }

        /* renamed from: n */
        public void mo1289n(View view) {
            C0184c j = mo1285j(view);
            j.f978h = this;
            this.f995a.add(0, view);
            this.f996b = Integer.MIN_VALUE;
            if (this.f995a.size() == 1) {
                this.f997c = Integer.MIN_VALUE;
            }
            if (j.mo1175t() || j.mo1174s()) {
                this.f998d = StaggeredGridLayoutManager.this.f962s.mo2972c(view) + this.f998d;
            }
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f967x = false;
        this.f968y = false;
        this.f947A = -1;
        this.f948B = Integer.MIN_VALUE;
        this.f949C = new C0185d();
        this.f950D = 2;
        this.f955I = new Rect();
        this.f956J = new C0183b();
        this.f957K = true;
        this.f959M = new C0182a();
        RecyclerView.C0162m.C0166d T = RecyclerView.C0162m.m601T(context, attributeSet, i, i2);
        int i3 = T.f883a;
        if (i3 == 0 || i3 == 1) {
            mo896c((String) null);
            if (i3 != this.f964u) {
                this.f964u = i3;
                C0682fb fbVar = this.f962s;
                this.f962s = this.f963t;
                this.f963t = fbVar;
                mo1129N0();
            }
            int i4 = T.f884b;
            mo896c((String) null);
            if (i4 != this.f960q) {
                this.f949C.mo1261a();
                mo1129N0();
                this.f960q = i4;
                this.f969z = new BitSet(this.f960q);
                this.f961r = new C0190f[this.f960q];
                for (int i5 = 0; i5 < this.f960q; i5++) {
                    this.f961r[i5] = new C0190f(i5);
                }
                mo1129N0();
            }
            boolean z = T.f885c;
            mo896c((String) null);
            C0188e eVar = this.f953G;
            if (!(eVar == null || eVar.f992k == z)) {
                eVar.f992k = z;
            }
            this.f967x = z;
            mo1129N0();
            this.f966w = new C0274bb();
            this.f962s = C0682fb.m2213a(this, this.f964u);
            this.f963t = C0682fb.m2213a(this, 1 - this.f964u);
            return;
        }
        throw new IllegalArgumentException("invalid orientation.");
    }

    /* renamed from: A1 */
    public final void mo1228A1(int i, int i2) {
        for (int i3 = 0; i3 < this.f960q; i3++) {
            if (!this.f961r[i3].f995a.isEmpty()) {
                mo1230C1(this.f961r[i3], i, i2);
            }
        }
    }

    /* renamed from: B1 */
    public final void mo1229B1(int i, RecyclerView.C0178w wVar) {
        C0274bb bbVar = this.f966w;
        boolean z = false;
        bbVar.f1301b = 0;
        bbVar.f1302c = i;
        RecyclerView recyclerView = this.f866b;
        if (recyclerView != null && recyclerView.f814j) {
            bbVar.f1305f = this.f962s.mo2980k() - 0;
            this.f966w.f1306g = this.f962s.mo2976g() + 0;
        } else {
            bbVar.f1306g = this.f962s.mo2975f() + 0;
            this.f966w.f1305f = 0;
        }
        C0274bb bbVar2 = this.f966w;
        bbVar2.f1307h = false;
        bbVar2.f1300a = true;
        if (this.f962s.mo2978i() == 0 && this.f962s.mo2975f() == 0) {
            z = true;
        }
        bbVar2.f1308i = z;
    }

    /* renamed from: C0 */
    public void mo887C0(Parcelable parcelable) {
        if (parcelable instanceof C0188e) {
            C0188e eVar = (C0188e) parcelable;
            this.f953G = eVar;
            if (this.f947A != -1) {
                eVar.f988g = null;
                eVar.f987f = 0;
                eVar.f985d = -1;
                eVar.f986e = -1;
                eVar.f988g = null;
                eVar.f987f = 0;
                eVar.f989h = 0;
                eVar.f990i = null;
                eVar.f991j = null;
            }
            mo1129N0();
        }
    }

    /* renamed from: C1 */
    public final void mo1230C1(C0190f fVar, int i, int i2) {
        int i3 = fVar.f998d;
        if (i == -1) {
            int i4 = fVar.f996b;
            if (i4 == Integer.MIN_VALUE) {
                fVar.mo1278c();
                i4 = fVar.f996b;
            }
            if (i4 + i3 > i2) {
                return;
            }
        } else {
            int i5 = fVar.f997c;
            if (i5 == Integer.MIN_VALUE) {
                fVar.mo1277b();
                i5 = fVar.f997c;
            }
            if (i5 - i3 < i2) {
                return;
            }
        }
        this.f969z.set(fVar.f999e, false);
    }

    /* renamed from: D0 */
    public Parcelable mo889D0() {
        int i;
        int i2;
        int[] iArr;
        C0188e eVar = this.f953G;
        if (eVar != null) {
            return new C0188e(eVar);
        }
        C0188e eVar2 = new C0188e();
        eVar2.f992k = this.f967x;
        eVar2.f993l = this.f951E;
        eVar2.f994m = this.f952F;
        C0185d dVar = this.f949C;
        if (dVar == null || (iArr = dVar.f979a) == null) {
            eVar2.f989h = 0;
        } else {
            eVar2.f990i = iArr;
            eVar2.f989h = iArr.length;
            eVar2.f991j = dVar.f980b;
        }
        int i3 = -1;
        if (mo1166z() > 0) {
            eVar2.f985d = this.f951E ? mo1242k1() : mo1241j1();
            View f1 = this.f968y ? mo1237f1(true) : mo1238g1(true);
            if (f1 != null) {
                i3 = mo1135S(f1);
            }
            eVar2.f986e = i3;
            int i4 = this.f960q;
            eVar2.f987f = i4;
            eVar2.f988g = new int[i4];
            for (int i5 = 0; i5 < this.f960q; i5++) {
                if (this.f951E) {
                    i = this.f961r[i5].mo1283h(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        i2 = this.f962s.mo2976g();
                    } else {
                        eVar2.f988g[i5] = i;
                    }
                } else {
                    i = this.f961r[i5].mo1286k(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        i2 = this.f962s.mo2980k();
                    } else {
                        eVar2.f988g[i5] = i;
                    }
                }
                i -= i2;
                eVar2.f988g[i5] = i;
            }
        } else {
            eVar2.f985d = -1;
            eVar2.f986e = -1;
            eVar2.f987f = 0;
        }
        return eVar2;
    }

    /* renamed from: D1 */
    public final int mo1231D1(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    /* renamed from: E0 */
    public void mo1111E0(int i) {
        if (i == 0) {
            mo1232a1();
        }
    }

    /* renamed from: O0 */
    public int mo858O0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        return mo1256y1(i, sVar, wVar);
    }

    /* renamed from: P0 */
    public void mo892P0(int i) {
        C0188e eVar = this.f953G;
        if (!(eVar == null || eVar.f985d == i)) {
            eVar.f988g = null;
            eVar.f987f = 0;
            eVar.f985d = -1;
            eVar.f986e = -1;
        }
        this.f947A = i;
        this.f948B = Integer.MIN_VALUE;
        mo1129N0();
    }

    /* renamed from: Q0 */
    public int mo860Q0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        return mo1256y1(i, sVar, wVar);
    }

    /* renamed from: T0 */
    public void mo861T0(Rect rect, int i, int i2) {
        int i3;
        int i4;
        int Q = mo1132Q() + mo1131P();
        int O = mo1130O() + mo1133R();
        if (this.f964u == 1) {
            i4 = RecyclerView.C0162m.m603h(i2, rect.height() + O, mo1126M());
            i3 = RecyclerView.C0162m.m603h(i, (this.f965v * this.f960q) + Q, mo1128N());
        } else {
            i3 = RecyclerView.C0162m.m603h(i, rect.width() + Q, mo1128N());
            i4 = RecyclerView.C0162m.m603h(i2, (this.f965v * this.f960q) + O, mo1126M());
        }
        this.f866b.setMeasuredDimension(i3, i4);
    }

    /* renamed from: Z */
    public boolean mo894Z() {
        return this.f950D != 0;
    }

    /* renamed from: Z0 */
    public boolean mo863Z0() {
        return this.f953G == null;
    }

    /* renamed from: a1 */
    public boolean mo1232a1() {
        int i;
        if (!(mo1166z() == 0 || this.f950D == 0 || !this.f872h)) {
            if (this.f968y) {
                i = mo1242k1();
                mo1241j1();
            } else {
                i = mo1241j1();
                mo1242k1();
            }
            if (i == 0 && mo1246o1() != null) {
                this.f949C.mo1261a();
                this.f871g = true;
                mo1129N0();
                return true;
            }
        }
        return false;
    }

    /* renamed from: b1 */
    public final int mo1233b1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        return C1401p4.m4366i(wVar, this.f962s, mo1238g1(!this.f957K), mo1237f1(!this.f957K), this, this.f957K);
    }

    /* renamed from: c */
    public void mo896c(String str) {
        RecyclerView recyclerView;
        if (this.f953G == null && (recyclerView = this.f866b) != null) {
            recyclerView.mo1013i(str);
        }
    }

    /* renamed from: c1 */
    public final int mo1234c1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        return C1401p4.m4368j(wVar, this.f962s, mo1238g1(!this.f957K), mo1237f1(!this.f957K), this, this.f957K, this.f968y);
    }

    /* renamed from: d1 */
    public final int mo1235d1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        return C1401p4.m4370k(wVar, this.f962s, mo1238g1(!this.f957K), mo1237f1(!this.f957K), this, this.f957K);
    }

    /* renamed from: e */
    public boolean mo899e() {
        return this.f964u == 0;
    }

    /* renamed from: e0 */
    public void mo1151e0(int i) {
        super.mo1151e0(i);
        for (int i2 = 0; i2 < this.f960q; i2++) {
            C0190f fVar = this.f961r[i2];
            int i3 = fVar.f996b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f996b = i3 + i;
            }
            int i4 = fVar.f997c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f997c = i4 + i;
            }
        }
    }

    /* renamed from: e1 */
    public final int mo1236e1(RecyclerView.C0173s sVar, C0274bb bbVar, RecyclerView.C0178w wVar) {
        int i;
        C0190f fVar;
        boolean z;
        boolean z2;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        RecyclerView.C0173s sVar2 = sVar;
        C0274bb bbVar2 = bbVar;
        this.f969z.set(0, this.f960q, true);
        if (this.f966w.f1308i) {
            i = bbVar2.f1304e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        } else {
            i = bbVar2.f1304e == 1 ? bbVar2.f1306g + bbVar2.f1301b : bbVar2.f1305f - bbVar2.f1301b;
        }
        mo1228A1(bbVar2.f1304e, i);
        int g = this.f968y ? this.f962s.mo2976g() : this.f962s.mo2980k();
        boolean z3 = false;
        while (true) {
            int i14 = bbVar2.f1302c;
            if ((i14 >= 0 && i14 < wVar.mo1202b()) && (this.f966w.f1308i || !this.f969z.isEmpty())) {
                View e = sVar2.mo1186e(bbVar2.f1302c);
                bbVar2.f1302c += bbVar2.f1303d;
                C0184c cVar = (C0184c) e.getLayoutParams();
                int r = cVar.mo1173r();
                int[] iArr = this.f949C.f979a;
                int i15 = (iArr == null || r >= iArr.length) ? -1 : iArr[r];
                if (i15 == -1) {
                    if (mo1250s1(bbVar2.f1304e)) {
                        i13 = this.f960q - 1;
                        i12 = -1;
                        i11 = -1;
                    } else {
                        i12 = this.f960q;
                        i13 = 0;
                        i11 = 1;
                    }
                    C0190f fVar2 = null;
                    if (bbVar2.f1304e == 1) {
                        int k = this.f962s.mo2980k();
                        int i16 = Integer.MAX_VALUE;
                        while (i13 != i12) {
                            C0190f fVar3 = this.f961r[i13];
                            int h = fVar3.mo1283h(k);
                            if (h < i16) {
                                fVar2 = fVar3;
                                i16 = h;
                            }
                            i13 += i11;
                        }
                    } else {
                        int g2 = this.f962s.mo2976g();
                        int i17 = Integer.MIN_VALUE;
                        while (i13 != i12) {
                            C0190f fVar4 = this.f961r[i13];
                            int k2 = fVar4.mo1286k(g2);
                            if (k2 > i17) {
                                fVar2 = fVar4;
                                i17 = k2;
                            }
                            i13 += i11;
                        }
                    }
                    fVar = fVar2;
                    C0185d dVar = this.f949C;
                    dVar.mo1262b(r);
                    dVar.f979a[r] = fVar.f999e;
                } else {
                    fVar = this.f961r[i15];
                }
                C0190f fVar5 = fVar;
                cVar.f978h = fVar5;
                if (bbVar2.f1304e == 1) {
                    z = false;
                    mo1147b(e, -1, false);
                } else {
                    z = false;
                    mo1147b(e, 0, false);
                }
                if (this.f964u == 1) {
                    i3 = RecyclerView.C0162m.m600A(this.f965v, this.f877m, z ? 1 : 0, cVar.width, z);
                    i2 = RecyclerView.C0162m.m600A(this.f880p, this.f878n, mo1130O() + mo1133R(), cVar.height, true);
                    z2 = false;
                } else {
                    i3 = RecyclerView.C0162m.m600A(this.f879o, this.f877m, mo1132Q() + mo1131P(), cVar.width, true);
                    z2 = false;
                    i2 = RecyclerView.C0162m.m600A(this.f965v, this.f878n, 0, cVar.height, false);
                }
                mo1248q1(e, i3, i2, z2);
                if (bbVar2.f1304e == 1) {
                    i5 = fVar5.mo1283h(g);
                    i4 = this.f962s.mo2972c(e) + i5;
                } else {
                    i4 = fVar5.mo1286k(g);
                    i5 = i4 - this.f962s.mo2972c(e);
                }
                int i18 = bbVar2.f1304e;
                C0190f fVar6 = cVar.f978h;
                if (i18 == 1) {
                    fVar6.mo1276a(e);
                } else {
                    fVar6.mo1289n(e);
                }
                if (!mo1247p1() || this.f964u != 1) {
                    i6 = this.f963t.mo2980k() + (fVar5.f999e * this.f965v);
                    i7 = this.f963t.mo2972c(e) + i6;
                } else {
                    i7 = this.f963t.mo2976g() - (((this.f960q - 1) - fVar5.f999e) * this.f965v);
                    i6 = i7 - this.f963t.mo2972c(e);
                }
                if (this.f964u == 1) {
                    i9 = i7;
                    i8 = i4;
                    i10 = i6;
                    i6 = i5;
                } else {
                    i8 = i7;
                    i9 = i4;
                    i10 = i5;
                }
                mo1150d0(e, i10, i6, i9, i8);
                mo1230C1(fVar5, this.f966w.f1304e, i);
                mo1252u1(sVar2, this.f966w);
                if (this.f966w.f1307h && e.hasFocusable()) {
                    this.f969z.set(fVar5.f999e, false);
                }
                z3 = true;
            }
        }
        if (!z3) {
            mo1252u1(sVar2, this.f966w);
        }
        int k3 = this.f966w.f1304e == -1 ? this.f962s.mo2980k() - mo1244m1(this.f962s.mo2980k()) : mo1243l1(this.f962s.mo2976g()) - this.f962s.mo2976g();
        if (k3 > 0) {
            return Math.min(bbVar2.f1301b, k3);
        }
        return 0;
    }

    /* renamed from: f */
    public boolean mo901f() {
        return this.f964u == 1;
    }

    /* renamed from: f0 */
    public void mo1152f0(int i) {
        super.mo1152f0(i);
        for (int i2 = 0; i2 < this.f960q; i2++) {
            C0190f fVar = this.f961r[i2];
            int i3 = fVar.f996b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f996b = i3 + i;
            }
            int i4 = fVar.f997c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f997c = i4 + i;
            }
        }
    }

    /* renamed from: f1 */
    public View mo1237f1(boolean z) {
        int k = this.f962s.mo2980k();
        int g = this.f962s.mo2976g();
        View view = null;
        for (int z2 = mo1166z() - 1; z2 >= 0; z2--) {
            View y = mo1165y(z2);
            int e = this.f962s.mo2974e(y);
            int b = this.f962s.mo2971b(y);
            if (b > k && e < g) {
                if (b <= g || !z) {
                    return y;
                }
                if (view == null) {
                    view = y;
                }
            }
        }
        return view;
    }

    /* renamed from: g */
    public boolean mo865g(RecyclerView.C0167n nVar) {
        return nVar instanceof C0184c;
    }

    /* renamed from: g0 */
    public void mo1153g0(RecyclerView.C0150e eVar, RecyclerView.C0150e eVar2) {
        this.f949C.mo1261a();
        for (int i = 0; i < this.f960q; i++) {
            this.f961r[i].mo1279d();
        }
    }

    /* renamed from: g1 */
    public View mo1238g1(boolean z) {
        int k = this.f962s.mo2980k();
        int g = this.f962s.mo2976g();
        int z2 = mo1166z();
        View view = null;
        for (int i = 0; i < z2; i++) {
            View y = mo1165y(i);
            int e = this.f962s.mo2974e(y);
            if (this.f962s.mo2971b(y) > k && e < g) {
                if (e >= k || !z) {
                    return y;
                }
                if (view == null) {
                    view = y;
                }
            }
        }
        return view;
    }

    /* renamed from: h1 */
    public final void mo1239h1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int g;
        int l1 = mo1243l1(Integer.MIN_VALUE);
        if (l1 != Integer.MIN_VALUE && (g = this.f962s.mo2976g() - l1) > 0) {
            int i = g - (-mo1256y1(-g, sVar, wVar));
            if (z && i > 0) {
                this.f962s.mo2984p(i);
            }
        }
    }

    /* renamed from: i */
    public void mo905i(int i, int i2, RecyclerView.C0178w wVar, RecyclerView.C0162m.C0165c cVar) {
        int i3;
        int i4;
        if (this.f964u != 0) {
            i = i2;
        }
        if (mo1166z() != 0 && i != 0) {
            mo1251t1(i, wVar);
            int[] iArr = this.f958L;
            if (iArr == null || iArr.length < this.f960q) {
                this.f958L = new int[this.f960q];
            }
            int i5 = 0;
            for (int i6 = 0; i6 < this.f960q; i6++) {
                C0274bb bbVar = this.f966w;
                if (bbVar.f1303d == -1) {
                    i4 = bbVar.f1305f;
                    i3 = this.f961r[i6].mo1286k(i4);
                } else {
                    i4 = this.f961r[i6].mo1283h(bbVar.f1306g);
                    i3 = this.f966w.f1306g;
                }
                int i7 = i4 - i3;
                if (i7 >= 0) {
                    this.f958L[i5] = i7;
                    i5++;
                }
            }
            Arrays.sort(this.f958L, 0, i5);
            int i8 = 0;
            while (i8 < i5) {
                int i9 = this.f966w.f1302c;
                if (i9 >= 0 && i9 < wVar.mo1202b()) {
                    ((C0021ab.C0023b) cVar).mo73a(this.f966w.f1302c, this.f958L[i8]);
                    C0274bb bbVar2 = this.f966w;
                    bbVar2.f1302c += bbVar2.f1303d;
                    i8++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: i1 */
    public final void mo1240i1(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int k;
        int m1 = mo1244m1(Integer.MAX_VALUE);
        if (m1 != Integer.MAX_VALUE && (k = m1 - this.f962s.mo2980k()) > 0) {
            int y1 = k - mo1256y1(k, sVar, wVar);
            if (z && y1 > 0) {
                this.f962s.mo2984p(-y1);
            }
        }
    }

    /* renamed from: j1 */
    public int mo1241j1() {
        if (mo1166z() == 0) {
            return 0;
        }
        return mo1135S(mo1165y(0));
    }

    /* renamed from: k */
    public int mo909k(RecyclerView.C0178w wVar) {
        return mo1233b1(wVar);
    }

    /* renamed from: k0 */
    public void mo910k0(RecyclerView recyclerView, RecyclerView.C0173s sVar) {
        mo1156j0();
        Runnable runnable = this.f959M;
        RecyclerView recyclerView2 = this.f866b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(runnable);
        }
        for (int i = 0; i < this.f960q; i++) {
            this.f961r[i].mo1279d();
        }
        recyclerView.requestLayout();
    }

    /* renamed from: k1 */
    public int mo1242k1() {
        int z = mo1166z();
        if (z == 0) {
            return 0;
        }
        return mo1135S(mo1165y(z - 1));
    }

    /* renamed from: l */
    public int mo866l(RecyclerView.C0178w wVar) {
        return mo1234c1(wVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0038, code lost:
        if (r8.f964u == 1) goto L_0x005c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x003d, code lost:
        if (r8.f964u == 0) goto L_0x005c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x004c, code lost:
        if (mo1247p1() == false) goto L_0x005a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0058, code lost:
        if (mo1247p1() == false) goto L_0x005c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x005f A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0060  */
    /* renamed from: l0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo867l0(android.view.View r9, int r10, androidx.recyclerview.widget.RecyclerView.C0173s r11, androidx.recyclerview.widget.RecyclerView.C0178w r12) {
        /*
            r8 = this;
            int r0 = r8.mo1166z()
            r1 = 0
            if (r0 != 0) goto L_0x0008
            return r1
        L_0x0008:
            android.view.View r9 = r8.mo1162s(r9)
            if (r9 != 0) goto L_0x000f
            return r1
        L_0x000f:
            r8.mo1255x1()
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = -1
            r3 = 1
            if (r10 == r3) goto L_0x004f
            r4 = 2
            if (r10 == r4) goto L_0x0043
            r4 = 17
            if (r10 == r4) goto L_0x003b
            r4 = 33
            if (r10 == r4) goto L_0x0036
            r4 = 66
            if (r10 == r4) goto L_0x0031
            r4 = 130(0x82, float:1.82E-43)
            if (r10 == r4) goto L_0x002c
            goto L_0x0040
        L_0x002c:
            int r10 = r8.f964u
            if (r10 != r3) goto L_0x0040
            goto L_0x005a
        L_0x0031:
            int r10 = r8.f964u
            if (r10 != 0) goto L_0x0040
            goto L_0x005a
        L_0x0036:
            int r10 = r8.f964u
            if (r10 != r3) goto L_0x0040
            goto L_0x005c
        L_0x003b:
            int r10 = r8.f964u
            if (r10 != 0) goto L_0x0040
            goto L_0x005c
        L_0x0040:
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x005d
        L_0x0043:
            int r10 = r8.f964u
            if (r10 != r3) goto L_0x0048
            goto L_0x005a
        L_0x0048:
            boolean r10 = r8.mo1247p1()
            if (r10 == 0) goto L_0x005a
            goto L_0x005c
        L_0x004f:
            int r10 = r8.f964u
            if (r10 != r3) goto L_0x0054
            goto L_0x005c
        L_0x0054:
            boolean r10 = r8.mo1247p1()
            if (r10 == 0) goto L_0x005c
        L_0x005a:
            r10 = 1
            goto L_0x005d
        L_0x005c:
            r10 = -1
        L_0x005d:
            if (r10 != r0) goto L_0x0060
            return r1
        L_0x0060:
            android.view.ViewGroup$LayoutParams r0 = r9.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r0 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0184c) r0
            java.util.Objects.requireNonNull(r0)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r0 = r0.f978h
            if (r10 != r3) goto L_0x0072
            int r4 = r8.mo1242k1()
            goto L_0x0076
        L_0x0072:
            int r4 = r8.mo1241j1()
        L_0x0076:
            r8.mo1229B1(r4, r12)
            r8.mo1257z1(r10)
            bb r5 = r8.f966w
            int r6 = r5.f1303d
            int r6 = r6 + r4
            r5.f1302c = r6
            r6 = 1051372203(0x3eaaaaab, float:0.33333334)
            fb r7 = r8.f962s
            int r7 = r7.mo2981l()
            float r7 = (float) r7
            float r7 = r7 * r6
            int r6 = (int) r7
            r5.f1301b = r6
            bb r5 = r8.f966w
            r5.f1307h = r3
            r6 = 0
            r5.f1300a = r6
            r8.mo1236e1(r11, r5, r12)
            boolean r11 = r8.f968y
            r8.f951E = r11
            android.view.View r11 = r0.mo1284i(r4, r10)
            if (r11 == 0) goto L_0x00a9
            if (r11 == r9) goto L_0x00a9
            return r11
        L_0x00a9:
            boolean r11 = r8.mo1250s1(r10)
            if (r11 == 0) goto L_0x00c4
            int r11 = r8.f960q
            int r11 = r11 - r3
        L_0x00b2:
            if (r11 < 0) goto L_0x00d9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r12 = r8.f961r
            r12 = r12[r11]
            android.view.View r12 = r12.mo1284i(r4, r10)
            if (r12 == 0) goto L_0x00c1
            if (r12 == r9) goto L_0x00c1
            return r12
        L_0x00c1:
            int r11 = r11 + -1
            goto L_0x00b2
        L_0x00c4:
            r11 = 0
        L_0x00c5:
            int r12 = r8.f960q
            if (r11 >= r12) goto L_0x00d9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r12 = r8.f961r
            r12 = r12[r11]
            android.view.View r12 = r12.mo1284i(r4, r10)
            if (r12 == 0) goto L_0x00d6
            if (r12 == r9) goto L_0x00d6
            return r12
        L_0x00d6:
            int r11 = r11 + 1
            goto L_0x00c5
        L_0x00d9:
            boolean r11 = r8.f967x
            r11 = r11 ^ r3
            if (r10 != r2) goto L_0x00e0
            r12 = 1
            goto L_0x00e1
        L_0x00e0:
            r12 = 0
        L_0x00e1:
            if (r11 != r12) goto L_0x00e5
            r11 = 1
            goto L_0x00e6
        L_0x00e5:
            r11 = 0
        L_0x00e6:
            if (r11 == 0) goto L_0x00ed
            int r12 = r0.mo1280e()
            goto L_0x00f1
        L_0x00ed:
            int r12 = r0.mo1281f()
        L_0x00f1:
            android.view.View r12 = r8.mo921t(r12)
            if (r12 == 0) goto L_0x00fa
            if (r12 == r9) goto L_0x00fa
            return r12
        L_0x00fa:
            boolean r10 = r8.mo1250s1(r10)
            if (r10 == 0) goto L_0x0127
            int r10 = r8.f960q
            int r10 = r10 - r3
        L_0x0103:
            if (r10 < 0) goto L_0x0148
            int r12 = r0.f999e
            if (r10 != r12) goto L_0x010a
            goto L_0x0124
        L_0x010a:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r12 = r8.f961r
            if (r11 == 0) goto L_0x0115
            r12 = r12[r10]
            int r12 = r12.mo1280e()
            goto L_0x011b
        L_0x0115:
            r12 = r12[r10]
            int r12 = r12.mo1281f()
        L_0x011b:
            android.view.View r12 = r8.mo921t(r12)
            if (r12 == 0) goto L_0x0124
            if (r12 == r9) goto L_0x0124
            return r12
        L_0x0124:
            int r10 = r10 + -1
            goto L_0x0103
        L_0x0127:
            int r10 = r8.f960q
            if (r6 >= r10) goto L_0x0148
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r10 = r8.f961r
            if (r11 == 0) goto L_0x0136
            r10 = r10[r6]
            int r10 = r10.mo1280e()
            goto L_0x013c
        L_0x0136:
            r10 = r10[r6]
            int r10 = r10.mo1281f()
        L_0x013c:
            android.view.View r10 = r8.mo921t(r10)
            if (r10 == 0) goto L_0x0145
            if (r10 == r9) goto L_0x0145
            return r10
        L_0x0145:
            int r6 = r6 + 1
            goto L_0x0127
        L_0x0148:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo867l0(android.view.View, int, androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w):android.view.View");
    }

    /* renamed from: l1 */
    public final int mo1243l1(int i) {
        int h = this.f961r[0].mo1283h(i);
        for (int i2 = 1; i2 < this.f960q; i2++) {
            int h2 = this.f961r[i2].mo1283h(i);
            if (h2 > h) {
                h = h2;
            }
        }
        return h;
    }

    /* renamed from: m */
    public int mo868m(RecyclerView.C0178w wVar) {
        return mo1235d1(wVar);
    }

    /* renamed from: m0 */
    public void mo913m0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.C0173s sVar = this.f866b.f804e;
        mo1157n0(accessibilityEvent);
        if (mo1166z() > 0) {
            View g1 = mo1238g1(false);
            View f1 = mo1237f1(false);
            if (g1 != null && f1 != null) {
                int S = mo1135S(g1);
                int S2 = mo1135S(f1);
                if (S < S2) {
                    accessibilityEvent.setFromIndex(S);
                    accessibilityEvent.setToIndex(S2);
                    return;
                }
                accessibilityEvent.setFromIndex(S2);
                accessibilityEvent.setToIndex(S);
            }
        }
    }

    /* renamed from: m1 */
    public final int mo1244m1(int i) {
        int k = this.f961r[0].mo1286k(i);
        for (int i2 = 1; i2 < this.f960q; i2++) {
            int k2 = this.f961r[i2].mo1286k(i);
            if (k2 < k) {
                k = k2;
            }
        }
        return k;
    }

    /* renamed from: n */
    public int mo915n(RecyclerView.C0178w wVar) {
        return mo1233b1(wVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0043 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0044  */
    /* renamed from: n1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1245n1(int r7, int r8, int r9) {
        /*
            r6 = this;
            boolean r0 = r6.f968y
            if (r0 == 0) goto L_0x0009
            int r0 = r6.mo1242k1()
            goto L_0x000d
        L_0x0009:
            int r0 = r6.mo1241j1()
        L_0x000d:
            r1 = 8
            if (r9 != r1) goto L_0x001a
            if (r7 >= r8) goto L_0x0016
            int r2 = r8 + 1
            goto L_0x001c
        L_0x0016:
            int r2 = r7 + 1
            r3 = r8
            goto L_0x001d
        L_0x001a:
            int r2 = r7 + r8
        L_0x001c:
            r3 = r7
        L_0x001d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r4 = r6.f949C
            r4.mo1264d(r3)
            r4 = 1
            if (r9 == r4) goto L_0x003c
            r5 = 2
            if (r9 == r5) goto L_0x0036
            if (r9 == r1) goto L_0x002b
            goto L_0x0041
        L_0x002b:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f949C
            r9.mo1266f(r7, r4)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r6.f949C
            r7.mo1265e(r8, r4)
            goto L_0x0041
        L_0x0036:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f949C
            r9.mo1266f(r7, r8)
            goto L_0x0041
        L_0x003c:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f949C
            r9.mo1265e(r7, r8)
        L_0x0041:
            if (r2 > r0) goto L_0x0044
            return
        L_0x0044:
            boolean r7 = r6.f968y
            if (r7 == 0) goto L_0x004d
            int r7 = r6.mo1241j1()
            goto L_0x0051
        L_0x004d:
            int r7 = r6.mo1242k1()
        L_0x0051:
            if (r3 > r7) goto L_0x0056
            r6.mo1129N0()
        L_0x0056:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo1245n1(int, int, int):void");
    }

    /* renamed from: o */
    public int mo870o(RecyclerView.C0178w wVar) {
        return mo1234c1(wVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00b3, code lost:
        if (r10 == r11) goto L_0x00c7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00c5, code lost:
        if (r10 == r11) goto L_0x00c7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00c9, code lost:
        r10 = false;
     */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0091  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0090 A[SYNTHETIC] */
    /* renamed from: o1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo1246o1() {
        /*
            r12 = this;
            int r0 = r12.mo1166z()
            r1 = 1
            int r0 = r0 - r1
            java.util.BitSet r2 = new java.util.BitSet
            int r3 = r12.f960q
            r2.<init>(r3)
            int r3 = r12.f960q
            r4 = 0
            r2.set(r4, r3, r1)
            int r3 = r12.f964u
            r5 = -1
            if (r3 != r1) goto L_0x0020
            boolean r3 = r12.mo1247p1()
            if (r3 == 0) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = -1
        L_0x0021:
            boolean r6 = r12.f968y
            if (r6 == 0) goto L_0x0027
            r6 = -1
            goto L_0x002b
        L_0x0027:
            int r0 = r0 + 1
            r6 = r0
            r0 = 0
        L_0x002b:
            if (r0 >= r6) goto L_0x002e
            r5 = 1
        L_0x002e:
            if (r0 == r6) goto L_0x00eb
            android.view.View r7 = r12.mo1165y(r0)
            android.view.ViewGroup$LayoutParams r8 = r7.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r8 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0184c) r8
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f978h
            int r9 = r9.f999e
            boolean r9 = r2.get(r9)
            if (r9 == 0) goto L_0x0098
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f978h
            boolean r10 = r12.f968y
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r10 == 0) goto L_0x006a
            int r10 = r9.f997c
            if (r10 == r11) goto L_0x0051
            goto L_0x0056
        L_0x0051:
            r9.mo1277b()
            int r10 = r9.f997c
        L_0x0056:
            fb r11 = r12.f962s
            int r11 = r11.mo2976g()
            if (r10 >= r11) goto L_0x008d
            java.util.ArrayList<android.view.View> r10 = r9.f995a
            int r11 = r10.size()
            int r11 = r11 - r1
            java.lang.Object r10 = r10.get(r11)
            goto L_0x0082
        L_0x006a:
            int r10 = r9.f996b
            if (r10 == r11) goto L_0x006f
            goto L_0x0074
        L_0x006f:
            r9.mo1278c()
            int r10 = r9.f996b
        L_0x0074:
            fb r11 = r12.f962s
            int r11 = r11.mo2980k()
            if (r10 <= r11) goto L_0x008d
            java.util.ArrayList<android.view.View> r10 = r9.f995a
            java.lang.Object r10 = r10.get(r4)
        L_0x0082:
            android.view.View r10 = (android.view.View) r10
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r9 = r9.mo1285j(r10)
            java.util.Objects.requireNonNull(r9)
            r9 = 1
            goto L_0x008e
        L_0x008d:
            r9 = 0
        L_0x008e:
            if (r9 == 0) goto L_0x0091
            return r7
        L_0x0091:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f978h
            int r9 = r9.f999e
            r2.clear(r9)
        L_0x0098:
            int r9 = r0 + r5
            if (r9 == r6) goto L_0x00e8
            android.view.View r9 = r12.mo1165y(r9)
            boolean r10 = r12.f968y
            if (r10 == 0) goto L_0x00b6
            fb r10 = r12.f962s
            int r10 = r10.mo2971b(r7)
            fb r11 = r12.f962s
            int r11 = r11.mo2971b(r9)
            if (r10 >= r11) goto L_0x00b3
            return r7
        L_0x00b3:
            if (r10 != r11) goto L_0x00c9
            goto L_0x00c7
        L_0x00b6:
            fb r10 = r12.f962s
            int r10 = r10.mo2974e(r7)
            fb r11 = r12.f962s
            int r11 = r11.mo2974e(r9)
            if (r10 <= r11) goto L_0x00c5
            return r7
        L_0x00c5:
            if (r10 != r11) goto L_0x00c9
        L_0x00c7:
            r10 = 1
            goto L_0x00ca
        L_0x00c9:
            r10 = 0
        L_0x00ca:
            if (r10 == 0) goto L_0x00e8
            android.view.ViewGroup$LayoutParams r9 = r9.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r9 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0184c) r9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r8 = r8.f978h
            int r8 = r8.f999e
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r9.f978h
            int r9 = r9.f999e
            int r8 = r8 - r9
            if (r8 >= 0) goto L_0x00df
            r8 = 1
            goto L_0x00e0
        L_0x00df:
            r8 = 0
        L_0x00e0:
            if (r3 >= 0) goto L_0x00e4
            r9 = 1
            goto L_0x00e5
        L_0x00e4:
            r9 = 0
        L_0x00e5:
            if (r8 == r9) goto L_0x00e8
            return r7
        L_0x00e8:
            int r0 = r0 + r5
            goto L_0x002e
        L_0x00eb:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo1246o1():android.view.View");
    }

    /* renamed from: p */
    public int mo871p(RecyclerView.C0178w wVar) {
        return mo1235d1(wVar);
    }

    /* renamed from: p1 */
    public boolean mo1247p1() {
        return mo1122K() == 1;
    }

    /* renamed from: q1 */
    public final void mo1248q1(View view, int i, int i2, boolean z) {
        mo1149d(view, this.f955I);
        C0184c cVar = (C0184c) view.getLayoutParams();
        int i3 = cVar.leftMargin;
        Rect rect = this.f955I;
        int D1 = mo1231D1(i, i3 + rect.left, cVar.rightMargin + rect.right);
        int i4 = cVar.topMargin;
        Rect rect2 = this.f955I;
        int D12 = mo1231D1(i2, i4 + rect2.top, cVar.bottomMargin + rect2.bottom);
        if (z ? mo1144Y0(view, D1, D12, cVar) : mo1141W0(view, D1, D12, cVar)) {
            view.measure(D1, D12);
        }
    }

    /* renamed from: r0 */
    public void mo873r0(RecyclerView recyclerView, int i, int i2) {
        mo1245n1(i, i2, 1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:101:0x018e, code lost:
        if ((r6 < mo1241j1()) != r11.f968y) goto L_0x0190;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x0192, code lost:
        r6 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:245:0x0410, code lost:
        if (mo1232a1() != false) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x0180, code lost:
        if (r11.f968y != false) goto L_0x0192;
     */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x01c3  */
    /* renamed from: r1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1249r1(androidx.recyclerview.widget.RecyclerView.C0173s r12, androidx.recyclerview.widget.RecyclerView.C0178w r13, boolean r14) {
        /*
            r11 = this;
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r0 = r11.f956J
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r1 = r11.f953G
            r2 = -1
            if (r1 != 0) goto L_0x000b
            int r1 = r11.f947A
            if (r1 == r2) goto L_0x0018
        L_0x000b:
            int r1 = r13.mo1202b()
            if (r1 != 0) goto L_0x0018
            r11.mo1119I0(r12)
            r0.mo1260b()
            return
        L_0x0018:
            boolean r1 = r0.f975e
            r3 = 1
            r4 = 0
            if (r1 == 0) goto L_0x0029
            int r1 = r11.f947A
            if (r1 != r2) goto L_0x0029
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r1 = r11.f953G
            if (r1 == 0) goto L_0x0027
            goto L_0x0029
        L_0x0027:
            r1 = 0
            goto L_0x002a
        L_0x0029:
            r1 = 1
        L_0x002a:
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x01fe
            r0.mo1260b()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            if (r6 == 0) goto L_0x00b8
            int r7 = r6.f987f
            r8 = 0
            if (r7 <= 0) goto L_0x007d
            int r9 = r11.f960q
            if (r7 != r9) goto L_0x006f
            r6 = 0
        L_0x003f:
            int r7 = r11.f960q
            if (r6 >= r7) goto L_0x007d
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f961r
            r7 = r7[r6]
            r7.mo1279d()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r7 = r11.f953G
            int[] r9 = r7.f988g
            r9 = r9[r6]
            if (r9 == r5) goto L_0x0064
            boolean r7 = r7.f993l
            if (r7 == 0) goto L_0x005d
            fb r7 = r11.f962s
            int r7 = r7.mo2976g()
            goto L_0x0063
        L_0x005d:
            fb r7 = r11.f962s
            int r7 = r7.mo2980k()
        L_0x0063:
            int r9 = r9 + r7
        L_0x0064:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f961r
            r7 = r7[r6]
            r7.f996b = r9
            r7.f997c = r9
            int r6 = r6 + 1
            goto L_0x003f
        L_0x006f:
            r6.f988g = r8
            r6.f987f = r4
            r6.f989h = r4
            r6.f990i = r8
            r6.f991j = r8
            int r7 = r6.f986e
            r6.f985d = r7
        L_0x007d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            boolean r7 = r6.f994m
            r11.f952F = r7
            boolean r6 = r6.f992k
            r11.mo896c(r8)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r7 = r11.f953G
            if (r7 == 0) goto L_0x0092
            boolean r8 = r7.f992k
            if (r8 == r6) goto L_0x0092
            r7.f992k = r6
        L_0x0092:
            r11.f967x = r6
            r11.mo1129N0()
            r11.mo1255x1()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            int r7 = r6.f985d
            if (r7 == r2) goto L_0x00a5
            r11.f947A = r7
            boolean r7 = r6.f993l
            goto L_0x00a7
        L_0x00a5:
            boolean r7 = r11.f968y
        L_0x00a7:
            r0.f973c = r7
            int r7 = r6.f989h
            if (r7 <= r3) goto L_0x00bf
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r11.f949C
            int[] r8 = r6.f990i
            r7.f979a = r8
            java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r6 = r6.f991j
            r7.f980b = r6
            goto L_0x00bf
        L_0x00b8:
            r11.mo1255x1()
            boolean r6 = r11.f968y
            r0.f973c = r6
        L_0x00bf:
            boolean r6 = r13.f912f
            if (r6 != 0) goto L_0x01bf
            int r6 = r11.f947A
            if (r6 != r2) goto L_0x00c9
            goto L_0x01bf
        L_0x00c9:
            if (r6 < 0) goto L_0x01bb
            int r7 = r13.mo1202b()
            if (r6 < r7) goto L_0x00d3
            goto L_0x01bb
        L_0x00d3:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            if (r6 == 0) goto L_0x00e8
            int r7 = r6.f985d
            if (r7 == r2) goto L_0x00e8
            int r6 = r6.f987f
            if (r6 >= r3) goto L_0x00e0
            goto L_0x00e8
        L_0x00e0:
            r0.f972b = r5
            int r6 = r11.f947A
            r0.f971a = r6
            goto L_0x01b9
        L_0x00e8:
            int r6 = r11.f947A
            android.view.View r6 = r11.mo921t(r6)
            if (r6 == 0) goto L_0x0170
            boolean r7 = r11.f968y
            if (r7 == 0) goto L_0x00f9
            int r7 = r11.mo1242k1()
            goto L_0x00fd
        L_0x00f9:
            int r7 = r11.mo1241j1()
        L_0x00fd:
            r0.f971a = r7
            int r7 = r11.f948B
            if (r7 == r5) goto L_0x0128
            boolean r7 = r0.f973c
            if (r7 == 0) goto L_0x0117
            fb r7 = r11.f962s
            int r7 = r7.mo2976g()
            int r8 = r11.f948B
            int r7 = r7 - r8
            fb r8 = r11.f962s
            int r6 = r8.mo2971b(r6)
            goto L_0x0126
        L_0x0117:
            fb r7 = r11.f962s
            int r7 = r7.mo2980k()
            int r8 = r11.f948B
            int r7 = r7 + r8
            fb r8 = r11.f962s
            int r6 = r8.mo2974e(r6)
        L_0x0126:
            int r7 = r7 - r6
            goto L_0x016a
        L_0x0128:
            fb r7 = r11.f962s
            int r7 = r7.mo2972c(r6)
            fb r8 = r11.f962s
            int r8 = r8.mo2981l()
            if (r7 <= r8) goto L_0x0148
            boolean r6 = r0.f973c
            if (r6 == 0) goto L_0x0141
            fb r6 = r11.f962s
            int r6 = r6.mo2976g()
            goto L_0x0158
        L_0x0141:
            fb r6 = r11.f962s
            int r6 = r6.mo2980k()
            goto L_0x0158
        L_0x0148:
            fb r7 = r11.f962s
            int r7 = r7.mo2974e(r6)
            fb r8 = r11.f962s
            int r8 = r8.mo2980k()
            int r7 = r7 - r8
            if (r7 >= 0) goto L_0x015b
            int r6 = -r7
        L_0x0158:
            r0.f972b = r6
            goto L_0x01b9
        L_0x015b:
            fb r7 = r11.f962s
            int r7 = r7.mo2976g()
            fb r8 = r11.f962s
            int r6 = r8.mo2971b(r6)
            int r7 = r7 - r6
            if (r7 >= 0) goto L_0x016d
        L_0x016a:
            r0.f972b = r7
            goto L_0x01b9
        L_0x016d:
            r0.f972b = r5
            goto L_0x01b9
        L_0x0170:
            int r6 = r11.f947A
            r0.f971a = r6
            int r7 = r11.f948B
            if (r7 != r5) goto L_0x019e
            int r7 = r11.mo1166z()
            if (r7 != 0) goto L_0x0183
            boolean r6 = r11.f968y
            if (r6 == 0) goto L_0x0190
            goto L_0x0192
        L_0x0183:
            int r7 = r11.mo1241j1()
            if (r6 >= r7) goto L_0x018b
            r6 = 1
            goto L_0x018c
        L_0x018b:
            r6 = 0
        L_0x018c:
            boolean r7 = r11.f968y
            if (r6 == r7) goto L_0x0192
        L_0x0190:
            r6 = -1
            goto L_0x0193
        L_0x0192:
            r6 = 1
        L_0x0193:
            if (r6 != r3) goto L_0x0197
            r6 = 1
            goto L_0x0198
        L_0x0197:
            r6 = 0
        L_0x0198:
            r0.f973c = r6
            r0.mo1259a()
            goto L_0x01b7
        L_0x019e:
            boolean r6 = r0.f973c
            if (r6 == 0) goto L_0x01ac
            androidx.recyclerview.widget.StaggeredGridLayoutManager r6 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            fb r6 = r6.f962s
            int r6 = r6.mo2976g()
            int r6 = r6 - r7
            goto L_0x01b5
        L_0x01ac:
            androidx.recyclerview.widget.StaggeredGridLayoutManager r6 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            fb r6 = r6.f962s
            int r6 = r6.mo2980k()
            int r6 = r6 + r7
        L_0x01b5:
            r0.f972b = r6
        L_0x01b7:
            r0.f974d = r3
        L_0x01b9:
            r6 = 1
            goto L_0x01c0
        L_0x01bb:
            r11.f947A = r2
            r11.f948B = r5
        L_0x01bf:
            r6 = 0
        L_0x01c0:
            if (r6 == 0) goto L_0x01c3
            goto L_0x01fc
        L_0x01c3:
            boolean r6 = r11.f951E
            int r7 = r13.mo1202b()
            if (r6 == 0) goto L_0x01df
            int r6 = r11.mo1166z()
        L_0x01cf:
            int r6 = r6 + r2
            if (r6 < 0) goto L_0x01f7
            android.view.View r8 = r11.mo1165y(r6)
            int r8 = r11.mo1135S(r8)
            if (r8 < 0) goto L_0x01cf
            if (r8 >= r7) goto L_0x01cf
            goto L_0x01f8
        L_0x01df:
            int r6 = r11.mo1166z()
            r8 = 0
        L_0x01e4:
            if (r8 >= r6) goto L_0x01f7
            android.view.View r9 = r11.mo1165y(r8)
            int r9 = r11.mo1135S(r9)
            if (r9 < 0) goto L_0x01f4
            if (r9 >= r7) goto L_0x01f4
            r8 = r9
            goto L_0x01f8
        L_0x01f4:
            int r8 = r8 + 1
            goto L_0x01e4
        L_0x01f7:
            r8 = 0
        L_0x01f8:
            r0.f971a = r8
            r0.f972b = r5
        L_0x01fc:
            r0.f975e = r3
        L_0x01fe:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            if (r6 != 0) goto L_0x021b
            int r6 = r11.f947A
            if (r6 != r2) goto L_0x021b
            boolean r6 = r0.f973c
            boolean r7 = r11.f951E
            if (r6 != r7) goto L_0x0214
            boolean r6 = r11.mo1247p1()
            boolean r7 = r11.f952F
            if (r6 == r7) goto L_0x021b
        L_0x0214:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r6 = r11.f949C
            r6.mo1261a()
            r0.f974d = r3
        L_0x021b:
            int r6 = r11.mo1166z()
            if (r6 <= 0) goto L_0x02d3
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f953G
            if (r6 == 0) goto L_0x0229
            int r6 = r6.f987f
            if (r6 >= r3) goto L_0x02d3
        L_0x0229:
            boolean r6 = r0.f974d
            if (r6 == 0) goto L_0x0248
            r1 = 0
        L_0x022e:
            int r6 = r11.f960q
            if (r1 >= r6) goto L_0x02d3
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f961r
            r6 = r6[r1]
            r6.mo1279d()
            int r6 = r0.f972b
            if (r6 == r5) goto L_0x0245
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f961r
            r7 = r7[r1]
            r7.f996b = r6
            r7.f997c = r6
        L_0x0245:
            int r1 = r1 + 1
            goto L_0x022e
        L_0x0248:
            if (r1 != 0) goto L_0x026a
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r1 = r11.f956J
            int[] r1 = r1.f976f
            if (r1 != 0) goto L_0x0251
            goto L_0x026a
        L_0x0251:
            r1 = 0
        L_0x0252:
            int r6 = r11.f960q
            if (r1 >= r6) goto L_0x02d3
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f961r
            r6 = r6[r1]
            r6.mo1279d()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r7 = r11.f956J
            int[] r7 = r7.f976f
            r7 = r7[r1]
            r6.f996b = r7
            r6.f997c = r7
            int r1 = r1 + 1
            goto L_0x0252
        L_0x026a:
            r1 = 0
        L_0x026b:
            int r6 = r11.f960q
            if (r1 >= r6) goto L_0x02ab
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f961r
            r6 = r6[r1]
            boolean r7 = r11.f968y
            int r8 = r0.f972b
            if (r7 == 0) goto L_0x027e
            int r9 = r6.mo1283h(r5)
            goto L_0x0282
        L_0x027e:
            int r9 = r6.mo1286k(r5)
        L_0x0282:
            r6.mo1279d()
            if (r9 != r5) goto L_0x0288
            goto L_0x02a8
        L_0x0288:
            if (r7 == 0) goto L_0x0294
            androidx.recyclerview.widget.StaggeredGridLayoutManager r10 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            fb r10 = r10.f962s
            int r10 = r10.mo2976g()
            if (r9 < r10) goto L_0x02a8
        L_0x0294:
            if (r7 != 0) goto L_0x02a1
            androidx.recyclerview.widget.StaggeredGridLayoutManager r7 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            fb r7 = r7.f962s
            int r7 = r7.mo2980k()
            if (r9 <= r7) goto L_0x02a1
            goto L_0x02a8
        L_0x02a1:
            if (r8 == r5) goto L_0x02a4
            int r9 = r9 + r8
        L_0x02a4:
            r6.f997c = r9
            r6.f996b = r9
        L_0x02a8:
            int r1 = r1 + 1
            goto L_0x026b
        L_0x02ab:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r1 = r11.f956J
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f961r
            java.util.Objects.requireNonNull(r1)
            int r7 = r6.length
            int[] r8 = r1.f976f
            if (r8 == 0) goto L_0x02ba
            int r8 = r8.length
            if (r8 >= r7) goto L_0x02c3
        L_0x02ba:
            androidx.recyclerview.widget.StaggeredGridLayoutManager r8 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r8 = r8.f961r
            int r8 = r8.length
            int[] r8 = new int[r8]
            r1.f976f = r8
        L_0x02c3:
            r8 = 0
        L_0x02c4:
            if (r8 >= r7) goto L_0x02d3
            int[] r9 = r1.f976f
            r10 = r6[r8]
            int r10 = r10.mo1286k(r5)
            r9[r8] = r10
            int r8 = r8 + 1
            goto L_0x02c4
        L_0x02d3:
            r11.mo1159q(r12)
            bb r1 = r11.f966w
            r1.f1300a = r4
            fb r1 = r11.f963t
            int r1 = r1.mo2981l()
            int r6 = r11.f960q
            int r6 = r1 / r6
            r11.f965v = r6
            fb r6 = r11.f963t
            int r6 = r6.mo2978i()
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r6)
            r11.f954H = r1
            int r1 = r0.f971a
            r11.mo1229B1(r1, r13)
            boolean r1 = r0.f973c
            if (r1 == 0) goto L_0x0307
            r11.mo1257z1(r2)
            bb r1 = r11.f966w
            r11.mo1236e1(r12, r1, r13)
            r11.mo1257z1(r3)
            goto L_0x0312
        L_0x0307:
            r11.mo1257z1(r3)
            bb r1 = r11.f966w
            r11.mo1236e1(r12, r1, r13)
            r11.mo1257z1(r2)
        L_0x0312:
            bb r1 = r11.f966w
            int r2 = r0.f971a
            int r6 = r1.f1303d
            int r2 = r2 + r6
            r1.f1302c = r2
            r11.mo1236e1(r12, r1, r13)
            fb r1 = r11.f963t
            int r1 = r1.mo2978i()
            r2 = 1073741824(0x40000000, float:2.0)
            if (r1 != r2) goto L_0x032a
            goto L_0x03d1
        L_0x032a:
            r1 = 0
            int r2 = r11.mo1166z()
            r6 = 0
        L_0x0330:
            if (r6 >= r2) goto L_0x0352
            android.view.View r7 = r11.mo1165y(r6)
            fb r8 = r11.f963t
            int r8 = r8.mo2972c(r7)
            float r8 = (float) r8
            int r9 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r9 >= 0) goto L_0x0342
            goto L_0x034f
        L_0x0342:
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r7 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0184c) r7
            java.util.Objects.requireNonNull(r7)
            float r1 = java.lang.Math.max(r1, r8)
        L_0x034f:
            int r6 = r6 + 1
            goto L_0x0330
        L_0x0352:
            int r6 = r11.f965v
            int r7 = r11.f960q
            float r7 = (float) r7
            float r1 = r1 * r7
            int r1 = java.lang.Math.round(r1)
            fb r7 = r11.f963t
            int r7 = r7.mo2978i()
            if (r7 != r5) goto L_0x036f
            fb r5 = r11.f963t
            int r5 = r5.mo2981l()
            int r1 = java.lang.Math.min(r1, r5)
        L_0x036f:
            int r5 = r11.f960q
            int r5 = r1 / r5
            r11.f965v = r5
            fb r5 = r11.f963t
            int r5 = r5.mo2978i()
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r5)
            r11.f954H = r1
            int r1 = r11.f965v
            if (r1 != r6) goto L_0x0386
            goto L_0x03d1
        L_0x0386:
            r1 = 0
        L_0x0387:
            if (r1 >= r2) goto L_0x03d1
            android.view.View r5 = r11.mo1165y(r1)
            android.view.ViewGroup$LayoutParams r7 = r5.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r7 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0184c) r7
            java.util.Objects.requireNonNull(r7)
            boolean r8 = r11.mo1247p1()
            if (r8 == 0) goto L_0x03b8
            int r8 = r11.f964u
            if (r8 != r3) goto L_0x03b8
            int r8 = r11.f960q
            int r9 = r8 + -1
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r7 = r7.f978h
            int r7 = r7.f999e
            int r9 = r9 - r7
            int r9 = -r9
            int r10 = r11.f965v
            int r9 = r9 * r10
            int r8 = r8 - r3
            int r8 = r8 - r7
            int r7 = -r8
            int r7 = r7 * r6
            int r9 = r9 - r7
            r5.offsetLeftAndRight(r9)
            goto L_0x03ce
        L_0x03b8:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r7 = r7.f978h
            int r7 = r7.f999e
            int r8 = r11.f965v
            int r8 = r8 * r7
            int r7 = r7 * r6
            int r9 = r11.f964u
            int r8 = r8 - r7
            if (r9 != r3) goto L_0x03cb
            r5.offsetLeftAndRight(r8)
            goto L_0x03ce
        L_0x03cb:
            r5.offsetTopAndBottom(r8)
        L_0x03ce:
            int r1 = r1 + 1
            goto L_0x0387
        L_0x03d1:
            int r1 = r11.mo1166z()
            if (r1 <= 0) goto L_0x03e8
            boolean r1 = r11.f968y
            if (r1 == 0) goto L_0x03e2
            r11.mo1239h1(r12, r13, r3)
            r11.mo1240i1(r12, r13, r4)
            goto L_0x03e8
        L_0x03e2:
            r11.mo1240i1(r12, r13, r3)
            r11.mo1239h1(r12, r13, r4)
        L_0x03e8:
            if (r14 == 0) goto L_0x0413
            boolean r14 = r13.f912f
            if (r14 != 0) goto L_0x0413
            int r14 = r11.f950D
            if (r14 == 0) goto L_0x0400
            int r14 = r11.mo1166z()
            if (r14 <= 0) goto L_0x0400
            android.view.View r14 = r11.mo1246o1()
            if (r14 == 0) goto L_0x0400
            r14 = 1
            goto L_0x0401
        L_0x0400:
            r14 = 0
        L_0x0401:
            if (r14 == 0) goto L_0x0413
            java.lang.Runnable r14 = r11.f959M
            androidx.recyclerview.widget.RecyclerView r1 = r11.f866b
            if (r1 == 0) goto L_0x040c
            r1.removeCallbacks(r14)
        L_0x040c:
            boolean r14 = r11.mo1232a1()
            if (r14 == 0) goto L_0x0413
            goto L_0x0414
        L_0x0413:
            r3 = 0
        L_0x0414:
            boolean r14 = r13.f912f
            if (r14 == 0) goto L_0x041d
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r14 = r11.f956J
            r14.mo1260b()
        L_0x041d:
            boolean r14 = r0.f973c
            r11.f951E = r14
            boolean r14 = r11.mo1247p1()
            r11.f952F = r14
            if (r3 == 0) goto L_0x0431
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r14 = r11.f956J
            r14.mo1260b()
            r11.mo1249r1(r12, r13, r4)
        L_0x0431:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo1249r1(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w, boolean):void");
    }

    /* renamed from: s0 */
    public void mo874s0(RecyclerView recyclerView) {
        this.f949C.mo1261a();
        mo1129N0();
    }

    /* renamed from: s1 */
    public final boolean mo1250s1(int i) {
        if (this.f964u == 0) {
            return (i == -1) != this.f968y;
        }
        return ((i == -1) == this.f968y) == mo1247p1();
    }

    /* renamed from: t0 */
    public void mo875t0(RecyclerView recyclerView, int i, int i2, int i3) {
        mo1245n1(i, i2, 8);
    }

    /* renamed from: t1 */
    public void mo1251t1(int i, RecyclerView.C0178w wVar) {
        int i2;
        int i3;
        if (i > 0) {
            i3 = mo1242k1();
            i2 = 1;
        } else {
            i3 = mo1241j1();
            i2 = -1;
        }
        this.f966w.f1300a = true;
        mo1229B1(i3, wVar);
        mo1257z1(i2);
        C0274bb bbVar = this.f966w;
        bbVar.f1302c = i3 + bbVar.f1303d;
        bbVar.f1301b = Math.abs(i);
    }

    /* renamed from: u */
    public RecyclerView.C0167n mo877u() {
        return this.f964u == 0 ? new C0184c(-2, -1) : new C0184c(-1, -2);
    }

    /* renamed from: u0 */
    public void mo878u0(RecyclerView recyclerView, int i, int i2) {
        mo1245n1(i, i2, 2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0011, code lost:
        if (r6.f1304e == -1) goto L_0x0013;
     */
    /* renamed from: u1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1252u1(androidx.recyclerview.widget.RecyclerView.C0173s r5, p000.C0274bb r6) {
        /*
            r4 = this;
            boolean r0 = r6.f1300a
            if (r0 == 0) goto L_0x007c
            boolean r0 = r6.f1308i
            if (r0 == 0) goto L_0x000a
            goto L_0x007c
        L_0x000a:
            int r0 = r6.f1301b
            r1 = -1
            if (r0 != 0) goto L_0x001f
            int r0 = r6.f1304e
            if (r0 != r1) goto L_0x0019
        L_0x0013:
            int r6 = r6.f1306g
        L_0x0015:
            r4.mo1253v1(r5, r6)
            goto L_0x007c
        L_0x0019:
            int r6 = r6.f1305f
        L_0x001b:
            r4.mo1254w1(r5, r6)
            goto L_0x007c
        L_0x001f:
            int r0 = r6.f1304e
            r2 = 0
            r3 = 1
            if (r0 != r1) goto L_0x0050
            int r0 = r6.f1305f
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.f961r
            r1 = r1[r2]
            int r1 = r1.mo1286k(r0)
        L_0x002f:
            int r2 = r4.f960q
            if (r3 >= r2) goto L_0x0041
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.f961r
            r2 = r2[r3]
            int r2 = r2.mo1286k(r0)
            if (r2 <= r1) goto L_0x003e
            r1 = r2
        L_0x003e:
            int r3 = r3 + 1
            goto L_0x002f
        L_0x0041:
            int r0 = r0 - r1
            if (r0 >= 0) goto L_0x0045
            goto L_0x0013
        L_0x0045:
            int r1 = r6.f1306g
            int r6 = r6.f1301b
            int r6 = java.lang.Math.min(r0, r6)
            int r6 = r1 - r6
            goto L_0x0015
        L_0x0050:
            int r0 = r6.f1306g
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.f961r
            r1 = r1[r2]
            int r1 = r1.mo1283h(r0)
        L_0x005a:
            int r2 = r4.f960q
            if (r3 >= r2) goto L_0x006c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.f961r
            r2 = r2[r3]
            int r2 = r2.mo1283h(r0)
            if (r2 >= r1) goto L_0x0069
            r1 = r2
        L_0x0069:
            int r3 = r3 + 1
            goto L_0x005a
        L_0x006c:
            int r0 = r6.f1306g
            int r1 = r1 - r0
            if (r1 >= 0) goto L_0x0072
            goto L_0x0019
        L_0x0072:
            int r0 = r6.f1305f
            int r6 = r6.f1301b
            int r6 = java.lang.Math.min(r1, r6)
            int r6 = r6 + r0
            goto L_0x001b
        L_0x007c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo1252u1(androidx.recyclerview.widget.RecyclerView$s, bb):void");
    }

    /* renamed from: v */
    public RecyclerView.C0167n mo880v(Context context, AttributeSet attributeSet) {
        return new C0184c(context, attributeSet);
    }

    /* renamed from: v1 */
    public final void mo1253v1(RecyclerView.C0173s sVar, int i) {
        int z = mo1166z() - 1;
        while (z >= 0) {
            View y = mo1165y(z);
            if (this.f962s.mo2974e(y) >= i && this.f962s.mo2983o(y) >= i) {
                C0184c cVar = (C0184c) y.getLayoutParams();
                Objects.requireNonNull(cVar);
                if (cVar.f978h.f995a.size() != 1) {
                    cVar.f978h.mo1287l();
                    mo1123K0(y, sVar);
                    z--;
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: w */
    public RecyclerView.C0167n mo881w(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0184c((ViewGroup.MarginLayoutParams) layoutParams) : new C0184c(layoutParams);
    }

    /* renamed from: w0 */
    public void mo882w0(RecyclerView recyclerView, int i, int i2, Object obj) {
        mo1245n1(i, i2, 4);
    }

    /* renamed from: w1 */
    public final void mo1254w1(RecyclerView.C0173s sVar, int i) {
        while (mo1166z() > 0) {
            View y = mo1165y(0);
            if (this.f962s.mo2971b(y) <= i && this.f962s.mo2982n(y) <= i) {
                C0184c cVar = (C0184c) y.getLayoutParams();
                Objects.requireNonNull(cVar);
                if (cVar.f978h.f995a.size() != 1) {
                    cVar.f978h.mo1288m();
                    mo1123K0(y, sVar);
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: x0 */
    public void mo883x0(RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        mo1249r1(sVar, wVar, true);
    }

    /* renamed from: x1 */
    public final void mo1255x1() {
        this.f968y = (this.f964u == 1 || !mo1247p1()) ? this.f967x : !this.f967x;
    }

    /* renamed from: y0 */
    public void mo884y0(RecyclerView.C0178w wVar) {
        this.f947A = -1;
        this.f948B = Integer.MIN_VALUE;
        this.f953G = null;
        this.f956J.mo1260b();
    }

    /* renamed from: y1 */
    public int mo1256y1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (mo1166z() == 0 || i == 0) {
            return 0;
        }
        mo1251t1(i, wVar);
        int e1 = mo1236e1(sVar, this.f966w, wVar);
        if (this.f966w.f1301b >= e1) {
            i = i < 0 ? -e1 : e1;
        }
        this.f962s.mo2984p(-i);
        this.f951E = this.f968y;
        C0274bb bbVar = this.f966w;
        bbVar.f1301b = 0;
        mo1252u1(sVar, bbVar);
        return i;
    }

    /* renamed from: z1 */
    public final void mo1257z1(int i) {
        C0274bb bbVar = this.f966w;
        bbVar.f1304e = i;
        int i2 = 1;
        if (this.f968y != (i == -1)) {
            i2 = -1;
        }
        bbVar.f1303d = i2;
    }
}
