package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import org.fasaroid.fira.R;

public class CardView extends FrameLayout {

    /* renamed from: k */
    public static final int[] f537k = {16842801};

    /* renamed from: l */
    public static final C1843u3 f538l;

    /* renamed from: d */
    public boolean f539d;

    /* renamed from: e */
    public boolean f540e;

    /* renamed from: f */
    public int f541f;

    /* renamed from: g */
    public int f542g;

    /* renamed from: h */
    public final Rect f543h;

    /* renamed from: i */
    public final Rect f544i = new Rect();

    /* renamed from: j */
    public final C1777t3 f545j;

    /* renamed from: androidx.cardview.widget.CardView$a */
    public class C0117a implements C1777t3 {

        /* renamed from: a */
        public Drawable f546a;

        public C0117a() {
        }

        /* renamed from: a */
        public boolean mo599a() {
            return CardView.this.getPreventCornerOverlap();
        }

        /* renamed from: b */
        public void mo600b(int i, int i2, int i3, int i4) {
            CardView.this.f544i.set(i, i2, i3, i4);
            CardView cardView = CardView.this;
            Rect rect = cardView.f543h;
            CardView.super.setPadding(i + rect.left, i2 + rect.top, i3 + rect.right, i4 + rect.bottom);
        }
    }

    static {
        C1843u3 r3Var = Build.VERSION.SDK_INT >= 21 ? new C1655r3() : new C1475q3();
        f538l = r3Var;
        r3Var.mo5314n();
    }

    public CardView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.cardViewStyle);
        int i;
        Resources resources;
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.f543h = rect;
        C0117a aVar = new C0117a();
        this.f545j = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1399p3.f4772a, R.attr.cardViewStyle, R.style.CardView);
        if (obtainStyledAttributes.hasValue(2)) {
            valueOf = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f537k);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i = R.color.cardview_light_background;
            } else {
                resources = getResources();
                i = R.color.cardview_dark_background;
            }
            valueOf = ColorStateList.valueOf(resources.getColor(i));
        }
        ColorStateList colorStateList = valueOf;
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(5, 0.0f);
        this.f539d = obtainStyledAttributes.getBoolean(7, false);
        this.f540e = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        float f = dimension2 > dimension3 ? dimension2 : dimension3;
        this.f541f = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f542g = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        f538l.mo5646h(aVar, context, colorStateList, dimension, dimension2, f);
    }

    public ColorStateList getCardBackgroundColor() {
        return f538l.mo5644f(this.f545j);
    }

    public float getCardElevation() {
        return f538l.mo5650l(this.f545j);
    }

    public int getContentPaddingBottom() {
        return this.f543h.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f543h.left;
    }

    public int getContentPaddingRight() {
        return this.f543h.right;
    }

    public int getContentPaddingTop() {
        return this.f543h.top;
    }

    public float getMaxCardElevation() {
        return f538l.mo5639a(this.f545j);
    }

    public boolean getPreventCornerOverlap() {
        return this.f540e;
    }

    public float getRadius() {
        return f538l.mo5640b(this.f545j);
    }

    public boolean getUseCompatPadding() {
        return this.f539d;
    }

    public void onMeasure(int i, int i2) {
        C1843u3 u3Var = f538l;
        if (!(u3Var instanceof C1655r3)) {
            int mode = View.MeasureSpec.getMode(i);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) u3Var.mo5642d(this.f545j)), View.MeasureSpec.getSize(i)), mode);
            }
            int mode2 = View.MeasureSpec.getMode(i2);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) u3Var.mo5641c(this.f545j)), View.MeasureSpec.getSize(i2)), mode2);
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        f538l.mo5649k(this.f545j, ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        f538l.mo5649k(this.f545j, colorStateList);
    }

    public void setCardElevation(float f) {
        f538l.mo5645g(this.f545j, f);
    }

    public void setMaxCardElevation(float f) {
        f538l.mo5651m(this.f545j, f);
    }

    public void setMinimumHeight(int i) {
        this.f542g = i;
        super.setMinimumHeight(i);
    }

    public void setMinimumWidth(int i) {
        this.f541f = i;
        super.setMinimumWidth(i);
    }

    public void setPadding(int i, int i2, int i3, int i4) {
    }

    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.f540e) {
            this.f540e = z;
            f538l.mo5648j(this.f545j);
        }
    }

    public void setRadius(float f) {
        f538l.mo5647i(this.f545j, f);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f539d != z) {
            this.f539d = z;
            f538l.mo5643e(this.f545j);
        }
    }
}
