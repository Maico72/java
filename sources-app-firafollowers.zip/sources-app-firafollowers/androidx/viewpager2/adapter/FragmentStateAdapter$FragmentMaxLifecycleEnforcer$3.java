package androidx.viewpager2.adapter;

import p000.C1409p9;

public class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements C1491q9 {
    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        throw null;
    }
}
