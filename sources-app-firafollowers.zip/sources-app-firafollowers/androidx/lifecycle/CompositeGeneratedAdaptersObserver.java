package androidx.lifecycle;

import p000.C1409p9;

public class CompositeGeneratedAdaptersObserver implements C1491q9 {

    /* renamed from: a */
    public final C1320o9[] f697a;

    public CompositeGeneratedAdaptersObserver(C1320o9[] o9VarArr) {
        this.f697a = o9VarArr;
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        C1985w9 w9Var = new C1985w9();
        for (C1320o9 a : this.f697a) {
            a.mo5023a(s9Var, aVar, false, w9Var);
        }
        for (C1320o9 a2 : this.f697a) {
            a2.mo5023a(s9Var, aVar, true, w9Var);
        }
    }
}
