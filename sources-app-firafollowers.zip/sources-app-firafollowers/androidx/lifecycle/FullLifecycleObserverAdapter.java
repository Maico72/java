package androidx.lifecycle;

import p000.C1409p9;

public class FullLifecycleObserverAdapter implements C1491q9 {

    /* renamed from: a */
    public final C1241n9 f698a;

    /* renamed from: b */
    public final C1491q9 f699b;

    public FullLifecycleObserverAdapter(C1241n9 n9Var, C1491q9 q9Var) {
        this.f698a = n9Var;
        this.f699b = q9Var;
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.f698a.mo4819c(s9Var);
                break;
            case 1:
                this.f698a.mo4822g(s9Var);
                break;
            case 2:
                this.f698a.mo4817a(s9Var);
                break;
            case 3:
                this.f698a.mo4820e(s9Var);
                break;
            case 4:
                this.f698a.mo4821f(s9Var);
                break;
            case 5:
                this.f698a.mo4818b(s9Var);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        C1491q9 q9Var = this.f699b;
        if (q9Var != null) {
            q9Var.mo158d(s9Var, aVar);
        }
    }
}
