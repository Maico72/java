package androidx.lifecycle;

import java.util.Map;
import p000.C1409p9;

public abstract class LiveData<T> {

    /* renamed from: i */
    public static final Object f700i = new Object();

    /* renamed from: a */
    public final Object f701a = new Object();

    /* renamed from: b */
    public C1294o3<C2128y9<? super T>, LiveData<T>.C0000a> f702b = new C1294o3<>();

    /* renamed from: c */
    public int f703c = 0;

    /* renamed from: d */
    public volatile Object f704d;

    /* renamed from: e */
    public volatile Object f705e;

    /* renamed from: f */
    public int f706f;

    /* renamed from: g */
    public boolean f707g;

    /* renamed from: h */
    public boolean f708h;

    public class LifecycleBoundObserver extends LiveData<T>.C0000a implements Object {

        /* renamed from: e */
        public final C1725s9 f709e;

        /* renamed from: f */
        public final /* synthetic */ LiveData f710f;

        /* renamed from: d */
        public void mo843d(C1725s9 s9Var, C1409p9.C1410a aVar) {
            if (((C1785t9) this.f709e.mo150a()).f5891b == C1409p9.C1411b.DESTROYED) {
                this.f710f.mo842f(this.f711a);
            } else {
                mo846h(mo845j());
            }
        }

        /* renamed from: i */
        public void mo844i() {
            ((C1785t9) this.f709e.mo150a()).f5890a.mo4711d(this);
        }

        /* renamed from: j */
        public boolean mo845j() {
            return ((C1785t9) this.f709e.mo150a()).f5891b.compareTo(C1409p9.C1411b.STARTED) >= 0;
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$a */
    public abstract class C0137a {

        /* renamed from: a */
        public final C2128y9<? super T> f711a;

        /* renamed from: b */
        public boolean f712b;

        /* renamed from: c */
        public int f713c;

        /* renamed from: d */
        public final /* synthetic */ LiveData f714d;

        /* renamed from: h */
        public void mo846h(boolean z) {
            if (z != this.f712b) {
                this.f712b = z;
                LiveData liveData = this.f714d;
                int i = liveData.f703c;
                int i2 = 1;
                boolean z2 = i == 0;
                if (!z) {
                    i2 = -1;
                }
                liveData.f703c = i + i2;
                if (z2 && z) {
                    liveData.mo840d();
                }
                LiveData liveData2 = this.f714d;
                if (liveData2.f703c == 0 && !this.f712b) {
                    liveData2.mo841e();
                }
                if (this.f712b) {
                    this.f714d.mo839c(this);
                }
            }
        }

        /* renamed from: i */
        public void mo844i() {
        }

        /* renamed from: j */
        public abstract boolean mo845j();
    }

    public LiveData() {
        Object obj = f700i;
        this.f704d = obj;
        this.f705e = obj;
        this.f706f = -1;
    }

    /* renamed from: a */
    public static void m393a(String str) {
        if (!C0995k3.m3153b().f3573a.mo4250a()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }

    /* renamed from: b */
    public final void mo838b(LiveData<T>.C0000a aVar) {
        if (aVar.f712b) {
            if (!aVar.mo845j()) {
                aVar.mo846h(false);
                return;
            }
            int i = aVar.f713c;
            int i2 = this.f706f;
            if (i < i2) {
                aVar.f713c = i2;
                aVar.f711a.mo6676a(this.f704d);
            }
        }
    }

    /* renamed from: c */
    public void mo839c(LiveData<T>.C0000a aVar) {
        if (this.f707g) {
            this.f708h = true;
            return;
        }
        this.f707g = true;
        do {
            this.f708h = false;
            if (aVar == null) {
                C1294o3<K, V>.C0520d b = this.f702b.mo4978b();
                while (b.hasNext()) {
                    mo838b((C0137a) ((Map.Entry) b.next()).getValue());
                    if (this.f708h) {
                        break;
                    }
                }
            } else {
                mo838b(aVar);
                aVar = null;
            }
        } while (this.f708h);
        this.f707g = false;
    }

    /* renamed from: d */
    public void mo840d() {
    }

    /* renamed from: e */
    public void mo841e() {
    }

    /* renamed from: f */
    public void mo842f(C2128y9<? super T> y9Var) {
        m393a("removeObserver");
        C0137a d = this.f702b.mo4711d(y9Var);
        if (d != null) {
            d.mo844i();
            d.mo846h(false);
        }
    }
}
