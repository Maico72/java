package androidx.lifecycle;

import p000.C1409p9;

public class SingleGeneratedAdapterObserver implements C1491q9 {

    /* renamed from: a */
    public final C1320o9 f717a;

    public SingleGeneratedAdapterObserver(C1320o9 o9Var) {
        this.f717a = o9Var;
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        this.f717a.mo5023a(s9Var, aVar, false, (C1985w9) null);
        this.f717a.mo5023a(s9Var, aVar, true, (C1985w9) null);
    }
}
