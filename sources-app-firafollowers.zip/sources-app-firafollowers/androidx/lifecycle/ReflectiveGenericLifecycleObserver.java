package androidx.lifecycle;

import p000.C1167m9;
import p000.C1409p9;

public class ReflectiveGenericLifecycleObserver implements C1491q9 {

    /* renamed from: a */
    public final Object f715a;

    /* renamed from: b */
    public final C1167m9.C1168a f716b;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f715a = obj;
        this.f716b = C1167m9.f4012c.mo4599b(obj.getClass());
    }

    /* renamed from: d */
    public void mo158d(C1725s9 s9Var, C1409p9.C1410a aVar) {
        C1167m9.C1168a aVar2 = this.f716b;
        Object obj = this.f715a;
        C1167m9.C1168a.m3672a(aVar2.f4015a.get(aVar), s9Var, aVar, obj);
        C1167m9.C1168a.m3672a(aVar2.f4015a.get(C1409p9.C1410a.ON_ANY), s9Var, aVar, obj);
    }
}
