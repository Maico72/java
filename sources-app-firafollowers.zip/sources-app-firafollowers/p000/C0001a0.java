package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.WeakHashMap;

@SuppressLint({"RestrictedAPI"})
/* renamed from: a0 */
public final class C0001a0 {

    /* renamed from: a */
    public static final ThreadLocal<TypedValue> f0a = new ThreadLocal<>();

    /* renamed from: b */
    public static final WeakHashMap<Context, SparseArray<C0002a>> f1b = new WeakHashMap<>(0);

    /* renamed from: c */
    public static final Object f2c = new Object();

    /* renamed from: a0$a */
    public static class C0002a {

        /* renamed from: a */
        public final ColorStateList f3a;

        /* renamed from: b */
        public final Configuration f4b;

        public C0002a(ColorStateList colorStateList, Configuration configuration) {
            this.f3a = colorStateList;
            this.f4b = configuration;
        }
    }

    /* renamed from: a */
    public static ColorStateList m0a(Context context, int i) {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        C0002a aVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23) {
            return context.getColorStateList(i);
        }
        synchronized (f2c) {
            SparseArray sparseArray = f1b.get(context);
            colorStateList = null;
            if (!(sparseArray == null || sparseArray.size() <= 0 || (aVar = (C0002a) sparseArray.get(i)) == null)) {
                if (aVar.f4b.equals(context.getResources().getConfiguration())) {
                    colorStateList2 = aVar.f3a;
                } else {
                    sparseArray.remove(i);
                }
            }
            colorStateList2 = null;
        }
        if (colorStateList2 != null) {
            return colorStateList2;
        }
        Resources resources = context.getResources();
        ThreadLocal<TypedValue> threadLocal = f0a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue == null) {
            typedValue = new TypedValue();
            threadLocal.set(typedValue);
        }
        boolean z = true;
        resources.getValue(i, typedValue, true);
        int i3 = typedValue.type;
        if (i3 < 28 || i3 > 31) {
            z = false;
        }
        if (!z) {
            Resources resources2 = context.getResources();
            try {
                colorStateList = C1401p4.m4378o(resources2, resources2.getXml(i), context.getTheme());
            } catch (Exception e) {
                Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", e);
            }
        }
        if (colorStateList != null) {
            synchronized (f2c) {
                WeakHashMap<Context, SparseArray<C0002a>> weakHashMap = f1b;
                SparseArray sparseArray2 = weakHashMap.get(context);
                if (sparseArray2 == null) {
                    sparseArray2 = new SparseArray();
                    weakHashMap.put(context, sparseArray2);
                }
                sparseArray2.append(i, new C0002a(colorStateList, context.getResources().getConfiguration()));
            }
            return colorStateList;
        }
        Object obj = C1901v4.f6251a;
        return i2 >= 23 ? context.getColorStateList(i) : context.getResources().getColorStateList(i);
    }

    /* renamed from: b */
    public static Drawable m1b(Context context, int i) {
        return C1710s2.m4883d().mo5792f(context, i);
    }
}
