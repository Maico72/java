package p000;

/* renamed from: do */
public interface C0575do<R> {
}
