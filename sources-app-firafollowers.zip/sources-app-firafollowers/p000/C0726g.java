package p000;

import android.view.View;
import androidx.appcompat.app.AlertController;
import androidx.core.widget.NestedScrollView;

/* renamed from: g */
public class C0726g implements NestedScrollView.C0130b {

    /* renamed from: a */
    public final /* synthetic */ View f2803a;

    /* renamed from: b */
    public final /* synthetic */ View f2804b;

    public C0726g(AlertController alertController, View view, View view2) {
        this.f2803a = view;
        this.f2804b = view2;
    }
}
