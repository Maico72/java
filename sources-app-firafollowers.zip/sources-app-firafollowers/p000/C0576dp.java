package p000;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Locale;
import java.util.Objects;
import java.util.TimeZone;

@Target({ElementType.ANNOTATION_TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: dp */
public @interface C0576dp {

    /* renamed from: dp$a */
    public enum C0577a {
        ACCEPT_SINGLE_VALUE_AS_ARRAY,
        ACCEPT_CASE_INSENSITIVE_PROPERTIES,
        ACCEPT_CASE_INSENSITIVE_VALUES,
        WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS,
        WRITE_DATES_WITH_ZONE_ID,
        WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED,
        WRITE_SORTED_MAP_ENTRIES,
        ADJUST_DATES_TO_CONTEXT_TIME_ZONE
    }

    /* renamed from: dp$b */
    public static class C0578b {

        /* renamed from: c */
        public static final C0578b f2325c = new C0578b(0, 0);

        /* renamed from: a */
        public final int f2326a;

        /* renamed from: b */
        public final int f2327b;

        public C0578b(int i, int i2) {
            this.f2326a = i;
            this.f2327b = i2;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj == null || obj.getClass() != C0578b.class) {
                return false;
            }
            C0578b bVar = (C0578b) obj;
            return bVar.f2326a == this.f2326a && bVar.f2327b == this.f2327b;
        }

        public int hashCode() {
            return this.f2327b + this.f2326a;
        }

        public String toString() {
            if (this == f2325c) {
                return "EMPTY";
            }
            return String.format("(enabled=0x%x,disabled=0x%x)", new Object[]{Integer.valueOf(this.f2326a), Integer.valueOf(this.f2327b)});
        }
    }

    /* renamed from: dp$c */
    public enum C0579c {
        ANY,
        NATURAL,
        SCALAR,
        ARRAY,
        OBJECT,
        NUMBER,
        NUMBER_FLOAT,
        NUMBER_INT,
        STRING,
        BOOLEAN,
        BINARY;

        /* renamed from: a */
        public boolean mo3086a() {
            return this == NUMBER || this == NUMBER_INT || this == NUMBER_FLOAT;
        }
    }

    /* renamed from: dp$d */
    public static class C0580d implements Object<C0576dp> {

        /* renamed from: k */
        public static final C0580d f2340k = new C0580d("", C0579c.ANY, "", "", C0578b.f2325c, (Boolean) null);

        /* renamed from: d */
        public final String f2341d;

        /* renamed from: e */
        public final C0579c f2342e;

        /* renamed from: f */
        public final Locale f2343f;

        /* renamed from: g */
        public final String f2344g;

        /* renamed from: h */
        public final Boolean f2345h;

        /* renamed from: i */
        public final C0578b f2346i;

        /* renamed from: j */
        public transient TimeZone f2347j;

        public C0580d() {
            this("", C0579c.ANY, "", "", C0578b.f2325c, (Boolean) null);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0580d(java.lang.String r14, p000.C0576dp.C0579c r15, java.lang.String r16, java.lang.String r17, p000.C0576dp.C0578b r18, java.lang.Boolean r19) {
            /*
                r13 = this;
                r0 = r16
                r1 = r17
                java.lang.String r2 = "##default"
                r3 = 0
                if (r0 == 0) goto L_0x001d
                int r4 = r16.length()
                if (r4 == 0) goto L_0x001d
                boolean r4 = r2.equals(r0)
                if (r4 == 0) goto L_0x0016
                goto L_0x001d
            L_0x0016:
                java.util.Locale r4 = new java.util.Locale
                r4.<init>(r0)
                r8 = r4
                goto L_0x001e
            L_0x001d:
                r8 = r3
            L_0x001e:
                if (r1 == 0) goto L_0x002f
                int r0 = r17.length()
                if (r0 == 0) goto L_0x002f
                boolean r0 = r2.equals(r1)
                if (r0 == 0) goto L_0x002d
                goto L_0x002f
            L_0x002d:
                r9 = r1
                goto L_0x0030
            L_0x002f:
                r9 = r3
            L_0x0030:
                r10 = 0
                r5 = r13
                r6 = r14
                r7 = r15
                r11 = r18
                r12 = r19
                r5.<init>(r6, r7, r8, r9, r10, r11, r12)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0576dp.C0580d.<init>(java.lang.String, dp$c, java.lang.String, java.lang.String, dp$b, java.lang.Boolean):void");
        }

        public C0580d(String str, C0579c cVar, Locale locale, String str2, TimeZone timeZone, C0578b bVar, Boolean bool) {
            this.f2341d = str == null ? "" : str;
            this.f2342e = cVar == null ? C0579c.ANY : cVar;
            this.f2343f = locale;
            this.f2347j = timeZone;
            this.f2344g = str2;
            this.f2346i = bVar == null ? C0578b.f2325c : bVar;
            this.f2345h = bool;
        }

        /* renamed from: a */
        public static <T> boolean m1828a(T t, T t2) {
            if (t == null) {
                return t2 == null;
            }
            if (t2 == null) {
                return false;
            }
            return t.equals(t2);
        }

        /* renamed from: b */
        public Boolean mo3087b(C0577a aVar) {
            C0578b bVar = this.f2346i;
            Objects.requireNonNull(bVar);
            int ordinal = 1 << aVar.ordinal();
            if ((bVar.f2327b & ordinal) != 0) {
                return Boolean.FALSE;
            }
            if ((ordinal & bVar.f2326a) != 0) {
                return Boolean.TRUE;
            }
            return null;
        }

        /* renamed from: c */
        public TimeZone mo3088c() {
            TimeZone timeZone = this.f2347j;
            if (timeZone != null) {
                return timeZone;
            }
            String str = this.f2344g;
            if (str == null) {
                return null;
            }
            TimeZone timeZone2 = TimeZone.getTimeZone(str);
            this.f2347j = timeZone2;
            return timeZone2;
        }

        /* renamed from: d */
        public boolean mo3089d() {
            return this.f2343f != null;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
            r0 = r1.f2344g;
         */
        /* renamed from: e */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo3090e() {
            /*
                r1 = this;
                java.util.TimeZone r0 = r1.f2347j
                if (r0 != 0) goto L_0x0011
                java.lang.String r0 = r1.f2344g
                if (r0 == 0) goto L_0x000f
                boolean r0 = r0.isEmpty()
                if (r0 != 0) goto L_0x000f
                goto L_0x0011
            L_0x000f:
                r0 = 0
                goto L_0x0012
            L_0x0011:
                r0 = 1
            L_0x0012:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0576dp.C0580d.mo3090e():boolean");
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj == null || obj.getClass() != C0580d.class) {
                return false;
            }
            C0580d dVar = (C0580d) obj;
            return this.f2342e == dVar.f2342e && this.f2346i.equals(dVar.f2346i) && m1828a(this.f2345h, dVar.f2345h) && m1828a(this.f2344g, dVar.f2344g) && m1828a(this.f2341d, dVar.f2341d) && m1828a(this.f2347j, dVar.f2347j) && m1828a(this.f2343f, dVar.f2343f);
        }

        /* renamed from: f */
        public final C0580d mo3092f(C0580d dVar) {
            C0580d dVar2;
            TimeZone timeZone;
            String str;
            if (dVar == null || dVar == (dVar2 = f2340k) || dVar == this) {
                return this;
            }
            if (this == dVar2) {
                return dVar;
            }
            String str2 = dVar.f2341d;
            if (str2 == null || str2.isEmpty()) {
                str2 = this.f2341d;
            }
            String str3 = str2;
            C0579c cVar = dVar.f2342e;
            if (cVar == C0579c.ANY) {
                cVar = this.f2342e;
            }
            C0579c cVar2 = cVar;
            Locale locale = dVar.f2343f;
            if (locale == null) {
                locale = this.f2343f;
            }
            Locale locale2 = locale;
            C0578b bVar = this.f2346i;
            if (bVar == null) {
                bVar = dVar.f2346i;
            } else {
                C0578b bVar2 = dVar.f2346i;
                if (bVar2 != null) {
                    int i = bVar2.f2327b;
                    int i2 = bVar2.f2326a;
                    if (!(i == 0 && i2 == 0)) {
                        int i3 = bVar.f2326a;
                        if (i3 == 0 && bVar.f2327b == 0) {
                            bVar = bVar2;
                        } else {
                            int i4 = ((i ^ -1) & i3) | i2;
                            int i5 = bVar.f2327b;
                            int i6 = i | ((i2 ^ -1) & i5);
                            if (!(i4 == i3 && i6 == i5)) {
                                bVar = new C0578b(i4, i6);
                            }
                        }
                    }
                }
            }
            C0578b bVar3 = bVar;
            Boolean bool = dVar.f2345h;
            if (bool == null) {
                bool = this.f2345h;
            }
            Boolean bool2 = bool;
            String str4 = dVar.f2344g;
            if (str4 == null || str4.isEmpty()) {
                str = this.f2344g;
                timeZone = this.f2347j;
            } else {
                timeZone = dVar.f2347j;
                str = str4;
            }
            return new C0580d(str3, cVar2, locale2, str, timeZone, bVar3, bool2);
        }

        public int hashCode() {
            String str = this.f2344g;
            int hashCode = str == null ? 1 : str.hashCode();
            String str2 = this.f2341d;
            if (str2 != null) {
                hashCode ^= str2.hashCode();
            }
            int hashCode2 = this.f2342e.hashCode() + hashCode;
            Boolean bool = this.f2345h;
            if (bool != null) {
                hashCode2 ^= bool.hashCode();
            }
            Locale locale = this.f2343f;
            if (locale != null) {
                hashCode2 += locale.hashCode();
            }
            return this.f2346i.hashCode() ^ hashCode2;
        }

        public String toString() {
            return String.format("JsonFormat.Value(pattern=%s,shape=%s,lenient=%s,locale=%s,timezone=%s,features=%s)", new Object[]{this.f2341d, this.f2342e, this.f2345h, this.f2343f, this.f2344g, this.f2346i});
        }
    }

    C0790gq lenient() default C0790gq.f2983f;

    String locale() default "##default";

    String pattern() default "";

    C0579c shape() default C0579c.ANY;

    String timezone() default "##default";

    C0577a[] with() default {};

    C0577a[] without() default {};
}
