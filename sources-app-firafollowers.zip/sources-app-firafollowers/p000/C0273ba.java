package p000;

import java.util.HashMap;
import java.util.Map;

/* renamed from: ba */
public abstract class C0273ba {

    /* renamed from: a */
    public final Map<String, Object> f1298a = new HashMap();

    /* renamed from: a */
    public void mo1691a() {
    }
}
