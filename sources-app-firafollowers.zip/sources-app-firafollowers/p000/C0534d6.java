package p000;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/* renamed from: d6 */
public class C0534d6 {

    /* renamed from: a */
    public final Object f2168a = new Object();

    /* renamed from: b */
    public HandlerThread f2169b;

    /* renamed from: c */
    public Handler f2170c;

    /* renamed from: d */
    public int f2171d = 0;

    /* renamed from: e */
    public Handler.Callback f2172e = new C0535a();

    /* renamed from: d6$a */
    public class C0535a implements Handler.Callback {
        public C0535a() {
        }

        public boolean handleMessage(Message message) {
            int i = message.what;
            if (i == 0) {
                C0534d6 d6Var = C0534d6.this;
                synchronized (d6Var.f2168a) {
                    if (!d6Var.f2170c.hasMessages(1)) {
                        d6Var.f2169b.quit();
                        d6Var.f2169b = null;
                        d6Var.f2170c = null;
                    }
                }
                return true;
            } else if (i != 1) {
                return true;
            } else {
                C0534d6 d6Var2 = C0534d6.this;
                Objects.requireNonNull(d6Var2);
                ((Runnable) message.obj).run();
                synchronized (d6Var2.f2168a) {
                    d6Var2.f2170c.removeMessages(0);
                    Handler handler = d6Var2.f2170c;
                    handler.sendMessageDelayed(handler.obtainMessage(0), (long) 10000);
                }
                return true;
            }
        }
    }

    /* renamed from: d6$b */
    public class C0536b implements Runnable {

        /* renamed from: d */
        public final /* synthetic */ AtomicReference f2174d;

        /* renamed from: e */
        public final /* synthetic */ Callable f2175e;

        /* renamed from: f */
        public final /* synthetic */ ReentrantLock f2176f;

        /* renamed from: g */
        public final /* synthetic */ AtomicBoolean f2177g;

        /* renamed from: h */
        public final /* synthetic */ Condition f2178h;

        public C0536b(C0534d6 d6Var, AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.f2174d = atomicReference;
            this.f2175e = callable;
            this.f2176f = reentrantLock;
            this.f2177g = atomicBoolean;
            this.f2178h = condition;
        }

        public void run() {
            try {
                this.f2174d.set(this.f2175e.call());
            } catch (Exception unused) {
            }
            this.f2176f.lock();
            try {
                this.f2177g.set(false);
                this.f2178h.signal();
            } finally {
                this.f2176f.unlock();
            }
        }
    }

    /* renamed from: d6$c */
    public interface C0537c<T> {
        /* renamed from: a */
        void mo26a(T t);
    }

    public C0534d6(String str, int i, int i2) {
    }

    /* renamed from: a */
    public final void mo2950a(Runnable runnable) {
        synchronized (this.f2168a) {
            if (this.f2169b == null) {
                HandlerThread handlerThread = new HandlerThread("fonts", 10);
                this.f2169b = handlerThread;
                handlerThread.start();
                this.f2170c = new Handler(this.f2169b.getLooper(), this.f2172e);
                this.f2171d++;
            }
            this.f2170c.removeMessages(0);
            Handler handler = this.f2170c;
            handler.sendMessage(handler.obtainMessage(1, runnable));
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:9|10|11|12|(4:25|14|15|16)(1:17)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003f */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x004d  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0045 A[SYNTHETIC] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <T> T mo2951b(java.util.concurrent.Callable<T> r13, int r14) {
        /*
            r12 = this;
            java.util.concurrent.locks.ReentrantLock r7 = new java.util.concurrent.locks.ReentrantLock
            r7.<init>()
            java.util.concurrent.locks.Condition r8 = r7.newCondition()
            java.util.concurrent.atomic.AtomicReference r9 = new java.util.concurrent.atomic.AtomicReference
            r9.<init>()
            java.util.concurrent.atomic.AtomicBoolean r10 = new java.util.concurrent.atomic.AtomicBoolean
            r0 = 1
            r10.<init>(r0)
            d6$b r11 = new d6$b
            r0 = r11
            r1 = r12
            r2 = r9
            r3 = r13
            r4 = r7
            r5 = r10
            r6 = r8
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r12.mo2950a(r11)
            r7.lock()
            boolean r13 = r10.get()     // Catch:{ all -> 0x005c }
            if (r13 != 0) goto L_0x0034
            java.lang.Object r13 = r9.get()     // Catch:{ all -> 0x005c }
            r7.unlock()
            return r13
        L_0x0034:
            java.util.concurrent.TimeUnit r13 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ all -> 0x005c }
            long r0 = (long) r14     // Catch:{ all -> 0x005c }
            long r13 = r13.toNanos(r0)     // Catch:{ all -> 0x005c }
        L_0x003b:
            long r13 = r8.awaitNanos(r13)     // Catch:{ InterruptedException -> 0x003f }
        L_0x003f:
            boolean r0 = r10.get()     // Catch:{ all -> 0x005c }
            if (r0 != 0) goto L_0x004d
            java.lang.Object r13 = r9.get()     // Catch:{ all -> 0x005c }
            r7.unlock()
            return r13
        L_0x004d:
            r0 = 0
            int r2 = (r13 > r0 ? 1 : (r13 == r0 ? 0 : -1))
            if (r2 <= 0) goto L_0x0054
            goto L_0x003b
        L_0x0054:
            java.lang.InterruptedException r13 = new java.lang.InterruptedException     // Catch:{ all -> 0x005c }
            java.lang.String r14 = "timeout"
            r13.<init>(r14)     // Catch:{ all -> 0x005c }
            throw r13     // Catch:{ all -> 0x005c }
        L_0x005c:
            r13 = move-exception
            r7.unlock()
            goto L_0x0062
        L_0x0061:
            throw r13
        L_0x0062:
            goto L_0x0061
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0534d6.mo2951b(java.util.concurrent.Callable, int):java.lang.Object");
    }
}
