package p000;

import androidx.recyclerview.widget.RecyclerView;
import p000.C2130ya;

/* renamed from: jb */
public abstract class C0956jb extends RecyclerView.C0156j {

    /* renamed from: g */
    public boolean f3391g = true;

    /* renamed from: a */
    public boolean mo1097a(RecyclerView.C0181z zVar, RecyclerView.C0181z zVar2, RecyclerView.C0156j.C0159c cVar, RecyclerView.C0156j.C0159c cVar2) {
        int i;
        int i2;
        int i3 = cVar.f862a;
        int i4 = cVar.f863b;
        if (zVar2.mo1225t()) {
            int i5 = cVar.f862a;
            i = cVar.f863b;
            i2 = i5;
        } else {
            i2 = cVar2.f862a;
            i = cVar2.f863b;
        }
        C2130ya yaVar = (C2130ya) this;
        if (zVar == zVar2) {
            return yaVar.mo4153i(zVar, i3, i4, i2, i);
        }
        float translationX = zVar.f928a.getTranslationX();
        float translationY = zVar.f928a.getTranslationY();
        float alpha = zVar.f928a.getAlpha();
        yaVar.mo6682n(zVar);
        zVar.f928a.setTranslationX(translationX);
        zVar.f928a.setTranslationY(translationY);
        zVar.f928a.setAlpha(alpha);
        yaVar.mo6682n(zVar2);
        zVar2.f928a.setTranslationX((float) (-((int) (((float) (i2 - i3)) - translationX))));
        zVar2.f928a.setTranslationY((float) (-((int) (((float) (i - i4)) - translationY))));
        zVar2.f928a.setAlpha(0.0f);
        yaVar.f6885k.add(new C2130ya.C2131a(zVar, zVar2, i3, i4, i2, i));
        return true;
    }

    /* renamed from: i */
    public abstract boolean mo4153i(RecyclerView.C0181z zVar, int i, int i2, int i3, int i4);
}
