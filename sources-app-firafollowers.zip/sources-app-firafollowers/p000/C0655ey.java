package p000;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: ey */
public class C0655ey extends C0860hz<AtomicReference<?>> {
    public C0655ey(C0655ey eyVar, C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, b10 b10, Object obj, boolean z) {
        super(eyVar, fsVar, awVar, psVar, b10, obj, z);
    }

    public C0655ey(i00 i00, boolean z, C0230aw awVar, C1462ps<Object> psVar) {
        super(i00, awVar, psVar);
    }

    /* renamed from: q */
    public C0860hz<AtomicReference<?>> mo3416q(Object obj, boolean z) {
        return new C0655ey(this, this.f3166g, this.f3167h, this.f3168i, this.f3169j, obj, z);
    }

    /* renamed from: r */
    public C0860hz<AtomicReference<?>> mo3417r(C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, b10 b10) {
        return new C0655ey(this, fsVar, awVar, psVar, b10, this.f3171l, this.f3172m);
    }
}
