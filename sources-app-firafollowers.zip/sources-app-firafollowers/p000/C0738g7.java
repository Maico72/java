package p000;

import android.view.View;

/* renamed from: g7 */
public interface C0738g7 {
    void onAnimationCancel(View view);

    void onAnimationEnd(View view);

    void onAnimationStart(View view);
}
