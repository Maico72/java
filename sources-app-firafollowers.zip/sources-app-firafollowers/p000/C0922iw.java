package p000;

/* renamed from: iw */
public class C0922iw extends C0796gw {

    /* renamed from: c */
    public final String f3316c;

    public C0922iw(C1035ks ksVar, n00 n00, C2031wv wvVar) {
        super(ksVar, n00, wvVar);
        String name = ksVar.f3696d.getName();
        int lastIndexOf = name.lastIndexOf(46);
        if (lastIndexOf < 0) {
            this.f3316c = ".";
            return;
        }
        this.f3316c = name.substring(0, lastIndexOf + 1);
        name.substring(0, lastIndexOf);
    }

    /* renamed from: b */
    public String mo3839b(Object obj) {
        String name = obj.getClass().getName();
        return name.startsWith(this.f3316c) ? name.substring(this.f3316c.length() - 1) : name;
    }
}
