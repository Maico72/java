package p000;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* renamed from: g0 */
public abstract class C0727g0 {

    /* renamed from: d */
    public Object f2805d;

    /* renamed from: e */
    public boolean f2806e;

    /* renamed from: g0$a */
    public interface C0728a {
        /* renamed from: a */
        boolean mo3689a(C0727g0 g0Var, Menu menu);

        /* renamed from: b */
        boolean mo3690b(C0727g0 g0Var, MenuItem menuItem);

        /* renamed from: c */
        boolean mo3691c(C0727g0 g0Var, Menu menu);

        /* renamed from: d */
        void mo3692d(C0727g0 g0Var);
    }

    /* renamed from: c */
    public abstract void mo3675c();

    /* renamed from: d */
    public abstract View mo3676d();

    /* renamed from: e */
    public abstract Menu mo3677e();

    /* renamed from: f */
    public abstract MenuInflater mo3678f();

    /* renamed from: g */
    public abstract CharSequence mo3679g();

    /* renamed from: h */
    public abstract CharSequence mo3680h();

    /* renamed from: i */
    public abstract void mo3681i();

    /* renamed from: j */
    public abstract boolean mo3682j();

    /* renamed from: k */
    public abstract void mo3683k(View view);

    /* renamed from: l */
    public abstract void mo3684l(int i);

    /* renamed from: m */
    public abstract void mo3685m(CharSequence charSequence);

    /* renamed from: n */
    public abstract void mo3686n(int i);

    /* renamed from: o */
    public abstract void mo3687o(CharSequence charSequence);

    /* renamed from: p */
    public abstract void mo3688p(boolean z);
}
