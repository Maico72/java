package p000;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: fd */
public abstract class C0684fd {

    /* renamed from: a */
    public final C2047x3<String, Method> f2730a;

    /* renamed from: b */
    public final C2047x3<String, Method> f2731b;

    /* renamed from: c */
    public final C2047x3<String, Class> f2732c;

    public C0684fd(C2047x3<String, Method> x3Var, C2047x3<String, Method> x3Var2, C2047x3<String, Class> x3Var3) {
        this.f2730a = x3Var;
        this.f2731b = x3Var2;
        this.f2732c = x3Var3;
    }

    /* renamed from: a */
    public abstract void mo3554a();

    /* renamed from: b */
    public abstract C0684fd mo3555b();

    /* renamed from: c */
    public final Class mo3556c(Class<? extends C0828hd> cls) {
        Class orDefault = this.f2732c.getOrDefault(cls.getName(), null);
        if (orDefault != null) {
            return orDefault;
        }
        Class<?> cls2 = Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
        this.f2732c.put(cls.getName(), cls2);
        return cls2;
    }

    /* renamed from: d */
    public final Method mo3557d(String str) {
        Class<C0684fd> cls = C0684fd.class;
        Method orDefault = this.f2730a.getOrDefault(str, null);
        if (orDefault != null) {
            return orDefault;
        }
        System.currentTimeMillis();
        Method declaredMethod = Class.forName(str, true, cls.getClassLoader()).getDeclaredMethod("read", new Class[]{cls});
        this.f2730a.put(str, declaredMethod);
        return declaredMethod;
    }

    /* renamed from: e */
    public final Method mo3558e(Class cls) {
        Method orDefault = this.f2731b.getOrDefault(cls.getName(), null);
        if (orDefault != null) {
            return orDefault;
        }
        Class c = mo3556c(cls);
        System.currentTimeMillis();
        Method declaredMethod = c.getDeclaredMethod("write", new Class[]{cls, C0684fd.class});
        this.f2731b.put(cls.getName(), declaredMethod);
        return declaredMethod;
    }

    /* renamed from: f */
    public abstract boolean mo3559f();

    /* renamed from: g */
    public abstract byte[] mo3560g();

    /* renamed from: h */
    public abstract CharSequence mo3561h();

    /* renamed from: i */
    public abstract boolean mo3562i(int i);

    /* renamed from: j */
    public abstract int mo3563j();

    /* renamed from: k */
    public int mo3564k(int i, int i2) {
        return !mo3562i(i2) ? i : mo3563j();
    }

    /* renamed from: l */
    public abstract <T extends Parcelable> T mo3565l();

    /* renamed from: m */
    public <T extends Parcelable> T mo3566m(T t, int i) {
        return !mo3562i(i) ? t : mo3565l();
    }

    /* renamed from: n */
    public abstract String mo3567n();

    /* renamed from: o */
    public <T extends C0828hd> T mo3568o() {
        String n = mo3567n();
        if (n == null) {
            return null;
        }
        C0684fd b = mo3555b();
        try {
            return (C0828hd) mo3557d(n).invoke((Object) null, new Object[]{b});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: p */
    public abstract void mo3569p(int i);

    /* renamed from: q */
    public abstract void mo3570q(boolean z);

    /* renamed from: r */
    public abstract void mo3571r(byte[] bArr);

    /* renamed from: s */
    public abstract void mo3572s(CharSequence charSequence);

    /* renamed from: t */
    public abstract void mo3573t(int i);

    /* renamed from: u */
    public abstract void mo3574u(Parcelable parcelable);

    /* renamed from: v */
    public abstract void mo3575v(String str);

    /* renamed from: w */
    public void mo3576w(C0828hd hdVar) {
        if (hdVar == null) {
            mo3575v((String) null);
            return;
        }
        try {
            mo3575v(mo3556c(hdVar.getClass()).getName());
            C0684fd b = mo3555b();
            try {
                mo3558e(hdVar.getClass()).invoke((Object) null, new Object[]{hdVar, b});
                b.mo3554a();
            } catch (IllegalAccessException e) {
                throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
            } catch (InvocationTargetException e2) {
                if (e2.getCause() instanceof RuntimeException) {
                    throw ((RuntimeException) e2.getCause());
                }
                throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
            } catch (NoSuchMethodException e3) {
                throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
            } catch (ClassNotFoundException e4) {
                throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
            }
        } catch (ClassNotFoundException e5) {
            throw new RuntimeException(hdVar.getClass().getSimpleName() + " does not have a Parcelizer", e5);
        }
    }
}
