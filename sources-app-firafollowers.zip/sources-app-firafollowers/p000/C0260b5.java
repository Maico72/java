package p000;

import java.util.List;

/* renamed from: b5 */
public final class C0260b5 {

    /* renamed from: a */
    public final int[] f1253a;

    /* renamed from: b */
    public final float[] f1254b;

    public C0260b5(int i, int i2) {
        this.f1253a = new int[]{i, i2};
        this.f1254b = new float[]{0.0f, 1.0f};
    }

    public C0260b5(int i, int i2, int i3) {
        this.f1253a = new int[]{i, i2, i3};
        this.f1254b = new float[]{0.0f, 0.5f, 1.0f};
    }

    public C0260b5(List<Integer> list, List<Float> list2) {
        int size = list.size();
        this.f1253a = new int[size];
        this.f1254b = new float[size];
        for (int i = 0; i < size; i++) {
            this.f1253a[i] = list.get(i).intValue();
            this.f1254b[i] = list2.get(i).floatValue();
        }
    }
}
