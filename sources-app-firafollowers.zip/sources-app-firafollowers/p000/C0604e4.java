package p000;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* renamed from: e4 */
public class C0604e4<K, V> {

    /* renamed from: g */
    public static Object[] f2472g;

    /* renamed from: h */
    public static int f2473h;

    /* renamed from: i */
    public static Object[] f2474i;

    /* renamed from: j */
    public static int f2475j;

    /* renamed from: d */
    public int[] f2476d;

    /* renamed from: e */
    public Object[] f2477e;

    /* renamed from: f */
    public int f2478f;

    public C0604e4() {
        this.f2476d = C0007a4.f19a;
        this.f2477e = C0007a4.f21c;
        this.f2478f = 0;
    }

    public C0604e4(int i) {
        if (i == 0) {
            this.f2476d = C0007a4.f19a;
            this.f2477e = C0007a4.f21c;
        } else {
            mo3266a(i);
        }
        this.f2478f = 0;
    }

    /* renamed from: c */
    public static void m1970c(int[] iArr, Object[] objArr, int i) {
        Class<C0604e4> cls = C0604e4.class;
        if (iArr.length == 8) {
            synchronized (cls) {
                if (f2475j < 10) {
                    objArr[0] = f2474i;
                    objArr[1] = iArr;
                    for (int i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f2474i = objArr;
                    f2475j++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (cls) {
                if (f2473h < 10) {
                    objArr[0] = f2472g;
                    objArr[1] = iArr;
                    for (int i3 = (i << 1) - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f2472g = objArr;
                    f2473h++;
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo3266a(int i) {
        Class<C0604e4> cls = C0604e4.class;
        if (i == 8) {
            synchronized (cls) {
                Object[] objArr = f2474i;
                if (objArr != null) {
                    this.f2477e = objArr;
                    f2474i = (Object[]) objArr[0];
                    this.f2476d = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f2475j--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (cls) {
                Object[] objArr2 = f2472g;
                if (objArr2 != null) {
                    this.f2477e = objArr2;
                    f2472g = (Object[]) objArr2[0];
                    this.f2476d = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f2473h--;
                    return;
                }
            }
        }
        this.f2476d = new int[i];
        this.f2477e = new Object[(i << 1)];
    }

    /* renamed from: b */
    public void mo3267b(int i) {
        int i2 = this.f2478f;
        int[] iArr = this.f2476d;
        if (iArr.length < i) {
            Object[] objArr = this.f2477e;
            mo3266a(i);
            if (this.f2478f > 0) {
                System.arraycopy(iArr, 0, this.f2476d, 0, i2);
                System.arraycopy(objArr, 0, this.f2477e, 0, i2 << 1);
            }
            m1970c(iArr, objArr, i2);
        }
        if (this.f2478f != i2) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        int i = this.f2478f;
        if (i > 0) {
            int[] iArr = this.f2476d;
            Object[] objArr = this.f2477e;
            this.f2476d = C0007a4.f19a;
            this.f2477e = C0007a4.f21c;
            this.f2478f = 0;
            m1970c(iArr, objArr, i);
        }
        if (this.f2478f > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return mo3272e(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return mo3275g(obj) >= 0;
    }

    /* renamed from: d */
    public int mo3271d(Object obj, int i) {
        int i2 = this.f2478f;
        if (i2 == 0) {
            return -1;
        }
        try {
            int a = C0007a4.m17a(this.f2476d, i2, i);
            if (a < 0 || obj.equals(this.f2477e[a << 1])) {
                return a;
            }
            int i3 = a + 1;
            while (i3 < i2 && this.f2476d[i3] == i) {
                if (obj.equals(this.f2477e[i3 << 1])) {
                    return i3;
                }
                i3++;
            }
            int i4 = a - 1;
            while (i4 >= 0 && this.f2476d[i4] == i) {
                if (obj.equals(this.f2477e[i4 << 1])) {
                    return i4;
                }
                i4--;
            }
            return i3 ^ -1;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    /* renamed from: e */
    public int mo3272e(Object obj) {
        return obj == null ? mo3274f() : mo3271d(obj, obj.hashCode());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0604e4) {
            C0604e4 e4Var = (C0604e4) obj;
            if (this.f2478f != e4Var.f2478f) {
                return false;
            }
            int i = 0;
            while (i < this.f2478f) {
                try {
                    Object h = mo3278h(i);
                    Object l = mo3284l(i);
                    Object obj2 = e4Var.get(h);
                    if (l == null) {
                        if (obj2 != null || !e4Var.containsKey(h)) {
                            return false;
                        }
                    } else if (!l.equals(obj2)) {
                        return false;
                    }
                    i++;
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (this.f2478f != map.size()) {
                return false;
            }
            int i2 = 0;
            while (i2 < this.f2478f) {
                try {
                    Object h2 = mo3278h(i2);
                    Object l2 = mo3284l(i2);
                    Object obj3 = map.get(h2);
                    if (l2 == null) {
                        if (obj3 != null || !map.containsKey(h2)) {
                            return false;
                        }
                    } else if (!l2.equals(obj3)) {
                        return false;
                    }
                    i2++;
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    /* renamed from: f */
    public int mo3274f() {
        int i = this.f2478f;
        if (i == 0) {
            return -1;
        }
        try {
            int a = C0007a4.m17a(this.f2476d, i, 0);
            if (a < 0 || this.f2477e[a << 1] == null) {
                return a;
            }
            int i2 = a + 1;
            while (i2 < i && this.f2476d[i2] == 0) {
                if (this.f2477e[i2 << 1] == null) {
                    return i2;
                }
                i2++;
            }
            int i3 = a - 1;
            while (i3 >= 0 && this.f2476d[i3] == 0) {
                if (this.f2477e[i3 << 1] == null) {
                    return i3;
                }
                i3--;
            }
            return i2 ^ -1;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    /* renamed from: g */
    public int mo3275g(Object obj) {
        int i = this.f2478f * 2;
        Object[] objArr = this.f2477e;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (obj.equals(objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    public V get(Object obj) {
        return getOrDefault(obj, (Object) null);
    }

    public V getOrDefault(Object obj, V v) {
        int e = mo3272e(obj);
        return e >= 0 ? this.f2477e[(e << 1) + 1] : v;
    }

    /* renamed from: h */
    public K mo3278h(int i) {
        return this.f2477e[i << 1];
    }

    public int hashCode() {
        int[] iArr = this.f2476d;
        Object[] objArr = this.f2477e;
        int i = this.f2478f;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    /* renamed from: i */
    public void mo3280i(C0604e4<? extends K, ? extends V> e4Var) {
        int i = e4Var.f2478f;
        mo3267b(this.f2478f + i);
        if (this.f2478f != 0) {
            for (int i2 = 0; i2 < i; i2++) {
                put(e4Var.mo3278h(i2), e4Var.mo3284l(i2));
            }
        } else if (i > 0) {
            System.arraycopy(e4Var.f2476d, 0, this.f2476d, 0, i);
            System.arraycopy(e4Var.f2477e, 0, this.f2477e, 0, i << 1);
            this.f2478f = i;
        }
    }

    public boolean isEmpty() {
        return this.f2478f <= 0;
    }

    /* renamed from: j */
    public V mo3282j(int i) {
        V[] vArr = this.f2477e;
        int i2 = i << 1;
        V v = vArr[i2 + 1];
        int i3 = this.f2478f;
        int i4 = 0;
        if (i3 <= 1) {
            m1970c(this.f2476d, vArr, i3);
            this.f2476d = C0007a4.f19a;
            this.f2477e = C0007a4.f21c;
        } else {
            int i5 = i3 - 1;
            int[] iArr = this.f2476d;
            int i6 = 8;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                if (i < i5) {
                    int i7 = i + 1;
                    int i8 = i5 - i;
                    System.arraycopy(iArr, i7, iArr, i, i8);
                    Object[] objArr = this.f2477e;
                    System.arraycopy(objArr, i7 << 1, objArr, i2, i8 << 1);
                }
                Object[] objArr2 = this.f2477e;
                int i9 = i5 << 1;
                objArr2[i9] = null;
                objArr2[i9 + 1] = null;
            } else {
                if (i3 > 8) {
                    i6 = i3 + (i3 >> 1);
                }
                mo3266a(i6);
                if (i3 == this.f2478f) {
                    if (i > 0) {
                        System.arraycopy(iArr, 0, this.f2476d, 0, i);
                        System.arraycopy(vArr, 0, this.f2477e, 0, i2);
                    }
                    if (i < i5) {
                        int i10 = i + 1;
                        int i11 = i5 - i;
                        System.arraycopy(iArr, i10, this.f2476d, i, i11);
                        System.arraycopy(vArr, i10 << 1, this.f2477e, i2, i11 << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
            i4 = i5;
        }
        if (i3 == this.f2478f) {
            this.f2478f = i4;
            return v;
        }
        throw new ConcurrentModificationException();
    }

    /* renamed from: k */
    public V mo3283k(int i, V v) {
        int i2 = (i << 1) + 1;
        V[] vArr = this.f2477e;
        V v2 = vArr[i2];
        vArr[i2] = v;
        return v2;
    }

    /* renamed from: l */
    public V mo3284l(int i) {
        return this.f2477e[(i << 1) + 1];
    }

    public V put(K k, V v) {
        int i;
        int i2;
        int i3 = this.f2478f;
        if (k == null) {
            i2 = mo3274f();
            i = 0;
        } else {
            int hashCode = k.hashCode();
            i = hashCode;
            i2 = mo3271d(k, hashCode);
        }
        if (i2 >= 0) {
            int i4 = (i2 << 1) + 1;
            V[] vArr = this.f2477e;
            V v2 = vArr[i4];
            vArr[i4] = v;
            return v2;
        }
        int i5 = i2 ^ -1;
        int[] iArr = this.f2476d;
        if (i3 >= iArr.length) {
            int i6 = 4;
            if (i3 >= 8) {
                i6 = (i3 >> 1) + i3;
            } else if (i3 >= 4) {
                i6 = 8;
            }
            Object[] objArr = this.f2477e;
            mo3266a(i6);
            if (i3 == this.f2478f) {
                int[] iArr2 = this.f2476d;
                if (iArr2.length > 0) {
                    System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                    System.arraycopy(objArr, 0, this.f2477e, 0, objArr.length);
                }
                m1970c(iArr, objArr, i3);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (i5 < i3) {
            int[] iArr3 = this.f2476d;
            int i7 = i5 + 1;
            System.arraycopy(iArr3, i5, iArr3, i7, i3 - i5);
            Object[] objArr2 = this.f2477e;
            System.arraycopy(objArr2, i5 << 1, objArr2, i7 << 1, (this.f2478f - i5) << 1);
        }
        int i8 = this.f2478f;
        if (i3 == i8) {
            int[] iArr4 = this.f2476d;
            if (i5 < iArr4.length) {
                iArr4[i5] = i;
                Object[] objArr3 = this.f2477e;
                int i9 = i5 << 1;
                objArr3[i9] = k;
                objArr3[i9 + 1] = v;
                this.f2478f = i8 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V orDefault = getOrDefault(k, (Object) null);
        return orDefault == null ? put(k, v) : orDefault;
    }

    public V remove(Object obj) {
        int e = mo3272e(obj);
        if (e >= 0) {
            return mo3282j(e);
        }
        return null;
    }

    public boolean remove(Object obj, Object obj2) {
        int e = mo3272e(obj);
        if (e < 0) {
            return false;
        }
        Object l = mo3284l(e);
        if (obj2 != l && (obj2 == null || !obj2.equals(l))) {
            return false;
        }
        mo3282j(e);
        return true;
    }

    public V replace(K k, V v) {
        int e = mo3272e(k);
        if (e >= 0) {
            return mo3283k(e, v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int e = mo3272e(k);
        if (e < 0) {
            return false;
        }
        V l = mo3284l(e);
        if (l != v && (v == null || !v.equals(l))) {
            return false;
        }
        mo3283k(e, v2);
        return true;
    }

    public int size() {
        return this.f2478f;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f2478f * 28);
        sb.append('{');
        for (int i = 0; i < this.f2478f; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object h = mo3278h(i);
            if (h != this) {
                sb.append(h);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            Object l = mo3284l(i);
            if (l != this) {
                sb.append(l);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
