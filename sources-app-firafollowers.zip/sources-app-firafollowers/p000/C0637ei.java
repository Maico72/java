package p000;

/* renamed from: ei */
public final class C0637ei implements C2071xh<int[]> {
    /* renamed from: a */
    public String mo1960a() {
        return "IntegerArrayPool";
    }

    /* renamed from: b */
    public int mo1961b(Object obj) {
        return ((int[]) obj).length;
    }

    /* renamed from: c */
    public int mo1962c() {
        return 4;
    }

    public Object newArray(int i) {
        return new int[i];
    }
}
