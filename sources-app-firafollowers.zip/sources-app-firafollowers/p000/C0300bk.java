package p000;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

/* renamed from: bk */
public class C0300bk<DataType> implements C0054ag<DataType, BitmapDrawable> {

    /* renamed from: a */
    public final C0054ag<DataType, Bitmap> f1344a;

    /* renamed from: b */
    public final Resources f1345b;

    public C0300bk(Resources resources, C0054ag<DataType, Bitmap> agVar) {
        this.f1345b = resources;
        this.f1344a = agVar;
    }

    /* renamed from: a */
    public C1675rh<BitmapDrawable> mo122a(DataType datatype, int i, int i2, C2150yf yfVar) {
        return C1948vk.m5424f(this.f1345b, this.f1344a.mo122a(datatype, i, i2, yfVar));
    }

    /* renamed from: b */
    public boolean mo123b(DataType datatype, C2150yf yfVar) {
        return this.f1344a.mo123b(datatype, yfVar);
    }
}
