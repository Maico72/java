package p000;

import java.io.Serializable;
import java.util.Set;

/* renamed from: ay */
public class C0232ay extends C0724fy implements Serializable {

    /* renamed from: o */
    public final b10 f1158o;

    public C0232ay(C0232ay ayVar, Set<String> set, Set<String> set2) {
        super((C0724fy) ayVar, set, set2);
        this.f1158o = ayVar.f1158o;
    }

    public C0232ay(C0232ay ayVar, C1638qx qxVar) {
        super((C0724fy) ayVar, qxVar, ayVar.f2794j);
        this.f1158o = ayVar.f1158o;
    }

    public C0232ay(C0232ay ayVar, C1638qx qxVar, Object obj) {
        super((C0724fy) ayVar, qxVar, obj);
        this.f1158o = ayVar.f1158o;
    }

    public C0232ay(C0232ay ayVar, C1700rw[] rwVarArr, C1700rw[] rwVarArr2) {
        super((C0724fy) ayVar, rwVarArr, rwVarArr2);
        this.f1158o = ayVar.f1158o;
    }

    /* renamed from: e */
    public boolean mo1480e() {
        return true;
    }

    /* renamed from: f */
    public final void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo4633h(obj);
        if (this.f2796l != null) {
            mo3669q(obj, mqVar, atVar, false);
            return;
        }
        Object obj2 = this.f2794j;
        if (obj2 != null) {
            if (this.f2792h != null) {
                Class<?> cls = atVar.f1135e;
            }
            mo5884m(atVar, obj2, obj);
            throw null;
        }
        mo3671u(obj, mqVar, atVar);
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        if (atVar.mo1442E(C2237zs.FAIL_ON_UNWRAPPED_TYPE_IDENTIFIERS)) {
            atVar.mo3831g(this.f5804d, "Unwrapped property requires use of type information: cannot serialize without disabling `SerializationFeature.FAIL_ON_UNWRAPPED_TYPE_IDENTIFIERS`");
        }
        mqVar.mo4633h(obj);
        if (this.f2796l != null) {
            mo3668p(obj, mqVar, atVar, awVar);
            return;
        }
        Object obj2 = this.f2794j;
        if (obj2 != null) {
            C1700rw[] rwVarArr = this.f2792h;
            mo5884m(atVar, obj2, obj);
            throw null;
        }
        mo3671u(obj, mqVar, atVar);
    }

    /* renamed from: h */
    public C1462ps<Object> mo1483h(b10 b10) {
        return new C0232ay((C0724fy) this, b10);
    }

    /* renamed from: s */
    public C0724fy mo1484s() {
        return this;
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("UnwrappingBeanSerializer for ");
        d.append(this.f5804d.getName());
        return d.toString();
    }

    /* renamed from: v */
    public C0724fy mo1486v(Set<String> set, Set<String> set2) {
        return new C0232ay(this, set, set2);
    }

    /* renamed from: w */
    public C0724fy mo1487w(Object obj) {
        return new C0232ay(this, this.f2796l, obj);
    }

    /* renamed from: x */
    public C0724fy mo1488x(C1638qx qxVar) {
        return new C0232ay(this, qxVar);
    }

    /* renamed from: y */
    public C0724fy mo1489y(C1700rw[] rwVarArr, C1700rw[] rwVarArr2) {
        return new C0232ay(this, rwVarArr, rwVarArr2);
    }

    public C0232ay(C0724fy fyVar, b10 b10) {
        super(fyVar, C0724fy.m2332t(fyVar.f2791g, b10), C0724fy.m2332t(fyVar.f2792h, b10));
        this.f1158o = b10;
    }
}
