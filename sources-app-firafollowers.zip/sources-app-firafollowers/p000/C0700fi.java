package p000;

import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.TreeMap;

/* renamed from: fi */
public final class C0700fi implements C2152yh {

    /* renamed from: a */
    public final C0568di<C0701a, Object> f2753a = new C0568di<>();

    /* renamed from: b */
    public final C0702b f2754b = new C0702b();

    /* renamed from: c */
    public final Map<Class<?>, NavigableMap<Integer, Integer>> f2755c = new HashMap();

    /* renamed from: d */
    public final Map<Class<?>, C2071xh<?>> f2756d = new HashMap();

    /* renamed from: e */
    public final int f2757e;

    /* renamed from: f */
    public int f2758f;

    /* renamed from: fi$a */
    public static final class C0701a implements C0894ii {

        /* renamed from: a */
        public final C0702b f2759a;

        /* renamed from: b */
        public int f2760b;

        /* renamed from: c */
        public Class<?> f2761c;

        public C0701a(C0702b bVar) {
            this.f2759a = bVar;
        }

        /* renamed from: a */
        public void mo3613a() {
            this.f2759a.mo6865c(this);
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0701a)) {
                return false;
            }
            C0701a aVar = (C0701a) obj;
            return this.f2760b == aVar.f2760b && this.f2761c == aVar.f2761c;
        }

        public int hashCode() {
            int i = this.f2760b * 31;
            Class<?> cls = this.f2761c;
            return i + (cls != null ? cls.hashCode() : 0);
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("Key{size=");
            d.append(this.f2760b);
            d.append("array=");
            d.append(this.f2761c);
            d.append('}');
            return d.toString();
        }
    }

    /* renamed from: fi$b */
    public static final class C0702b extends C2220zh<C0701a> {
        /* renamed from: a */
        public C0894ii mo3617a() {
            return new C0701a(this);
        }

        /* renamed from: d */
        public C0701a mo3618d(int i, Class<?> cls) {
            C0701a aVar = (C0701a) mo6864b();
            aVar.f2760b = i;
            aVar.f2761c = cls;
            return aVar;
        }
    }

    public C0700fi(int i) {
        this.f2757e = i;
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index 0 out of bounds for length 0
        	at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        	at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        	at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        	at java.base/java.util.Objects.checkIndex(Objects.java:372)
        	at java.base/java.util.ArrayList.get(ArrayList.java:458)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* renamed from: a */
    public synchronized void mo3603a(int r2) {
        /*
            r1 = this;
            monitor-enter(r1)
            r0 = 40
            if (r2 < r0) goto L_0x000f
            monitor-enter(r1)     // Catch:{ all -> 0x0020 }
            r2 = 0
            r1.mo3609g(r2)     // Catch:{ all -> 0x000c }
            monitor-exit(r1)     // Catch:{ all -> 0x0020 }
            goto L_0x001e
        L_0x000c:
            r2 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0020 }
            throw r2     // Catch:{ all -> 0x0020 }
        L_0x000f:
            r0 = 20
            if (r2 >= r0) goto L_0x0017
            r0 = 15
            if (r2 != r0) goto L_0x001e
        L_0x0017:
            int r2 = r1.f2757e     // Catch:{ all -> 0x0020 }
            int r2 = r2 / 2
            r1.mo3609g(r2)     // Catch:{ all -> 0x0020 }
        L_0x001e:
            monitor-exit(r1)
            return
        L_0x0020:
            r2 = move-exception
            monitor-exit(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0700fi.mo3603a(int):void");
    }

    /* renamed from: b */
    public synchronized void mo3604b() {
        mo3609g(0);
    }

    /* renamed from: c */
    public synchronized <T> T mo3605c(int i, Class<T> cls) {
        C0701a aVar;
        aVar = (C0701a) this.f2754b.mo6864b();
        aVar.f2760b = i;
        aVar.f2761c = cls;
        return mo3611i(aVar, cls);
    }

    /* renamed from: d */
    public synchronized <T> void mo3606d(T t) {
        Class<?> cls = t.getClass();
        C2071xh<?> h = mo3610h(cls);
        int b = h.mo1961b(t);
        int c = h.mo1962c() * b;
        int i = 1;
        if (c <= this.f2757e / 2) {
            C0701a d = this.f2754b.mo3618d(b, cls);
            this.f2753a.mo3068b(d, t);
            NavigableMap<Integer, Integer> j = mo3612j(cls);
            Integer num = (Integer) j.get(Integer.valueOf(d.f2760b));
            Integer valueOf = Integer.valueOf(d.f2760b);
            if (num != null) {
                i = 1 + num.intValue();
            }
            j.put(valueOf, Integer.valueOf(i));
            this.f2758f += c;
            mo3609g(this.f2757e);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0023  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x003a  */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized <T> T mo3607e(int r6, java.lang.Class<T> r7) {
        /*
            r5 = this;
            monitor-enter(r5)
            java.util.NavigableMap r0 = r5.mo3612j(r7)     // Catch:{ all -> 0x004d }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r6)     // Catch:{ all -> 0x004d }
            java.lang.Object r0 = r0.ceilingKey(r1)     // Catch:{ all -> 0x004d }
            java.lang.Integer r0 = (java.lang.Integer) r0     // Catch:{ all -> 0x004d }
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x002c
            int r3 = r5.f2758f     // Catch:{ all -> 0x004d }
            if (r3 == 0) goto L_0x0020
            int r4 = r5.f2757e     // Catch:{ all -> 0x004d }
            int r4 = r4 / r3
            r3 = 2
            if (r4 < r3) goto L_0x001e
            goto L_0x0020
        L_0x001e:
            r3 = 0
            goto L_0x0021
        L_0x0020:
            r3 = 1
        L_0x0021:
            if (r3 != 0) goto L_0x002d
            int r3 = r0.intValue()     // Catch:{ all -> 0x004d }
            int r4 = r6 * 8
            if (r3 > r4) goto L_0x002c
            goto L_0x002d
        L_0x002c:
            r1 = 0
        L_0x002d:
            if (r1 == 0) goto L_0x003a
            fi$b r6 = r5.f2754b     // Catch:{ all -> 0x004d }
            int r0 = r0.intValue()     // Catch:{ all -> 0x004d }
            fi$a r6 = r6.mo3618d(r0, r7)     // Catch:{ all -> 0x004d }
            goto L_0x0047
        L_0x003a:
            fi$b r0 = r5.f2754b     // Catch:{ all -> 0x004d }
            ii r0 = r0.mo6864b()     // Catch:{ all -> 0x004d }
            fi$a r0 = (p000.C0700fi.C0701a) r0     // Catch:{ all -> 0x004d }
            r0.f2760b = r6     // Catch:{ all -> 0x004d }
            r0.f2761c = r7     // Catch:{ all -> 0x004d }
            r6 = r0
        L_0x0047:
            java.lang.Object r6 = r5.mo3611i(r6, r7)     // Catch:{ all -> 0x004d }
            monitor-exit(r5)
            return r6
        L_0x004d:
            r6 = move-exception
            monitor-exit(r5)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0700fi.mo3607e(int, java.lang.Class):java.lang.Object");
    }

    /* renamed from: f */
    public final void mo3608f(int i, Class<?> cls) {
        NavigableMap<Integer, Integer> j = mo3612j(cls);
        Integer num = (Integer) j.get(Integer.valueOf(i));
        if (num != null) {
            int intValue = num.intValue();
            Integer valueOf = Integer.valueOf(i);
            if (intValue == 1) {
                j.remove(valueOf);
            } else {
                j.put(valueOf, Integer.valueOf(num.intValue() - 1));
            }
        } else {
            throw new NullPointerException("Tried to decrement empty size, size: " + i + ", this: " + this);
        }
    }

    /* renamed from: g */
    public final void mo3609g(int i) {
        while (this.f2758f > i) {
            Object c = this.f2753a.mo3069c();
            Objects.requireNonNull(c, "Argument must not be null");
            C2071xh<?> h = mo3610h(c.getClass());
            this.f2758f -= h.mo1962c() * h.mo1961b(c);
            mo3608f(h.mo1961b(c), c.getClass());
            if (Log.isLoggable(h.mo1960a(), 2)) {
                String a = h.mo1960a();
                StringBuilder d = C1012kd.m3195d("evicted: ");
                d.append(h.mo1961b(c));
                Log.v(a, d.toString());
            }
        }
    }

    /* renamed from: h */
    public final <T> C2071xh<T> mo3610h(Class<T> cls) {
        C2071xh<T> xhVar = this.f2756d.get(cls);
        if (xhVar == null) {
            if (cls.equals(int[].class)) {
                xhVar = new C0637ei();
            } else if (cls.equals(byte[].class)) {
                xhVar = new C0365ci();
            } else {
                StringBuilder d = C1012kd.m3195d("No array pool found for: ");
                d.append(cls.getSimpleName());
                throw new IllegalArgumentException(d.toString());
            }
            this.f2756d.put(cls, xhVar);
        }
        return xhVar;
    }

    /* renamed from: i */
    public final <T> T mo3611i(C0701a aVar, Class<T> cls) {
        C2071xh<T> h = mo3610h(cls);
        T a = this.f2753a.mo3067a(aVar);
        if (a != null) {
            this.f2758f -= h.mo1962c() * h.mo1961b(a);
            mo3608f(h.mo1961b(a), cls);
        }
        if (a != null) {
            return a;
        }
        if (Log.isLoggable(h.mo1960a(), 2)) {
            String a2 = h.mo1960a();
            StringBuilder d = C1012kd.m3195d("Allocated ");
            d.append(aVar.f2760b);
            d.append(" bytes");
            Log.v(a2, d.toString());
        }
        return h.newArray(aVar.f2760b);
    }

    /* renamed from: j */
    public final NavigableMap<Integer, Integer> mo3612j(Class<?> cls) {
        NavigableMap<Integer, Integer> navigableMap = this.f2755c.get(cls);
        if (navigableMap != null) {
            return navigableMap;
        }
        TreeMap treeMap = new TreeMap();
        this.f2755c.put(cls, treeMap);
        return treeMap;
    }
}
