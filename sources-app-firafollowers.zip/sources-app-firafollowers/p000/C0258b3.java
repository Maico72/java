package p000;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

/* renamed from: b3 */
public class C0258b3 extends C1776t2 {

    /* renamed from: b */
    public final WeakReference<Context> f1210b;

    public C0258b3(Context context, Resources resources) {
        super(resources);
        this.f1210b = new WeakReference<>(context);
    }

    public Drawable getDrawable(int i) {
        Drawable drawable = this.f5817a.getDrawable(i);
        Context context = (Context) this.f1210b.get();
        if (!(drawable == null || context == null)) {
            C1710s2.m4883d().mo5797l(context, i, drawable);
        }
        return drawable;
    }
}
