package p000;

import p000.C0576dp;
import p000.C1029kp;

/* renamed from: es */
public abstract class C0649es {

    /* renamed from: a */
    public final C1035ks f2616a;

    public C0649es(C1035ks ksVar) {
        this.f2616a = ksVar;
    }

    /* renamed from: a */
    public abstract C0576dp.C0580d mo2811a(C0576dp.C0580d dVar);

    /* renamed from: b */
    public abstract C1887uu mo2812b();

    /* renamed from: c */
    public abstract C1029kp.C1031b mo2813c(C1029kp.C1031b bVar);
}
