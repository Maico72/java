package p000;

import org.fasaroid.fira.R;

/* renamed from: g4 */
public final class C0733g4 {

    /* renamed from: a */
    public static final int[] f2829a = {R.attr.keylines, R.attr.statusBarBackground};

    /* renamed from: b */
    public static final int[] f2830b = {16842931, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
}
