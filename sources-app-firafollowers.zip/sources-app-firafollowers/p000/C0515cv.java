package p000;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import p000.C0576dp;
import p000.C1029kp;

/* renamed from: cv */
public class C0515cv extends C0649es {

    /* renamed from: j */
    public static final Class<?>[] f2099j = new Class[0];

    /* renamed from: b */
    public final C1280nv f2100b;

    /* renamed from: c */
    public final C1757st<?> f2101c;

    /* renamed from: d */
    public final C0583ds f2102d;

    /* renamed from: e */
    public final C1364ou f2103e;

    /* renamed from: f */
    public Class<?>[] f2104f;

    /* renamed from: g */
    public boolean f2105g;

    /* renamed from: h */
    public List<C0652ev> f2106h;

    /* renamed from: i */
    public C1208mv f2107i;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0515cv(p000.C1280nv r3) {
        /*
            r2 = this;
            ks r0 = r3.f4360d
            ou r1 = r3.f4361e
            r2.<init>(r0)
            r2.f2100b = r3
            st<?> r0 = r3.f4357a
            r2.f2101c = r0
            if (r0 != 0) goto L_0x0011
            r0 = 0
            goto L_0x0015
        L_0x0011:
            ds r0 = r0.mo5863e()
        L_0x0015:
            r2.f2102d = r0
            r2.f2103e = r1
            ds r0 = r3.f4363g
            ou r1 = r3.f4361e
            mv r0 = r0.mo3149r(r1)
            if (r0 == 0) goto L_0x002b
            ds r1 = r3.f4363g
            ou r3 = r3.f4361e
            mv r0 = r1.mo3150s(r3, r0)
        L_0x002b:
            r2.f2107i = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0515cv.<init>(nv):void");
    }

    public C0515cv(C1757st<?> stVar, C1035ks ksVar, C1364ou ouVar, List<C0652ev> list) {
        super(ksVar);
        this.f2100b = null;
        this.f2101c = stVar;
        if (stVar == null) {
            this.f2102d = null;
        } else {
            this.f2102d = stVar.mo5863e();
        }
        this.f2103e = ouVar;
        this.f2106h = list;
    }

    /* renamed from: e */
    public static C0515cv m1634e(C1757st<?> stVar, C1035ks ksVar, C1364ou ouVar) {
        return new C0515cv(stVar, ksVar, ouVar, Collections.emptyList());
    }

    /* renamed from: a */
    public C0576dp.C0580d mo2811a(C0576dp.C0580d dVar) {
        C0576dp.C0580d dVar2;
        C0583ds dsVar = this.f2102d;
        if (dsVar == null || (dVar2 = dsVar.mo3139h(this.f2103e)) == null) {
            dVar2 = null;
        }
        C0576dp.C0580d h = this.f2101c.mo5866h(this.f2103e.f4584e);
        if (h != null) {
            return dVar2 == null ? h : dVar2.mo3092f(h);
        }
        return dVar2;
    }

    /* renamed from: b */
    public C1887uu mo2812b() {
        C1280nv nvVar = this.f2100b;
        if (nvVar == null) {
            return null;
        }
        if (!nvVar.f4365i) {
            nvVar.mo4885h();
        }
        LinkedList<C1887uu> linkedList = nvVar.f4374r;
        if (linkedList == null) {
            return null;
        }
        if (linkedList.size() <= 1) {
            return nvVar.f4374r.get(0);
        }
        nvVar.mo4886i("Multiple 'as-value' properties defined (%s vs %s)", nvVar.f4374r.get(0), nvVar.f4374r.get(1));
        throw null;
    }

    /* renamed from: c */
    public C1029kp.C1031b mo2813c(C1029kp.C1031b bVar) {
        C1029kp.C1031b z;
        C0583ds dsVar = this.f2102d;
        return (dsVar == null || (z = dsVar.mo3157z(this.f2103e)) == null) ? bVar : bVar == null ? z : bVar.mo4315a(z);
    }

    /* renamed from: d */
    public List<C0652ev> mo2814d() {
        if (this.f2106h == null) {
            C1280nv nvVar = this.f2100b;
            if (!nvVar.f4365i) {
                nvVar.mo4885h();
            }
            this.f2106h = new ArrayList(nvVar.f4366j.values());
        }
        return this.f2106h;
    }
}
