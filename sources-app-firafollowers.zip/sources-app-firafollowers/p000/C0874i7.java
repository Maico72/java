package p000;

/* renamed from: i7 */
public interface C0874i7 {
}
