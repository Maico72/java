package p000;

@Deprecated
/* renamed from: an */
public interface C0066an extends C0574dn, C2230zm {
}
