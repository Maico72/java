package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: f1 */
public class C0662f1 extends C1838u0 implements SubMenu {

    /* renamed from: A */
    public C1967w0 f2626A;

    /* renamed from: z */
    public C1838u0 f2627z;

    public C0662f1(Context context, C1838u0 u0Var, C1967w0 w0Var) {
        super(context);
        this.f2627z = u0Var;
        this.f2626A = w0Var;
    }

    /* renamed from: d */
    public boolean mo3431d(C1967w0 w0Var) {
        return this.f2627z.mo3431d(w0Var);
    }

    /* renamed from: e */
    public boolean mo3432e(C1838u0 u0Var, MenuItem menuItem) {
        return super.mo3432e(u0Var, menuItem) || this.f2627z.mo3432e(u0Var, menuItem);
    }

    /* renamed from: f */
    public boolean mo3433f(C1967w0 w0Var) {
        return this.f2627z.mo3433f(w0Var);
    }

    public MenuItem getItem() {
        return this.f2626A;
    }

    /* renamed from: j */
    public String mo3435j() {
        C1967w0 w0Var = this.f2626A;
        int i = w0Var != null ? w0Var.f6461a : 0;
        if (i == 0) {
            return null;
        }
        return "android:menu:actionviewstates" + ":" + i;
    }

    /* renamed from: k */
    public C1838u0 mo3436k() {
        return this.f2627z.mo3436k();
    }

    /* renamed from: m */
    public boolean mo3437m() {
        return this.f2627z.mo3437m();
    }

    /* renamed from: n */
    public boolean mo3438n() {
        return this.f2627z.mo3438n();
    }

    /* renamed from: o */
    public boolean mo3439o() {
        return this.f2627z.mo3439o();
    }

    public void setGroupDividerEnabled(boolean z) {
        this.f2627z.setGroupDividerEnabled(z);
    }

    public SubMenu setHeaderIcon(int i) {
        mo6095x(0, (CharSequence) null, i, (Drawable) null, (View) null);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        mo6095x(i, (CharSequence) null, 0, (Drawable) null, (View) null);
        return this;
    }

    public SubMenu setHeaderView(View view) {
        mo6095x(0, (CharSequence) null, 0, (Drawable) null, view);
        return this;
    }

    public SubMenu setIcon(int i) {
        this.f2626A.setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f2626A.setIcon(drawable);
        return this;
    }

    public void setQwertyMode(boolean z) {
        this.f2627z.setQwertyMode(z);
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        mo6095x(0, (CharSequence) null, 0, drawable, (View) null);
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        mo6095x(0, charSequence, 0, (Drawable) null, (View) null);
        return this;
    }
}
