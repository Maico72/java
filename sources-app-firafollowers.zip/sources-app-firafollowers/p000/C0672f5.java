package p000;

/* renamed from: f5 */
public final class C0672f5 {

    /* renamed from: e */
    public static final C0672f5 f2684e = new C0672f5(0, 0, 0, 0);

    /* renamed from: a */
    public final int f2685a;

    /* renamed from: b */
    public final int f2686b;

    /* renamed from: c */
    public final int f2687c;

    /* renamed from: d */
    public final int f2688d;

    public C0672f5(int i, int i2, int i3, int i4) {
        this.f2685a = i;
        this.f2686b = i2;
        this.f2687c = i3;
        this.f2688d = i4;
    }

    /* renamed from: a */
    public static C0672f5 m2163a(int i, int i2, int i3, int i4) {
        return (i == 0 && i2 == 0 && i3 == 0 && i4 == 0) ? f2684e : new C0672f5(i, i2, i3, i4);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0672f5.class != obj.getClass()) {
            return false;
        }
        C0672f5 f5Var = (C0672f5) obj;
        return this.f2688d == f5Var.f2688d && this.f2685a == f5Var.f2685a && this.f2687c == f5Var.f2687c && this.f2686b == f5Var.f2686b;
    }

    public int hashCode() {
        return (((((this.f2685a * 31) + this.f2686b) * 31) + this.f2687c) * 31) + this.f2688d;
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("Insets{left=");
        d.append(this.f2685a);
        d.append(", top=");
        d.append(this.f2686b);
        d.append(", right=");
        d.append(this.f2687c);
        d.append(", bottom=");
        d.append(this.f2688d);
        d.append('}');
        return d.toString();
    }
}
