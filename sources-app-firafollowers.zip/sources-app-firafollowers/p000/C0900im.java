package p000;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import p000.C0051af;
import p000.C0785gm;

/* renamed from: im */
public final class C0900im implements C0785gm {

    /* renamed from: d */
    public final Context f3273d;

    /* renamed from: e */
    public final C0785gm.C0786a f3274e;

    /* renamed from: f */
    public boolean f3275f;

    /* renamed from: g */
    public boolean f3276g;

    /* renamed from: h */
    public final BroadcastReceiver f3277h = new C0901a();

    /* renamed from: im$a */
    public class C0901a extends BroadcastReceiver {
        public C0901a() {
        }

        public void onReceive(Context context, Intent intent) {
            C0900im imVar = C0900im.this;
            boolean z = imVar.f3275f;
            imVar.f3275f = imVar.mo4049l(context);
            if (z != C0900im.this.f3275f) {
                if (Log.isLoggable("ConnectivityMonitor", 3)) {
                    StringBuilder d = C1012kd.m3195d("connectivity changed, isConnected: ");
                    d.append(C0900im.this.f3275f);
                    Log.d("ConnectivityMonitor", d.toString());
                }
                C0900im imVar2 = C0900im.this;
                C0785gm.C0786a aVar = imVar2.f3274e;
                boolean z2 = imVar2.f3275f;
                C0051af.C0053b bVar = (C0051af.C0053b) aVar;
                Objects.requireNonNull(bVar);
                if (z2) {
                    synchronized (C0051af.this) {
                        C1950vm vmVar = bVar.f178a;
                        Iterator it = ((ArrayList) C1624qo.m4654e(vmVar.f6408a)).iterator();
                        while (it.hasNext()) {
                            C1197mn mnVar = (C1197mn) it.next();
                            if (!mnVar.mo4460i() && !mnVar.mo4462j()) {
                                mnVar.clear();
                                if (!vmVar.f6410c) {
                                    mnVar.mo4457f();
                                } else {
                                    vmVar.f6409b.add(mnVar);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public C0900im(Context context, C0785gm.C0786a aVar) {
        this.f3273d = context.getApplicationContext();
        this.f3274e = aVar;
    }

    /* renamed from: e */
    public void mo108e() {
        if (this.f3276g) {
            this.f3273d.unregisterReceiver(this.f3277h);
            this.f3276g = false;
        }
    }

    /* renamed from: i */
    public void mo109i() {
        if (!this.f3276g) {
            this.f3275f = mo4049l(this.f3273d);
            try {
                this.f3273d.registerReceiver(this.f3277h, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
                this.f3276g = true;
            } catch (SecurityException e) {
                if (Log.isLoggable("ConnectivityMonitor", 5)) {
                    Log.w("ConnectivityMonitor", "Failed to register", e);
                }
            }
        }
    }

    /* renamed from: k */
    public void mo110k() {
    }

    @SuppressLint({"MissingPermission"})
    /* renamed from: l */
    public boolean mo4049l(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        Objects.requireNonNull(connectivityManager, "Argument must not be null");
        try {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
                return false;
            }
            return true;
        } catch (RuntimeException e) {
            if (Log.isLoggable("ConnectivityMonitor", 5)) {
                Log.w("ConnectivityMonitor", "Failed to determine connectivity status when connectivity changed", e);
            }
            return true;
        }
    }
}
