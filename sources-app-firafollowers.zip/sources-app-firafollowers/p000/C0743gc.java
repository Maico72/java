package p000;

import p000.C0545dc;

/* renamed from: gc */
public class C0743gc implements C0545dc.C0549d {
    /* renamed from: a */
    public void mo3018a(C0545dc dcVar) {
    }

    /* renamed from: b */
    public void mo3019b(C0545dc dcVar) {
    }

    /* renamed from: c */
    public void mo3020c(C0545dc dcVar) {
    }
}
