package p000;

import android.view.animation.Interpolator;
import androidx.fragment.app.Fragment;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Objects;
import p000.C1230n8;
import p000.C1409p9;
import p000.C1906v8;

/* renamed from: d8 */
public final class C0541d8 extends C1906v8 implements C1230n8.C1238h {

    /* renamed from: q */
    public final C1230n8 f2196q;

    /* renamed from: r */
    public boolean f2197r;

    /* renamed from: s */
    public int f2198s = -1;

    public C0541d8(C1230n8 n8Var) {
        this.f2196q = n8Var;
    }

    /* renamed from: l */
    public static boolean m1720l(C1906v8.C1907a aVar) {
        Fragment fragment = aVar.f6286b;
        if (fragment == null || !fragment.f672n || fragment.f647H == null || fragment.f642C || fragment.f641B) {
            return false;
        }
        Fragment.C0134a aVar2 = fragment.f651L;
        return false;
    }

    /* renamed from: a */
    public boolean mo2958a(ArrayList<C0541d8> arrayList, ArrayList<Boolean> arrayList2) {
        Interpolator interpolator = C1230n8.f4206J;
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f6276h) {
            return true;
        }
        C1230n8 n8Var = this.f2196q;
        if (n8Var.f4222k == null) {
            n8Var.f4222k = new ArrayList<>();
        }
        n8Var.f4222k.add(this);
        return true;
    }

    /* renamed from: c */
    public void mo2959c(int i, Fragment fragment, String str, int i2) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            StringBuilder d = C1012kd.m3195d("Fragment ");
            d.append(cls.getCanonicalName());
            d.append(" must be a public static class to be  properly recreated from instance state.");
            throw new IllegalStateException(d.toString());
        }
        if (str != null) {
            String str2 = fragment.f640A;
            if (str2 == null || str.equals(str2)) {
                fragment.f640A = str;
            } else {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.f640A + " now " + str);
            }
        }
        if (i != 0) {
            if (i != -1) {
                int i3 = fragment.f683y;
                if (i3 == 0 || i3 == i) {
                    fragment.f683y = i;
                    fragment.f684z = i;
                } else {
                    throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.f683y + " now " + i);
                }
            } else {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
        }
        mo6214b(new C1906v8.C1907a(i2, fragment));
        fragment.f679u = this.f2196q;
    }

    /* renamed from: d */
    public C1906v8 mo2960d(Fragment fragment, C1409p9.C1411b bVar) {
        if (fragment.f679u == this.f2196q) {
            C1409p9.C1411b bVar2 = C1409p9.C1411b.CREATED;
            if (bVar.compareTo(bVar2) >= 0) {
                mo6214b(new C1906v8.C1907a(10, fragment, bVar));
                return this;
            }
            throw new IllegalArgumentException("Cannot set maximum Lifecycle below " + bVar2);
        }
        StringBuilder d = C1012kd.m3195d("Cannot setMaxLifecycle for Fragment not attached to FragmentManager ");
        d.append(this.f2196q);
        throw new IllegalArgumentException(d.toString());
    }

    /* renamed from: e */
    public void mo2961e(int i) {
        if (this.f6276h) {
            Interpolator interpolator = C1230n8.f4206J;
            int size = this.f6269a.size();
            for (int i2 = 0; i2 < size; i2++) {
                Fragment fragment = this.f6269a.get(i2).f6286b;
                if (fragment != null) {
                    fragment.f678t += i;
                    Interpolator interpolator2 = C1230n8.f4206J;
                }
            }
        }
    }

    /* renamed from: f */
    public int mo2962f(boolean z) {
        if (!this.f2197r) {
            Interpolator interpolator = C1230n8.f4206J;
            this.f2197r = true;
            int i = -1;
            if (this.f6276h) {
                C1230n8 n8Var = this.f2196q;
                synchronized (n8Var) {
                    ArrayList<Integer> arrayList = n8Var.f4227p;
                    if (arrayList != null) {
                        if (arrayList.size() > 0) {
                            ArrayList<Integer> arrayList2 = n8Var.f4227p;
                            i = arrayList2.remove(arrayList2.size() - 1).intValue();
                            n8Var.f4226o.set(i, this);
                        }
                    }
                    if (n8Var.f4226o == null) {
                        n8Var.f4226o = new ArrayList<>();
                    }
                    i = n8Var.f4226o.size();
                    n8Var.f4226o.add(this);
                }
            }
            this.f2198s = i;
            this.f2196q.mo4757Q(this, z);
            return this.f2198s;
        }
        throw new IllegalStateException("commit already called");
    }

    /* renamed from: g */
    public void mo2963g(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f6277i);
            printWriter.print(" mIndex=");
            printWriter.print(this.f2198s);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f2197r);
            if (this.f6274f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f6274f));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f6275g));
            }
            if (!(this.f6270b == 0 && this.f6271c == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f6270b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f6271c));
            }
            if (!(this.f6272d == 0 && this.f6273e == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f6272d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f6273e));
            }
            if (!(this.f6278j == 0 && this.f6279k == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f6278j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f6279k);
            }
            if (!(this.f6280l == 0 && this.f6281m == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f6280l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f6281m);
            }
        }
        if (!this.f6269a.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.f6269a.size();
            for (int i = 0; i < size; i++) {
                C1906v8.C1907a aVar = this.f6269a.get(i);
                switch (aVar.f6285a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        StringBuilder d = C1012kd.m3195d("cmd=");
                        d.append(aVar.f6285a);
                        str2 = d.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f6286b);
                if (z) {
                    if (!(aVar.f6287c == 0 && aVar.f6288d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f6287c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f6288d));
                    }
                    if (aVar.f6289e != 0 || aVar.f6290f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f6289e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f6290f));
                    }
                }
            }
        }
    }

    /* renamed from: h */
    public void mo2964h() {
        int size = this.f6269a.size();
        for (int i = 0; i < size; i++) {
            C1906v8.C1907a aVar = this.f6269a.get(i);
            Fragment fragment = aVar.f6286b;
            if (fragment != null) {
                int i2 = this.f6274f;
                int i3 = this.f6275g;
                if (!(fragment.f651L == null && i2 == 0 && i3 == 0)) {
                    fragment.mo808f();
                    Fragment.C0134a aVar2 = fragment.f651L;
                    aVar2.f690e = i2;
                    aVar2.f691f = i3;
                }
            }
            switch (aVar.f6285a) {
                case 1:
                    fragment.mo806e0(aVar.f6287c);
                    this.f2196q.mo4772f(fragment, false);
                    break;
                case 3:
                    fragment.mo806e0(aVar.f6288d);
                    this.f2196q.mo4783k0(fragment);
                    break;
                case 4:
                    fragment.mo806e0(aVar.f6288d);
                    Objects.requireNonNull(this.f2196q);
                    if (!fragment.f641B) {
                        fragment.f641B = true;
                        fragment.f653N = !fragment.f653N;
                        break;
                    }
                    break;
                case 5:
                    fragment.mo806e0(aVar.f6287c);
                    Objects.requireNonNull(this.f2196q);
                    if (fragment.f641B) {
                        fragment.f641B = false;
                        fragment.f653N = !fragment.f653N;
                        break;
                    }
                    break;
                case 6:
                    fragment.mo806e0(aVar.f6288d);
                    this.f2196q.mo4786m(fragment);
                    break;
                case 7:
                    fragment.mo806e0(aVar.f6287c);
                    this.f2196q.mo4776h(fragment);
                    break;
                case 8:
                    this.f2196q.mo4799r0(fragment);
                    break;
                case 9:
                    this.f2196q.mo4799r0((Fragment) null);
                    break;
                case 10:
                    this.f2196q.mo4797q0(fragment, aVar.f6292h);
                    break;
                default:
                    StringBuilder d = C1012kd.m3195d("Unknown cmd: ");
                    d.append(aVar.f6285a);
                    throw new IllegalArgumentException(d.toString());
            }
            if (!(this.f6284p || aVar.f6285a == 1 || fragment == null)) {
                this.f2196q.mo4771e0(fragment);
            }
        }
        if (!this.f6284p) {
            C1230n8 n8Var = this.f2196q;
            n8Var.mo4773f0(n8Var.f4229r, true);
        }
    }

    /* renamed from: i */
    public void mo2965i(boolean z) {
        for (int size = this.f6269a.size() - 1; size >= 0; size--) {
            C1906v8.C1907a aVar = this.f6269a.get(size);
            Fragment fragment = aVar.f6286b;
            if (fragment != null) {
                int i = this.f6274f;
                Interpolator interpolator = C1230n8.f4206J;
                int i2 = 8194;
                if (i != 4097) {
                    i2 = i != 4099 ? i != 8194 ? 0 : 4097 : 4099;
                }
                int i3 = this.f6275g;
                if (!(fragment.f651L == null && i2 == 0 && i3 == 0)) {
                    fragment.mo808f();
                    Fragment.C0134a aVar2 = fragment.f651L;
                    aVar2.f690e = i2;
                    aVar2.f691f = i3;
                }
            }
            switch (aVar.f6285a) {
                case 1:
                    fragment.mo806e0(aVar.f6290f);
                    this.f2196q.mo4783k0(fragment);
                    break;
                case 3:
                    fragment.mo806e0(aVar.f6289e);
                    this.f2196q.mo4772f(fragment, false);
                    break;
                case 4:
                    fragment.mo806e0(aVar.f6289e);
                    Objects.requireNonNull(this.f2196q);
                    if (fragment.f641B) {
                        fragment.f641B = false;
                        fragment.f653N = !fragment.f653N;
                        break;
                    }
                    break;
                case 5:
                    fragment.mo806e0(aVar.f6290f);
                    Objects.requireNonNull(this.f2196q);
                    if (!fragment.f641B) {
                        fragment.f641B = true;
                        fragment.f653N = !fragment.f653N;
                        break;
                    }
                    break;
                case 6:
                    fragment.mo806e0(aVar.f6289e);
                    this.f2196q.mo4776h(fragment);
                    break;
                case 7:
                    fragment.mo806e0(aVar.f6290f);
                    this.f2196q.mo4786m(fragment);
                    break;
                case 8:
                    this.f2196q.mo4799r0((Fragment) null);
                    break;
                case 9:
                    this.f2196q.mo4799r0(fragment);
                    break;
                case 10:
                    this.f2196q.mo4797q0(fragment, aVar.f6291g);
                    break;
                default:
                    StringBuilder d = C1012kd.m3195d("Unknown cmd: ");
                    d.append(aVar.f6285a);
                    throw new IllegalArgumentException(d.toString());
            }
            if (!(this.f6284p || aVar.f6285a == 3 || fragment == null)) {
                this.f2196q.mo4771e0(fragment);
            }
        }
        if (!this.f6284p && z) {
            C1230n8 n8Var = this.f2196q;
            n8Var.mo4773f0(n8Var.f4229r, true);
        }
    }

    /* renamed from: j */
    public boolean mo2966j(int i) {
        int size = this.f6269a.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment fragment = this.f6269a.get(i2).f6286b;
            int i3 = fragment != null ? fragment.f684z : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: k */
    public boolean mo2967k(ArrayList<C0541d8> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f6269a.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            Fragment fragment = this.f6269a.get(i4).f6286b;
            int i5 = fragment != null ? fragment.f684z : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0541d8 d8Var = arrayList.get(i6);
                    int size2 = d8Var.f6269a.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        Fragment fragment2 = d8Var.f6269a.get(i7).f6286b;
                        if ((fragment2 != null ? fragment2.f684z : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f2198s >= 0) {
            sb.append(" #");
            sb.append(this.f2198s);
        }
        if (this.f6277i != null) {
            sb.append(" ");
            sb.append(this.f6277i);
        }
        sb.append("}");
        return sb.toString();
    }
}
