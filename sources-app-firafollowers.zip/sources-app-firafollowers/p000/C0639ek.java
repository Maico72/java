package p000;

import android.graphics.Bitmap;

/* renamed from: ek */
public final class C0639ek extends C2224zj<Bitmap> {

    /* renamed from: b */
    public final C0056ai f2605b = new C0291bi();
}
