package p000;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* renamed from: jj */
public interface C0969jj<Model, Data> {

    /* renamed from: jj$a */
    public static class C0970a<Data> {

        /* renamed from: a */
        public final C2005wf f3455a;

        /* renamed from: b */
        public final List<C2005wf> f3456b;

        /* renamed from: c */
        public final C0768gg<Data> f3457c;

        public C0970a(C2005wf wfVar, C0768gg<Data> ggVar) {
            List<C2005wf> emptyList = Collections.emptyList();
            Objects.requireNonNull(wfVar, "Argument must not be null");
            this.f3455a = wfVar;
            Objects.requireNonNull(emptyList, "Argument must not be null");
            this.f3456b = emptyList;
            Objects.requireNonNull(ggVar, "Argument must not be null");
            this.f3457c = ggVar;
        }
    }

    /* renamed from: a */
    C0970a<Data> mo132a(Model model, int i, int i2, C2150yf yfVar);

    /* renamed from: b */
    boolean mo133b(Model model);
}
