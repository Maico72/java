package p000;

import android.content.Context;

/* renamed from: cg */
public interface C0363cg<T> extends C2005wf {
    /* renamed from: b */
    C1675rh<T> mo142b(Context context, C1675rh<T> rhVar, int i, int i2);
}
