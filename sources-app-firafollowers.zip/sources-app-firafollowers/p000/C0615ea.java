package p000;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/* renamed from: ea */
public class C0615ea {

    /* renamed from: a */
    public final HashMap<String, C0273ba> f2513a = new HashMap<>();

    /* renamed from: a */
    public final void mo3304a() {
        for (C0273ba next : this.f2513a.values()) {
            Map<String, Object> map = next.f1298a;
            if (map != null) {
                synchronized (map) {
                    for (Object next2 : next.f1298a.values()) {
                        if (next2 instanceof Closeable) {
                            try {
                                ((Closeable) next2).close();
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }
            }
            next.mo1691a();
        }
        this.f2513a.clear();
    }
}
