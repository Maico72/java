package p000;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import p000.C1906v8;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: e8 */
public final class C0612e8 implements Parcelable {
    public static final Parcelable.Creator<C0612e8> CREATOR = new C0613a();

    /* renamed from: d */
    public final int[] f2496d;

    /* renamed from: e */
    public final ArrayList<String> f2497e;

    /* renamed from: f */
    public final int[] f2498f;

    /* renamed from: g */
    public final int[] f2499g;

    /* renamed from: h */
    public final int f2500h;

    /* renamed from: i */
    public final int f2501i;

    /* renamed from: j */
    public final String f2502j;

    /* renamed from: k */
    public final int f2503k;

    /* renamed from: l */
    public final int f2504l;

    /* renamed from: m */
    public final CharSequence f2505m;

    /* renamed from: n */
    public final int f2506n;

    /* renamed from: o */
    public final CharSequence f2507o;

    /* renamed from: p */
    public final ArrayList<String> f2508p;

    /* renamed from: q */
    public final ArrayList<String> f2509q;

    /* renamed from: r */
    public final boolean f2510r;

    /* renamed from: e8$a */
    public static class C0613a implements Parcelable.Creator<C0612e8> {
        public Object createFromParcel(Parcel parcel) {
            return new C0612e8(parcel);
        }

        public Object[] newArray(int i) {
            return new C0612e8[i];
        }
    }

    public C0612e8(Parcel parcel) {
        this.f2496d = parcel.createIntArray();
        this.f2497e = parcel.createStringArrayList();
        this.f2498f = parcel.createIntArray();
        this.f2499g = parcel.createIntArray();
        this.f2500h = parcel.readInt();
        this.f2501i = parcel.readInt();
        this.f2502j = parcel.readString();
        this.f2503k = parcel.readInt();
        this.f2504l = parcel.readInt();
        this.f2505m = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2506n = parcel.readInt();
        this.f2507o = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2508p = parcel.createStringArrayList();
        this.f2509q = parcel.createStringArrayList();
        this.f2510r = parcel.readInt() != 0;
    }

    public C0612e8(C0541d8 d8Var) {
        int size = d8Var.f6269a.size();
        this.f2496d = new int[(size * 5)];
        if (d8Var.f6276h) {
            this.f2497e = new ArrayList<>(size);
            this.f2498f = new int[size];
            this.f2499g = new int[size];
            int i = 0;
            int i2 = 0;
            while (i < size) {
                C1906v8.C1907a aVar = d8Var.f6269a.get(i);
                int i3 = i2 + 1;
                this.f2496d[i2] = aVar.f6285a;
                ArrayList<String> arrayList = this.f2497e;
                Fragment fragment = aVar.f6286b;
                arrayList.add(fragment != null ? fragment.f666h : null);
                int[] iArr = this.f2496d;
                int i4 = i3 + 1;
                iArr[i3] = aVar.f6287c;
                int i5 = i4 + 1;
                iArr[i4] = aVar.f6288d;
                int i6 = i5 + 1;
                iArr[i5] = aVar.f6289e;
                iArr[i6] = aVar.f6290f;
                this.f2498f[i] = aVar.f6291g.ordinal();
                this.f2499g[i] = aVar.f6292h.ordinal();
                i++;
                i2 = i6 + 1;
            }
            this.f2500h = d8Var.f6274f;
            this.f2501i = d8Var.f6275g;
            this.f2502j = d8Var.f6277i;
            this.f2503k = d8Var.f2198s;
            this.f2504l = d8Var.f6278j;
            this.f2505m = d8Var.f6279k;
            this.f2506n = d8Var.f6280l;
            this.f2507o = d8Var.f6281m;
            this.f2508p = d8Var.f6282n;
            this.f2509q = d8Var.f6283o;
            this.f2510r = d8Var.f6284p;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f2496d);
        parcel.writeStringList(this.f2497e);
        parcel.writeIntArray(this.f2498f);
        parcel.writeIntArray(this.f2499g);
        parcel.writeInt(this.f2500h);
        parcel.writeInt(this.f2501i);
        parcel.writeString(this.f2502j);
        parcel.writeInt(this.f2503k);
        parcel.writeInt(this.f2504l);
        TextUtils.writeToParcel(this.f2505m, parcel, 0);
        parcel.writeInt(this.f2506n);
        TextUtils.writeToParcel(this.f2507o, parcel, 0);
        parcel.writeStringList(this.f2508p);
        parcel.writeStringList(this.f2509q);
        parcel.writeInt(this.f2510r ? 1 : 0);
    }
}
