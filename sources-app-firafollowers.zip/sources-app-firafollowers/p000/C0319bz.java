package p000;

import p000.C1356oq;

@C0313bt
/* renamed from: bz */
public class C0319bz extends C2171yy<Object> {

    /* renamed from: f */
    public static final C0319bz f1369f = new C0319bz();

    public C0319bz() {
        super(Number.class, C1356oq.C1358b.INT, "integer");
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3742t(((Number) obj).intValue());
    }
}
