package p000;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: hc */
public class C0825hc {

    /* renamed from: a */
    public static C0545dc f3060a = new C1910vb();

    /* renamed from: b */
    public static ThreadLocal<WeakReference<C2047x3<ViewGroup, ArrayList<C0545dc>>>> f3061b = new ThreadLocal<>();

    /* renamed from: c */
    public static ArrayList<ViewGroup> f3062c = new ArrayList<>();

    /* renamed from: hc$a */
    public static class C0826a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

        /* renamed from: d */
        public C0545dc f3063d;

        /* renamed from: e */
        public ViewGroup f3064e;

        /* renamed from: hc$a$a */
        public class C0827a extends C0743gc {

            /* renamed from: a */
            public final /* synthetic */ C2047x3 f3065a;

            public C0827a(C2047x3 x3Var) {
                this.f3065a = x3Var;
            }

            /* renamed from: d */
            public void mo3021d(C0545dc dcVar) {
                ((ArrayList) this.f3065a.get(C0826a.this.f3064e)).remove(dcVar);
            }
        }

        public C0826a(C0545dc dcVar, ViewGroup viewGroup) {
            this.f3063d = dcVar;
            this.f3064e = viewGroup;
        }

        /* JADX WARNING: Removed duplicated region for block: B:103:0x021c  */
        /* JADX WARNING: Removed duplicated region for block: B:109:0x0249  */
        /* JADX WARNING: Removed duplicated region for block: B:12:0x005c  */
        /* JADX WARNING: Removed duplicated region for block: B:135:0x01f6 A[EDGE_INSN: B:135:0x01f6->B:93:0x01f6 ?: BREAK  , SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:19:0x009f  */
        /* JADX WARNING: Removed duplicated region for block: B:96:0x01fb  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onPreDraw() {
            /*
                r18 = this;
                r0 = r18
                android.view.ViewGroup r1 = r0.f3064e
                android.view.ViewTreeObserver r1 = r1.getViewTreeObserver()
                r1.removeOnPreDrawListener(r0)
                android.view.ViewGroup r1 = r0.f3064e
                r1.removeOnAttachStateChangeListener(r0)
                java.util.ArrayList<android.view.ViewGroup> r1 = p000.C0825hc.f3062c
                android.view.ViewGroup r2 = r0.f3064e
                boolean r1 = r1.remove(r2)
                r2 = 1
                if (r1 != 0) goto L_0x001c
                return r2
            L_0x001c:
                x3 r1 = p000.C0825hc.m2646a()
                android.view.ViewGroup r3 = r0.f3064e
                java.lang.Object r3 = r1.get(r3)
                java.util.ArrayList r3 = (java.util.ArrayList) r3
                r4 = 0
                if (r3 != 0) goto L_0x0036
                java.util.ArrayList r3 = new java.util.ArrayList
                r3.<init>()
                android.view.ViewGroup r5 = r0.f3064e
                r1.put(r5, r3)
                goto L_0x0042
            L_0x0036:
                int r5 = r3.size()
                if (r5 <= 0) goto L_0x0042
                java.util.ArrayList r5 = new java.util.ArrayList
                r5.<init>(r3)
                goto L_0x0043
            L_0x0042:
                r5 = r4
            L_0x0043:
                dc r6 = r0.f3063d
                r3.add(r6)
                dc r3 = r0.f3063d
                hc$a$a r6 = new hc$a$a
                r6.<init>(r1)
                r3.mo2992a(r6)
                dc r1 = r0.f3063d
                android.view.ViewGroup r3 = r0.f3064e
                r6 = 0
                r1.mo2999h(r3, r6)
                if (r5 == 0) goto L_0x0072
                java.util.Iterator r1 = r5.iterator()
            L_0x0060:
                boolean r3 = r1.hasNext()
                if (r3 == 0) goto L_0x0072
                java.lang.Object r3 = r1.next()
                dc r3 = (p000.C0545dc) r3
                android.view.ViewGroup r5 = r0.f3064e
                r3.mo3014x(r5)
                goto L_0x0060
            L_0x0072:
                dc r1 = r0.f3063d
                android.view.ViewGroup r8 = r0.f3064e
                java.util.Objects.requireNonNull(r1)
                java.util.ArrayList r3 = new java.util.ArrayList
                r3.<init>()
                r1.f2216n = r3
                java.util.ArrayList r3 = new java.util.ArrayList
                r3.<init>()
                r1.f2217o = r3
                mc r3 = r1.f2212j
                mc r5 = r1.f2213k
                x3 r7 = new x3
                x3<android.view.View, lc> r9 = r3.f4024a
                r7.<init>((p000.C0604e4) r9)
                x3 r9 = new x3
                x3<android.view.View, lc> r10 = r5.f4024a
                r9.<init>((p000.C0604e4) r10)
                r10 = 0
            L_0x009a:
                int[] r11 = r1.f2215m
                int r12 = r11.length
                if (r10 >= r12) goto L_0x01f6
                r11 = r11[r10]
                if (r11 == r2) goto L_0x01b4
                r12 = 2
                if (r11 == r12) goto L_0x0166
                r12 = 3
                if (r11 == r12) goto L_0x0112
                r12 = 4
                if (r11 == r12) goto L_0x00af
            L_0x00ac:
                r17 = r3
                goto L_0x010e
            L_0x00af:
                b4<android.view.View> r11 = r3.f4026c
                b4<android.view.View> r12 = r5.f4026c
                int r13 = r11.mo1592h()
                r14 = 0
            L_0x00b8:
                if (r14 >= r13) goto L_0x00ac
                java.lang.Object r15 = r11.mo1593i(r14)
                android.view.View r15 = (android.view.View) r15
                if (r15 == 0) goto L_0x0104
                boolean r16 = r1.mo3009s(r15)
                if (r16 == 0) goto L_0x0104
                boolean r6 = r11.f1249d
                if (r6 == 0) goto L_0x00cf
                r11.mo1588d()
            L_0x00cf:
                long[] r6 = r11.f1250e
                r17 = r3
                r2 = r6[r14]
                java.lang.Object r2 = r12.mo1589e(r2)
                android.view.View r2 = (android.view.View) r2
                if (r2 == 0) goto L_0x0106
                boolean r3 = r1.mo3009s(r2)
                if (r3 == 0) goto L_0x0106
                java.lang.Object r3 = r7.getOrDefault(r15, r4)
                lc r3 = (p000.C1104lc) r3
                java.lang.Object r6 = r9.getOrDefault(r2, r4)
                lc r6 = (p000.C1104lc) r6
                if (r3 == 0) goto L_0x0106
                if (r6 == 0) goto L_0x0106
                java.util.ArrayList<lc> r4 = r1.f2216n
                r4.add(r3)
                java.util.ArrayList<lc> r3 = r1.f2217o
                r3.add(r6)
                r7.remove(r15)
                r9.remove(r2)
                goto L_0x0106
            L_0x0104:
                r17 = r3
            L_0x0106:
                int r14 = r14 + 1
                r3 = r17
                r2 = 1
                r4 = 0
                r6 = 0
                goto L_0x00b8
            L_0x010e:
                r2 = r17
                goto L_0x01ec
            L_0x0112:
                r2 = r3
                android.util.SparseArray<android.view.View> r3 = r2.f4025b
                android.util.SparseArray<android.view.View> r4 = r5.f4025b
                int r6 = r3.size()
                r11 = 0
            L_0x011c:
                if (r11 >= r6) goto L_0x01ec
                java.lang.Object r12 = r3.valueAt(r11)
                android.view.View r12 = (android.view.View) r12
                if (r12 == 0) goto L_0x0161
                boolean r13 = r1.mo3009s(r12)
                if (r13 == 0) goto L_0x0161
                int r13 = r3.keyAt(r11)
                java.lang.Object r13 = r4.get(r13)
                android.view.View r13 = (android.view.View) r13
                if (r13 == 0) goto L_0x0161
                boolean r14 = r1.mo3009s(r13)
                if (r14 == 0) goto L_0x0161
                r14 = 0
                java.lang.Object r15 = r7.getOrDefault(r12, r14)
                lc r15 = (p000.C1104lc) r15
                java.lang.Object r17 = r9.getOrDefault(r13, r14)
                r14 = r17
                lc r14 = (p000.C1104lc) r14
                if (r15 == 0) goto L_0x0161
                if (r14 == 0) goto L_0x0161
                java.util.ArrayList<lc> r0 = r1.f2216n
                r0.add(r15)
                java.util.ArrayList<lc> r0 = r1.f2217o
                r0.add(r14)
                r7.remove(r12)
                r9.remove(r13)
            L_0x0161:
                int r11 = r11 + 1
                r0 = r18
                goto L_0x011c
            L_0x0166:
                r2 = r3
                x3<java.lang.String, android.view.View> r0 = r2.f4027d
                x3<java.lang.String, android.view.View> r3 = r5.f4027d
                int r4 = r0.f2478f
                r6 = 0
            L_0x016e:
                if (r6 >= r4) goto L_0x01ec
                java.lang.Object r11 = r0.mo3284l(r6)
                android.view.View r11 = (android.view.View) r11
                if (r11 == 0) goto L_0x01b1
                boolean r12 = r1.mo3009s(r11)
                if (r12 == 0) goto L_0x01b1
                java.lang.Object r12 = r0.mo3278h(r6)
                java.lang.Object r12 = r3.get(r12)
                android.view.View r12 = (android.view.View) r12
                if (r12 == 0) goto L_0x01b1
                boolean r13 = r1.mo3009s(r12)
                if (r13 == 0) goto L_0x01b1
                r13 = 0
                java.lang.Object r14 = r7.getOrDefault(r11, r13)
                lc r14 = (p000.C1104lc) r14
                java.lang.Object r15 = r9.getOrDefault(r12, r13)
                lc r15 = (p000.C1104lc) r15
                if (r14 == 0) goto L_0x01b1
                if (r15 == 0) goto L_0x01b1
                java.util.ArrayList<lc> r13 = r1.f2216n
                r13.add(r14)
                java.util.ArrayList<lc> r13 = r1.f2217o
                r13.add(r15)
                r7.remove(r11)
                r9.remove(r12)
            L_0x01b1:
                int r6 = r6 + 1
                goto L_0x016e
            L_0x01b4:
                r2 = r3
                int r0 = r7.f2478f
            L_0x01b7:
                int r0 = r0 + -1
                if (r0 < 0) goto L_0x01ec
                java.lang.Object r3 = r7.mo3278h(r0)
                android.view.View r3 = (android.view.View) r3
                if (r3 == 0) goto L_0x01b7
                boolean r4 = r1.mo3009s(r3)
                if (r4 == 0) goto L_0x01b7
                java.lang.Object r3 = r9.remove(r3)
                lc r3 = (p000.C1104lc) r3
                if (r3 == 0) goto L_0x01b7
                android.view.View r4 = r3.f3869b
                if (r4 == 0) goto L_0x01b7
                boolean r4 = r1.mo3009s(r4)
                if (r4 == 0) goto L_0x01b7
                java.lang.Object r4 = r7.mo3282j(r0)
                lc r4 = (p000.C1104lc) r4
                java.util.ArrayList<lc> r6 = r1.f2216n
                r6.add(r4)
                java.util.ArrayList<lc> r4 = r1.f2217o
                r4.add(r3)
                goto L_0x01b7
            L_0x01ec:
                int r10 = r10 + 1
                r0 = r18
                r3 = r2
                r2 = 1
                r4 = 0
                r6 = 0
                goto L_0x009a
            L_0x01f6:
                r0 = 0
            L_0x01f7:
                int r2 = r7.f2478f
                if (r0 >= r2) goto L_0x0217
                java.lang.Object r2 = r7.mo3284l(r0)
                lc r2 = (p000.C1104lc) r2
                android.view.View r3 = r2.f3869b
                boolean r3 = r1.mo3009s(r3)
                if (r3 == 0) goto L_0x0214
                java.util.ArrayList<lc> r3 = r1.f2216n
                r3.add(r2)
                java.util.ArrayList<lc> r2 = r1.f2217o
                r3 = 0
                r2.add(r3)
            L_0x0214:
                int r0 = r0 + 1
                goto L_0x01f7
            L_0x0217:
                r0 = 0
            L_0x0218:
                int r2 = r9.f2478f
                if (r0 >= r2) goto L_0x0238
                java.lang.Object r2 = r9.mo3284l(r0)
                lc r2 = (p000.C1104lc) r2
                android.view.View r3 = r2.f3869b
                boolean r3 = r1.mo3009s(r3)
                if (r3 == 0) goto L_0x0235
                java.util.ArrayList<lc> r3 = r1.f2217o
                r3.add(r2)
                java.util.ArrayList<lc> r2 = r1.f2216n
                r3 = 0
                r2.add(r3)
            L_0x0235:
                int r0 = r0 + 1
                goto L_0x0218
            L_0x0238:
                x3 r0 = p000.C0545dc.m1756o()
                int r2 = r0.f2478f
                tc r3 = p000.C1417pc.f4821a
                wc r3 = new wc
                r3.<init>(r8)
                r4 = 1
                int r2 = r2 - r4
            L_0x0247:
                if (r2 < 0) goto L_0x029b
                java.lang.Object r4 = r0.mo3278h(r2)
                android.animation.Animator r4 = (android.animation.Animator) r4
                r5 = 0
                if (r4 == 0) goto L_0x0298
                java.lang.Object r6 = r0.getOrDefault(r4, r5)
                dc$b r6 = (p000.C0545dc.C0547b) r6
                if (r6 == 0) goto L_0x0298
                android.view.View r7 = r6.f2226a
                if (r7 == 0) goto L_0x0298
                xc r7 = r6.f2229d
                boolean r7 = r3.equals(r7)
                if (r7 == 0) goto L_0x0298
                lc r7 = r6.f2228c
                android.view.View r9 = r6.f2226a
                r10 = 1
                lc r11 = r1.mo3007q(r9, r10)
                lc r9 = r1.mo3005n(r9, r10)
                if (r11 != 0) goto L_0x0277
                if (r9 == 0) goto L_0x0281
            L_0x0277:
                dc r6 = r6.f2230e
                boolean r6 = r6.mo3008r(r7, r9)
                if (r6 == 0) goto L_0x0281
                r6 = 1
                goto L_0x0282
            L_0x0281:
                r6 = 0
            L_0x0282:
                if (r6 == 0) goto L_0x0298
                boolean r6 = r4.isRunning()
                if (r6 != 0) goto L_0x0295
                boolean r6 = r4.isStarted()
                if (r6 == 0) goto L_0x0291
                goto L_0x0295
            L_0x0291:
                r0.remove(r4)
                goto L_0x0298
            L_0x0295:
                r4.cancel()
            L_0x0298:
                int r2 = r2 + -1
                goto L_0x0247
            L_0x029b:
                mc r9 = r1.f2212j
                mc r10 = r1.f2213k
                java.util.ArrayList<lc> r11 = r1.f2216n
                java.util.ArrayList<lc> r12 = r1.f2217o
                r7 = r1
                r7.mo3003l(r8, r9, r10, r11, r12)
                r1.mo3015y()
                r0 = 1
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0825hc.C0826a.onPreDraw():boolean");
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            this.f3064e.getViewTreeObserver().removeOnPreDrawListener(this);
            this.f3064e.removeOnAttachStateChangeListener(this);
            C0825hc.f3062c.remove(this.f3064e);
            ArrayList arrayList = C0825hc.m2646a().get(this.f3064e);
            if (arrayList != null && arrayList.size() > 0) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((C0545dc) it.next()).mo3014x(this.f3064e);
                }
            }
            this.f3063d.mo3000i(true);
        }
    }

    /* renamed from: a */
    public static C2047x3<ViewGroup, ArrayList<C0545dc>> m2646a() {
        C2047x3<ViewGroup, ArrayList<C0545dc>> x3Var;
        WeakReference weakReference = f3061b.get();
        if (weakReference != null && (x3Var = (C2047x3) weakReference.get()) != null) {
            return x3Var;
        }
        C2047x3<ViewGroup, ArrayList<C0545dc>> x3Var2 = new C2047x3<>();
        f3061b.set(new WeakReference(x3Var2));
        return x3Var2;
    }
}
