package p000;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import java.nio.ByteBuffer;

/* renamed from: ik */
public final class C0898ik implements C0054ag<ByteBuffer, Bitmap> {

    /* renamed from: a */
    public final C0639ek f3272a = new C0639ek();

    /* renamed from: a */
    public C1675rh mo122a(Object obj, int i, int i2, C2150yf yfVar) {
        return this.f3272a.mo122a(ImageDecoder.createSource((ByteBuffer) obj), i, i2, yfVar);
    }

    /* renamed from: b */
    public /* bridge */ /* synthetic */ boolean mo123b(Object obj, C2150yf yfVar) {
        ByteBuffer byteBuffer = (ByteBuffer) obj;
        return true;
    }
}
