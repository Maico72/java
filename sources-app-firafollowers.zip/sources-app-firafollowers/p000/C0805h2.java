package p000;

import android.view.Menu;
import android.view.Window;
import p000.C0003a1;

/* renamed from: h2 */
public interface C0805h2 {
    /* renamed from: a */
    void mo246a(Menu menu, C0003a1.C0004a aVar);

    /* renamed from: b */
    boolean mo247b();

    /* renamed from: c */
    boolean mo248c();

    /* renamed from: d */
    boolean mo250d();

    /* renamed from: e */
    boolean mo252e();

    /* renamed from: f */
    void mo253f();

    /* renamed from: g */
    boolean mo255g();

    /* renamed from: k */
    void mo265k(int i);

    /* renamed from: l */
    void mo266l();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
