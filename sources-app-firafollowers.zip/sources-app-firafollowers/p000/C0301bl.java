package p000;

import android.graphics.Bitmap;

/* renamed from: bl */
public final class C0301bl implements C0054ag<Bitmap, Bitmap> {

    /* renamed from: bl$a */
    public static final class C0302a implements C1675rh<Bitmap> {

        /* renamed from: d */
        public final Bitmap f1346d;

        public C0302a(Bitmap bitmap) {
            this.f1346d = bitmap;
        }

        /* renamed from: b */
        public Object mo1714b() {
            return this.f1346d;
        }

        /* renamed from: c */
        public int mo1715c() {
            return C1624qo.m4653d(this.f1346d);
        }

        /* renamed from: d */
        public Class<Bitmap> mo1716d() {
            return Bitmap.class;
        }

        /* renamed from: e */
        public void mo1717e() {
        }
    }

    /* renamed from: a */
    public C1675rh mo122a(Object obj, int i, int i2, C2150yf yfVar) {
        return new C0302a((Bitmap) obj);
    }

    /* renamed from: b */
    public /* bridge */ /* synthetic */ boolean mo123b(Object obj, C2150yf yfVar) {
        Bitmap bitmap = (Bitmap) obj;
        return true;
    }
}
