package p000;

import java.security.MessageDigest;
import java.util.Map;
import java.util.Objects;

/* renamed from: jh */
public class C0964jh implements C2005wf {

    /* renamed from: b */
    public final Object f3434b;

    /* renamed from: c */
    public final int f3435c;

    /* renamed from: d */
    public final int f3436d;

    /* renamed from: e */
    public final Class<?> f3437e;

    /* renamed from: f */
    public final Class<?> f3438f;

    /* renamed from: g */
    public final C2005wf f3439g;

    /* renamed from: h */
    public final Map<Class<?>, C0363cg<?>> f3440h;

    /* renamed from: i */
    public final C2150yf f3441i;

    /* renamed from: j */
    public int f3442j;

    public C0964jh(Object obj, C2005wf wfVar, int i, int i2, Map<Class<?>, C0363cg<?>> map, Class<?> cls, Class<?> cls2, C2150yf yfVar) {
        Objects.requireNonNull(obj, "Argument must not be null");
        this.f3434b = obj;
        Objects.requireNonNull(wfVar, "Signature must not be null");
        this.f3439g = wfVar;
        this.f3435c = i;
        this.f3436d = i2;
        Objects.requireNonNull(map, "Argument must not be null");
        this.f3440h = map;
        Objects.requireNonNull(cls, "Resource class must not be null");
        this.f3437e = cls;
        Objects.requireNonNull(cls2, "Transcode class must not be null");
        this.f3438f = cls2;
        Objects.requireNonNull(yfVar, "Argument must not be null");
        this.f3441i = yfVar;
    }

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0964jh)) {
            return false;
        }
        C0964jh jhVar = (C0964jh) obj;
        return this.f3434b.equals(jhVar.f3434b) && this.f3439g.equals(jhVar.f3439g) && this.f3436d == jhVar.f3436d && this.f3435c == jhVar.f3435c && this.f3440h.equals(jhVar.f3440h) && this.f3437e.equals(jhVar.f3437e) && this.f3438f.equals(jhVar.f3438f) && this.f3441i.equals(jhVar.f3441i);
    }

    public int hashCode() {
        if (this.f3442j == 0) {
            int hashCode = this.f3434b.hashCode();
            this.f3442j = hashCode;
            int hashCode2 = this.f3439g.hashCode() + (hashCode * 31);
            this.f3442j = hashCode2;
            int i = (hashCode2 * 31) + this.f3435c;
            this.f3442j = i;
            int i2 = (i * 31) + this.f3436d;
            this.f3442j = i2;
            int hashCode3 = this.f3440h.hashCode() + (i2 * 31);
            this.f3442j = hashCode3;
            int hashCode4 = this.f3437e.hashCode() + (hashCode3 * 31);
            this.f3442j = hashCode4;
            int hashCode5 = this.f3438f.hashCode() + (hashCode4 * 31);
            this.f3442j = hashCode5;
            this.f3442j = this.f3441i.hashCode() + (hashCode5 * 31);
        }
        return this.f3442j;
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("EngineKey{model=");
        d.append(this.f3434b);
        d.append(", width=");
        d.append(this.f3435c);
        d.append(", height=");
        d.append(this.f3436d);
        d.append(", resourceClass=");
        d.append(this.f3437e);
        d.append(", transcodeClass=");
        d.append(this.f3438f);
        d.append(", signature=");
        d.append(this.f3439g);
        d.append(", hashCode=");
        d.append(this.f3442j);
        d.append(", transformations=");
        d.append(this.f3440h);
        d.append(", options=");
        d.append(this.f3441i);
        d.append('}');
        return d.toString();
    }
}
