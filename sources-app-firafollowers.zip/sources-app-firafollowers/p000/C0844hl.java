package p000;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.util.Objects;

/* renamed from: hl */
public abstract class C0844hl<T extends Drawable> implements C1675rh<T>, C1256nh {

    /* renamed from: d */
    public final T f3140d;

    public C0844hl(T t) {
        Objects.requireNonNull(t, "Argument must not be null");
        this.f3140d = t;
    }

    /* renamed from: a */
    public void mo3626a() {
        Bitmap b;
        T t = this.f3140d;
        if (t instanceof BitmapDrawable) {
            b = ((BitmapDrawable) t).getBitmap();
        } else if (t instanceof C1452pl) {
            b = ((C1452pl) t).mo5258b();
        } else {
            return;
        }
        b.prepareToDraw();
    }

    /* renamed from: b */
    public Object mo1714b() {
        Drawable.ConstantState constantState = this.f3140d.getConstantState();
        return constantState == null ? this.f3140d : constantState.newDrawable();
    }
}
