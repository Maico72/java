package p000;

/* renamed from: b4 */
public class C0259b4<E> implements Cloneable {

    /* renamed from: h */
    public static final Object f1248h = new Object();

    /* renamed from: d */
    public boolean f1249d = false;

    /* renamed from: e */
    public long[] f1250e;

    /* renamed from: f */
    public Object[] f1251f;

    /* renamed from: g */
    public int f1252g;

    public C0259b4() {
        int f = C0007a4.m22f(10);
        this.f1250e = new long[f];
        this.f1251f = new Object[f];
    }

    /* renamed from: a */
    public void mo1584a(long j, E e) {
        int i = this.f1252g;
        if (i == 0 || j > this.f1250e[i - 1]) {
            if (this.f1249d && i >= this.f1250e.length) {
                mo1588d();
            }
            int i2 = this.f1252g;
            if (i2 >= this.f1250e.length) {
                int f = C0007a4.m22f(i2 + 1);
                long[] jArr = new long[f];
                Object[] objArr = new Object[f];
                long[] jArr2 = this.f1250e;
                System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
                Object[] objArr2 = this.f1251f;
                System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
                this.f1250e = jArr;
                this.f1251f = objArr;
            }
            this.f1250e[i2] = j;
            this.f1251f[i2] = e;
            this.f1252g = i2 + 1;
            return;
        }
        mo1591g(j, e);
    }

    /* renamed from: b */
    public void mo1585b() {
        int i = this.f1252g;
        Object[] objArr = this.f1251f;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f1252g = 0;
        this.f1249d = false;
    }

    /* renamed from: c */
    public C0259b4<E> clone() {
        try {
            C0259b4<E> b4Var = (C0259b4) super.clone();
            b4Var.f1250e = (long[]) this.f1250e.clone();
            b4Var.f1251f = (Object[]) this.f1251f.clone();
            return b4Var;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    /* renamed from: d */
    public final void mo1588d() {
        int i = this.f1252g;
        long[] jArr = this.f1250e;
        Object[] objArr = this.f1251f;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f1248h) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f1249d = false;
        this.f1252g = i2;
    }

    /* renamed from: e */
    public E mo1589e(long j) {
        return mo1590f(j, (Object) null);
    }

    /* renamed from: f */
    public E mo1590f(long j, E e) {
        int b = C0007a4.m18b(this.f1250e, this.f1252g, j);
        if (b >= 0) {
            E[] eArr = this.f1251f;
            if (eArr[b] != f1248h) {
                return eArr[b];
            }
        }
        return e;
    }

    /* renamed from: g */
    public void mo1591g(long j, E e) {
        int b = C0007a4.m18b(this.f1250e, this.f1252g, j);
        if (b >= 0) {
            this.f1251f[b] = e;
            return;
        }
        int i = b ^ -1;
        int i2 = this.f1252g;
        if (i < i2) {
            Object[] objArr = this.f1251f;
            if (objArr[i] == f1248h) {
                this.f1250e[i] = j;
                objArr[i] = e;
                return;
            }
        }
        if (this.f1249d && i2 >= this.f1250e.length) {
            mo1588d();
            i = C0007a4.m18b(this.f1250e, this.f1252g, j) ^ -1;
        }
        int i3 = this.f1252g;
        if (i3 >= this.f1250e.length) {
            int f = C0007a4.m22f(i3 + 1);
            long[] jArr = new long[f];
            Object[] objArr2 = new Object[f];
            long[] jArr2 = this.f1250e;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f1251f;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f1250e = jArr;
            this.f1251f = objArr2;
        }
        int i4 = this.f1252g;
        if (i4 - i != 0) {
            long[] jArr3 = this.f1250e;
            int i5 = i + 1;
            System.arraycopy(jArr3, i, jArr3, i5, i4 - i);
            Object[] objArr4 = this.f1251f;
            System.arraycopy(objArr4, i, objArr4, i5, this.f1252g - i);
        }
        this.f1250e[i] = j;
        this.f1251f[i] = e;
        this.f1252g++;
    }

    /* renamed from: h */
    public int mo1592h() {
        if (this.f1249d) {
            mo1588d();
        }
        return this.f1252g;
    }

    /* renamed from: i */
    public E mo1593i(int i) {
        if (this.f1249d) {
            mo1588d();
        }
        return this.f1251f[i];
    }

    public String toString() {
        if (mo1592h() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1252g * 28);
        sb.append('{');
        for (int i = 0; i < this.f1252g; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            if (this.f1249d) {
                mo1588d();
            }
            sb.append(this.f1250e[i]);
            sb.append('=');
            Object i2 = mo1593i(i);
            if (i2 != this) {
                sb.append(i2);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
