package p000;

import android.view.View;
import androidx.appcompat.app.AlertController;

/* renamed from: j */
public class C0926j implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ View f3319d;

    /* renamed from: e */
    public final /* synthetic */ View f3320e;

    /* renamed from: f */
    public final /* synthetic */ AlertController f3321f;

    public C0926j(AlertController alertController, View view, View view2) {
        this.f3321f = alertController;
        this.f3319d = view;
        this.f3320e = view2;
    }

    public void run() {
        AlertController.m141c(this.f3321f.f242g, this.f3319d, this.f3320e);
    }
}
