package p000;

/* renamed from: ih */
public interface C0893ih {
}
