package p000;

/* renamed from: by */
public final class C0318by {

    /* renamed from: a */
    public final C0581dq<?> f1366a;

    /* renamed from: b */
    public Object f1367b;

    /* renamed from: c */
    public boolean f1368c = false;

    public C0318by(C0581dq<?> dqVar) {
        this.f1366a = dqVar;
    }

    /* renamed from: a */
    public void mo1732a(C1200mq mqVar, C0221at atVar, C1638qx qxVar) {
        this.f1368c = true;
        if (mqVar.mo3725c()) {
            Object obj = this.f1367b;
            mqVar.mo3749z(obj == null ? null : String.valueOf(obj));
            return;
        }
        C1882uq uqVar = qxVar.f5357b;
        if (uqVar != null) {
            mqVar.mo3737o(uqVar);
            qxVar.f5359d.mo1481f(this.f1367b, mqVar, atVar);
        }
    }

    /* renamed from: b */
    public boolean mo1733b(C1200mq mqVar, C0221at atVar, C1638qx qxVar) {
        if (this.f1367b == null) {
            return false;
        }
        if (!this.f1368c && !qxVar.f5360e) {
            return false;
        }
        if (!mqVar.mo3725c()) {
            qxVar.f5359d.mo1481f(this.f1367b, mqVar, atVar);
            return true;
        }
        String.valueOf(this.f1367b);
        throw new C1137lq("No native support for writing Object Ids", mqVar);
    }
}
