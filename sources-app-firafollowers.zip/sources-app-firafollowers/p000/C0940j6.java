package p000;

/* renamed from: j6 */
public interface C0940j6<T> {
    /* renamed from: a */
    boolean mo4123a(T t);

    /* renamed from: b */
    T mo4124b();
}
