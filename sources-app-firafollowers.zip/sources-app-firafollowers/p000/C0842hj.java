package p000;

/* renamed from: hj */
public interface C0842hj {
    /* renamed from: a */
    boolean mo3947a(Object obj);
}
