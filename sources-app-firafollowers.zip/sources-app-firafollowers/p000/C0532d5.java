package p000;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: d5 */
public final class C0532d5 {

    /* renamed from: d5$a */
    public static class C0533a {

        /* renamed from: a */
        public static final Object f2162a = new Object();

        /* renamed from: b */
        public static Method f2163b;

        /* renamed from: c */
        public static boolean f2164c;
    }

    /* renamed from: a */
    public static Drawable m1701a(Resources resources, int i, Resources.Theme theme) {
        return Build.VERSION.SDK_INT >= 21 ? resources.getDrawable(i, theme) : resources.getDrawable(i);
    }

    /* renamed from: b */
    public static C1980w4 m1702b(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme, String str, int i, int i2) {
        C1980w4 w4Var;
        if (m1704d(xmlPullParser, str)) {
            TypedValue typedValue = new TypedValue();
            typedArray.getValue(i, typedValue);
            int i3 = typedValue.type;
            if (i3 >= 28 && i3 <= 31) {
                return new C1980w4((Shader) null, (ColorStateList) null, typedValue.data);
            }
            try {
                w4Var = C1980w4.m5531a(typedArray.getResources(), typedArray.getResourceId(i, 0), theme);
            } catch (Exception e) {
                Log.e("ComplexColorCompat", "Failed to inflate ComplexColor.", e);
                w4Var = null;
            }
            if (w4Var != null) {
                return w4Var;
            }
        }
        return new C1980w4((Shader) null, (ColorStateList) null, i2);
    }

    /* renamed from: c */
    public static String m1703c(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i) {
        if (!m1704d(xmlPullParser, str)) {
            return null;
        }
        return typedArray.getString(i);
    }

    /* renamed from: d */
    public static boolean m1704d(XmlPullParser xmlPullParser, String str) {
        return xmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", str) != null;
    }

    /* renamed from: e */
    public static TypedArray m1705e(Resources resources, Resources.Theme theme, AttributeSet attributeSet, int[] iArr) {
        return theme == null ? resources.obtainAttributes(attributeSet, iArr) : theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }
}
