package p000;

/* renamed from: cb */
public class C0348cb {

    /* renamed from: a */
    public final C0349a f1544a;

    /* renamed from: cb$a */
    public interface C0349a {
    }

    public C0348cb(C0349a aVar) {
        this.f1544a = aVar;
    }
}
