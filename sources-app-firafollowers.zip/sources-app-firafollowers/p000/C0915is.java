package p000;

import java.io.Serializable;

/* renamed from: is */
public abstract class C0915is extends C0792gs implements Serializable {
}
