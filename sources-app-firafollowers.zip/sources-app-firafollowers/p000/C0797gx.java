package p000;

import java.io.Serializable;
import p000.C1029kp;

/* renamed from: gx */
public abstract class C0797gx extends C1700rw implements Serializable {
    public C0797gx() {
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0797gx(p000.C0652ev r15, p000.o00 r16, p000.C1035ks r17, p000.C1462ps<?> r18, p000.C0230aw r19, p000.C1035ks r20, p000.C1029kp.C1031b r21, java.lang.Class<?>[] r22) {
        /*
            r14 = this;
            r0 = r21
            kp$a r1 = p000.C1029kp.C1030a.USE_DEFAULTS
            kp$a r2 = p000.C1029kp.C1030a.ALWAYS
            uu r5 = r15.mo3186l()
            r3 = 0
            if (r0 != 0) goto L_0x000f
            r11 = 0
            goto L_0x0017
        L_0x000f:
            kp$a r4 = r0.f3669d
            if (r4 == r2) goto L_0x0016
            if (r4 == r1) goto L_0x0016
            r3 = 1
        L_0x0016:
            r11 = r3
        L_0x0017:
            if (r0 != 0) goto L_0x001d
            java.lang.Boolean r0 = java.lang.Boolean.FALSE
        L_0x001b:
            r12 = r0
            goto L_0x002d
        L_0x001d:
            kp$a r0 = r0.f3669d
            if (r0 == r2) goto L_0x002b
            kp$a r2 = p000.C1029kp.C1030a.NON_NULL
            if (r0 == r2) goto L_0x002b
            if (r0 != r1) goto L_0x0028
            goto L_0x002b
        L_0x0028:
            kp$a r0 = p000.C1029kp.C1030a.NON_EMPTY
            goto L_0x001b
        L_0x002b:
            r0 = 0
            goto L_0x001b
        L_0x002d:
            r8 = 0
            r9 = 0
            r10 = 0
            r13 = 0
            r3 = r14
            r4 = r15
            r6 = r16
            r7 = r17
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0797gx.<init>(ev, o00, ks, ps, aw, ks, kp$b, java.lang.Class[]):void");
    }

    /* renamed from: j */
    public void mo3841j(Object obj, C1200mq mqVar, C0221at atVar) {
        Object l = mo3843l(obj, mqVar, atVar);
        if (l == null) {
            C1462ps<Object> psVar = this.f5627o;
            if (psVar != null) {
                psVar.mo1481f(null, mqVar, atVar);
            } else {
                mqVar.mo3739q();
            }
        } else {
            C1462ps<Object> psVar2 = this.f5626n;
            if (psVar2 == null) {
                Class<?> cls = l.getClass();
                C1762sx sxVar = this.f5629q;
                C1462ps<Object> c = sxVar.mo5880c(cls);
                psVar2 = c == null ? mo5763e(sxVar, cls, atVar) : c;
            }
            Object obj2 = this.f5631s;
            if (obj2 != null) {
                if (C1029kp.C1030a.NON_EMPTY == obj2) {
                    if (psVar2.mo3672d(atVar, l)) {
                        C1462ps<Object> psVar3 = this.f5627o;
                        if (psVar3 != null) {
                            psVar3.mo1481f(null, mqVar, atVar);
                            return;
                        } else {
                            mqVar.mo3739q();
                            return;
                        }
                    }
                } else if (obj2.equals(l)) {
                    C1462ps<Object> psVar4 = this.f5627o;
                    if (psVar4 != null) {
                        psVar4.mo1481f(null, mqVar, atVar);
                        return;
                    } else {
                        mqVar.mo3739q();
                        return;
                    }
                }
            }
            if (l != obj || !mo5764f(mqVar, atVar, psVar2)) {
                C0230aw awVar = this.f5628p;
                if (awVar == null) {
                    psVar2.mo1481f(l, mqVar, atVar);
                } else {
                    psVar2.mo1482g(l, mqVar, atVar, awVar);
                }
            }
        }
    }

    /* renamed from: k */
    public void mo3842k(Object obj, C1200mq mqVar, C0221at atVar) {
        Object l = mo3843l(obj, mqVar, atVar);
        if (l != null) {
            C1462ps<Object> psVar = this.f5626n;
            if (psVar == null) {
                Class<?> cls = l.getClass();
                C1762sx sxVar = this.f5629q;
                C1462ps<Object> c = sxVar.mo5880c(cls);
                psVar = c == null ? mo5763e(sxVar, cls, atVar) : c;
            }
            Object obj2 = this.f5631s;
            if (obj2 != null) {
                if (C1029kp.C1030a.NON_EMPTY == obj2) {
                    if (psVar.mo3672d(atVar, l)) {
                        return;
                    }
                } else if (obj2.equals(l)) {
                    return;
                }
            }
            if (l != obj || !mo5764f(mqVar, atVar, psVar)) {
                mqVar.mo3737o(this.f5617e);
                C0230aw awVar = this.f5628p;
                if (awVar == null) {
                    psVar.mo1481f(l, mqVar, atVar);
                } else {
                    psVar.mo1482g(l, mqVar, atVar, awVar);
                }
            }
        } else if (this.f5627o != null) {
            mqVar.mo3737o(this.f5617e);
            this.f5627o.mo1481f(null, mqVar, atVar);
        }
    }

    /* renamed from: l */
    public abstract Object mo3843l(Object obj, C1200mq mqVar, C0221at atVar);

    /* renamed from: m */
    public abstract C0797gx mo3844m(C1757st<?> stVar, C1364ou ouVar, C0652ev evVar, C1035ks ksVar);
}
