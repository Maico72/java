package p000;

/* renamed from: fm */
public class C0708fm implements C1454pm {
    /* renamed from: a */
    public void mo3402a(C1622qm qmVar) {
        qmVar.mo109i();
    }

    /* renamed from: b */
    public void mo3403b(C1622qm qmVar) {
    }
}
