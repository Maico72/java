package p000;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;

/* renamed from: e9 */
public class C0614e9 implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ ArrayList f2511d;

    /* renamed from: e */
    public final /* synthetic */ Map f2512e;

    public C0614e9(C0680f9 f9Var, ArrayList arrayList, Map map) {
        this.f2511d = arrayList;
        this.f2512e = map;
    }

    public void run() {
        int size = this.f2511d.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f2511d.get(i);
            C0010a7.m46s(view, (String) this.f2512e.get(C0010a7.m36i(view)));
        }
    }
}
