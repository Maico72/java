package p000;

import android.widget.ListView;

/* renamed from: d1 */
public interface C0522d1 {
    /* renamed from: b */
    boolean mo2858b();

    void dismiss();

    /* renamed from: f */
    void mo2860f();

    /* renamed from: k */
    ListView mo2861k();
}
