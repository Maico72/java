package p000;

/* renamed from: de */
public class C0551de extends C0685fe {
    public C0551de(C1999wd wdVar) {
        super(wdVar);
    }
}
