package p000;

import android.util.AndroidRuntimeException;

/* renamed from: h9 */
public final class C0819h9 extends AndroidRuntimeException {
    public C0819h9(String str) {
        super(str);
    }
}
