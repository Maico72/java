package p000;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.StrictMode;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: cf */
public final class C0357cf implements Closeable {

    /* renamed from: d */
    public final File f1560d;

    /* renamed from: e */
    public final File f1561e;

    /* renamed from: f */
    public final File f1562f;

    /* renamed from: g */
    public final File f1563g;

    /* renamed from: h */
    public final int f1564h;

    /* renamed from: i */
    public long f1565i;

    /* renamed from: j */
    public final int f1566j;

    /* renamed from: k */
    public long f1567k = 0;

    /* renamed from: l */
    public Writer f1568l;

    /* renamed from: m */
    public final LinkedHashMap<String, C0361d> f1569m = new LinkedHashMap<>(0, 0.75f, true);

    /* renamed from: n */
    public int f1570n;

    /* renamed from: o */
    public long f1571o = 0;

    /* renamed from: p */
    public final ThreadPoolExecutor f1572p = new ThreadPoolExecutor(0, 1, 60, TimeUnit.SECONDS, new LinkedBlockingQueue(), new C0359b((C0358a) null));

    /* renamed from: q */
    public final Callable<Void> f1573q = new C0358a();

    /* renamed from: cf$a */
    public class C0358a implements Callable<Void> {
        public C0358a() {
        }

        public Object call() {
            synchronized (C0357cf.this) {
                C0357cf cfVar = C0357cf.this;
                if (cfVar.f1568l != null) {
                    cfVar.mo1945o();
                    if (C0357cf.this.mo1940h()) {
                        C0357cf.this.mo1944m();
                        C0357cf.this.f1570n = 0;
                    }
                }
            }
            return null;
        }
    }

    /* renamed from: cf$b */
    public static final class C0359b implements ThreadFactory {
        public C0359b(C0358a aVar) {
        }

        public synchronized Thread newThread(Runnable runnable) {
            Thread thread;
            thread = new Thread(runnable, "glide-disk-lru-cache-thread");
            thread.setPriority(1);
            return thread;
        }
    }

    /* renamed from: cf$c */
    public final class C0360c {

        /* renamed from: a */
        public final C0361d f1575a;

        /* renamed from: b */
        public final boolean[] f1576b;

        /* renamed from: c */
        public boolean f1577c;

        public C0360c(C0361d dVar, C0358a aVar) {
            boolean[] zArr;
            this.f1575a = dVar;
            if (dVar.f1583e) {
                zArr = null;
            } else {
                zArr = new boolean[C0357cf.this.f1566j];
            }
            this.f1576b = zArr;
        }

        /* renamed from: a */
        public void mo1948a() {
            C0357cf.m1333a(C0357cf.this, this, false);
        }

        /* renamed from: b */
        public File mo1949b(int i) {
            File file;
            synchronized (C0357cf.this) {
                C0361d dVar = this.f1575a;
                if (dVar.f1584f == this) {
                    if (!dVar.f1583e) {
                        this.f1576b[i] = true;
                    }
                    file = dVar.f1582d[i];
                    C0357cf.this.f1560d.mkdirs();
                } else {
                    throw new IllegalStateException();
                }
            }
            return file;
        }
    }

    /* renamed from: cf$d */
    public final class C0361d {

        /* renamed from: a */
        public final String f1579a;

        /* renamed from: b */
        public final long[] f1580b;

        /* renamed from: c */
        public File[] f1581c;

        /* renamed from: d */
        public File[] f1582d;

        /* renamed from: e */
        public boolean f1583e;

        /* renamed from: f */
        public C0360c f1584f;

        /* renamed from: g */
        public long f1585g;

        public C0361d(String str, C0358a aVar) {
            this.f1579a = str;
            int i = C0357cf.this.f1566j;
            this.f1580b = new long[i];
            this.f1581c = new File[i];
            this.f1582d = new File[i];
            StringBuilder sb = new StringBuilder(str);
            sb.append('.');
            int length = sb.length();
            for (int i2 = 0; i2 < C0357cf.this.f1566j; i2++) {
                sb.append(i2);
                this.f1581c[i2] = new File(C0357cf.this.f1560d, sb.toString());
                sb.append(".tmp");
                this.f1582d[i2] = new File(C0357cf.this.f1560d, sb.toString());
                sb.setLength(length);
            }
        }

        /* renamed from: a */
        public String mo1950a() {
            StringBuilder sb = new StringBuilder();
            for (long append : this.f1580b) {
                sb.append(' ');
                sb.append(append);
            }
            return sb.toString();
        }

        /* renamed from: b */
        public final IOException mo1951b(String[] strArr) {
            StringBuilder d = C1012kd.m3195d("unexpected journal line: ");
            d.append(Arrays.toString(strArr));
            throw new IOException(d.toString());
        }
    }

    /* renamed from: cf$e */
    public final class C0362e {

        /* renamed from: a */
        public final File[] f1587a;

        public C0362e(C0357cf cfVar, String str, long j, File[] fileArr, long[] jArr, C0358a aVar) {
            this.f1587a = fileArr;
        }
    }

    public C0357cf(File file, int i, int i2, long j) {
        File file2 = file;
        this.f1560d = file2;
        this.f1564h = i;
        this.f1561e = new File(file2, "journal");
        this.f1562f = new File(file2, "journal.tmp");
        this.f1563g = new File(file2, "journal.bkp");
        this.f1566j = i2;
        this.f1565i = j;
    }

    /* renamed from: a */
    public static void m1333a(C0357cf cfVar, C0360c cVar, boolean z) {
        synchronized (cfVar) {
            C0361d dVar = cVar.f1575a;
            if (dVar.f1584f == cVar) {
                if (z && !dVar.f1583e) {
                    int i = 0;
                    while (true) {
                        if (i >= cfVar.f1566j) {
                            break;
                        } else if (!cVar.f1576b[i]) {
                            cVar.mo1948a();
                            throw new IllegalStateException("Newly created entry didn't create value for index " + i);
                        } else if (!dVar.f1582d[i].exists()) {
                            cVar.mo1948a();
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                for (int i2 = 0; i2 < cfVar.f1566j; i2++) {
                    File file = dVar.f1582d[i2];
                    if (!z) {
                        m1335d(file);
                    } else if (file.exists()) {
                        File file2 = dVar.f1581c[i2];
                        file.renameTo(file2);
                        long j = dVar.f1580b[i2];
                        long length = file2.length();
                        dVar.f1580b[i2] = length;
                        cfVar.f1567k = (cfVar.f1567k - j) + length;
                    }
                }
                cfVar.f1570n++;
                dVar.f1584f = null;
                if (dVar.f1583e || z) {
                    dVar.f1583e = true;
                    cfVar.f1568l.append("CLEAN");
                    cfVar.f1568l.append(' ');
                    cfVar.f1568l.append(dVar.f1579a);
                    cfVar.f1568l.append(dVar.mo1950a());
                    cfVar.f1568l.append(10);
                    if (z) {
                        long j2 = cfVar.f1571o;
                        cfVar.f1571o = 1 + j2;
                        dVar.f1585g = j2;
                    }
                } else {
                    cfVar.f1569m.remove(dVar.f1579a);
                    cfVar.f1568l.append("REMOVE");
                    cfVar.f1568l.append(' ');
                    cfVar.f1568l.append(dVar.f1579a);
                    cfVar.f1568l.append(10);
                }
                m1336f(cfVar.f1568l);
                if (cfVar.f1567k > cfVar.f1565i || cfVar.mo1940h()) {
                    cfVar.f1572p.submit(cfVar.f1573q);
                }
            } else {
                throw new IllegalStateException();
            }
        }
    }

    @TargetApi(26)
    /* renamed from: c */
    public static void m1334c(Writer writer) {
        if (Build.VERSION.SDK_INT < 26) {
            writer.close();
            return;
        }
        StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitUnbufferedIo().build());
        try {
            writer.close();
        } finally {
            StrictMode.setThreadPolicy(threadPolicy);
        }
    }

    /* renamed from: d */
    public static void m1335d(File file) {
        if (file.exists() && !file.delete()) {
            throw new IOException();
        }
    }

    @TargetApi(26)
    /* renamed from: f */
    public static void m1336f(Writer writer) {
        if (Build.VERSION.SDK_INT < 26) {
            writer.flush();
            return;
        }
        StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitUnbufferedIo().build());
        try {
            writer.flush();
        } finally {
            StrictMode.setThreadPolicy(threadPolicy);
        }
    }

    /* renamed from: i */
    public static C0357cf m1337i(File file, int i, int i2, long j) {
        if (j <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        } else if (i2 > 0) {
            File file2 = new File(file, "journal.bkp");
            if (file2.exists()) {
                File file3 = new File(file, "journal");
                if (file3.exists()) {
                    file2.delete();
                } else {
                    m1338n(file2, file3, false);
                }
            }
            C0357cf cfVar = new C0357cf(file, i, i2, j);
            if (cfVar.f1561e.exists()) {
                try {
                    cfVar.mo1942k();
                    cfVar.mo1941j();
                    return cfVar;
                } catch (IOException e) {
                    PrintStream printStream = System.out;
                    printStream.println("DiskLruCache " + file + " is corrupt: " + e.getMessage() + ", removing");
                    cfVar.close();
                    C0633ef.m2027a(cfVar.f1560d);
                }
            }
            file.mkdirs();
            C0357cf cfVar2 = new C0357cf(file, i, i2, j);
            cfVar2.mo1944m();
            return cfVar2;
        } else {
            throw new IllegalArgumentException("valueCount <= 0");
        }
    }

    /* renamed from: n */
    public static void m1338n(File file, File file2, boolean z) {
        if (z) {
            m1335d(file2);
        }
        if (!file.renameTo(file2)) {
            throw new IOException();
        }
    }

    /* renamed from: b */
    public final void mo1936b() {
        if (this.f1568l == null) {
            throw new IllegalStateException("cache is closed");
        }
    }

    public synchronized void close() {
        if (this.f1568l != null) {
            Iterator it = new ArrayList(this.f1569m.values()).iterator();
            while (it.hasNext()) {
                C0360c cVar = ((C0361d) it.next()).f1584f;
                if (cVar != null) {
                    cVar.mo1948a();
                }
            }
            mo1945o();
            m1334c(this.f1568l);
            this.f1568l = null;
        }
    }

    /* renamed from: e */
    public C0360c mo1938e(String str) {
        synchronized (this) {
            mo1936b();
            C0361d dVar = this.f1569m.get(str);
            if (dVar == null) {
                dVar = new C0361d(str, (C0358a) null);
                this.f1569m.put(str, dVar);
            } else if (dVar.f1584f != null) {
                return null;
            }
            C0360c cVar = new C0360c(dVar, (C0358a) null);
            dVar.f1584f = cVar;
            this.f1568l.append("DIRTY");
            this.f1568l.append(' ');
            this.f1568l.append(str);
            this.f1568l.append(10);
            m1336f(this.f1568l);
            return cVar;
        }
    }

    /* renamed from: g */
    public synchronized C0362e mo1939g(String str) {
        mo1936b();
        C0361d dVar = this.f1569m.get(str);
        if (dVar == null) {
            return null;
        }
        if (!dVar.f1583e) {
            return null;
        }
        for (File exists : dVar.f1581c) {
            if (!exists.exists()) {
                return null;
            }
        }
        this.f1570n++;
        this.f1568l.append("READ");
        this.f1568l.append(' ');
        this.f1568l.append(str);
        this.f1568l.append(10);
        if (mo1940h()) {
            this.f1572p.submit(this.f1573q);
        }
        return new C0362e(this, str, dVar.f1585g, dVar.f1581c, dVar.f1580b, (C0358a) null);
    }

    /* renamed from: h */
    public final boolean mo1940h() {
        int i = this.f1570n;
        return i >= 2000 && i >= this.f1569m.size();
    }

    /* renamed from: j */
    public final void mo1941j() {
        m1335d(this.f1562f);
        Iterator<C0361d> it = this.f1569m.values().iterator();
        while (it.hasNext()) {
            C0361d next = it.next();
            int i = 0;
            if (next.f1584f == null) {
                while (i < this.f1566j) {
                    this.f1567k += next.f1580b[i];
                    i++;
                }
            } else {
                next.f1584f = null;
                while (i < this.f1566j) {
                    m1335d(next.f1581c[i]);
                    m1335d(next.f1582d[i]);
                    i++;
                }
                it.remove();
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:16|17|(1:19)|(1:21)(1:22)|23|24|38) */
    /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
        r9.f1570n = r2 - r9.f1569m.size();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006d, code lost:
        if (r1.f2248h == -1) goto L_0x006f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x006f, code lost:
        r0 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0070, code lost:
        if (r0 != false) goto L_0x0072;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0072, code lost:
        mo1944m();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0076, code lost:
        r9.f1568l = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(r9.f1561e, true), p000.C0633ef.f2596a));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x008f, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0090, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:?, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:16:0x0060 */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:16:0x0060=Splitter:B:16:0x0060, B:28:0x0091=Splitter:B:28:0x0091} */
    /* renamed from: k */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1942k() {
        /*
            r9 = this;
            java.lang.String r0 = ", "
            df r1 = new df
            java.io.FileInputStream r2 = new java.io.FileInputStream
            java.io.File r3 = r9.f1561e
            r2.<init>(r3)
            java.nio.charset.Charset r3 = p000.C0633ef.f2596a
            r1.<init>(r2, r3)
            java.lang.String r2 = r1.mo3047b()     // Catch:{ all -> 0x00bf }
            java.lang.String r3 = r1.mo3047b()     // Catch:{ all -> 0x00bf }
            java.lang.String r4 = r1.mo3047b()     // Catch:{ all -> 0x00bf }
            java.lang.String r5 = r1.mo3047b()     // Catch:{ all -> 0x00bf }
            java.lang.String r6 = r1.mo3047b()     // Catch:{ all -> 0x00bf }
            java.lang.String r7 = "libcore.io.DiskLruCache"
            boolean r7 = r7.equals(r2)     // Catch:{ all -> 0x00bf }
            if (r7 == 0) goto L_0x0091
            java.lang.String r7 = "1"
            boolean r7 = r7.equals(r3)     // Catch:{ all -> 0x00bf }
            if (r7 == 0) goto L_0x0091
            int r7 = r9.f1564h     // Catch:{ all -> 0x00bf }
            java.lang.String r7 = java.lang.Integer.toString(r7)     // Catch:{ all -> 0x00bf }
            boolean r4 = r7.equals(r4)     // Catch:{ all -> 0x00bf }
            if (r4 == 0) goto L_0x0091
            int r4 = r9.f1566j     // Catch:{ all -> 0x00bf }
            java.lang.String r4 = java.lang.Integer.toString(r4)     // Catch:{ all -> 0x00bf }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x00bf }
            if (r4 == 0) goto L_0x0091
            java.lang.String r4 = ""
            boolean r4 = r4.equals(r6)     // Catch:{ all -> 0x00bf }
            if (r4 == 0) goto L_0x0091
            r0 = 0
            r2 = 0
        L_0x0056:
            java.lang.String r3 = r1.mo3047b()     // Catch:{ EOFException -> 0x0060 }
            r9.mo1943l(r3)     // Catch:{ EOFException -> 0x0060 }
            int r2 = r2 + 1
            goto L_0x0056
        L_0x0060:
            java.util.LinkedHashMap<java.lang.String, cf$d> r3 = r9.f1569m     // Catch:{ all -> 0x00bf }
            int r3 = r3.size()     // Catch:{ all -> 0x00bf }
            int r2 = r2 - r3
            r9.f1570n = r2     // Catch:{ all -> 0x00bf }
            int r2 = r1.f2248h     // Catch:{ all -> 0x00bf }
            r3 = -1
            r4 = 1
            if (r2 != r3) goto L_0x0070
            r0 = 1
        L_0x0070:
            if (r0 == 0) goto L_0x0076
            r9.mo1944m()     // Catch:{ all -> 0x00bf }
            goto L_0x008b
        L_0x0076:
            java.io.BufferedWriter r0 = new java.io.BufferedWriter     // Catch:{ all -> 0x00bf }
            java.io.OutputStreamWriter r2 = new java.io.OutputStreamWriter     // Catch:{ all -> 0x00bf }
            java.io.FileOutputStream r3 = new java.io.FileOutputStream     // Catch:{ all -> 0x00bf }
            java.io.File r5 = r9.f1561e     // Catch:{ all -> 0x00bf }
            r3.<init>(r5, r4)     // Catch:{ all -> 0x00bf }
            java.nio.charset.Charset r4 = p000.C0633ef.f2596a     // Catch:{ all -> 0x00bf }
            r2.<init>(r3, r4)     // Catch:{ all -> 0x00bf }
            r0.<init>(r2)     // Catch:{ all -> 0x00bf }
            r9.f1568l = r0     // Catch:{ all -> 0x00bf }
        L_0x008b:
            r1.close()     // Catch:{ RuntimeException -> 0x008f, Exception -> 0x008e }
        L_0x008e:
            return
        L_0x008f:
            r0 = move-exception
            throw r0
        L_0x0091:
            java.io.IOException r4 = new java.io.IOException     // Catch:{ all -> 0x00bf }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x00bf }
            r7.<init>()     // Catch:{ all -> 0x00bf }
            java.lang.String r8 = "unexpected journal header: ["
            r7.append(r8)     // Catch:{ all -> 0x00bf }
            r7.append(r2)     // Catch:{ all -> 0x00bf }
            r7.append(r0)     // Catch:{ all -> 0x00bf }
            r7.append(r3)     // Catch:{ all -> 0x00bf }
            r7.append(r0)     // Catch:{ all -> 0x00bf }
            r7.append(r5)     // Catch:{ all -> 0x00bf }
            r7.append(r0)     // Catch:{ all -> 0x00bf }
            r7.append(r6)     // Catch:{ all -> 0x00bf }
            java.lang.String r0 = "]"
            r7.append(r0)     // Catch:{ all -> 0x00bf }
            java.lang.String r0 = r7.toString()     // Catch:{ all -> 0x00bf }
            r4.<init>(r0)     // Catch:{ all -> 0x00bf }
            throw r4     // Catch:{ all -> 0x00bf }
        L_0x00bf:
            r0 = move-exception
            r1.close()     // Catch:{ RuntimeException -> 0x00c4, Exception -> 0x00c3 }
        L_0x00c3:
            throw r0
        L_0x00c4:
            r0 = move-exception
            goto L_0x00c7
        L_0x00c6:
            throw r0
        L_0x00c7:
            goto L_0x00c6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0357cf.mo1942k():void");
    }

    /* renamed from: l */
    public final void mo1943l(String str) {
        String str2;
        int indexOf = str.indexOf(32);
        if (indexOf != -1) {
            int i = indexOf + 1;
            int indexOf2 = str.indexOf(32, i);
            if (indexOf2 == -1) {
                str2 = str.substring(i);
                if (indexOf == 6 && str.startsWith("REMOVE")) {
                    this.f1569m.remove(str2);
                    return;
                }
            } else {
                str2 = str.substring(i, indexOf2);
            }
            C0361d dVar = this.f1569m.get(str2);
            if (dVar == null) {
                dVar = new C0361d(str2, (C0358a) null);
                this.f1569m.put(str2, dVar);
            }
            if (indexOf2 != -1 && indexOf == 5 && str.startsWith("CLEAN")) {
                String[] split = str.substring(indexOf2 + 1).split(" ");
                dVar.f1583e = true;
                dVar.f1584f = null;
                if (split.length == C0357cf.this.f1566j) {
                    int i2 = 0;
                    while (i2 < split.length) {
                        try {
                            dVar.f1580b[i2] = Long.parseLong(split[i2]);
                            i2++;
                        } catch (NumberFormatException unused) {
                            dVar.mo1951b(split);
                            throw null;
                        }
                    }
                    return;
                }
                dVar.mo1951b(split);
                throw null;
            } else if (indexOf2 == -1 && indexOf == 5 && str.startsWith("DIRTY")) {
                dVar.f1584f = new C0360c(dVar, (C0358a) null);
            } else if (indexOf2 != -1 || indexOf != 4 || !str.startsWith("READ")) {
                throw new IOException(C1012kd.m3202k("unexpected journal line: ", str));
            }
        } else {
            throw new IOException(C1012kd.m3202k("unexpected journal line: ", str));
        }
    }

    /* renamed from: m */
    public final synchronized void mo1944m() {
        String str;
        Writer writer = this.f1568l;
        if (writer != null) {
            m1334c(writer);
        }
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.f1562f), C0633ef.f2596a));
        try {
            bufferedWriter.write("libcore.io.DiskLruCache");
            bufferedWriter.write("\n");
            bufferedWriter.write("1");
            bufferedWriter.write("\n");
            bufferedWriter.write(Integer.toString(this.f1564h));
            bufferedWriter.write("\n");
            bufferedWriter.write(Integer.toString(this.f1566j));
            bufferedWriter.write("\n");
            bufferedWriter.write("\n");
            for (C0361d next : this.f1569m.values()) {
                if (next.f1584f != null) {
                    str = "DIRTY " + next.f1579a + 10;
                } else {
                    str = "CLEAN " + next.f1579a + next.mo1950a() + 10;
                }
                bufferedWriter.write(str);
            }
            m1334c(bufferedWriter);
            if (this.f1561e.exists()) {
                m1338n(this.f1561e, this.f1563g, true);
            }
            m1338n(this.f1562f, this.f1561e, false);
            this.f1563g.delete();
            this.f1568l = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.f1561e, true), C0633ef.f2596a));
        } catch (Throwable th) {
            m1334c(bufferedWriter);
            throw th;
        }
    }

    /* renamed from: o */
    public final void mo1945o() {
        while (this.f1567k > this.f1565i) {
            String str = (String) this.f1569m.entrySet().iterator().next().getKey();
            synchronized (this) {
                mo1936b();
                C0361d dVar = this.f1569m.get(str);
                if (dVar != null) {
                    if (dVar.f1584f == null) {
                        for (int i = 0; i < this.f1566j; i++) {
                            File file = dVar.f1581c[i];
                            if (file.exists()) {
                                if (!file.delete()) {
                                    throw new IOException("failed to delete " + file);
                                }
                            }
                            long j = this.f1567k;
                            long[] jArr = dVar.f1580b;
                            this.f1567k = j - jArr[i];
                            jArr[i] = 0;
                        }
                        this.f1570n++;
                        this.f1568l.append("REMOVE");
                        this.f1568l.append(' ');
                        this.f1568l.append(str);
                        this.f1568l.append(10);
                        this.f1569m.remove(str);
                        if (mo1940h()) {
                            this.f1572p.submit(this.f1573q);
                        }
                    }
                }
            }
        }
    }
}
