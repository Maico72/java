package p000;

import java.lang.reflect.Type;
import java.util.Objects;
import p000.t00;

/* renamed from: gs */
public abstract class C0792gs {
    /* renamed from: a */
    public final String mo3827a(String str, Object... objArr) {
        return objArr.length > 0 ? String.format(str, objArr) : str;
    }

    /* renamed from: b */
    public C1035ks mo3828b(Type type) {
        if (type == null) {
            return null;
        }
        return mo1447d().mo4662b((b00) null, type, n00.f4138g);
    }

    /* renamed from: c */
    public t00<Object, Object> mo3829c(C1279nu nuVar, Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof t00) {
            return (t00) obj;
        }
        if (obj instanceof Class) {
            Class<t00.C1774a> cls = (Class) obj;
            if (cls == t00.C1774a.class || s00.m4864p(cls)) {
                return null;
            }
            if (t00.class.isAssignableFrom(cls)) {
                C2164ys ysVar = ((C0221at) this).f1134d;
                Objects.requireNonNull(ysVar.f5782e);
                return (t00) s00.m4855g(cls, ysVar.mo5861b());
            }
            throw new IllegalStateException(C1012kd.m3198g(cls, C1012kd.m3195d("AnnotationIntrospector returned Class "), "; expected Class<Converter>"));
        }
        StringBuilder d = C1012kd.m3195d("AnnotationIntrospector returned Converter definition of type ");
        d.append(obj.getClass().getName());
        d.append("; expected type Converter or Class<Converter> instead");
        throw new IllegalStateException(d.toString());
    }

    /* renamed from: d */
    public abstract n00 mo1447d();

    /* renamed from: e */
    public C0581dq<?> mo3830e(C1279nu nuVar, C1208mv mvVar) {
        Class<? extends C0581dq<?>> cls = mvVar.f4127b;
        C2164ys ysVar = ((C0221at) this).f1134d;
        Objects.requireNonNull(ysVar.f5782e);
        return ((C0581dq) s00.m4855g(cls, ysVar.mo5861b())).mo3096b(mvVar.f4129d);
    }

    /* renamed from: f */
    public abstract <T> T mo1448f(C1035ks ksVar, String str);

    /* renamed from: g */
    public <T> T mo3831g(Class<?> cls, String str) {
        return mo1448f(mo3828b(cls), str);
    }
}
