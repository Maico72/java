package p000;

/* renamed from: bg */
public interface C0288bg<T> extends C1253nf<C1675rh<T>> {
    /* renamed from: b */
    C1178mf mo1705b(C2150yf yfVar);
}
