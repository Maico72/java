package p000;

/* renamed from: fx */
public interface C0723fx {
    /* renamed from: a */
    C1462ps<?> mo3660a(C2164ys ysVar, C2244zz zzVar, C0649es esVar, C0230aw awVar, C1462ps<Object> psVar);

    /* renamed from: b */
    C1462ps<?> mo3661b(C2164ys ysVar, f00 f00, C0649es esVar, C1462ps<Object> psVar, C0230aw awVar, C1462ps<Object> psVar2);

    /* renamed from: c */
    C1462ps<?> mo3662c(C2164ys ysVar, C1035ks ksVar, C0649es esVar);

    /* renamed from: d */
    C1462ps<?> mo3663d(C2164ys ysVar, i00 i00, C0649es esVar, C0230aw awVar, C1462ps<Object> psVar);

    /* renamed from: e */
    C1462ps<?> mo3664e(C2164ys ysVar, d00 d00, C0649es esVar, C0230aw awVar, C1462ps<Object> psVar);

    /* renamed from: f */
    C1462ps<?> mo3665f(C2164ys ysVar, c00 c00, C0649es esVar, C0230aw awVar, C1462ps<Object> psVar);

    /* renamed from: g */
    C1462ps<?> mo3666g(C2164ys ysVar, g00 g00, C0649es esVar, C1462ps<Object> psVar, C0230aw awVar, C1462ps<Object> psVar2);
}
