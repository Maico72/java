package p000;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Collections;
import java.util.Set;

@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: ip */
public @interface C0910ip {

    /* renamed from: ip$a */
    public static class C0911a implements Object<C0910ip> {

        /* renamed from: i */
        public static final C0911a f3285i = new C0911a(Collections.emptySet(), false, false, false, true);

        /* renamed from: d */
        public final Set<String> f3286d;

        /* renamed from: e */
        public final boolean f3287e;

        /* renamed from: f */
        public final boolean f3288f;

        /* renamed from: g */
        public final boolean f3289g;

        /* renamed from: h */
        public final boolean f3290h;

        public C0911a(Set<String> set, boolean z, boolean z2, boolean z3, boolean z4) {
            this.f3286d = set == null ? Collections.emptySet() : set;
            this.f3287e = z;
            this.f3288f = z2;
            this.f3289g = z3;
            this.f3290h = z4;
        }

        /* renamed from: a */
        public static boolean m2831a(C0911a aVar, C0911a aVar2) {
            return aVar.f3287e == aVar2.f3287e && aVar.f3290h == aVar2.f3290h && aVar.f3288f == aVar2.f3288f && aVar.f3289g == aVar2.f3289g && aVar.f3286d.equals(aVar2.f3286d);
        }

        /* renamed from: b */
        public static C0911a m2832b(Set<String> set, boolean z, boolean z2, boolean z3, boolean z4) {
            C0911a aVar = f3285i;
            if (z == aVar.f3287e && z2 == aVar.f3288f && z3 == aVar.f3289g && z4 == aVar.f3290h && (set == null || set.size() == 0)) {
                return aVar;
            }
            return new C0911a(set, z, z2, z3, z4);
        }

        /* renamed from: c */
        public Set<String> mo4082c() {
            return this.f3288f ? Collections.emptySet() : this.f3286d;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            return obj != null && obj.getClass() == C0911a.class && m2831a(this, (C0911a) obj);
        }

        public int hashCode() {
            return this.f3286d.size() + (this.f3287e ? 1 : -3) + (this.f3288f ? 3 : -7) + (this.f3289g ? 7 : -11) + (this.f3290h ? 11 : -13);
        }

        public String toString() {
            return String.format("JsonIgnoreProperties.Value(ignored=%s,ignoreUnknown=%s,allowGetters=%s,allowSetters=%s,merge=%s)", new Object[]{this.f3286d, Boolean.valueOf(this.f3287e), Boolean.valueOf(this.f3288f), Boolean.valueOf(this.f3289g), Boolean.valueOf(this.f3290h)});
        }
    }

    boolean allowGetters() default false;

    boolean allowSetters() default false;

    boolean ignoreUnknown() default false;

    String[] value() default {};
}
