package p000;

import java.io.FilterInputStream;
import java.io.InputStream;

/* renamed from: jg */
public final class C0963jg extends FilterInputStream {

    /* renamed from: f */
    public static final byte[] f3429f;

    /* renamed from: g */
    public static final int f3430g;

    /* renamed from: h */
    public static final int f3431h;

    /* renamed from: d */
    public final byte f3432d;

    /* renamed from: e */
    public int f3433e;

    static {
        byte[] bArr = {-1, -31, 0, 28, 69, 120, 105, 102, 0, 0, 77, 77, 0, 0, 0, 0, 0, 8, 0, 1, 1, 18, 0, 2, 0, 0, 0, 1, 0};
        f3429f = bArr;
        int length = bArr.length;
        f3430g = length;
        f3431h = length + 2;
    }

    public C0963jg(InputStream inputStream, int i) {
        super(inputStream);
        if (i < -1 || i > 8) {
            throw new IllegalArgumentException(C1012kd.m3199h("Cannot add invalid orientation: ", i));
        }
        this.f3432d = (byte) i;
    }

    public void mark(int i) {
        throw new UnsupportedOperationException();
    }

    public boolean markSupported() {
        return false;
    }

    public int read() {
        int i;
        int i2 = this.f3433e;
        int read = (i2 < 2 || i2 > (i = f3431h)) ? super.read() : i2 == i ? this.f3432d : f3429f[i2 - 2] & 255;
        if (read != -1) {
            this.f3433e++;
        }
        return read;
    }

    public int read(byte[] bArr, int i, int i2) {
        int i3;
        int i4 = this.f3433e;
        int i5 = f3431h;
        if (i4 > i5) {
            i3 = super.read(bArr, i, i2);
        } else if (i4 == i5) {
            bArr[i] = this.f3432d;
            i3 = 1;
        } else if (i4 < 2) {
            i3 = super.read(bArr, i, 2 - i4);
        } else {
            int min = Math.min(i5 - i4, i2);
            System.arraycopy(f3429f, this.f3433e - 2, bArr, i, min);
            i3 = min;
        }
        if (i3 > 0) {
            this.f3433e += i3;
        }
        return i3;
    }

    public void reset() {
        throw new UnsupportedOperationException();
    }

    public long skip(long j) {
        long skip = super.skip(j);
        if (skip > 0) {
            this.f3433e = (int) (((long) this.f3433e) + skip);
        }
        return skip;
    }
}
