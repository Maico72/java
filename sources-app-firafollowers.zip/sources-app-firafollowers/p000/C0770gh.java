package p000;

import android.os.SystemClock;
import android.util.Log;
import java.io.File;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import p000.C0560dh;
import p000.C1020ki;
import p000.C1117lh;
import p000.C1272no;
import p000.C1685ro;
import p000.C1740si;
import p000.C1936vg;

/* renamed from: gh */
public class C0770gh implements C0893ih, C1740si.C1741a, C1117lh.C1118a {

    /* renamed from: i */
    public static final boolean f2935i = Log.isLoggable("Engine", 2);

    /* renamed from: a */
    public final C1342oh f2936a;

    /* renamed from: b */
    public final C1019kh f2937b;

    /* renamed from: c */
    public final C1740si f2938c;

    /* renamed from: d */
    public final C0773b f2939d;

    /* renamed from: e */
    public final C1866uh f2940e;

    /* renamed from: f */
    public final C0775c f2941f;

    /* renamed from: g */
    public final C0771a f2942g;

    /* renamed from: h */
    public final C1936vg f2943h;

    /* renamed from: gh$a */
    public static class C0771a {

        /* renamed from: a */
        public final C0560dh.C0564d f2944a;

        /* renamed from: b */
        public final C0940j6<C0560dh<?>> f2945b = C1685ro.m4792a(150, new C0772a());

        /* renamed from: c */
        public int f2946c;

        /* renamed from: gh$a$a */
        public class C0772a implements C1685ro.C1687b<C0560dh<?>> {
            public C0772a() {
            }

            /* renamed from: a */
            public Object mo3810a() {
                C0771a aVar = C0771a.this;
                return new C0560dh(aVar.f2944a, aVar.f2945b);
            }
        }

        public C0771a(C0560dh.C0564d dVar) {
            this.f2944a = dVar;
        }
    }

    /* renamed from: gh$b */
    public static class C0773b {

        /* renamed from: a */
        public final C1941vi f2948a;

        /* renamed from: b */
        public final C1941vi f2949b;

        /* renamed from: c */
        public final C1941vi f2950c;

        /* renamed from: d */
        public final C1941vi f2951d;

        /* renamed from: e */
        public final C0893ih f2952e;

        /* renamed from: f */
        public final C1117lh.C1118a f2953f;

        /* renamed from: g */
        public final C0940j6<C0835hh<?>> f2954g = C1685ro.m4792a(150, new C0774a());

        /* renamed from: gh$b$a */
        public class C0774a implements C1685ro.C1687b<C0835hh<?>> {
            public C0774a() {
            }

            /* renamed from: a */
            public Object mo3810a() {
                C0773b bVar = C0773b.this;
                return new C0835hh(bVar.f2948a, bVar.f2949b, bVar.f2950c, bVar.f2951d, bVar.f2952e, bVar.f2953f, bVar.f2954g);
            }
        }

        public C0773b(C1941vi viVar, C1941vi viVar2, C1941vi viVar3, C1941vi viVar4, C0893ih ihVar, C1117lh.C1118a aVar) {
            this.f2948a = viVar;
            this.f2949b = viVar2;
            this.f2950c = viVar3;
            this.f2951d = viVar4;
            this.f2952e = ihVar;
            this.f2953f = aVar;
        }
    }

    /* renamed from: gh$c */
    public static class C0775c implements C0560dh.C0564d {

        /* renamed from: a */
        public final C1020ki.C1021a f2956a;

        /* renamed from: b */
        public volatile C1020ki f2957b;

        public C0775c(C1020ki.C1021a aVar) {
            this.f2956a = aVar;
        }

        /* renamed from: a */
        public C1020ki mo3811a() {
            if (this.f2957b == null) {
                synchronized (this) {
                    if (this.f2957b == null) {
                        C1257ni niVar = (C1257ni) this.f2956a;
                        C1449pi piVar = (C1449pi) niVar.f4308b;
                        File cacheDir = piVar.f4898a.getCacheDir();
                        C1343oi oiVar = null;
                        if (cacheDir == null) {
                            cacheDir = null;
                        } else if (piVar.f4899b != null) {
                            cacheDir = new File(cacheDir, piVar.f4899b);
                        }
                        if (cacheDir != null) {
                            if (cacheDir.isDirectory() || cacheDir.mkdirs()) {
                                oiVar = new C1343oi(cacheDir, niVar.f4307a);
                            }
                        }
                        this.f2957b = oiVar;
                    }
                    if (this.f2957b == null) {
                        this.f2957b = new C1119li();
                    }
                }
            }
            return this.f2957b;
        }
    }

    /* renamed from: gh$d */
    public class C0776d {

        /* renamed from: a */
        public final C0835hh<?> f2958a;

        /* renamed from: b */
        public final C1623qn f2959b;

        public C0776d(C1623qn qnVar, C0835hh<?> hhVar) {
            this.f2959b = qnVar;
            this.f2958a = hhVar;
        }
    }

    public C0770gh(C1740si siVar, C1020ki.C1021a aVar, C1941vi viVar, C1941vi viVar2, C1941vi viVar3, C1941vi viVar4, boolean z) {
        this.f2938c = siVar;
        C0775c cVar = new C0775c(aVar);
        this.f2941f = cVar;
        C1936vg vgVar = new C1936vg(z);
        this.f2943h = vgVar;
        synchronized (this) {
            synchronized (vgVar) {
                vgVar.f6386d = this;
            }
        }
        this.f2937b = new C1019kh();
        this.f2936a = new C1342oh();
        this.f2939d = new C0773b(viVar, viVar2, viVar3, viVar4, this, this);
        this.f2942g = new C0771a(cVar);
        this.f2940e = new C1866uh();
        ((C1676ri) siVar).f5481d = this;
    }

    /* renamed from: d */
    public static void m2504d(String str, long j, C2005wf wfVar) {
        Log.v("Engine", str + " in " + C1198mo.m3727a(j) + "ms, key: " + wfVar);
    }

    /* renamed from: a */
    public void mo3804a(C2005wf wfVar, C1117lh<?> lhVar) {
        C1936vg vgVar = this.f2943h;
        synchronized (vgVar) {
            C1936vg.C1939b remove = vgVar.f6384b.remove(wfVar);
            if (remove != null) {
                remove.f6390c = null;
                remove.clear();
            }
        }
        if (lhVar.f3901d) {
            C1675rh rhVar = (C1675rh) ((C1676ri) this.f2938c).mo4864d(wfVar, lhVar);
        } else {
            this.f2940e.mo6130a(lhVar, false);
        }
    }

    /* renamed from: b */
    public <R> C0776d mo3805b(C1933ve veVar, Object obj, C2005wf wfVar, int i, int i2, Class<?> cls, Class<R> cls2, C2066xe xeVar, C0696fh fhVar, Map<Class<?>, C0363cg<?>> map, boolean z, boolean z2, C2150yf yfVar, boolean z3, boolean z4, boolean z5, boolean z6, C1623qn qnVar, Executor executor) {
        long j;
        if (f2935i) {
            int i3 = C1198mo.f4090b;
            j = SystemClock.elapsedRealtimeNanos();
        } else {
            j = 0;
        }
        long j2 = j;
        Objects.requireNonNull(this.f2937b);
        C0964jh jhVar = new C0964jh(obj, wfVar, i, i2, map, cls, cls2, yfVar);
        synchronized (this) {
            C1117lh<?> c = mo3806c(jhVar, z3, j2);
            if (c == null) {
                C0776d g = mo3809g(veVar, obj, wfVar, i, i2, cls, cls2, xeVar, fhVar, map, z, z2, yfVar, z3, z4, z5, z6, qnVar, executor, jhVar, j2);
                return g;
            }
            ((C1683rn) qnVar).mo5729p(c, C1017kf.MEMORY_CACHE, false);
            return null;
        }
    }

    /* renamed from: c */
    public final C1117lh<?> mo3806c(C0964jh jhVar, boolean z, long j) {
        C1117lh<?> lhVar;
        Y y;
        C1117lh<?> lhVar2;
        if (!z) {
            return null;
        }
        C1936vg vgVar = this.f2943h;
        synchronized (vgVar) {
            C1936vg.C1939b bVar = vgVar.f6384b.get(jhVar);
            if (bVar == null) {
                lhVar = null;
            } else {
                lhVar = (C1117lh) bVar.get();
                if (lhVar == null) {
                    vgVar.mo6254b(bVar);
                }
            }
        }
        if (lhVar != null) {
            lhVar.mo4439a();
        }
        if (lhVar != null) {
            if (f2935i) {
                m2504d("Loaded resource from active resources", j, jhVar);
            }
            return lhVar;
        }
        C1676ri riVar = (C1676ri) this.f2938c;
        synchronized (riVar) {
            C1272no.C1273a remove = riVar.f4346a.remove(jhVar);
            if (remove == null) {
                y = null;
            } else {
                riVar.f4348c -= (long) remove.f4350b;
                y = remove.f4349a;
            }
        }
        C1675rh rhVar = (C1675rh) y;
        if (rhVar == null) {
            lhVar2 = null;
        } else {
            lhVar2 = rhVar instanceof C1117lh ? (C1117lh) rhVar : new C1117lh<>(rhVar, true, true, jhVar, this);
        }
        if (lhVar2 != null) {
            lhVar2.mo4439a();
            this.f2943h.mo6253a(jhVar, lhVar2);
        }
        if (lhVar2 == null) {
            return null;
        }
        if (f2935i) {
            m2504d("Loaded resource from cache", j, jhVar);
        }
        return lhVar2;
    }

    /* renamed from: e */
    public synchronized void mo3807e(C0835hh<?> hhVar, C2005wf wfVar, C1117lh<?> lhVar) {
        if (lhVar != null) {
            if (lhVar.f3901d) {
                this.f2943h.mo6253a(wfVar, lhVar);
            }
        }
        C1342oh ohVar = this.f2936a;
        Objects.requireNonNull(ohVar);
        Map<C2005wf, C0835hh<?>> a = ohVar.mo5057a(hhVar.f3124s);
        if (hhVar.equals(a.get(wfVar))) {
            a.remove(wfVar);
        }
    }

    /* renamed from: f */
    public void mo3808f(C1675rh<?> rhVar) {
        if (rhVar instanceof C1117lh) {
            ((C1117lh) rhVar).mo4440f();
            return;
        }
        throw new IllegalArgumentException("Cannot release anything but an EngineResource");
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x00e9  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00ec  */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <R> p000.C0770gh.C0776d mo3809g(p000.C1933ve r17, java.lang.Object r18, p000.C2005wf r19, int r20, int r21, java.lang.Class<?> r22, java.lang.Class<R> r23, p000.C2066xe r24, p000.C0696fh r25, java.util.Map<java.lang.Class<?>, p000.C0363cg<?>> r26, boolean r27, boolean r28, p000.C2150yf r29, boolean r30, boolean r31, boolean r32, boolean r33, p000.C1623qn r34, java.util.concurrent.Executor r35, p000.C0964jh r36, long r37) {
        /*
            r16 = this;
            r1 = r16
            r0 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            r5 = r21
            r6 = r24
            r7 = r25
            r8 = r29
            r9 = r33
            r10 = r34
            r11 = r35
            r12 = r36
            r13 = r37
            oh r15 = r1.f2936a
            if (r9 == 0) goto L_0x0023
            java.util.Map<wf, hh<?>> r15 = r15.f4540b
            goto L_0x0025
        L_0x0023:
            java.util.Map<wf, hh<?>> r15 = r15.f4539a
        L_0x0025:
            java.lang.Object r15 = r15.get(r12)
            hh r15 = (p000.C0835hh) r15
            if (r15 == 0) goto L_0x003f
            r15.mo3933b(r10, r11)
            boolean r0 = f2935i
            if (r0 == 0) goto L_0x0039
            java.lang.String r0 = "Added to existing load"
            m2504d(r0, r13, r12)
        L_0x0039:
            gh$d r0 = new gh$d
            r0.<init>(r10, r15)
            return r0
        L_0x003f:
            gh$b r15 = r1.f2939d
            j6<hh<?>> r15 = r15.f2954g
            java.lang.Object r15 = r15.mo4124b()
            hh r15 = (p000.C0835hh) r15
            java.lang.String r13 = "Argument must not be null"
            java.util.Objects.requireNonNull(r15, r13)
            monitor-enter(r15)
            r15.f3120o = r12     // Catch:{ all -> 0x0116 }
            r13 = r30
            r15.f3121p = r13     // Catch:{ all -> 0x0116 }
            r13 = r31
            r15.f3122q = r13     // Catch:{ all -> 0x0116 }
            r13 = r32
            r15.f3123r = r13     // Catch:{ all -> 0x0116 }
            r15.f3124s = r9     // Catch:{ all -> 0x0116 }
            monitor-exit(r15)
            gh$a r13 = r1.f2942g
            j6<dh<?>> r14 = r13.f2945b
            java.lang.Object r14 = r14.mo4124b()
            dh r14 = (p000.C0560dh) r14
            java.lang.String r10 = "Argument must not be null"
            java.util.Objects.requireNonNull(r14, r10)
            int r10 = r13.f2946c
            int r11 = r10 + 1
            r13.f2946c = r11
            ch<R> r11 = r14.f2262d
            dh$d r13 = r14.f2265g
            r11.f1593c = r0
            r11.f1594d = r2
            r11.f1604n = r3
            r11.f1595e = r4
            r11.f1596f = r5
            r11.f1606p = r7
            r1 = r22
            r11.f1597g = r1
            r11.f1598h = r13
            r1 = r23
            r11.f1601k = r1
            r11.f1605o = r6
            r11.f1599i = r8
            r1 = r26
            r11.f1600j = r1
            r1 = r27
            r11.f1607q = r1
            r1 = r28
            r11.f1608r = r1
            r14.f2269k = r0
            r14.f2270l = r3
            r14.f2271m = r6
            r14.f2272n = r12
            r14.f2273o = r4
            r14.f2274p = r5
            r14.f2275q = r7
            r14.f2282x = r9
            r14.f2276r = r8
            r14.f2277s = r15
            r14.f2278t = r10
            dh$f r0 = p000.C0560dh.C0566f.INITIALIZE
            r14.f2280v = r0
            r14.f2283y = r2
            r1 = r16
            oh r0 = r1.f2936a
            java.util.Objects.requireNonNull(r0)
            boolean r2 = r15.f3124s
            java.util.Map r0 = r0.mo5057a(r2)
            r0.put(r12, r15)
            r0 = r34
            r2 = r35
            r15.mo3933b(r0, r2)
            monitor-enter(r15)
            r15.f3131z = r14     // Catch:{ all -> 0x0113 }
            dh$g r2 = p000.C0560dh.C0567g.INITIALIZE     // Catch:{ all -> 0x0113 }
            dh$g r2 = r14.mo3058i(r2)     // Catch:{ all -> 0x0113 }
            dh$g r3 = p000.C0560dh.C0567g.RESOURCE_CACHE     // Catch:{ all -> 0x0113 }
            if (r2 == r3) goto L_0x00e6
            dh$g r3 = p000.C0560dh.C0567g.DATA_CACHE     // Catch:{ all -> 0x0113 }
            if (r2 != r3) goto L_0x00e4
            goto L_0x00e6
        L_0x00e4:
            r2 = 0
            goto L_0x00e7
        L_0x00e6:
            r2 = 1
        L_0x00e7:
            if (r2 == 0) goto L_0x00ec
            vi r2 = r15.f3115j     // Catch:{ all -> 0x0113 }
            goto L_0x00fc
        L_0x00ec:
            boolean r2 = r15.f3122q     // Catch:{ all -> 0x0113 }
            if (r2 == 0) goto L_0x00f3
            vi r2 = r15.f3117l     // Catch:{ all -> 0x0113 }
            goto L_0x00fc
        L_0x00f3:
            boolean r2 = r15.f3123r     // Catch:{ all -> 0x0113 }
            if (r2 == 0) goto L_0x00fa
            vi r2 = r15.f3118m     // Catch:{ all -> 0x0113 }
            goto L_0x00fc
        L_0x00fa:
            vi r2 = r15.f3116k     // Catch:{ all -> 0x0113 }
        L_0x00fc:
            java.util.concurrent.ExecutorService r2 = r2.f6395a     // Catch:{ all -> 0x0113 }
            r2.execute(r14)     // Catch:{ all -> 0x0113 }
            monitor-exit(r15)
            boolean r2 = f2935i
            if (r2 == 0) goto L_0x010d
            java.lang.String r2 = "Started new load"
            r3 = r37
            m2504d(r2, r3, r12)
        L_0x010d:
            gh$d r2 = new gh$d
            r2.<init>(r0, r15)
            return r2
        L_0x0113:
            r0 = move-exception
            monitor-exit(r15)
            throw r0
        L_0x0116:
            r0 = move-exception
            monitor-exit(r15)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0770gh.mo3809g(ve, java.lang.Object, wf, int, int, java.lang.Class, java.lang.Class, xe, fh, java.util.Map, boolean, boolean, yf, boolean, boolean, boolean, boolean, qn, java.util.concurrent.Executor, jh, long):gh$d");
    }
}
