package p000;

import android.media.MediaDataSource;
import java.nio.ByteBuffer;
import p000.C0368cl;

/* renamed from: dl */
public class C0572dl extends MediaDataSource {

    /* renamed from: d */
    public final /* synthetic */ ByteBuffer f2314d;

    public C0572dl(C0368cl.C0372d dVar, ByteBuffer byteBuffer) {
        this.f2314d = byteBuffer;
    }

    public void close() {
    }

    public long getSize() {
        return (long) this.f2314d.limit();
    }

    public int readAt(long j, byte[] bArr, int i, int i2) {
        if (j >= ((long) this.f2314d.limit())) {
            return -1;
        }
        this.f2314d.position((int) j);
        int min = Math.min(i2, this.f2314d.remaining());
        this.f2314d.get(bArr, i, min);
        return min;
    }
}
