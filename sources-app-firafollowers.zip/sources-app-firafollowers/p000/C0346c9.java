package p000;

import android.view.View;
import java.util.ArrayList;

/* renamed from: c9 */
public class C0346c9 implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ int f1539d;

    /* renamed from: e */
    public final /* synthetic */ ArrayList f1540e;

    /* renamed from: f */
    public final /* synthetic */ ArrayList f1541f;

    /* renamed from: g */
    public final /* synthetic */ ArrayList f1542g;

    /* renamed from: h */
    public final /* synthetic */ ArrayList f1543h;

    public C0346c9(C0680f9 f9Var, int i, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4) {
        this.f1539d = i;
        this.f1540e = arrayList;
        this.f1541f = arrayList2;
        this.f1542g = arrayList3;
        this.f1543h = arrayList4;
    }

    public void run() {
        for (int i = 0; i < this.f1539d; i++) {
            C0010a7.m46s((View) this.f1540e.get(i), (String) this.f1541f.get(i));
            C0010a7.m46s((View) this.f1542g.get(i), (String) this.f1543h.get(i));
        }
    }
}
