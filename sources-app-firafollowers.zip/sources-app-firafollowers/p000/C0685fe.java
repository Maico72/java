package p000;

/* renamed from: fe */
public class C0685fe extends Exception {
    public C0685fe() {
    }

    public C0685fe(Throwable th) {
        super(th);
    }

    public C0685fe(C1999wd wdVar) {
    }
}
