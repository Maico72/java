package p000;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

/* renamed from: d0 */
public class C0521d0 extends Drawable implements Drawable.Callback {

    /* renamed from: d */
    public Drawable f2118d;

    public C0521d0(Drawable drawable) {
        Drawable drawable2 = this.f2118d;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f2118d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
    }

    public void draw(Canvas canvas) {
        this.f2118d.draw(canvas);
    }

    public int getChangingConfigurations() {
        return this.f2118d.getChangingConfigurations();
    }

    public Drawable getCurrent() {
        return this.f2118d.getCurrent();
    }

    public int getIntrinsicHeight() {
        return this.f2118d.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        return this.f2118d.getIntrinsicWidth();
    }

    public int getMinimumHeight() {
        return this.f2118d.getMinimumHeight();
    }

    public int getMinimumWidth() {
        return this.f2118d.getMinimumWidth();
    }

    public int getOpacity() {
        return this.f2118d.getOpacity();
    }

    public boolean getPadding(Rect rect) {
        return this.f2118d.getPadding(rect);
    }

    public int[] getState() {
        return this.f2118d.getState();
    }

    public Region getTransparentRegion() {
        return this.f2118d.getTransparentRegion();
    }

    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public boolean isAutoMirrored() {
        return this.f2118d.isAutoMirrored();
    }

    public boolean isStateful() {
        return this.f2118d.isStateful();
    }

    public void jumpToCurrentState() {
        this.f2118d.jumpToCurrentState();
    }

    public void onBoundsChange(Rect rect) {
        this.f2118d.setBounds(rect);
    }

    public boolean onLevelChange(int i) {
        return this.f2118d.setLevel(i);
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        scheduleSelf(runnable, j);
    }

    public void setAlpha(int i) {
        this.f2118d.setAlpha(i);
    }

    public void setAutoMirrored(boolean z) {
        this.f2118d.setAutoMirrored(z);
    }

    public void setChangingConfigurations(int i) {
        this.f2118d.setChangingConfigurations(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f2118d.setColorFilter(colorFilter);
    }

    public void setDither(boolean z) {
        this.f2118d.setDither(z);
    }

    public void setFilterBitmap(boolean z) {
        this.f2118d.setFilterBitmap(z);
    }

    public void setHotspot(float f, float f2) {
        C1401p4.m4349Z(this.f2118d, f, f2);
    }

    public void setHotspotBounds(int i, int i2, int i3, int i4) {
        C1401p4.m4351a0(this.f2118d, i, i2, i3, i4);
    }

    public boolean setState(int[] iArr) {
        return this.f2118d.setState(iArr);
    }

    public void setTint(int i) {
        C1401p4.m4365h0(this.f2118d, i);
    }

    public void setTintList(ColorStateList colorStateList) {
        C1401p4.m4367i0(this.f2118d, colorStateList);
    }

    public void setTintMode(PorterDuff.Mode mode) {
        C1401p4.m4369j0(this.f2118d, mode);
    }

    public boolean setVisible(boolean z, boolean z2) {
        return super.setVisible(z, z2) || this.f2118d.setVisible(z, z2);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
