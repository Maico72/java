package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import java.util.Objects;
import org.fasaroid.fira.R;
import p000.C0003a1;

/* renamed from: e3 */
public class C0600e3 implements C0864i2 {

    /* renamed from: a */
    public Toolbar f2446a;

    /* renamed from: b */
    public int f2447b;

    /* renamed from: c */
    public View f2448c;

    /* renamed from: d */
    public View f2449d;

    /* renamed from: e */
    public Drawable f2450e;

    /* renamed from: f */
    public Drawable f2451f;

    /* renamed from: g */
    public Drawable f2452g;

    /* renamed from: h */
    public boolean f2453h;

    /* renamed from: i */
    public CharSequence f2454i;

    /* renamed from: j */
    public CharSequence f2455j;

    /* renamed from: k */
    public CharSequence f2456k;

    /* renamed from: l */
    public Window.Callback f2457l;

    /* renamed from: m */
    public boolean f2458m;

    /* renamed from: n */
    public C0928j1 f2459n;

    /* renamed from: o */
    public int f2460o = 0;

    /* renamed from: p */
    public Drawable f2461p;

    /* renamed from: e3$a */
    public class C0601a extends C0815h7 {

        /* renamed from: a */
        public boolean f2462a = false;

        /* renamed from: b */
        public final /* synthetic */ int f2463b;

        public C0601a(int i) {
            this.f2463b = i;
        }

        public void onAnimationCancel(View view) {
            this.f2462a = true;
        }

        public void onAnimationEnd(View view) {
            if (!this.f2462a) {
                C0600e3.this.f2446a.setVisibility(this.f2463b);
            }
        }

        public void onAnimationStart(View view) {
            C0600e3.this.f2446a.setVisibility(0);
        }
    }

    public C0600e3(Toolbar toolbar, boolean z) {
        Drawable drawable;
        this.f2446a = toolbar;
        this.f2454i = toolbar.getTitle();
        this.f2455j = toolbar.getSubtitle();
        this.f2453h = this.f2454i != null;
        this.f2452g = toolbar.getNavigationIcon();
        String str = null;
        C0327c3 s = C0327c3.m1245s(toolbar.getContext(), (AttributeSet) null, C0593e.f2371a, R.attr.actionBarStyle, 0);
        int i = 15;
        this.f2461p = s.mo1830g(15);
        if (z) {
            CharSequence o = s.mo1838o(27);
            if (!TextUtils.isEmpty(o)) {
                this.f2453h = true;
                this.f2454i = o;
                if ((this.f2447b & 8) != 0) {
                    this.f2446a.setTitle(o);
                }
            }
            CharSequence o2 = s.mo1838o(25);
            if (!TextUtils.isEmpty(o2)) {
                this.f2455j = o2;
                if ((this.f2447b & 8) != 0) {
                    this.f2446a.setSubtitle(o2);
                }
            }
            Drawable g = s.mo1830g(20);
            if (g != null) {
                this.f2451f = g;
                mo3262y();
            }
            Drawable g2 = s.mo1830g(17);
            if (g2 != null) {
                this.f2450e = g2;
                mo3262y();
            }
            if (this.f2452g == null && (drawable = this.f2461p) != null) {
                this.f2452g = drawable;
                mo3261x();
            }
            mo3259v(s.mo1834k(10, 0));
            int m = s.mo1836m(9, 0);
            if (m != 0) {
                View inflate = LayoutInflater.from(this.f2446a.getContext()).inflate(m, this.f2446a, false);
                View view = this.f2449d;
                if (!(view == null || (this.f2447b & 16) == 0)) {
                    this.f2446a.removeView(view);
                }
                this.f2449d = inflate;
                if (!(inflate == null || (this.f2447b & 16) == 0)) {
                    this.f2446a.addView(inflate);
                }
                mo3259v(this.f2447b | 16);
            }
            int l = s.mo1835l(13, 0);
            if (l > 0) {
                ViewGroup.LayoutParams layoutParams = this.f2446a.getLayoutParams();
                layoutParams.height = l;
                this.f2446a.setLayoutParams(layoutParams);
            }
            int e = s.mo1828e(7, -1);
            int e2 = s.mo1828e(3, -1);
            if (e >= 0 || e2 >= 0) {
                Toolbar toolbar2 = this.f2446a;
                int max = Math.max(e, 0);
                int max2 = Math.max(e2, 0);
                toolbar2.mo468d();
                toolbar2.f519w.mo6102a(max, max2);
            }
            int m2 = s.mo1836m(28, 0);
            if (m2 != 0) {
                Toolbar toolbar3 = this.f2446a;
                Context context = toolbar3.getContext();
                toolbar3.f511o = m2;
                TextView textView = toolbar3.f501e;
                if (textView != null) {
                    textView.setTextAppearance(context, m2);
                }
            }
            int m3 = s.mo1836m(26, 0);
            if (m3 != 0) {
                Toolbar toolbar4 = this.f2446a;
                Context context2 = toolbar4.getContext();
                toolbar4.f512p = m3;
                TextView textView2 = toolbar4.f502f;
                if (textView2 != null) {
                    textView2.setTextAppearance(context2, m3);
                }
            }
            int m4 = s.mo1836m(22, 0);
            if (m4 != 0) {
                this.f2446a.setPopupTheme(m4);
            }
        } else {
            if (this.f2446a.getNavigationIcon() != null) {
                this.f2461p = this.f2446a.getNavigationIcon();
            } else {
                i = 11;
            }
            this.f2447b = i;
        }
        s.f1430b.recycle();
        if (R.string.abc_action_bar_up_description != this.f2460o) {
            this.f2460o = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(this.f2446a.getNavigationContentDescription())) {
                int i2 = this.f2460o;
                this.f2456k = i2 != 0 ? mo3248o().getString(i2) : str;
                mo3260w();
            }
        }
        this.f2456k = this.f2446a.getNavigationContentDescription();
        this.f2446a.setNavigationOnClickListener(new C0525d3(this));
    }

    /* renamed from: a */
    public void mo3232a(Menu menu, C0003a1.C0004a aVar) {
        C1967w0 w0Var;
        if (this.f2459n == null) {
            C0928j1 j1Var = new C0928j1(this.f2446a.getContext());
            this.f2459n = j1Var;
            Objects.requireNonNull(j1Var);
        }
        C0928j1 j1Var2 = this.f2459n;
        j1Var2.f4717h = aVar;
        Toolbar toolbar = this.f2446a;
        C1838u0 u0Var = (C1838u0) menu;
        if (u0Var != null || toolbar.f500d != null) {
            toolbar.mo470f();
            C1838u0 u0Var2 = toolbar.f500d.f375s;
            if (u0Var2 != u0Var) {
                if (u0Var2 != null) {
                    u0Var2.mo6092u(toolbar.f496M);
                    u0Var2.mo6092u(toolbar.f497N);
                }
                if (toolbar.f497N == null) {
                    toolbar.f497N = new Toolbar.C0111d();
                }
                j1Var2.f3338t = true;
                if (u0Var != null) {
                    u0Var.mo6066b(j1Var2, toolbar.f509m);
                    u0Var.mo6066b(toolbar.f497N, toolbar.f509m);
                } else {
                    j1Var2.mo8d(toolbar.f509m, (C1838u0) null);
                    Toolbar.C0111d dVar = toolbar.f497N;
                    C1838u0 u0Var3 = dVar.f526d;
                    if (!(u0Var3 == null || (w0Var = dVar.f527e) == null)) {
                        u0Var3.mo3431d(w0Var);
                    }
                    dVar.f526d = null;
                    j1Var2.mo13j(true);
                    toolbar.f497N.mo13j(true);
                }
                toolbar.f500d.setPopupTheme(toolbar.f510n);
                toolbar.f500d.setPresenter(j1Var2);
                toolbar.f496M = j1Var2;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0021 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3233b() {
        /*
            r4 = this;
            androidx.appcompat.widget.Toolbar r0 = r4.f2446a
            androidx.appcompat.widget.ActionMenuView r0 = r0.f500d
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0022
            j1 r0 = r0.f379w
            if (r0 == 0) goto L_0x001e
            j1$c r3 = r0.f3343y
            if (r3 != 0) goto L_0x0019
            boolean r0 = r0.mo4113m()
            if (r0 == 0) goto L_0x0017
            goto L_0x0019
        L_0x0017:
            r0 = 0
            goto L_0x001a
        L_0x0019:
            r0 = 1
        L_0x001a:
            if (r0 == 0) goto L_0x001e
            r0 = 1
            goto L_0x001f
        L_0x001e:
            r0 = 0
        L_0x001f:
            if (r0 == 0) goto L_0x0022
            r1 = 1
        L_0x0022:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0600e3.mo3233b():boolean");
    }

    /* renamed from: c */
    public boolean mo3234c() {
        return this.f2446a.mo512o();
    }

    public void collapseActionView() {
        Toolbar.C0111d dVar = this.f2446a.f497N;
        C1967w0 w0Var = dVar == null ? null : dVar.f527e;
        if (w0Var != null) {
            w0Var.collapseActionView();
        }
    }

    /* renamed from: d */
    public boolean mo3236d() {
        ActionMenuView actionMenuView = this.f2446a.f500d;
        if (actionMenuView == null) {
            return false;
        }
        C0928j1 j1Var = actionMenuView.f379w;
        if (j1Var != null && j1Var.mo4111k()) {
            return true;
        }
        return false;
    }

    /* renamed from: e */
    public boolean mo3237e() {
        return this.f2446a.mo557u();
    }

    /* renamed from: f */
    public void mo3238f() {
        this.f2458m = true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r0.f500d;
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3239g() {
        /*
            r2 = this;
            androidx.appcompat.widget.Toolbar r0 = r2.f2446a
            int r1 = r0.getVisibility()
            if (r1 != 0) goto L_0x0012
            androidx.appcompat.widget.ActionMenuView r0 = r0.f500d
            if (r0 == 0) goto L_0x0012
            boolean r0 = r0.f378v
            if (r0 == 0) goto L_0x0012
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0600e3.mo3239g():boolean");
    }

    public CharSequence getTitle() {
        return this.f2446a.getTitle();
    }

    /* renamed from: h */
    public void mo3241h() {
        C0928j1 j1Var;
        ActionMenuView actionMenuView = this.f2446a.f500d;
        if (actionMenuView != null && (j1Var = actionMenuView.f379w) != null) {
            j1Var.mo4109b();
        }
    }

    /* renamed from: i */
    public int mo3242i() {
        return this.f2447b;
    }

    /* renamed from: j */
    public void mo3243j(int i) {
        this.f2446a.setVisibility(i);
    }

    /* renamed from: k */
    public void mo3244k(int i) {
        this.f2451f = i != 0 ? C0001a0.m1b(mo3248o(), i) : null;
        mo3262y();
    }

    /* renamed from: l */
    public void mo3245l(C1898v2 v2Var) {
        Toolbar toolbar;
        View view = this.f2448c;
        if (view != null && view.getParent() == (toolbar = this.f2446a)) {
            toolbar.removeView(this.f2448c);
        }
        this.f2448c = null;
    }

    /* renamed from: m */
    public ViewGroup mo3246m() {
        return this.f2446a;
    }

    /* renamed from: n */
    public void mo3247n(boolean z) {
    }

    /* renamed from: o */
    public Context mo3248o() {
        return this.f2446a.getContext();
    }

    /* renamed from: p */
    public int mo3249p() {
        return 0;
    }

    /* renamed from: q */
    public C0675f7 mo3250q(int i, long j) {
        C0675f7 a = C0010a7.m28a(this.f2446a);
        a.mo3520a(i == 0 ? 1.0f : 0.0f);
        a.mo3524e(j);
        C0601a aVar = new C0601a(i);
        View view = (View) a.f2700a.get();
        if (view != null) {
            a.mo3526g(view, aVar);
        }
        return a;
    }

    /* renamed from: r */
    public void mo3251r() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: s */
    public boolean mo3252s() {
        Toolbar.C0111d dVar = this.f2446a.f497N;
        return (dVar == null || dVar.f527e == null) ? false : true;
    }

    public void setIcon(int i) {
        this.f2450e = i != 0 ? C0001a0.m1b(mo3248o(), i) : null;
        mo3262y();
    }

    public void setIcon(Drawable drawable) {
        this.f2450e = drawable;
        mo3262y();
    }

    public void setWindowCallback(Window.Callback callback) {
        this.f2457l = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        if (!this.f2453h) {
            this.f2454i = charSequence;
            if ((this.f2447b & 8) != 0) {
                this.f2446a.setTitle(charSequence);
            }
        }
    }

    /* renamed from: t */
    public void mo3257t() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: u */
    public void mo3258u(boolean z) {
        this.f2446a.setCollapsible(z);
    }

    /* renamed from: v */
    public void mo3259v(int i) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i2 = this.f2447b ^ i;
        this.f2447b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    mo3260w();
                }
                mo3261x();
            }
            if ((i2 & 3) != 0) {
                mo3262y();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.f2446a.setTitle(this.f2454i);
                    toolbar = this.f2446a;
                    charSequence = this.f2455j;
                } else {
                    charSequence = null;
                    this.f2446a.setTitle((CharSequence) null);
                    toolbar = this.f2446a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i2 & 16) != 0 && (view = this.f2449d) != null) {
                if ((i & 16) != 0) {
                    this.f2446a.addView(view);
                } else {
                    this.f2446a.removeView(view);
                }
            }
        }
    }

    /* renamed from: w */
    public final void mo3260w() {
        if ((this.f2447b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.f2456k)) {
            this.f2446a.setNavigationContentDescription(this.f2460o);
        } else {
            this.f2446a.setNavigationContentDescription(this.f2456k);
        }
    }

    /* renamed from: x */
    public final void mo3261x() {
        Drawable drawable;
        Toolbar toolbar;
        if ((this.f2447b & 4) != 0) {
            toolbar = this.f2446a;
            drawable = this.f2452g;
            if (drawable == null) {
                drawable = this.f2461p;
            }
        } else {
            toolbar = this.f2446a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    /* renamed from: y */
    public final void mo3262y() {
        Drawable drawable;
        int i = this.f2447b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f2451f) == null) {
            drawable = this.f2450e;
        }
        this.f2446a.setLogo(drawable);
    }
}
