package p000;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

/* renamed from: b9 */
public class C0268b9 extends C0680f9 {

    /* renamed from: b9$a */
    public class C0269a extends Transition.EpicenterCallback {

        /* renamed from: a */
        public final /* synthetic */ Rect f1287a;

        public C0269a(C0268b9 b9Var, Rect rect) {
            this.f1287a = rect;
        }

        public Rect onGetEpicenter(Transition transition) {
            return this.f1287a;
        }
    }

    /* renamed from: b9$b */
    public class C0270b implements Transition.TransitionListener {

        /* renamed from: a */
        public final /* synthetic */ View f1288a;

        /* renamed from: b */
        public final /* synthetic */ ArrayList f1289b;

        public C0270b(C0268b9 b9Var, View view, ArrayList arrayList) {
            this.f1288a = view;
            this.f1289b = arrayList;
        }

        public void onTransitionCancel(Transition transition) {
        }

        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
            this.f1288a.setVisibility(8);
            int size = this.f1289b.size();
            for (int i = 0; i < size; i++) {
                ((View) this.f1289b.get(i)).setVisibility(0);
            }
        }

        public void onTransitionPause(Transition transition) {
        }

        public void onTransitionResume(Transition transition) {
        }

        public void onTransitionStart(Transition transition) {
        }
    }

    /* renamed from: b9$c */
    public class C0271c implements Transition.TransitionListener {

        /* renamed from: a */
        public final /* synthetic */ Object f1290a;

        /* renamed from: b */
        public final /* synthetic */ ArrayList f1291b;

        /* renamed from: c */
        public final /* synthetic */ Object f1292c;

        /* renamed from: d */
        public final /* synthetic */ ArrayList f1293d;

        /* renamed from: e */
        public final /* synthetic */ Object f1294e;

        /* renamed from: f */
        public final /* synthetic */ ArrayList f1295f;

        public C0271c(Object obj, ArrayList arrayList, Object obj2, ArrayList arrayList2, Object obj3, ArrayList arrayList3) {
            this.f1290a = obj;
            this.f1291b = arrayList;
            this.f1292c = obj2;
            this.f1293d = arrayList2;
            this.f1294e = obj3;
            this.f1295f = arrayList3;
        }

        public void onTransitionCancel(Transition transition) {
        }

        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
        }

        public void onTransitionPause(Transition transition) {
        }

        public void onTransitionResume(Transition transition) {
        }

        public void onTransitionStart(Transition transition) {
            Object obj = this.f1290a;
            if (obj != null) {
                C0268b9.this.mo1670n(obj, this.f1291b, (ArrayList<View>) null);
            }
            Object obj2 = this.f1292c;
            if (obj2 != null) {
                C0268b9.this.mo1670n(obj2, this.f1293d, (ArrayList<View>) null);
            }
            Object obj3 = this.f1294e;
            if (obj3 != null) {
                C0268b9.this.mo1670n(obj3, this.f1295f, (ArrayList<View>) null);
            }
        }
    }

    /* renamed from: b9$d */
    public class C0272d extends Transition.EpicenterCallback {

        /* renamed from: a */
        public final /* synthetic */ Rect f1297a;

        public C0272d(C0268b9 b9Var, Rect rect) {
            this.f1297a = rect;
        }

        public Rect onGetEpicenter(Transition transition) {
            Rect rect = this.f1297a;
            if (rect == null || rect.isEmpty()) {
                return null;
            }
            return this.f1297a;
        }
    }

    /* renamed from: v */
    public static boolean m1122v(Transition transition) {
        return !C0680f9.m2192k(transition.getTargetIds()) || !C0680f9.m2192k(transition.getTargetNames()) || !C0680f9.m2192k(transition.getTargetTypes());
    }

    /* renamed from: a */
    public void mo1663a(Object obj, View view) {
        if (obj != null) {
            ((Transition) obj).addTarget(view);
        }
    }

    /* renamed from: b */
    public void mo1664b(Object obj, ArrayList<View> arrayList) {
        Transition transition = (Transition) obj;
        if (transition != null) {
            int i = 0;
            if (transition instanceof TransitionSet) {
                TransitionSet transitionSet = (TransitionSet) transition;
                int transitionCount = transitionSet.getTransitionCount();
                while (i < transitionCount) {
                    mo1664b(transitionSet.getTransitionAt(i), arrayList);
                    i++;
                }
            } else if (!m1122v(transition) && C0680f9.m2192k(transition.getTargets())) {
                int size = arrayList.size();
                while (i < size) {
                    transition.addTarget(arrayList.get(i));
                    i++;
                }
            }
        }
    }

    /* renamed from: c */
    public void mo1665c(ViewGroup viewGroup, Object obj) {
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) obj);
    }

    /* renamed from: e */
    public boolean mo1666e(Object obj) {
        return obj instanceof Transition;
    }

    /* renamed from: g */
    public Object mo1667g(Object obj) {
        if (obj != null) {
            return ((Transition) obj).clone();
        }
        return null;
    }

    /* renamed from: l */
    public Object mo1668l(Object obj, Object obj2, Object obj3) {
        TransitionSet transitionSet = new TransitionSet();
        if (obj != null) {
            transitionSet.addTransition((Transition) obj);
        }
        if (obj2 != null) {
            transitionSet.addTransition((Transition) obj2);
        }
        if (obj3 != null) {
            transitionSet.addTransition((Transition) obj3);
        }
        return transitionSet;
    }

    /* renamed from: m */
    public void mo1669m(Object obj, View view) {
        if (obj != null) {
            ((Transition) obj).removeTarget(view);
        }
    }

    /* renamed from: n */
    public void mo1670n(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        List<View> targets;
        Transition transition = (Transition) obj;
        int i = 0;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            int transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                mo1670n(transitionSet.getTransitionAt(i), arrayList, arrayList2);
                i++;
            }
        } else if (!m1122v(transition) && (targets = transition.getTargets()) != null && targets.size() == arrayList.size() && targets.containsAll(arrayList)) {
            int size = arrayList2 == null ? 0 : arrayList2.size();
            while (i < size) {
                transition.addTarget(arrayList2.get(i));
                i++;
            }
            for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
                transition.removeTarget(arrayList.get(size2));
            }
        }
    }

    /* renamed from: o */
    public void mo1671o(Object obj, View view, ArrayList<View> arrayList) {
        ((Transition) obj).addListener(new C0270b(this, view, arrayList));
    }

    /* renamed from: p */
    public void mo1672p(Object obj, Object obj2, ArrayList<View> arrayList, Object obj3, ArrayList<View> arrayList2, Object obj4, ArrayList<View> arrayList3) {
        ((Transition) obj).addListener(new C0271c(obj2, arrayList, obj3, arrayList2, obj4, arrayList3));
    }

    /* renamed from: q */
    public void mo1673q(Object obj, Rect rect) {
        if (obj != null) {
            ((Transition) obj).setEpicenterCallback(new C0272d(this, rect));
        }
    }

    /* renamed from: r */
    public void mo1674r(Object obj, View view) {
        if (view != null) {
            Rect rect = new Rect();
            mo3546j(view, rect);
            ((Transition) obj).setEpicenterCallback(new C0269a(this, rect));
        }
    }

    /* renamed from: s */
    public void mo1675s(Object obj, View view, ArrayList<View> arrayList) {
        TransitionSet transitionSet = (TransitionSet) obj;
        List targets = transitionSet.getTargets();
        targets.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0680f9.m2190d(targets, arrayList.get(i));
        }
        targets.add(view);
        arrayList.add(view);
        mo1664b(transitionSet, arrayList);
    }

    /* renamed from: t */
    public void mo1676t(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        TransitionSet transitionSet = (TransitionSet) obj;
        if (transitionSet != null) {
            transitionSet.getTargets().clear();
            transitionSet.getTargets().addAll(arrayList2);
            mo1670n(transitionSet, arrayList, arrayList2);
        }
    }

    /* renamed from: u */
    public Object mo1677u(Object obj) {
        if (obj == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition) obj);
        return transitionSet;
    }
}
