package p000;

import java.util.Objects;

/* renamed from: fl */
public class C0707fl implements C1675rh<byte[]> {

    /* renamed from: d */
    public final byte[] f2770d;

    public C0707fl(byte[] bArr) {
        Objects.requireNonNull(bArr, "Argument must not be null");
        this.f2770d = bArr;
    }

    /* renamed from: b */
    public Object mo1714b() {
        return this.f2770d;
    }

    /* renamed from: c */
    public int mo1715c() {
        return this.f2770d.length;
    }

    /* renamed from: d */
    public Class<byte[]> mo1716d() {
        return byte[].class;
    }

    /* renamed from: e */
    public void mo1717e() {
    }
}
