package p000;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.graphics.Path;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;

/* renamed from: dc */
public abstract class C0545dc implements Cloneable {

    /* renamed from: x */
    public static final int[] f2203x = {2, 1, 3, 4};

    /* renamed from: y */
    public static final C2204zb f2204y = new C0546a();

    /* renamed from: z */
    public static ThreadLocal<C2047x3<Animator, C0547b>> f2205z = new ThreadLocal<>();

    /* renamed from: d */
    public String f2206d = getClass().getName();

    /* renamed from: e */
    public long f2207e = -1;

    /* renamed from: f */
    public long f2208f = -1;

    /* renamed from: g */
    public TimeInterpolator f2209g = null;

    /* renamed from: h */
    public ArrayList<Integer> f2210h = new ArrayList<>();

    /* renamed from: i */
    public ArrayList<View> f2211i = new ArrayList<>();

    /* renamed from: j */
    public C1174mc f2212j = new C1174mc();

    /* renamed from: k */
    public C1174mc f2213k = new C1174mc();

    /* renamed from: l */
    public C0957jc f2214l = null;

    /* renamed from: m */
    public int[] f2215m = f2203x;

    /* renamed from: n */
    public ArrayList<C1104lc> f2216n;

    /* renamed from: o */
    public ArrayList<C1104lc> f2217o;

    /* renamed from: p */
    public ArrayList<Animator> f2218p = new ArrayList<>();

    /* renamed from: q */
    public int f2219q = 0;

    /* renamed from: r */
    public boolean f2220r = false;

    /* renamed from: s */
    public boolean f2221s = false;

    /* renamed from: t */
    public ArrayList<C0549d> f2222t = null;

    /* renamed from: u */
    public ArrayList<Animator> f2223u = new ArrayList<>();

    /* renamed from: v */
    public C0548c f2224v;

    /* renamed from: w */
    public C2204zb f2225w = f2204y;

    /* renamed from: dc$a */
    public static class C0546a extends C2204zb {
        /* renamed from: a */
        public Path mo3017a(float f, float f2, float f3, float f4) {
            Path path = new Path();
            path.moveTo(f, f2);
            path.lineTo(f3, f4);
            return path;
        }
    }

    /* renamed from: dc$b */
    public static class C0547b {

        /* renamed from: a */
        public View f2226a;

        /* renamed from: b */
        public String f2227b;

        /* renamed from: c */
        public C1104lc f2228c;

        /* renamed from: d */
        public C2062xc f2229d;

        /* renamed from: e */
        public C0545dc f2230e;

        public C0547b(View view, String str, C0545dc dcVar, C2062xc xcVar, C1104lc lcVar) {
            this.f2226a = view;
            this.f2227b = str;
            this.f2228c = lcVar;
            this.f2229d = xcVar;
            this.f2230e = dcVar;
        }
    }

    /* renamed from: dc$c */
    public static abstract class C0548c {
    }

    /* renamed from: dc$d */
    public interface C0549d {
        /* renamed from: a */
        void mo3018a(C0545dc dcVar);

        /* renamed from: b */
        void mo3019b(C0545dc dcVar);

        /* renamed from: c */
        void mo3020c(C0545dc dcVar);

        /* renamed from: d */
        void mo3021d(C0545dc dcVar);
    }

    /* renamed from: c */
    public static void m1755c(C1174mc mcVar, View view, C1104lc lcVar) {
        mcVar.f4024a.put(view, lcVar);
        int id = view.getId();
        if (id >= 0) {
            if (mcVar.f4025b.indexOfKey(id) >= 0) {
                mcVar.f4025b.put(id, (Object) null);
            } else {
                mcVar.f4025b.put(id, view);
            }
        }
        String i = C0010a7.m36i(view);
        if (i != null) {
            if (mcVar.f4027d.mo3272e(i) >= 0) {
                mcVar.f4027d.put(i, null);
            } else {
                mcVar.f4027d.put(i, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            ListView listView = (ListView) view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                C0259b4<View> b4Var = mcVar.f4026c;
                if (b4Var.f1249d) {
                    b4Var.mo1588d();
                }
                if (C0007a4.m18b(b4Var.f1250e, b4Var.f1252g, itemIdAtPosition) >= 0) {
                    View e = mcVar.f4026c.mo1589e(itemIdAtPosition);
                    if (e != null) {
                        e.setHasTransientState(false);
                        mcVar.f4026c.mo1591g(itemIdAtPosition, null);
                        return;
                    }
                    return;
                }
                view.setHasTransientState(true);
                mcVar.f4026c.mo1591g(itemIdAtPosition, view);
            }
        }
    }

    /* renamed from: o */
    public static C2047x3<Animator, C0547b> m1756o() {
        C2047x3<Animator, C0547b> x3Var = f2205z.get();
        if (x3Var != null) {
            return x3Var;
        }
        C2047x3<Animator, C0547b> x3Var2 = new C2047x3<>();
        f2205z.set(x3Var2);
        return x3Var2;
    }

    /* renamed from: t */
    public static boolean m1757t(C1104lc lcVar, C1104lc lcVar2, String str) {
        Object obj = lcVar.f3868a.get(str);
        Object obj2 = lcVar2.f3868a.get(str);
        if (obj == null && obj2 == null) {
            return false;
        }
        if (obj == null || obj2 == null) {
            return true;
        }
        return true ^ obj.equals(obj2);
    }

    /* renamed from: A */
    public void mo2985A(C0548c cVar) {
        this.f2224v = cVar;
    }

    /* renamed from: B */
    public C0545dc mo2986B(TimeInterpolator timeInterpolator) {
        this.f2209g = timeInterpolator;
        return this;
    }

    /* renamed from: C */
    public void mo2987C(C2204zb zbVar) {
        if (zbVar == null) {
            zbVar = f2204y;
        }
        this.f2225w = zbVar;
    }

    /* renamed from: D */
    public void mo2988D(C0884ic icVar) {
    }

    /* renamed from: E */
    public C0545dc mo2989E(long j) {
        this.f2207e = j;
        return this;
    }

    /* renamed from: F */
    public void mo2990F() {
        if (this.f2219q == 0) {
            ArrayList<C0549d> arrayList = this.f2222t;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.f2222t.clone();
                int size = arrayList2.size();
                for (int i = 0; i < size; i++) {
                    ((C0549d) arrayList2.get(i)).mo3020c(this);
                }
            }
            this.f2221s = false;
        }
        this.f2219q++;
    }

    /* renamed from: G */
    public String mo2991G(String str) {
        StringBuilder d = C1012kd.m3195d(str);
        d.append(getClass().getSimpleName());
        d.append("@");
        d.append(Integer.toHexString(hashCode()));
        d.append(": ");
        String sb = d.toString();
        if (this.f2208f != -1) {
            sb = sb + "dur(" + this.f2208f + ") ";
        }
        if (this.f2207e != -1) {
            sb = sb + "dly(" + this.f2207e + ") ";
        }
        if (this.f2209g != null) {
            sb = sb + "interp(" + this.f2209g + ") ";
        }
        if (this.f2210h.size() <= 0 && this.f2211i.size() <= 0) {
            return sb;
        }
        String k = C1012kd.m3202k(sb, "tgts(");
        if (this.f2210h.size() > 0) {
            for (int i = 0; i < this.f2210h.size(); i++) {
                if (i > 0) {
                    k = C1012kd.m3202k(k, ", ");
                }
                StringBuilder d2 = C1012kd.m3195d(k);
                d2.append(this.f2210h.get(i));
                k = d2.toString();
            }
        }
        if (this.f2211i.size() > 0) {
            for (int i2 = 0; i2 < this.f2211i.size(); i2++) {
                if (i2 > 0) {
                    k = C1012kd.m3202k(k, ", ");
                }
                StringBuilder d3 = C1012kd.m3195d(k);
                d3.append(this.f2211i.get(i2));
                k = d3.toString();
            }
        }
        return C1012kd.m3202k(k, ")");
    }

    /* renamed from: a */
    public C0545dc mo2992a(C0549d dVar) {
        if (this.f2222t == null) {
            this.f2222t = new ArrayList<>();
        }
        this.f2222t.add(dVar);
        return this;
    }

    /* renamed from: b */
    public C0545dc mo2993b(View view) {
        this.f2211i.add(view);
        return this;
    }

    /* renamed from: d */
    public abstract void mo2995d(C1104lc lcVar);

    /* renamed from: e */
    public final void mo2996e(View view, boolean z) {
        if (view != null) {
            view.getId();
            if (view.getParent() instanceof ViewGroup) {
                C1104lc lcVar = new C1104lc();
                lcVar.f3869b = view;
                if (z) {
                    mo2998g(lcVar);
                } else {
                    mo2995d(lcVar);
                }
                lcVar.f3870c.add(this);
                mo2997f(lcVar);
                m1755c(z ? this.f2212j : this.f2213k, view, lcVar);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    mo2996e(viewGroup.getChildAt(i), z);
                }
            }
        }
    }

    /* renamed from: f */
    public void mo2997f(C1104lc lcVar) {
    }

    /* renamed from: g */
    public abstract void mo2998g(C1104lc lcVar);

    /* renamed from: h */
    public void mo2999h(ViewGroup viewGroup, boolean z) {
        mo3000i(z);
        if (this.f2210h.size() > 0 || this.f2211i.size() > 0) {
            for (int i = 0; i < this.f2210h.size(); i++) {
                View findViewById = viewGroup.findViewById(this.f2210h.get(i).intValue());
                if (findViewById != null) {
                    C1104lc lcVar = new C1104lc();
                    lcVar.f3869b = findViewById;
                    if (z) {
                        mo2998g(lcVar);
                    } else {
                        mo2995d(lcVar);
                    }
                    lcVar.f3870c.add(this);
                    mo2997f(lcVar);
                    m1755c(z ? this.f2212j : this.f2213k, findViewById, lcVar);
                }
            }
            for (int i2 = 0; i2 < this.f2211i.size(); i2++) {
                View view = this.f2211i.get(i2);
                C1104lc lcVar2 = new C1104lc();
                lcVar2.f3869b = view;
                if (z) {
                    mo2998g(lcVar2);
                } else {
                    mo2995d(lcVar2);
                }
                lcVar2.f3870c.add(this);
                mo2997f(lcVar2);
                m1755c(z ? this.f2212j : this.f2213k, view, lcVar2);
            }
            return;
        }
        mo2996e(viewGroup, z);
    }

    /* renamed from: i */
    public void mo3000i(boolean z) {
        C1174mc mcVar;
        if (z) {
            this.f2212j.f4024a.clear();
            this.f2212j.f4025b.clear();
            mcVar = this.f2212j;
        } else {
            this.f2213k.f4024a.clear();
            this.f2213k.f4025b.clear();
            mcVar = this.f2213k;
        }
        mcVar.f4026c.mo1585b();
    }

    /* renamed from: j */
    public C0545dc clone() {
        try {
            C0545dc dcVar = (C0545dc) super.clone();
            dcVar.f2223u = new ArrayList<>();
            dcVar.f2212j = new C1174mc();
            dcVar.f2213k = new C1174mc();
            dcVar.f2216n = null;
            dcVar.f2217o = null;
            return dcVar;
        } catch (CloneNotSupportedException unused) {
            return null;
        }
    }

    /* renamed from: k */
    public Animator mo3002k(ViewGroup viewGroup, C1104lc lcVar, C1104lc lcVar2) {
        return null;
    }

    /* renamed from: l */
    public void mo3003l(ViewGroup viewGroup, C1174mc mcVar, C1174mc mcVar2, ArrayList<C1104lc> arrayList, ArrayList<C1104lc> arrayList2) {
        int i;
        Animator k;
        Animator animator;
        C1104lc lcVar;
        View view;
        C1104lc lcVar2;
        Animator animator2;
        ViewGroup viewGroup2 = viewGroup;
        C2047x3<Animator, C0547b> o = m1756o();
        SparseIntArray sparseIntArray = new SparseIntArray();
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            C1104lc lcVar3 = arrayList.get(i2);
            C1104lc lcVar4 = arrayList2.get(i2);
            if (lcVar3 != null && !lcVar3.f3870c.contains(this)) {
                lcVar3 = null;
            }
            if (lcVar4 != null && !lcVar4.f3870c.contains(this)) {
                lcVar4 = null;
            }
            if (!(lcVar3 == null && lcVar4 == null)) {
                if ((lcVar3 == null || lcVar4 == null || mo3008r(lcVar3, lcVar4)) && (k = mo3002k(viewGroup2, lcVar3, lcVar4)) != null) {
                    if (lcVar4 != null) {
                        View view2 = lcVar4.f3869b;
                        String[] p = mo3006p();
                        if (view2 != null && p != null && p.length > 0) {
                            lcVar2 = new C1104lc();
                            lcVar2.f3869b = view2;
                            C1104lc orDefault = mcVar2.f4024a.getOrDefault(view2, null);
                            if (orDefault != null) {
                                int i3 = 0;
                                while (i3 < p.length) {
                                    lcVar2.f3868a.put(p[i3], orDefault.f3868a.get(p[i3]));
                                    i3++;
                                    k = k;
                                    size = size;
                                    orDefault = orDefault;
                                }
                            }
                            Animator animator3 = k;
                            i = size;
                            int i4 = o.f2478f;
                            int i5 = 0;
                            while (true) {
                                if (i5 >= i4) {
                                    animator2 = animator3;
                                    break;
                                }
                                C0547b bVar = o.get(o.mo3278h(i5));
                                if (bVar.f2228c != null && bVar.f2226a == view2 && bVar.f2227b.equals(this.f2206d) && bVar.f2228c.equals(lcVar2)) {
                                    animator2 = null;
                                    break;
                                }
                                i5++;
                            }
                        } else {
                            C1174mc mcVar3 = mcVar2;
                            i = size;
                            animator2 = k;
                            lcVar2 = null;
                        }
                        view = view2;
                        animator = animator2;
                        lcVar = lcVar2;
                    } else {
                        C1174mc mcVar4 = mcVar2;
                        i = size;
                        view = lcVar3.f3869b;
                        animator = k;
                        lcVar = null;
                    }
                    if (animator != null) {
                        String str = this.f2206d;
                        C1793tc tcVar = C1417pc.f4821a;
                        o.put(animator, new C0547b(view, str, this, new C1997wc(viewGroup2), lcVar));
                        this.f2223u.add(animator);
                    }
                    i2++;
                    size = i;
                }
            }
            C1174mc mcVar5 = mcVar2;
            i = size;
            i2++;
            size = i;
        }
        for (int i6 = 0; i6 < sparseIntArray.size(); i6++) {
            Animator animator4 = this.f2223u.get(sparseIntArray.keyAt(i6));
            animator4.setStartDelay(animator4.getStartDelay() + (((long) sparseIntArray.valueAt(i6)) - Long.MAX_VALUE));
        }
    }

    /* renamed from: m */
    public void mo3004m() {
        int i = this.f2219q - 1;
        this.f2219q = i;
        if (i == 0) {
            ArrayList<C0549d> arrayList = this.f2222t;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.f2222t.clone();
                int size = arrayList2.size();
                for (int i2 = 0; i2 < size; i2++) {
                    ((C0549d) arrayList2.get(i2)).mo3021d(this);
                }
            }
            for (int i3 = 0; i3 < this.f2212j.f4026c.mo1592h(); i3++) {
                View i4 = this.f2212j.f4026c.mo1593i(i3);
                if (i4 != null) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    i4.setHasTransientState(false);
                }
            }
            for (int i5 = 0; i5 < this.f2213k.f4026c.mo1592h(); i5++) {
                View i6 = this.f2213k.f4026c.mo1593i(i5);
                if (i6 != null) {
                    WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                    i6.setHasTransientState(false);
                }
            }
            this.f2221s = true;
        }
    }

    /* renamed from: n */
    public C1104lc mo3005n(View view, boolean z) {
        C0957jc jcVar = this.f2214l;
        if (jcVar != null) {
            return jcVar.mo3005n(view, z);
        }
        ArrayList<C1104lc> arrayList = z ? this.f2216n : this.f2217o;
        if (arrayList == null) {
            return null;
        }
        int size = arrayList.size();
        int i = -1;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            C1104lc lcVar = arrayList.get(i2);
            if (lcVar == null) {
                return null;
            }
            if (lcVar.f3869b == view) {
                i = i2;
                break;
            }
            i2++;
        }
        if (i < 0) {
            return null;
        }
        return (z ? this.f2217o : this.f2216n).get(i);
    }

    /* renamed from: p */
    public String[] mo3006p() {
        return null;
    }

    /* renamed from: q */
    public C1104lc mo3007q(View view, boolean z) {
        C0957jc jcVar = this.f2214l;
        if (jcVar != null) {
            return jcVar.mo3007q(view, z);
        }
        return (z ? this.f2212j : this.f2213k).f4024a.getOrDefault(view, null);
    }

    /* renamed from: r */
    public boolean mo3008r(C1104lc lcVar, C1104lc lcVar2) {
        if (lcVar == null || lcVar2 == null) {
            return false;
        }
        String[] p = mo3006p();
        if (p != null) {
            int length = p.length;
            int i = 0;
            while (i < length) {
                if (!m1757t(lcVar, lcVar2, p[i])) {
                    i++;
                }
            }
            return false;
        }
        for (String t : lcVar.f3868a.keySet()) {
            if (m1757t(lcVar, lcVar2, t)) {
            }
        }
        return false;
        return true;
    }

    /* renamed from: s */
    public boolean mo3009s(View view) {
        return (this.f2210h.size() == 0 && this.f2211i.size() == 0) || this.f2210h.contains(Integer.valueOf(view.getId())) || this.f2211i.contains(view);
    }

    public String toString() {
        return mo2991G("");
    }

    /* renamed from: u */
    public void mo3011u(View view) {
        if (!this.f2221s) {
            C2047x3<Animator, C0547b> o = m1756o();
            int i = o.f2478f;
            C1793tc tcVar = C1417pc.f4821a;
            C1997wc wcVar = new C1997wc(view);
            for (int i2 = i - 1; i2 >= 0; i2--) {
                C0547b l = o.mo3284l(i2);
                if (l.f2226a != null && wcVar.equals(l.f2229d)) {
                    o.mo3278h(i2).pause();
                }
            }
            ArrayList<C0549d> arrayList = this.f2222t;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.f2222t.clone();
                int size = arrayList2.size();
                for (int i3 = 0; i3 < size; i3++) {
                    ((C0549d) arrayList2.get(i3)).mo3018a(this);
                }
            }
            this.f2220r = true;
        }
    }

    /* renamed from: v */
    public C0545dc mo3012v(C0549d dVar) {
        ArrayList<C0549d> arrayList = this.f2222t;
        if (arrayList == null) {
            return this;
        }
        arrayList.remove(dVar);
        if (this.f2222t.size() == 0) {
            this.f2222t = null;
        }
        return this;
    }

    /* renamed from: w */
    public C0545dc mo3013w(View view) {
        this.f2211i.remove(view);
        return this;
    }

    /* renamed from: x */
    public void mo3014x(View view) {
        if (this.f2220r) {
            if (!this.f2221s) {
                C2047x3<Animator, C0547b> o = m1756o();
                int i = o.f2478f;
                C1793tc tcVar = C1417pc.f4821a;
                C1997wc wcVar = new C1997wc(view);
                for (int i2 = i - 1; i2 >= 0; i2--) {
                    C0547b l = o.mo3284l(i2);
                    if (l.f2226a != null && wcVar.equals(l.f2229d)) {
                        o.mo3278h(i2).resume();
                    }
                }
                ArrayList<C0549d> arrayList = this.f2222t;
                if (arrayList != null && arrayList.size() > 0) {
                    ArrayList arrayList2 = (ArrayList) this.f2222t.clone();
                    int size = arrayList2.size();
                    for (int i3 = 0; i3 < size; i3++) {
                        ((C0549d) arrayList2.get(i3)).mo3019b(this);
                    }
                }
            }
            this.f2220r = false;
        }
    }

    /* renamed from: y */
    public void mo3015y() {
        mo2990F();
        C2047x3<Animator, C0547b> o = m1756o();
        Iterator<Animator> it = this.f2223u.iterator();
        while (it.hasNext()) {
            Animator next = it.next();
            if (o.containsKey(next)) {
                mo2990F();
                if (next != null) {
                    next.addListener(new C0621ec(this, o));
                    long j = this.f2208f;
                    if (j >= 0) {
                        next.setDuration(j);
                    }
                    long j2 = this.f2207e;
                    if (j2 >= 0) {
                        next.setStartDelay(j2);
                    }
                    TimeInterpolator timeInterpolator = this.f2209g;
                    if (timeInterpolator != null) {
                        next.setInterpolator(timeInterpolator);
                    }
                    next.addListener(new C0683fc(this));
                    next.start();
                }
            }
        }
        this.f2223u.clear();
        mo3004m();
    }

    /* renamed from: z */
    public C0545dc mo3016z(long j) {
        this.f2208f = j;
        return this;
    }
}
