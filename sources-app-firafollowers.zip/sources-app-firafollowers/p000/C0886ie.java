package p000;

import java.util.Map;

/* renamed from: ie */
public abstract class C0886ie {
    /* renamed from: a */
    public abstract C1177me mo4035a(C2210zd<?> zdVar, Map<String, String> map);
}
