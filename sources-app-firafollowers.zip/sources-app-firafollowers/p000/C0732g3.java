package p000;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import org.fasaroid.fira.R;

/* renamed from: g3 */
public class C0732g3 {

    /* renamed from: a */
    public final Context f2821a;

    /* renamed from: b */
    public final View f2822b;

    /* renamed from: c */
    public final TextView f2823c;

    /* renamed from: d */
    public final WindowManager.LayoutParams f2824d;

    /* renamed from: e */
    public final Rect f2825e = new Rect();

    /* renamed from: f */
    public final int[] f2826f = new int[2];

    /* renamed from: g */
    public final int[] f2827g = new int[2];

    public C0732g3(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f2824d = layoutParams;
        this.f2821a = context;
        View inflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
        this.f2822b = inflate;
        this.f2823c = (TextView) inflate.findViewById(R.id.message);
        layoutParams.setTitle(C0732g3.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = 2131689479;
        layoutParams.flags = 24;
    }

    /* renamed from: a */
    public void mo3754a() {
        if (this.f2822b.getParent() != null) {
            ((WindowManager) this.f2821a.getSystemService("window")).removeView(this.f2822b);
        }
    }
}
