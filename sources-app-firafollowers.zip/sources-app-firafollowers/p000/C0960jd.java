package p000;

import android.graphics.Rect;
import android.view.View;
import androidx.viewpager.widget.ViewPager;

/* renamed from: jd */
public class C0960jd implements C2052x6 {

    /* renamed from: a */
    public final Rect f3401a = new Rect();

    /* renamed from: b */
    public final /* synthetic */ ViewPager f3402b;

    public C0960jd(ViewPager viewPager) {
        this.f3402b = viewPager;
    }

    /* renamed from: a */
    public C0943j7 mo650a(View view, C0943j7 j7Var) {
        C0943j7 m = C0010a7.m40m(view, j7Var);
        if (m.mo4131g()) {
            return m;
        }
        Rect rect = this.f3401a;
        rect.left = m.mo4126b();
        rect.top = m.mo4128d();
        rect.right = m.mo4127c();
        rect.bottom = m.mo4125a();
        int childCount = this.f3402b.getChildCount();
        for (int i = 0; i < childCount; i++) {
            C0943j7 d = C0010a7.m31d(this.f3402b.getChildAt(i), m);
            rect.left = Math.min(d.mo4126b(), rect.left);
            rect.top = Math.min(d.mo4128d(), rect.top);
            rect.right = Math.min(d.mo4127c(), rect.right);
            rect.bottom = Math.min(d.mo4125a(), rect.bottom);
        }
        return m.mo4132h(rect.left, rect.top, rect.right, rect.bottom);
    }
}
