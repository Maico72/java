package p000;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import java.security.MessageDigest;

/* renamed from: jk */
public class C0971jk extends C0783gk {

    /* renamed from: b */
    public static final byte[] f3458b = "com.bumptech.glide.load.resource.bitmap.CenterCrop".getBytes(C2005wf.f6654a);

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
        messageDigest.update(f3458b);
    }

    /* renamed from: c */
    public Bitmap mo3816c(C0056ai aiVar, Bitmap bitmap, int i, int i2) {
        float f;
        float f2;
        Paint paint = C0063al.f193a;
        if (bitmap.getWidth() == i && bitmap.getHeight() == i2) {
            return bitmap;
        }
        Matrix matrix = new Matrix();
        float f3 = 0.0f;
        if (bitmap.getWidth() * i2 > bitmap.getHeight() * i) {
            f2 = ((float) i2) / ((float) bitmap.getHeight());
            f3 = (((float) i) - (((float) bitmap.getWidth()) * f2)) * 0.5f;
            f = 0.0f;
        } else {
            f2 = ((float) i) / ((float) bitmap.getWidth());
            f = (((float) i2) - (((float) bitmap.getHeight()) * f2)) * 0.5f;
        }
        matrix.setScale(f2, f2);
        matrix.postTranslate((float) ((int) (f3 + 0.5f)), (float) ((int) (f + 0.5f)));
        Bitmap d = aiVar.mo130d(i, i2, C0063al.m128c(bitmap));
        d.setHasAlpha(bitmap.hasAlpha());
        C0063al.m126a(bitmap, d, matrix);
        return d;
    }

    public boolean equals(Object obj) {
        return obj instanceof C0971jk;
    }

    public int hashCode() {
        return -599754482;
    }
}
