package p000;

import android.graphics.Bitmap;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import p000.C0847ho;

/* renamed from: hk */
public class C0843hk implements C0054ag<ByteBuffer, Bitmap> {

    /* renamed from: a */
    public final C1263nk f3139a;

    public C0843hk(C1263nk nkVar) {
        this.f3139a = nkVar;
    }

    /* renamed from: a */
    public C1675rh mo122a(Object obj, int i, int i2, C2150yf yfVar) {
        AtomicReference<byte[]> atomicReference = C0847ho.f3143a;
        return this.f3139a.mo4856b(new C0847ho.C0848a((ByteBuffer) obj), i, i2, yfVar, C1263nk.f4323k);
    }

    /* renamed from: b */
    public boolean mo123b(Object obj, C2150yf yfVar) {
        ByteBuffer byteBuffer = (ByteBuffer) obj;
        Objects.requireNonNull(this.f3139a);
        return true;
    }
}
