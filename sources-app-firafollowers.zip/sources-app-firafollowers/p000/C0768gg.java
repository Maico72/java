package p000;

/* renamed from: gg */
public interface C0768gg<T> {

    /* renamed from: gg$a */
    public interface C0769a<T> {
        /* renamed from: d */
        void mo3802d(Exception exc);

        /* renamed from: f */
        void mo3803f(T t);
    }

    /* renamed from: a */
    Class<T> mo134a();

    /* renamed from: b */
    void mo135b();

    /* renamed from: c */
    C1017kf mo136c();

    void cancel();

    /* renamed from: e */
    void mo138e(C2066xe xeVar, C0769a<? super T> aVar);
}
