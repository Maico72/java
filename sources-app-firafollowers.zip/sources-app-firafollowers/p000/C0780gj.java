package p000;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import java.io.File;
import java.io.FileNotFoundException;
import p000.C0768gg;
import p000.C0969jj;

/* renamed from: gj */
public final class C0780gj implements C0969jj<Uri, File> {

    /* renamed from: a */
    public final Context f2971a;

    /* renamed from: gj$a */
    public static final class C0781a implements C1023kj<Uri, File> {

        /* renamed from: a */
        public final Context f2972a;

        public C0781a(Context context) {
            this.f2972a = context;
        }

        /* renamed from: b */
        public C0969jj<Uri, File> mo139b(C1259nj njVar) {
            return new C0780gj(this.f2972a);
        }
    }

    /* renamed from: gj$b */
    public static class C0782b implements C0768gg<File> {

        /* renamed from: f */
        public static final String[] f2973f = {"_data"};

        /* renamed from: d */
        public final Context f2974d;

        /* renamed from: e */
        public final Uri f2975e;

        public C0782b(Context context, Uri uri) {
            this.f2974d = context;
            this.f2975e = uri;
        }

        /* renamed from: a */
        public Class<File> mo134a() {
            return File.class;
        }

        /* renamed from: b */
        public void mo135b() {
        }

        /* renamed from: c */
        public C1017kf mo136c() {
            return C1017kf.LOCAL;
        }

        public void cancel() {
        }

        /* renamed from: e */
        public void mo138e(C2066xe xeVar, C0768gg.C0769a<? super File> aVar) {
            Cursor query = this.f2974d.getContentResolver().query(this.f2975e, f2973f, (String) null, (String[]) null, (String) null);
            String str = null;
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        str = query.getString(query.getColumnIndexOrThrow("_data"));
                    }
                } finally {
                    query.close();
                }
            }
            if (TextUtils.isEmpty(str)) {
                StringBuilder d = C1012kd.m3195d("Failed to find file path for: ");
                d.append(this.f2975e);
                aVar.mo3802d(new FileNotFoundException(d.toString()));
                return;
            }
            aVar.mo3803f(new File(str));
        }
    }

    public C0780gj(Context context) {
        this.f2971a = context;
    }

    /* renamed from: a */
    public C0969jj.C0970a mo132a(Object obj, int i, int i2, C2150yf yfVar) {
        Uri uri = (Uri) obj;
        return new C0969jj.C0970a(new C0788go(uri), new C0782b(this.f2971a, uri));
    }

    /* renamed from: b */
    public boolean mo133b(Object obj) {
        return C1401p4.m4333J((Uri) obj);
    }
}
