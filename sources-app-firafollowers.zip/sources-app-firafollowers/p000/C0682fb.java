package p000;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: fb */
public abstract class C0682fb {

    /* renamed from: a */
    public final RecyclerView.C0162m f2724a;

    /* renamed from: b */
    public int f2725b = Integer.MIN_VALUE;

    /* renamed from: c */
    public final Rect f2726c = new Rect();

    public C0682fb(RecyclerView.C0162m mVar, C0544db dbVar) {
        this.f2724a = mVar;
    }

    /* renamed from: a */
    public static C0682fb m2213a(RecyclerView.C0162m mVar, int i) {
        if (i == 0) {
            return new C0544db(mVar);
        }
        if (i == 1) {
            return new C0616eb(mVar);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    /* renamed from: b */
    public abstract int mo2971b(View view);

    /* renamed from: c */
    public abstract int mo2972c(View view);

    /* renamed from: d */
    public abstract int mo2973d(View view);

    /* renamed from: e */
    public abstract int mo2974e(View view);

    /* renamed from: f */
    public abstract int mo2975f();

    /* renamed from: g */
    public abstract int mo2976g();

    /* renamed from: h */
    public abstract int mo2977h();

    /* renamed from: i */
    public abstract int mo2978i();

    /* renamed from: j */
    public abstract int mo2979j();

    /* renamed from: k */
    public abstract int mo2980k();

    /* renamed from: l */
    public abstract int mo2981l();

    /* renamed from: m */
    public int mo3550m() {
        if (Integer.MIN_VALUE == this.f2725b) {
            return 0;
        }
        return mo2981l() - this.f2725b;
    }

    /* renamed from: n */
    public abstract int mo2982n(View view);

    /* renamed from: o */
    public abstract int mo2983o(View view);

    /* renamed from: p */
    public abstract void mo2984p(int i);
}
