package p000;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: ae */
public class C0028ae {

    /* renamed from: a */
    public final AtomicInteger f86a = new AtomicInteger();

    /* renamed from: b */
    public final Set<C2210zd<?>> f87b = new HashSet();

    /* renamed from: c */
    public final PriorityBlockingQueue<C2210zd<?>> f88c = new PriorityBlockingQueue<>();

    /* renamed from: d */
    public final PriorityBlockingQueue<C2210zd<?>> f89d = new PriorityBlockingQueue<>();

    /* renamed from: e */
    public final C1175md f90e;

    /* renamed from: f */
    public final C1795td f91f;

    /* renamed from: g */
    public final C0352ce f92g;

    /* renamed from: h */
    public final C1856ud[] f93h;

    /* renamed from: i */
    public C1332od f94i;

    /* renamed from: j */
    public final List<C0030b> f95j = new ArrayList();

    /* renamed from: k */
    public final List<C0029a> f96k = new ArrayList();

    /* renamed from: ae$a */
    public interface C0029a {
        /* renamed from: a */
        void mo83a(C2210zd<?> zdVar, int i);
    }

    @Deprecated
    /* renamed from: ae$b */
    public interface C0030b<T> {
        /* renamed from: a */
        void mo84a(C2210zd<T> zdVar);
    }

    public C0028ae(C1175md mdVar, C1795td tdVar) {
        C1667rd rdVar = new C1667rd(new Handler(Looper.getMainLooper()));
        this.f90e = mdVar;
        this.f91f = tdVar;
        this.f93h = new C1856ud[4];
        this.f92g = rdVar;
    }

    /* renamed from: a */
    public void mo82a(C2210zd<?> zdVar, int i) {
        synchronized (this.f96k) {
            for (C0029a a : this.f96k) {
                a.mo83a(zdVar, i);
            }
        }
    }
}
