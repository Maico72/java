package p000;

/* renamed from: a5 */
public final class C0008a5 implements C2049x4 {

    /* renamed from: a */
    public final C2115y5 f22a;

    /* renamed from: b */
    public final int f23b;

    /* renamed from: c */
    public final int f24c;

    public C0008a5(C2115y5 y5Var, int i, int i2) {
        this.f22a = y5Var;
        this.f24c = i;
        this.f23b = i2;
    }
}
