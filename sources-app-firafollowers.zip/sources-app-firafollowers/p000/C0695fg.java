package p000;

import java.io.OutputStream;

/* renamed from: fg */
public final class C0695fg extends OutputStream {

    /* renamed from: d */
    public final OutputStream f2746d;

    /* renamed from: e */
    public byte[] f2747e;

    /* renamed from: f */
    public C2152yh f2748f;

    /* renamed from: g */
    public int f2749g;

    public C0695fg(OutputStream outputStream, C2152yh yhVar) {
        this.f2746d = outputStream;
        this.f2748f = yhVar;
        this.f2747e = (byte[]) yhVar.mo3607e(65536, byte[].class);
    }

    /* JADX INFO: finally extract failed */
    public void close() {
        try {
            flush();
            this.f2746d.close();
            byte[] bArr = this.f2747e;
            if (bArr != null) {
                this.f2748f.mo3606d(bArr);
                this.f2747e = null;
            }
        } catch (Throwable th) {
            this.f2746d.close();
            throw th;
        }
    }

    public void flush() {
        int i = this.f2749g;
        if (i > 0) {
            this.f2746d.write(this.f2747e, 0, i);
            this.f2749g = 0;
        }
        this.f2746d.flush();
    }

    public void write(int i) {
        byte[] bArr = this.f2747e;
        int i2 = this.f2749g;
        int i3 = i2 + 1;
        this.f2749g = i3;
        bArr[i2] = (byte) i;
        if (i3 == bArr.length && i3 > 0) {
            this.f2746d.write(bArr, 0, i3);
            this.f2749g = 0;
        }
    }

    public void write(byte[] bArr) {
        write(bArr, 0, bArr.length);
    }

    public void write(byte[] bArr, int i, int i2) {
        int i3 = 0;
        do {
            int i4 = i2 - i3;
            int i5 = i + i3;
            int i6 = this.f2749g;
            if (i6 != 0 || i4 < this.f2747e.length) {
                int min = Math.min(i4, this.f2747e.length - i6);
                System.arraycopy(bArr, i5, this.f2747e, this.f2749g, min);
                int i7 = this.f2749g + min;
                this.f2749g = i7;
                i3 += min;
                byte[] bArr2 = this.f2747e;
                if (i7 == bArr2.length && i7 > 0) {
                    this.f2746d.write(bArr2, 0, i7);
                    this.f2749g = 0;
                    continue;
                }
            } else {
                this.f2746d.write(bArr, i5, i4);
                return;
            }
        } while (i3 < i2);
    }
}
