package p000;

/* renamed from: ce */
public interface C0352ce {
}
