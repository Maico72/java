package p000;

/* renamed from: gm */
public interface C0785gm extends C1622qm {

    /* renamed from: gm$a */
    public interface C0786a {
    }
}
