package p000;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.util.StateSet;
import p000.C0321c0;
import p000.C0594e0;

@SuppressLint({"RestrictedAPI"})
/* renamed from: b0 */
public class C0235b0 extends C0594e0 implements C1402p5 {

    /* renamed from: s */
    public C0238c f1162s;

    /* renamed from: t */
    public C0242g f1163t;

    /* renamed from: u */
    public int f1164u;

    /* renamed from: v */
    public int f1165v;

    /* renamed from: w */
    public boolean f1166w;

    /* renamed from: b0$b */
    public static class C0237b extends C0242g {

        /* renamed from: a */
        public final Animatable f1167a;

        public C0237b(Animatable animatable) {
            super((C0236a) null);
            this.f1167a = animatable;
        }

        /* renamed from: c */
        public void mo1499c() {
            this.f1167a.start();
        }

        /* renamed from: d */
        public void mo1500d() {
            this.f1167a.stop();
        }
    }

    /* renamed from: b0$c */
    public static class C0238c extends C0594e0.C0595a {

        /* renamed from: K */
        public C0259b4<Long> f1168K;

        /* renamed from: L */
        public C0670f4<Integer> f1169L;

        public C0238c(C0238c cVar, C0235b0 b0Var, Resources resources) {
            super(cVar, b0Var, resources);
            C0670f4<Integer> f4Var;
            if (cVar != null) {
                this.f1168K = cVar.f1168K;
                f4Var = cVar.f1169L;
            } else {
                this.f1168K = new C0259b4<>();
                f4Var = new C0670f4<>(10);
            }
            this.f1169L = f4Var;
        }

        /* renamed from: h */
        public static long m988h(int i, int i2) {
            return ((long) i2) | (((long) i) << 32);
        }

        /* renamed from: e */
        public void mo1501e() {
            this.f1168K = this.f1168K.clone();
            this.f1169L = this.f1169L.clone();
        }

        /* renamed from: i */
        public int mo1502i(int i) {
            if (i < 0) {
                return 0;
            }
            return this.f1169L.mo3488e(i, 0).intValue();
        }

        public Drawable newDrawable() {
            return new C0235b0(this, (Resources) null);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0235b0(this, resources);
        }
    }

    /* renamed from: b0$d */
    public static class C0239d extends C0242g {

        /* renamed from: a */
        public final C2205zc f1170a;

        public C0239d(C2205zc zcVar) {
            super((C0236a) null);
            this.f1170a = zcVar;
        }

        /* renamed from: c */
        public void mo1499c() {
            this.f1170a.start();
        }

        /* renamed from: d */
        public void mo1500d() {
            this.f1170a.stop();
        }
    }

    /* renamed from: b0$e */
    public static class C0240e extends C0242g {

        /* renamed from: a */
        public final ObjectAnimator f1171a;

        /* renamed from: b */
        public final boolean f1172b;

        public C0240e(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super((C0236a) null);
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i = z ? numberOfFrames - 1 : 0;
            int i2 = z ? 0 : numberOfFrames - 1;
            C0241f fVar = new C0241f(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", new int[]{i, i2});
            ofInt.setAutoCancel(true);
            ofInt.setDuration((long) fVar.f1175c);
            ofInt.setInterpolator(fVar);
            this.f1172b = z2;
            this.f1171a = ofInt;
        }

        /* renamed from: a */
        public boolean mo1505a() {
            return this.f1172b;
        }

        /* renamed from: b */
        public void mo1506b() {
            this.f1171a.reverse();
        }

        /* renamed from: c */
        public void mo1499c() {
            this.f1171a.start();
        }

        /* renamed from: d */
        public void mo1500d() {
            this.f1171a.cancel();
        }
    }

    /* renamed from: b0$f */
    public static class C0241f implements TimeInterpolator {

        /* renamed from: a */
        public int[] f1173a;

        /* renamed from: b */
        public int f1174b;

        /* renamed from: c */
        public int f1175c;

        public C0241f(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.f1174b = numberOfFrames;
            int[] iArr = this.f1173a;
            if (iArr == null || iArr.length < numberOfFrames) {
                this.f1173a = new int[numberOfFrames];
            }
            int[] iArr2 = this.f1173a;
            int i = 0;
            for (int i2 = 0; i2 < numberOfFrames; i2++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i2) - 1 : i2);
                iArr2[i2] = duration;
                i += duration;
            }
            this.f1175c = i;
        }

        public float getInterpolation(float f) {
            int i = (int) ((f * ((float) this.f1175c)) + 0.5f);
            int i2 = this.f1174b;
            int[] iArr = this.f1173a;
            int i3 = 0;
            while (i3 < i2 && i >= iArr[i3]) {
                i -= iArr[i3];
                i3++;
            }
            return (((float) i3) / ((float) i2)) + (i3 < i2 ? ((float) i) / ((float) this.f1175c) : 0.0f);
        }
    }

    /* renamed from: b0$g */
    public static abstract class C0242g {
        public C0242g(C0236a aVar) {
        }

        /* renamed from: a */
        public boolean mo1505a() {
            return false;
        }

        /* renamed from: b */
        public void mo1506b() {
        }

        /* renamed from: c */
        public abstract void mo1499c();

        /* renamed from: d */
        public abstract void mo1500d();
    }

    static {
        Class<C0235b0> cls = C0235b0.class;
    }

    public C0235b0() {
        this((C0238c) null, (Resources) null);
    }

    public C0235b0(C0238c cVar, Resources resources) {
        super((C0594e0.C0595a) null);
        this.f1164u = -1;
        this.f1165v = -1;
        C0238c cVar2 = new C0238c(cVar, this, resources);
        super.mo1492e(cVar2);
        this.f1162s = cVar2;
        onStateChange(getState());
        jumpToCurrentState();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0213, code lost:
        throw new org.xmlpull.v1.XmlPullParserException(p000.C1012kd.m3194c(r2, new java.lang.StringBuilder(), ": <transition> tag requires 'fromId' & 'toId' attributes"));
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static p000.C0235b0 m982g(android.content.Context r19, android.content.res.Resources r20, org.xmlpull.v1.XmlPullParser r21, android.util.AttributeSet r22, android.content.res.Resources.Theme r23) {
        /*
            r0 = r19
            r1 = r20
            r2 = r21
            r3 = r22
            r4 = r23
            java.lang.String r5 = r21.getName()
            java.lang.String r6 = "animated-selector"
            boolean r6 = r5.equals(r6)
            if (r6 == 0) goto L_0x023a
            b0 r5 = new b0
            r6 = 0
            r5.<init>(r6, r6)
            int[] r6 = p000.C0661f0.f2621a
            android.content.res.TypedArray r6 = p000.C0532d5.m1705e(r1, r4, r3, r6)
            r7 = 1
            boolean r8 = r6.getBoolean(r7, r7)
            r5.setVisible(r8, r7)
            b0$c r8 = r5.f1162s
            int r9 = android.os.Build.VERSION.SDK_INT
            r10 = 21
            if (r9 < r10) goto L_0x003b
            int r10 = r8.f1397d
            int r11 = r6.getChangingConfigurations()
            r10 = r10 | r11
            r8.f1397d = r10
        L_0x003b:
            boolean r10 = r8.f1402i
            r11 = 2
            boolean r10 = r6.getBoolean(r11, r10)
            r8.f1402i = r10
            boolean r10 = r8.f1405l
            r12 = 3
            boolean r10 = r6.getBoolean(r12, r10)
            r8.f1405l = r10
            int r10 = r8.f1385A
            r13 = 4
            int r10 = r6.getInt(r13, r10)
            r8.f1385A = r10
            r10 = 5
            int r14 = r8.f1386B
            int r10 = r6.getInt(r10, r14)
            r8.f1386B = r10
            boolean r8 = r8.f1417x
            r10 = 0
            boolean r8 = r6.getBoolean(r10, r8)
            r5.setDither(r8)
            c0$c r8 = r5.f1371d
            r8.mo1776f(r1)
            r6.recycle()
            int r6 = r21.getDepth()
            int r6 = r6 + r7
        L_0x0076:
            int r8 = r21.next()
            if (r8 == r7) goto L_0x0232
            int r14 = r21.getDepth()
            if (r14 >= r6) goto L_0x0084
            if (r8 == r12) goto L_0x0232
        L_0x0084:
            if (r8 == r11) goto L_0x0087
            goto L_0x0076
        L_0x0087:
            if (r14 <= r6) goto L_0x008a
            goto L_0x0076
        L_0x008a:
            java.lang.String r8 = r21.getName()
            java.lang.String r11 = "item"
            boolean r8 = r8.equals(r11)
            r11 = -1
            if (r8 == 0) goto L_0x014f
            int[] r8 = p000.C0661f0.f2622b
            android.content.res.TypedArray r8 = p000.C0532d5.m1705e(r1, r4, r3, r8)
            int r12 = r8.getResourceId(r10, r10)
            int r7 = r8.getResourceId(r7, r11)
            if (r7 <= 0) goto L_0x00b0
            s2 r11 = p000.C1710s2.m4883d()
            android.graphics.drawable.Drawable r7 = r11.mo5792f(r0, r7)
            goto L_0x00b1
        L_0x00b0:
            r7 = 0
        L_0x00b1:
            r8.recycle()
            int r8 = r22.getAttributeCount()
            int[] r11 = new int[r8]
            r14 = 0
            r15 = 0
        L_0x00bc:
            r16 = r6
            if (r15 >= r8) goto L_0x00e6
            int r6 = r3.getAttributeNameResource(r15)
            r17 = r8
            if (r6 == 0) goto L_0x00df
            r8 = 16842960(0x10100d0, float:2.369414E-38)
            if (r6 == r8) goto L_0x00df
            r8 = 16843161(0x1010199, float:2.3694704E-38)
            if (r6 == r8) goto L_0x00df
            int r8 = r14 + 1
            boolean r18 = r3.getAttributeBooleanValue(r15, r10)
            if (r18 == 0) goto L_0x00db
            goto L_0x00dc
        L_0x00db:
            int r6 = -r6
        L_0x00dc:
            r11[r14] = r6
            r14 = r8
        L_0x00df:
            int r15 = r15 + 1
            r6 = r16
            r8 = r17
            goto L_0x00bc
        L_0x00e6:
            int[] r6 = android.util.StateSet.trimStateSet(r11, r14)
            java.lang.String r8 = ": <item> tag requires a 'drawable' attribute or child tag defining a drawable"
            if (r7 != 0) goto L_0x0126
        L_0x00ee:
            int r7 = r21.next()
            if (r7 != r13) goto L_0x00f5
            goto L_0x00ee
        L_0x00f5:
            r11 = 2
            if (r7 != r11) goto L_0x0117
            java.lang.String r7 = r21.getName()
            java.lang.String r11 = "vector"
            boolean r7 = r7.equals(r11)
            if (r7 == 0) goto L_0x0109
            ed r7 = p000.C0622ed.m2013a(r20, r21, r22, r23)
            goto L_0x0126
        L_0x0109:
            r7 = 21
            if (r9 < r7) goto L_0x0112
            android.graphics.drawable.Drawable r7 = android.graphics.drawable.Drawable.createFromXmlInner(r20, r21, r22, r23)
            goto L_0x0126
        L_0x0112:
            android.graphics.drawable.Drawable r7 = android.graphics.drawable.Drawable.createFromXmlInner(r20, r21, r22)
            goto L_0x0126
        L_0x0117:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r1 = p000.C1012kd.m3194c(r2, r1, r8)
            r0.<init>(r1)
            throw r0
        L_0x0126:
            if (r7 == 0) goto L_0x0140
            b0$c r8 = r5.f1162s
            int r7 = r8.mo1771a(r7)
            int[][] r11 = r8.f2399J
            r11[r7] = r6
            f4<java.lang.Integer> r6 = r8.f1169L
            java.lang.Integer r8 = java.lang.Integer.valueOf(r12)
            r6.mo3490g(r7, r8)
            r7 = 1
            r11 = 2
            r12 = 3
            goto L_0x022e
        L_0x0140:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r1 = p000.C1012kd.m3194c(r2, r1, r8)
            r0.<init>(r1)
            throw r0
        L_0x014f:
            r16 = r6
            java.lang.String r6 = r21.getName()
            java.lang.String r7 = "transition"
            boolean r6 = r6.equals(r7)
            if (r6 == 0) goto L_0x0223
            int[] r6 = p000.C0661f0.f2623c
            android.content.res.TypedArray r6 = p000.C0532d5.m1705e(r1, r4, r3, r6)
            r7 = 2
            int r7 = r6.getResourceId(r7, r11)
            r8 = 1
            int r8 = r6.getResourceId(r8, r11)
            int r12 = r6.getResourceId(r10, r11)
            if (r12 <= 0) goto L_0x017c
            s2 r14 = p000.C1710s2.m4883d()
            android.graphics.drawable.Drawable r12 = r14.mo5792f(r0, r12)
            goto L_0x017d
        L_0x017c:
            r12 = 0
        L_0x017d:
            r14 = 3
            boolean r10 = r6.getBoolean(r14, r10)
            r6.recycle()
            java.lang.String r6 = ": <transition> tag requires a 'drawable' attribute or child tag defining a drawable"
            if (r12 != 0) goto L_0x01c6
        L_0x0189:
            int r12 = r21.next()
            if (r12 != r13) goto L_0x0190
            goto L_0x0189
        L_0x0190:
            r13 = 2
            if (r12 != r13) goto L_0x01b7
            java.lang.String r12 = r21.getName()
            java.lang.String r13 = "animated-vector"
            boolean r12 = r12.equals(r13)
            if (r12 == 0) goto L_0x01a9
            zc r12 = new zc
            r13 = 0
            r12.<init>(r0, r13, r13)
            r12.inflate(r1, r2, r3, r4)
            goto L_0x01c6
        L_0x01a9:
            r12 = 21
            if (r9 < r12) goto L_0x01b2
            android.graphics.drawable.Drawable r12 = android.graphics.drawable.Drawable.createFromXmlInner(r20, r21, r22, r23)
            goto L_0x01c6
        L_0x01b2:
            android.graphics.drawable.Drawable r12 = android.graphics.drawable.Drawable.createFromXmlInner(r20, r21, r22)
            goto L_0x01c6
        L_0x01b7:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r1 = p000.C1012kd.m3194c(r2, r1, r6)
            r0.<init>(r1)
            throw r0
        L_0x01c6:
            if (r12 == 0) goto L_0x0214
            if (r7 == r11) goto L_0x0203
            if (r8 == r11) goto L_0x0203
            b0$c r6 = r5.f1162s
            int r11 = r6.mo1771a(r12)
            long r12 = p000.C0235b0.C0238c.m988h(r7, r8)
            if (r10 == 0) goto L_0x01de
            r14 = 8589934592(0x200000000, double:4.243991582E-314)
            goto L_0x01e0
        L_0x01de:
            r14 = 0
        L_0x01e0:
            b4<java.lang.Long> r0 = r6.f1168K
            long r3 = (long) r11
            long r17 = r3 | r14
            java.lang.Long r11 = java.lang.Long.valueOf(r17)
            r0.mo1584a(r12, r11)
            if (r10 == 0) goto L_0x0223
            long r7 = p000.C0235b0.C0238c.m988h(r8, r7)
            b4<java.lang.Long> r0 = r6.f1168K
            r10 = 4294967296(0x100000000, double:2.121995791E-314)
            long r3 = r3 | r10
            long r3 = r3 | r14
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            r0.mo1584a(r7, r3)
            goto L_0x0223
        L_0x0203:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = ": <transition> tag requires 'fromId' & 'toId' attributes"
            java.lang.String r1 = p000.C1012kd.m3194c(r2, r1, r3)
            r0.<init>(r1)
            throw r0
        L_0x0214:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r1 = p000.C1012kd.m3194c(r2, r1, r6)
            r0.<init>(r1)
            throw r0
        L_0x0223:
            r7 = 1
            r10 = 0
            r11 = 2
            r12 = 3
            r13 = 4
            r0 = r19
            r3 = r22
            r4 = r23
        L_0x022e:
            r6 = r16
            goto L_0x0076
        L_0x0232:
            int[] r0 = r5.getState()
            r5.onStateChange(r0)
            return r5
        L_0x023a:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = r21.getPositionDescription()
            r1.append(r2)
            java.lang.String r2 = ": invalid animated-selector tag "
            r1.append(r2)
            r1.append(r5)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            goto L_0x0259
        L_0x0258:
            throw r0
        L_0x0259:
            goto L_0x0258
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0235b0.m982g(android.content.Context, android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):b0");
    }

    /* renamed from: b */
    public C0321c0.C0324c mo1491b() {
        return new C0238c(this.f1162s, this, (Resources) null);
    }

    /* renamed from: e */
    public void mo1492e(C0321c0.C0324c cVar) {
        super.mo1492e(cVar);
        if (cVar instanceof C0238c) {
            this.f1162s = (C0238c) cVar;
        }
    }

    /* renamed from: f */
    public C0594e0.C0595a mo1493f() {
        return new C0238c(this.f1162s, this, (Resources) null);
    }

    public boolean isStateful() {
        return true;
    }

    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        C0242g gVar = this.f1163t;
        if (gVar != null) {
            gVar.mo1500d();
            this.f1163t = null;
            mo1738d(this.f1164u);
            this.f1164u = -1;
            this.f1165v = -1;
        }
    }

    public Drawable mutate() {
        if (!this.f1166w) {
            super.mutate();
            if (this == this) {
                this.f1162s.mo1501e();
                this.f1166w = true;
            }
        }
        return this;
    }

    public boolean onStateChange(int[] iArr) {
        boolean z;
        C0242g gVar;
        int[] iArr2 = iArr;
        C0238c cVar = this.f1162s;
        int g = cVar.mo3165g(iArr2);
        if (g < 0) {
            g = cVar.mo3165g(StateSet.WILD_CARD);
        }
        int i = this.f1377j;
        boolean z2 = false;
        if (g != i) {
            C0242g gVar2 = this.f1163t;
            if (gVar2 != null) {
                if (g != this.f1164u) {
                    if (g != this.f1165v || !gVar2.mo1505a()) {
                        i = this.f1164u;
                        gVar2.mo1500d();
                    } else {
                        gVar2.mo1506b();
                        this.f1164u = this.f1165v;
                        this.f1165v = g;
                    }
                }
                z = true;
                if (z || mo1738d(g)) {
                    z2 = true;
                }
            }
            this.f1163t = null;
            this.f1165v = -1;
            this.f1164u = -1;
            C0238c cVar2 = this.f1162s;
            int i2 = cVar2.mo1502i(i);
            int i3 = cVar2.mo1502i(g);
            if (!(i3 == 0 || i2 == 0)) {
                int longValue = (int) cVar2.f1168K.mo1590f(C0238c.m988h(i2, i3), -1L).longValue();
                if (longValue >= 0) {
                    boolean z3 = (cVar2.f1168K.mo1590f(C0238c.m988h(i2, i3), -1L).longValue() & 8589934592L) != 0;
                    mo1738d(longValue);
                    Drawable drawable = this.f1373f;
                    if (drawable instanceof AnimationDrawable) {
                        gVar = new C0240e((AnimationDrawable) drawable, (cVar2.f1168K.mo1590f(C0238c.m988h(i2, i3), -1L).longValue() & 4294967296L) != 0, z3);
                    } else if (drawable instanceof C2205zc) {
                        gVar = new C0239d((C2205zc) drawable);
                    } else if (drawable instanceof Animatable) {
                        gVar = new C0237b((Animatable) drawable);
                    }
                    gVar.mo1499c();
                    this.f1163t = gVar;
                    this.f1165v = i;
                    this.f1164u = g;
                    z = true;
                    z2 = true;
                }
            }
            z = false;
            z2 = true;
        }
        Drawable drawable2 = this.f1373f;
        return drawable2 != null ? z2 | drawable2.setState(iArr2) : z2;
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        C0242g gVar = this.f1163t;
        if (gVar != null && (visible || z2)) {
            if (z) {
                gVar.mo1499c();
            } else {
                jumpToCurrentState();
            }
        }
        return visible;
    }
}
