package p000;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: a8 */
public abstract class C0015a8 implements Parcelable {
    public static final Parcelable.Creator<C0015a8> CREATOR = new C0017b();

    /* renamed from: e */
    public static final C0015a8 f42e = new C0016a();

    /* renamed from: d */
    public final Parcelable f43d;

    /* renamed from: a8$a */
    public static class C0016a extends C0015a8 {
        public C0016a() {
            super((C0016a) null);
        }
    }

    /* renamed from: a8$b */
    public static class C0017b implements Parcelable.ClassLoaderCreator<C0015a8> {
        public Object createFromParcel(Parcel parcel) {
            if (parcel.readParcelable((ClassLoader) null) == null) {
                return C0015a8.f42e;
            }
            throw new IllegalStateException("superState must be null");
        }

        public Object[] newArray(int i) {
            return new C0015a8[i];
        }

        public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
            if (parcel.readParcelable(classLoader) == null) {
                return C0015a8.f42e;
            }
            throw new IllegalStateException("superState must be null");
        }
    }

    public C0015a8(C0016a aVar) {
        this.f43d = null;
    }

    public C0015a8(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f43d = readParcelable == null ? f42e : readParcelable;
    }

    public C0015a8(Parcelable parcelable) {
        if (parcelable != null) {
            this.f43d = parcelable == f42e ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f43d, i);
    }
}
