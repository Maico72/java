package p000;

/* renamed from: jr */
public class C0979jr extends C1627qq {

    /* renamed from: c */
    public final C0979jr f3467c;

    /* renamed from: d */
    public C0852hr f3468d;

    /* renamed from: e */
    public C0979jr f3469e;

    /* renamed from: f */
    public String f3470f;

    /* renamed from: g */
    public Object f3471g;

    /* renamed from: h */
    public boolean f3472h;

    public C0979jr(int i, C0979jr jrVar, C0852hr hrVar) {
        this.f5339a = i;
        this.f3467c = jrVar;
        this.f3468d = hrVar;
        this.f5340b = -1;
    }

    public C0979jr(int i, C0979jr jrVar, C0852hr hrVar, Object obj) {
        this.f5339a = i;
        this.f3467c = jrVar;
        this.f3468d = hrVar;
        this.f5340b = -1;
        this.f3471g = obj;
    }

    /* renamed from: a */
    public final String mo3854a() {
        return this.f3470f;
    }

    /* renamed from: d */
    public void mo3855d(Object obj) {
        this.f3471g = obj;
    }

    /* renamed from: f */
    public C0979jr mo4188f() {
        C0979jr jrVar = this.f3469e;
        if (jrVar == null) {
            C0852hr hrVar = this.f3468d;
            C0979jr jrVar2 = new C0979jr(1, this, hrVar == null ? null : hrVar.mo3956a());
            this.f3469e = jrVar2;
            return jrVar2;
        }
        jrVar.mo4192j(1);
        return jrVar;
    }

    /* renamed from: g */
    public C0979jr mo4189g(Object obj) {
        C0979jr jrVar = this.f3469e;
        if (jrVar == null) {
            C0852hr hrVar = this.f3468d;
            C0979jr jrVar2 = new C0979jr(1, this, hrVar == null ? null : hrVar.mo3956a(), obj);
            this.f3469e = jrVar2;
            return jrVar2;
        }
        jrVar.mo4193k(1, obj);
        return jrVar;
    }

    /* renamed from: h */
    public C0979jr mo4190h() {
        C0979jr jrVar = this.f3469e;
        if (jrVar == null) {
            C0852hr hrVar = this.f3468d;
            C0979jr jrVar2 = new C0979jr(2, this, hrVar == null ? null : hrVar.mo3956a());
            this.f3469e = jrVar2;
            return jrVar2;
        }
        jrVar.mo4192j(2);
        return jrVar;
    }

    /* renamed from: i */
    public C0979jr mo4191i(Object obj) {
        C0979jr jrVar = this.f3469e;
        if (jrVar == null) {
            C0852hr hrVar = this.f3468d;
            C0979jr jrVar2 = new C0979jr(2, this, hrVar == null ? null : hrVar.mo3956a(), obj);
            this.f3469e = jrVar2;
            return jrVar2;
        }
        jrVar.mo4193k(2, obj);
        return jrVar;
    }

    /* renamed from: j */
    public C0979jr mo4192j(int i) {
        this.f5339a = i;
        this.f5340b = -1;
        this.f3470f = null;
        this.f3472h = false;
        this.f3471g = null;
        C0852hr hrVar = this.f3468d;
        if (hrVar != null) {
            hrVar.f3150b = null;
            hrVar.f3151c = null;
            hrVar.f3152d = null;
        }
        return this;
    }

    /* renamed from: k */
    public C0979jr mo4193k(int i, Object obj) {
        this.f5339a = i;
        this.f5340b = -1;
        this.f3470f = null;
        this.f3472h = false;
        this.f3471g = obj;
        C0852hr hrVar = this.f3468d;
        if (hrVar != null) {
            hrVar.f3150b = null;
            hrVar.f3151c = null;
            hrVar.f3152d = null;
        }
        return this;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0053  */
    /* renamed from: l */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int mo4194l(java.lang.String r5) {
        /*
            r4 = this;
            int r0 = r4.f5339a
            r1 = 2
            if (r0 != r1) goto L_0x0071
            boolean r0 = r4.f3472h
            if (r0 == 0) goto L_0x000a
            goto L_0x0071
        L_0x000a:
            r0 = 1
            r4.f3472h = r0
            r4.f3470f = r5
            hr r1 = r4.f3468d
            if (r1 == 0) goto L_0x006b
            java.lang.String r2 = r1.f3150b
            if (r2 != 0) goto L_0x001a
            r1.f3150b = r5
            goto L_0x0027
        L_0x001a:
            boolean r2 = r5.equals(r2)
            if (r2 == 0) goto L_0x0021
            goto L_0x002f
        L_0x0021:
            java.lang.String r2 = r1.f3151c
            if (r2 != 0) goto L_0x0029
            r1.f3151c = r5
        L_0x0027:
            r2 = 0
            goto L_0x0051
        L_0x0029:
            boolean r2 = r5.equals(r2)
            if (r2 == 0) goto L_0x0031
        L_0x002f:
            r2 = 1
            goto L_0x0051
        L_0x0031:
            java.util.HashSet<java.lang.String> r2 = r1.f3152d
            if (r2 != 0) goto L_0x004a
            java.util.HashSet r2 = new java.util.HashSet
            r3 = 16
            r2.<init>(r3)
            r1.f3152d = r2
            java.lang.String r3 = r1.f3150b
            r2.add(r3)
            java.util.HashSet<java.lang.String> r2 = r1.f3152d
            java.lang.String r3 = r1.f3151c
            r2.add(r3)
        L_0x004a:
            java.util.HashSet<java.lang.String> r2 = r1.f3152d
            boolean r2 = r2.add(r5)
            r2 = r2 ^ r0
        L_0x0051:
            if (r2 == 0) goto L_0x006b
            java.lang.Object r0 = r1.f3149a
            lq r1 = new lq
            java.lang.String r2 = "Duplicate field '"
            java.lang.String r3 = "'"
            java.lang.String r5 = p000.C1012kd.m3203l(r2, r5, r3)
            boolean r2 = r0 instanceof p000.C1200mq
            if (r2 == 0) goto L_0x0066
            mq r0 = (p000.C1200mq) r0
            goto L_0x0067
        L_0x0066:
            r0 = 0
        L_0x0067:
            r1.<init>(r5, r0)
            throw r1
        L_0x006b:
            int r5 = r4.f5340b
            if (r5 >= 0) goto L_0x0070
            r0 = 0
        L_0x0070:
            return r0
        L_0x0071:
            r5 = 4
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0979jr.mo4194l(java.lang.String):int");
    }

    /* renamed from: m */
    public int mo4195m() {
        int i = this.f5339a;
        if (i == 2) {
            if (!this.f3472h) {
                return 5;
            }
            this.f3472h = false;
            this.f5340b++;
            return 2;
        } else if (i == 1) {
            int i2 = this.f5340b;
            this.f5340b = i2 + 1;
            return i2 < 0 ? 0 : 1;
        } else {
            int i3 = this.f5340b + 1;
            this.f5340b = i3;
            return i3 == 0 ? 0 : 3;
        }
    }
}
