package p000;

/* renamed from: gz */
public class C0800gz<T> extends C1770sz<T> {
    public C0800gz(Class<?> cls) {
        super(cls, false);
    }

    /* renamed from: f */
    public void mo1481f(T t, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3710E(t.toString());
    }

    /* renamed from: g */
    public void mo1482g(T t, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        C1460pr e = awVar.mo1478e(mqVar, awVar.mo1477d(t, C1692rq.VALUE_EMBEDDED_OBJECT));
        mqVar.mo3710E(t.toString());
        awVar.mo1479f(mqVar, e);
    }
}
