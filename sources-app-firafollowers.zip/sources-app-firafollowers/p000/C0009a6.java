package p000;

import android.os.Handler;
import p000.C0332c6;
import p000.C0534d6;

/* renamed from: a6 */
public class C0009a6 implements C0534d6.C0537c<C0332c6.C0336d> {

    /* renamed from: a */
    public final /* synthetic */ C0329c5 f25a;

    /* renamed from: b */
    public final /* synthetic */ Handler f26b;

    public C0009a6(C0329c5 c5Var, Handler handler) {
        this.f25a = c5Var;
        this.f26b = handler;
    }

    /* renamed from: a */
    public void mo26a(Object obj) {
        C0329c5 c5Var;
        int i;
        C0332c6.C0336d dVar = (C0332c6.C0336d) obj;
        if (dVar == null) {
            c5Var = this.f25a;
            i = 1;
        } else {
            i = dVar.f1458b;
            if (i == 0) {
                this.f25a.mo1845b(dVar.f1457a, this.f26b);
                return;
            }
            c5Var = this.f25a;
        }
        c5Var.mo1844a(i, this.f26b);
    }
}
