package p000;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* renamed from: i3 */
public class C0869i3 {

    /* renamed from: a */
    public static Method f3195a;

    static {
        try {
            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", new Class[]{Rect.class, Rect.class});
            f3195a = declaredMethod;
            if (!declaredMethod.isAccessible()) {
                f3195a.setAccessible(true);
            }
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
        }
    }

    /* renamed from: a */
    public static void m2743a(View view, Rect rect, Rect rect2) {
        Method method = f3195a;
        if (method != null) {
            try {
                method.invoke(view, new Object[]{rect, rect2});
            } catch (Exception e) {
                Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e);
            }
        }
    }

    /* renamed from: b */
    public static boolean m2744b(View view) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        return view.getLayoutDirection() == 1;
    }
}
