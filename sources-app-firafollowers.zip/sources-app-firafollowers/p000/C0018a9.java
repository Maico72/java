package p000;

import android.os.Build;
import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* renamed from: a9 */
public class C0018a9 {

    /* renamed from: a */
    public static final int[] f45a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b */
    public static final C0680f9 f46b = (Build.VERSION.SDK_INT >= 21 ? new C0268b9() : null);

    /* renamed from: c */
    public static final C0680f9 f47c;

    /* renamed from: a9$a */
    public static class C0019a {

        /* renamed from: a */
        public Fragment f48a;

        /* renamed from: b */
        public boolean f49b;

        /* renamed from: c */
        public C0541d8 f50c;

        /* renamed from: d */
        public Fragment f51d;

        /* renamed from: e */
        public boolean f52e;

        /* renamed from: f */
        public C0541d8 f53f;
    }

    static {
        C0680f9 f9Var = null;
        try {
            f9Var = (C0680f9) Class.forName("yb").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
        }
        f47c = f9Var;
    }

    /* renamed from: a */
    public static void m53a(ArrayList<View> arrayList, C2047x3<String, View> x3Var, Collection<String> collection) {
        for (int i = x3Var.f2478f - 1; i >= 0; i--) {
            View l = x3Var.mo3284l(i);
            if (collection.contains(C0010a7.m36i(l))) {
                arrayList.add(l);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0038, code lost:
        if (r6.f672n != false) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0074, code lost:
        r12 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x0086, code lost:
        if (r6.f641B == false) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0088, code lost:
        r12 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x0097  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x00da  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x00eb A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:99:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m54b(p000.C0541d8 r11, p000.C1906v8.C1907a r12, android.util.SparseArray<p000.C0018a9.C0019a> r13, boolean r14, boolean r15) {
        /*
            androidx.fragment.app.Fragment r6 = r12.f6286b
            if (r6 != 0) goto L_0x0005
            return
        L_0x0005:
            int r7 = r6.f684z
            if (r7 != 0) goto L_0x000a
            return
        L_0x000a:
            if (r14 == 0) goto L_0x0013
            int[] r0 = f45a
            int r12 = r12.f6285a
            r12 = r0[r12]
            goto L_0x0015
        L_0x0013:
            int r12 = r12.f6285a
        L_0x0015:
            r0 = 1
            r1 = 0
            if (r12 == r0) goto L_0x007b
            r2 = 3
            if (r12 == r2) goto L_0x0056
            r2 = 4
            if (r12 == r2) goto L_0x003e
            r2 = 5
            if (r12 == r2) goto L_0x002c
            r2 = 6
            if (r12 == r2) goto L_0x0056
            r2 = 7
            if (r12 == r2) goto L_0x007b
            r12 = 0
            r2 = 0
            goto L_0x008c
        L_0x002c:
            if (r15 == 0) goto L_0x003b
            boolean r12 = r6.f653N
            if (r12 == 0) goto L_0x008a
            boolean r12 = r6.f641B
            if (r12 != 0) goto L_0x008a
            boolean r12 = r6.f672n
            if (r12 == 0) goto L_0x008a
            goto L_0x0088
        L_0x003b:
            boolean r12 = r6.f641B
            goto L_0x008b
        L_0x003e:
            if (r15 == 0) goto L_0x004d
            boolean r12 = r6.f653N
            if (r12 == 0) goto L_0x0076
            boolean r12 = r6.f672n
            if (r12 == 0) goto L_0x0076
            boolean r12 = r6.f641B
            if (r12 == 0) goto L_0x0076
            goto L_0x0074
        L_0x004d:
            boolean r12 = r6.f672n
            if (r12 == 0) goto L_0x0076
            boolean r12 = r6.f641B
            if (r12 != 0) goto L_0x0076
            goto L_0x0074
        L_0x0056:
            boolean r12 = r6.f672n
            if (r15 == 0) goto L_0x006e
            if (r12 != 0) goto L_0x0076
            android.view.View r12 = r6.f647H
            if (r12 == 0) goto L_0x0076
            int r12 = r12.getVisibility()
            if (r12 != 0) goto L_0x0076
            float r12 = r6.f654O
            r2 = 0
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 < 0) goto L_0x0076
            goto L_0x0074
        L_0x006e:
            if (r12 == 0) goto L_0x0076
            boolean r12 = r6.f641B
            if (r12 != 0) goto L_0x0076
        L_0x0074:
            r12 = 1
            goto L_0x0077
        L_0x0076:
            r12 = 0
        L_0x0077:
            r8 = r12
            r12 = 1
            r2 = 0
            goto L_0x008f
        L_0x007b:
            if (r15 == 0) goto L_0x0080
            boolean r12 = r6.f652M
            goto L_0x008b
        L_0x0080:
            boolean r12 = r6.f672n
            if (r12 != 0) goto L_0x008a
            boolean r12 = r6.f641B
            if (r12 != 0) goto L_0x008a
        L_0x0088:
            r12 = 1
            goto L_0x008b
        L_0x008a:
            r12 = 0
        L_0x008b:
            r2 = 1
        L_0x008c:
            r1 = r12
            r12 = 0
            r8 = 0
        L_0x008f:
            java.lang.Object r3 = r13.get(r7)
            a9$a r3 = (p000.C0018a9.C0019a) r3
            if (r1 == 0) goto L_0x00a8
            if (r3 != 0) goto L_0x00a2
            a9$a r1 = new a9$a
            r1.<init>()
            r13.put(r7, r1)
            r3 = r1
        L_0x00a2:
            r3.f48a = r6
            r3.f49b = r14
            r3.f50c = r11
        L_0x00a8:
            r9 = r3
            r10 = 0
            if (r15 != 0) goto L_0x00d0
            if (r2 == 0) goto L_0x00d0
            if (r9 == 0) goto L_0x00b6
            androidx.fragment.app.Fragment r1 = r9.f51d
            if (r1 != r6) goto L_0x00b6
            r9.f51d = r10
        L_0x00b6:
            n8 r1 = r11.f2196q
            int r2 = r6.f662d
            if (r2 >= r0) goto L_0x00d0
            int r2 = r1.f4229r
            if (r2 < r0) goto L_0x00d0
            boolean r0 = r11.f6284p
            if (r0 != 0) goto L_0x00d0
            r1.mo4769c0(r6)
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 0
            r0 = r1
            r1 = r6
            r0.mo4775g0(r1, r2, r3, r4, r5)
        L_0x00d0:
            if (r8 == 0) goto L_0x00e9
            if (r9 == 0) goto L_0x00d8
            androidx.fragment.app.Fragment r0 = r9.f51d
            if (r0 != 0) goto L_0x00e9
        L_0x00d8:
            if (r9 != 0) goto L_0x00e3
            a9$a r0 = new a9$a
            r0.<init>()
            r13.put(r7, r0)
            r9 = r0
        L_0x00e3:
            r9.f51d = r6
            r9.f52e = r14
            r9.f53f = r11
        L_0x00e9:
            if (r15 != 0) goto L_0x00f5
            if (r12 == 0) goto L_0x00f5
            if (r9 == 0) goto L_0x00f5
            androidx.fragment.app.Fragment r11 = r9.f48a
            if (r11 != r6) goto L_0x00f5
            r9.f48a = r10
        L_0x00f5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0018a9.m54b(d8, v8$a, android.util.SparseArray, boolean, boolean):void");
    }

    /* renamed from: c */
    public static void m55c(Fragment fragment, Fragment fragment2, boolean z, C2047x3<String, View> x3Var, boolean z2) {
        if (z) {
            fragment2.mo819n();
        } else {
            fragment.mo819n();
        }
    }

    /* renamed from: d */
    public static boolean m56d(C0680f9 f9Var, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!f9Var.mo1666e(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: e */
    public static C2047x3<String, View> m57e(C0680f9 f9Var, C2047x3<String, String> x3Var, Object obj, C0019a aVar) {
        ArrayList<String> arrayList;
        Fragment fragment = aVar.f48a;
        View view = fragment.f647H;
        if (x3Var.isEmpty() || obj == null || view == null) {
            x3Var.clear();
            return null;
        }
        C2047x3<String, View> x3Var2 = new C2047x3<>();
        f9Var.mo3545i(x3Var2, view);
        C0541d8 d8Var = aVar.f50c;
        if (aVar.f49b) {
            arrayList = d8Var.f6282n;
        } else {
            fragment.mo819n();
            arrayList = d8Var.f6283o;
        }
        if (arrayList != null) {
            C0526d4.m1687k(x3Var2, arrayList);
            C0526d4.m1687k(x3Var2, x3Var.values());
        }
        int i = x3Var.f2478f;
        while (true) {
            i--;
            if (i < 0) {
                return x3Var2;
            }
            if (!x3Var2.containsKey(x3Var.mo3284l(i))) {
                x3Var.mo3282j(i);
            }
        }
    }

    /* renamed from: f */
    public static C2047x3<String, View> m58f(C0680f9 f9Var, C2047x3<String, String> x3Var, Object obj, C0019a aVar) {
        ArrayList<String> arrayList;
        if (x3Var.isEmpty() || obj == null) {
            x3Var.clear();
            return null;
        }
        Fragment fragment = aVar.f51d;
        C2047x3<String, View> x3Var2 = new C2047x3<>();
        f9Var.mo3545i(x3Var2, fragment.mo800Y());
        C0541d8 d8Var = aVar.f53f;
        if (aVar.f52e) {
            fragment.mo819n();
            arrayList = d8Var.f6283o;
        } else {
            arrayList = d8Var.f6282n;
        }
        C0526d4.m1687k(x3Var2, arrayList);
        C0526d4.m1687k(x3Var, x3Var2.keySet());
        return x3Var2;
    }

    /* renamed from: g */
    public static C0680f9 m59g(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            fragment.mo820o();
            Object v = fragment.mo831v();
            if (v != null) {
                arrayList.add(v);
            }
            Object x = fragment.mo833x();
            if (x != null) {
                arrayList.add(x);
            }
        }
        if (fragment2 != null) {
            fragment2.mo818m();
            Object t = fragment2.mo828t();
            if (t != null) {
                arrayList.add(t);
            }
            fragment2.mo832w();
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        C0680f9 f9Var = f46b;
        if (f9Var != null && m56d(f9Var, arrayList)) {
            return f9Var;
        }
        C0680f9 f9Var2 = f47c;
        if (f9Var2 != null && m56d(f9Var2, arrayList)) {
            return f9Var2;
        }
        if (f9Var == null && f9Var2 == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    /* renamed from: h */
    public static ArrayList<View> m60h(C0680f9 f9Var, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = fragment.f647H;
        if (view2 != null) {
            f9Var.mo3544f(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        f9Var.mo1664b(obj, arrayList2);
        return arrayList2;
    }

    /* renamed from: i */
    public static Object m61i(C0680f9 f9Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.mo828t();
        } else {
            fragment.mo818m();
        }
        return f9Var.mo1667g(obj);
    }

    /* renamed from: j */
    public static Object m62j(C0680f9 f9Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.mo831v();
        } else {
            fragment.mo820o();
        }
        return f9Var.mo1667g(obj);
    }

    /* renamed from: k */
    public static View m63k(C2047x3<String, View> x3Var, C0019a aVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        C0541d8 d8Var = aVar.f50c;
        if (obj == null || x3Var == null || (arrayList = d8Var.f6282n) == null || arrayList.isEmpty()) {
            return null;
        }
        return x3Var.get((z ? d8Var.f6282n : d8Var.f6283o).get(0));
    }

    /* renamed from: l */
    public static Object m64l(C0680f9 f9Var, Fragment fragment, Fragment fragment2, boolean z) {
        Object obj;
        if (z) {
            obj = fragment2.mo833x();
        } else {
            fragment.mo832w();
            obj = null;
        }
        return f9Var.mo1677u(f9Var.mo1667g(obj));
    }

    /* renamed from: m */
    public static void m65m(C0680f9 f9Var, Object obj, Object obj2, C2047x3<String, View> x3Var, boolean z, C0541d8 d8Var) {
        ArrayList<String> arrayList = d8Var.f6282n;
        if (arrayList != null && !arrayList.isEmpty()) {
            View view = x3Var.get((z ? d8Var.f6283o : d8Var.f6282n).get(0));
            f9Var.mo1674r(obj, view);
            if (obj2 != null) {
                f9Var.mo1674r(obj2, view);
            }
        }
    }

    /* renamed from: n */
    public static void m66n(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                arrayList.get(size).setVisibility(i);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r3v8, types: [android.view.View] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x03ef  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0431 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0210 A[ADDED_TO_REGION] */
    /* renamed from: o */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m67o(p000.C1230n8 r38, java.util.ArrayList<p000.C0541d8> r39, java.util.ArrayList<java.lang.Boolean> r40, int r41, int r42, boolean r43) {
        /*
            r0 = r38
            r1 = r39
            r2 = r40
            r3 = r42
            r4 = r43
            int r5 = r0.f4229r
            r6 = 1
            if (r5 >= r6) goto L_0x0010
            return
        L_0x0010:
            android.util.SparseArray r5 = new android.util.SparseArray
            r5.<init>()
            r7 = r41
        L_0x0017:
            r8 = 0
            if (r7 >= r3) goto L_0x0068
            java.lang.Object r9 = r1.get(r7)
            d8 r9 = (p000.C0541d8) r9
            java.lang.Object r10 = r2.get(r7)
            java.lang.Boolean r10 = (java.lang.Boolean) r10
            boolean r10 = r10.booleanValue()
            if (r10 == 0) goto L_0x004e
            n8 r8 = r9.f2196q
            i8 r8 = r8.f4231t
            boolean r8 = r8.mo3762e()
            if (r8 != 0) goto L_0x0037
            goto L_0x0065
        L_0x0037:
            java.util.ArrayList<v8$a> r8 = r9.f6269a
            int r8 = r8.size()
            int r8 = r8 - r6
        L_0x003e:
            if (r8 < 0) goto L_0x0065
            java.util.ArrayList<v8$a> r10 = r9.f6269a
            java.lang.Object r10 = r10.get(r8)
            v8$a r10 = (p000.C1906v8.C1907a) r10
            m54b(r9, r10, r5, r6, r4)
            int r8 = r8 + -1
            goto L_0x003e
        L_0x004e:
            java.util.ArrayList<v8$a> r10 = r9.f6269a
            int r10 = r10.size()
            r11 = 0
        L_0x0055:
            if (r11 >= r10) goto L_0x0065
            java.util.ArrayList<v8$a> r12 = r9.f6269a
            java.lang.Object r12 = r12.get(r11)
            v8$a r12 = (p000.C1906v8.C1907a) r12
            m54b(r9, r12, r5, r8, r4)
            int r11 = r11 + 1
            goto L_0x0055
        L_0x0065:
            int r7 = r7 + 1
            goto L_0x0017
        L_0x0068:
            int r7 = r5.size()
            if (r7 == 0) goto L_0x0445
            android.view.View r7 = new android.view.View
            l8 r9 = r0.f4230s
            android.content.Context r9 = r9.f3848e
            r7.<init>(r9)
            int r15 = r5.size()
            r14 = 0
        L_0x007c:
            if (r14 >= r15) goto L_0x0445
            int r9 = r5.keyAt(r14)
            x3 r13 = new x3
            r13.<init>()
            int r10 = r3 + -1
            r12 = r41
        L_0x008b:
            if (r10 < r12) goto L_0x00f2
            java.lang.Object r11 = r1.get(r10)
            d8 r11 = (p000.C0541d8) r11
            boolean r16 = r11.mo2966j(r9)
            if (r16 != 0) goto L_0x009a
            goto L_0x00e7
        L_0x009a:
            java.lang.Object r16 = r2.get(r10)
            java.lang.Boolean r16 = (java.lang.Boolean) r16
            boolean r16 = r16.booleanValue()
            java.util.ArrayList<java.lang.String> r6 = r11.f6282n
            if (r6 == 0) goto L_0x00e7
            int r6 = r6.size()
            java.util.ArrayList<java.lang.String> r8 = r11.f6282n
            java.util.ArrayList<java.lang.String> r11 = r11.f6283o
            if (r16 == 0) goto L_0x00b3
            goto L_0x00b8
        L_0x00b3:
            r37 = r11
            r11 = r8
            r8 = r37
        L_0x00b8:
            r1 = 0
        L_0x00b9:
            if (r1 >= r6) goto L_0x00e7
            java.lang.Object r16 = r11.get(r1)
            r2 = r16
            java.lang.String r2 = (java.lang.String) r2
            java.lang.Object r16 = r8.get(r1)
            r3 = r16
            java.lang.String r3 = (java.lang.String) r3
            java.lang.Object r16 = r13.remove(r3)
            r17 = r6
            r6 = r16
            java.lang.String r6 = (java.lang.String) r6
            if (r6 == 0) goto L_0x00db
            r13.put(r2, r6)
            goto L_0x00de
        L_0x00db:
            r13.put(r2, r3)
        L_0x00de:
            int r1 = r1 + 1
            r2 = r40
            r3 = r42
            r6 = r17
            goto L_0x00b9
        L_0x00e7:
            int r10 = r10 + -1
            r1 = r39
            r2 = r40
            r3 = r42
            r6 = 1
            r8 = 0
            goto L_0x008b
        L_0x00f2:
            java.lang.Object r1 = r5.valueAt(r14)
            a9$a r1 = (p000.C0018a9.C0019a) r1
            if (r4 == 0) goto L_0x02d3
            i8 r3 = r0.f4231t
            boolean r3 = r3.mo3762e()
            if (r3 == 0) goto L_0x010b
            i8 r3 = r0.f4231t
            android.view.View r3 = r3.mo3761b(r9)
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            goto L_0x010c
        L_0x010b:
            r3 = 0
        L_0x010c:
            if (r3 != 0) goto L_0x010f
            goto L_0x0119
        L_0x010f:
            androidx.fragment.app.Fragment r6 = r1.f48a
            androidx.fragment.app.Fragment r8 = r1.f51d
            f9 r9 = m59g(r8, r6)
            if (r9 != 0) goto L_0x0122
        L_0x0119:
            r31 = r5
            r32 = r14
            r33 = r15
        L_0x011f:
            r0 = 0
            goto L_0x02d0
        L_0x0122:
            boolean r10 = r1.f49b
            boolean r11 = r1.f52e
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.lang.Object r10 = m61i(r9, r6, r10)
            java.lang.Object r11 = m62j(r9, r8, r11)
            r31 = r5
            androidx.fragment.app.Fragment r5 = r1.f48a
            androidx.fragment.app.Fragment r12 = r1.f51d
            r32 = r14
            if (r5 == 0) goto L_0x014d
            android.view.View r14 = r5.mo800Y()
            r33 = r15
            r15 = 0
            r14.setVisibility(r15)
            goto L_0x014f
        L_0x014d:
            r33 = r15
        L_0x014f:
            if (r5 == 0) goto L_0x01eb
            if (r12 != 0) goto L_0x0155
            goto L_0x01eb
        L_0x0155:
            boolean r14 = r1.f49b
            boolean r15 = r13.isEmpty()
            if (r15 == 0) goto L_0x015f
            r15 = 0
            goto L_0x0163
        L_0x015f:
            java.lang.Object r15 = m64l(r9, r5, r12, r14)
        L_0x0163:
            x3 r0 = m58f(r9, r13, r15, r1)
            r34 = r6
            x3 r6 = m57e(r9, r13, r15, r1)
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x017f
            if (r0 == 0) goto L_0x0178
            r0.clear()
        L_0x0178:
            if (r6 == 0) goto L_0x017d
            r6.clear()
        L_0x017d:
            r15 = 0
            goto L_0x0191
        L_0x017f:
            r16 = r15
            java.util.Set r15 = r13.keySet()
            m53a(r4, r0, r15)
            java.util.Collection r15 = r13.values()
            m53a(r2, r6, r15)
            r15 = r16
        L_0x0191:
            if (r10 != 0) goto L_0x019a
            if (r11 != 0) goto L_0x019a
            if (r15 != 0) goto L_0x019a
            r36 = r2
            goto L_0x01ef
        L_0x019a:
            r35 = r13
            r13 = 1
            m55c(r5, r12, r14, r0, r13)
            if (r15 == 0) goto L_0x01d0
            r2.add(r7)
            r9.mo1675s(r15, r7, r4)
            boolean r13 = r1.f52e
            r36 = r2
            d8 r2 = r1.f53f
            r16 = r9
            r17 = r15
            r18 = r11
            r19 = r0
            r20 = r13
            r21 = r2
            m65m(r16, r17, r18, r19, r20, r21)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            android.view.View r1 = m63k(r6, r1, r10, r14)
            if (r1 == 0) goto L_0x01cb
            r9.mo1673q(r10, r0)
        L_0x01cb:
            r29 = r0
            r27 = r1
            goto L_0x01d6
        L_0x01d0:
            r36 = r2
            r27 = 0
            r29 = 0
        L_0x01d6:
            y8 r0 = new y8
            r22 = r0
            r23 = r5
            r24 = r12
            r25 = r14
            r26 = r6
            r28 = r9
            r22.<init>(r23, r24, r25, r26, r27, r28, r29)
            p000.C2117y6.m5794a(r3, r0)
            goto L_0x01f2
        L_0x01eb:
            r36 = r2
            r34 = r6
        L_0x01ef:
            r35 = r13
            r15 = 0
        L_0x01f2:
            if (r10 != 0) goto L_0x01fa
            if (r15 != 0) goto L_0x01fa
            if (r11 != 0) goto L_0x01fa
            goto L_0x011f
        L_0x01fa:
            java.util.ArrayList r0 = m60h(r9, r11, r8, r4, r7)
            r1 = r34
            r2 = r36
            java.util.ArrayList r1 = m60h(r9, r10, r1, r2, r7)
            r5 = 4
            m66n(r1, r5)
            java.lang.Object r5 = r9.mo1668l(r11, r10, r15)
            if (r5 == 0) goto L_0x011f
            if (r8 == 0) goto L_0x0233
            if (r11 == 0) goto L_0x0233
            boolean r6 = r8.f672n
            if (r6 == 0) goto L_0x0233
            boolean r6 = r8.f641B
            if (r6 == 0) goto L_0x0233
            boolean r6 = r8.f653N
            if (r6 == 0) goto L_0x0233
            r6 = 1
            r8.mo804c0(r6)
            android.view.View r6 = r8.f647H
            r9.mo1671o(r11, r6, r0)
            android.view.ViewGroup r6 = r8.f646G
            w8 r8 = new w8
            r8.<init>(r0)
            p000.C2117y6.m5794a(r6, r8)
        L_0x0233:
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            int r8 = r2.size()
            r12 = 0
        L_0x023d:
            if (r12 >= r8) goto L_0x0253
            java.lang.Object r13 = r2.get(r12)
            android.view.View r13 = (android.view.View) r13
            java.lang.String r14 = p000.C0010a7.m36i(r13)
            r6.add(r14)
            r14 = 0
            p000.C0010a7.m46s(r13, r14)
            int r12 = r12 + 1
            goto L_0x023d
        L_0x0253:
            r22 = r9
            r23 = r5
            r24 = r10
            r25 = r1
            r26 = r11
            r27 = r0
            r28 = r15
            r29 = r2
            r22.mo1672p(r23, r24, r25, r26, r27, r28, r29)
            r9.mo1665c(r3, r5)
            int r0 = r2.size()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            r8 = 0
        L_0x0273:
            if (r8 >= r0) goto L_0x02b3
            java.lang.Object r10 = r4.get(r8)
            android.view.View r10 = (android.view.View) r10
            java.lang.String r11 = p000.C0010a7.m36i(r10)
            r5.add(r11)
            if (r11 != 0) goto L_0x0287
            r13 = r35
            goto L_0x02ae
        L_0x0287:
            r14 = 0
            p000.C0010a7.m46s(r10, r14)
            r13 = r35
            java.lang.Object r10 = r13.getOrDefault(r11, r14)
            java.lang.String r10 = (java.lang.String) r10
            r12 = 0
        L_0x0294:
            if (r12 >= r0) goto L_0x02ae
            java.lang.Object r14 = r6.get(r12)
            boolean r14 = r10.equals(r14)
            if (r14 == 0) goto L_0x02aa
            java.lang.Object r10 = r2.get(r12)
            android.view.View r10 = (android.view.View) r10
            p000.C0010a7.m46s(r10, r11)
            goto L_0x02ae
        L_0x02aa:
            int r12 = r12 + 1
            r14 = 0
            goto L_0x0294
        L_0x02ae:
            int r8 = r8 + 1
            r35 = r13
            goto L_0x0273
        L_0x02b3:
            c9 r8 = new c9
            r22 = r8
            r23 = r9
            r24 = r0
            r25 = r2
            r26 = r6
            r27 = r4
            r28 = r5
            r22.<init>(r23, r24, r25, r26, r27, r28)
            p000.C2117y6.m5794a(r3, r8)
            r0 = 0
            m66n(r1, r0)
            r9.mo1676t(r15, r4, r2)
        L_0x02d0:
            r2 = r38
            goto L_0x02fc
        L_0x02d3:
            r2 = r0
            r31 = r5
            r32 = r14
            r33 = r15
            r0 = 0
            i8 r3 = r2.f4231t
            boolean r3 = r3.mo3762e()
            if (r3 == 0) goto L_0x02ee
            i8 r3 = r2.f4231t
            android.view.View r3 = r3.mo3761b(r9)
            r14 = r3
            android.view.ViewGroup r14 = (android.view.ViewGroup) r14
            r3 = r14
            goto L_0x02ef
        L_0x02ee:
            r3 = 0
        L_0x02ef:
            if (r3 != 0) goto L_0x02f2
            goto L_0x02fc
        L_0x02f2:
            androidx.fragment.app.Fragment r4 = r1.f48a
            androidx.fragment.app.Fragment r5 = r1.f51d
            f9 r6 = m59g(r5, r4)
            if (r6 != 0) goto L_0x0302
        L_0x02fc:
            r1 = r32
            r29 = r33
            goto L_0x0431
        L_0x0302:
            boolean r8 = r1.f49b
            boolean r9 = r1.f52e
            java.lang.Object r8 = m61i(r6, r4, r8)
            java.lang.Object r12 = m62j(r6, r5, r9)
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            androidx.fragment.app.Fragment r9 = r1.f48a
            androidx.fragment.app.Fragment r15 = r1.f51d
            if (r9 == 0) goto L_0x03ba
            if (r15 != 0) goto L_0x0322
            goto L_0x03ba
        L_0x0322:
            boolean r14 = r1.f49b
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x032c
            r0 = 0
            goto L_0x0332
        L_0x032c:
            java.lang.Object r16 = m64l(r6, r9, r15, r14)
            r0 = r16
        L_0x0332:
            x3 r2 = m58f(r6, r13, r0, r1)
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x033e
            r0 = 0
            goto L_0x0349
        L_0x033e:
            r16 = r0
            java.util.Collection r0 = r2.values()
            r11.addAll(r0)
            r0 = r16
        L_0x0349:
            if (r8 != 0) goto L_0x0351
            if (r12 != 0) goto L_0x0351
            if (r0 != 0) goto L_0x0351
            goto L_0x03ba
        L_0x0351:
            r22 = r4
            r4 = 1
            m55c(r9, r15, r14, r2, r4)
            if (r0 == 0) goto L_0x0380
            android.graphics.Rect r4 = new android.graphics.Rect
            r4.<init>()
            r6.mo1675s(r0, r7, r11)
            r20 = r9
            boolean r9 = r1.f52e
            r21 = r10
            d8 r10 = r1.f53f
            r23 = r14
            r14 = r6
            r24 = r15
            r15 = r0
            r16 = r12
            r17 = r2
            r18 = r9
            r19 = r10
            m65m(r14, r15, r16, r17, r18, r19)
            if (r8 == 0) goto L_0x0389
            r6.mo1673q(r8, r4)
            goto L_0x0389
        L_0x0380:
            r20 = r9
            r21 = r10
            r23 = r14
            r24 = r15
            r4 = 0
        L_0x0389:
            z8 r2 = new z8
            r16 = r20
            r9 = r2
            r15 = r21
            r10 = r6
            r14 = r11
            r11 = r13
            r25 = r5
            r5 = r12
            r12 = r0
            r26 = r0
            r0 = r13
            r13 = r1
            r27 = r14
            r1 = r32
            r28 = 0
            r14 = r15
            r30 = r15
            r29 = r33
            r15 = r7
            r17 = r24
            r18 = r23
            r19 = r27
            r20 = r8
            r21 = r4
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21)
            p000.C2117y6.m5794a(r3, r2)
            r2 = r26
            goto L_0x03cc
        L_0x03ba:
            r22 = r4
            r25 = r5
            r30 = r10
            r27 = r11
            r5 = r12
            r0 = r13
            r1 = r32
            r29 = r33
            r28 = 0
            r2 = r28
        L_0x03cc:
            if (r8 != 0) goto L_0x03d4
            if (r2 != 0) goto L_0x03d4
            if (r5 != 0) goto L_0x03d4
            goto L_0x0431
        L_0x03d4:
            r4 = r25
            r9 = r27
            java.util.ArrayList r4 = m60h(r6, r5, r4, r9, r7)
            if (r4 == 0) goto L_0x03e4
            boolean r9 = r4.isEmpty()
            if (r9 == 0) goto L_0x03e6
        L_0x03e4:
            r5 = r28
        L_0x03e6:
            r6.mo1663a(r8, r7)
            java.lang.Object r13 = r6.mo1668l(r5, r8, r2)
            if (r13 == 0) goto L_0x0431
            java.util.ArrayList r23 = new java.util.ArrayList
            r23.<init>()
            r14 = r6
            r15 = r13
            r16 = r8
            r17 = r23
            r18 = r5
            r19 = r4
            r20 = r2
            r21 = r30
            r14.mo1672p(r15, r16, r17, r18, r19, r20, r21)
            x8 r2 = new x8
            r9 = r2
            r10 = r8
            r11 = r6
            r12 = r7
            r8 = r13
            r13 = r22
            r14 = r30
            r15 = r23
            r16 = r4
            r17 = r5
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17)
            p000.C2117y6.m5794a(r3, r2)
            d9 r2 = new d9
            r4 = r30
            r2.<init>(r6, r4, r0)
            p000.C2117y6.m5794a(r3, r2)
            r6.mo1665c(r3, r8)
            e9 r2 = new e9
            r2.<init>(r6, r4, r0)
            p000.C2117y6.m5794a(r3, r2)
        L_0x0431:
            int r14 = r1 + 1
            r0 = r38
            r1 = r39
            r2 = r40
            r3 = r42
            r4 = r43
            r15 = r29
            r5 = r31
            r6 = 1
            r8 = 0
            goto L_0x007c
        L_0x0445:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0018a9.m67o(n8, java.util.ArrayList, java.util.ArrayList, int, int, boolean):void");
    }
}
