package p000;

import java.util.Objects;
import java.util.Set;
import p000.C0576dp;
import p000.C1203ms;

/* renamed from: fy */
public abstract class C0724fy extends C1770sz<Object> implements C2100xw, C0517cx {

    /* renamed from: n */
    public static final C1700rw[] f2789n = new C1700rw[0];

    /* renamed from: f */
    public final C1035ks f2790f;

    /* renamed from: g */
    public final C1700rw[] f2791g;

    /* renamed from: h */
    public final C1700rw[] f2792h;

    /* renamed from: i */
    public final C1467pw f2793i;

    /* renamed from: j */
    public final Object f2794j;

    /* renamed from: k */
    public final C1887uu f2795k;

    /* renamed from: l */
    public final C1638qx f2796l;

    /* renamed from: m */
    public final C0576dp.C0579c f2797m;

    static {
        new C1957vs("#object-ref");
    }

    public C0724fy(C0724fy fyVar, C1638qx qxVar, Object obj) {
        super(fyVar.f5804d);
        this.f2790f = fyVar.f2790f;
        this.f2791g = fyVar.f2791g;
        this.f2792h = fyVar.f2792h;
        this.f2795k = fyVar.f2795k;
        this.f2793i = fyVar.f2793i;
        this.f2796l = qxVar;
        this.f2794j = obj;
        this.f2797m = fyVar.f2797m;
    }

    public C0724fy(C0724fy fyVar, C1700rw[] rwVarArr, C1700rw[] rwVarArr2) {
        super(fyVar.f5804d);
        this.f2790f = fyVar.f2790f;
        this.f2791g = rwVarArr;
        this.f2792h = rwVarArr2;
        this.f2795k = fyVar.f2795k;
        this.f2793i = fyVar.f2793i;
        this.f2796l = fyVar.f2796l;
        this.f2794j = fyVar.f2794j;
        this.f2797m = fyVar.f2797m;
    }

    public C0724fy(C1035ks ksVar, C1832tw twVar, C1700rw[] rwVarArr, C1700rw[] rwVarArr2) {
        super(ksVar);
        this.f2790f = ksVar;
        this.f2791g = rwVarArr;
        this.f2792h = rwVarArr2;
        C0576dp.C0579c cVar = null;
        if (twVar == null) {
            this.f2795k = null;
            this.f2793i = null;
            this.f2794j = null;
            this.f2796l = null;
        } else {
            this.f2795k = twVar.f6065g;
            this.f2793i = twVar.f6063e;
            this.f2794j = twVar.f6064f;
            this.f2796l = twVar.f6066h;
            cVar = twVar.f6059a.mo2811a((C0576dp.C0580d) null).f2342e;
        }
        this.f2797m = cVar;
    }

    /* renamed from: t */
    public static final C1700rw[] m2332t(C1700rw[] rwVarArr, b10 b10) {
        if (rwVarArr == null || rwVarArr.length == 0 || b10 == null || b10 == b10.f1179d) {
            return rwVarArr;
        }
        int length = rwVarArr.length;
        C1700rw[] rwVarArr2 = new C1700rw[length];
        for (int i = 0; i < length; i++) {
            C1700rw rwVar = rwVarArr[i];
            if (rwVar != null) {
                rwVarArr2[i] = rwVar.mo4361i(b10);
            }
        }
        return rwVarArr2;
    }

    /* JADX WARNING: type inference failed for: r12v7, types: [rx, dq] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00ae  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0172  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0178  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x01a1  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x01d2  */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x01d8  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x01de  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x01e3 A[RETURN] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<?> mo2818a(p000.C0221at r21, p000.C0714fs r22) {
        /*
            r20 = this;
            r0 = r20
            r1 = r21
            r9 = r22
            ds r2 = r21.mo1464w()
            r3 = 0
            if (r9 == 0) goto L_0x0015
            if (r2 != 0) goto L_0x0010
            goto L_0x0015
        L_0x0010:
            uu r4 = r22.mo3644a()
            goto L_0x0016
        L_0x0015:
            r4 = r3
        L_0x0016:
            ys r5 = r1.f1134d
            java.lang.Class<T> r6 = r0.f5804d
            dp$d r6 = r0.mo5883l(r1, r9, r6)
            r7 = 0
            r8 = 1
            if (r6 == 0) goto L_0x00a9
            dp$c r10 = r6.f2342e
            dp$c r11 = p000.C0576dp.C0579c.ANY
            if (r10 == r11) goto L_0x002a
            r12 = 1
            goto L_0x002b
        L_0x002a:
            r12 = 0
        L_0x002b:
            if (r12 == 0) goto L_0x00a9
            if (r10 == r11) goto L_0x00aa
            dp$c r11 = r0.f2797m
            if (r10 == r11) goto L_0x00aa
            ks r11 = r0.f2790f
            boolean r11 = r11.mo4347x()
            if (r11 == 0) goto L_0x0067
            int r11 = r10.ordinal()
            r12 = 5
            if (r11 == r12) goto L_0x004a
            r12 = 7
            if (r11 == r12) goto L_0x004a
            r12 = 8
            if (r11 == r12) goto L_0x004a
            goto L_0x00aa
        L_0x004a:
            ks r2 = r0.f2790f
            r5.mo5869k(r2)
            ks r2 = r0.f2790f
            java.lang.Class<?> r2 = r2.f3696d
            ys r4 = r1.f1134d
            u00 r4 = p000.u00.m5235a(r4, r2)
            java.lang.Boolean r2 = p000.C1374oy.m4222p(r2, r6, r8, r3)
            oy r3 = new oy
            r3.<init>(r4, r2)
            ps r1 = r1.mo1467z(r3, r9)
            return r1
        L_0x0067:
            dp$c r6 = p000.C0576dp.C0579c.NATURAL
            if (r10 != r6) goto L_0x00aa
            ks r6 = r0.f2790f
            boolean r6 = r6.mo3423A()
            if (r6 == 0) goto L_0x007e
            java.lang.Class<java.util.Map> r6 = java.util.Map.class
            java.lang.Class<T> r11 = r0.f5804d
            boolean r6 = r6.isAssignableFrom(r11)
            if (r6 == 0) goto L_0x007e
            goto L_0x00aa
        L_0x007e:
            java.lang.Class<java.util.Map$Entry> r6 = java.util.Map.Entry.class
            java.lang.Class<T> r11 = r0.f5804d
            boolean r6 = r6.isAssignableFrom(r11)
            if (r6 == 0) goto L_0x00aa
            ks r2 = r0.f2790f
            java.lang.Class<java.util.Map$Entry> r3 = java.util.Map.Entry.class
            ks r2 = r2.mo4342i(r3)
            ks r4 = r2.mo4340h(r7)
            ks r5 = r2.mo4340h(r8)
            px r10 = new px
            ks r3 = r0.f2790f
            r6 = 0
            r7 = 0
            r2 = r10
            r8 = r22
            r2.<init>(r3, r4, r5, r6, r7, r8)
            ps r1 = r1.mo1467z(r10, r9)
            return r1
        L_0x00a9:
            r10 = r3
        L_0x00aa:
            qx r6 = r0.f2796l
            if (r4 == 0) goto L_0x0172
            ip$a r11 = r2.mo3155x(r5, r4)
            java.util.Set r11 = r11.mo4082c()
            lp$a r5 = r2.mo3100A(r5, r4)
            java.util.Set<java.lang.String> r5 = r5.f3926d
            mv r12 = r2.mo3149r(r4)
            if (r12 != 0) goto L_0x00ec
            if (r6 == 0) goto L_0x015e
            mv r12 = r2.mo3150s(r4, r3)
            if (r12 == 0) goto L_0x015e
            qx r6 = r0.f2796l
            boolean r12 = r12.f4130e
            boolean r13 = r6.f5360e
            if (r12 != r13) goto L_0x00d4
            goto L_0x015e
        L_0x00d4:
            qx r19 = new qx
            ks r14 = r6.f5356a
            uq r15 = r6.f5357b
            dq<?> r13 = r6.f5358c
            ps<java.lang.Object> r6 = r6.f5359d
            r16 = r13
            r13 = r19
            r17 = r6
            r18 = r12
            r13.<init>(r14, r15, r16, r17, r18)
            r6 = r19
            goto L_0x015e
        L_0x00ec:
            mv r6 = r2.mo3150s(r4, r12)
            java.lang.Class<? extends dq<?>> r12 = r6.f4127b
            ks r13 = r1.mo3828b(r12)
            n00 r14 = r21.mo1447d()
            java.lang.Class<dq> r15 = p000.C0581dq.class
            ks[] r13 = r14.mo4669i(r13, r15)
            r13 = r13[r7]
            java.lang.Class<fq> r14 = p000.C0712fq.class
            if (r12 != r14) goto L_0x0152
            vs r12 = r6.f4126a
            java.lang.String r12 = r12.f6424d
            rw[] r13 = r0.f2791g
            int r14 = r13.length
            r13 = 0
        L_0x010e:
            if (r13 != r14) goto L_0x0132
            ks r2 = r0.f2790f
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            java.lang.Class<T> r5 = r0.f5804d
            java.lang.String r5 = p000.s00.m4869u(r5)
            r4[r7] = r5
            if (r12 != 0) goto L_0x0122
            java.lang.String r5 = "[null]"
            goto L_0x0126
        L_0x0122:
            java.lang.String r5 = p000.s00.m4851c(r12)
        L_0x0126:
            r4[r8] = r5
            java.lang.String r5 = "Invalid Object Id definition for %s: cannot find property with name %s"
            java.lang.String r4 = java.lang.String.format(r5, r4)
            r1.mo1448f(r2, r4)
            throw r3
        L_0x0132:
            rw[] r15 = r0.f2791g
            r15 = r15[r13]
            gr r7 = r15.f5617e
            java.lang.String r7 = r7.f2986d
            boolean r7 = r12.equals(r7)
            if (r7 == 0) goto L_0x014e
            ks r7 = r15.f5619g
            rx r12 = new rx
            r12.<init>((p000.C1208mv) r6, (p000.C1700rw) r15)
            boolean r6 = r6.f4130e
            qx r6 = p000.C1638qx.m4683a(r7, r3, r12, r6)
            goto L_0x015f
        L_0x014e:
            int r13 = r13 + 1
            r7 = 0
            goto L_0x010e
        L_0x0152:
            dq r7 = r1.mo3830e(r4, r6)
            vs r12 = r6.f4126a
            boolean r6 = r6.f4130e
            qx r6 = p000.C1638qx.m4683a(r13, r12, r7, r6)
        L_0x015e:
            r13 = 0
        L_0x015f:
            java.lang.Object r2 = r2.mo3138g(r4)
            if (r2 == 0) goto L_0x0170
            java.lang.Object r4 = r0.f2794j
            if (r4 == 0) goto L_0x0176
            boolean r4 = r2.equals(r4)
            if (r4 != 0) goto L_0x0170
            goto L_0x0176
        L_0x0170:
            r2 = r3
            goto L_0x0176
        L_0x0172:
            r2 = r3
            r5 = r2
            r11 = r5
            r13 = 0
        L_0x0176:
            if (r13 <= 0) goto L_0x01a1
            rw[] r4 = r0.f2791g
            int r7 = r4.length
            java.lang.Object[] r4 = java.util.Arrays.copyOf(r4, r7)
            rw[] r4 = (p000.C1700rw[]) r4
            r7 = r4[r13]
            r12 = 0
            java.lang.System.arraycopy(r4, r12, r4, r8, r13)
            r4[r12] = r7
            rw[] r7 = r0.f2792h
            if (r7 != 0) goto L_0x018e
            goto L_0x019c
        L_0x018e:
            int r3 = r7.length
            java.lang.Object[] r3 = java.util.Arrays.copyOf(r7, r3)
            rw[] r3 = (p000.C1700rw[]) r3
            r7 = r3[r13]
            java.lang.System.arraycopy(r3, r12, r3, r8, r13)
            r3[r12] = r7
        L_0x019c:
            fy r3 = r0.mo1489y(r4, r3)
            goto L_0x01a2
        L_0x01a1:
            r3 = r0
        L_0x01a2:
            if (r6 == 0) goto L_0x01c2
            ks r4 = r6.f5356a
            ps r16 = r1.mo1462u(r4, r9)
            qx r1 = new qx
            ks r13 = r6.f5356a
            uq r14 = r6.f5357b
            dq<?> r15 = r6.f5358c
            boolean r4 = r6.f5360e
            r12 = r1
            r17 = r4
            r12.<init>(r13, r14, r15, r16, r17)
            qx r4 = r0.f2796l
            if (r1 == r4) goto L_0x01c2
            fy r3 = r3.mo1488x(r1)
        L_0x01c2:
            if (r11 == 0) goto L_0x01ca
            boolean r1 = r11.isEmpty()
            if (r1 == 0) goto L_0x01cc
        L_0x01ca:
            if (r5 == 0) goto L_0x01d0
        L_0x01cc:
            fy r3 = r3.mo1486v(r11, r5)
        L_0x01d0:
            if (r2 == 0) goto L_0x01d6
            fy r3 = r3.mo1487w(r2)
        L_0x01d6:
            if (r10 != 0) goto L_0x01da
            dp$c r10 = r0.f2797m
        L_0x01da:
            dp$c r1 = p000.C0576dp.C0579c.ARRAY
            if (r10 != r1) goto L_0x01e3
            fy r1 = r3.mo1484s()
            return r1
        L_0x01e3:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0724fy.mo2818a(at, fs):ps");
    }

    /* renamed from: b */
    public void mo2817b(C0221at atVar) {
        C1700rw rwVar;
        C0230aw awVar;
        C1887uu uuVar;
        Object H;
        C1462ps<Object> psVar;
        C1700rw rwVar2;
        C1700rw[] rwVarArr = this.f2792h;
        int length = rwVarArr == null ? 0 : rwVarArr.length;
        int length2 = this.f2791g.length;
        for (int i = 0; i < length2; i++) {
            C1700rw rwVar3 = this.f2791g[i];
            boolean z = true;
            if (!rwVar3.f5630r) {
                if (!(rwVar3.f5627o != null) && (psVar = atVar.f1141k) != null) {
                    rwVar3.mo4359g(psVar);
                    if (i < length && (rwVar2 = this.f2792h[i]) != null) {
                        rwVar2.mo4359g(psVar);
                    }
                }
            }
            if (rwVar3.f5626n == null) {
                z = false;
            }
            if (!z) {
                C0583ds w = atVar.mo1464w();
                C1462ps<Object> psVar2 = null;
                if (!(w == null || (uuVar = rwVar3.f5623k) == null || (H = w.mo3107H(uuVar)) == null)) {
                    t00<Object, Object> c = atVar.mo3829c(rwVar3.f5623k, H);
                    C1035ks b = c.mo5896b(atVar.mo1447d());
                    if (!b.mo4349z()) {
                        psVar2 = atVar.mo1462u(b, rwVar3);
                    }
                    psVar2 = new C1148lz(c, b, psVar2);
                }
                if (psVar2 == null) {
                    C1035ks ksVar = rwVar3.f5620h;
                    if (ksVar == null) {
                        ksVar = rwVar3.f5619g;
                        if (!ksVar.mo4348y()) {
                            if (ksVar.mo1797w() || ksVar.mo4339g() > 0) {
                                rwVar3.f5621i = ksVar;
                            }
                        }
                    }
                    psVar2 = atVar.mo1462u(ksVar, rwVar3);
                    if (ksVar.mo1797w() && (awVar = (C0230aw) ksVar.mo1791k().f3699g) != null && (psVar2 instanceof C2033ww)) {
                        C2033ww wwVar = (C2033ww) psVar2;
                        Objects.requireNonNull(wwVar);
                        psVar2 = wwVar.mo3673p(awVar);
                    }
                }
                if (i >= length || (rwVar = this.f2792h[i]) == null) {
                    rwVar3.mo4360h(psVar2);
                } else {
                    rwVar.mo4360h(psVar2);
                }
            }
        }
        C1467pw pwVar = this.f2793i;
        if (pwVar != null) {
            C1462ps<Object> psVar3 = pwVar.f4952c;
            if (psVar3 instanceof C2100xw) {
                C1462ps<?> z2 = atVar.mo1467z(psVar3, pwVar.f4950a);
                pwVar.f4952c = z2;
                if (z2 instanceof C1963vy) {
                    pwVar.f4953d = (C1963vy) z2;
                }
            }
        }
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        C1638qx qxVar = this.f2796l;
        mqVar.mo4633h(obj);
        if (qxVar != null) {
            mo3668p(obj, mqVar, atVar, awVar);
            return;
        }
        C1460pr r = mo3670r(awVar, obj, C1692rq.START_OBJECT);
        awVar.mo1478e(mqVar, r);
        Object obj2 = this.f2794j;
        if (obj2 != null) {
            if (this.f2792h != null) {
                Class<?> cls = atVar.f1135e;
            }
            mo5884m(atVar, obj2, obj);
            throw null;
        }
        mo3671u(obj, mqVar, atVar);
        awVar.mo1479f(mqVar, r);
    }

    /* renamed from: i */
    public boolean mo3667i() {
        return this.f2796l != null;
    }

    /* renamed from: p */
    public final void mo3668p(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        C1638qx qxVar = this.f2796l;
        C0318by q = atVar.mo1458q(obj, qxVar.f5358c);
        if (!q.mo1733b(mqVar, atVar, qxVar)) {
            if (q.f1367b == null) {
                q.f1367b = q.f1366a.mo3097c(obj);
            }
            Object obj2 = q.f1367b;
            if (qxVar.f5360e) {
                qxVar.f5359d.mo1481f(obj2, mqVar, atVar);
                return;
            }
            C1638qx qxVar2 = this.f2796l;
            C1460pr r = mo3670r(awVar, obj, C1692rq.START_OBJECT);
            awVar.mo1478e(mqVar, r);
            q.mo1732a(mqVar, atVar, qxVar2);
            Object obj3 = this.f2794j;
            if (obj3 == null) {
                mo3671u(obj, mqVar, atVar);
                awVar.mo1479f(mqVar, r);
                return;
            }
            mo5884m(atVar, obj3, obj);
            throw null;
        }
    }

    /* renamed from: q */
    public final void mo3669q(Object obj, C1200mq mqVar, C0221at atVar, boolean z) {
        C1638qx qxVar = this.f2796l;
        C0318by q = atVar.mo1458q(obj, qxVar.f5358c);
        if (!q.mo1733b(mqVar, atVar, qxVar)) {
            if (q.f1367b == null) {
                q.f1367b = q.f1366a.mo3097c(obj);
            }
            Object obj2 = q.f1367b;
            if (qxVar.f5360e) {
                qxVar.f5359d.mo1481f(obj2, mqVar, atVar);
                return;
            }
            if (z) {
                mqVar.mo3715J(obj);
            }
            q.mo1732a(mqVar, atVar, qxVar);
            Object obj3 = this.f2794j;
            if (obj3 == null) {
                mo3671u(obj, mqVar, atVar);
                if (z) {
                    mqVar.mo3736n();
                    return;
                }
                return;
            }
            mo5884m(atVar, obj3, obj);
            throw null;
        }
    }

    /* renamed from: r */
    public final C1460pr mo3670r(C0230aw awVar, Object obj, C1692rq rqVar) {
        C1887uu uuVar = this.f2795k;
        if (uuVar == null) {
            return awVar.mo1477d(obj, rqVar);
        }
        Object j = uuVar.mo5608j(obj);
        if (j == null) {
            j = "";
        }
        C1460pr d = awVar.mo1477d(obj, rqVar);
        d.f4925c = j;
        return d;
    }

    /* renamed from: s */
    public abstract C0724fy mo1484s();

    /* renamed from: u */
    public void mo3671u(Object obj, C1200mq mqVar, C0221at atVar) {
        String str = "[anySetter]";
        C1700rw[] rwVarArr = this.f2792h;
        if (rwVarArr == null || atVar.f1135e == null) {
            rwVarArr = this.f2791g;
        }
        try {
            for (C1700rw rwVar : rwVarArr) {
                if (rwVar != null) {
                    rwVar.mo3842k(obj, mqVar, atVar);
                }
            }
            C1467pw pwVar = this.f2793i;
            if (pwVar != null) {
                pwVar.mo5294a(obj, mqVar, atVar);
            }
        } catch (Exception e) {
            if (0 != rwVarArr.length) {
                str = rwVarArr[0].f5617e.f2986d;
            }
            mo5886o(atVar, e, obj, str);
            throw null;
        } catch (StackOverflowError e2) {
            C1203ms msVar = new C1203ms(mqVar, "Infinite recursion (StackOverflowError)", e2);
            if (0 != rwVarArr.length) {
                str = rwVarArr[0].f5617e.f2986d;
            }
            msVar.mo4637d(new C1203ms.C1204a(obj, str));
            throw msVar;
        }
    }

    /* renamed from: v */
    public abstract C0724fy mo1486v(Set<String> set, Set<String> set2);

    /* renamed from: w */
    public abstract C0724fy mo1487w(Object obj);

    /* renamed from: x */
    public abstract C0724fy mo1488x(C1638qx qxVar);

    /* renamed from: y */
    public abstract C0724fy mo1489y(C1700rw[] rwVarArr, C1700rw[] rwVarArr2);

    /* JADX WARNING: type inference failed for: r11v11, types: [java.lang.Object[]] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0724fy(p000.C0724fy r10, java.util.Set<java.lang.String> r11, java.util.Set<java.lang.String> r12) {
        /*
            r9 = this;
            java.lang.Class<T> r0 = r10.f5804d
            r9.<init>(r0)
            ks r0 = r10.f2790f
            r9.f2790f = r0
            rw[] r0 = r10.f2791g
            rw[] r1 = r10.f2792h
            int r2 = r0.length
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>(r2)
            r4 = 0
            if (r1 != 0) goto L_0x0018
            r5 = r4
            goto L_0x001d
        L_0x0018:
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>(r2)
        L_0x001d:
            r6 = 0
        L_0x001e:
            if (r6 >= r2) goto L_0x003a
            r7 = r0[r6]
            gr r8 = r7.f5617e
            java.lang.String r8 = r8.f2986d
            boolean r8 = p000.C1401p4.m4373l0(r8, r11, r12)
            if (r8 == 0) goto L_0x002d
            goto L_0x0037
        L_0x002d:
            r3.add(r7)
            if (r1 == 0) goto L_0x0037
            r7 = r1[r6]
            r5.add(r7)
        L_0x0037:
            int r6 = r6 + 1
            goto L_0x001e
        L_0x003a:
            int r11 = r3.size()
            rw[] r11 = new p000.C1700rw[r11]
            java.lang.Object[] r11 = r3.toArray(r11)
            rw[] r11 = (p000.C1700rw[]) r11
            r9.f2791g = r11
            if (r5 != 0) goto L_0x004b
            goto L_0x0058
        L_0x004b:
            int r11 = r5.size()
            rw[] r11 = new p000.C1700rw[r11]
            java.lang.Object[] r11 = r5.toArray(r11)
            r4 = r11
            rw[] r4 = (p000.C1700rw[]) r4
        L_0x0058:
            r9.f2792h = r4
            uu r11 = r10.f2795k
            r9.f2795k = r11
            pw r11 = r10.f2793i
            r9.f2793i = r11
            qx r11 = r10.f2796l
            r9.f2796l = r11
            java.lang.Object r11 = r10.f2794j
            r9.f2794j = r11
            dp$c r10 = r10.f2797m
            r9.f2797m = r10
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0724fy.<init>(fy, java.util.Set, java.util.Set):void");
    }
}
