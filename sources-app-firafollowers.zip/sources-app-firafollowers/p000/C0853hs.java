package p000;

import java.io.Serializable;

/* renamed from: hs */
public final class C0853hs extends C1828tt<C0980js, C0853hs> implements Serializable {

    /* renamed from: v */
    public static final int f3153v = C1757st.m4986c(C0980js.class);

    /* renamed from: o */
    public final C1372ow f3154o;

    /* renamed from: p */
    public final C1141lt f3155p;

    /* renamed from: q */
    public final int f3156q;

    /* renamed from: r */
    public final int f3157r;

    /* renamed from: s */
    public final int f3158s;

    /* renamed from: t */
    public final int f3159t;

    /* renamed from: u */
    public final int f3160u;

    public C0853hs(C0853hs hsVar, int i, int i2, int i3, int i4, int i5, int i6) {
        super(hsVar, i);
        this.f3156q = i2;
        this.f3154o = hsVar.f3154o;
        this.f3155p = hsVar.f3155p;
        this.f3157r = i3;
        this.f3158s = i4;
        this.f3159t = i5;
        this.f3160u = i6;
    }

    public C0853hs(C0981jt jtVar, C2099xv xvVar, C1466pv pvVar, d10 d10, C1464pt ptVar, C1141lt ltVar) {
        super(jtVar, xvVar, pvVar, d10, ptVar);
        this.f3156q = f3153v;
        this.f3154o = C1372ow.f4622e;
        this.f3155p = ltVar;
        this.f3157r = 0;
        this.f3158s = 0;
        this.f3159t = 0;
        this.f3160u = 0;
    }

    /* renamed from: o */
    public C1828tt mo3957o(int i) {
        return new C0853hs(this, i, this.f3156q, this.f3157r, this.f3158s, this.f3159t, this.f3160u);
    }
}
