package p000;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/* renamed from: d4 */
public abstract class C0526d4<K, V> {

    /* renamed from: a */
    public C0526d4<K, V>.C0234b f2146a;

    /* renamed from: b */
    public C0526d4<K, V>.C0320c f2147b;

    /* renamed from: c */
    public C0526d4<K, V>.C0593e f2148c;

    /* renamed from: d4$a */
    public final class C0527a<T> implements Iterator<T> {

        /* renamed from: d */
        public final int f2149d;

        /* renamed from: e */
        public int f2150e;

        /* renamed from: f */
        public int f2151f;

        /* renamed from: g */
        public boolean f2152g = false;

        public C0527a(int i) {
            this.f2149d = i;
            this.f2150e = C0526d4.this.mo2887d();
        }

        public boolean hasNext() {
            return this.f2151f < this.f2150e;
        }

        public T next() {
            if (hasNext()) {
                T b = C0526d4.this.mo2885b(this.f2151f, this.f2149d);
                this.f2151f++;
                this.f2152g = true;
                return b;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.f2152g) {
                int i = this.f2151f - 1;
                this.f2151f = i;
                this.f2150e--;
                this.f2152g = false;
                C0526d4.this.mo2891h(i);
                return;
            }
            throw new IllegalStateException();
        }
    }

    /* renamed from: d4$b */
    public final class C0528b implements Set<Map.Entry<K, V>> {
        public C0528b() {
        }

        public boolean add(Object obj) {
            Map.Entry entry = (Map.Entry) obj;
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Map.Entry<K, V>> collection) {
            int d = C0526d4.this.mo2887d();
            for (Map.Entry entry : collection) {
                C0526d4.this.mo2890g(entry.getKey(), entry.getValue());
            }
            return d != C0526d4.this.mo2887d();
        }

        public void clear() {
            C0526d4.this.mo2884a();
        }

        public boolean contains(Object obj) {
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            int e = C0526d4.this.mo2888e(entry.getKey());
            if (e < 0) {
                return false;
            }
            return C0007a4.m19c(C0526d4.this.mo2885b(e, 1), entry.getValue());
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean equals(Object obj) {
            return C0526d4.m1686j(this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int d = C0526d4.this.mo2887d() - 1; d >= 0; d--) {
                Object b = C0526d4.this.mo2885b(d, 0);
                Object b2 = C0526d4.this.mo2885b(d, 1);
                i += (b == null ? 0 : b.hashCode()) ^ (b2 == null ? 0 : b2.hashCode());
            }
            return i;
        }

        public boolean isEmpty() {
            return C0526d4.this.mo2887d() == 0;
        }

        public Iterator<Map.Entry<K, V>> iterator() {
            return new C0530d();
        }

        public boolean remove(Object obj) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return C0526d4.this.mo2887d();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: d4$c */
    public final class C0529c implements Set<K> {
        public C0529c() {
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0526d4.this.mo2884a();
        }

        public boolean contains(Object obj) {
            return C0526d4.this.mo2888e(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            Map c = C0526d4.this.mo2886c();
            for (Object containsKey : collection) {
                if (!c.containsKey(containsKey)) {
                    return false;
                }
            }
            return true;
        }

        public boolean equals(Object obj) {
            return C0526d4.m1686j(this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int d = C0526d4.this.mo2887d() - 1; d >= 0; d--) {
                Object b = C0526d4.this.mo2885b(d, 0);
                i += b == null ? 0 : b.hashCode();
            }
            return i;
        }

        public boolean isEmpty() {
            return C0526d4.this.mo2887d() == 0;
        }

        public Iterator<K> iterator() {
            return new C0527a(0);
        }

        public boolean remove(Object obj) {
            int e = C0526d4.this.mo2888e(obj);
            if (e < 0) {
                return false;
            }
            C0526d4.this.mo2891h(e);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            Map c = C0526d4.this.mo2886c();
            int size = c.size();
            for (Object remove : collection) {
                c.remove(remove);
            }
            return size != c.size();
        }

        public boolean retainAll(Collection<?> collection) {
            return C0526d4.m1687k(C0526d4.this.mo2886c(), collection);
        }

        public int size() {
            return C0526d4.this.mo2887d();
        }

        public Object[] toArray() {
            return C0526d4.this.mo2893l(0);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0526d4.this.mo2894m(tArr, 0);
        }
    }

    /* renamed from: d4$d */
    public final class C0530d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {

        /* renamed from: d */
        public int f2156d;

        /* renamed from: e */
        public int f2157e;

        /* renamed from: f */
        public boolean f2158f = false;

        public C0530d() {
            this.f2156d = C0526d4.this.mo2887d() - 1;
            this.f2157e = -1;
        }

        public boolean equals(Object obj) {
            if (!this.f2158f) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(obj instanceof Map.Entry)) {
                return false;
            } else {
                Map.Entry entry = (Map.Entry) obj;
                return C0007a4.m19c(entry.getKey(), C0526d4.this.mo2885b(this.f2157e, 0)) && C0007a4.m19c(entry.getValue(), C0526d4.this.mo2885b(this.f2157e, 1));
            }
        }

        public K getKey() {
            if (this.f2158f) {
                return C0526d4.this.mo2885b(this.f2157e, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.f2158f) {
                return C0526d4.this.mo2885b(this.f2157e, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public boolean hasNext() {
            return this.f2157e < this.f2156d;
        }

        public int hashCode() {
            if (this.f2158f) {
                int i = 0;
                Object b = C0526d4.this.mo2885b(this.f2157e, 0);
                Object b2 = C0526d4.this.mo2885b(this.f2157e, 1);
                int hashCode = b == null ? 0 : b.hashCode();
                if (b2 != null) {
                    i = b2.hashCode();
                }
                return hashCode ^ i;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public Object next() {
            if (hasNext()) {
                this.f2157e++;
                this.f2158f = true;
                return this;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.f2158f) {
                C0526d4.this.mo2891h(this.f2157e);
                this.f2157e--;
                this.f2156d--;
                this.f2158f = false;
                return;
            }
            throw new IllegalStateException();
        }

        public V setValue(V v) {
            if (this.f2158f) {
                return C0526d4.this.mo2892i(this.f2157e, v);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public String toString() {
            return getKey() + "=" + getValue();
        }
    }

    /* renamed from: d4$e */
    public final class C0531e implements Collection<V> {
        public C0531e() {
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0526d4.this.mo2884a();
        }

        public boolean contains(Object obj) {
            return C0526d4.this.mo2889f(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return C0526d4.this.mo2887d() == 0;
        }

        public Iterator<V> iterator() {
            return new C0527a(1);
        }

        public boolean remove(Object obj) {
            int f = C0526d4.this.mo2889f(obj);
            if (f < 0) {
                return false;
            }
            C0526d4.this.mo2891h(f);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int d = C0526d4.this.mo2887d();
            int i = 0;
            boolean z = false;
            while (i < d) {
                if (collection.contains(C0526d4.this.mo2885b(i, 1))) {
                    C0526d4.this.mo2891h(i);
                    i--;
                    d--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public boolean retainAll(Collection<?> collection) {
            int d = C0526d4.this.mo2887d();
            int i = 0;
            boolean z = false;
            while (i < d) {
                if (!collection.contains(C0526d4.this.mo2885b(i, 1))) {
                    C0526d4.this.mo2891h(i);
                    i--;
                    d--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public int size() {
            return C0526d4.this.mo2887d();
        }

        public Object[] toArray() {
            return C0526d4.this.mo2893l(1);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0526d4.this.mo2894m(tArr, 1);
        }
    }

    /* renamed from: j */
    public static <T> boolean m1686j(Set<T> set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                return set.size() == set2.size() && set.containsAll(set2);
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    /* renamed from: k */
    public static <K, V> boolean m1687k(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    /* renamed from: a */
    public abstract void mo2884a();

    /* renamed from: b */
    public abstract Object mo2885b(int i, int i2);

    /* renamed from: c */
    public abstract Map<K, V> mo2886c();

    /* renamed from: d */
    public abstract int mo2887d();

    /* renamed from: e */
    public abstract int mo2888e(Object obj);

    /* renamed from: f */
    public abstract int mo2889f(Object obj);

    /* renamed from: g */
    public abstract void mo2890g(K k, V v);

    /* renamed from: h */
    public abstract void mo2891h(int i);

    /* renamed from: i */
    public abstract V mo2892i(int i, V v);

    /* renamed from: l */
    public Object[] mo2893l(int i) {
        int d = mo2887d();
        Object[] objArr = new Object[d];
        for (int i2 = 0; i2 < d; i2++) {
            objArr[i2] = mo2885b(i2, i);
        }
        return objArr;
    }

    /* renamed from: m */
    public <T> T[] mo2894m(T[] tArr, int i) {
        int d = mo2887d();
        if (tArr.length < d) {
            tArr = (Object[]) Array.newInstance(tArr.getClass().getComponentType(), d);
        }
        for (int i2 = 0; i2 < d; i2++) {
            tArr[i2] = mo2885b(i2, i);
        }
        if (tArr.length > d) {
            tArr[d] = null;
        }
        return tArr;
    }
}
