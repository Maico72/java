package p000;

import android.graphics.Bitmap;

/* renamed from: ai */
public interface C0056ai {
    /* renamed from: a */
    void mo127a(int i);

    /* renamed from: b */
    void mo128b();

    /* renamed from: c */
    Bitmap mo129c(int i, int i2, Bitmap.Config config);

    /* renamed from: d */
    Bitmap mo130d(int i, int i2, Bitmap.Config config);

    /* renamed from: e */
    void mo131e(Bitmap bitmap);
}
