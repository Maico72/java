package p000;

/* renamed from: io */
public final class C0904io<K, V> extends C2047x3<K, V> {

    /* renamed from: l */
    public int f3284l;

    public void clear() {
        this.f3284l = 0;
        super.clear();
    }

    public int hashCode() {
        if (this.f3284l == 0) {
            this.f3284l = super.hashCode();
        }
        return this.f3284l;
    }

    /* renamed from: i */
    public void mo3280i(C0604e4<? extends K, ? extends V> e4Var) {
        this.f3284l = 0;
        super.mo3280i(e4Var);
    }

    /* renamed from: j */
    public V mo3282j(int i) {
        this.f3284l = 0;
        return super.mo3282j(i);
    }

    /* renamed from: k */
    public V mo3283k(int i, V v) {
        this.f3284l = 0;
        int i2 = (i << 1) + 1;
        V[] vArr = this.f2477e;
        V v2 = vArr[i2];
        vArr[i2] = v;
        return v2;
    }

    public V put(K k, V v) {
        this.f3284l = 0;
        return super.put(k, v);
    }
}
