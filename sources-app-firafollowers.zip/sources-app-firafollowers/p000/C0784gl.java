package p000;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;

/* renamed from: gl */
public final class C0784gl {

    /* renamed from: a */
    public static volatile boolean f2976a = true;

    /* renamed from: a */
    public static Drawable m2532a(Context context, Context context2, int i, Resources.Theme theme) {
        try {
            if (f2976a) {
                return C0001a0.m1b(theme != null ? new C0862i0(context2, theme) : context2, i);
            }
        } catch (NoClassDefFoundError unused) {
            f2976a = false;
        } catch (IllegalStateException e) {
            if (!context.getPackageName().equals(context2.getPackageName())) {
                return C1901v4.m5334c(context2, i);
            }
            throw e;
        } catch (Resources.NotFoundException unused2) {
        }
        if (theme == null) {
            theme = context2.getTheme();
        }
        return C0532d5.m1701a(context2.getResources(), i, theme);
    }
}
