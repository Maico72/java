package p000;

import java.lang.reflect.InvocationTargetException;

@Deprecated
/* renamed from: cn */
public final class C0379cn {
    /* renamed from: a */
    public static C0066an m1379a(String str) {
        try {
            Class<?> cls = Class.forName(str);
            try {
                Object newInstance = cls.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                if (newInstance instanceof C0066an) {
                    return (C0066an) newInstance;
                }
                throw new RuntimeException("Expected instanceof GlideModule, but found: " + newInstance);
            } catch (InstantiationException e) {
                m1380b(cls, e);
                throw null;
            } catch (IllegalAccessException e2) {
                m1380b(cls, e2);
                throw null;
            } catch (NoSuchMethodException e3) {
                m1380b(cls, e3);
                throw null;
            } catch (InvocationTargetException e4) {
                m1380b(cls, e4);
                throw null;
            }
        } catch (ClassNotFoundException e5) {
            throw new IllegalArgumentException("Unable to find GlideModule implementation", e5);
        }
    }

    /* renamed from: b */
    public static void m1380b(Class<?> cls, Exception exc) {
        throw new RuntimeException("Unable to instantiate GlideModule implementation for " + cls, exc);
    }
}
