package p000;

import android.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* renamed from: eh */
public class C0635eh<DataType, ResourceType, Transcode> {

    /* renamed from: a */
    public final Class<DataType> f2600a;

    /* renamed from: b */
    public final List<? extends C0054ag<DataType, ResourceType>> f2601b;

    /* renamed from: c */
    public final C0303bm<ResourceType, Transcode> f2602c;

    /* renamed from: d */
    public final C0940j6<List<Throwable>> f2603d;

    /* renamed from: e */
    public final String f2604e;

    /* renamed from: eh$a */
    public interface C0636a<ResourceType> {
    }

    public C0635eh(Class<DataType> cls, Class<ResourceType> cls2, Class<Transcode> cls3, List<? extends C0054ag<DataType, ResourceType>> list, C0303bm<ResourceType, Transcode> bmVar, C0940j6<List<Throwable>> j6Var) {
        this.f2600a = cls;
        this.f2601b = list;
        this.f2602c = bmVar;
        this.f2603d = j6Var;
        StringBuilder d = C1012kd.m3195d("Failed DecodePath{");
        d.append(cls.getSimpleName());
        d.append("->");
        d.append(cls2.getSimpleName());
        d.append("->");
        d.append(cls3.getSimpleName());
        d.append("}");
        this.f2604e = d.toString();
    }

    /* JADX INFO: finally extract failed */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: hg<DataType>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v2, resolved type: rh<ResourceType>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v4, resolved type: qh<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v2, resolved type: java.lang.Class<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v5, resolved type: qh<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v4, resolved type: T} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v14, resolved type: zg} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: java.lang.Class<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v8, resolved type: java.lang.Class<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v7, resolved type: rh<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v11, resolved type: qh<T>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v12, resolved type: qh<Z>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v27, resolved type: th} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v12, resolved type: th} */
    /* JADX WARNING: type inference failed for: r11v13, types: [wf] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1675rh<Transcode> mo3398a(p000.C0833hg<DataType> r11, int r12, int r13, p000.C2150yf r14, p000.C0635eh.C0636a<ResourceType> r15) {
        /*
            r10 = this;
            j6<java.util.List<java.lang.Throwable>> r0 = r10.f2603d
            java.lang.Object r0 = r0.mo4124b()
            java.lang.String r1 = "Argument must not be null"
            java.util.Objects.requireNonNull(r0, r1)
            java.util.List r0 = (java.util.List) r0
            r2 = r10
            r3 = r11
            r4 = r12
            r5 = r13
            r6 = r14
            r7 = r0
            rh r11 = r2.mo3399b(r3, r4, r5, r6, r7)     // Catch:{ all -> 0x011e }
            j6<java.util.List<java.lang.Throwable>> r12 = r10.f2603d
            r12.mo4123a(r0)
            dh$b r15 = (p000.C0560dh.C0562b) r15
            dh r12 = p000.C0560dh.this
            kf r13 = r15.f2285a
            java.util.Objects.requireNonNull(r12)
            java.lang.Object r15 = r11.mo1714b()
            java.lang.Class r7 = r15.getClass()
            kf r15 = p000.C1017kf.RESOURCE_DISK_CACHE
            r0 = 0
            if (r13 == r15) goto L_0x0045
            ch<R> r15 = r12.f2262d
            cg r15 = r15.mo1958f(r7)
            ve r1 = r12.f2269k
            int r2 = r12.f2273o
            int r3 = r12.f2274p
            rh r1 = r15.mo142b(r1, r11, r2, r3)
            r6 = r15
            r15 = r1
            goto L_0x0047
        L_0x0045:
            r15 = r11
            r6 = r0
        L_0x0047:
            boolean r1 = r11.equals(r15)
            if (r1 != 0) goto L_0x0050
            r11.mo1717e()
        L_0x0050:
            ch<R> r11 = r12.f2262d
            ve r11 = r11.f1593c
            ye r11 = r11.f6371b
            jn r11 = r11.f6938d
            java.lang.Class r1 = r15.mo1716d()
            bg r11 = r11.mo4181a(r1)
            r1 = 0
            r2 = 1
            if (r11 == 0) goto L_0x0066
            r11 = 1
            goto L_0x0067
        L_0x0066:
            r11 = 0
        L_0x0067:
            if (r11 == 0) goto L_0x008c
            ch<R> r11 = r12.f2262d
            ve r11 = r11.f1593c
            ye r11 = r11.f6371b
            jn r11 = r11.f6938d
            java.lang.Class r0 = r15.mo1716d()
            bg r0 = r11.mo4181a(r0)
            if (r0 == 0) goto L_0x0082
            yf r11 = r12.f2276r
            mf r11 = r0.mo1705b(r11)
            goto L_0x008e
        L_0x0082:
            ye$d r11 = new ye$d
            java.lang.Class r12 = r15.mo1716d()
            r11.<init>(r12)
            throw r11
        L_0x008c:
            mf r11 = p000.C1178mf.NONE
        L_0x008e:
            r9 = r0
            ch<R> r0 = r12.f2262d
            wf r3 = r12.f2253A
            java.util.List r0 = r0.mo1955c()
            int r4 = r0.size()
            r5 = 0
        L_0x009c:
            if (r5 >= r4) goto L_0x00b1
            java.lang.Object r8 = r0.get(r5)
            jj$a r8 = (p000.C0969jj.C0970a) r8
            wf r8 = r8.f3455a
            boolean r8 = r8.equals(r3)
            if (r8 == 0) goto L_0x00ae
            r1 = 1
            goto L_0x00b1
        L_0x00ae:
            int r5 = r5 + 1
            goto L_0x009c
        L_0x00b1:
            r0 = r1 ^ 1
            fh r1 = r12.f2275q
            boolean r13 = r1.mo3602d(r0, r13, r11)
            if (r13 == 0) goto L_0x0117
            if (r9 == 0) goto L_0x0109
            int r13 = r11.ordinal()
            if (r13 == 0) goto L_0x00f3
            if (r13 != r2) goto L_0x00dc
            th r11 = new th
            ch<R> r13 = r12.f2262d
            ve r13 = r13.f1593c
            yh r1 = r13.f6370a
            wf r2 = r12.f2253A
            wf r3 = r12.f2270l
            int r4 = r12.f2273o
            int r5 = r12.f2274p
            yf r8 = r12.f2276r
            r0 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            goto L_0x00fc
        L_0x00dc:
            java.lang.IllegalArgumentException r12 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            java.lang.String r14 = "Unknown strategy: "
            r13.append(r14)
            r13.append(r11)
            java.lang.String r11 = r13.toString()
            r12.<init>(r11)
            throw r12
        L_0x00f3:
            zg r11 = new zg
            wf r13 = r12.f2253A
            wf r0 = r12.f2270l
            r11.<init>(r13, r0)
        L_0x00fc:
            qh r15 = p000.C1613qh.m4629f(r15)
            dh$c<?> r12 = r12.f2267i
            r12.f2287a = r11
            r12.f2288b = r9
            r12.f2289c = r15
            goto L_0x0117
        L_0x0109:
            ye$d r11 = new ye$d
            java.lang.Object r12 = r15.mo1714b()
            java.lang.Class r12 = r12.getClass()
            r11.<init>(r12)
            throw r11
        L_0x0117:
            bm<ResourceType, Transcode> r11 = r10.f2602c
            rh r11 = r11.mo149a(r15, r14)
            return r11
        L_0x011e:
            r11 = move-exception
            j6<java.util.List<java.lang.Throwable>> r12 = r10.f2603d
            r12.mo4123a(r0)
            goto L_0x0126
        L_0x0125:
            throw r11
        L_0x0126:
            goto L_0x0125
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0635eh.mo3398a(hg, int, int, yf, eh$a):rh");
    }

    /* renamed from: b */
    public final C1675rh<ResourceType> mo3399b(C0833hg<DataType> hgVar, int i, int i2, C2150yf yfVar, List<Throwable> list) {
        int size = this.f2601b.size();
        C1675rh<ResourceType> rhVar = null;
        for (int i3 = 0; i3 < size; i3++) {
            C0054ag agVar = (C0054ag) this.f2601b.get(i3);
            try {
                if (agVar.mo123b(hgVar.mo1979a(), yfVar)) {
                    rhVar = agVar.mo122a(hgVar.mo1979a(), i, i2, yfVar);
                }
            } catch (IOException | OutOfMemoryError | RuntimeException e) {
                if (Log.isLoggable("DecodePath", 2)) {
                    Log.v("DecodePath", "Failed to decode data for " + agVar, e);
                }
                list.add(e);
            }
            if (rhVar != null) {
                break;
            }
        }
        if (rhVar != null) {
            return rhVar;
        }
        throw new C1182mh(this.f2604e, (List<Throwable>) new ArrayList(list));
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("DecodePath{ dataClass=");
        d.append(this.f2600a);
        d.append(", decoders=");
        d.append(this.f2601b);
        d.append(", transcoder=");
        d.append(this.f2602c);
        d.append('}');
        return d.toString();
    }
}
