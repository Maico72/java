package p000;

/* renamed from: da */
public abstract class C0543da implements C0347ca {
    /* renamed from: a */
    public abstract <T extends C0273ba> T mo2970a(String str, Class<T> cls);
}
