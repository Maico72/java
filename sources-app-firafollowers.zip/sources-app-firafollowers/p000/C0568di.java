package p000;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import p000.C0894ii;

/* renamed from: di */
public class C0568di<K extends C0894ii, V> {

    /* renamed from: a */
    public final C0569a<K, V> f2304a = new C0569a<>(null);

    /* renamed from: b */
    public final Map<K, C0569a<K, V>> f2305b = new HashMap();

    /* renamed from: di$a */
    public static class C0569a<K, V> {

        /* renamed from: a */
        public final K f2306a;

        /* renamed from: b */
        public List<V> f2307b;

        /* renamed from: c */
        public C0569a<K, V> f2308c;

        /* renamed from: d */
        public C0569a<K, V> f2309d;

        public C0569a() {
            this((Object) null);
        }

        public C0569a(K k) {
            this.f2309d = this;
            this.f2308c = this;
            this.f2306a = k;
        }

        /* renamed from: a */
        public V mo3071a() {
            List<V> list = this.f2307b;
            int size = list != null ? list.size() : 0;
            if (size > 0) {
                return this.f2307b.remove(size - 1);
            }
            return null;
        }
    }

    /* renamed from: a */
    public V mo3067a(K k) {
        C0569a<K, V> aVar = this.f2305b.get(k);
        if (aVar == null) {
            aVar = new C0569a<>(k);
            this.f2305b.put(k, aVar);
        } else {
            k.mo3613a();
        }
        C0569a<K, V> aVar2 = aVar.f2309d;
        aVar2.f2308c = aVar.f2308c;
        aVar.f2308c.f2309d = aVar2;
        C0569a<K, V> aVar3 = this.f2304a;
        aVar.f2309d = aVar3;
        C0569a<K, V> aVar4 = aVar3.f2308c;
        aVar.f2308c = aVar4;
        aVar4.f2309d = aVar;
        aVar.f2309d.f2308c = aVar;
        return aVar.mo3071a();
    }

    /* renamed from: b */
    public void mo3068b(K k, V v) {
        C0569a<K, V> aVar = this.f2305b.get(k);
        if (aVar == null) {
            aVar = new C0569a<>(k);
            C0569a<K, V> aVar2 = aVar.f2309d;
            aVar2.f2308c = aVar.f2308c;
            aVar.f2308c.f2309d = aVar2;
            C0569a<K, V> aVar3 = this.f2304a;
            aVar.f2309d = aVar3.f2309d;
            aVar.f2308c = aVar3;
            aVar3.f2309d = aVar;
            aVar.f2309d.f2308c = aVar;
            this.f2305b.put(k, aVar);
        } else {
            k.mo3613a();
        }
        if (aVar.f2307b == null) {
            aVar.f2307b = new ArrayList();
        }
        aVar.f2307b.add(v);
    }

    /* renamed from: c */
    public V mo3069c() {
        C0569a<K, V> aVar = this.f2304a;
        while (true) {
            aVar = aVar.f2309d;
            if (aVar.equals(this.f2304a)) {
                return null;
            }
            V a = aVar.mo3071a();
            if (a != null) {
                return a;
            }
            C0569a<K, V> aVar2 = aVar.f2309d;
            aVar2.f2308c = aVar.f2308c;
            aVar.f2308c.f2309d = aVar2;
            this.f2305b.remove(aVar.f2306a);
            ((C0894ii) aVar.f2306a).mo3613a();
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("GroupedLinkedMap( ");
        boolean z = false;
        for (C0569a<K, V> aVar = this.f2304a.f2308c; !aVar.equals(this.f2304a); aVar = aVar.f2308c) {
            z = true;
            sb.append('{');
            sb.append(aVar.f2306a);
            sb.append(':');
            List<V> list = aVar.f2307b;
            sb.append(list != null ? list.size() : 0);
            sb.append("}, ");
        }
        if (z) {
            sb.delete(sb.length() - 2, sb.length());
        }
        sb.append(" )");
        return sb.toString();
    }
}
