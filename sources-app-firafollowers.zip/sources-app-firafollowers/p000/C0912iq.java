package p000;

import java.io.Serializable;
import java.util.Arrays;

/* renamed from: iq */
public final class C0912iq implements Serializable {

    /* renamed from: d */
    public final transient int[] f3291d;

    /* renamed from: e */
    public final transient char[] f3292e;

    /* renamed from: f */
    public final transient byte[] f3293f;

    /* renamed from: g */
    public final String f3294g;

    /* renamed from: h */
    public final char f3295h;

    /* renamed from: i */
    public final int f3296i;

    /* renamed from: j */
    public final boolean f3297j;

    /* renamed from: k */
    public final C0913a f3298k;

    /* renamed from: iq$a */
    public enum C0913a {
        PADDING_FORBIDDEN,
        PADDING_REQUIRED,
        PADDING_ALLOWED
    }

    public C0912iq(C0912iq iqVar, String str, boolean z, char c, int i) {
        C0913a aVar = iqVar.f3298k;
        int[] iArr = new int[128];
        this.f3291d = iArr;
        char[] cArr = new char[64];
        this.f3292e = cArr;
        byte[] bArr = new byte[64];
        this.f3293f = bArr;
        this.f3294g = str;
        byte[] bArr2 = iqVar.f3293f;
        System.arraycopy(bArr2, 0, bArr, 0, bArr2.length);
        char[] cArr2 = iqVar.f3292e;
        System.arraycopy(cArr2, 0, cArr, 0, cArr2.length);
        int[] iArr2 = iqVar.f3291d;
        System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
        this.f3297j = z;
        this.f3295h = c;
        this.f3296i = i;
        this.f3298k = aVar;
    }

    public C0912iq(String str, String str2, boolean z, char c, int i) {
        int[] iArr = new int[128];
        this.f3291d = iArr;
        char[] cArr = new char[64];
        this.f3292e = cArr;
        this.f3293f = new byte[64];
        this.f3294g = str;
        this.f3297j = z;
        this.f3295h = c;
        this.f3296i = i;
        int length = str2.length();
        if (length == 64) {
            str2.getChars(0, length, cArr, 0);
            Arrays.fill(iArr, -1);
            for (int i2 = 0; i2 < length; i2++) {
                char c2 = this.f3292e[i2];
                this.f3293f[i2] = (byte) c2;
                this.f3291d[c2] = i2;
            }
            if (z) {
                this.f3291d[c] = -2;
            }
            this.f3298k = z ? C0913a.PADDING_REQUIRED : C0913a.PADDING_FORBIDDEN;
            return;
        }
        throw new IllegalArgumentException("Base64Alphabet length must be exactly 64 (was " + length + ")");
    }

    /* renamed from: a */
    public int mo4086a(int i, char[] cArr, int i2) {
        int i3 = i2 + 1;
        char[] cArr2 = this.f3292e;
        cArr[i2] = cArr2[(i >> 18) & 63];
        int i4 = i3 + 1;
        cArr[i3] = cArr2[(i >> 12) & 63];
        int i5 = i4 + 1;
        cArr[i4] = cArr2[(i >> 6) & 63];
        int i6 = i5 + 1;
        cArr[i5] = cArr2[i & 63];
        return i6;
    }

    /* renamed from: b */
    public int mo4087b(int i, int i2, char[] cArr, int i3) {
        int i4 = i3 + 1;
        char[] cArr2 = this.f3292e;
        cArr[i3] = cArr2[(i >> 18) & 63];
        int i5 = i4 + 1;
        cArr[i4] = cArr2[(i >> 12) & 63];
        if (this.f3297j) {
            int i6 = i5 + 1;
            cArr[i5] = i2 == 2 ? cArr2[(i >> 6) & 63] : this.f3295h;
            int i7 = i6 + 1;
            cArr[i6] = this.f3295h;
            return i7;
        } else if (i2 != 2) {
            return i5;
        } else {
            cArr[i5] = cArr2[(i >> 6) & 63];
            return i5 + 1;
        }
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != C0912iq.class) {
            return false;
        }
        C0912iq iqVar = (C0912iq) obj;
        return iqVar.f3295h == this.f3295h && iqVar.f3296i == this.f3296i && iqVar.f3297j == this.f3297j && iqVar.f3298k == this.f3298k && this.f3294g.equals(iqVar.f3294g);
    }

    public int hashCode() {
        return this.f3294g.hashCode();
    }

    public String toString() {
        return this.f3294g;
    }
}
