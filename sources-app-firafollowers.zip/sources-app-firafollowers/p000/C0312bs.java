package p000;

import java.util.regex.Pattern;

/* renamed from: bs */
public class C0312bs {

    /* renamed from: a */
    public static final /* synthetic */ int f1364a = 0;

    static {
        Pattern.compile("[-_./;:]");
    }
}
