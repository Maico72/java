package p000;

import android.graphics.drawable.Drawable;

/* renamed from: ao */
public interface C0214ao<R> extends C1622qm {
    /* renamed from: a */
    void mo1428a(C2231zn znVar);

    /* renamed from: b */
    void mo1429b(Drawable drawable);

    /* renamed from: c */
    void mo1430c(R r, C0575do<? super R> doVar);

    /* renamed from: d */
    void mo1431d(Drawable drawable);

    /* renamed from: f */
    C1197mn mo1432f();

    /* renamed from: g */
    void mo1433g(Drawable drawable);

    /* renamed from: h */
    void mo1434h(C2231zn znVar);

    /* renamed from: j */
    void mo1435j(C1197mn mnVar);
}
