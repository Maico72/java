package p000;

/* renamed from: ej */
public interface C0638ej {
    /* renamed from: a */
    String mo3401a();
}
