package p000;

import java.util.HashSet;

/* renamed from: hr */
public class C0852hr {

    /* renamed from: a */
    public final Object f3149a;

    /* renamed from: b */
    public String f3150b;

    /* renamed from: c */
    public String f3151c;

    /* renamed from: d */
    public HashSet<String> f3152d;

    public C0852hr(Object obj) {
        this.f3149a = obj;
    }

    /* renamed from: a */
    public C0852hr mo3956a() {
        return new C0852hr(this.f3149a);
    }
}
