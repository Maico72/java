package p000;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: gn */
public class C0787gn {

    /* renamed from: c */
    public static final C1448ph<?, ?, ?> f2977c = new C1448ph(Object.class, Object.class, Object.class, Collections.singletonList(new C0635eh(Object.class, Object.class, Object.class, Collections.emptyList(), new C0573dm(), (C0940j6<List<Throwable>>) null)), (C0940j6<List<Throwable>>) null);

    /* renamed from: a */
    public final C2047x3<C1456po, C1448ph<?, ?, ?>> f2978a = new C2047x3<>();

    /* renamed from: b */
    public final AtomicReference<C1456po> f2979b = new AtomicReference<>();
}
