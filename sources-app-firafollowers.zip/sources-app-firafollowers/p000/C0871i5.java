package p000;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import p000.C0332c6;
import p000.C1221n5;

/* renamed from: i5 */
public class C0871i5 extends C1221n5 {

    /* renamed from: b */
    public static Class<?> f3214b;

    /* renamed from: c */
    public static Constructor<?> f3215c;

    /* renamed from: d */
    public static Method f3216d;

    /* renamed from: e */
    public static Method f3217e;

    /* renamed from: f */
    public static boolean f3218f;

    /* renamed from: h */
    public static boolean m2749h(Object obj, String str, int i, boolean z) {
        m2750j();
        try {
            return ((Boolean) f3216d.invoke(obj, new Object[]{str, Integer.valueOf(i), Boolean.valueOf(z)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    /* renamed from: j */
    public static void m2750j() {
        Method method;
        Class<?> cls;
        Method method2;
        if (!f3218f) {
            f3218f = true;
            Constructor<?> constructor = null;
            try {
                cls = Class.forName("android.graphics.FontFamily");
                Constructor<?> constructor2 = cls.getConstructor(new Class[0]);
                method = cls.getMethod("addFontWeightStyle", new Class[]{String.class, Integer.TYPE, Boolean.TYPE});
                method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(cls, 1).getClass()});
                constructor = constructor2;
            } catch (ClassNotFoundException | NoSuchMethodException e) {
                Log.e("TypefaceCompatApi21Impl", e.getClass().getName(), e);
                method2 = null;
                cls = null;
                method = null;
            }
            f3215c = constructor;
            f3214b = cls;
            f3216d = method;
            f3217e = method2;
        }
    }

    /* renamed from: a */
    public Typeface mo3999a(Context context, C2111y4 y4Var, Resources resources, int i) {
        m2750j();
        try {
            Object newInstance = f3215c.newInstance(new Object[0]);
            C2192z4[] z4VarArr = y4Var.f6843a;
            int length = z4VarArr.length;
            int i2 = 0;
            while (i2 < length) {
                C2192z4 z4Var = z4VarArr[i2];
                File F = C1401p4.m4329F(context);
                if (F == null) {
                    return null;
                }
                try {
                    if (!C1401p4.m4374m(F, resources, z4Var.f7092f)) {
                        F.delete();
                        return null;
                    } else if (!m2749h(newInstance, F.getPath(), z4Var.f7088b, z4Var.f7089c)) {
                        return null;
                    } else {
                        i2++;
                    }
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    F.delete();
                }
            }
            m2750j();
            try {
                Object newInstance2 = Array.newInstance(f3214b, 1);
                Array.set(newInstance2, 0, newInstance);
                return (Typeface) f3217e.invoke((Object) null, new Object[]{newInstance2});
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    /* renamed from: b */
    public Typeface mo4000b(Context context, CancellationSignal cancellationSignal, C0332c6.C0335c[] cVarArr, int i) {
        FileInputStream fileInputStream;
        if (cVarArr.length < 1) {
            return null;
        }
        C0332c6.C0335c cVar = (C0332c6.C0335c) C1221n5.m3844e(cVarArr, i, new C1221n5.C1222a(this));
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(cVar.f1452a, "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            try {
                File i2 = mo4001i(openFileDescriptor);
                if (i2 != null) {
                    if (i2.canRead()) {
                        Typeface createFromFile = Typeface.createFromFile(i2);
                        openFileDescriptor.close();
                        return createFromFile;
                    }
                }
                fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                Typeface c = mo4576c(context, fileInputStream);
                fileInputStream.close();
                openFileDescriptor.close();
                return c;
            } catch (Throwable th) {
                openFileDescriptor.close();
                throw th;
            }
        } catch (IOException unused) {
            return null;
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
        throw th;
    }

    /* renamed from: i */
    public final File mo4001i(ParcelFileDescriptor parcelFileDescriptor) {
        try {
            String readlink = Os.readlink("/proc/self/fd/" + parcelFileDescriptor.getFd());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
            return null;
        } catch (ErrnoException unused) {
            return null;
        }
    }
}
