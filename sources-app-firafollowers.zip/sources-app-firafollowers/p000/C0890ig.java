package p000;

import java.util.HashMap;
import java.util.Map;
import p000.C0833hg;

/* renamed from: ig */
public class C0890ig {

    /* renamed from: b */
    public static final C0833hg.C0834a<?> f3264b = new C0891a();

    /* renamed from: a */
    public final Map<Class<?>, C0833hg.C0834a<?>> f3265a = new HashMap();

    /* renamed from: ig$a */
    public class C0891a implements C0833hg.C0834a<Object> {
        /* renamed from: a */
        public Class<Object> mo1983a() {
            throw new UnsupportedOperationException("Not implemented");
        }

        /* renamed from: b */
        public C0833hg<Object> mo1984b(Object obj) {
            return new C0892b(obj);
        }
    }

    /* renamed from: ig$b */
    public static final class C0892b implements C0833hg<Object> {

        /* renamed from: a */
        public final Object f3266a;

        public C0892b(Object obj) {
            this.f3266a = obj;
        }

        /* renamed from: a */
        public Object mo1979a() {
            return this.f3266a;
        }

        /* renamed from: b */
        public void mo1980b() {
        }
    }
}
