package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import p000.C0332c6;
import p000.C0534d6;

@SuppressLint({"NewApi"})
/* renamed from: h5 */
public class C0808h5 {

    /* renamed from: a */
    public static final C1221n5 f3033a;

    /* renamed from: b */
    public static final C0328c4<String, Typeface> f3034b = new C0328c4<>(16);

    static {
        C1221n5 n5Var;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            n5Var = new C1161m5();
        } else if (i >= 28) {
            n5Var = new C1062l5();
        } else if (i >= 26) {
            n5Var = new C1000k5();
        } else {
            if (i >= 24) {
                Method method = C0939j5.f3362d;
                if (method == null) {
                    Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
                }
                if (method != null) {
                    n5Var = new C0939j5();
                }
            }
            n5Var = i >= 21 ? new C0871i5() : new C1221n5();
        }
        f3033a = n5Var;
    }

    /* renamed from: a */
    public static Typeface m2599a(Context context, C2049x4 x4Var, Resources resources, int i, int i2, C0329c5 c5Var, Handler handler, boolean z) {
        Typeface typeface;
        if (x4Var instanceof C0008a5) {
            C0008a5 a5Var = (C0008a5) x4Var;
            boolean z2 = true;
            if (!z ? c5Var != null : a5Var.f24c != 0) {
                z2 = false;
            }
            int i3 = z ? a5Var.f23b : -1;
            C2115y5 y5Var = a5Var.f22a;
            C0328c4<String, Typeface> c4Var = C0332c6.f1445a;
            String str = y5Var.f6855e + "-" + i2;
            typeface = C0332c6.f1445a.mo1840a(str);
            if (typeface != null) {
                if (c5Var != null) {
                    c5Var.mo1846c(typeface);
                }
            } else if (!z2 || i3 != -1) {
                C2193z5 z5Var = new C2193z5(context, y5Var, i2, str);
                typeface = null;
                if (z2) {
                    try {
                        typeface = ((C0332c6.C0336d) C0332c6.f1446b.mo2951b(z5Var, i3)).f1457a;
                    } catch (InterruptedException unused) {
                    }
                } else {
                    C0009a6 a6Var = c5Var == null ? null : new C0009a6(c5Var, handler);
                    synchronized (C0332c6.f1447c) {
                        C0604e4<String, ArrayList<C0534d6.C0537c<C0332c6.C0336d>>> e4Var = C0332c6.f1448d;
                        ArrayList orDefault = e4Var.getOrDefault(str, null);
                        if (orDefault == null) {
                            if (a6Var != null) {
                                ArrayList arrayList = new ArrayList();
                                arrayList.add(a6Var);
                                e4Var.put(str, arrayList);
                            }
                            C0534d6 d6Var = C0332c6.f1446b;
                            C0261b6 b6Var = new C0261b6(str);
                            Objects.requireNonNull(d6Var);
                            d6Var.mo2950a(new C0608e6(d6Var, z5Var, new Handler(), b6Var));
                        } else if (a6Var != null) {
                            orDefault.add(a6Var);
                        }
                    }
                }
            } else {
                C0332c6.C0336d b = C0332c6.m1274b(context, y5Var, i2);
                if (c5Var != null) {
                    int i4 = b.f1458b;
                    if (i4 == 0) {
                        c5Var.mo1845b(b.f1457a, handler);
                    } else {
                        c5Var.mo1844a(i4, handler);
                    }
                }
                typeface = b.f1457a;
            }
        } else {
            typeface = f3033a.mo3999a(context, (C2111y4) x4Var, resources, i2);
            if (c5Var != null) {
                if (typeface != null) {
                    c5Var.mo1845b(typeface, handler);
                } else {
                    c5Var.mo1844a(-3, handler);
                }
            }
        }
        if (typeface != null) {
            f3034b.mo1841b(m2601c(resources, i, i2), typeface);
        }
        return typeface;
    }

    /* renamed from: b */
    public static Typeface m2600b(Context context, Resources resources, int i, String str, int i2) {
        Typeface d = f3033a.mo4254d(context, resources, i, str, i2);
        if (d != null) {
            f3034b.mo1841b(m2601c(resources, i, i2), d);
        }
        return d;
    }

    /* renamed from: c */
    public static String m2601c(Resources resources, int i, int i2) {
        return resources.getResourcePackageName(i) + "-" + i + "-" + i2;
    }
}
