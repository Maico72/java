package p000;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import p000.C2210zd;

/* renamed from: he */
public class C0830he implements C2210zd.C2212b {

    /* renamed from: a */
    public final Map<String, List<C2210zd<?>>> f3083a = new HashMap();

    /* renamed from: b */
    public final C0352ce f3084b;

    /* renamed from: c */
    public final C1332od f3085c;

    /* renamed from: d */
    public final BlockingQueue<C2210zd<?>> f3086d;

    public C0830he(C1332od odVar, BlockingQueue<C2210zd<?>> blockingQueue, C0352ce ceVar) {
        this.f3084b = ceVar;
        this.f3085c = odVar;
        this.f3086d = blockingQueue;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0039, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0054, code lost:
        return false;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized boolean mo3928a(p000.C2210zd<?> r6) {
        /*
            r5 = this;
            monitor-enter(r5)
            java.lang.String r0 = r6.mo6839g()     // Catch:{ all -> 0x0058 }
            java.util.Map<java.lang.String, java.util.List<zd<?>>> r1 = r5.f3083a     // Catch:{ all -> 0x0058 }
            boolean r1 = r1.containsKey(r0)     // Catch:{ all -> 0x0058 }
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L_0x003a
            java.util.Map<java.lang.String, java.util.List<zd<?>>> r1 = r5.f3083a     // Catch:{ all -> 0x0058 }
            java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x0058 }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x0058 }
            if (r1 != 0) goto L_0x001e
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x0058 }
            r1.<init>()     // Catch:{ all -> 0x0058 }
        L_0x001e:
            java.lang.String r4 = "waiting-for-response"
            r6.mo6835a(r4)     // Catch:{ all -> 0x0058 }
            r1.add(r6)     // Catch:{ all -> 0x0058 }
            java.util.Map<java.lang.String, java.util.List<zd<?>>> r6 = r5.f3083a     // Catch:{ all -> 0x0058 }
            r6.put(r0, r1)     // Catch:{ all -> 0x0058 }
            boolean r6 = p000.C0746ge.f2867a     // Catch:{ all -> 0x0058 }
            if (r6 == 0) goto L_0x0038
            java.lang.String r6 = "Request for cacheKey=%s is in flight, putting on hold."
            java.lang.Object[] r1 = new java.lang.Object[r2]     // Catch:{ all -> 0x0058 }
            r1[r3] = r0     // Catch:{ all -> 0x0058 }
            p000.C0746ge.m2471b(r6, r1)     // Catch:{ all -> 0x0058 }
        L_0x0038:
            monitor-exit(r5)
            return r2
        L_0x003a:
            java.util.Map<java.lang.String, java.util.List<zd<?>>> r1 = r5.f3083a     // Catch:{ all -> 0x0058 }
            r4 = 0
            r1.put(r0, r4)     // Catch:{ all -> 0x0058 }
            java.lang.Object r1 = r6.f7177h     // Catch:{ all -> 0x0058 }
            monitor-enter(r1)     // Catch:{ all -> 0x0058 }
            r6.f7185p = r5     // Catch:{ all -> 0x0055 }
            monitor-exit(r1)     // Catch:{ all -> 0x0055 }
            boolean r6 = p000.C0746ge.f2867a     // Catch:{ all -> 0x0058 }
            if (r6 == 0) goto L_0x0053
            java.lang.String r6 = "new request, sending to network %s"
            java.lang.Object[] r1 = new java.lang.Object[r2]     // Catch:{ all -> 0x0058 }
            r1[r3] = r0     // Catch:{ all -> 0x0058 }
            p000.C0746ge.m2471b(r6, r1)     // Catch:{ all -> 0x0058 }
        L_0x0053:
            monitor-exit(r5)
            return r3
        L_0x0055:
            r6 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0055 }
            throw r6     // Catch:{ all -> 0x0058 }
        L_0x0058:
            r6 = move-exception
            monitor-exit(r5)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0830he.mo3928a(zd):boolean");
    }

    /* renamed from: b */
    public synchronized void mo3929b(C2210zd<?> zdVar) {
        BlockingQueue<C2210zd<?>> blockingQueue;
        String g = zdVar.mo6839g();
        List remove = this.f3083a.remove(g);
        if (remove != null && !remove.isEmpty()) {
            if (C0746ge.f2867a) {
                C0746ge.m2473d("%d waiting requests for cacheKey=%s; resend to network", Integer.valueOf(remove.size()), g);
            }
            C2210zd zdVar2 = (C2210zd) remove.remove(0);
            this.f3083a.put(g, remove);
            synchronized (zdVar2.f7177h) {
                zdVar2.f7185p = this;
            }
            if (!(this.f3085c == null || (blockingQueue = this.f3086d) == null)) {
                try {
                    blockingQueue.put(zdVar2);
                } catch (InterruptedException e) {
                    C0746ge.m2472c("Couldn't add request to queue. %s", e.toString());
                    Thread.currentThread().interrupt();
                    C1332od odVar = this.f3085c;
                    odVar.f4513h = true;
                    odVar.interrupt();
                }
            }
        }
        return;
    }
}
