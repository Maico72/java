package p000;

import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import p000.C0785gm;
import p000.C1859ue;

/* renamed from: af */
public class C0051af implements ComponentCallbacks2, C1622qm {

    /* renamed from: n */
    public static final C1455pn f166n;

    /* renamed from: d */
    public final C1798te f167d;

    /* renamed from: e */
    public final Context f168e;

    /* renamed from: f */
    public final C1454pm f169f;

    /* renamed from: g */
    public final C1950vm f170g;

    /* renamed from: h */
    public final C1875um f171h;

    /* renamed from: i */
    public final C2087xm f172i = new C2087xm();

    /* renamed from: j */
    public final Runnable f173j;

    /* renamed from: k */
    public final C0785gm f174k;

    /* renamed from: l */
    public final CopyOnWriteArrayList<C1353on<Object>> f175l;

    /* renamed from: m */
    public C1455pn f176m;

    /* renamed from: af$a */
    public class C0052a implements Runnable {
        public C0052a() {
        }

        public void run() {
            C0051af afVar = C0051af.this;
            afVar.f169f.mo3402a(afVar);
        }
    }

    /* renamed from: af$b */
    public class C0053b implements C0785gm.C0786a {

        /* renamed from: a */
        public final C1950vm f178a;

        public C0053b(C1950vm vmVar) {
            this.f178a = vmVar;
        }
    }

    static {
        C1455pn pnVar = (C1455pn) new C1455pn().mo4286c(Bitmap.class);
        pnVar.f3653w = true;
        f166n = pnVar;
        ((C1455pn) new C1455pn().mo4286c(C1452pl.class)).f3653w = true;
        C1455pn pnVar2 = (C1455pn) ((C1455pn) ((C1455pn) new C1455pn().mo4288d(C0696fh.f2751b)).mo4292h(C2066xe.LOW)).mo4297l(true);
    }

    public C0051af(C1798te teVar, C1454pm pmVar, C1875um umVar, Context context) {
        C1455pn pnVar;
        C1950vm vmVar = new C1950vm();
        C0845hm hmVar = teVar.f5955j;
        C0052a aVar = new C0052a();
        this.f173j = aVar;
        this.f167d = teVar;
        this.f169f = pmVar;
        this.f171h = umVar;
        this.f170g = vmVar;
        this.f168e = context;
        Context applicationContext = context.getApplicationContext();
        C0053b bVar = new C0053b(vmVar);
        Objects.requireNonNull((C0973jm) hmVar);
        boolean z = C1901v4.m5332a(applicationContext, "android.permission.ACCESS_NETWORK_STATE") == 0;
        if (Log.isLoggable("ConnectivityMonitor", 3)) {
            Log.d("ConnectivityMonitor", z ? "ACCESS_NETWORK_STATE permission granted, registering connectivity monitor" : "ACCESS_NETWORK_STATE permission missing, cannot register connectivity monitor");
        }
        C0785gm imVar = z ? new C0900im(applicationContext, bVar) : new C1682rm();
        this.f174k = imVar;
        if (C1624qo.m4657h()) {
            C1624qo.m4655f().post(aVar);
        } else {
            pmVar.mo3402a(this);
        }
        pmVar.mo3402a(imVar);
        this.f175l = new CopyOnWriteArrayList<>(teVar.f5951f.f6374e);
        C1933ve veVar = teVar.f5951f;
        synchronized (veVar) {
            if (veVar.f6379j == null) {
                Objects.requireNonNull((C1859ue.C1860a) veVar.f6373d);
                C1455pn pnVar2 = new C1455pn();
                pnVar2.f3653w = true;
                veVar.f6379j = pnVar2;
            }
            pnVar = veVar.f6379j;
        }
        synchronized (this) {
            C1455pn pnVar3 = (C1455pn) pnVar.clone();
            if (pnVar3.f3653w) {
                if (!pnVar3.f3655y) {
                    throw new IllegalStateException("You cannot auto lock an already locked options object, try clone() first");
                }
            }
            pnVar3.f3655y = true;
            pnVar3.f3653w = true;
            this.f176m = pnVar3;
        }
        synchronized (teVar.f5956k) {
            if (!teVar.f5956k.contains(this)) {
                teVar.f5956k.add(this);
            } else {
                throw new IllegalStateException("Cannot register already registered manager");
            }
        }
    }

    /* renamed from: e */
    public synchronized void mo108e() {
        mo113n();
        this.f172i.mo108e();
    }

    /* renamed from: i */
    public synchronized void mo109i() {
        mo114o();
        this.f172i.mo109i();
    }

    /* renamed from: k */
    public synchronized void mo110k() {
        this.f172i.mo110k();
        for (T l : C1624qo.m4654e(this.f172i.f6807d)) {
            mo111l(l);
        }
        this.f172i.f6807d.clear();
        C1950vm vmVar = this.f170g;
        Iterator it = ((ArrayList) C1624qo.m4654e(vmVar.f6408a)).iterator();
        while (it.hasNext()) {
            vmVar.mo6274a((C1197mn) it.next());
        }
        vmVar.f6409b.clear();
        this.f169f.mo3403b(this);
        this.f169f.mo3403b(this.f174k);
        C1624qo.m4655f().removeCallbacks(this.f173j);
        C1798te teVar = this.f167d;
        synchronized (teVar.f5956k) {
            if (teVar.f5956k.contains(this)) {
                teVar.f5956k.remove(this);
            } else {
                throw new IllegalStateException("Cannot unregister not yet registered manager");
            }
        }
    }

    /* renamed from: l */
    public void mo111l(C0214ao<?> aoVar) {
        boolean z;
        if (aoVar != null) {
            boolean p = mo118p(aoVar);
            C1197mn f = aoVar.mo1432f();
            if (!p) {
                C1798te teVar = this.f167d;
                synchronized (teVar.f5956k) {
                    Iterator<C0051af> it = teVar.f5956k.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            if (it.next().mo118p(aoVar)) {
                                z = true;
                                break;
                            }
                        } else {
                            z = false;
                            break;
                        }
                    }
                }
                if (!z && f != null) {
                    aoVar.mo1435j((C1197mn) null);
                    f.clear();
                }
            }
        }
    }

    /* renamed from: m */
    public C2216ze<Drawable> mo112m(String str) {
        return new C2216ze(this.f167d, this, Drawable.class, this.f168e).mo6858w(str);
    }

    /* renamed from: n */
    public synchronized void mo113n() {
        C1950vm vmVar = this.f170g;
        vmVar.f6410c = true;
        Iterator it = ((ArrayList) C1624qo.m4654e(vmVar.f6408a)).iterator();
        while (it.hasNext()) {
            C1197mn mnVar = (C1197mn) it.next();
            if (mnVar.isRunning()) {
                mnVar.mo4456e();
                vmVar.f6409b.add(mnVar);
            }
        }
    }

    /* renamed from: o */
    public synchronized void mo114o() {
        C1950vm vmVar = this.f170g;
        vmVar.f6410c = false;
        Iterator it = ((ArrayList) C1624qo.m4654e(vmVar.f6408a)).iterator();
        while (it.hasNext()) {
            C1197mn mnVar = (C1197mn) it.next();
            if (!mnVar.mo4460i() && !mnVar.isRunning()) {
                mnVar.mo4457f();
            }
        }
        vmVar.f6409b.clear();
    }

    public void onConfigurationChanged(Configuration configuration) {
    }

    public void onLowMemory() {
    }

    public void onTrimMemory(int i) {
    }

    /* renamed from: p */
    public synchronized boolean mo118p(C0214ao<?> aoVar) {
        C1197mn f = aoVar.mo1432f();
        if (f == null) {
            return true;
        }
        if (!this.f170g.mo6274a(f)) {
            return false;
        }
        this.f172i.f6807d.remove(aoVar);
        aoVar.mo1435j((C1197mn) null);
        return true;
    }

    public synchronized String toString() {
        return super.toString() + "{tracker=" + this.f170g + ", treeNode=" + this.f171h + "}";
    }
}
