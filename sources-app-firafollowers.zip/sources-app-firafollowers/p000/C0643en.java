package p000;

import java.util.ArrayList;
import java.util.List;

/* renamed from: en */
public class C0643en {

    /* renamed from: a */
    public final List<C0644a<?>> f2610a = new ArrayList();

    /* renamed from: en$a */
    public static final class C0644a<T> {

        /* renamed from: a */
        public final Class<T> f2611a;

        /* renamed from: b */
        public final C1253nf<T> f2612b;

        public C0644a(Class<T> cls, C1253nf<T> nfVar) {
            this.f2611a = cls;
            this.f2612b = nfVar;
        }
    }
}
