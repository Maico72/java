package p000;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;

/* renamed from: gd */
public class C0744gd extends C0684fd {

    /* renamed from: d */
    public final SparseIntArray f2856d;

    /* renamed from: e */
    public final Parcel f2857e;

    /* renamed from: f */
    public final int f2858f;

    /* renamed from: g */
    public final int f2859g;

    /* renamed from: h */
    public final String f2860h;

    /* renamed from: i */
    public int f2861i;

    /* renamed from: j */
    public int f2862j;

    /* renamed from: k */
    public int f2863k;

    public C0744gd(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new C2047x3(), new C2047x3(), new C2047x3());
    }

    public C0744gd(Parcel parcel, int i, int i2, String str, C2047x3<String, Method> x3Var, C2047x3<String, Method> x3Var2, C2047x3<String, Class> x3Var3) {
        super(x3Var, x3Var2, x3Var3);
        this.f2856d = new SparseIntArray();
        this.f2861i = -1;
        this.f2862j = 0;
        this.f2863k = -1;
        this.f2857e = parcel;
        this.f2858f = i;
        this.f2859g = i2;
        this.f2862j = i;
        this.f2860h = str;
    }

    /* renamed from: a */
    public void mo3554a() {
        int i = this.f2861i;
        if (i >= 0) {
            int i2 = this.f2856d.get(i);
            int dataPosition = this.f2857e.dataPosition();
            this.f2857e.setDataPosition(i2);
            this.f2857e.writeInt(dataPosition - i2);
            this.f2857e.setDataPosition(dataPosition);
        }
    }

    /* renamed from: b */
    public C0684fd mo3555b() {
        Parcel parcel = this.f2857e;
        int dataPosition = parcel.dataPosition();
        int i = this.f2862j;
        if (i == this.f2858f) {
            i = this.f2859g;
        }
        return new C0744gd(parcel, dataPosition, i, C1012kd.m3204m(new StringBuilder(), this.f2860h, "  "), this.f2730a, this.f2731b, this.f2732c);
    }

    /* renamed from: f */
    public boolean mo3559f() {
        return this.f2857e.readInt() != 0;
    }

    /* renamed from: g */
    public byte[] mo3560g() {
        int readInt = this.f2857e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f2857e.readByteArray(bArr);
        return bArr;
    }

    /* renamed from: h */
    public CharSequence mo3561h() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f2857e);
    }

    /* renamed from: i */
    public boolean mo3562i(int i) {
        while (this.f2862j < this.f2859g) {
            int i2 = this.f2863k;
            if (i2 == i) {
                return true;
            }
            if (String.valueOf(i2).compareTo(String.valueOf(i)) > 0) {
                return false;
            }
            this.f2857e.setDataPosition(this.f2862j);
            int readInt = this.f2857e.readInt();
            this.f2863k = this.f2857e.readInt();
            this.f2862j += readInt;
        }
        return this.f2863k == i;
    }

    /* renamed from: j */
    public int mo3563j() {
        return this.f2857e.readInt();
    }

    /* renamed from: l */
    public <T extends Parcelable> T mo3565l() {
        return this.f2857e.readParcelable(C0744gd.class.getClassLoader());
    }

    /* renamed from: n */
    public String mo3567n() {
        return this.f2857e.readString();
    }

    /* renamed from: p */
    public void mo3569p(int i) {
        mo3554a();
        this.f2861i = i;
        this.f2856d.put(i, this.f2857e.dataPosition());
        this.f2857e.writeInt(0);
        this.f2857e.writeInt(i);
    }

    /* renamed from: q */
    public void mo3570q(boolean z) {
        this.f2857e.writeInt(z ? 1 : 0);
    }

    /* renamed from: r */
    public void mo3571r(byte[] bArr) {
        if (bArr != null) {
            this.f2857e.writeInt(bArr.length);
            this.f2857e.writeByteArray(bArr);
            return;
        }
        this.f2857e.writeInt(-1);
    }

    /* renamed from: s */
    public void mo3572s(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f2857e, 0);
    }

    /* renamed from: t */
    public void mo3573t(int i) {
        this.f2857e.writeInt(i);
    }

    /* renamed from: u */
    public void mo3574u(Parcelable parcelable) {
        this.f2857e.writeParcelable(parcelable, 0);
    }

    /* renamed from: v */
    public void mo3575v(String str) {
        this.f2857e.writeString(str);
    }
}
