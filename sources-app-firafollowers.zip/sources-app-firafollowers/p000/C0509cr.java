package p000;

/* renamed from: cr */
public final class C0509cr {

    /* renamed from: a */
    public static final char[] f2097a = ((char[]) C0217ar.f1120a.clone());

    /* renamed from: b */
    public static final C0509cr f2098b = new C0509cr();

    static {
        C0217ar.f1121b.clone();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0031, code lost:
        r14 = r7 + 1;
        r7 = r0.charAt(r7);
        r15 = r2[r7];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0039, code lost:
        if (r15 >= 0) goto L_0x0051;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x003b, code lost:
        r10[1] = 'u';
        r11 = f2097a;
        r10[4] = r11[r7 >> 4];
        r10[5] = r11[r7 & 15];
        r12 = 6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0051, code lost:
        r10[1] = (char) r15;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0054, code lost:
        r7 = r9 + r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0057, code lost:
        if (r7 <= r1.length) goto L_0x0071;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0059, code lost:
        r7 = r1.length - r9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x005b, code lost:
        if (r7 <= 0) goto L_0x0060;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x005d, code lost:
        java.lang.System.arraycopy(r10, 0, r1, r9, r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0060, code lost:
        if (r8 != null) goto L_0x0067;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0062, code lost:
        r8 = new p000.C2236zr((p000.C1628qr) null, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0067, code lost:
        r1 = r8.mo6882e();
        r12 = r12 - r7;
        java.lang.System.arraycopy(r10, r7, r1, 0, r12);
        r9 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0071, code lost:
        java.lang.System.arraycopy(r10, 0, r1, r9, r12);
        r9 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0075, code lost:
        r7 = r14;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0020, code lost:
        r12 = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0022, code lost:
        if (r10 != null) goto L_0x0031;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0024, code lost:
        r10 = new char[6];
        r10[0] = '\\';
        r10[2] = '0';
        r10[3] = '0';
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public char[] mo2796a(java.lang.String r17) {
        /*
            r16 = this;
            r0 = r17
            r1 = 120(0x78, float:1.68E-43)
            char[] r1 = new char[r1]
            int[] r2 = p000.C0217ar.f1125f
            int r3 = r2.length
            int r4 = r17.length()
            r5 = 0
            r6 = 0
            r8 = r6
            r10 = r8
            r7 = 0
            r9 = 0
        L_0x0013:
            r11 = 1
            if (r7 >= r4) goto L_0x008f
        L_0x0016:
            char r12 = r0.charAt(r7)
            if (r12 >= r3) goto L_0x0077
            r13 = r2[r12]
            if (r13 == 0) goto L_0x0077
            r12 = 2
            r13 = 6
            if (r10 != 0) goto L_0x0031
            char[] r10 = new char[r13]
            r14 = 92
            r10[r5] = r14
            r14 = 48
            r10[r12] = r14
            r15 = 3
            r10[r15] = r14
        L_0x0031:
            int r14 = r7 + 1
            char r7 = r0.charAt(r7)
            r15 = r2[r7]
            if (r15 >= 0) goto L_0x0051
            r12 = 117(0x75, float:1.64E-43)
            r10[r11] = r12
            char[] r11 = f2097a
            int r12 = r7 >> 4
            char r12 = r11[r12]
            r15 = 4
            r10[r15] = r12
            r7 = r7 & 15
            char r7 = r11[r7]
            r11 = 5
            r10[r11] = r7
            r12 = 6
            goto L_0x0054
        L_0x0051:
            char r7 = (char) r15
            r10[r11] = r7
        L_0x0054:
            int r7 = r9 + r12
            int r11 = r1.length
            if (r7 <= r11) goto L_0x0071
            int r7 = r1.length
            int r7 = r7 - r9
            if (r7 <= 0) goto L_0x0060
            java.lang.System.arraycopy(r10, r5, r1, r9, r7)
        L_0x0060:
            if (r8 != 0) goto L_0x0067
            zr r8 = new zr
            r8.<init>(r6, r1)
        L_0x0067:
            char[] r1 = r8.mo6882e()
            int r12 = r12 - r7
            java.lang.System.arraycopy(r10, r7, r1, r5, r12)
            r9 = r12
            goto L_0x0075
        L_0x0071:
            java.lang.System.arraycopy(r10, r5, r1, r9, r12)
            r9 = r7
        L_0x0075:
            r7 = r14
            goto L_0x0013
        L_0x0077:
            int r13 = r1.length
            if (r9 < r13) goto L_0x0086
            if (r8 != 0) goto L_0x0081
            zr r8 = new zr
            r8.<init>(r6, r1)
        L_0x0081:
            char[] r1 = r8.mo6882e()
            r9 = 0
        L_0x0086:
            int r13 = r9 + 1
            r1[r9] = r12
            int r7 = r7 + 1
            r9 = r13
            if (r7 < r4) goto L_0x0016
        L_0x008f:
            if (r8 != 0) goto L_0x0096
            char[] r0 = java.util.Arrays.copyOfRange(r1, r5, r9)
            return r0
        L_0x0096:
            r8.f7251g = r9
            char[] r0 = r8.f7253i
            if (r0 != 0) goto L_0x00ea
            char[] r1 = p000.C2236zr.f7244j
            java.lang.String r2 = r8.f7252h
            if (r2 == 0) goto L_0x00a7
            char[] r0 = r2.toCharArray()
            goto L_0x00e8
        L_0x00a7:
            int r3 = r8.f7246b
            if (r3 < 0) goto L_0x00ac
            goto L_0x00c0
        L_0x00ac:
            if (r3 < 0) goto L_0x00b0
            r0 = 0
            goto L_0x00be
        L_0x00b0:
            if (r0 == 0) goto L_0x00b4
            int r0 = r0.length
            goto L_0x00be
        L_0x00b4:
            if (r2 == 0) goto L_0x00bb
            int r0 = r2.length()
            goto L_0x00be
        L_0x00bb:
            int r0 = r8.f7249e
            int r0 = r0 + r9
        L_0x00be:
            if (r0 >= r11) goto L_0x00c2
        L_0x00c0:
            r0 = r1
            goto L_0x00e8
        L_0x00c2:
            char[] r0 = new char[r0]
            java.util.ArrayList<char[]> r1 = r8.f7247c
            if (r1 == 0) goto L_0x00e0
            int r1 = r1.size()
            r2 = 0
            r3 = 0
        L_0x00ce:
            if (r2 >= r1) goto L_0x00e1
            java.util.ArrayList<char[]> r4 = r8.f7247c
            java.lang.Object r4 = r4.get(r2)
            char[] r4 = (char[]) r4
            int r6 = r4.length
            java.lang.System.arraycopy(r4, r5, r0, r3, r6)
            int r3 = r3 + r6
            int r2 = r2 + 1
            goto L_0x00ce
        L_0x00e0:
            r3 = 0
        L_0x00e1:
            char[] r1 = r8.f7250f
            int r2 = r8.f7251g
            java.lang.System.arraycopy(r1, r5, r0, r3, r2)
        L_0x00e8:
            r8.f7253i = r0
        L_0x00ea:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0509cr.mo2796a(java.lang.String):char[]");
    }
}
