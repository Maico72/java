package p000;

/* renamed from: hd */
public interface C0828hd {
}
