package p000;

import java.nio.ByteBuffer;
import java.util.Objects;

/* renamed from: iy */
public class C0924iy extends C1703rz<ByteBuffer> {
    public C0924iy() {
        super(ByteBuffer.class);
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        ByteBuffer byteBuffer = (ByteBuffer) obj;
        if (byteBuffer.hasArray()) {
            int position = byteBuffer.position();
            byte[] array = byteBuffer.array();
            int arrayOffset = byteBuffer.arrayOffset() + position;
            int limit = byteBuffer.limit() - position;
            Objects.requireNonNull(mqVar);
            mqVar.mo3733j(C0978jq.f3466b, array, arrayOffset, limit);
            return;
        }
        ByteBuffer asReadOnlyBuffer = byteBuffer.asReadOnlyBuffer();
        if (asReadOnlyBuffer.position() > 0) {
            asReadOnlyBuffer.rewind();
        }
        r00 r00 = new r00(asReadOnlyBuffer);
        int remaining = asReadOnlyBuffer.remaining();
        Objects.requireNonNull(mqVar);
        mqVar.mo3732i(C0978jq.f3466b, r00, remaining);
        r00.close();
    }
}
