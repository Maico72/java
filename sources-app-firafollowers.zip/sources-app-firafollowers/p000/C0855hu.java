package p000;

import java.nio.file.Path;

/* renamed from: hu */
public class C0855hu extends C0794gu {

    /* renamed from: b */
    public final Class<?> f3161b = Path.class;

    /* renamed from: a */
    public C1462ps<?> mo3833a(Class<?> cls) {
        if (this.f3161b.isAssignableFrom(cls)) {
            return new C1037ku();
        }
        return null;
    }
}
