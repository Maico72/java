package p000;

/* renamed from: je */
public class C0961je implements C1795td {

    /* renamed from: a */
    public final C0886ie f3403a;

    /* renamed from: b */
    public final C1013ke f3404b;

    public C0961je(C0886ie ieVar) {
        C1013ke keVar = new C1013ke(4096);
        this.f3403a = ieVar;
        this.f3404b = keVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x007e  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00f9  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00fb  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00fe A[LOOP:0: B:1:0x0004->B:61:0x00fe, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x0117 A[EDGE_INSN: B:78:0x0117->B:62:0x0117 ?: BREAK  , SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1999wd mo4157a(p000.C2210zd<?> r15) {
        /*
            r14 = this;
            long r0 = android.os.SystemClock.elapsedRealtime()
        L_0x0004:
            java.util.Collections.emptyList()
            r2 = 0
            r3 = 0
            md$a r4 = r15.f7184o     // Catch:{ IOException -> 0x0067 }
            java.util.Map r4 = p000.C1401p4.m4390x(r4)     // Catch:{ IOException -> 0x0067 }
            ie r5 = r14.f3403a     // Catch:{ IOException -> 0x0067 }
            me r4 = r5.mo4035a(r15, r4)     // Catch:{ IOException -> 0x0067 }
            int r6 = r4.f4040a     // Catch:{ IOException -> 0x0064 }
            java.util.List r11 = r4.mo4609a()     // Catch:{ IOException -> 0x0064 }
            r5 = 304(0x130, float:4.26E-43)
            if (r6 != r5) goto L_0x0029
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0064 }
            long r5 = r5 - r0
            wd r15 = p000.C1439pe.m4455a(r15, r5, r11)     // Catch:{ IOException -> 0x0064 }
            return r15
        L_0x0029:
            java.io.InputStream r5 = r4.f4043d     // Catch:{ IOException -> 0x0064 }
            if (r5 == 0) goto L_0x002e
            goto L_0x002f
        L_0x002e:
            r5 = r2
        L_0x002f:
            if (r5 == 0) goto L_0x003a
            int r7 = r4.f4042c     // Catch:{ IOException -> 0x0064 }
            ke r8 = r14.f3404b     // Catch:{ IOException -> 0x0064 }
            byte[] r5 = p000.C1439pe.m4456b(r5, r7, r8)     // Catch:{ IOException -> 0x0064 }
            goto L_0x003c
        L_0x003a:
            byte[] r5 = new byte[r3]     // Catch:{ IOException -> 0x0064 }
        L_0x003c:
            r12 = r5
            long r7 = android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0061 }
            long r7 = r7 - r0
            p000.C1439pe.m4457c(r7, r15, r12, r6)     // Catch:{ IOException -> 0x0061 }
            r5 = 200(0xc8, float:2.8E-43)
            if (r6 < r5) goto L_0x005b
            r5 = 299(0x12b, float:4.19E-43)
            if (r6 > r5) goto L_0x005b
            wd r13 = new wd     // Catch:{ IOException -> 0x0061 }
            r8 = 0
            long r9 = android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0061 }
            long r9 = r9 - r0
            r5 = r13
            r7 = r12
            r5.<init>(r6, r7, r8, r9, r11)     // Catch:{ IOException -> 0x0061 }
            return r13
        L_0x005b:
            java.io.IOException r5 = new java.io.IOException     // Catch:{ IOException -> 0x0061 }
            r5.<init>()     // Catch:{ IOException -> 0x0061 }
            throw r5     // Catch:{ IOException -> 0x0061 }
        L_0x0061:
            r5 = move-exception
            r8 = r12
            goto L_0x006b
        L_0x0064:
            r5 = move-exception
            r8 = r2
            goto L_0x006b
        L_0x0067:
            r4 = move-exception
            r5 = r4
            r4 = r2
            r8 = r4
        L_0x006b:
            boolean r6 = r5 instanceof java.net.SocketTimeoutException
            r13 = 1
            r7 = 2
            if (r6 == 0) goto L_0x007e
            pe$b r3 = new pe$b
            ee r4 = new ee
            r4.<init>()
            java.lang.String r5 = "socket"
            r3.<init>(r5, r4, r2)
            goto L_0x00e3
        L_0x007e:
            boolean r6 = r5 instanceof java.net.MalformedURLException
            if (r6 != 0) goto L_0x013b
            if (r4 == 0) goto L_0x0135
            int r5 = r4.f4040a
            java.lang.Object[] r6 = new java.lang.Object[r7]
            java.lang.Integer r7 = java.lang.Integer.valueOf(r5)
            r6[r3] = r7
            java.lang.String r3 = r15.f7175f
            r6[r13] = r3
            java.lang.String r3 = "Unexpected response code %d for %s"
            p000.C0746ge.m2472c(r3, r6)
            if (r8 == 0) goto L_0x00d7
            java.util.List r12 = r4.mo4609a()
            wd r3 = new wd
            r9 = 0
            long r6 = android.os.SystemClock.elapsedRealtime()
            long r10 = r6 - r0
            r6 = r3
            r7 = r5
            r6.<init>(r7, r8, r9, r10, r12)
            r4 = 401(0x191, float:5.62E-43)
            if (r5 == r4) goto L_0x00c9
            r4 = 403(0x193, float:5.65E-43)
            if (r5 != r4) goto L_0x00b4
            goto L_0x00c9
        L_0x00b4:
            r15 = 400(0x190, float:5.6E-43)
            if (r5 < r15) goto L_0x00c3
            r15 = 499(0x1f3, float:6.99E-43)
            if (r5 <= r15) goto L_0x00bd
            goto L_0x00c3
        L_0x00bd:
            pd r15 = new pd
            r15.<init>(r3)
            throw r15
        L_0x00c3:
            de r15 = new de
            r15.<init>(r3)
            throw r15
        L_0x00c9:
            pe$b r4 = new pe$b
            ld r5 = new ld
            r5.<init>(r3)
            java.lang.String r3 = "auth"
            r4.<init>(r3, r5, r2)
            r3 = r4
            goto L_0x00e3
        L_0x00d7:
            pe$b r3 = new pe$b
            vd r4 = new vd
            r4.<init>()
            java.lang.String r5 = "network"
            r3.<init>(r5, r4, r2)
        L_0x00e3:
            qd r2 = r15.f7183n
            int r4 = r2.f5304a
            fe r5 = r3.f4876b     // Catch:{ fe -> 0x011b }
            int r6 = r2.f5305b     // Catch:{ fe -> 0x011b }
            int r6 = r6 + r13
            r2.f5305b = r6     // Catch:{ fe -> 0x011b }
            float r7 = (float) r4     // Catch:{ fe -> 0x011b }
            r8 = 1065353216(0x3f800000, float:1.0)
            float r7 = r7 * r8
            int r7 = (int) r7     // Catch:{ fe -> 0x011b }
            int r7 = r7 + r4
            r2.f5304a = r7     // Catch:{ fe -> 0x011b }
            if (r6 > r13) goto L_0x00fb
            r2 = 1
            goto L_0x00fc
        L_0x00fb:
            r2 = 0
        L_0x00fc:
            if (r2 == 0) goto L_0x0117
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.String r3 = r3.f4875a
            r5 = 0
            r2[r5] = r3
            java.lang.Integer r3 = java.lang.Integer.valueOf(r4)
            r2[r13] = r3
            java.lang.String r3 = "%s-retry [timeout=%s]"
            java.lang.String r2 = java.lang.String.format(r3, r2)
            r15.mo6835a(r2)
            goto L_0x0004
        L_0x0117:
            r0 = 2
            throw r5     // Catch:{ fe -> 0x0119 }
        L_0x0119:
            r1 = move-exception
            goto L_0x011e
        L_0x011b:
            r0 = move-exception
            r1 = r0
            r0 = 2
        L_0x011e:
            java.lang.Object[] r0 = new java.lang.Object[r0]
            java.lang.String r2 = r3.f4875a
            r3 = 0
            r0[r3] = r2
            java.lang.Integer r2 = java.lang.Integer.valueOf(r4)
            r0[r13] = r2
            java.lang.String r2 = "%s-timeout-giveup [timeout=%s]"
            java.lang.String r0 = java.lang.String.format(r2, r0)
            r15.mo6835a(r0)
            throw r1
        L_0x0135:
            xd r15 = new xd
            r15.<init>(r5)
            throw r15
        L_0x013b:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "Bad URL "
            java.lang.StringBuilder r1 = p000.C1012kd.m3195d(r1)
            java.lang.String r15 = r15.f7175f
            r1.append(r15)
            java.lang.String r15 = r1.toString()
            r0.<init>(r15, r5)
            goto L_0x0151
        L_0x0150:
            throw r0
        L_0x0151:
            goto L_0x0150
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0961je.mo4157a(zd):wd");
    }
}
