package p000;

/* renamed from: ic */
public abstract class C0884ic {
}
