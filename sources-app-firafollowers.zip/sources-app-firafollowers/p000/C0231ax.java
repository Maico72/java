package p000;

/* renamed from: ax */
public interface C0231ax {
}
