package p000;

/* renamed from: hi */
public interface C0841hi {
}
