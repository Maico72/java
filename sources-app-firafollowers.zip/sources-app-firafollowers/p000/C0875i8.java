package p000;

import android.view.View;

/* renamed from: i8 */
public abstract class C0875i8 {
    /* renamed from: b */
    public abstract View mo3761b(int i);

    /* renamed from: e */
    public abstract boolean mo3762e();
}
