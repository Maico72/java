package p000;

/* renamed from: a */
public interface C0000a {
    void cancel();
}
