package p000;

/* renamed from: hm */
public interface C0845hm {
}
