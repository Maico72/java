package p000;

import java.util.Map;
import p000.C0703fj;

/* renamed from: dj */
public interface C0570dj {

    /* renamed from: a */
    public static final C0570dj f2310a = new C0703fj(new C0703fj.C0704a().f2766a);

    /* renamed from: a */
    Map<String, String> mo3072a();
}
