package p000;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import androidx.appcompat.widget.ActionBarContainer;

/* renamed from: i1 */
public class C0863i1 extends Drawable {

    /* renamed from: a */
    public final ActionBarContainer f3182a;

    public C0863i1(ActionBarContainer actionBarContainer) {
        this.f3182a = actionBarContainer;
    }

    public void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f3182a;
        if (actionBarContainer.f321k) {
            Drawable drawable = actionBarContainer.f320j;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f318h;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        ActionBarContainer actionBarContainer2 = this.f3182a;
        Drawable drawable3 = actionBarContainer2.f319i;
        if (drawable3 != null && actionBarContainer2.f322l) {
            drawable3.draw(canvas);
        }
    }

    public int getOpacity() {
        return 0;
    }

    public void getOutline(Outline outline) {
        Drawable drawable;
        ActionBarContainer actionBarContainer = this.f3182a;
        if (actionBarContainer.f321k) {
            drawable = actionBarContainer.f320j;
            if (drawable == null) {
                return;
            }
        } else {
            drawable = actionBarContainer.f318h;
            if (drawable == null) {
                return;
            }
        }
        drawable.getOutline(outline);
    }

    public void setAlpha(int i) {
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }
}
