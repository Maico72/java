package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import p000.C0003a1;

/* renamed from: i2 */
public interface C0864i2 {
    /* renamed from: a */
    void mo3232a(Menu menu, C0003a1.C0004a aVar);

    /* renamed from: b */
    boolean mo3233b();

    /* renamed from: c */
    boolean mo3234c();

    void collapseActionView();

    /* renamed from: d */
    boolean mo3236d();

    /* renamed from: e */
    boolean mo3237e();

    /* renamed from: f */
    void mo3238f();

    /* renamed from: g */
    boolean mo3239g();

    CharSequence getTitle();

    /* renamed from: h */
    void mo3241h();

    /* renamed from: i */
    int mo3242i();

    /* renamed from: j */
    void mo3243j(int i);

    /* renamed from: k */
    void mo3244k(int i);

    /* renamed from: l */
    void mo3245l(C1898v2 v2Var);

    /* renamed from: m */
    ViewGroup mo3246m();

    /* renamed from: n */
    void mo3247n(boolean z);

    /* renamed from: o */
    Context mo3248o();

    /* renamed from: p */
    int mo3249p();

    /* renamed from: q */
    C0675f7 mo3250q(int i, long j);

    /* renamed from: r */
    void mo3251r();

    /* renamed from: s */
    boolean mo3252s();

    void setIcon(int i);

    void setIcon(Drawable drawable);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    /* renamed from: t */
    void mo3257t();

    /* renamed from: u */
    void mo3258u(boolean z);

    /* renamed from: v */
    void mo3259v(int i);
}
