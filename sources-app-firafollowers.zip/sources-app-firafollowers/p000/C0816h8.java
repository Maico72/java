package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Objects;
import p000.C0996k4;
import p000.C1409p9;

/* renamed from: h8 */
public class C0816h8 extends ComponentActivity implements C0996k4.C0998b, C0996k4.C0999c {

    /* renamed from: i */
    public final C0952j8 f3044i;

    /* renamed from: j */
    public final C1785t9 f3045j = new C1785t9(this);

    /* renamed from: k */
    public boolean f3046k;

    /* renamed from: l */
    public boolean f3047l;

    /* renamed from: m */
    public boolean f3048m = true;

    /* renamed from: n */
    public boolean f3049n;

    /* renamed from: o */
    public boolean f3050o;

    /* renamed from: p */
    public int f3051p;

    /* renamed from: q */
    public C0670f4<String> f3052q;

    /* renamed from: h8$a */
    public class C0817a extends C1097l8<C0816h8> implements C0681fa, C0320c {
        public C0817a() {
            super(C0816h8.this);
        }

        /* renamed from: a */
        public C1409p9 mo150a() {
            return C0816h8.this.f3045j;
        }

        /* renamed from: b */
        public View mo3761b(int i) {
            return C0816h8.this.findViewById(i);
        }

        /* renamed from: c */
        public OnBackPressedDispatcher mo151c() {
            return C0816h8.this.f200h;
        }

        /* renamed from: e */
        public boolean mo3762e() {
            Window window = C0816h8.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        /* renamed from: f */
        public void mo3898f(Fragment fragment) {
            C0816h8.this.mo3872o();
        }

        /* renamed from: g */
        public C0615ea mo153g() {
            return C0816h8.this.mo153g();
        }

        /* renamed from: h */
        public void mo3899h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            C0816h8.this.dump(str, (FileDescriptor) null, printWriter, strArr);
        }

        /* renamed from: i */
        public Object mo3900i() {
            return C0816h8.this;
        }

        /* renamed from: j */
        public LayoutInflater mo3901j() {
            return C0816h8.this.getLayoutInflater().cloneInContext(C0816h8.this);
        }

        /* renamed from: k */
        public int mo3902k() {
            Window window = C0816h8.this.getWindow();
            if (window == null) {
                return 0;
            }
            return window.getAttributes().windowAnimations;
        }

        /* renamed from: l */
        public boolean mo3903l() {
            return C0816h8.this.getWindow() != null;
        }

        /* JADX INFO: finally extract failed */
        /* renamed from: m */
        public void mo3904m(Fragment fragment, String[] strArr, int i) {
            C0816h8 h8Var = C0816h8.this;
            Objects.requireNonNull(h8Var);
            if (i == -1) {
                C0996k4.m3155d(h8Var, strArr, i);
                return;
            }
            C0816h8.m2610l(i);
            try {
                h8Var.f3049n = true;
                C0996k4.m3155d(h8Var, strArr, ((h8Var.mo3870k(fragment) + 1) << 16) + (i & 65535));
                h8Var.f3049n = false;
            } catch (Throwable th) {
                h8Var.f3049n = false;
                throw th;
            }
        }

        /* renamed from: n */
        public boolean mo3905n(Fragment fragment) {
            return !C0816h8.this.isFinishing();
        }

        /* renamed from: o */
        public void mo3906o(Fragment fragment, Intent intent, int i, Bundle bundle) {
            C0816h8 h8Var = C0816h8.this;
            h8Var.f3050o = true;
            if (i == -1) {
                try {
                    int i2 = C0996k4.f3575b;
                    h8Var.startActivityForResult(intent, -1, bundle);
                } catch (Throwable th) {
                    h8Var.f3050o = false;
                    throw th;
                }
            } else {
                C0816h8.m2610l(i);
                int k = ((h8Var.mo3870k(fragment) + 1) << 16) + (i & 65535);
                int i3 = C0996k4.f3575b;
                h8Var.startActivityForResult(intent, k, bundle);
            }
            h8Var.f3050o = false;
        }

        /* renamed from: p */
        public void mo3907p() {
            C0816h8.this.mo3893p();
        }
    }

    public C0816h8() {
        C0817a aVar = new C0817a();
        C1401p4.m4358e(aVar, "callbacks == null");
        this.f3044i = new C0952j8(aVar);
    }

    /* renamed from: l */
    public static void m2610l(int i) {
        if ((i & -65536) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    /* renamed from: n */
    public static boolean m2611n(C1166m8 m8Var, C1409p9.C1411b bVar) {
        boolean z = false;
        for (Fragment next : m8Var.mo4596c()) {
            if (next != null) {
                if (next.f658S.f5891b.compareTo(C1409p9.C1411b.STARTED) >= 0) {
                    next.f658S.mo5980f(bVar);
                    z = true;
                }
                C1097l8 l8Var = next.f680v;
                if ((l8Var == null ? null : l8Var.mo3900i()) != null) {
                    z |= m2611n(next.mo816k(), bVar);
                }
            }
        }
        return z;
    }

    /* renamed from: b */
    public final void mo3868b(int i) {
        if (!this.f3049n && i != -1) {
            m2610l(i);
        }
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f3046k);
        printWriter.print(" mResumed=");
        printWriter.print(this.f3047l);
        printWriter.print(" mStopped=");
        printWriter.print(this.f3048m);
        if (getApplication() != null) {
            C0741ga.m2445b(this).mo3766a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f3044i.f3386a.f3851h.mo4756P(str, fileDescriptor, printWriter, strArr);
    }

    /* renamed from: k */
    public final int mo3870k(Fragment fragment) {
        if (this.f3052q.mo3492i() < 65534) {
            while (true) {
                C0670f4<String> f4Var = this.f3052q;
                int i = this.f3051p;
                if (f4Var.f2673d) {
                    f4Var.mo3485c();
                }
                if (C0007a4.m17a(f4Var.f2674e, f4Var.f2676g, i) >= 0) {
                    this.f3051p = (this.f3051p + 1) % 65534;
                } else {
                    int i2 = this.f3051p;
                    this.f3052q.mo3490g(i2, fragment.f666h);
                    this.f3051p = (this.f3051p + 1) % 65534;
                    return i2;
                }
            }
        } else {
            throw new IllegalStateException("Too many pending Fragment activity results.");
        }
    }

    /* renamed from: m */
    public C1166m8 mo3871m() {
        return this.f3044i.f3386a.f3851h;
    }

    /* renamed from: o */
    public void mo3872o() {
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        this.f3044i.mo4150a();
        int i3 = i >> 16;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String d = this.f3052q.mo3487d(i4);
            this.f3052q.mo3491h(i4);
            if (d == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.f3044i.f3386a.f3851h.mo4763W(d) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + d);
            }
        } else {
            int i5 = C0996k4.f3575b;
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f3044i.mo4150a();
        this.f3044i.f3386a.f3851h.mo4788n(configuration);
    }

    public void onCreate(Bundle bundle) {
        C1097l8<?> l8Var = this.f3044i.f3386a;
        l8Var.f3851h.mo4774g(l8Var, l8Var, (Fragment) null);
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            C1097l8<?> l8Var2 = this.f3044i.f3386a;
            if (l8Var2 instanceof C0681fa) {
                l8Var2.f3851h.mo4787m0(parcelable);
                if (bundle.containsKey("android:support:next_request_index")) {
                    this.f3051p = bundle.getInt("android:support:next_request_index");
                    int[] intArray = bundle.getIntArray("android:support:request_indicies");
                    String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                    if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                        Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                    } else {
                        this.f3052q = new C0670f4<>(intArray.length);
                        for (int i = 0; i < intArray.length; i++) {
                            this.f3052q.mo3490g(intArray[i], stringArray[i]);
                        }
                    }
                }
            } else {
                throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
            }
        }
        if (this.f3052q == null) {
            this.f3052q = new C0670f4<>(10);
            this.f3051p = 0;
        }
        super.onCreate(bundle);
        this.f3045j.mo5979d(C1409p9.C1410a.ON_CREATE);
        this.f3044i.f3386a.f3851h.mo4794p();
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        if (i != 0) {
            return super.onCreatePanelMenu(i, menu);
        }
        boolean onCreatePanelMenu = super.onCreatePanelMenu(i, menu);
        C0952j8 j8Var = this.f3044i;
        return onCreatePanelMenu | j8Var.f3386a.f3851h.mo4796q(menu, getMenuInflater());
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View onCreateView = this.f3044i.f3386a.f3851h.onCreateView(view, str, context, attributeSet);
        return onCreateView == null ? super.onCreateView(view, str, context, attributeSet) : onCreateView;
    }

    public void onDestroy() {
        super.onDestroy();
        this.f3044i.f3386a.f3851h.mo4798r();
        this.f3045j.mo5979d(C1409p9.C1410a.ON_DESTROY);
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.f3044i.f3386a.f3851h.mo4800s();
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.f3044i.f3386a.f3851h.mo4749I(menuItem);
        }
        if (i != 6) {
            return false;
        }
        return this.f3044i.f3386a.f3851h.mo4790o(menuItem);
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.f3044i.f3386a.f3851h.mo4802t(z);
    }

    public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent intent) {
        super.onNewIntent(intent);
        this.f3044i.mo4150a();
    }

    public void onPanelClosed(int i, Menu menu) {
        if (i == 0) {
            this.f3044i.f3386a.f3851h.mo4750J(menu);
        }
        super.onPanelClosed(i, menu);
    }

    public void onPause() {
        super.onPause();
        this.f3047l = false;
        this.f3044i.f3386a.f3851h.mo4754N(3);
        this.f3045j.mo5979d(C1409p9.C1410a.ON_PAUSE);
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.f3044i.f3386a.f3851h.mo4752L(z);
    }

    public void onPostResume() {
        super.onPostResume();
        this.f3045j.mo5979d(C1409p9.C1410a.ON_RESUME);
        C1230n8 n8Var = this.f3044i.f3386a.f3851h;
        n8Var.f4235x = false;
        n8Var.f4236y = false;
        n8Var.mo4754N(4);
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        if (i == 0) {
            return super.onPreparePanel(0, view, menu) | this.f3044i.f3386a.f3851h.mo4753M(menu);
        }
        return super.onPreparePanel(i, view, menu);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f3044i.mo4150a();
        int i2 = (i >> 16) & 65535;
        if (i2 != 0) {
            int i3 = i2 - 1;
            String d = this.f3052q.mo3487d(i3);
            this.f3052q.mo3491h(i3);
            if (d == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            Fragment W = this.f3044i.f3386a.f3851h.mo4763W(d);
            if (W == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + d);
                return;
            }
            W.mo86N(i & 65535, strArr, iArr);
        }
    }

    public void onResume() {
        super.onResume();
        this.f3047l = true;
        this.f3044i.mo4150a();
        this.f3044i.f3386a.f3851h.mo4759S();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        do {
        } while (m2611n(mo3871m(), C1409p9.C1411b.CREATED));
        this.f3045j.mo5979d(C1409p9.C1410a.ON_STOP);
        Parcelable n0 = this.f3044i.f3386a.f3851h.mo4789n0();
        if (n0 != null) {
            bundle.putParcelable("android:support:fragments", n0);
        }
        if (this.f3052q.mo3492i() > 0) {
            bundle.putInt("android:support:next_request_index", this.f3051p);
            int[] iArr = new int[this.f3052q.mo3492i()];
            String[] strArr = new String[this.f3052q.mo3492i()];
            for (int i = 0; i < this.f3052q.mo3492i(); i++) {
                iArr[i] = this.f3052q.mo3489f(i);
                strArr[i] = this.f3052q.mo3493j(i);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    public void onStart() {
        super.onStart();
        this.f3048m = false;
        if (!this.f3046k) {
            this.f3046k = true;
            C1230n8 n8Var = this.f3044i.f3386a.f3851h;
            n8Var.f4235x = false;
            n8Var.f4236y = false;
            n8Var.mo4754N(2);
        }
        this.f3044i.mo4150a();
        this.f3044i.f3386a.f3851h.mo4759S();
        this.f3045j.mo5979d(C1409p9.C1410a.ON_START);
        C1230n8 n8Var2 = this.f3044i.f3386a.f3851h;
        n8Var2.f4235x = false;
        n8Var2.f4236y = false;
        n8Var2.mo4754N(3);
    }

    public void onStateNotSaved() {
        this.f3044i.mo4150a();
    }

    public void onStop() {
        super.onStop();
        this.f3048m = true;
        do {
        } while (m2611n(mo3871m(), C1409p9.C1411b.CREATED));
        C1230n8 n8Var = this.f3044i.f3386a.f3851h;
        n8Var.f4236y = true;
        n8Var.mo4754N(2);
        this.f3045j.mo5979d(C1409p9.C1410a.ON_STOP);
    }

    @Deprecated
    /* renamed from: p */
    public void mo3893p() {
        invalidateOptionsMenu();
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i) {
        if (!this.f3050o && i != -1) {
            m2610l(i);
        }
        super.startActivityForResult(intent, i);
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i, Bundle bundle) {
        if (!this.f3050o && i != -1) {
            m2610l(i);
        }
        super.startActivityForResult(intent, i, bundle);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        if (i != -1) {
            m2610l(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        if (i != -1) {
            m2610l(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View onCreateView = this.f3044i.f3386a.f3851h.onCreateView((View) null, str, context, attributeSet);
        return onCreateView == null ? super.onCreateView(str, context, attributeSet) : onCreateView;
    }
}
