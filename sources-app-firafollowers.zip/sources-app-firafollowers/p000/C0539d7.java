package p000;

import android.view.View;
import p000.C0010a7;

/* renamed from: d7 */
public class C0539d7 extends C0010a7.C0012b<Boolean> {
    public C0539d7(int i, Class cls, int i2) {
        super(i, cls, i2);
    }

    /* renamed from: a */
    public Object mo30a(View view) {
        return Boolean.valueOf(view.isAccessibilityHeading());
    }
}
