package p000;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: eb */
public class C0616eb extends C0682fb {
    public C0616eb(RecyclerView.C0162m mVar) {
        super(mVar, (C0544db) null);
    }

    /* renamed from: b */
    public int mo2971b(View view) {
        return this.f2724a.mo1108C(view) + ((RecyclerView.C0167n) view.getLayoutParams()).bottomMargin;
    }

    /* renamed from: c */
    public int mo2972c(View view) {
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
        return this.f2724a.mo1112F(view) + nVar.topMargin + nVar.bottomMargin;
    }

    /* renamed from: d */
    public int mo2973d(View view) {
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
        return this.f2724a.mo1114G(view) + nVar.leftMargin + nVar.rightMargin;
    }

    /* renamed from: e */
    public int mo2974e(View view) {
        return this.f2724a.mo1118I(view) - ((RecyclerView.C0167n) view.getLayoutParams()).topMargin;
    }

    /* renamed from: f */
    public int mo2975f() {
        return this.f2724a.f880p;
    }

    /* renamed from: g */
    public int mo2976g() {
        RecyclerView.C0162m mVar = this.f2724a;
        return mVar.f880p - mVar.mo1130O();
    }

    /* renamed from: h */
    public int mo2977h() {
        return this.f2724a.mo1130O();
    }

    /* renamed from: i */
    public int mo2978i() {
        return this.f2724a.f878n;
    }

    /* renamed from: j */
    public int mo2979j() {
        return this.f2724a.f877m;
    }

    /* renamed from: k */
    public int mo2980k() {
        return this.f2724a.mo1133R();
    }

    /* renamed from: l */
    public int mo2981l() {
        RecyclerView.C0162m mVar = this.f2724a;
        return (mVar.f880p - mVar.mo1133R()) - this.f2724a.mo1130O();
    }

    /* renamed from: n */
    public int mo2982n(View view) {
        this.f2724a.mo1143Y(view, true, this.f2726c);
        return this.f2726c.bottom;
    }

    /* renamed from: o */
    public int mo2983o(View view) {
        this.f2724a.mo1143Y(view, true, this.f2726c);
        return this.f2726c.top;
    }

    /* renamed from: p */
    public void mo2984p(int i) {
        this.f2724a.mo1152f0(i);
    }
}
