package p000;

import java.util.ArrayList;
import java.util.List;

/* renamed from: jn */
public class C0974jn {

    /* renamed from: a */
    public final List<C0975a<?>> f3460a = new ArrayList();

    /* renamed from: jn$a */
    public static final class C0975a<T> {

        /* renamed from: a */
        public final Class<T> f3461a;

        /* renamed from: b */
        public final C0288bg<T> f3462b;

        public C0975a(Class<T> cls, C0288bg<T> bgVar) {
            this.f3461a = cls;
            this.f3462b = bgVar;
        }
    }

    /* renamed from: a */
    public synchronized <Z> C0288bg<Z> mo4181a(Class<Z> cls) {
        int size = this.f3460a.size();
        for (int i = 0; i < size; i++) {
            C0975a aVar = this.f3460a.get(i);
            if (aVar.f3461a.isAssignableFrom(cls)) {
                return aVar.f3462b;
            }
        }
        return null;
    }
}
