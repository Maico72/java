package p000;

import java.security.MessageDigest;
import java.util.Objects;

/* renamed from: go */
public final class C0788go implements C2005wf {

    /* renamed from: b */
    public final Object f2980b;

    public C0788go(Object obj) {
        Objects.requireNonNull(obj, "Argument must not be null");
        this.f2980b = obj;
    }

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
        messageDigest.update(this.f2980b.toString().getBytes(C2005wf.f6654a));
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0788go) {
            return this.f2980b.equals(((C0788go) obj).f2980b);
        }
        return false;
    }

    public int hashCode() {
        return this.f2980b.hashCode();
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("ObjectKey{object=");
        d.append(this.f2980b);
        d.append('}');
        return d.toString();
    }
}
