package p000;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: ed */
public class C0622ed extends C0550dd {

    /* renamed from: m */
    public static final PorterDuff.Mode f2524m = PorterDuff.Mode.SRC_IN;

    /* renamed from: e */
    public C0630h f2525e;

    /* renamed from: f */
    public PorterDuffColorFilter f2526f;

    /* renamed from: g */
    public ColorFilter f2527g;

    /* renamed from: h */
    public boolean f2528h;

    /* renamed from: i */
    public boolean f2529i;

    /* renamed from: j */
    public final float[] f2530j;

    /* renamed from: k */
    public final Matrix f2531k;

    /* renamed from: l */
    public final Rect f2532l;

    /* renamed from: ed$b */
    public static class C0624b extends C0628f {
        public C0624b() {
        }

        public C0624b(C0624b bVar) {
            super(bVar);
        }

        /* renamed from: c */
        public boolean mo3340c() {
            return true;
        }
    }

    /* renamed from: ed$c */
    public static class C0625c extends C0628f {

        /* renamed from: e */
        public int[] f2533e;

        /* renamed from: f */
        public C1980w4 f2534f;

        /* renamed from: g */
        public float f2535g = 0.0f;

        /* renamed from: h */
        public C1980w4 f2536h;

        /* renamed from: i */
        public float f2537i = 1.0f;

        /* renamed from: j */
        public float f2538j = 1.0f;

        /* renamed from: k */
        public float f2539k = 0.0f;

        /* renamed from: l */
        public float f2540l = 1.0f;

        /* renamed from: m */
        public float f2541m = 0.0f;

        /* renamed from: n */
        public Paint.Cap f2542n = Paint.Cap.BUTT;

        /* renamed from: o */
        public Paint.Join f2543o = Paint.Join.MITER;

        /* renamed from: p */
        public float f2544p = 4.0f;

        public C0625c() {
        }

        public C0625c(C0625c cVar) {
            super(cVar);
            this.f2533e = cVar.f2533e;
            this.f2534f = cVar.f2534f;
            this.f2535g = cVar.f2535g;
            this.f2537i = cVar.f2537i;
            this.f2536h = cVar.f2536h;
            this.f2560c = cVar.f2560c;
            this.f2538j = cVar.f2538j;
            this.f2539k = cVar.f2539k;
            this.f2540l = cVar.f2540l;
            this.f2541m = cVar.f2541m;
            this.f2542n = cVar.f2542n;
            this.f2543o = cVar.f2543o;
            this.f2544p = cVar.f2544p;
        }

        /* renamed from: a */
        public boolean mo3341a() {
            return this.f2536h.mo6425c() || this.f2534f.mo6425c();
        }

        /* renamed from: b */
        public boolean mo3342b(int[] iArr) {
            return this.f2534f.mo6426d(iArr) | this.f2536h.mo6426d(iArr);
        }

        public float getFillAlpha() {
            return this.f2538j;
        }

        public int getFillColor() {
            return this.f2536h.f6578c;
        }

        public float getStrokeAlpha() {
            return this.f2537i;
        }

        public int getStrokeColor() {
            return this.f2534f.f6578c;
        }

        public float getStrokeWidth() {
            return this.f2535g;
        }

        public float getTrimPathEnd() {
            return this.f2540l;
        }

        public float getTrimPathOffset() {
            return this.f2541m;
        }

        public float getTrimPathStart() {
            return this.f2539k;
        }

        public void setFillAlpha(float f) {
            this.f2538j = f;
        }

        public void setFillColor(int i) {
            this.f2536h.f6578c = i;
        }

        public void setStrokeAlpha(float f) {
            this.f2537i = f;
        }

        public void setStrokeColor(int i) {
            this.f2534f.f6578c = i;
        }

        public void setStrokeWidth(float f) {
            this.f2535g = f;
        }

        public void setTrimPathEnd(float f) {
            this.f2540l = f;
        }

        public void setTrimPathOffset(float f) {
            this.f2541m = f;
        }

        public void setTrimPathStart(float f) {
            this.f2539k = f;
        }
    }

    /* renamed from: ed$d */
    public static class C0626d extends C0627e {

        /* renamed from: a */
        public final Matrix f2545a;

        /* renamed from: b */
        public final ArrayList<C0627e> f2546b;

        /* renamed from: c */
        public float f2547c;

        /* renamed from: d */
        public float f2548d;

        /* renamed from: e */
        public float f2549e;

        /* renamed from: f */
        public float f2550f;

        /* renamed from: g */
        public float f2551g;

        /* renamed from: h */
        public float f2552h;

        /* renamed from: i */
        public float f2553i;

        /* renamed from: j */
        public final Matrix f2554j;

        /* renamed from: k */
        public int f2555k;

        /* renamed from: l */
        public int[] f2556l;

        /* renamed from: m */
        public String f2557m;

        public C0626d() {
            super((C0623a) null);
            this.f2545a = new Matrix();
            this.f2546b = new ArrayList<>();
            this.f2547c = 0.0f;
            this.f2548d = 0.0f;
            this.f2549e = 0.0f;
            this.f2550f = 1.0f;
            this.f2551g = 1.0f;
            this.f2552h = 0.0f;
            this.f2553i = 0.0f;
            this.f2554j = new Matrix();
            this.f2557m = null;
        }

        public C0626d(C0626d dVar, C2047x3<String, Object> x3Var) {
            super((C0623a) null);
            C0628f fVar;
            this.f2545a = new Matrix();
            this.f2546b = new ArrayList<>();
            this.f2547c = 0.0f;
            this.f2548d = 0.0f;
            this.f2549e = 0.0f;
            this.f2550f = 1.0f;
            this.f2551g = 1.0f;
            this.f2552h = 0.0f;
            this.f2553i = 0.0f;
            Matrix matrix = new Matrix();
            this.f2554j = matrix;
            this.f2557m = null;
            this.f2547c = dVar.f2547c;
            this.f2548d = dVar.f2548d;
            this.f2549e = dVar.f2549e;
            this.f2550f = dVar.f2550f;
            this.f2551g = dVar.f2551g;
            this.f2552h = dVar.f2552h;
            this.f2553i = dVar.f2553i;
            this.f2556l = dVar.f2556l;
            String str = dVar.f2557m;
            this.f2557m = str;
            this.f2555k = dVar.f2555k;
            if (str != null) {
                x3Var.put(str, this);
            }
            matrix.set(dVar.f2554j);
            ArrayList<C0627e> arrayList = dVar.f2546b;
            for (int i = 0; i < arrayList.size(); i++) {
                C0627e eVar = arrayList.get(i);
                if (eVar instanceof C0626d) {
                    this.f2546b.add(new C0626d((C0626d) eVar, x3Var));
                } else {
                    if (eVar instanceof C0625c) {
                        fVar = new C0625c((C0625c) eVar);
                    } else if (eVar instanceof C0624b) {
                        fVar = new C0624b((C0624b) eVar);
                    } else {
                        throw new IllegalStateException("Unknown object in the tree!");
                    }
                    this.f2546b.add(fVar);
                    String str2 = fVar.f2559b;
                    if (str2 != null) {
                        x3Var.put(str2, fVar);
                    }
                }
            }
        }

        /* renamed from: a */
        public boolean mo3341a() {
            for (int i = 0; i < this.f2546b.size(); i++) {
                if (this.f2546b.get(i).mo3341a()) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: b */
        public boolean mo3342b(int[] iArr) {
            boolean z = false;
            for (int i = 0; i < this.f2546b.size(); i++) {
                z |= this.f2546b.get(i).mo3342b(iArr);
            }
            return z;
        }

        /* renamed from: c */
        public final void mo3359c() {
            this.f2554j.reset();
            this.f2554j.postTranslate(-this.f2548d, -this.f2549e);
            this.f2554j.postScale(this.f2550f, this.f2551g);
            this.f2554j.postRotate(this.f2547c, 0.0f, 0.0f);
            this.f2554j.postTranslate(this.f2552h + this.f2548d, this.f2553i + this.f2549e);
        }

        public String getGroupName() {
            return this.f2557m;
        }

        public Matrix getLocalMatrix() {
            return this.f2554j;
        }

        public float getPivotX() {
            return this.f2548d;
        }

        public float getPivotY() {
            return this.f2549e;
        }

        public float getRotation() {
            return this.f2547c;
        }

        public float getScaleX() {
            return this.f2550f;
        }

        public float getScaleY() {
            return this.f2551g;
        }

        public float getTranslateX() {
            return this.f2552h;
        }

        public float getTranslateY() {
            return this.f2553i;
        }

        public void setPivotX(float f) {
            if (f != this.f2548d) {
                this.f2548d = f;
                mo3359c();
            }
        }

        public void setPivotY(float f) {
            if (f != this.f2549e) {
                this.f2549e = f;
                mo3359c();
            }
        }

        public void setRotation(float f) {
            if (f != this.f2547c) {
                this.f2547c = f;
                mo3359c();
            }
        }

        public void setScaleX(float f) {
            if (f != this.f2550f) {
                this.f2550f = f;
                mo3359c();
            }
        }

        public void setScaleY(float f) {
            if (f != this.f2551g) {
                this.f2551g = f;
                mo3359c();
            }
        }

        public void setTranslateX(float f) {
            if (f != this.f2552h) {
                this.f2552h = f;
                mo3359c();
            }
        }

        public void setTranslateY(float f) {
            if (f != this.f2553i) {
                this.f2553i = f;
                mo3359c();
            }
        }
    }

    /* renamed from: ed$e */
    public static abstract class C0627e {
        public C0627e() {
        }

        public C0627e(C0623a aVar) {
        }

        /* renamed from: a */
        public boolean mo3341a() {
            return false;
        }

        /* renamed from: b */
        public boolean mo3342b(int[] iArr) {
            return false;
        }
    }

    /* renamed from: ed$f */
    public static abstract class C0628f extends C0627e {

        /* renamed from: a */
        public C0734g5[] f2558a = null;

        /* renamed from: b */
        public String f2559b;

        /* renamed from: c */
        public int f2560c = 0;

        /* renamed from: d */
        public int f2561d;

        public C0628f() {
            super((C0623a) null);
        }

        public C0628f(C0628f fVar) {
            super((C0623a) null);
            this.f2559b = fVar.f2559b;
            this.f2561d = fVar.f2561d;
            this.f2558a = C1401p4.m4386t(fVar.f2558a);
        }

        /* renamed from: c */
        public boolean mo3340c() {
            return false;
        }

        public C0734g5[] getPathData() {
            return this.f2558a;
        }

        public String getPathName() {
            return this.f2559b;
        }

        public void setPathData(C0734g5[] g5VarArr) {
            if (!C1401p4.m4352b(this.f2558a, g5VarArr)) {
                this.f2558a = C1401p4.m4386t(g5VarArr);
                return;
            }
            C0734g5[] g5VarArr2 = this.f2558a;
            for (int i = 0; i < g5VarArr.length; i++) {
                g5VarArr2[i].f2831a = g5VarArr[i].f2831a;
                for (int i2 = 0; i2 < g5VarArr[i].f2832b.length; i2++) {
                    g5VarArr2[i].f2832b[i2] = g5VarArr[i].f2832b[i2];
                }
            }
        }
    }

    /* renamed from: ed$g */
    public static class C0629g {

        /* renamed from: q */
        public static final Matrix f2562q = new Matrix();

        /* renamed from: a */
        public final Path f2563a;

        /* renamed from: b */
        public final Path f2564b;

        /* renamed from: c */
        public final Matrix f2565c;

        /* renamed from: d */
        public Paint f2566d;

        /* renamed from: e */
        public Paint f2567e;

        /* renamed from: f */
        public PathMeasure f2568f;

        /* renamed from: g */
        public int f2569g;

        /* renamed from: h */
        public final C0626d f2570h;

        /* renamed from: i */
        public float f2571i;

        /* renamed from: j */
        public float f2572j;

        /* renamed from: k */
        public float f2573k;

        /* renamed from: l */
        public float f2574l;

        /* renamed from: m */
        public int f2575m;

        /* renamed from: n */
        public String f2576n;

        /* renamed from: o */
        public Boolean f2577o;

        /* renamed from: p */
        public final C2047x3<String, Object> f2578p;

        public C0629g() {
            this.f2565c = new Matrix();
            this.f2571i = 0.0f;
            this.f2572j = 0.0f;
            this.f2573k = 0.0f;
            this.f2574l = 0.0f;
            this.f2575m = 255;
            this.f2576n = null;
            this.f2577o = null;
            this.f2578p = new C2047x3<>();
            this.f2570h = new C0626d();
            this.f2563a = new Path();
            this.f2564b = new Path();
        }

        public C0629g(C0629g gVar) {
            this.f2565c = new Matrix();
            this.f2571i = 0.0f;
            this.f2572j = 0.0f;
            this.f2573k = 0.0f;
            this.f2574l = 0.0f;
            this.f2575m = 255;
            this.f2576n = null;
            this.f2577o = null;
            C2047x3<String, Object> x3Var = new C2047x3<>();
            this.f2578p = x3Var;
            this.f2570h = new C0626d(gVar.f2570h, x3Var);
            this.f2563a = new Path(gVar.f2563a);
            this.f2564b = new Path(gVar.f2564b);
            this.f2571i = gVar.f2571i;
            this.f2572j = gVar.f2572j;
            this.f2573k = gVar.f2573k;
            this.f2574l = gVar.f2574l;
            this.f2569g = gVar.f2569g;
            this.f2575m = gVar.f2575m;
            this.f2576n = gVar.f2576n;
            String str = gVar.f2576n;
            if (str != null) {
                x3Var.put(str, this);
            }
            this.f2577o = gVar.f2577o;
        }

        /* JADX WARNING: type inference failed for: r11v0 */
        /* JADX WARNING: type inference failed for: r11v1, types: [boolean] */
        /* JADX WARNING: type inference failed for: r11v2 */
        /* renamed from: a */
        public final void mo3379a(C0626d dVar, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            C0629g gVar;
            C0629g gVar2 = this;
            C0626d dVar2 = dVar;
            Canvas canvas2 = canvas;
            ColorFilter colorFilter2 = colorFilter;
            dVar2.f2545a.set(matrix);
            dVar2.f2545a.preConcat(dVar2.f2554j);
            canvas.save();
            ? r11 = 0;
            int i3 = 0;
            while (i3 < dVar2.f2546b.size()) {
                C0627e eVar = dVar2.f2546b.get(i3);
                if (eVar instanceof C0626d) {
                    mo3379a((C0626d) eVar, dVar2.f2545a, canvas, i, i2, colorFilter);
                } else if (eVar instanceof C0628f) {
                    C0628f fVar = (C0628f) eVar;
                    float f = ((float) i) / gVar2.f2573k;
                    float f2 = ((float) i2) / gVar2.f2574l;
                    float min = Math.min(f, f2);
                    Matrix matrix2 = dVar2.f2545a;
                    gVar2.f2565c.set(matrix2);
                    gVar2.f2565c.postScale(f, f2);
                    float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
                    matrix2.mapVectors(fArr);
                    float f3 = min;
                    float f4 = (fArr[r11] * fArr[3]) - (fArr[1] * fArr[2]);
                    float max = Math.max((float) Math.hypot((double) fArr[r11], (double) fArr[1]), (float) Math.hypot((double) fArr[2], (double) fArr[3]));
                    float abs = max > 0.0f ? Math.abs(f4) / max : 0.0f;
                    if (abs == 0.0f) {
                        gVar = this;
                    } else {
                        gVar = this;
                        Path path = gVar.f2563a;
                        Objects.requireNonNull(fVar);
                        path.reset();
                        C0734g5[] g5VarArr = fVar.f2558a;
                        if (g5VarArr != null) {
                            C0734g5.m2433b(g5VarArr, path);
                        }
                        Path path2 = gVar.f2563a;
                        gVar.f2564b.reset();
                        if (fVar.mo3340c()) {
                            gVar.f2564b.setFillType(fVar.f2560c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                            gVar.f2564b.addPath(path2, gVar.f2565c);
                            canvas2.clipPath(gVar.f2564b);
                        } else {
                            C0625c cVar = (C0625c) fVar;
                            float f5 = cVar.f2539k;
                            if (!(f5 == 0.0f && cVar.f2540l == 1.0f)) {
                                float f6 = cVar.f2541m;
                                float f7 = (f5 + f6) % 1.0f;
                                float f8 = (cVar.f2540l + f6) % 1.0f;
                                if (gVar.f2568f == null) {
                                    gVar.f2568f = new PathMeasure();
                                }
                                gVar.f2568f.setPath(gVar.f2563a, r11);
                                float length = gVar.f2568f.getLength();
                                float f9 = f7 * length;
                                float f10 = f8 * length;
                                path2.reset();
                                if (f9 > f10) {
                                    gVar.f2568f.getSegment(f9, length, path2, true);
                                    gVar.f2568f.getSegment(0.0f, f10, path2, true);
                                } else {
                                    gVar.f2568f.getSegment(f9, f10, path2, true);
                                }
                                path2.rLineTo(0.0f, 0.0f);
                            }
                            gVar.f2564b.addPath(path2, gVar.f2565c);
                            C1980w4 w4Var = cVar.f2536h;
                            if (w4Var.mo6424b() || w4Var.f6578c != 0) {
                                C1980w4 w4Var2 = cVar.f2536h;
                                if (gVar.f2567e == null) {
                                    Paint paint = new Paint(1);
                                    gVar.f2567e = paint;
                                    paint.setStyle(Paint.Style.FILL);
                                }
                                Paint paint2 = gVar.f2567e;
                                if (w4Var2.mo6424b()) {
                                    Shader shader = w4Var2.f6576a;
                                    shader.setLocalMatrix(gVar.f2565c);
                                    paint2.setShader(shader);
                                    paint2.setAlpha(Math.round(cVar.f2538j * 255.0f));
                                } else {
                                    paint2.setShader((Shader) null);
                                    paint2.setAlpha(255);
                                    int i4 = w4Var2.f6578c;
                                    float f11 = cVar.f2538j;
                                    PorterDuff.Mode mode = C0622ed.f2524m;
                                    paint2.setColor((i4 & 16777215) | (((int) (((float) Color.alpha(i4)) * f11)) << 24));
                                }
                                paint2.setColorFilter(colorFilter2);
                                gVar.f2564b.setFillType(cVar.f2560c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                                canvas2.drawPath(gVar.f2564b, paint2);
                            }
                            C1980w4 w4Var3 = cVar.f2534f;
                            if (w4Var3.mo6424b() || w4Var3.f6578c != 0) {
                                C1980w4 w4Var4 = cVar.f2534f;
                                if (gVar.f2566d == null) {
                                    Paint paint3 = new Paint(1);
                                    gVar.f2566d = paint3;
                                    paint3.setStyle(Paint.Style.STROKE);
                                }
                                Paint paint4 = gVar.f2566d;
                                Paint.Join join = cVar.f2543o;
                                if (join != null) {
                                    paint4.setStrokeJoin(join);
                                }
                                Paint.Cap cap = cVar.f2542n;
                                if (cap != null) {
                                    paint4.setStrokeCap(cap);
                                }
                                paint4.setStrokeMiter(cVar.f2544p);
                                if (w4Var4.mo6424b()) {
                                    Shader shader2 = w4Var4.f6576a;
                                    shader2.setLocalMatrix(gVar.f2565c);
                                    paint4.setShader(shader2);
                                    paint4.setAlpha(Math.round(cVar.f2537i * 255.0f));
                                } else {
                                    paint4.setShader((Shader) null);
                                    paint4.setAlpha(255);
                                    int i5 = w4Var4.f6578c;
                                    float f12 = cVar.f2537i;
                                    PorterDuff.Mode mode2 = C0622ed.f2524m;
                                    paint4.setColor((i5 & 16777215) | (((int) (((float) Color.alpha(i5)) * f12)) << 24));
                                }
                                paint4.setColorFilter(colorFilter2);
                                paint4.setStrokeWidth(cVar.f2535g * abs * f3);
                                canvas2.drawPath(gVar.f2564b, paint4);
                            }
                        }
                    }
                    i3++;
                    gVar2 = gVar;
                    r11 = 0;
                }
                int i6 = i;
                int i7 = i2;
                gVar = gVar2;
                i3++;
                gVar2 = gVar;
                r11 = 0;
            }
            C0629g gVar3 = gVar2;
            canvas.restore();
        }

        public float getAlpha() {
            return ((float) getRootAlpha()) / 255.0f;
        }

        public int getRootAlpha() {
            return this.f2575m;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public void setRootAlpha(int i) {
            this.f2575m = i;
        }
    }

    /* renamed from: ed$h */
    public static class C0630h extends Drawable.ConstantState {

        /* renamed from: a */
        public int f2579a;

        /* renamed from: b */
        public C0629g f2580b;

        /* renamed from: c */
        public ColorStateList f2581c;

        /* renamed from: d */
        public PorterDuff.Mode f2582d;

        /* renamed from: e */
        public boolean f2583e;

        /* renamed from: f */
        public Bitmap f2584f;

        /* renamed from: g */
        public ColorStateList f2585g;

        /* renamed from: h */
        public PorterDuff.Mode f2586h;

        /* renamed from: i */
        public int f2587i;

        /* renamed from: j */
        public boolean f2588j;

        /* renamed from: k */
        public boolean f2589k;

        /* renamed from: l */
        public Paint f2590l;

        public C0630h() {
            this.f2581c = null;
            this.f2582d = C0622ed.f2524m;
            this.f2580b = new C0629g();
        }

        public C0630h(C0630h hVar) {
            this.f2581c = null;
            this.f2582d = C0622ed.f2524m;
            if (hVar != null) {
                this.f2579a = hVar.f2579a;
                C0629g gVar = new C0629g(hVar.f2580b);
                this.f2580b = gVar;
                if (hVar.f2580b.f2567e != null) {
                    gVar.f2567e = new Paint(hVar.f2580b.f2567e);
                }
                if (hVar.f2580b.f2566d != null) {
                    this.f2580b.f2566d = new Paint(hVar.f2580b.f2566d);
                }
                this.f2581c = hVar.f2581c;
                this.f2582d = hVar.f2582d;
                this.f2583e = hVar.f2583e;
            }
        }

        /* renamed from: a */
        public boolean mo3384a() {
            C0629g gVar = this.f2580b;
            if (gVar.f2577o == null) {
                gVar.f2577o = Boolean.valueOf(gVar.f2570h.mo3341a());
            }
            return gVar.f2577o.booleanValue();
        }

        /* renamed from: b */
        public void mo3385b(int i, int i2) {
            this.f2584f.eraseColor(0);
            Canvas canvas = new Canvas(this.f2584f);
            C0629g gVar = this.f2580b;
            gVar.mo3379a(gVar.f2570h, C0629g.f2562q, canvas, i, i2, (ColorFilter) null);
        }

        public int getChangingConfigurations() {
            return this.f2579a;
        }

        public Drawable newDrawable() {
            return new C0622ed(this);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0622ed(this);
        }
    }

    /* renamed from: ed$i */
    public static class C0631i extends Drawable.ConstantState {

        /* renamed from: a */
        public final Drawable.ConstantState f2591a;

        public C0631i(Drawable.ConstantState constantState) {
            this.f2591a = constantState;
        }

        public boolean canApplyTheme() {
            return this.f2591a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.f2591a.getChangingConfigurations();
        }

        public Drawable newDrawable() {
            C0622ed edVar = new C0622ed();
            edVar.f2232d = (VectorDrawable) this.f2591a.newDrawable();
            return edVar;
        }

        public Drawable newDrawable(Resources resources) {
            C0622ed edVar = new C0622ed();
            edVar.f2232d = (VectorDrawable) this.f2591a.newDrawable(resources);
            return edVar;
        }

        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            C0622ed edVar = new C0622ed();
            edVar.f2232d = (VectorDrawable) this.f2591a.newDrawable(resources, theme);
            return edVar;
        }
    }

    public C0622ed() {
        this.f2529i = true;
        this.f2530j = new float[9];
        this.f2531k = new Matrix();
        this.f2532l = new Rect();
        this.f2525e = new C0630h();
    }

    public C0622ed(C0630h hVar) {
        this.f2529i = true;
        this.f2530j = new float[9];
        this.f2531k = new Matrix();
        this.f2532l = new Rect();
        this.f2525e = hVar;
        this.f2526f = mo3313b(hVar.f2581c, hVar.f2582d);
    }

    /* renamed from: a */
    public static C0622ed m2013a(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        C0622ed edVar = new C0622ed();
        edVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return edVar;
    }

    /* renamed from: b */
    public PorterDuffColorFilter mo3313b(ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    public boolean canApplyTheme() {
        Drawable drawable = this.f2232d;
        if (drawable == null || Build.VERSION.SDK_INT < 21) {
            return false;
        }
        drawable.canApplyTheme();
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00d3, code lost:
        if ((r1 == r7.getWidth() && r3 == r6.f2584f.getHeight()) == false) goto L_0x00d5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void draw(android.graphics.Canvas r11) {
        /*
            r10 = this;
            android.graphics.drawable.Drawable r0 = r10.f2232d
            if (r0 == 0) goto L_0x0008
            r0.draw(r11)
            return
        L_0x0008:
            android.graphics.Rect r0 = r10.f2532l
            r10.copyBounds(r0)
            android.graphics.Rect r0 = r10.f2532l
            int r0 = r0.width()
            if (r0 <= 0) goto L_0x016b
            android.graphics.Rect r0 = r10.f2532l
            int r0 = r0.height()
            if (r0 > 0) goto L_0x001f
            goto L_0x016b
        L_0x001f:
            android.graphics.ColorFilter r0 = r10.f2527g
            if (r0 != 0) goto L_0x0025
            android.graphics.PorterDuffColorFilter r0 = r10.f2526f
        L_0x0025:
            android.graphics.Matrix r1 = r10.f2531k
            r11.getMatrix(r1)
            android.graphics.Matrix r1 = r10.f2531k
            float[] r2 = r10.f2530j
            r1.getValues(r2)
            float[] r1 = r10.f2530j
            r2 = 0
            r1 = r1[r2]
            float r1 = java.lang.Math.abs(r1)
            float[] r3 = r10.f2530j
            r4 = 4
            r3 = r3[r4]
            float r3 = java.lang.Math.abs(r3)
            float[] r4 = r10.f2530j
            r5 = 1
            r4 = r4[r5]
            float r4 = java.lang.Math.abs(r4)
            float[] r6 = r10.f2530j
            r7 = 3
            r6 = r6[r7]
            float r6 = java.lang.Math.abs(r6)
            r7 = 1065353216(0x3f800000, float:1.0)
            r8 = 0
            int r4 = (r4 > r8 ? 1 : (r4 == r8 ? 0 : -1))
            if (r4 != 0) goto L_0x0060
            int r4 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r4 == 0) goto L_0x0064
        L_0x0060:
            r1 = 1065353216(0x3f800000, float:1.0)
            r3 = 1065353216(0x3f800000, float:1.0)
        L_0x0064:
            android.graphics.Rect r4 = r10.f2532l
            int r4 = r4.width()
            float r4 = (float) r4
            float r4 = r4 * r1
            int r1 = (int) r4
            android.graphics.Rect r4 = r10.f2532l
            int r4 = r4.height()
            float r4 = (float) r4
            float r4 = r4 * r3
            int r3 = (int) r4
            r4 = 2048(0x800, float:2.87E-42)
            int r1 = java.lang.Math.min(r4, r1)
            int r3 = java.lang.Math.min(r4, r3)
            if (r1 <= 0) goto L_0x016b
            if (r3 > 0) goto L_0x0088
            goto L_0x016b
        L_0x0088:
            int r4 = r11.save()
            android.graphics.Rect r6 = r10.f2532l
            int r9 = r6.left
            float r9 = (float) r9
            int r6 = r6.top
            float r6 = (float) r6
            r11.translate(r9, r6)
            boolean r6 = r10.isAutoMirrored()
            if (r6 == 0) goto L_0x00a5
            int r6 = p000.C1401p4.m4392z(r10)
            if (r6 != r5) goto L_0x00a5
            r6 = 1
            goto L_0x00a6
        L_0x00a5:
            r6 = 0
        L_0x00a6:
            if (r6 == 0) goto L_0x00b7
            android.graphics.Rect r6 = r10.f2532l
            int r6 = r6.width()
            float r6 = (float) r6
            r11.translate(r6, r8)
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            r11.scale(r6, r7)
        L_0x00b7:
            android.graphics.Rect r6 = r10.f2532l
            r6.offsetTo(r2, r2)
            ed$h r6 = r10.f2525e
            android.graphics.Bitmap r7 = r6.f2584f
            if (r7 == 0) goto L_0x00d5
            int r7 = r7.getWidth()
            if (r1 != r7) goto L_0x00d2
            android.graphics.Bitmap r7 = r6.f2584f
            int r7 = r7.getHeight()
            if (r3 != r7) goto L_0x00d2
            r7 = 1
            goto L_0x00d3
        L_0x00d2:
            r7 = 0
        L_0x00d3:
            if (r7 != 0) goto L_0x00df
        L_0x00d5:
            android.graphics.Bitmap$Config r7 = android.graphics.Bitmap.Config.ARGB_8888
            android.graphics.Bitmap r7 = android.graphics.Bitmap.createBitmap(r1, r3, r7)
            r6.f2584f = r7
            r6.f2589k = r5
        L_0x00df:
            boolean r6 = r10.f2529i
            if (r6 != 0) goto L_0x00e9
            ed$h r6 = r10.f2525e
            r6.mo3385b(r1, r3)
            goto L_0x012d
        L_0x00e9:
            ed$h r6 = r10.f2525e
            boolean r7 = r6.f2589k
            if (r7 != 0) goto L_0x010d
            android.content.res.ColorStateList r7 = r6.f2585g
            android.content.res.ColorStateList r8 = r6.f2581c
            if (r7 != r8) goto L_0x010d
            android.graphics.PorterDuff$Mode r7 = r6.f2586h
            android.graphics.PorterDuff$Mode r8 = r6.f2582d
            if (r7 != r8) goto L_0x010d
            boolean r7 = r6.f2588j
            boolean r8 = r6.f2583e
            if (r7 != r8) goto L_0x010d
            int r7 = r6.f2587i
            ed$g r6 = r6.f2580b
            int r6 = r6.getRootAlpha()
            if (r7 != r6) goto L_0x010d
            r6 = 1
            goto L_0x010e
        L_0x010d:
            r6 = 0
        L_0x010e:
            if (r6 != 0) goto L_0x012d
            ed$h r6 = r10.f2525e
            r6.mo3385b(r1, r3)
            ed$h r1 = r10.f2525e
            android.content.res.ColorStateList r3 = r1.f2581c
            r1.f2585g = r3
            android.graphics.PorterDuff$Mode r3 = r1.f2582d
            r1.f2586h = r3
            ed$g r3 = r1.f2580b
            int r3 = r3.getRootAlpha()
            r1.f2587i = r3
            boolean r3 = r1.f2583e
            r1.f2588j = r3
            r1.f2589k = r2
        L_0x012d:
            ed$h r1 = r10.f2525e
            android.graphics.Rect r3 = r10.f2532l
            ed$g r6 = r1.f2580b
            int r6 = r6.getRootAlpha()
            r7 = 255(0xff, float:3.57E-43)
            if (r6 >= r7) goto L_0x013c
            r2 = 1
        L_0x013c:
            r6 = 0
            if (r2 != 0) goto L_0x0143
            if (r0 != 0) goto L_0x0143
            r0 = r6
            goto L_0x0163
        L_0x0143:
            android.graphics.Paint r2 = r1.f2590l
            if (r2 != 0) goto L_0x0151
            android.graphics.Paint r2 = new android.graphics.Paint
            r2.<init>()
            r1.f2590l = r2
            r2.setFilterBitmap(r5)
        L_0x0151:
            android.graphics.Paint r2 = r1.f2590l
            ed$g r5 = r1.f2580b
            int r5 = r5.getRootAlpha()
            r2.setAlpha(r5)
            android.graphics.Paint r2 = r1.f2590l
            r2.setColorFilter(r0)
            android.graphics.Paint r0 = r1.f2590l
        L_0x0163:
            android.graphics.Bitmap r1 = r1.f2584f
            r11.drawBitmap(r1, r6, r3, r0)
            r11.restoreToCount(r4)
        L_0x016b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0622ed.draw(android.graphics.Canvas):void");
    }

    public int getAlpha() {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            return drawable.getAlpha();
        }
        return this.f2525e.f2580b.getRootAlpha();
    }

    public int getChangingConfigurations() {
        Drawable drawable = this.f2232d;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f2525e.getChangingConfigurations();
    }

    public ColorFilter getColorFilter() {
        Drawable drawable = this.f2232d;
        if (drawable == null) {
            return this.f2527g;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            return drawable.getColorFilter();
        }
        return null;
    }

    public Drawable.ConstantState getConstantState() {
        if (this.f2232d != null && Build.VERSION.SDK_INT >= 24) {
            return new C0631i(this.f2232d.getConstantState());
        }
        this.f2525e.f2579a = getChangingConfigurations();
        return this.f2525e;
    }

    public int getIntrinsicHeight() {
        Drawable drawable = this.f2232d;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.f2525e.f2580b.f2572j;
    }

    public int getIntrinsicWidth() {
        Drawable drawable = this.f2232d;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.f2525e.f2580b.f2571i;
    }

    public int getOpacity() {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, (Resources.Theme) null);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:202:0x04e2  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00c1  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00ce  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0101  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void inflate(android.content.res.Resources r28, org.xmlpull.v1.XmlPullParser r29, android.util.AttributeSet r30, android.content.res.Resources.Theme r31) {
        /*
            r27 = this;
            r1 = r27
            r2 = r28
            r9 = r29
            r10 = r30
            r11 = r31
            android.graphics.drawable.Drawable r0 = r1.f2232d
            if (r0 == 0) goto L_0x001c
            int r3 = android.os.Build.VERSION.SDK_INT
            r4 = 21
            if (r3 < r4) goto L_0x0018
            r0.inflate(r2, r9, r10, r11)
            goto L_0x001b
        L_0x0018:
            r0.inflate(r2, r9, r10)
        L_0x001b:
            return
        L_0x001c:
            ed$h r12 = r1.f2525e
            ed$g r0 = new ed$g
            r0.<init>()
            r12.f2580b = r0
            int[] r0 = p000.C2142yc.f6921a
            android.content.res.TypedArray r3 = p000.C0532d5.m1705e(r2, r11, r10, r0)
            ed$h r4 = r1.f2525e
            ed$g r5 = r4.f2580b
            java.lang.String r0 = "tintMode"
            boolean r0 = p000.C0532d5.m1704d(r9, r0)
            r13 = 6
            r14 = -1
            if (r0 != 0) goto L_0x003b
            r0 = -1
            goto L_0x003f
        L_0x003b:
            int r0 = r3.getInt(r13, r14)
        L_0x003f:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.SRC_IN
            r15 = 9
            r8 = 5
            r7 = 3
            if (r0 == r7) goto L_0x005b
            if (r0 == r8) goto L_0x005d
            if (r0 == r15) goto L_0x0058
            switch(r0) {
                case 14: goto L_0x0055;
                case 15: goto L_0x0052;
                case 16: goto L_0x004f;
                default: goto L_0x004e;
            }
        L_0x004e:
            goto L_0x005d
        L_0x004f:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.ADD
            goto L_0x005d
        L_0x0052:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.SCREEN
            goto L_0x005d
        L_0x0055:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L_0x005d
        L_0x0058:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.SRC_ATOP
            goto L_0x005d
        L_0x005b:
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.SRC_OVER
        L_0x005d:
            r4.f2582d = r6
            java.lang.String r0 = "tint"
            boolean r0 = p000.C0532d5.m1704d(r9, r0)
            r13 = 0
            r15 = 1
            r14 = 2
            if (r0 == 0) goto L_0x00be
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r3.getValue(r15, r0)
            int r6 = r0.type
            if (r6 == r14) goto L_0x009f
            r14 = 28
            if (r6 < r14) goto L_0x0085
            r14 = 31
            if (r6 > r14) goto L_0x0085
            int r0 = r0.data
            android.content.res.ColorStateList r0 = android.content.res.ColorStateList.valueOf(r0)
            goto L_0x00bf
        L_0x0085:
            android.content.res.Resources r0 = r3.getResources()
            int r6 = r3.getResourceId(r15, r13)
            android.content.res.XmlResourceParser r6 = r0.getXml(r6)     // Catch:{ Exception -> 0x0096 }
            android.content.res.ColorStateList r0 = p000.C1401p4.m4378o(r0, r6, r11)     // Catch:{ Exception -> 0x0096 }
            goto L_0x00bf
        L_0x0096:
            r0 = move-exception
            java.lang.String r6 = "CSLCompat"
            java.lang.String r14 = "Failed to inflate ColorStateList."
            android.util.Log.e(r6, r14, r0)
            goto L_0x00be
        L_0x009f:
            java.lang.UnsupportedOperationException r2 = new java.lang.UnsupportedOperationException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Failed to resolve attribute at index "
            r3.append(r4)
            r3.append(r15)
            java.lang.String r4 = ": "
            r3.append(r4)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r2.<init>(r0)
            throw r2
        L_0x00be:
            r0 = 0
        L_0x00bf:
            if (r0 == 0) goto L_0x00c3
            r4.f2581c = r0
        L_0x00c3:
            boolean r0 = r4.f2583e
            java.lang.String r6 = "autoMirrored"
            boolean r6 = p000.C0532d5.m1704d(r9, r6)
            if (r6 != 0) goto L_0x00ce
            goto L_0x00d2
        L_0x00ce:
            boolean r0 = r3.getBoolean(r8, r0)
        L_0x00d2:
            r4.f2583e = r0
            float r0 = r5.f2573k
            java.lang.String r4 = "viewportWidth"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            r14 = 7
            if (r4 != 0) goto L_0x00e0
            goto L_0x00e4
        L_0x00e0:
            float r0 = r3.getFloat(r14, r0)
        L_0x00e4:
            r5.f2573k = r0
            float r0 = r5.f2574l
            java.lang.String r4 = "viewportHeight"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            r6 = 8
            if (r4 != 0) goto L_0x00f3
            goto L_0x00f7
        L_0x00f3:
            float r0 = r3.getFloat(r6, r0)
        L_0x00f7:
            r5.f2574l = r0
            float r4 = r5.f2573k
            r19 = 0
            int r4 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1))
            if (r4 <= 0) goto L_0x04e2
            int r0 = (r0 > r19 ? 1 : (r0 == r19 ? 0 : -1))
            if (r0 <= 0) goto L_0x04c6
            float r0 = r5.f2571i
            float r0 = r3.getDimension(r7, r0)
            r5.f2571i = r0
            float r0 = r5.f2572j
            r4 = 2
            float r0 = r3.getDimension(r4, r0)
            r5.f2572j = r0
            float r4 = r5.f2571i
            int r4 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1))
            if (r4 <= 0) goto L_0x04aa
            int r0 = (r0 > r19 ? 1 : (r0 == r19 ? 0 : -1))
            if (r0 <= 0) goto L_0x048e
            float r0 = r5.getAlpha()
            java.lang.String r4 = "alpha"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            r14 = 4
            if (r4 != 0) goto L_0x012e
            goto L_0x0132
        L_0x012e:
            float r0 = r3.getFloat(r14, r0)
        L_0x0132:
            r5.setAlpha(r0)
            java.lang.String r0 = r3.getString(r13)
            if (r0 == 0) goto L_0x0142
            r5.f2576n = r0
            x3<java.lang.String, java.lang.Object> r4 = r5.f2578p
            r4.put(r0, r5)
        L_0x0142:
            r3.recycle()
            int r0 = r27.getChangingConfigurations()
            r12.f2579a = r0
            r12.f2589k = r15
            ed$h r0 = r1.f2525e
            ed$g r5 = r0.f2580b
            java.util.ArrayDeque r4 = new java.util.ArrayDeque
            r4.<init>()
            ed$d r3 = r5.f2570h
            r4.push(r3)
            int r3 = r29.getEventType()
            int r20 = r29.getDepth()
            int r14 = r20 + 1
            r20 = 1
        L_0x0167:
            if (r3 == r15) goto L_0x0475
            int r6 = r29.getDepth()
            if (r6 >= r14) goto L_0x0171
            if (r3 == r7) goto L_0x0475
        L_0x0171:
            java.lang.String r6 = "group"
            r7 = 2
            if (r3 != r7) goto L_0x0446
            java.lang.String r3 = r29.getName()
            java.lang.Object r7 = r4.peek()
            ed$d r7 = (p000.C0622ed.C0626d) r7
            java.lang.String r8 = "path"
            boolean r8 = r8.equals(r3)
            java.lang.String r15 = "fillType"
            java.lang.String r13 = "pathData"
            if (r8 == 0) goto L_0x031c
            ed$c r8 = new ed$c
            r8.<init>()
            int[] r3 = p000.C2142yc.f6923c
            android.content.res.TypedArray r6 = p000.C0532d5.m1705e(r2, r11, r10, r3)
            r3 = 0
            r8.f2533e = r3
            boolean r13 = p000.C0532d5.m1704d(r9, r13)
            if (r13 != 0) goto L_0x01b1
            r24 = r4
            r25 = r5
            r1 = r6
            r13 = r8
            r18 = r14
            r17 = -1
            r21 = 8
            r22 = 9
            r14 = r7
            goto L_0x02ee
        L_0x01b1:
            r13 = 0
            java.lang.String r3 = r6.getString(r13)
            if (r3 == 0) goto L_0x01ba
            r8.f2559b = r3
        L_0x01ba:
            r3 = 2
            java.lang.String r13 = r6.getString(r3)
            if (r13 == 0) goto L_0x01c7
            g5[] r3 = p000.C1401p4.m4384r(r13)
            r8.f2558a = r3
        L_0x01c7:
            r13 = 1
            r20 = 0
            java.lang.String r23 = "fillColor"
            r18 = 0
            r3 = r6
            r24 = r4
            r4 = r29
            r25 = r5
            r5 = r31
            r26 = r6
            r6 = r23
            r18 = r14
            r1 = 3
            r14 = r7
            r7 = r13
            r13 = r8
            r1 = 5
            r8 = r20
            w4 r3 = p000.C0532d5.m1702b(r3, r4, r5, r6, r7, r8)
            r13.f2536h = r3
            r3 = 12
            float r4 = r13.f2538j
            java.lang.String r5 = "fillAlpha"
            boolean r5 = p000.C0532d5.m1704d(r9, r5)
            r8 = r26
            if (r5 != 0) goto L_0x01f9
            goto L_0x01fd
        L_0x01f9:
            float r4 = r8.getFloat(r3, r4)
        L_0x01fd:
            r13.f2538j = r4
            java.lang.String r3 = "strokeLineCap"
            boolean r3 = p000.C0532d5.m1704d(r9, r3)
            if (r3 != 0) goto L_0x020b
            r3 = -1
            r7 = 8
            goto L_0x0213
        L_0x020b:
            r3 = -1
            r7 = 8
            int r4 = r8.getInt(r7, r3)
            r3 = r4
        L_0x0213:
            android.graphics.Paint$Cap r4 = r13.f2542n
            if (r3 == 0) goto L_0x0224
            r5 = 1
            if (r3 == r5) goto L_0x0221
            r5 = 2
            if (r3 == r5) goto L_0x021e
            goto L_0x0226
        L_0x021e:
            android.graphics.Paint$Cap r4 = android.graphics.Paint.Cap.SQUARE
            goto L_0x0226
        L_0x0221:
            android.graphics.Paint$Cap r4 = android.graphics.Paint.Cap.ROUND
            goto L_0x0226
        L_0x0224:
            android.graphics.Paint$Cap r4 = android.graphics.Paint.Cap.BUTT
        L_0x0226:
            r13.f2542n = r4
            java.lang.String r3 = "strokeLineJoin"
            boolean r3 = p000.C0532d5.m1704d(r9, r3)
            if (r3 != 0) goto L_0x0235
            r3 = -1
            r5 = -1
            r6 = 9
            goto L_0x023c
        L_0x0235:
            r5 = -1
            r6 = 9
            int r3 = r8.getInt(r6, r5)
        L_0x023c:
            android.graphics.Paint$Join r4 = r13.f2543o
            if (r3 == 0) goto L_0x024d
            r5 = 1
            if (r3 == r5) goto L_0x024a
            r5 = 2
            if (r3 == r5) goto L_0x0247
            goto L_0x024f
        L_0x0247:
            android.graphics.Paint$Join r4 = android.graphics.Paint.Join.BEVEL
            goto L_0x024f
        L_0x024a:
            android.graphics.Paint$Join r4 = android.graphics.Paint.Join.ROUND
            goto L_0x024f
        L_0x024d:
            android.graphics.Paint$Join r4 = android.graphics.Paint.Join.MITER
        L_0x024f:
            r13.f2543o = r4
            r3 = 10
            float r4 = r13.f2544p
            java.lang.String r5 = "strokeMiterLimit"
            boolean r5 = p000.C0532d5.m1704d(r9, r5)
            if (r5 != 0) goto L_0x025e
            goto L_0x0262
        L_0x025e:
            float r4 = r8.getFloat(r3, r4)
        L_0x0262:
            r13.f2544p = r4
            r16 = 3
            r20 = 0
            java.lang.String r21 = "strokeColor"
            r3 = r8
            r4 = r29
            r17 = -1
            r5 = r31
            r22 = 9
            r6 = r21
            r21 = 8
            r7 = r16
            r1 = r8
            r8 = r20
            w4 r3 = p000.C0532d5.m1702b(r3, r4, r5, r6, r7, r8)
            r13.f2534f = r3
            r3 = 11
            float r4 = r13.f2537i
            java.lang.String r5 = "strokeAlpha"
            boolean r5 = p000.C0532d5.m1704d(r9, r5)
            if (r5 != 0) goto L_0x028f
            goto L_0x0293
        L_0x028f:
            float r4 = r1.getFloat(r3, r4)
        L_0x0293:
            r13.f2537i = r4
            float r3 = r13.f2535g
            java.lang.String r4 = "strokeWidth"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            if (r4 != 0) goto L_0x02a0
            goto L_0x02a5
        L_0x02a0:
            r4 = 4
            float r3 = r1.getFloat(r4, r3)
        L_0x02a5:
            r13.f2535g = r3
            float r3 = r13.f2540l
            java.lang.String r4 = "trimPathEnd"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            if (r4 != 0) goto L_0x02b2
            goto L_0x02b7
        L_0x02b2:
            r4 = 6
            float r3 = r1.getFloat(r4, r3)
        L_0x02b7:
            r13.f2540l = r3
            float r3 = r13.f2541m
            java.lang.String r4 = "trimPathOffset"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            if (r4 != 0) goto L_0x02c4
            goto L_0x02c9
        L_0x02c4:
            r4 = 7
            float r3 = r1.getFloat(r4, r3)
        L_0x02c9:
            r13.f2541m = r3
            float r3 = r13.f2539k
            java.lang.String r4 = "trimPathStart"
            boolean r4 = p000.C0532d5.m1704d(r9, r4)
            if (r4 != 0) goto L_0x02d6
            goto L_0x02db
        L_0x02d6:
            r4 = 5
            float r3 = r1.getFloat(r4, r3)
        L_0x02db:
            r13.f2539k = r3
            r3 = 13
            int r4 = r13.f2560c
            boolean r5 = p000.C0532d5.m1704d(r9, r15)
            if (r5 != 0) goto L_0x02e8
            goto L_0x02ec
        L_0x02e8:
            int r4 = r1.getInt(r3, r4)
        L_0x02ec:
            r13.f2560c = r4
        L_0x02ee:
            r1.recycle()
            java.util.ArrayList<ed$e> r1 = r14.f2546b
            r1.add(r13)
            java.lang.String r1 = r13.getPathName()
            if (r1 == 0) goto L_0x0308
            r1 = r25
            x3<java.lang.String, java.lang.Object> r3 = r1.f2578p
            java.lang.String r4 = r13.getPathName()
            r3.put(r4, r13)
            goto L_0x030a
        L_0x0308:
            r1 = r25
        L_0x030a:
            int r3 = r0.f2579a
            int r4 = r13.f2561d
            r3 = r3 | r4
            r0.f2579a = r3
            r4 = r24
            r6 = 0
            r7 = 5
            r8 = 1
            r13 = 2
            r15 = 4
            r20 = 0
            goto L_0x0443
        L_0x031c:
            r24 = r4
            r1 = r5
            r18 = r14
            r17 = -1
            r21 = 8
            r22 = 9
            r14 = r7
            java.lang.String r4 = "clip-path"
            boolean r4 = r4.equals(r3)
            if (r4 == 0) goto L_0x0388
            ed$b r3 = new ed$b
            r3.<init>()
            boolean r4 = p000.C0532d5.m1704d(r9, r13)
            if (r4 != 0) goto L_0x033c
            goto L_0x036b
        L_0x033c:
            int[] r4 = p000.C2142yc.f6924d
            android.content.res.TypedArray r4 = p000.C0532d5.m1705e(r2, r11, r10, r4)
            r5 = 0
            java.lang.String r6 = r4.getString(r5)
            if (r6 == 0) goto L_0x034b
            r3.f2559b = r6
        L_0x034b:
            r5 = 1
            java.lang.String r6 = r4.getString(r5)
            if (r6 == 0) goto L_0x0358
            g5[] r5 = p000.C1401p4.m4384r(r6)
            r3.f2558a = r5
        L_0x0358:
            boolean r5 = p000.C0532d5.m1704d(r9, r15)
            if (r5 != 0) goto L_0x0360
            r13 = 0
            goto L_0x0366
        L_0x0360:
            r5 = 0
            r6 = 2
            int r13 = r4.getInt(r6, r5)
        L_0x0366:
            r3.f2560c = r13
            r4.recycle()
        L_0x036b:
            java.util.ArrayList<ed$e> r4 = r14.f2546b
            r4.add(r3)
            java.lang.String r4 = r3.getPathName()
            if (r4 == 0) goto L_0x037f
            x3<java.lang.String, java.lang.Object> r4 = r1.f2578p
            java.lang.String r5 = r3.getPathName()
            r4.put(r5, r3)
        L_0x037f:
            int r4 = r0.f2579a
            int r3 = r3.f2561d
            r3 = r3 | r4
            r0.f2579a = r3
            goto L_0x043c
        L_0x0388:
            boolean r3 = r6.equals(r3)
            if (r3 == 0) goto L_0x043c
            ed$d r3 = new ed$d
            r3.<init>()
            int[] r4 = p000.C2142yc.f6922b
            android.content.res.TypedArray r4 = p000.C0532d5.m1705e(r2, r11, r10, r4)
            r5 = 0
            r3.f2556l = r5
            float r6 = r3.f2547c
            java.lang.String r7 = "rotation"
            boolean r7 = p000.C0532d5.m1704d(r9, r7)
            if (r7 != 0) goto L_0x03a8
            r7 = 5
            goto L_0x03ad
        L_0x03a8:
            r7 = 5
            float r6 = r4.getFloat(r7, r6)
        L_0x03ad:
            r3.f2547c = r6
            float r6 = r3.f2548d
            r8 = 1
            float r6 = r4.getFloat(r8, r6)
            r3.f2548d = r6
            float r6 = r3.f2549e
            r13 = 2
            float r6 = r4.getFloat(r13, r6)
            r3.f2549e = r6
            float r6 = r3.f2550f
            java.lang.String r15 = "scaleX"
            boolean r15 = p000.C0532d5.m1704d(r9, r15)
            if (r15 != 0) goto L_0x03cc
            goto L_0x03d1
        L_0x03cc:
            r15 = 3
            float r6 = r4.getFloat(r15, r6)
        L_0x03d1:
            r3.f2550f = r6
            float r6 = r3.f2551g
            java.lang.String r15 = "scaleY"
            boolean r15 = p000.C0532d5.m1704d(r9, r15)
            if (r15 != 0) goto L_0x03df
            r15 = 4
            goto L_0x03e4
        L_0x03df:
            r15 = 4
            float r6 = r4.getFloat(r15, r6)
        L_0x03e4:
            r3.f2551g = r6
            float r6 = r3.f2552h
            java.lang.String r5 = "translateX"
            boolean r5 = p000.C0532d5.m1704d(r9, r5)
            if (r5 != 0) goto L_0x03f2
            r5 = 6
            goto L_0x03f7
        L_0x03f2:
            r5 = 6
            float r6 = r4.getFloat(r5, r6)
        L_0x03f7:
            r3.f2552h = r6
            float r6 = r3.f2553i
            java.lang.String r5 = "translateY"
            boolean r5 = p000.C0532d5.m1704d(r9, r5)
            if (r5 != 0) goto L_0x0405
            r5 = 7
            goto L_0x040a
        L_0x0405:
            r5 = 7
            float r6 = r4.getFloat(r5, r6)
        L_0x040a:
            r3.f2553i = r6
            r6 = 0
            java.lang.String r5 = r4.getString(r6)
            if (r5 == 0) goto L_0x0415
            r3.f2557m = r5
        L_0x0415:
            r3.mo3359c()
            r4.recycle()
            java.util.ArrayList<ed$e> r4 = r14.f2546b
            r4.add(r3)
            r4 = r24
            r4.push(r3)
            java.lang.String r5 = r3.getGroupName()
            if (r5 == 0) goto L_0x0434
            x3<java.lang.String, java.lang.Object> r5 = r1.f2578p
            java.lang.String r14 = r3.getGroupName()
            r5.put(r14, r3)
        L_0x0434:
            int r5 = r0.f2579a
            int r3 = r3.f2555k
            r3 = r3 | r5
            r0.f2579a = r3
            goto L_0x0443
        L_0x043c:
            r4 = r24
            r6 = 0
            r7 = 5
            r8 = 1
            r13 = 2
            r15 = 4
        L_0x0443:
            r5 = 3
            r14 = 0
            goto L_0x0464
        L_0x0446:
            r1 = r5
            r18 = r14
            r5 = 3
            r7 = 5
            r8 = 1
            r13 = 2
            r14 = 0
            r15 = 4
            r17 = -1
            r21 = 8
            r22 = 9
            if (r3 != r5) goto L_0x0464
            java.lang.String r3 = r29.getName()
            boolean r3 = r6.equals(r3)
            if (r3 == 0) goto L_0x0464
            r4.pop()
        L_0x0464:
            int r3 = r29.next()
            r6 = 8
            r7 = 3
            r8 = 5
            r13 = 0
            r15 = 1
            r5 = r1
            r14 = r18
            r1 = r27
            goto L_0x0167
        L_0x0475:
            if (r20 != 0) goto L_0x0484
            android.content.res.ColorStateList r0 = r12.f2581c
            android.graphics.PorterDuff$Mode r1 = r12.f2582d
            r2 = r27
            android.graphics.PorterDuffColorFilter r0 = r2.mo3313b(r0, r1)
            r2.f2526f = r0
            return
        L_0x0484:
            r2 = r27
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r1 = "no path defined"
            r0.<init>(r1)
            throw r0
        L_0x048e:
            r2 = r1
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = r3.getPositionDescription()
            r1.append(r3)
            java.lang.String r3 = "<vector> tag requires height > 0"
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x04aa:
            r2 = r1
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = r3.getPositionDescription()
            r1.append(r3)
            java.lang.String r3 = "<vector> tag requires width > 0"
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x04c6:
            r2 = r1
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = r3.getPositionDescription()
            r1.append(r3)
            java.lang.String r3 = "<vector> tag requires viewportHeight > 0"
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x04e2:
            r2 = r1
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = r3.getPositionDescription()
            r1.append(r3)
            java.lang.String r3 = "<vector> tag requires viewportWidth > 0"
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            goto L_0x04ff
        L_0x04fe:
            throw r0
        L_0x04ff:
            goto L_0x04fe
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0622ed.inflate(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):void");
    }

    public void invalidateSelf() {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    public boolean isAutoMirrored() {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            return drawable.isAutoMirrored();
        }
        return this.f2525e.f2583e;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0019, code lost:
        r0 = r1.f2525e.f2581c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000f, code lost:
        r0 = r1.f2525e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            android.graphics.drawable.Drawable r0 = r1.f2232d
            if (r0 == 0) goto L_0x0009
            boolean r0 = r0.isStateful()
            return r0
        L_0x0009:
            boolean r0 = super.isStateful()
            if (r0 != 0) goto L_0x0028
            ed$h r0 = r1.f2525e
            if (r0 == 0) goto L_0x0026
            boolean r0 = r0.mo3384a()
            if (r0 != 0) goto L_0x0028
            ed$h r0 = r1.f2525e
            android.content.res.ColorStateList r0 = r0.f2581c
            if (r0 == 0) goto L_0x0026
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0026
            goto L_0x0028
        L_0x0026:
            r0 = 0
            goto L_0x0029
        L_0x0028:
            r0 = 1
        L_0x0029:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0622ed.isStateful():boolean");
    }

    public Drawable mutate() {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.f2528h && super.mutate() == this) {
            this.f2525e = new C0630h(this.f2525e);
            this.f2528h = true;
        }
        return this;
    }

    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    public boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z = false;
        C0630h hVar = this.f2525e;
        ColorStateList colorStateList = hVar.f2581c;
        if (!(colorStateList == null || (mode = hVar.f2582d) == null)) {
            this.f2526f = mo3313b(colorStateList, mode);
            invalidateSelf();
            z = true;
        }
        if (hVar.mo3384a()) {
            boolean b = hVar.f2580b.f2570h.mo3342b(iArr);
            hVar.f2589k |= b;
            if (b) {
                invalidateSelf();
                return true;
            }
        }
        return z;
    }

    public void scheduleSelf(Runnable runnable, long j) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    public void setAlpha(int i) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else if (this.f2525e.f2580b.getRootAlpha() != i) {
            this.f2525e.f2580b.setRootAlpha(i);
            invalidateSelf();
        }
    }

    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.setAutoMirrored(z);
        } else {
            this.f2525e.f2583e = z;
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        this.f2527g = colorFilter;
        invalidateSelf();
    }

    public void setTint(int i) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            C1401p4.m4365h0(drawable, i);
        } else {
            setTintList(ColorStateList.valueOf(i));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            C1401p4.m4367i0(drawable, colorStateList);
            return;
        }
        C0630h hVar = this.f2525e;
        if (hVar.f2581c != colorStateList) {
            hVar.f2581c = colorStateList;
            this.f2526f = mo3313b(colorStateList, hVar.f2582d);
            invalidateSelf();
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            C1401p4.m4369j0(drawable, mode);
            return;
        }
        C0630h hVar = this.f2525e;
        if (hVar.f2582d != mode) {
            hVar.f2582d = mode;
            this.f2526f = mo3313b(hVar.f2581c, mode);
            invalidateSelf();
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f2232d;
        return drawable != null ? drawable.setVisible(z, z2) : super.setVisible(z, z2);
    }

    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.f2232d;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
