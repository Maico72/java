package p000;

/* renamed from: fu */
public class C0719fu extends C1203ms {
    public C0719fu(C1200mq mqVar, String str, C0649es esVar, C0652ev evVar) {
        super(mqVar, str);
    }

    public C0719fu(C1200mq mqVar, String str, C1035ks ksVar) {
        super(mqVar, str);
    }
}
