package p000;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import p000.C1230n8;
import p000.C1906v8;

/* renamed from: f8 */
public class C0678f8 extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    /* renamed from: X */
    public Handler f2706X;

    /* renamed from: Y */
    public Runnable f2707Y = new C0679a();

    /* renamed from: Z */
    public int f2708Z = 0;

    /* renamed from: a0 */
    public int f2709a0 = 0;

    /* renamed from: b0 */
    public boolean f2710b0 = true;

    /* renamed from: c0 */
    public boolean f2711c0 = true;

    /* renamed from: d0 */
    public int f2712d0 = -1;

    /* renamed from: e0 */
    public Dialog f2713e0;

    /* renamed from: f0 */
    public boolean f2714f0;

    /* renamed from: g0 */
    public boolean f2715g0;

    /* renamed from: h0 */
    public boolean f2716h0;

    /* renamed from: f8$a */
    public class C0679a implements Runnable {
        public C0679a() {
        }

        public void run() {
            C0678f8 f8Var = C0678f8.this;
            Dialog dialog = f8Var.f2713e0;
            if (dialog != null) {
                f8Var.onDismiss(dialog);
            }
        }
    }

    /* renamed from: E */
    public void mo783E(Bundle bundle) {
        Bundle bundle2;
        this.f645F = true;
        if (this.f2711c0) {
            View view = this.f647H;
            if (view != null) {
                if (view.getParent() == null) {
                    this.f2713e0.setContentView(view);
                } else {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
            }
            C0816h8 h = mo811h();
            if (h != null) {
                this.f2713e0.setOwnerActivity(h);
            }
            this.f2713e0.setCancelable(this.f2710b0);
            this.f2713e0.setOnCancelListener(this);
            this.f2713e0.setOnDismissListener(this);
            if (bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
                this.f2713e0.onRestoreInstanceState(bundle2);
            }
        }
    }

    /* renamed from: F */
    public void mo784F(Context context) {
        super.mo784F(context);
        if (!this.f2716h0) {
            this.f2715g0 = false;
        }
    }

    /* renamed from: G */
    public void mo785G(Bundle bundle) {
        super.mo785G(bundle);
        this.f2706X = new Handler();
        this.f2711c0 = this.f684z == 0;
        if (bundle != null) {
            this.f2708Z = bundle.getInt("android:style", 0);
            this.f2709a0 = bundle.getInt("android:theme", 0);
            this.f2710b0 = bundle.getBoolean("android:cancelable", true);
            this.f2711c0 = bundle.getBoolean("android:showsDialog", this.f2711c0);
            this.f2712d0 = bundle.getInt("android:backStackId", -1);
        }
    }

    /* renamed from: J */
    public void mo787J() {
        this.f645F = true;
        Dialog dialog = this.f2713e0;
        if (dialog != null) {
            this.f2714f0 = true;
            dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
            this.f2713e0.dismiss();
            if (!this.f2715g0) {
                onDismiss(this.f2713e0);
            }
            this.f2713e0 = null;
        }
    }

    /* renamed from: K */
    public void mo788K() {
        this.f645F = true;
        if (!this.f2716h0 && !this.f2715g0) {
            this.f2715g0 = true;
        }
    }

    /* renamed from: L */
    public LayoutInflater mo789L(Bundle bundle) {
        Context context;
        if (!this.f2711c0) {
            return super.mo789L(bundle);
        }
        Dialog dialog = new Dialog(mo798W(), this.f2709a0);
        this.f2713e0 = dialog;
        if (dialog != null) {
            int i = this.f2708Z;
            if (!(i == 1 || i == 2)) {
                if (i == 3) {
                    dialog.getWindow().addFlags(24);
                }
                context = this.f2713e0.getContext();
            }
            dialog.requestWindowFeature(1);
            context = this.f2713e0.getContext();
        } else {
            context = this.f680v.f3848e;
        }
        return (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: O */
    public void mo791O(Bundle bundle) {
        Bundle onSaveInstanceState;
        Dialog dialog = this.f2713e0;
        if (!(dialog == null || (onSaveInstanceState = dialog.onSaveInstanceState()) == null)) {
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i = this.f2708Z;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.f2709a0;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.f2710b0;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.f2711c0;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.f2712d0;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    /* renamed from: Q */
    public void mo793Q() {
        this.f645F = true;
        Dialog dialog = this.f2713e0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    /* renamed from: i0 */
    public void mo3538i0(boolean z, boolean z2) {
        if (!this.f2715g0) {
            this.f2715g0 = true;
            this.f2716h0 = false;
            Dialog dialog = this.f2713e0;
            if (dialog != null) {
                dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
                this.f2713e0.dismiss();
                if (!z2) {
                    if (Looper.myLooper() == this.f2706X.getLooper()) {
                        onDismiss(this.f2713e0);
                    } else {
                        this.f2706X.post(this.f2707Y);
                    }
                }
            }
            this.f2714f0 = true;
            if (this.f2712d0 >= 0) {
                C1166m8 X = mo799X();
                int i = this.f2712d0;
                C1230n8 n8Var = (C1230n8) X;
                if (i >= 0) {
                    n8Var.mo4757Q(new C1230n8.C1239i((String) null, i, 1), false);
                    this.f2712d0 = -1;
                    return;
                }
                throw new IllegalArgumentException(C1012kd.m3199h("Bad id: ", i));
            }
            C0541d8 d8Var = new C0541d8((C1230n8) mo799X());
            C1230n8 n8Var2 = this.f679u;
            if (n8Var2 == null || n8Var2 == d8Var.f2196q) {
                d8Var.mo6214b(new C1906v8.C1907a(3, this));
                if (z) {
                    d8Var.mo2962f(true);
                } else {
                    d8Var.mo2962f(false);
                }
            } else {
                StringBuilder d = C1012kd.m3195d("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
                d.append(toString());
                d.append(" is already attached to a FragmentManager.");
                throw new IllegalStateException(d.toString());
            }
        }
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.f2714f0) {
            mo3538i0(true, true);
        }
    }
}
