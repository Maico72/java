package p000;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;

/* renamed from: f */
public abstract class C0657f {

    /* renamed from: f$a */
    public static class C0658a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public int f2620a;

        public C0658a(int i, int i2) {
            super(i, i2);
            this.f2620a = 0;
            this.f2620a = 8388627;
        }

        public C0658a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2620a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0593e.f2372b);
            this.f2620a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public C0658a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2620a = 0;
        }

        public C0658a(C0658a aVar) {
            super(aVar);
            this.f2620a = 0;
            this.f2620a = aVar.f2620a;
        }
    }

    /* renamed from: f$b */
    public interface C0659b {
        /* renamed from: a */
        void mo3421a(boolean z);
    }

    @Deprecated
    /* renamed from: f$c */
    public static abstract class C0660c {
        /* renamed from: a */
        public abstract void mo3422a();
    }

    /* renamed from: a */
    public abstract void mo3418a(boolean z);

    /* renamed from: b */
    public abstract Context mo3419b();

    /* renamed from: c */
    public abstract void mo3420c(boolean z);
}
