package p000;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Map;
import java.util.WeakHashMap;
import p000.C1226n7;

/* renamed from: ib */
public class C0882ib extends C1163m6 {

    /* renamed from: d */
    public final RecyclerView f3243d;

    /* renamed from: e */
    public final C0883a f3244e;

    /* renamed from: ib$a */
    public static class C0883a extends C1163m6 {

        /* renamed from: d */
        public final C0882ib f3245d;

        /* renamed from: e */
        public Map<View, C1163m6> f3246e = new WeakHashMap();

        public C0883a(C0882ib ibVar) {
            this.f3245d = ibVar;
        }

        /* renamed from: a */
        public boolean mo4018a(View view, AccessibilityEvent accessibilityEvent) {
            C1163m6 m6Var = this.f3246e.get(view);
            return m6Var != null ? m6Var.mo4018a(view, accessibilityEvent) : this.f4001a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        /* renamed from: b */
        public C1307o7 mo4019b(View view) {
            C1163m6 m6Var = this.f3246e.get(view);
            return m6Var != null ? m6Var.mo4019b(view) : super.mo4019b(view);
        }

        /* renamed from: c */
        public void mo772c(View view, AccessibilityEvent accessibilityEvent) {
            C1163m6 m6Var = this.f3246e.get(view);
            if (m6Var != null) {
                m6Var.mo772c(view, accessibilityEvent);
            } else {
                this.f4001a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            }
        }

        /* renamed from: d */
        public void mo773d(View view, C1226n7 n7Var) {
            if (!this.f3245d.mo4017j() && this.f3245d.f3243d.getLayoutManager() != null) {
                this.f3245d.f3243d.getLayoutManager().mo1158o0(view, n7Var);
                C1163m6 m6Var = this.f3246e.get(view);
                if (m6Var != null) {
                    m6Var.mo773d(view, n7Var);
                    return;
                }
            }
            this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
        }

        /* renamed from: e */
        public void mo2327e(View view, AccessibilityEvent accessibilityEvent) {
            C1163m6 m6Var = this.f3246e.get(view);
            if (m6Var != null) {
                m6Var.mo2327e(view, accessibilityEvent);
            } else {
                this.f4001a.onPopulateAccessibilityEvent(view, accessibilityEvent);
            }
        }

        /* renamed from: f */
        public boolean mo4020f(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            C1163m6 m6Var = this.f3246e.get(viewGroup);
            return m6Var != null ? m6Var.mo4020f(viewGroup, view, accessibilityEvent) : this.f4001a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
        }

        /* renamed from: g */
        public boolean mo774g(View view, int i, Bundle bundle) {
            if (this.f3245d.mo4017j() || this.f3245d.f3243d.getLayoutManager() == null) {
                return super.mo774g(view, i, bundle);
            }
            C1163m6 m6Var = this.f3246e.get(view);
            if (m6Var != null) {
                if (m6Var.mo774g(view, i, bundle)) {
                    return true;
                }
            } else if (super.mo774g(view, i, bundle)) {
                return true;
            }
            RecyclerView.C0162m layoutManager = this.f3245d.f3243d.getLayoutManager();
            RecyclerView.C0173s sVar = layoutManager.f866b.f804e;
            return layoutManager.mo1115G0();
        }

        /* renamed from: h */
        public void mo4021h(View view, int i) {
            C1163m6 m6Var = this.f3246e.get(view);
            if (m6Var != null) {
                m6Var.mo4021h(view, i);
            } else {
                this.f4001a.sendAccessibilityEvent(view, i);
            }
        }

        /* renamed from: i */
        public void mo4022i(View view, AccessibilityEvent accessibilityEvent) {
            C1163m6 m6Var = this.f3246e.get(view);
            if (m6Var != null) {
                m6Var.mo4022i(view, accessibilityEvent);
            } else {
                this.f4001a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
            }
        }
    }

    public C0882ib(RecyclerView recyclerView) {
        this.f3243d = recyclerView;
        C0883a aVar = this.f3244e;
        this.f3244e = aVar == null ? new C0883a(this) : aVar;
    }

    /* renamed from: c */
    public void mo772c(View view, AccessibilityEvent accessibilityEvent) {
        this.f4001a.onInitializeAccessibilityEvent(view, accessibilityEvent);
        if ((view instanceof RecyclerView) && !mo4017j()) {
            RecyclerView recyclerView = (RecyclerView) view;
            if (recyclerView.getLayoutManager() != null) {
                recyclerView.getLayoutManager().mo913m0(accessibilityEvent);
            }
        }
    }

    /* renamed from: d */
    public void mo773d(View view, C1226n7 n7Var) {
        this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
        if (!mo4017j() && this.f3243d.getLayoutManager() != null) {
            RecyclerView.C0162m layoutManager = this.f3243d.getLayoutManager();
            RecyclerView recyclerView = layoutManager.f866b;
            RecyclerView.C0173s sVar = recyclerView.f804e;
            RecyclerView.C0178w wVar = recyclerView.f813i0;
            if (recyclerView.canScrollVertically(-1) || layoutManager.f866b.canScrollHorizontally(-1)) {
                n7Var.f4196a.addAction(8192);
                n7Var.f4196a.setScrollable(true);
            }
            if (layoutManager.f866b.canScrollVertically(1) || layoutManager.f866b.canScrollHorizontally(1)) {
                n7Var.f4196a.addAction(4096);
                n7Var.f4196a.setScrollable(true);
            }
            int V = layoutManager.mo862V(sVar, wVar);
            int B = layoutManager.mo847B(sVar, wVar);
            boolean a0 = layoutManager.mo1146a0();
            n7Var.f4196a.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) (Build.VERSION.SDK_INT >= 21 ? new C1226n7.C1228b(AccessibilityNodeInfo.CollectionInfo.obtain(V, B, a0, layoutManager.mo1140W())) : new C1226n7.C1228b(AccessibilityNodeInfo.CollectionInfo.obtain(V, B, a0))).f4204a);
        }
    }

    /* renamed from: g */
    public boolean mo774g(View view, int i, Bundle bundle) {
        if (super.mo774g(view, i, bundle)) {
            return true;
        }
        if (mo4017j() || this.f3243d.getLayoutManager() == null) {
            return false;
        }
        RecyclerView.C0162m layoutManager = this.f3243d.getLayoutManager();
        RecyclerView.C0173s sVar = layoutManager.f866b.f804e;
        return layoutManager.mo1113F0(i);
    }

    /* renamed from: j */
    public boolean mo4017j() {
        return this.f3243d.mo950M();
    }
}
