package p000;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

/* renamed from: f3 */
public class C0667f3 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: m */
    public static C0667f3 f2657m;

    /* renamed from: n */
    public static C0667f3 f2658n;

    /* renamed from: d */
    public final View f2659d;

    /* renamed from: e */
    public final CharSequence f2660e;

    /* renamed from: f */
    public final int f2661f;

    /* renamed from: g */
    public final Runnable f2662g = new C0668a();

    /* renamed from: h */
    public final Runnable f2663h = new C0669b();

    /* renamed from: i */
    public int f2664i;

    /* renamed from: j */
    public int f2665j;

    /* renamed from: k */
    public C0732g3 f2666k;

    /* renamed from: l */
    public boolean f2667l;

    /* renamed from: f3$a */
    public class C0668a implements Runnable {
        public C0668a() {
        }

        public void run() {
            C0667f3.this.mo3476d(false);
        }
    }

    /* renamed from: f3$b */
    public class C0669b implements Runnable {
        public C0669b() {
        }

        public void run() {
            C0667f3.this.mo3475b();
        }
    }

    public C0667f3(View view, CharSequence charSequence) {
        this.f2659d = view;
        this.f2660e = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        Method method = C0611e7.f2493a;
        this.f2661f = Build.VERSION.SDK_INT >= 28 ? viewConfiguration.getScaledHoverSlop() : viewConfiguration.getScaledTouchSlop() / 2;
        mo3474a();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    /* renamed from: c */
    public static void m2139c(C0667f3 f3Var) {
        C0667f3 f3Var2 = f2657m;
        if (f3Var2 != null) {
            f3Var2.f2659d.removeCallbacks(f3Var2.f2662g);
        }
        f2657m = f3Var;
        if (f3Var != null) {
            f3Var.f2659d.postDelayed(f3Var.f2662g, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    /* renamed from: a */
    public final void mo3474a() {
        this.f2664i = Integer.MAX_VALUE;
        this.f2665j = Integer.MAX_VALUE;
    }

    /* renamed from: b */
    public void mo3475b() {
        if (f2658n == this) {
            f2658n = null;
            C0732g3 g3Var = this.f2666k;
            if (g3Var != null) {
                g3Var.mo3754a();
                this.f2666k = null;
                mo3474a();
                this.f2659d.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f2657m == this) {
            m2139c((C0667f3) null);
        }
        this.f2659d.removeCallbacks(this.f2663h);
    }

    /* renamed from: d */
    public void mo3476d(boolean z) {
        int i;
        int i2;
        long j;
        View view = this.f2659d;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (view.isAttachedToWindow()) {
            m2139c((C0667f3) null);
            C0667f3 f3Var = f2658n;
            if (f3Var != null) {
                f3Var.mo3475b();
            }
            f2658n = this;
            this.f2667l = z;
            C0732g3 g3Var = new C0732g3(this.f2659d.getContext());
            this.f2666k = g3Var;
            View view2 = this.f2659d;
            int i3 = this.f2664i;
            int i4 = this.f2665j;
            boolean z2 = this.f2667l;
            CharSequence charSequence = this.f2660e;
            if (g3Var.f2822b.getParent() != null) {
                g3Var.mo3754a();
            }
            g3Var.f2823c.setText(charSequence);
            WindowManager.LayoutParams layoutParams = g3Var.f2824d;
            layoutParams.token = view2.getApplicationWindowToken();
            int dimensionPixelOffset = g3Var.f2821a.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
            if (view2.getWidth() < dimensionPixelOffset) {
                i3 = view2.getWidth() / 2;
            }
            if (view2.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = g3Var.f2821a.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
                i = i4 + dimensionPixelOffset2;
                i2 = i4 - dimensionPixelOffset2;
            } else {
                i = view2.getHeight();
                i2 = 0;
            }
            layoutParams.gravity = 49;
            int dimensionPixelOffset3 = g3Var.f2821a.getResources().getDimensionPixelOffset(z2 ? R.dimen.tooltip_y_offset_touch : R.dimen.tooltip_y_offset_non_touch);
            View rootView = view2.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context = view2.getContext();
                while (true) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else if (context instanceof Activity) {
                        rootView = ((Activity) context).getWindow().getDecorView();
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
            } else {
                rootView.getWindowVisibleDisplayFrame(g3Var.f2825e);
                Rect rect = g3Var.f2825e;
                if (rect.left < 0 && rect.top < 0) {
                    Resources resources = g3Var.f2821a.getResources();
                    int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
                    int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
                    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                    g3Var.f2825e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                rootView.getLocationOnScreen(g3Var.f2827g);
                view2.getLocationOnScreen(g3Var.f2826f);
                int[] iArr = g3Var.f2826f;
                int i5 = iArr[0];
                int[] iArr2 = g3Var.f2827g;
                iArr[0] = i5 - iArr2[0];
                iArr[1] = iArr[1] - iArr2[1];
                layoutParams.x = (iArr[0] + i3) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                g3Var.f2822b.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = g3Var.f2822b.getMeasuredHeight();
                int[] iArr3 = g3Var.f2826f;
                int i6 = ((iArr3[1] + i2) - dimensionPixelOffset3) - measuredHeight;
                int i7 = iArr3[1] + i + dimensionPixelOffset3;
                if (!z2 ? measuredHeight + i7 > g3Var.f2825e.height() : i6 >= 0) {
                    layoutParams.y = i6;
                } else {
                    layoutParams.y = i7;
                }
            }
            ((WindowManager) g3Var.f2821a.getSystemService("window")).addView(g3Var.f2822b, g3Var.f2824d);
            this.f2659d.addOnAttachStateChangeListener(this);
            if (this.f2667l) {
                j = 2500;
            } else {
                j = ((this.f2659d.getWindowSystemUiVisibility() & 1) == 1 ? 3000 : 15000) - ((long) ViewConfiguration.getLongPressTimeout());
            }
            this.f2659d.removeCallbacks(this.f2663h);
            this.f2659d.postDelayed(this.f2663h, j);
        }
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        boolean z;
        if (this.f2666k != null && this.f2667l) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f2659d.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                mo3474a();
                mo3475b();
            }
        } else if (this.f2659d.isEnabled() && this.f2666k == null) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (Math.abs(x - this.f2664i) > this.f2661f || Math.abs(y - this.f2665j) > this.f2661f) {
                this.f2664i = x;
                this.f2665j = y;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                m2139c(this);
            }
        }
        return false;
    }

    public boolean onLongClick(View view) {
        this.f2664i = view.getWidth() / 2;
        this.f2665j = view.getHeight() / 2;
        mo3476d(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        mo3475b();
    }
}
