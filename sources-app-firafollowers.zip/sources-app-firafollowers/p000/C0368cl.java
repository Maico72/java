package p000;

import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.ParcelFileDescriptor;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.Objects;
import p000.C2067xf;

/* renamed from: cl */
public class C0368cl<T> implements C0054ag<T, Bitmap> {

    /* renamed from: d */
    public static final C2067xf<Long> f1618d = new C2067xf<>("com.bumptech.glide.load.resource.bitmap.VideoBitmapDecode.TargetFrame", -1L, new C0369a());

    /* renamed from: e */
    public static final C2067xf<Integer> f1619e = new C2067xf<>("com.bumptech.glide.load.resource.bitmap.VideoBitmapDecode.FrameOption", 2, new C0370b());

    /* renamed from: f */
    public static final C0373e f1620f = new C0373e();

    /* renamed from: a */
    public final C0374f<T> f1621a;

    /* renamed from: b */
    public final C0056ai f1622b;

    /* renamed from: c */
    public final C0373e f1623c;

    /* renamed from: cl$a */
    public class C0369a implements C2067xf.C2069b<Long> {

        /* renamed from: a */
        public final ByteBuffer f1624a = ByteBuffer.allocate(8);

        /* renamed from: a */
        public void mo1970a(byte[] bArr, Object obj, MessageDigest messageDigest) {
            Long l = (Long) obj;
            messageDigest.update(bArr);
            synchronized (this.f1624a) {
                this.f1624a.position(0);
                messageDigest.update(this.f1624a.putLong(l.longValue()).array());
            }
        }
    }

    /* renamed from: cl$b */
    public class C0370b implements C2067xf.C2069b<Integer> {

        /* renamed from: a */
        public final ByteBuffer f1625a = ByteBuffer.allocate(4);

        /* renamed from: a */
        public void mo1970a(byte[] bArr, Object obj, MessageDigest messageDigest) {
            Integer num = (Integer) obj;
            if (num != null) {
                messageDigest.update(bArr);
                synchronized (this.f1625a) {
                    this.f1625a.position(0);
                    messageDigest.update(this.f1625a.putInt(num.intValue()).array());
                }
            }
        }
    }

    /* renamed from: cl$c */
    public static final class C0371c implements C0374f<AssetFileDescriptor> {
        public C0371c(C0369a aVar) {
        }

        /* renamed from: a */
        public void mo1971a(MediaMetadataRetriever mediaMetadataRetriever, Object obj) {
            AssetFileDescriptor assetFileDescriptor = (AssetFileDescriptor) obj;
            mediaMetadataRetriever.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
        }
    }

    /* renamed from: cl$d */
    public static final class C0372d implements C0374f<ByteBuffer> {
        /* renamed from: a */
        public void mo1971a(MediaMetadataRetriever mediaMetadataRetriever, Object obj) {
            mediaMetadataRetriever.setDataSource(new C0572dl(this, (ByteBuffer) obj));
        }
    }

    /* renamed from: cl$e */
    public static class C0373e {
    }

    /* renamed from: cl$f */
    public interface C0374f<T> {
        /* renamed from: a */
        void mo1971a(MediaMetadataRetriever mediaMetadataRetriever, T t);
    }

    /* renamed from: cl$g */
    public static final class C0375g implements C0374f<ParcelFileDescriptor> {
        /* renamed from: a */
        public void mo1971a(MediaMetadataRetriever mediaMetadataRetriever, Object obj) {
            mediaMetadataRetriever.setDataSource(((ParcelFileDescriptor) obj).getFileDescriptor());
        }
    }

    /* renamed from: cl$h */
    public static final class C0376h extends RuntimeException {
        public C0376h() {
            super("MediaMetadataRetriever failed to retrieve a frame without throwing, check the adb logs for .*MetadataRetriever.* prior to this exception for details");
        }
    }

    public C0368cl(C0056ai aiVar, C0374f<T> fVar) {
        C0373e eVar = f1620f;
        this.f1622b = aiVar;
        this.f1621a = fVar;
        this.f1623c = eVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x006b A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x006c  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.graphics.Bitmap m1368c(android.media.MediaMetadataRetriever r9, long r10, int r12, int r13, int r14, p000.C1189mk r15) {
        /*
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 27
            if (r0 < r1) goto L_0x0062
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r13 == r0) goto L_0x0062
            if (r14 == r0) goto L_0x0062
            mk r0 = p000.C1189mk.f4081d
            if (r15 == r0) goto L_0x0062
            r0 = 18
            java.lang.String r0 = r9.extractMetadata(r0)     // Catch:{ all -> 0x0053 }
            int r0 = java.lang.Integer.parseInt(r0)     // Catch:{ all -> 0x0053 }
            r1 = 19
            java.lang.String r1 = r9.extractMetadata(r1)     // Catch:{ all -> 0x0053 }
            int r1 = java.lang.Integer.parseInt(r1)     // Catch:{ all -> 0x0053 }
            r2 = 24
            java.lang.String r2 = r9.extractMetadata(r2)     // Catch:{ all -> 0x0053 }
            int r2 = java.lang.Integer.parseInt(r2)     // Catch:{ all -> 0x0053 }
            r3 = 90
            if (r2 == r3) goto L_0x0036
            r3 = 270(0x10e, float:3.78E-43)
            if (r2 != r3) goto L_0x0039
        L_0x0036:
            r8 = r1
            r1 = r0
            r0 = r8
        L_0x0039:
            float r13 = r15.mo4627b(r0, r1, r13, r14)     // Catch:{ all -> 0x0053 }
            float r14 = (float) r0     // Catch:{ all -> 0x0053 }
            float r14 = r14 * r13
            int r6 = java.lang.Math.round(r14)     // Catch:{ all -> 0x0053 }
            float r14 = (float) r1     // Catch:{ all -> 0x0053 }
            float r13 = r13 * r14
            int r7 = java.lang.Math.round(r13)     // Catch:{ all -> 0x0053 }
            r2 = r9
            r3 = r10
            r5 = r12
            android.graphics.Bitmap r13 = r2.getScaledFrameAtTime(r3, r5, r6, r7)     // Catch:{ all -> 0x0053 }
            goto L_0x0063
        L_0x0053:
            r13 = move-exception
            r14 = 3
            java.lang.String r15 = "VideoDecoder"
            boolean r14 = android.util.Log.isLoggable(r15, r14)
            if (r14 == 0) goto L_0x0062
            java.lang.String r14 = "Exception trying to decode a scaled frame on oreo+, falling back to a fullsize frame"
            android.util.Log.d(r15, r14, r13)
        L_0x0062:
            r13 = 0
        L_0x0063:
            if (r13 != 0) goto L_0x0069
            android.graphics.Bitmap r13 = r9.getFrameAtTime(r10, r12)
        L_0x0069:
            if (r13 == 0) goto L_0x006c
            return r13
        L_0x006c:
            cl$h r9 = new cl$h
            r9.<init>()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0368cl.m1368c(android.media.MediaMetadataRetriever, long, int, int, int, mk):android.graphics.Bitmap");
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: a */
    public C1675rh<Bitmap> mo122a(T t, int i, int i2, C2150yf yfVar) {
        long longValue = ((Long) yfVar.mo6704c(f1618d)).longValue();
        if (longValue >= 0 || longValue == -1) {
            Integer num = (Integer) yfVar.mo6704c(f1619e);
            if (num == null) {
                num = 2;
            }
            C1189mk mkVar = (C1189mk) yfVar.mo6704c(C1189mk.f4083f);
            if (mkVar == null) {
                mkVar = C1189mk.f4082e;
            }
            C1189mk mkVar2 = mkVar;
            Objects.requireNonNull(this.f1623c);
            MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
            try {
                this.f1621a.mo1971a(mediaMetadataRetriever, t);
                Bitmap c = m1368c(mediaMetadataRetriever, longValue, num.intValue(), i, i2, mkVar2);
                mediaMetadataRetriever.release();
                return C0706fk.m2298f(c, this.f1622b);
            } catch (Throwable th) {
                mediaMetadataRetriever.release();
                throw th;
            }
        } else {
            throw new IllegalArgumentException("Requested frame must be non-negative, or DEFAULT_FRAME, given: " + longValue);
        }
    }

    /* renamed from: b */
    public boolean mo123b(T t, C2150yf yfVar) {
        return true;
    }
}
