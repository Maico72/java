package p000;

import java.text.DateFormat;
import java.util.Map;
import java.util.Objects;
import p000.C1631qt;
import p000.t00;

/* renamed from: at */
public abstract class C0221at extends C0792gs {

    /* renamed from: p */
    public static final C1462ps<Object> f1132p = new C0985jx("Null key for a Map not allowed in JSON (use a converting NullKeySerializer?)");

    /* renamed from: q */
    public static final C1462ps<Object> f1133q = new C2101xx();

    /* renamed from: d */
    public final C2164ys f1134d;

    /* renamed from: e */
    public final Class<?> f1135e;

    /* renamed from: f */
    public final C0654ex f1136f;

    /* renamed from: g */
    public final C0590dx f1137g;

    /* renamed from: h */
    public transient C1631qt f1138h;

    /* renamed from: i */
    public C1462ps<Object> f1139i;

    /* renamed from: j */
    public C1462ps<Object> f1140j;

    /* renamed from: k */
    public C1462ps<Object> f1141k;

    /* renamed from: l */
    public C1462ps<Object> f1142l;

    /* renamed from: m */
    public final C1833tx f1143m;

    /* renamed from: n */
    public DateFormat f1144n;

    /* renamed from: o */
    public final boolean f1145o;

    public C0221at() {
        this.f1139i = f1133q;
        this.f1141k = C2035wy.f6698f;
        this.f1142l = f1132p;
        this.f1134d = null;
        this.f1136f = null;
        this.f1137g = new C0590dx();
        this.f1143m = null;
        this.f1135e = null;
        this.f1138h = null;
        this.f1145o = true;
    }

    public C0221at(C0221at atVar, C2164ys ysVar, C0654ex exVar) {
        this.f1139i = f1133q;
        this.f1141k = C2035wy.f6698f;
        C1462ps<Object> psVar = f1132p;
        this.f1142l = psVar;
        this.f1136f = exVar;
        this.f1134d = ysVar;
        C0590dx dxVar = atVar.f1137g;
        this.f1137g = dxVar;
        this.f1139i = atVar.f1139i;
        this.f1140j = atVar.f1140j;
        C1462ps<Object> psVar2 = atVar.f1141k;
        this.f1141k = psVar2;
        this.f1142l = atVar.f1142l;
        this.f1145o = psVar2 == psVar;
        this.f1135e = ysVar.f6044i;
        this.f1138h = ysVar.f6045j;
        C1833tx txVar = dxVar.f2362b.get();
        if (txVar == null) {
            synchronized (dxVar) {
                txVar = dxVar.f2362b.get();
                if (txVar == null) {
                    C1833tx txVar2 = new C1833tx(dxVar.f2361a);
                    dxVar.f2362b.set(txVar2);
                    txVar = txVar2;
                }
            }
        }
        this.f1143m = txVar;
    }

    /* renamed from: A */
    public C1462ps<?> mo1438A(C1462ps<?> psVar, C0714fs fsVar) {
        return (psVar == null || !(psVar instanceof C2100xw)) ? psVar : ((C2100xw) psVar).mo2818a(this, fsVar);
    }

    /* renamed from: B */
    public abstract Object mo1439B(C0652ev evVar, Class<?> cls);

    /* renamed from: C */
    public abstract boolean mo1440C(Object obj);

    /* renamed from: D */
    public final boolean mo1441D(C1694rs rsVar) {
        return this.f1134d.mo5872n(rsVar);
    }

    /* renamed from: E */
    public final boolean mo1442E(C2237zs zsVar) {
        return this.f1134d.mo6713s(zsVar);
    }

    /* renamed from: F */
    public <T> T mo1443F(C0649es esVar, C0652ev evVar, String str, Object... objArr) {
        String str2;
        String a = mo3827a(str, objArr);
        String str3 = "N/A";
        if (evVar != null) {
            String k = evVar.mo3185k();
            if (k == null) {
                str2 = "[N/A]";
            } else {
                Object[] objArr2 = new Object[1];
                if (k.length() > 500) {
                    k = k.substring(0, 500) + "]...[" + k.substring(k.length() - 500);
                }
                objArr2[0] = k;
                str2 = String.format("\"%s\"", objArr2);
            }
        } else {
            str2 = str3;
        }
        if (esVar != null) {
            str3 = s00.m4869u(esVar.f2616a.f3696d);
        }
        throw new C0719fu(((C2168yw) this).f6983t, String.format("Invalid definition for property %s (of type %s): %s", new Object[]{str2, str3, a}), esVar, evVar);
    }

    /* renamed from: G */
    public <T> T mo1444G(C0649es esVar, String str, Object... objArr) {
        throw new C0719fu(((C2168yw) this).f6983t, String.format("Invalid type definition for type %s: %s", new Object[]{s00.m4869u(esVar.f2616a.f3696d), mo3827a(str, objArr)}), esVar, (C0652ev) null);
    }

    /* renamed from: H */
    public void mo1445H(String str, Object... objArr) {
        throw new C1203ms(((C2168yw) this).f6983t, mo3827a(str, objArr), (Throwable) null);
    }

    /* renamed from: I */
    public abstract C1462ps<Object> mo1446I(C1279nu nuVar, Object obj);

    /* renamed from: d */
    public final n00 mo1447d() {
        return this.f1134d.f5782e.f3505d;
    }

    /* renamed from: f */
    public <T> T mo1448f(C1035ks ksVar, String str) {
        throw new C0719fu(((C2168yw) this).f6983t, str, ksVar);
    }

    /* renamed from: h */
    public C1462ps<Object> mo1449h(C1035ks ksVar) {
        try {
            C1462ps<Object> j = mo1451j(ksVar);
            if (j != null) {
                C0590dx dxVar = this.f1137g;
                synchronized (dxVar) {
                    if (dxVar.f2361a.put(new i10(ksVar, false), j) == null) {
                        dxVar.f2362b.set((Object) null);
                    }
                    if (j instanceof C0517cx) {
                        ((C0517cx) j).mo2817b(this);
                    }
                }
            }
            return j;
        } catch (IllegalArgumentException e) {
            throw new C1203ms(((C2168yw) this).f6983t, mo3827a(s00.m4856h(e), new Object[0]), e);
        }
    }

    /* renamed from: i */
    public C1462ps<Object> mo1450i(Class<?> cls) {
        C1035ks b = this.f1134d.f5782e.f3505d.mo4662b((b00) null, cls, n00.f4138g);
        try {
            C1462ps<Object> j = mo1451j(b);
            if (j != null) {
                C0590dx dxVar = this.f1137g;
                synchronized (dxVar) {
                    C1462ps<Object> put = dxVar.f2361a.put(new i10(cls, false), j);
                    C1462ps<Object> put2 = dxVar.f2361a.put(new i10(b, false), j);
                    if (put == null || put2 == null) {
                        dxVar.f2362b.set((Object) null);
                    }
                    if (j instanceof C0517cx) {
                        ((C0517cx) j).mo2817b(this);
                    }
                }
            }
            return j;
        } catch (IllegalArgumentException e) {
            throw new C1203ms(((C2168yw) this).f6983t, mo3827a(s00.m4856h(e), new Object[0]), e);
        }
    }

    /* renamed from: j */
    public C1462ps<Object> mo1451j(C1035ks ksVar) {
        C1035ks ksVar2;
        Object H;
        C1889uw uwVar = (C1889uw) this.f1136f;
        Objects.requireNonNull(uwVar);
        C2164ys ysVar = this.f1134d;
        C0649es r = ysVar.mo6712r(ksVar);
        C1462ps e = uwVar.mo5614e(this, ((C0515cv) r).f2103e);
        if (e != null) {
            return e;
        }
        C0583ds e2 = ysVar.mo5863e();
        boolean z = false;
        t00 t00 = null;
        if (e2 == null) {
            ksVar2 = ksVar;
        } else {
            try {
                ksVar2 = e2.mo3135e0(ysVar, ((C0515cv) r).f2103e, ksVar);
            } catch (C1203ms e3) {
                mo1444G(r, e3.mo4636c(), new Object[0]);
                throw null;
            }
        }
        if (ksVar2 != ksVar) {
            if (!ksVar2.mo4345t(ksVar.f3696d)) {
                r = ysVar.mo6712r(ksVar2);
            }
            z = true;
        }
        C0515cv cvVar = (C0515cv) r;
        C0583ds dsVar = cvVar.f2102d;
        if (!(dsVar == null || (H = dsVar.mo3107H(cvVar.f2103e)) == null)) {
            if (!(H instanceof t00)) {
                if (H instanceof Class) {
                    Class<t00.C1774a> cls = (Class) H;
                    if (cls != t00.C1774a.class && !s00.m4864p(cls)) {
                        if (t00.class.isAssignableFrom(cls)) {
                            Objects.requireNonNull(cvVar.f2101c.f5782e);
                            H = s00.m4855g(cls, cvVar.f2101c.mo5861b());
                        } else {
                            throw new IllegalStateException(C1012kd.m3198g(cls, C1012kd.m3195d("AnnotationIntrospector returned Class "), "; expected Class<Converter>"));
                        }
                    }
                } else {
                    StringBuilder d = C1012kd.m3195d("AnnotationIntrospector returned Converter definition of type ");
                    d.append(H.getClass().getName());
                    d.append("; expected type Converter or Class<Converter> instead");
                    throw new IllegalStateException(d.toString());
                }
            }
            t00 = (t00) H;
        }
        if (t00 == null) {
            return uwVar.mo6148h(this, ksVar2, r, z);
        }
        C1035ks b = t00.mo5896b(mo1447d());
        if (!b.mo4345t(ksVar2.f3696d)) {
            r = ysVar.mo6712r(b);
            e = uwVar.mo5614e(this, ((C0515cv) r).f2103e);
        }
        if (e == null && !b.mo4349z()) {
            e = uwVar.mo6148h(this, b, r, true);
        }
        return new C1148lz(t00, b, e);
    }

    /* renamed from: k */
    public final DateFormat mo1452k() {
        DateFormat dateFormat = this.f1144n;
        if (dateFormat != null) {
            return dateFormat;
        }
        DateFormat dateFormat2 = (DateFormat) this.f1134d.f5782e.f3512k.clone();
        this.f1144n = dateFormat2;
        return dateFormat2;
    }

    /* renamed from: l */
    public C1035ks mo1453l(C1035ks ksVar, Class<?> cls) {
        if (ksVar.f3696d == cls) {
            return ksVar;
        }
        return this.f1134d.f5782e.f3505d.mo4668h(ksVar, cls, true);
    }

    /* renamed from: m */
    public final void mo1454m(C1200mq mqVar) {
        if (this.f1145o) {
            mqVar.mo3739q();
        } else {
            this.f1141k.mo1481f(null, mqVar, this);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r1.f1137g.mo3160a(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0010, code lost:
        r0 = mo1449h(r2);
     */
    /* renamed from: n */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1455n(p000.C1035ks r2, p000.C0714fs r3) {
        /*
            r1 = this;
            tx r0 = r1.f1143m
            ps r0 = r0.mo6053a(r2)
            if (r0 != 0) goto L_0x001d
            dx r0 = r1.f1137g
            ps r0 = r0.mo3160a(r2)
            if (r0 != 0) goto L_0x001d
            ps r0 = r1.mo1449h(r2)
            if (r0 != 0) goto L_0x001d
            java.lang.Class<?> r2 = r2.f3696d
            ps r2 = r1.mo1466y(r2)
            return r2
        L_0x001d:
            ps r2 = r1.mo1438A(r0, r3)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1455n(ks, fs):ps");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r4.f1137g.mo3161b(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0010, code lost:
        r0 = r4.f1137g.mo3160a(r4.f1134d.f5782e.f3505d.mo4662b((p000.b00) null, r5, p000.n00.f4138g));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0025, code lost:
        r0 = mo1450i(r5);
     */
    /* renamed from: o */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1456o(java.lang.Class<?> r5, p000.C0714fs r6) {
        /*
            r4 = this;
            tx r0 = r4.f1143m
            ps r0 = r0.mo6054b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ps r0 = r0.mo3161b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ys r1 = r4.f1134d
            jt r1 = r1.f5782e
            n00 r1 = r1.f3505d
            m00 r2 = p000.n00.f4138g
            r3 = 0
            ks r1 = r1.mo4662b(r3, r5, r2)
            ps r0 = r0.mo3160a(r1)
            if (r0 != 0) goto L_0x0030
            ps r0 = r4.mo1450i(r5)
            if (r0 != 0) goto L_0x0030
            ps r5 = r4.mo1466y(r5)
            return r5
        L_0x0030:
            ps r5 = r4.mo1438A(r0, r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1456o(java.lang.Class, fs):ps");
    }

    /* renamed from: p */
    public C1462ps<Object> mo1457p(C1035ks ksVar, C0714fs fsVar) {
        C1462ps<Object> a = this.f1136f.mo3414a(this, ksVar, this.f1140j);
        if (a instanceof C0517cx) {
            ((C0517cx) a).mo2817b(this);
        }
        return mo1438A(a, fsVar);
    }

    /* renamed from: q */
    public abstract C0318by mo1458q(Object obj, C0581dq<?> dqVar);

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r1.f1137g.mo3160a(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0010, code lost:
        r0 = mo1449h(r2);
     */
    /* renamed from: r */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1459r(p000.C1035ks r2, p000.C0714fs r3) {
        /*
            r1 = this;
            tx r0 = r1.f1143m
            ps r0 = r0.mo6053a(r2)
            if (r0 != 0) goto L_0x001d
            dx r0 = r1.f1137g
            ps r0 = r0.mo3160a(r2)
            if (r0 != 0) goto L_0x001d
            ps r0 = r1.mo1449h(r2)
            if (r0 != 0) goto L_0x001d
            java.lang.Class<?> r2 = r2.f3696d
            ps r2 = r1.mo1466y(r2)
            return r2
        L_0x001d:
            ps r2 = r1.mo1467z(r0, r3)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1459r(ks, fs):ps");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r4.f1137g.mo3161b(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0010, code lost:
        r0 = r4.f1137g.mo3160a(r4.f1134d.f5782e.f3505d.mo4662b((p000.b00) null, r5, p000.n00.f4138g));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0025, code lost:
        r0 = mo1450i(r5);
     */
    /* renamed from: s */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1460s(java.lang.Class<?> r5, p000.C0714fs r6) {
        /*
            r4 = this;
            tx r0 = r4.f1143m
            ps r0 = r0.mo6054b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ps r0 = r0.mo3161b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ys r1 = r4.f1134d
            jt r1 = r1.f5782e
            n00 r1 = r1.f3505d
            m00 r2 = p000.n00.f4138g
            r3 = 0
            ks r1 = r1.mo4662b(r3, r5, r2)
            ps r0 = r0.mo3160a(r1)
            if (r0 != 0) goto L_0x0030
            ps r0 = r4.mo1450i(r5)
            if (r0 != 0) goto L_0x0030
            ps r5 = r4.mo1466y(r5)
            return r5
        L_0x0030:
            ps r5 = r4.mo1467z(r0, r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1460s(java.lang.Class, fs):ps");
    }

    /* renamed from: t */
    public C1462ps<Object> mo1461t(C1035ks ksVar) {
        C1462ps<Object> a = this.f1143m.mo6053a(ksVar);
        if (a != null) {
            return a;
        }
        C1462ps<Object> a2 = this.f1137g.mo3160a(ksVar);
        if (a2 != null) {
            return a2;
        }
        C1462ps<Object> h = mo1449h(ksVar);
        return h == null ? mo1466y(ksVar.f3696d) : h;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x000a, code lost:
        r0 = r1.f1137g.mo3160a(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0012, code lost:
        r0 = mo1449h(r2);
     */
    /* renamed from: u */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1462u(p000.C1035ks r2, p000.C0714fs r3) {
        /*
            r1 = this;
            if (r2 == 0) goto L_0x0024
            tx r0 = r1.f1143m
            ps r0 = r0.mo6053a(r2)
            if (r0 != 0) goto L_0x001f
            dx r0 = r1.f1137g
            ps r0 = r0.mo3160a(r2)
            if (r0 != 0) goto L_0x001f
            ps r0 = r1.mo1449h(r2)
            if (r0 != 0) goto L_0x001f
            java.lang.Class<?> r2 = r2.f3696d
            ps r2 = r1.mo1466y(r2)
            return r2
        L_0x001f:
            ps r2 = r1.mo1438A(r0, r3)
            return r2
        L_0x0024:
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.String r3 = "Null passed for `valueType` of `findValueSerializer()`"
            r1.mo1445H(r3, r2)
            r2 = 0
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1462u(ks, fs):ps");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r4.f1137g.mo3161b(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0010, code lost:
        r0 = r4.f1137g.mo3160a(r4.f1134d.f5782e.f3505d.mo4662b((p000.b00) null, r5, p000.n00.f4138g));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0025, code lost:
        r0 = mo1450i(r5);
     */
    /* renamed from: v */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<java.lang.Object> mo1463v(java.lang.Class<?> r5, p000.C0714fs r6) {
        /*
            r4 = this;
            tx r0 = r4.f1143m
            ps r0 = r0.mo6054b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ps r0 = r0.mo3161b(r5)
            if (r0 != 0) goto L_0x0030
            dx r0 = r4.f1137g
            ys r1 = r4.f1134d
            jt r1 = r1.f5782e
            n00 r1 = r1.f3505d
            m00 r2 = p000.n00.f4138g
            r3 = 0
            ks r1 = r1.mo4662b(r3, r5, r2)
            ps r0 = r0.mo3160a(r1)
            if (r0 != 0) goto L_0x0030
            ps r0 = r4.mo1450i(r5)
            if (r0 != 0) goto L_0x0030
            ps r5 = r4.mo1466y(r5)
            return r5
        L_0x0030:
            ps r5 = r4.mo1438A(r0, r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0221at.mo1463v(java.lang.Class, fs):ps");
    }

    /* renamed from: w */
    public final C0583ds mo1464w() {
        return this.f1134d.mo5863e();
    }

    /* renamed from: x */
    public Object mo1465x(Object obj) {
        Object obj2;
        C1631qt.C1632a aVar = (C1631qt.C1632a) this.f1138h;
        Map<Object, Object> map = aVar.f5348e;
        if (map == null || (obj2 = map.get(obj)) == null) {
            return aVar.f5347d.get(obj);
        }
        if (obj2 == C1631qt.C1632a.f5346g) {
            return null;
        }
        return obj2;
    }

    /* renamed from: y */
    public C1462ps<Object> mo1466y(Class<?> cls) {
        return cls == Object.class ? this.f1139i : new C2101xx(cls);
    }

    /* renamed from: z */
    public C1462ps<?> mo1467z(C1462ps<?> psVar, C0714fs fsVar) {
        return (psVar == null || !(psVar instanceof C2100xw)) ? psVar : ((C2100xw) psVar).mo2818a(this, fsVar);
    }
}
