package p000;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: hn */
public class C0846hn {

    /* renamed from: a */
    public final AtomicReference<C1456po> f3141a = new AtomicReference<>();

    /* renamed from: b */
    public final C2047x3<C1456po, List<Class<?>>> f3142b = new C2047x3<>();
}
