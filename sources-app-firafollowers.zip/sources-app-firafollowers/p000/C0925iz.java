package p000;

import java.util.Objects;
import p000.C1360os;

@C0313bt
/* renamed from: iz */
public class C0925iz extends C1770sz<C1360os> {

    /* renamed from: f */
    public static final C0925iz f3318f = new C0925iz();

    public C0925iz() {
        super(C1360os.class);
    }

    /* renamed from: d */
    public boolean mo3672d(C0221at atVar, Object obj) {
        C1360os osVar = (C1360os) obj;
        if (!(osVar instanceof C1360os.C1361a)) {
            return false;
        }
        Objects.requireNonNull((C1360os.C1361a) osVar);
        return false;
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        ((C1360os) obj).mo4385b(mqVar, atVar);
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        ((C1360os) obj).mo4384a(mqVar, atVar, awVar);
    }
}
