package p000;

/* renamed from: co */
public class C0380co<R> implements C0575do<R> {

    /* renamed from: a */
    public static final C0380co<?> f1630a = new C0380co<>();

    /* renamed from: b */
    public static final C0645eo<?> f1631b = new C0381a();

    /* renamed from: co$a */
    public static class C0381a<R> implements C0645eo<R> {
    }
}
