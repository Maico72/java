package p000;

/* renamed from: bh */
public interface C0289bh {

    /* renamed from: bh$a */
    public interface C0290a {
        /* renamed from: b */
        void mo1708b();

        /* renamed from: c */
        void mo1709c(C2005wf wfVar, Object obj, C0768gg<?> ggVar, C1017kf kfVar, C2005wf wfVar2);

        /* renamed from: d */
        void mo1710d(C2005wf wfVar, Exception exc, C0768gg<?> ggVar, C1017kf kfVar);
    }

    /* renamed from: a */
    boolean mo1706a();

    void cancel();
}
