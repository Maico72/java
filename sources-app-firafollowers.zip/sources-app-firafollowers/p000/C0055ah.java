package p000;

import p000.C1020ki;

/* renamed from: ah */
public class C0055ah<DataType> implements C1020ki.C1022b {

    /* renamed from: a */
    public final C1253nf<DataType> f184a;

    /* renamed from: b */
    public final DataType f185b;

    /* renamed from: c */
    public final C2150yf f186c;

    public C0055ah(C1253nf<DataType> nfVar, DataType datatype, C2150yf yfVar) {
        this.f184a = nfVar;
        this.f185b = datatype;
        this.f186c = yfVar;
    }
}
