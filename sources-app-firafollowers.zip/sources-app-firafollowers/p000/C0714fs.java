package p000;

import java.io.Serializable;
import p000.C0576dp;
import p000.C1029kp;

/* renamed from: fs */
public interface C0714fs {

    /* renamed from: c */
    public static final C0576dp.C0580d f2775c = new C0576dp.C0580d("", C0576dp.C0579c.ANY, "", "", C0576dp.C0578b.f2325c, (Boolean) null);

    /* renamed from: fs$a */
    public static class C0715a implements C0714fs, Serializable {

        /* renamed from: d */
        public final C1035ks f2776d;

        /* renamed from: e */
        public final C1884us f2777e;

        /* renamed from: f */
        public final C1887uu f2778f;

        public C0715a(C1957vs vsVar, C1035ks ksVar, C1957vs vsVar2, C1887uu uuVar, C1884us usVar) {
            this.f2776d = ksVar;
            this.f2777e = usVar;
            this.f2778f = uuVar;
        }

        /* renamed from: a */
        public C1887uu mo3644a() {
            return this.f2778f;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x0013, code lost:
            r2 = r2.mo3157z((r0 = r1.f2778f));
         */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public p000.C1029kp.C1031b mo3645b(p000.C1757st<?> r2, java.lang.Class<?> r3) {
            /*
                r1 = this;
                ks r0 = r1.f2776d
                java.lang.Class<?> r0 = r0.f3696d
                kp$b r3 = r2.mo5865g(r3, r0)
                ds r2 = r2.mo5863e()
                if (r2 == 0) goto L_0x001f
                uu r0 = r1.f2778f
                if (r0 != 0) goto L_0x0013
                goto L_0x001f
            L_0x0013:
                kp$b r2 = r2.mo3157z(r0)
                if (r2 != 0) goto L_0x001a
                return r3
            L_0x001a:
                kp$b r2 = r3.mo4315a(r2)
                return r2
            L_0x001f:
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0714fs.C0715a.mo3645b(st, java.lang.Class):kp$b");
        }

        /* renamed from: c */
        public C1035ks mo3646c() {
            return this.f2776d;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
            r2 = r2.mo3139h((r0 = r1.f2778f));
         */
        /* renamed from: d */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public p000.C0576dp.C0580d mo3647d(p000.C1757st<?> r2, java.lang.Class<?> r3) {
            /*
                r1 = this;
                dp$d r3 = r2.mo5866h(r3)
                ds r2 = r2.mo5863e()
                if (r2 == 0) goto L_0x001b
                uu r0 = r1.f2778f
                if (r0 != 0) goto L_0x000f
                goto L_0x001b
            L_0x000f:
                dp$d r2 = r2.mo3139h(r0)
                if (r2 != 0) goto L_0x0016
                return r3
            L_0x0016:
                dp$d r2 = r3.mo3092f(r2)
                return r2
            L_0x001b:
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0714fs.C0715a.mo3647d(st, java.lang.Class):dp$d");
        }
    }

    static {
        C1029kp.C1031b bVar = C1029kp.C1031b.f3668h;
        C1029kp.C1031b bVar2 = C1029kp.C1031b.f3668h;
    }

    /* renamed from: a */
    C1887uu mo3644a();

    /* renamed from: b */
    C1029kp.C1031b mo3645b(C1757st<?> stVar, Class<?> cls);

    /* renamed from: c */
    C1035ks mo3646c();

    /* renamed from: d */
    C0576dp.C0580d mo3647d(C1757st<?> stVar, Class<?> cls);
}
