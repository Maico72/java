package p000;

/* renamed from: fq */
public abstract class C0712fq extends C0712fq<Object> {

    /* renamed from: d */
    public final Class<?> f2773d;

    public C0712fq(Class<?> cls) {
        this.f2773d = cls;
    }

    /* renamed from: a */
    public boolean mo3632a(C0581dq dqVar) {
        return dqVar.getClass() == getClass() && dqVar.mo3098d() == this.f2773d;
    }

    /* renamed from: d */
    public final Class mo3633d() {
        return this.f2773d;
    }
}
