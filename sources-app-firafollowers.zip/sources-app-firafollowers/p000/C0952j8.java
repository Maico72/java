package p000;

/* renamed from: j8 */
public class C0952j8 {

    /* renamed from: a */
    public final C1097l8<?> f3386a;

    public C0952j8(C1097l8<?> l8Var) {
        this.f3386a = l8Var;
    }

    /* renamed from: a */
    public void mo4150a() {
        this.f3386a.f3851h.mo4777h0();
    }
}
