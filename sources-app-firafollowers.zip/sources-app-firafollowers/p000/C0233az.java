package p000;

import p000.C1356oq;

@C0313bt
/* renamed from: az */
public class C0233az extends C2171yy<Object> {

    /* renamed from: f */
    public static final C0233az f1159f = new C0233az();

    public C0233az() {
        super(Float.class, C1356oq.C1358b.FLOAT, "number");
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3741s(((Float) obj).floatValue());
    }
}
