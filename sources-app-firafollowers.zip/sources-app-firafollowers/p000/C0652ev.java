package p000;

import p000.C0583ds;
import p000.C1029kp;

/* renamed from: ev */
public abstract class C0652ev {

    /* renamed from: d */
    public static final C1029kp.C1031b f2617d = C1029kp.C1031b.f3668h;

    static {
        C1029kp.C1031b bVar = C1029kp.C1031b.f3668h;
    }

    /* renamed from: a */
    public boolean mo3409a() {
        Object f = mo3180f();
        if (f == null && (f = mo3188n()) == null) {
            f = mo3181g();
        }
        return f != null;
    }

    /* renamed from: b */
    public abstract C1029kp.C1031b mo3179b();

    /* renamed from: c */
    public C0583ds.C0584a mo3410c() {
        return null;
    }

    /* renamed from: d */
    public Class<?>[] mo3411d() {
        return null;
    }

    /* renamed from: e */
    public C1887uu mo3412e() {
        C1959vu i = mo3183i();
        return i == null ? mo3181g() : i;
    }

    /* renamed from: f */
    public abstract C2166yu mo3180f();

    /* renamed from: g */
    public abstract C1758su mo3181g();

    /* renamed from: h */
    public abstract C1957vs mo3182h();

    /* renamed from: i */
    public abstract C1959vu mo3183i();

    /* renamed from: j */
    public abstract C1884us mo3184j();

    /* renamed from: k */
    public abstract String mo3185k();

    /* renamed from: l */
    public abstract C1887uu mo3186l();

    /* renamed from: m */
    public abstract Class<?> mo3187m();

    /* renamed from: n */
    public abstract C1959vu mo3188n();

    /* renamed from: o */
    public abstract C1957vs mo3189o();

    /* renamed from: p */
    public abstract boolean mo3190p();

    /* renamed from: q */
    public boolean mo3413q() {
        return false;
    }
}
