package p000;

import android.content.res.AssetManager;
import android.util.Log;
import java.io.IOException;
import p000.C0768gg;

/* renamed from: eg */
public abstract class C0634eg<T> implements C0768gg<T> {

    /* renamed from: d */
    public final String f2597d;

    /* renamed from: e */
    public final AssetManager f2598e;

    /* renamed from: f */
    public T f2599f;

    public C0634eg(AssetManager assetManager, String str) {
        this.f2598e = assetManager;
        this.f2597d = str;
    }

    /* renamed from: b */
    public void mo135b() {
        T t = this.f2599f;
        if (t != null) {
            try {
                mo3396d(t);
            } catch (IOException unused) {
            }
        }
    }

    /* renamed from: c */
    public C1017kf mo136c() {
        return C1017kf.LOCAL;
    }

    public void cancel() {
    }

    /* renamed from: d */
    public abstract void mo3396d(T t);

    /* renamed from: e */
    public void mo138e(C2066xe xeVar, C0768gg.C0769a<? super T> aVar) {
        try {
            T f = mo3397f(this.f2598e, this.f2597d);
            this.f2599f = f;
            aVar.mo3803f(f);
        } catch (IOException e) {
            if (Log.isLoggable("AssetPathFetcher", 3)) {
                Log.d("AssetPathFetcher", "Failed to load data from asset manager", e);
            }
            aVar.mo3802d(e);
        }
    }

    /* renamed from: f */
    public abstract T mo3397f(AssetManager assetManager, String str);
}
