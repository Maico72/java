package p000;

/* renamed from: ii */
public interface C0894ii {
    /* renamed from: a */
    void mo3613a();
}
