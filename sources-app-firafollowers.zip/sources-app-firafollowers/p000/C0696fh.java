package p000;

/* renamed from: fh */
public abstract class C0696fh {

    /* renamed from: a */
    public static final C0696fh f2750a = new C0697a();

    /* renamed from: b */
    public static final C0696fh f2751b = new C0698b();

    /* renamed from: c */
    public static final C0696fh f2752c = new C0699c();

    /* renamed from: fh$a */
    public class C0697a extends C0696fh {
        /* renamed from: a */
        public boolean mo3599a() {
            return false;
        }

        /* renamed from: b */
        public boolean mo3600b() {
            return false;
        }

        /* renamed from: c */
        public boolean mo3601c(C1017kf kfVar) {
            return false;
        }

        /* renamed from: d */
        public boolean mo3602d(boolean z, C1017kf kfVar, C1178mf mfVar) {
            return false;
        }
    }

    /* renamed from: fh$b */
    public class C0698b extends C0696fh {
        /* renamed from: a */
        public boolean mo3599a() {
            return true;
        }

        /* renamed from: b */
        public boolean mo3600b() {
            return false;
        }

        /* renamed from: c */
        public boolean mo3601c(C1017kf kfVar) {
            return (kfVar == C1017kf.DATA_DISK_CACHE || kfVar == C1017kf.MEMORY_CACHE) ? false : true;
        }

        /* renamed from: d */
        public boolean mo3602d(boolean z, C1017kf kfVar, C1178mf mfVar) {
            return false;
        }
    }

    /* renamed from: fh$c */
    public class C0699c extends C0696fh {
        /* renamed from: a */
        public boolean mo3599a() {
            return true;
        }

        /* renamed from: b */
        public boolean mo3600b() {
            return true;
        }

        /* renamed from: c */
        public boolean mo3601c(C1017kf kfVar) {
            return kfVar == C1017kf.REMOTE;
        }

        /* renamed from: d */
        public boolean mo3602d(boolean z, C1017kf kfVar, C1178mf mfVar) {
            return ((z && kfVar == C1017kf.DATA_DISK_CACHE) || kfVar == C1017kf.LOCAL) && mfVar == C1178mf.TRANSFORMED;
        }
    }

    /* renamed from: a */
    public abstract boolean mo3599a();

    /* renamed from: b */
    public abstract boolean mo3600b();

    /* renamed from: c */
    public abstract boolean mo3601c(C1017kf kfVar);

    /* renamed from: d */
    public abstract boolean mo3602d(boolean z, C1017kf kfVar, C1178mf mfVar);
}
