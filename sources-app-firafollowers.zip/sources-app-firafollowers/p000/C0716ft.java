package p000;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import p000.C1462ps;
import p000.t00;

@Target({ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: ft */
public @interface C0716ft {

    @Deprecated
    /* renamed from: ft$a */
    public enum C0717a {
        ALWAYS,
        NON_NULL,
        NON_DEFAULT,
        NON_EMPTY,
        DEFAULT_INCLUSION
    }

    /* renamed from: ft$b */
    public enum C0718b {
        DYNAMIC,
        STATIC,
        DEFAULT_TYPING
    }

    /* renamed from: as */
    Class<?> mo3648as() default Void.class;

    Class<?> contentAs() default Void.class;

    Class<? extends t00> contentConverter() default t00.C1774a.class;

    Class<? extends C1462ps> contentUsing() default C1462ps.C1463a.class;

    Class<? extends t00> converter() default t00.C1774a.class;

    @Deprecated
    C0717a include() default C0717a.DEFAULT_INCLUSION;

    Class<?> keyAs() default Void.class;

    Class<? extends C1462ps> keyUsing() default C1462ps.C1463a.class;

    Class<? extends C1462ps> nullsUsing() default C1462ps.C1463a.class;

    C0718b typing() default C0718b.DEFAULT_TYPING;

    Class<? extends C1462ps> using() default C1462ps.C1463a.class;
}
