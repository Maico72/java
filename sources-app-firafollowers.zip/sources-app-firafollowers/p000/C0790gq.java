package p000;

/* renamed from: gq */
public enum C0790gq {
    TRUE,
    FALSE,
    DEFAULT;

    /* renamed from: a */
    public Boolean mo3819a() {
        if (this == DEFAULT) {
            return null;
        }
        return this == TRUE ? Boolean.TRUE : Boolean.FALSE;
    }
}
