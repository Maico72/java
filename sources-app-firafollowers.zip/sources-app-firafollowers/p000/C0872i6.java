package p000;

import android.util.Log;
import java.io.Writer;

@Deprecated
/* renamed from: i6 */
public class C0872i6 extends Writer {

    /* renamed from: d */
    public final String f3219d;

    /* renamed from: e */
    public StringBuilder f3220e = new StringBuilder(128);

    public C0872i6(String str) {
        this.f3219d = str;
    }

    /* renamed from: a */
    public final void mo4002a() {
        if (this.f3220e.length() > 0) {
            Log.d(this.f3219d, this.f3220e.toString());
            StringBuilder sb = this.f3220e;
            sb.delete(0, sb.length());
        }
    }

    public void close() {
        mo4002a();
    }

    public void flush() {
        mo4002a();
    }

    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == 10) {
                mo4002a();
            } else {
                this.f3220e.append(c);
            }
        }
    }
}
