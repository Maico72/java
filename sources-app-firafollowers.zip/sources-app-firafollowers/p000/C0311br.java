package p000;

/* renamed from: br */
public class C0311br {

    /* renamed from: a */
    public final Object f1359a;

    /* renamed from: b */
    public final boolean f1360b;

    /* renamed from: c */
    public final C1628qr f1361c;

    /* renamed from: d */
    public byte[] f1362d;

    /* renamed from: e */
    public char[] f1363e;

    public C0311br(C1628qr qrVar, Object obj, boolean z) {
        this.f1361c = qrVar;
        this.f1359a = obj;
        this.f1360b = z;
    }

    /* renamed from: a */
    public void mo1728a(byte[] bArr) {
        byte[] bArr2 = this.f1362d;
        if (bArr == bArr2 || bArr.length >= bArr2.length) {
            this.f1362d = null;
            this.f1361c.f5343a.set(3, bArr);
            return;
        }
        throw new IllegalArgumentException("Trying to release buffer smaller than original");
    }
}
