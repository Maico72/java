package p000;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import java.io.File;

/* renamed from: ck */
public class C0367ck implements C0288bg<BitmapDrawable> {

    /* renamed from: a */
    public final C0056ai f1616a;

    /* renamed from: b */
    public final C0288bg<Bitmap> f1617b;

    public C0367ck(C0056ai aiVar, C0288bg<Bitmap> bgVar) {
        this.f1616a = aiVar;
        this.f1617b = bgVar;
    }

    /* renamed from: a */
    public boolean mo1969a(Object obj, File file, C2150yf yfVar) {
        return this.f1617b.mo1969a(new C0706fk(((BitmapDrawable) ((C1675rh) obj).mo1714b()).getBitmap(), this.f1616a), file, yfVar);
    }

    /* renamed from: b */
    public C1178mf mo1705b(C2150yf yfVar) {
        return this.f1617b.mo1705b(yfVar);
    }
}
