package p000;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PointF;
import android.util.Property;

/* renamed from: ac */
public class C0025ac<T> extends Property<T, Float> {

    /* renamed from: a */
    public final Property<T, PointF> f76a;

    /* renamed from: b */
    public final PathMeasure f77b;

    /* renamed from: c */
    public final float f78c;

    /* renamed from: d */
    public final float[] f79d = new float[2];

    /* renamed from: e */
    public final PointF f80e = new PointF();

    /* renamed from: f */
    public float f81f;

    public C0025ac(Property<T, PointF> property, Path path) {
        super(Float.class, property.getName());
        this.f76a = property;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        this.f77b = pathMeasure;
        this.f78c = pathMeasure.getLength();
    }

    public Object get(Object obj) {
        return Float.valueOf(this.f81f);
    }

    public void set(Object obj, Object obj2) {
        Float f = (Float) obj2;
        this.f81f = f.floatValue();
        this.f77b.getPosTan(f.floatValue() * this.f78c, this.f79d, (float[]) null);
        PointF pointF = this.f80e;
        float[] fArr = this.f79d;
        pointF.x = fArr[0];
        pointF.y = fArr[1];
        this.f76a.set(obj, pointF);
    }
}
