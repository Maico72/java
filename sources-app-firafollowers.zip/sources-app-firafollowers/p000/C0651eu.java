package p000;

import java.io.Serializable;

/* renamed from: eu */
public class C0651eu implements C0514cu, Serializable {
}
