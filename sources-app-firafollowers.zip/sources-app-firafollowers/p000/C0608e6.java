package p000;

import android.os.Handler;
import java.util.concurrent.Callable;
import p000.C0534d6;

/* renamed from: e6 */
public class C0608e6 implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ Callable f2486d;

    /* renamed from: e */
    public final /* synthetic */ Handler f2487e;

    /* renamed from: f */
    public final /* synthetic */ C0534d6.C0537c f2488f;

    /* renamed from: e6$a */
    public class C0609a implements Runnable {

        /* renamed from: d */
        public final /* synthetic */ Object f2489d;

        public C0609a(Object obj) {
            this.f2489d = obj;
        }

        public void run() {
            C0608e6.this.f2488f.mo26a(this.f2489d);
        }
    }

    public C0608e6(C0534d6 d6Var, Callable callable, Handler handler, C0534d6.C0537c cVar) {
        this.f2486d = callable;
        this.f2487e = handler;
        this.f2488f = cVar;
    }

    public void run() {
        Object obj;
        try {
            obj = this.f2486d.call();
        } catch (Exception unused) {
            obj = null;
        }
        this.f2487e.post(new C0609a(obj));
    }
}
