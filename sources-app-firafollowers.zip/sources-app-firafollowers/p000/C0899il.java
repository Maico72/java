package p000;

import android.graphics.drawable.Drawable;

/* renamed from: il */
public final class C0899il extends C0844hl<Drawable> {
    public C0899il(Drawable drawable) {
        super(drawable);
    }

    /* renamed from: c */
    public int mo1715c() {
        return Math.max(1, this.f3140d.getIntrinsicHeight() * this.f3140d.getIntrinsicWidth() * 4);
    }

    /* renamed from: d */
    public Class<Drawable> mo1716d() {
        return this.f3140d.getClass();
    }

    /* renamed from: e */
    public void mo1717e() {
    }
}
