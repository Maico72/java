package p000;

/* renamed from: h6 */
public final class C0809h6 {

    /* renamed from: a */
    public static final C0735g6 f3036a;

    /* renamed from: b */
    public static final C0735g6 f3037b;

    /* renamed from: h6$a */
    public static class C0810a implements C0811b {

        /* renamed from: a */
        public static final C0810a f3038a = new C0810a();

        /* renamed from: a */
        public int mo3862a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            int i4 = 2;
            while (i < i3 && i4 == 2) {
                byte directionality = Character.getDirectionality(charSequence.charAt(i));
                C0735g6 g6Var = C0809h6.f3036a;
                if (directionality != 0) {
                    if (!(directionality == 1 || directionality == 2)) {
                        switch (directionality) {
                            case 14:
                            case 15:
                                break;
                            case 16:
                            case 17:
                                break;
                            default:
                                i4 = 2;
                                break;
                        }
                    }
                    i4 = 0;
                    i++;
                }
                i4 = 1;
                i++;
            }
            return i4;
        }
    }

    /* renamed from: h6$b */
    public interface C0811b {
        /* renamed from: a */
        int mo3862a(CharSequence charSequence, int i, int i2);
    }

    /* renamed from: h6$c */
    public static abstract class C0812c implements C0735g6 {

        /* renamed from: a */
        public final C0811b f3039a;

        public C0812c(C0811b bVar) {
            this.f3039a = bVar;
        }

        /* renamed from: a */
        public abstract boolean mo3863a();
    }

    /* renamed from: h6$d */
    public static class C0813d extends C0812c {

        /* renamed from: b */
        public final boolean f3040b;

        public C0813d(C0811b bVar, boolean z) {
            super(bVar);
            this.f3040b = z;
        }

        /* renamed from: a */
        public boolean mo3863a() {
            return this.f3040b;
        }
    }

    static {
        C0810a aVar = C0810a.f3038a;
        f3036a = new C0813d(aVar, false);
        f3037b = new C0813d(aVar, true);
    }
}
