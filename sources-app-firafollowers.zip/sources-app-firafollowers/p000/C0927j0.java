package p000;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;
import p000.C0727g0;
import p000.C1838u0;

/* renamed from: j0 */
public class C0927j0 extends C0727g0 implements C1838u0.C1839a {

    /* renamed from: f */
    public Context f3322f;

    /* renamed from: g */
    public ActionBarContextView f3323g;

    /* renamed from: h */
    public C0727g0.C0728a f3324h;

    /* renamed from: i */
    public WeakReference<View> f3325i;

    /* renamed from: j */
    public boolean f3326j;

    /* renamed from: k */
    public C1838u0 f3327k;

    public C0927j0(Context context, ActionBarContextView actionBarContextView, C0727g0.C0728a aVar, boolean z) {
        this.f3322f = context;
        this.f3323g = actionBarContextView;
        this.f3324h = aVar;
        C1838u0 u0Var = new C1838u0(actionBarContextView.getContext());
        u0Var.f6087l = 1;
        this.f3327k = u0Var;
        u0Var.f6080e = this;
    }

    /* renamed from: a */
    public boolean mo330a(C1838u0 u0Var, MenuItem menuItem) {
        return this.f3324h.mo3690b(this, menuItem);
    }

    /* renamed from: b */
    public void mo331b(C1838u0 u0Var) {
        mo3681i();
        C0928j1 j1Var = this.f3323g.f3002g;
        if (j1Var != null) {
            j1Var.mo4114n();
        }
    }

    /* renamed from: c */
    public void mo3675c() {
        if (!this.f3326j) {
            this.f3326j = true;
            this.f3323g.sendAccessibilityEvent(32);
            this.f3324h.mo3692d(this);
        }
    }

    /* renamed from: d */
    public View mo3676d() {
        WeakReference<View> weakReference = this.f3325i;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    /* renamed from: e */
    public Menu mo3677e() {
        return this.f3327k;
    }

    /* renamed from: f */
    public MenuInflater mo3678f() {
        return new C1053l0(this.f3323g.getContext());
    }

    /* renamed from: g */
    public CharSequence mo3679g() {
        return this.f3323g.getSubtitle();
    }

    /* renamed from: h */
    public CharSequence mo3680h() {
        return this.f3323g.getTitle();
    }

    /* renamed from: i */
    public void mo3681i() {
        this.f3324h.mo3689a(this, this.f3327k);
    }

    /* renamed from: j */
    public boolean mo3682j() {
        return this.f3323g.f333u;
    }

    /* renamed from: k */
    public void mo3683k(View view) {
        this.f3323g.setCustomView(view);
        this.f3325i = view != null ? new WeakReference<>(view) : null;
    }

    /* renamed from: l */
    public void mo3684l(int i) {
        this.f3323g.setSubtitle(this.f3322f.getString(i));
    }

    /* renamed from: m */
    public void mo3685m(CharSequence charSequence) {
        this.f3323g.setSubtitle(charSequence);
    }

    /* renamed from: n */
    public void mo3686n(int i) {
        this.f3323g.setTitle(this.f3322f.getString(i));
    }

    /* renamed from: o */
    public void mo3687o(CharSequence charSequence) {
        this.f3323g.setTitle(charSequence);
    }

    /* renamed from: p */
    public void mo3688p(boolean z) {
        this.f2806e = z;
        this.f3323g.setTitleOptional(z);
    }
}
