package p000;

import p000.C2090xp;

/* renamed from: cw */
public class C0516cw extends C0653ew {
    public C0516cw(C2167yv yvVar, C0714fs fsVar, String str) {
        super(yvVar, fsVar, str);
    }

    /* renamed from: c */
    public C2090xp.C2091a mo1476c() {
        return C2090xp.C2091a.EXISTING_PROPERTY;
    }

    /* renamed from: i */
    public C0516cw mo2815h(C0714fs fsVar) {
        return this.f4378b == fsVar ? this : new C0516cw(this.f4377a, fsVar, this.f2618c);
    }
}
