package p000;

import android.content.Context;

@Deprecated
/* renamed from: dn */
public interface C0574dn {
    /* renamed from: a */
    void mo1718a(Context context, C1798te teVar, C2144ye yeVar);
}
