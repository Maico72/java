package p000;

import android.graphics.Bitmap;
import java.util.Objects;

/* renamed from: fk */
public class C0706fk implements C1675rh<Bitmap>, C1256nh {

    /* renamed from: d */
    public final Bitmap f2768d;

    /* renamed from: e */
    public final C0056ai f2769e;

    public C0706fk(Bitmap bitmap, C0056ai aiVar) {
        Objects.requireNonNull(bitmap, "Bitmap must not be null");
        this.f2768d = bitmap;
        Objects.requireNonNull(aiVar, "BitmapPool must not be null");
        this.f2769e = aiVar;
    }

    /* renamed from: f */
    public static C0706fk m2298f(Bitmap bitmap, C0056ai aiVar) {
        if (bitmap == null) {
            return null;
        }
        return new C0706fk(bitmap, aiVar);
    }

    /* renamed from: a */
    public void mo3626a() {
        this.f2768d.prepareToDraw();
    }

    /* renamed from: b */
    public Object mo1714b() {
        return this.f2768d;
    }

    /* renamed from: c */
    public int mo1715c() {
        return C1624qo.m4653d(this.f2768d);
    }

    /* renamed from: d */
    public Class<Bitmap> mo1716d() {
        return Bitmap.class;
    }

    /* renamed from: e */
    public void mo1717e() {
        this.f2769e.mo131e(this.f2768d);
    }
}
