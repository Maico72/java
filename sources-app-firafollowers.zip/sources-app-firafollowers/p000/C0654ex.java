package p000;

/* renamed from: ex */
public abstract class C0654ex {
    /* renamed from: a */
    public abstract C1462ps<Object> mo3414a(C0221at atVar, C1035ks ksVar, C1462ps<Object> psVar);

    /* renamed from: b */
    public abstract C0230aw mo3415b(C2164ys ysVar, C1035ks ksVar);
}
