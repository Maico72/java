package p000;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import org.fasaroid.fira.R;

/* renamed from: h1 */
public abstract class C0803h1 extends ViewGroup {

    /* renamed from: d */
    public final C0804a f2999d;

    /* renamed from: e */
    public final Context f3000e;

    /* renamed from: f */
    public ActionMenuView f3001f;

    /* renamed from: g */
    public C0928j1 f3002g;

    /* renamed from: h */
    public int f3003h;

    /* renamed from: i */
    public C0675f7 f3004i;

    /* renamed from: j */
    public boolean f3005j;

    /* renamed from: k */
    public boolean f3006k;

    /* renamed from: h1$a */
    public class C0804a implements C0738g7 {

        /* renamed from: a */
        public boolean f3007a = false;

        /* renamed from: b */
        public int f3008b;

        public C0804a() {
        }

        public void onAnimationCancel(View view) {
            this.f3007a = true;
        }

        public void onAnimationEnd(View view) {
            if (!this.f3007a) {
                C0803h1 h1Var = C0803h1.this;
                h1Var.f3004i = null;
                C0803h1.super.setVisibility(this.f3008b);
            }
        }

        public void onAnimationStart(View view) {
            C0803h1.super.setVisibility(0);
            this.f3007a = false;
        }
    }

    public C0803h1(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0803h1(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2999d = new C0804a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f3000e = context;
        } else {
            this.f3000e = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    /* renamed from: c */
    public int mo3848c(View view, int i, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    /* renamed from: d */
    public int mo3849d(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = ((i3 - measuredHeight) / 2) + i2;
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    /* renamed from: e */
    public C0675f7 mo3850e(int i, long j) {
        C0675f7 f7Var = this.f3004i;
        if (f7Var != null) {
            f7Var.mo3521b();
        }
        if (i == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            C0675f7 a = C0010a7.m28a(this);
            a.mo3520a(1.0f);
            a.mo3524e(j);
            C0804a aVar = this.f2999d;
            C0803h1.this.f3004i = a;
            aVar.f3008b = i;
            View view = (View) a.f2700a.get();
            if (view != null) {
                a.mo3526g(view, aVar);
            }
            return a;
        }
        C0675f7 a2 = C0010a7.m28a(this);
        a2.mo3520a(0.0f);
        a2.mo3524e(j);
        C0804a aVar2 = this.f2999d;
        C0803h1.this.f3004i = a2;
        aVar2.f3008b = i;
        View view2 = (View) a2.f2700a.get();
        if (view2 != null) {
            a2.mo3526g(view2, aVar2);
        }
        return a2;
    }

    public int getAnimatedVisibility() {
        return this.f3004i != null ? this.f2999d.f3008b : getVisibility();
    }

    public int getContentHeight() {
        return this.f3003h;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, C0593e.f2371a, R.attr.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(13, 0));
        obtainStyledAttributes.recycle();
        C0928j1 j1Var = this.f3002g;
        if (j1Var != null) {
            Configuration configuration2 = j1Var.f4714e.getResources().getConfiguration();
            int i = configuration2.screenWidthDp;
            int i2 = configuration2.screenHeightDp;
            j1Var.f3337s = (configuration2.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && i2 > 720) || (i > 720 && i2 > 960)) ? 5 : (i >= 500 || (i > 640 && i2 > 480) || (i > 480 && i2 > 640)) ? 4 : i >= 360 ? 3 : 2;
            C1838u0 u0Var = j1Var.f4715f;
            if (u0Var != null) {
                u0Var.mo6082q(true);
            }
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f3006k = false;
        }
        if (!this.f3006k) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f3006k = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f3006k = false;
        }
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f3005j = false;
        }
        if (!this.f3005j) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f3005j = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f3005j = false;
        }
        return true;
    }

    public abstract void setContentHeight(int i);

    public void setVisibility(int i) {
        if (i != getVisibility()) {
            C0675f7 f7Var = this.f3004i;
            if (f7Var != null) {
                f7Var.mo3521b();
            }
            super.setVisibility(i);
        }
    }
}
