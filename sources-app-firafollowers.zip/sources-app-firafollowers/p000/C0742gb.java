package p000;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import p000.C1412pa;

/* renamed from: gb */
public class C0742gb implements C1412pa.C1414b {

    /* renamed from: a */
    public final /* synthetic */ RecyclerView f2853a;

    public C0742gb(RecyclerView recyclerView) {
        this.f2853a = recyclerView;
    }

    /* renamed from: a */
    public View mo3768a(int i) {
        return this.f2853a.getChildAt(i);
    }

    /* renamed from: b */
    public int mo3769b() {
        return this.f2853a.getChildCount();
    }

    /* renamed from: c */
    public void mo3770c(int i) {
        View childAt = this.f2853a.getChildAt(i);
        if (childAt != null) {
            this.f2853a.mo1039p(childAt);
            childAt.clearAnimation();
        }
        this.f2853a.removeViewAt(i);
    }
}
