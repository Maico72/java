package p000;

import p000.C1356oq;

@C0313bt
/* renamed from: ez */
public class C0656ez extends C2171yy<Object> {

    /* renamed from: f */
    public static final C0656ez f2619f = new C0656ez();

    public C0656ez() {
        super(Short.class, C1356oq.C1358b.INT, "number");
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3748y(((Short) obj).shortValue());
    }
}
