package p000;

/* renamed from: jq */
public final class C0978jq {

    /* renamed from: a */
    public static final C0912iq f3465a;

    /* renamed from: b */
    public static final C0912iq f3466b;

    static {
        C0912iq iqVar = new C0912iq("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        f3465a = iqVar;
        f3466b = new C0912iq(iqVar, "MIME-NO-LINEFEEDS", true, '=', Integer.MAX_VALUE);
        byte[] bArr = iqVar.f3293f;
        System.arraycopy(bArr, 0, new byte[64], 0, bArr.length);
        char[] cArr = iqVar.f3292e;
        System.arraycopy(cArr, 0, new char[64], 0, cArr.length);
        int[] iArr = iqVar.f3291d;
        System.arraycopy(iArr, 0, new int[128], 0, iArr.length);
        StringBuilder sb = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
        sb.setCharAt(sb.indexOf("+"), '-');
        sb.setCharAt(sb.indexOf("/"), '_');
        new C0912iq("MODIFIED-FOR-URL", sb.toString(), false, 0, Integer.MAX_VALUE);
    }
}
