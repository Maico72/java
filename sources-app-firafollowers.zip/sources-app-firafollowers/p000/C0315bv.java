package p000;

import java.lang.annotation.Annotation;
import java.util.HashMap;

/* renamed from: bv */
public final class C0315bv implements o00 {

    /* renamed from: d */
    public HashMap<Class<?>, Annotation> f1365d;

    public C0315bv() {
    }

    public C0315bv(HashMap<Class<?>, Annotation> hashMap) {
        this.f1365d = hashMap;
    }

    /* renamed from: c */
    public static C0315bv m1202c(C0315bv bvVar, C0315bv bvVar2) {
        HashMap<Class<?>, Annotation> hashMap;
        HashMap<Class<?>, Annotation> hashMap2;
        if (bvVar == null || (hashMap = bvVar.f1365d) == null || hashMap.isEmpty()) {
            return bvVar2;
        }
        if (bvVar2 == null || (hashMap2 = bvVar2.f1365d) == null || hashMap2.isEmpty()) {
            return bvVar;
        }
        HashMap hashMap3 = new HashMap();
        for (Annotation next : bvVar2.f1365d.values()) {
            hashMap3.put(next.annotationType(), next);
        }
        for (Annotation next2 : bvVar.f1365d.values()) {
            hashMap3.put(next2.annotationType(), next2);
        }
        return new C0315bv(hashMap3);
    }

    /* renamed from: a */
    public <A extends Annotation> A mo1472a(Class<A> cls) {
        HashMap<Class<?>, Annotation> hashMap = this.f1365d;
        if (hashMap == null) {
            return null;
        }
        return (Annotation) hashMap.get(cls);
    }

    /* renamed from: b */
    public boolean mo1729b(Class<? extends Annotation>[] clsArr) {
        if (this.f1365d != null) {
            for (Class<? extends Annotation> containsKey : clsArr) {
                if (this.f1365d.containsKey(containsKey)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int size() {
        HashMap<Class<?>, Annotation> hashMap = this.f1365d;
        if (hashMap == null) {
            return 0;
        }
        return hashMap.size();
    }

    public String toString() {
        HashMap<Class<?>, Annotation> hashMap = this.f1365d;
        return hashMap == null ? "[null]" : hashMap.toString();
    }
}
