package p000;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: ec */
public class C0621ec extends AnimatorListenerAdapter {

    /* renamed from: a */
    public final /* synthetic */ C2047x3 f2520a;

    /* renamed from: b */
    public final /* synthetic */ C0545dc f2521b;

    public C0621ec(C0545dc dcVar, C2047x3 x3Var) {
        this.f2521b = dcVar;
        this.f2520a = x3Var;
    }

    public void onAnimationEnd(Animator animator) {
        this.f2520a.remove(animator);
        this.f2521b.f2218p.remove(animator);
    }

    public void onAnimationStart(Animator animator) {
        this.f2521b.f2218p.add(animator);
    }
}
