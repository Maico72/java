package p000;

/* renamed from: eo */
public interface C0645eo<R> {
}
