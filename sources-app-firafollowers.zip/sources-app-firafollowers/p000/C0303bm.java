package p000;

/* renamed from: bm */
public interface C0303bm<Z, R> {
    /* renamed from: a */
    C1675rh<R> mo149a(C1675rh<Z> rhVar, C2150yf yfVar);
}
