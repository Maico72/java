package p000;

import java.util.Objects;
import p000.C0576dp;

/* renamed from: cy */
public abstract class C0518cy<T> extends C2033ww<T> implements C2100xw {

    /* renamed from: f */
    public final C0714fs f2108f;

    /* renamed from: g */
    public final Boolean f2109g;

    public C0518cy(C0518cy<?> cyVar, C0714fs fsVar, Boolean bool) {
        super(cyVar.f5804d, false);
        this.f2108f = fsVar;
        this.f2109g = bool;
    }

    public C0518cy(Class<T> cls) {
        super(cls);
        this.f2108f = null;
        this.f2109g = null;
    }

    /* renamed from: a */
    public C1462ps<?> mo2818a(C0221at atVar, C0714fs fsVar) {
        C0576dp.C0580d l;
        if (!(fsVar == null || (l = mo5883l(atVar, fsVar, this.f5804d)) == null)) {
            Boolean b = l.mo3087b(C0576dp.C0577a.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
            if (!Objects.equals(b, this.f2109g)) {
                return mo2820r(fsVar, b);
            }
        }
        return this;
    }

    /* renamed from: g */
    public final void mo1482g(T t, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        C1460pr e = awVar.mo1478e(mqVar, awVar.mo1477d(t, C1692rq.START_ARRAY));
        mqVar.mo4633h(t);
        mo2821s(t, mqVar, atVar);
        awVar.mo1479f(mqVar, e);
    }

    /* renamed from: q */
    public final boolean mo2819q(C0221at atVar) {
        Boolean bool = this.f2109g;
        return bool == null ? atVar.mo1442E(C2237zs.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED) : bool.booleanValue();
    }

    /* renamed from: r */
    public abstract C1462ps<?> mo2820r(C0714fs fsVar, Boolean bool);

    /* renamed from: s */
    public abstract void mo2821s(T t, C1200mq mqVar, C0221at atVar);
}
