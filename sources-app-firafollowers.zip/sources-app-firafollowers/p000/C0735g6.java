package p000;

/* renamed from: g6 */
public interface C0735g6 {
}
