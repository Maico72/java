package p000;

import android.database.DataSetObservable;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: id */
public abstract class C0885id {

    /* renamed from: a */
    public final DataSetObservable f3249a = new DataSetObservable();

    /* renamed from: a */
    public abstract void mo4025a(ViewGroup viewGroup, int i, Object obj);

    /* renamed from: b */
    public void mo4026b(ViewGroup viewGroup) {
    }

    /* renamed from: c */
    public abstract int mo4027c();

    /* renamed from: d */
    public CharSequence mo4028d(int i) {
        return null;
    }

    /* renamed from: e */
    public abstract Object mo4029e(ViewGroup viewGroup, int i);

    /* renamed from: f */
    public abstract boolean mo4030f(View view, Object obj);

    /* renamed from: g */
    public void mo4031g(Parcelable parcelable, ClassLoader classLoader) {
    }

    /* renamed from: h */
    public Parcelable mo4032h() {
        return null;
    }

    /* renamed from: i */
    public abstract void mo4033i(ViewGroup viewGroup, int i, Object obj);

    /* renamed from: j */
    public void mo4034j(ViewGroup viewGroup) {
    }
}
