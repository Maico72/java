package p000;

/* renamed from: ee */
public class C0632ee extends C0685fe {
}
