package p000;

import java.io.Serializable;
import java.util.ArrayList;
import p000.C0720fv;

/* renamed from: dv */
public class C0588dv extends C0720fv implements Serializable {

    /* renamed from: d */
    public static final Class<?> f2354d = C1277ns.class;

    /* renamed from: e */
    public static final C0515cv f2355e;

    /* renamed from: f */
    public static final C0515cv f2356f;

    /* renamed from: g */
    public static final C0515cv f2357g;

    /* renamed from: h */
    public static final C0515cv f2358h;

    /* renamed from: i */
    public static final C0515cv f2359i;

    static {
        Class<String> cls = String.class;
        Class<Object> cls2 = Object.class;
        k00 M = k00.m3116M(cls);
        Class<?> cls3 = C1465pu.f4939i;
        f2355e = C0515cv.m1634e((C1757st<?>) null, M, new C1364ou(cls));
        Class cls4 = Boolean.TYPE;
        f2356f = C0515cv.m1634e((C1757st<?>) null, k00.m3116M(cls4), new C1364ou(cls4));
        Class cls5 = Integer.TYPE;
        f2357g = C0515cv.m1634e((C1757st<?>) null, k00.m3116M(cls5), new C1364ou(cls5));
        Class cls6 = Long.TYPE;
        f2358h = C0515cv.m1634e((C1757st<?>) null, k00.m3116M(cls6), new C1364ou(cls6));
        f2359i = C0515cv.m1634e((C1757st<?>) null, k00.m3116M(cls2), new C1364ou(cls2));
    }

    /* renamed from: a */
    public C0515cv mo3158a(C1757st<?> stVar, C1035ks ksVar) {
        Class<?> cls = ksVar.f3696d;
        if (cls.isPrimitive()) {
            if (cls == Integer.TYPE) {
                return f2357g;
            }
            if (cls == Long.TYPE) {
                return f2358h;
            }
            if (cls == Boolean.TYPE) {
                return f2356f;
            }
            return null;
        } else if (s00.m4866r(cls)) {
            if (cls == Object.class) {
                return f2359i;
            }
            if (cls == String.class) {
                return f2355e;
            }
            if (cls == Integer.class) {
                return f2357g;
            }
            if (cls == Long.class) {
                return f2358h;
            }
            if (cls == Boolean.class) {
                return f2356f;
            }
            return null;
        } else if (!f2354d.isAssignableFrom(cls)) {
            return null;
        } else {
            Class<?> cls2 = C1465pu.f4939i;
            return C0515cv.m1634e(stVar, ksVar, new C1364ou(cls));
        }
    }

    /* renamed from: b */
    public C1364ou mo3159b(C1757st<?> stVar, C1035ks ksVar, C0720fv.C0721a aVar) {
        C1757st<?> stVar2 = stVar;
        C1035ks ksVar2 = ksVar;
        Class<?> cls = C1465pu.f4939i;
        boolean z = true;
        if (ksVar.mo4346u()) {
            if (stVar2 == null || ((C1828tt) stVar2).mo3659a(ksVar2.f3696d) == null) {
                return new C1364ou(ksVar2.f3696d);
            }
        }
        C1465pu puVar = new C1465pu(stVar2, ksVar2, aVar);
        ArrayList arrayList = new ArrayList(8);
        Class<Object> cls2 = Object.class;
        Class<?> cls3 = puVar.f4945e.f3696d;
        if (cls3 != cls2) {
            z = false;
        }
        if (!z) {
            if (cls3.isInterface()) {
                C1465pu.m4489d(puVar.f4945e, arrayList, false);
            } else {
                C1465pu.m4490e(puVar.f4945e, arrayList, false);
            }
        }
        return new C1364ou(puVar.f4945e, puVar.f4946f, arrayList, puVar.f4947g, puVar.mo5292g(arrayList), puVar.f4944d, puVar.f4942b, puVar.f4943c, puVar.f4941a.f5782e.f3505d, puVar.f4948h);
    }
}
