package p000;

@Deprecated
/* renamed from: h0 */
public interface C0802h0 {
    /* renamed from: c */
    void mo385c();

    /* renamed from: e */
    void mo387e();
}
