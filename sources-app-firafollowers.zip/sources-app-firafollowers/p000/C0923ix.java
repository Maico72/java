package p000;

import java.util.Set;
import p000.C1203ms;

/* renamed from: ix */
public class C0923ix extends C0724fy {

    /* renamed from: o */
    public final C0724fy f3317o;

    public C0923ix(C0724fy fyVar) {
        super(fyVar, (C1638qx) null, fyVar.f2794j);
        this.f3317o = fyVar;
    }

    public C0923ix(C0724fy fyVar, Set<String> set, Set<String> set2) {
        super(fyVar, set, set2);
        this.f3317o = fyVar;
    }

    public C0923ix(C0724fy fyVar, C1638qx qxVar, Object obj) {
        super(fyVar, qxVar, obj);
        this.f3317o = fyVar;
    }

    /* renamed from: e */
    public boolean mo1480e() {
        return false;
    }

    /* renamed from: f */
    public final void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        if (atVar.mo1442E(C2237zs.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) {
            C1700rw[] rwVarArr = this.f2792h;
            if (rwVarArr == null || atVar.f1135e == null) {
                rwVarArr = this.f2791g;
            }
            boolean z = true;
            if (rwVarArr.length != 1) {
                z = false;
            }
            if (z) {
                mo4104z(obj, mqVar, atVar);
                return;
            }
        }
        mqVar.mo3712G(obj);
        mo4104z(obj, mqVar, atVar);
        mqVar.mo3735m();
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        if (this.f2796l != null) {
            mo3668p(obj, mqVar, atVar, awVar);
            return;
        }
        C1460pr r = mo3670r(awVar, obj, C1692rq.START_ARRAY);
        awVar.mo1478e(mqVar, r);
        mqVar.mo4633h(obj);
        mo4104z(obj, mqVar, atVar);
        awVar.mo1479f(mqVar, r);
    }

    /* renamed from: h */
    public C1462ps<Object> mo1483h(b10 b10) {
        return this.f3317o.mo1483h(b10);
    }

    /* renamed from: s */
    public C0724fy mo1484s() {
        return this;
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("BeanAsArraySerializer for ");
        d.append(this.f5804d.getName());
        return d.toString();
    }

    /* renamed from: v */
    public C0724fy mo1486v(Set set, Set set2) {
        return new C0923ix((C0724fy) this, (Set<String>) set, (Set<String>) set2);
    }

    /* renamed from: w */
    public C0724fy mo1487w(Object obj) {
        return new C0923ix((C0724fy) this, this.f2796l, obj);
    }

    /* renamed from: x */
    public C0724fy mo1488x(C1638qx qxVar) {
        return this.f3317o.mo1488x(qxVar);
    }

    /* renamed from: y */
    public C0724fy mo1489y(C1700rw[] rwVarArr, C1700rw[] rwVarArr2) {
        return this;
    }

    /* renamed from: z */
    public final void mo4104z(Object obj, C1200mq mqVar, C0221at atVar) {
        String str = "[anySetter]";
        C1700rw[] rwVarArr = this.f2792h;
        if (rwVarArr == null || atVar.f1135e == null) {
            rwVarArr = this.f2791g;
        }
        try {
            for (C1700rw rwVar : rwVarArr) {
                if (rwVar == null) {
                    mqVar.mo3739q();
                } else {
                    rwVar.mo3841j(obj, mqVar, atVar);
                }
            }
        } catch (Exception e) {
            if (0 != rwVarArr.length) {
                str = rwVarArr[0].f5617e.f2986d;
            }
            mo5886o(atVar, e, obj, str);
            throw null;
        } catch (StackOverflowError e2) {
            C1203ms msVar = new C1203ms(mqVar, "Infinite recursion (StackOverflowError)", e2);
            if (0 != rwVarArr.length) {
                str = rwVarArr[0].f5617e.f2986d;
            }
            msVar.mo4637d(new C1203ms.C1204a(obj, str));
            throw msVar;
        }
    }
}
