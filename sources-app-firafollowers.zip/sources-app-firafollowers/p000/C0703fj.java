package p000;

import android.text.TextUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: fj */
public final class C0703fj implements C0570dj {

    /* renamed from: b */
    public final Map<String, List<C0638ej>> f2762b;

    /* renamed from: c */
    public volatile Map<String, String> f2763c;

    /* renamed from: fj$a */
    public static final class C0704a {

        /* renamed from: b */
        public static final String f2764b;

        /* renamed from: c */
        public static final Map<String, List<C0638ej>> f2765c;

        /* renamed from: a */
        public Map<String, List<C0638ej>> f2766a = f2765c;

        static {
            String property = System.getProperty("http.agent");
            if (!TextUtils.isEmpty(property)) {
                int length = property.length();
                StringBuilder sb = new StringBuilder(property.length());
                for (int i = 0; i < length; i++) {
                    char charAt = property.charAt(i);
                    if ((charAt <= 31 && charAt != 9) || charAt >= 127) {
                        charAt = '?';
                    }
                    sb.append(charAt);
                }
                property = sb.toString();
            }
            f2764b = property;
            HashMap hashMap = new HashMap(2);
            if (!TextUtils.isEmpty(property)) {
                hashMap.put("User-Agent", Collections.singletonList(new C0705b(property)));
            }
            f2765c = Collections.unmodifiableMap(hashMap);
        }
    }

    /* renamed from: fj$b */
    public static final class C0705b implements C0638ej {

        /* renamed from: a */
        public final String f2767a;

        public C0705b(String str) {
            this.f2767a = str;
        }

        /* renamed from: a */
        public String mo3401a() {
            return this.f2767a;
        }

        public boolean equals(Object obj) {
            if (obj instanceof C0705b) {
                return this.f2767a.equals(((C0705b) obj).f2767a);
            }
            return false;
        }

        public int hashCode() {
            return this.f2767a.hashCode();
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("StringHeaderFactory{value='");
            d.append(this.f2767a);
            d.append('\'');
            d.append('}');
            return d.toString();
        }
    }

    public C0703fj(Map<String, List<C0638ej>> map) {
        this.f2762b = Collections.unmodifiableMap(map);
    }

    /* renamed from: a */
    public Map<String, String> mo3072a() {
        if (this.f2763c == null) {
            synchronized (this) {
                if (this.f2763c == null) {
                    this.f2763c = Collections.unmodifiableMap(mo3619b());
                }
            }
        }
        return this.f2763c;
    }

    /* renamed from: b */
    public final Map<String, String> mo3619b() {
        HashMap hashMap = new HashMap();
        for (Map.Entry next : this.f2762b.entrySet()) {
            List list = (List) next.getValue();
            StringBuilder sb = new StringBuilder();
            int size = list.size();
            for (int i = 0; i < size; i++) {
                String a = ((C0638ej) list.get(i)).mo3401a();
                if (!TextUtils.isEmpty(a)) {
                    sb.append(a);
                    if (i != list.size() - 1) {
                        sb.append(',');
                    }
                }
            }
            String sb2 = sb.toString();
            if (!TextUtils.isEmpty(sb2)) {
                hashMap.put(next.getKey(), sb2);
            }
        }
        return hashMap;
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0703fj) {
            return this.f2762b.equals(((C0703fj) obj).f2762b);
        }
        return false;
    }

    public int hashCode() {
        return this.f2762b.hashCode();
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("LazyHeaders{headers=");
        d.append(this.f2762b);
        d.append('}');
        return d.toString();
    }
}
