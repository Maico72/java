package p000;

import android.view.View;
import android.widget.AbsListView;
import androidx.appcompat.app.AlertController;

/* renamed from: i */
public class C0861i implements AbsListView.OnScrollListener {

    /* renamed from: a */
    public final /* synthetic */ View f3173a;

    /* renamed from: b */
    public final /* synthetic */ View f3174b;

    public C0861i(AlertController alertController, View view, View view2) {
        this.f3173a = view;
        this.f3174b = view2;
    }

    public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        AlertController.m141c(absListView, this.f3173a, this.f3174b);
    }

    public void onScrollStateChanged(AbsListView absListView, int i) {
    }
}
