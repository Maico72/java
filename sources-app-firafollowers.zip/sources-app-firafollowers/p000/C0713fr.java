package p000;

import java.io.Writer;

/* renamed from: fr */
public final class C0713fr extends Writer {

    /* renamed from: d */
    public final C2236zr f2774d;

    public C0713fr(C1628qr qrVar) {
        this.f2774d = new C2236zr(qrVar);
    }

    public Writer append(char c) {
        write((int) c);
        return this;
    }

    public Writer append(CharSequence charSequence) {
        String charSequence2 = charSequence.toString();
        this.f2774d.mo6878a(charSequence2, 0, charSequence2.length());
        return this;
    }

    public Writer append(CharSequence charSequence, int i, int i2) {
        String charSequence2 = charSequence.subSequence(i, i2).toString();
        this.f2774d.mo6878a(charSequence2, 0, charSequence2.length());
        return this;
    }

    /* renamed from: append  reason: collision with other method in class */
    public Appendable m6075append(char c) {
        write((int) c);
        return this;
    }

    public void close() {
    }

    public void flush() {
    }

    public void write(int i) {
        C2236zr zrVar = this.f2774d;
        char c = (char) i;
        if (zrVar.f7246b >= 0) {
            zrVar.mo6883f(16);
        }
        zrVar.f7252h = null;
        zrVar.f7253i = null;
        char[] cArr = zrVar.f7250f;
        if (zrVar.f7251g >= cArr.length) {
            zrVar.mo6881d();
            cArr = zrVar.f7250f;
        }
        int i2 = zrVar.f7251g;
        zrVar.f7251g = i2 + 1;
        cArr[i2] = c;
    }

    public void write(String str) {
        this.f2774d.mo6878a(str, 0, str.length());
    }

    public void write(String str, int i, int i2) {
        this.f2774d.mo6878a(str, i, i2);
    }

    public void write(char[] cArr) {
        this.f2774d.mo6879b(cArr, 0, cArr.length);
    }

    public void write(char[] cArr, int i, int i2) {
        this.f2774d.mo6879b(cArr, i, i2);
    }
}
