package p000;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.AlertController;
import java.util.Objects;
import java.util.WeakHashMap;
import p000.C1051l;

/* renamed from: b2 */
public class C0247b2 extends Spinner implements C2195z6 {

    /* renamed from: l */
    public static final int[] f1182l = {16843505};

    /* renamed from: d */
    public final C1056l1 f1183d;

    /* renamed from: e */
    public final Context f1184e;

    /* renamed from: f */
    public C1156m2 f1185f;

    /* renamed from: g */
    public SpinnerAdapter f1186g;

    /* renamed from: h */
    public final boolean f1187h;

    /* renamed from: i */
    public C0257f f1188i;

    /* renamed from: j */
    public int f1189j;

    /* renamed from: k */
    public final Rect f1190k = new Rect();

    /* renamed from: b2$a */
    public class C0248a implements ViewTreeObserver.OnGlobalLayoutListener {
        public C0248a() {
        }

        public void onGlobalLayout() {
            if (!C0247b2.this.getInternalPopup().mo1538b()) {
                C0247b2.this.mo1511b();
            }
            ViewTreeObserver viewTreeObserver = C0247b2.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    /* renamed from: b2$b */
    public class C0249b implements C0257f, DialogInterface.OnClickListener {

        /* renamed from: d */
        public C1051l f1192d;

        /* renamed from: e */
        public ListAdapter f1193e;

        /* renamed from: f */
        public CharSequence f1194f;

        public C0249b() {
        }

        /* renamed from: a */
        public void mo1537a(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: b */
        public boolean mo1538b() {
            C1051l lVar = this.f1192d;
            if (lVar != null) {
                return lVar.isShowing();
            }
            return false;
        }

        /* renamed from: c */
        public int mo1539c() {
            return 0;
        }

        /* renamed from: d */
        public void mo1540d(int i, int i2) {
            if (this.f1193e != null) {
                C1051l.C1052a aVar = new C1051l.C1052a(C0247b2.this.getPopupContext());
                CharSequence charSequence = this.f1194f;
                if (charSequence != null) {
                    aVar.f3717a.f268d = charSequence;
                }
                ListAdapter listAdapter = this.f1193e;
                int selectedItemPosition = C0247b2.this.getSelectedItemPosition();
                AlertController.C0073b bVar = aVar.f3717a;
                bVar.f277m = listAdapter;
                bVar.f278n = this;
                bVar.f281q = selectedItemPosition;
                bVar.f280p = true;
                C1051l a = aVar.mo4369a();
                this.f1192d = a;
                ListView listView = a.f3716f.f242g;
                listView.setTextDirection(i);
                listView.setTextAlignment(i2);
                this.f1192d.show();
            }
        }

        public void dismiss() {
            C1051l lVar = this.f1192d;
            if (lVar != null) {
                lVar.dismiss();
                this.f1192d = null;
            }
        }

        /* renamed from: g */
        public int mo1542g() {
            return 0;
        }

        /* renamed from: i */
        public Drawable mo1543i() {
            return null;
        }

        /* renamed from: j */
        public CharSequence mo1544j() {
            return this.f1194f;
        }

        /* renamed from: l */
        public void mo1545l(CharSequence charSequence) {
            this.f1194f = charSequence;
        }

        /* renamed from: m */
        public void mo1546m(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        /* renamed from: n */
        public void mo1547n(int i) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: o */
        public void mo1548o(ListAdapter listAdapter) {
            this.f1193e = listAdapter;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            C0247b2.this.setSelection(i);
            if (C0247b2.this.getOnItemClickListener() != null) {
                C0247b2.this.performItemClick((View) null, i, this.f1193e.getItemId(i));
            }
            C1051l lVar = this.f1192d;
            if (lVar != null) {
                lVar.dismiss();
                this.f1192d = null;
            }
        }

        /* renamed from: p */
        public void mo1550p(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }
    }

    /* renamed from: b2$c */
    public static class C0250c implements ListAdapter, SpinnerAdapter {

        /* renamed from: d */
        public SpinnerAdapter f1196d;

        /* renamed from: e */
        public ListAdapter f1197e;

        public C0250c(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f1196d = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f1197e = (ListAdapter) spinnerAdapter;
            }
            if (theme == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 23 && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                    themedSpinnerAdapter.setDropDownViewTheme(theme);
                }
            } else if (spinnerAdapter instanceof C2109y2) {
                C2109y2 y2Var = (C2109y2) spinnerAdapter;
                if (y2Var.getDropDownViewTheme() == null) {
                    y2Var.setDropDownViewTheme(theme);
                }
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f1197e;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public Object getItem(int i) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i);
        }

        public long getItemId(int i) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter == null) {
                return -1;
            }
            return spinnerAdapter.getItemId(i);
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public boolean isEnabled(int i) {
            ListAdapter listAdapter = this.f1197e;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1196d;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* renamed from: b2$d */
    public class C0251d extends C1393p2 implements C0257f {

        /* renamed from: G */
        public CharSequence f1198G;

        /* renamed from: H */
        public ListAdapter f1199H;

        /* renamed from: I */
        public final Rect f1200I = new Rect();

        /* renamed from: J */
        public int f1201J;

        /* renamed from: b2$d$a */
        public class C0252a implements AdapterView.OnItemClickListener {
            public C0252a(C0247b2 b2Var) {
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                C0247b2.this.setSelection(i);
                if (C0247b2.this.getOnItemClickListener() != null) {
                    C0251d dVar = C0251d.this;
                    C0247b2.this.performItemClick(view, i, dVar.f1199H.getItemId(i));
                }
                C0251d.this.dismiss();
            }
        }

        /* renamed from: b2$d$b */
        public class C0253b implements ViewTreeObserver.OnGlobalLayoutListener {
            public C0253b() {
            }

            public void onGlobalLayout() {
                C0251d dVar = C0251d.this;
                C0247b2 b2Var = C0247b2.this;
                Objects.requireNonNull(dVar);
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (!(b2Var.isAttachedToWindow() && b2Var.getGlobalVisibleRect(dVar.f1200I))) {
                    C0251d.this.dismiss();
                    return;
                }
                C0251d.this.mo1564t();
                C0251d.this.mo2860f();
            }
        }

        /* renamed from: b2$d$c */
        public class C0254c implements PopupWindow.OnDismissListener {

            /* renamed from: d */
            public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f1205d;

            public C0254c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f1205d = onGlobalLayoutListener;
            }

            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = C0247b2.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f1205d);
                }
            }
        }

        public C0251d(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i, 0);
            this.f4759s = C0247b2.this;
            mo5169s(true);
            this.f4757q = 0;
            this.f4760t = new C0252a(C0247b2.this);
        }

        /* renamed from: d */
        public void mo1540d(int i, int i2) {
            ViewTreeObserver viewTreeObserver;
            boolean b = mo2858b();
            mo1564t();
            this.f4743C.setInputMethodMode(2);
            mo2860f();
            C0992k2 k2Var = this.f4746f;
            k2Var.setChoiceMode(1);
            k2Var.setTextDirection(i);
            k2Var.setTextAlignment(i2);
            int selectedItemPosition = C0247b2.this.getSelectedItemPosition();
            C0992k2 k2Var2 = this.f4746f;
            if (mo2858b() && k2Var2 != null) {
                k2Var2.setListSelectionHidden(false);
                k2Var2.setSelection(selectedItemPosition);
                if (k2Var2.getChoiceMode() != 0) {
                    k2Var2.setItemChecked(selectedItemPosition, true);
                }
            }
            if (!b && (viewTreeObserver = C0247b2.this.getViewTreeObserver()) != null) {
                C0253b bVar = new C0253b();
                viewTreeObserver.addOnGlobalLayoutListener(bVar);
                this.f4743C.setOnDismissListener(new C0254c(bVar));
            }
        }

        /* renamed from: j */
        public CharSequence mo1544j() {
            return this.f1198G;
        }

        /* renamed from: l */
        public void mo1545l(CharSequence charSequence) {
            this.f1198G = charSequence;
        }

        /* renamed from: o */
        public void mo1548o(ListAdapter listAdapter) {
            super.mo1548o(listAdapter);
            this.f1199H = listAdapter;
        }

        /* renamed from: p */
        public void mo1550p(int i) {
            this.f1201J = i;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x008d  */
        /* JADX WARNING: Removed duplicated region for block: B:22:0x0096  */
        /* renamed from: t */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1564t() {
            /*
                r8 = this;
                android.graphics.drawable.Drawable r0 = r8.mo5164i()
                r1 = 0
                if (r0 == 0) goto L_0x0026
                b2 r1 = p000.C0247b2.this
                android.graphics.Rect r1 = r1.f1190k
                r0.getPadding(r1)
                b2 r0 = p000.C0247b2.this
                boolean r0 = p000.C0869i3.m2744b(r0)
                if (r0 == 0) goto L_0x001d
                b2 r0 = p000.C0247b2.this
                android.graphics.Rect r0 = r0.f1190k
                int r0 = r0.right
                goto L_0x0024
            L_0x001d:
                b2 r0 = p000.C0247b2.this
                android.graphics.Rect r0 = r0.f1190k
                int r0 = r0.left
                int r0 = -r0
            L_0x0024:
                r1 = r0
                goto L_0x002e
            L_0x0026:
                b2 r0 = p000.C0247b2.this
                android.graphics.Rect r0 = r0.f1190k
                r0.right = r1
                r0.left = r1
            L_0x002e:
                b2 r0 = p000.C0247b2.this
                int r0 = r0.getPaddingLeft()
                b2 r2 = p000.C0247b2.this
                int r2 = r2.getPaddingRight()
                b2 r3 = p000.C0247b2.this
                int r3 = r3.getWidth()
                b2 r4 = p000.C0247b2.this
                int r5 = r4.f1189j
                r6 = -2
                if (r5 != r6) goto L_0x0078
                android.widget.ListAdapter r5 = r8.f1199H
                android.widget.SpinnerAdapter r5 = (android.widget.SpinnerAdapter) r5
                android.graphics.drawable.Drawable r6 = r8.mo5164i()
                int r4 = r4.mo1510a(r5, r6)
                b2 r5 = p000.C0247b2.this
                android.content.Context r5 = r5.getContext()
                android.content.res.Resources r5 = r5.getResources()
                android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
                int r5 = r5.widthPixels
                b2 r6 = p000.C0247b2.this
                android.graphics.Rect r6 = r6.f1190k
                int r7 = r6.left
                int r5 = r5 - r7
                int r6 = r6.right
                int r5 = r5 - r6
                if (r4 <= r5) goto L_0x0070
                r4 = r5
            L_0x0070:
                int r5 = r3 - r0
                int r5 = r5 - r2
                int r4 = java.lang.Math.max(r4, r5)
                goto L_0x007e
            L_0x0078:
                r4 = -1
                if (r5 != r4) goto L_0x0082
                int r4 = r3 - r0
                int r4 = r4 - r2
            L_0x007e:
                r8.mo5168r(r4)
                goto L_0x0085
            L_0x0082:
                r8.mo5168r(r5)
            L_0x0085:
                b2 r4 = p000.C0247b2.this
                boolean r4 = p000.C0869i3.m2744b(r4)
                if (r4 == 0) goto L_0x0096
                int r3 = r3 - r2
                int r0 = r8.f4748h
                int r3 = r3 - r0
                int r0 = r8.f1201J
                int r3 = r3 - r0
                int r3 = r3 + r1
                goto L_0x009b
            L_0x0096:
                int r2 = r8.f1201J
                int r0 = r0 + r2
                int r3 = r0 + r1
            L_0x009b:
                r8.f4749i = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0247b2.C0251d.mo1564t():void");
        }
    }

    /* renamed from: b2$e */
    public static class C0255e extends View.BaseSavedState {
        public static final Parcelable.Creator<C0255e> CREATOR = new C0256a();

        /* renamed from: d */
        public boolean f1207d;

        /* renamed from: b2$e$a */
        public class C0256a implements Parcelable.Creator<C0255e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0255e(parcel);
            }

            public Object[] newArray(int i) {
                return new C0255e[i];
            }
        }

        public C0255e(Parcel parcel) {
            super(parcel);
            this.f1207d = parcel.readByte() != 0;
        }

        public C0255e(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.f1207d ? (byte) 1 : 0);
        }
    }

    /* renamed from: b2$f */
    public interface C0257f {
        /* renamed from: a */
        void mo1537a(int i);

        /* renamed from: b */
        boolean mo1538b();

        /* renamed from: c */
        int mo1539c();

        /* renamed from: d */
        void mo1540d(int i, int i2);

        void dismiss();

        /* renamed from: g */
        int mo1542g();

        /* renamed from: i */
        Drawable mo1543i();

        /* renamed from: j */
        CharSequence mo1544j();

        /* renamed from: l */
        void mo1545l(CharSequence charSequence);

        /* renamed from: m */
        void mo1546m(Drawable drawable);

        /* renamed from: n */
        void mo1547n(int i);

        /* renamed from: o */
        void mo1548o(ListAdapter listAdapter);

        /* renamed from: p */
        void mo1550p(int i);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0056, code lost:
        if (r5 != null) goto L_0x0058;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00d0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0247b2(android.content.Context r10, android.util.AttributeSet r11, int r12) {
        /*
            r9 = this;
            int[] r0 = p000.C0593e.f2392v
            r9.<init>(r10, r11, r12)
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r9.f1190k = r1
            android.content.Context r1 = r9.getContext()
            p000.C2045x2.m5634a(r9, r1)
            r1 = 0
            android.content.res.TypedArray r2 = r10.obtainStyledAttributes(r11, r0, r12, r1)
            l1 r3 = new l1
            r3.<init>(r9)
            r9.f1183d = r3
            r3 = 4
            int r3 = r2.getResourceId(r3, r1)
            if (r3 == 0) goto L_0x002e
            i0 r4 = new i0
            r4.<init>((android.content.Context) r10, (int) r3)
            r9.f1184e = r4
            goto L_0x0030
        L_0x002e:
            r9.f1184e = r10
        L_0x0030:
            r3 = 0
            r4 = -1
            int[] r5 = f1182l     // Catch:{ Exception -> 0x004c, all -> 0x0049 }
            android.content.res.TypedArray r5 = r10.obtainStyledAttributes(r11, r5, r12, r1)     // Catch:{ Exception -> 0x004c, all -> 0x0049 }
            boolean r6 = r5.hasValue(r1)     // Catch:{ Exception -> 0x0047 }
            if (r6 == 0) goto L_0x0058
            int r4 = r5.getInt(r1, r1)     // Catch:{ Exception -> 0x0047 }
            goto L_0x0058
        L_0x0043:
            r10 = move-exception
            r3 = r5
            goto L_0x00ce
        L_0x0047:
            r6 = move-exception
            goto L_0x004f
        L_0x0049:
            r10 = move-exception
            goto L_0x00ce
        L_0x004c:
            r5 = move-exception
            r6 = r5
            r5 = r3
        L_0x004f:
            java.lang.String r7 = "AppCompatSpinner"
            java.lang.String r8 = "Could not read android:spinnerMode"
            android.util.Log.i(r7, r8, r6)     // Catch:{ all -> 0x0043 }
            if (r5 == 0) goto L_0x005b
        L_0x0058:
            r5.recycle()
        L_0x005b:
            r5 = 2
            r6 = 1
            if (r4 == 0) goto L_0x0095
            if (r4 == r6) goto L_0x0062
            goto L_0x00a3
        L_0x0062:
            b2$d r4 = new b2$d
            android.content.Context r7 = r9.f1184e
            r4.<init>(r7, r11, r12)
            android.content.Context r7 = r9.f1184e
            c3 r0 = p000.C0327c3.m1245s(r7, r11, r0, r12, r1)
            r7 = 3
            r8 = -2
            int r7 = r0.mo1835l(r7, r8)
            r9.f1189j = r7
            android.graphics.drawable.Drawable r7 = r0.mo1830g(r6)
            android.widget.PopupWindow r8 = r4.f4743C
            r8.setBackgroundDrawable(r7)
            java.lang.String r5 = r2.getString(r5)
            r4.f1198G = r5
            android.content.res.TypedArray r0 = r0.f1430b
            r0.recycle()
            r9.f1188i = r4
            a2 r0 = new a2
            r0.<init>(r9, r9, r4)
            r9.f1185f = r0
            goto L_0x00a3
        L_0x0095:
            b2$b r0 = new b2$b
            r0.<init>()
            r9.f1188i = r0
            java.lang.String r4 = r2.getString(r5)
            r0.mo1545l(r4)
        L_0x00a3:
            java.lang.CharSequence[] r0 = r2.getTextArray(r1)
            if (r0 == 0) goto L_0x00ba
            android.widget.ArrayAdapter r1 = new android.widget.ArrayAdapter
            r4 = 17367048(0x1090008, float:2.5162948E-38)
            r1.<init>(r10, r4, r0)
            r10 = 2131492977(0x7f0c0071, float:1.8609421E38)
            r1.setDropDownViewResource(r10)
            r9.setAdapter((android.widget.SpinnerAdapter) r1)
        L_0x00ba:
            r2.recycle()
            r9.f1187h = r6
            android.widget.SpinnerAdapter r10 = r9.f1186g
            if (r10 == 0) goto L_0x00c8
            r9.setAdapter((android.widget.SpinnerAdapter) r10)
            r9.f1186g = r3
        L_0x00c8:
            l1 r10 = r9.f1183d
            r10.mo4390d(r11, r12)
            return
        L_0x00ce:
            if (r3 == 0) goto L_0x00d3
            r3.recycle()
        L_0x00d3:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0247b2.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* renamed from: a */
    public int mo1510a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i2 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i2 = Math.max(i2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i2;
        }
        drawable.getPadding(this.f1190k);
        Rect rect = this.f1190k;
        return i2 + rect.left + rect.right;
    }

    /* renamed from: b */
    public void mo1511b() {
        this.f1188i.mo1540d(getTextDirection(), getTextAlignment());
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            l1Var.mo4387a();
        }
    }

    public int getDropDownHorizontalOffset() {
        C0257f fVar = this.f1188i;
        return fVar != null ? fVar.mo1539c() : super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        C0257f fVar = this.f1188i;
        return fVar != null ? fVar.mo1542g() : super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        return this.f1188i != null ? this.f1189j : super.getDropDownWidth();
    }

    public final C0257f getInternalPopup() {
        return this.f1188i;
    }

    public Drawable getPopupBackground() {
        C0257f fVar = this.f1188i;
        return fVar != null ? fVar.mo1543i() : super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.f1184e;
    }

    public CharSequence getPrompt() {
        C0257f fVar = this.f1188i;
        return fVar != null ? fVar.mo1544j() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            return l1Var.mo4388b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            return l1Var.mo4389c();
        }
        return null;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0257f fVar = this.f1188i;
        if (fVar != null && fVar.mo1538b()) {
            this.f1188i.dismiss();
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1188i != null && View.MeasureSpec.getMode(i) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), mo1510a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i)), getMeasuredHeight());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        C0255e eVar = (C0255e) parcelable;
        super.onRestoreInstanceState(eVar.getSuperState());
        if (eVar.f1207d && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new C0248a());
        }
    }

    public Parcelable onSaveInstanceState() {
        C0255e eVar = new C0255e(super.onSaveInstanceState());
        C0257f fVar = this.f1188i;
        eVar.f1207d = fVar != null && fVar.mo1538b();
        return eVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C1156m2 m2Var = this.f1185f;
        if (m2Var == null || !m2Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public boolean performClick() {
        C0257f fVar = this.f1188i;
        if (fVar == null) {
            return super.performClick();
        }
        if (fVar.mo1538b()) {
            return true;
        }
        mo1511b();
        return true;
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f1187h) {
            this.f1186g = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f1188i != null) {
            Context context = this.f1184e;
            if (context == null) {
                context = getContext();
            }
            this.f1188i.mo1548o(new C0250c(spinnerAdapter, context.getTheme()));
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            l1Var.mo4391e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            l1Var.mo4392f(i);
        }
    }

    public void setDropDownHorizontalOffset(int i) {
        C0257f fVar = this.f1188i;
        if (fVar != null) {
            fVar.mo1550p(i);
            this.f1188i.mo1537a(i);
            return;
        }
        super.setDropDownHorizontalOffset(i);
    }

    public void setDropDownVerticalOffset(int i) {
        C0257f fVar = this.f1188i;
        if (fVar != null) {
            fVar.mo1547n(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    public void setDropDownWidth(int i) {
        if (this.f1188i != null) {
            this.f1189j = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        C0257f fVar = this.f1188i;
        if (fVar != null) {
            fVar.mo1546m(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(C0001a0.m1b(getPopupContext(), i));
    }

    public void setPrompt(CharSequence charSequence) {
        C0257f fVar = this.f1188i;
        if (fVar != null) {
            fVar.mo1545l(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            l1Var.mo4394h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C1056l1 l1Var = this.f1183d;
        if (l1Var != null) {
            l1Var.mo4395i(mode);
        }
    }
}
