package p000;

/* renamed from: gu */
public abstract class C0794gu {

    /* renamed from: a */
    public static final C0794gu f2988a;

    static {
        C0794gu guVar;
        try {
            guVar = (C0794gu) s00.m4855g(Class.forName("hu"), false);
        } catch (Throwable unused) {
            guVar = null;
        }
        f2988a = guVar;
    }

    /* renamed from: a */
    public abstract C1462ps<?> mo3833a(Class<?> cls);
}
