package p000;

import java.util.Objects;
import p000.C1762sx;

/* renamed from: dy */
public abstract class C0591dy<T> extends C2033ww<T> implements C2100xw {

    /* renamed from: f */
    public final C1035ks f2363f;

    /* renamed from: g */
    public final C0714fs f2364g;

    /* renamed from: h */
    public final boolean f2365h;

    /* renamed from: i */
    public final Boolean f2366i;

    /* renamed from: j */
    public final C0230aw f2367j;

    /* renamed from: k */
    public final C1462ps<Object> f2368k;

    /* renamed from: l */
    public C1762sx f2369l;

    public C0591dy(C0591dy<?> dyVar, C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, Boolean bool) {
        super((C2033ww<?>) dyVar);
        this.f2363f = dyVar.f2363f;
        this.f2365h = dyVar.f2365h;
        this.f2367j = awVar;
        this.f2364g = fsVar;
        this.f2368k = psVar;
        this.f2369l = C1762sx.C1764b.f5795b;
        this.f2366i = bool;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0591dy(Class<?> cls, C1035ks ksVar, boolean z, C0230aw awVar, C1462ps<Object> psVar) {
        super(cls, false);
        boolean z2 = false;
        this.f2363f = ksVar;
        if (z || (ksVar != null && ksVar.mo4348y())) {
            z2 = true;
        }
        this.f2365h = z2;
        this.f2367j = awVar;
        this.f2364g = null;
        this.f2368k = psVar;
        this.f2369l = C1762sx.C1764b.f5795b;
        this.f2366i = null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0031  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0062 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0063  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<?> mo2818a(p000.C0221at r6, p000.C0714fs r7) {
        /*
            r5 = this;
            aw r0 = r5.f2367j
            if (r0 == 0) goto L_0x0008
            aw r0 = r0.mo1474a(r7)
        L_0x0008:
            r1 = 0
            if (r7 == 0) goto L_0x0020
            ds r2 = r6.mo1464w()
            uu r3 = r7.mo3644a()
            if (r3 == 0) goto L_0x0020
            java.lang.Object r2 = r2.mo3130c(r3)
            if (r2 == 0) goto L_0x0020
            ps r2 = r6.mo1446I(r3, r2)
            goto L_0x0021
        L_0x0020:
            r2 = r1
        L_0x0021:
            java.lang.Class<T> r3 = r5.f5804d
            dp$d r3 = r5.mo5883l(r6, r7, r3)
            if (r3 == 0) goto L_0x002f
            dp$a r1 = p000.C0576dp.C0577a.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED
            java.lang.Boolean r1 = r3.mo3087b(r1)
        L_0x002f:
            if (r2 != 0) goto L_0x0033
            ps<java.lang.Object> r2 = r5.f2368k
        L_0x0033:
            ps r2 = r5.mo5882k(r6, r7, r2)
            if (r2 != 0) goto L_0x004d
            ks r3 = r5.f2363f
            if (r3 == 0) goto L_0x004d
            boolean r4 = r5.f2365h
            if (r4 == 0) goto L_0x004d
            boolean r3 = r3.mo4349z()
            if (r3 != 0) goto L_0x004d
            ks r2 = r5.f2363f
            ps r2 = r6.mo1455n(r2, r7)
        L_0x004d:
            ps<java.lang.Object> r6 = r5.f2368k
            if (r2 != r6) goto L_0x0063
            fs r6 = r5.f2364g
            if (r7 != r6) goto L_0x0063
            aw r6 = r5.f2367j
            if (r6 != r0) goto L_0x0063
            java.lang.Boolean r6 = r5.f2366i
            boolean r6 = java.util.Objects.equals(r6, r1)
            if (r6 != 0) goto L_0x0062
            goto L_0x0063
        L_0x0062:
            return r5
        L_0x0063:
            dy r6 = r5.mo3164s(r7, r0, r2, r1)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0591dy.mo2818a(at, fs):ps");
    }

    /* renamed from: g */
    public void mo1482g(T t, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        C1460pr e = awVar.mo1478e(mqVar, awVar.mo1477d(t, C1692rq.START_ARRAY));
        mqVar.mo4633h(t);
        mo3163r(t, mqVar, atVar);
        awVar.mo1479f(mqVar, e);
    }

    /* renamed from: q */
    public final C1462ps<Object> mo3162q(C1762sx sxVar, Class<?> cls, C0221at atVar) {
        C0714fs fsVar = this.f2364g;
        Objects.requireNonNull(sxVar);
        C1462ps<Object> o = atVar.mo1456o(cls, fsVar);
        C1762sx b = sxVar.mo5879b(cls, o);
        if (sxVar != b) {
            this.f2369l = b;
        }
        return o;
    }

    /* renamed from: r */
    public abstract void mo3163r(T t, C1200mq mqVar, C0221at atVar);

    /* renamed from: s */
    public abstract C0591dy<T> mo3164s(C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, Boolean bool);
}
