package p000;

import android.os.Build;
import android.os.SystemClock;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import p000.C0289bh;
import p000.C0635eh;
import p000.C0770gh;
import p000.C0833hg;
import p000.C0835hh;
import p000.C1117lh;
import p000.C1685ro;
import p000.C1877uo;

/* renamed from: dh */
public class C0560dh<R> implements C0289bh.C0290a, Runnable, Comparable<C0560dh<?>>, C1685ro.C1689d {

    /* renamed from: A */
    public C2005wf f2253A;

    /* renamed from: B */
    public C2005wf f2254B;

    /* renamed from: C */
    public Object f2255C;

    /* renamed from: D */
    public C1017kf f2256D;

    /* renamed from: E */
    public C0768gg<?> f2257E;

    /* renamed from: F */
    public volatile C0289bh f2258F;

    /* renamed from: G */
    public volatile boolean f2259G;

    /* renamed from: H */
    public volatile boolean f2260H;

    /* renamed from: I */
    public boolean f2261I;

    /* renamed from: d */
    public final C0364ch<R> f2262d = new C0364ch<>();

    /* renamed from: e */
    public final List<Throwable> f2263e = new ArrayList();

    /* renamed from: f */
    public final C1877uo f2264f = new C1877uo.C1879b();

    /* renamed from: g */
    public final C0564d f2265g;

    /* renamed from: h */
    public final C0940j6<C0560dh<?>> f2266h;

    /* renamed from: i */
    public final C0563c<?> f2267i = new C0563c<>();

    /* renamed from: j */
    public final C0565e f2268j = new C0565e();

    /* renamed from: k */
    public C1933ve f2269k;

    /* renamed from: l */
    public C2005wf f2270l;

    /* renamed from: m */
    public C2066xe f2271m;

    /* renamed from: n */
    public C0964jh f2272n;

    /* renamed from: o */
    public int f2273o;

    /* renamed from: p */
    public int f2274p;

    /* renamed from: q */
    public C0696fh f2275q;

    /* renamed from: r */
    public C2150yf f2276r;

    /* renamed from: s */
    public C0561a<R> f2277s;

    /* renamed from: t */
    public int f2278t;

    /* renamed from: u */
    public C0567g f2279u;

    /* renamed from: v */
    public C0566f f2280v;

    /* renamed from: w */
    public long f2281w;

    /* renamed from: x */
    public boolean f2282x;

    /* renamed from: y */
    public Object f2283y;

    /* renamed from: z */
    public Thread f2284z;

    /* renamed from: dh$a */
    public interface C0561a<R> {
    }

    /* renamed from: dh$b */
    public final class C0562b<Z> implements C0635eh.C0636a<Z> {

        /* renamed from: a */
        public final C1017kf f2285a;

        public C0562b(C1017kf kfVar) {
            this.f2285a = kfVar;
        }
    }

    /* renamed from: dh$c */
    public static class C0563c<Z> {

        /* renamed from: a */
        public C2005wf f2287a;

        /* renamed from: b */
        public C0288bg<Z> f2288b;

        /* renamed from: c */
        public C1613qh<Z> f2289c;
    }

    /* renamed from: dh$d */
    public interface C0564d {
    }

    /* renamed from: dh$e */
    public static class C0565e {

        /* renamed from: a */
        public boolean f2290a;

        /* renamed from: b */
        public boolean f2291b;

        /* renamed from: c */
        public boolean f2292c;

        /* renamed from: a */
        public final boolean mo3066a(boolean z) {
            return (this.f2292c || z || this.f2291b) && this.f2290a;
        }
    }

    /* renamed from: dh$f */
    public enum C0566f {
        INITIALIZE,
        SWITCH_TO_SOURCE_SERVICE,
        DECODE_DATA
    }

    /* renamed from: dh$g */
    public enum C0567g {
        INITIALIZE,
        RESOURCE_CACHE,
        DATA_CACHE,
        SOURCE,
        ENCODE,
        FINISHED
    }

    public C0560dh(C0564d dVar, C0940j6<C0560dh<?>> j6Var) {
        this.f2265g = dVar;
        this.f2266h = j6Var;
    }

    /* renamed from: a */
    public C1877uo mo3052a() {
        return this.f2264f;
    }

    /* renamed from: b */
    public void mo1708b() {
        this.f2280v = C0566f.SWITCH_TO_SOURCE_SERVICE;
        ((C0835hh) this.f2277s).mo3940i(this);
    }

    /* renamed from: c */
    public void mo1709c(C2005wf wfVar, Object obj, C0768gg<?> ggVar, C1017kf kfVar, C2005wf wfVar2) {
        this.f2253A = wfVar;
        this.f2255C = obj;
        this.f2257E = ggVar;
        this.f2256D = kfVar;
        this.f2254B = wfVar2;
        boolean z = false;
        if (wfVar != this.f2262d.mo1953a().get(0)) {
            z = true;
        }
        this.f2261I = z;
        if (Thread.currentThread() != this.f2284z) {
            this.f2280v = C0566f.DECODE_DATA;
            ((C0835hh) this.f2277s).mo3940i(this);
            return;
        }
        mo3056g();
    }

    public int compareTo(Object obj) {
        C0560dh dhVar = (C0560dh) obj;
        int ordinal = this.f2271m.ordinal() - dhVar.f2271m.ordinal();
        return ordinal == 0 ? this.f2278t - dhVar.f2278t : ordinal;
    }

    /* renamed from: d */
    public void mo1710d(C2005wf wfVar, Exception exc, C0768gg<?> ggVar, C1017kf kfVar) {
        ggVar.mo135b();
        C1182mh mhVar = new C1182mh("Fetching data failed", (Throwable) exc);
        Class<?> a = ggVar.mo134a();
        mhVar.f4058e = wfVar;
        mhVar.f4059f = kfVar;
        mhVar.f4060g = a;
        this.f2263e.add(mhVar);
        if (Thread.currentThread() != this.f2284z) {
            this.f2280v = C0566f.SWITCH_TO_SOURCE_SERVICE;
            ((C0835hh) this.f2277s).mo3940i(this);
            return;
        }
        mo3062m();
    }

    /* renamed from: e */
    public final <Data> C1675rh<R> mo3054e(C0768gg<?> ggVar, Data data, C1017kf kfVar) {
        if (data == null) {
            ggVar.mo135b();
            return null;
        }
        try {
            int i = C1198mo.f4090b;
            long elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos();
            C1675rh<R> f = mo3055f(data, kfVar);
            if (Log.isLoggable("DecodeJob", 2)) {
                mo3059j("Decoded result " + f, elapsedRealtimeNanos, (String) null);
            }
            return f;
        } finally {
            ggVar.mo135b();
        }
    }

    /* renamed from: f */
    public final <Data> C1675rh<R> mo3055f(Data data, C1017kf kfVar) {
        C0833hg<?> b;
        C1448ph<Data, ?, R> d = this.f2262d.mo1956d(data.getClass());
        C2150yf yfVar = this.f2276r;
        if (Build.VERSION.SDK_INT >= 26) {
            boolean z = kfVar == C1017kf.RESOURCE_DISK_CACHE || this.f2262d.f1608r;
            C2067xf xfVar = C1263nk.f4321i;
            Boolean bool = (Boolean) yfVar.mo6704c(xfVar);
            if (bool == null || (bool.booleanValue() && !z)) {
                yfVar = new C2150yf();
                yfVar.mo6705d(this.f2276r);
                yfVar.f6950b.put(xfVar, Boolean.valueOf(z));
            }
        }
        C2150yf yfVar2 = yfVar;
        C0890ig igVar = this.f2269k.f6371b.f6939e;
        synchronized (igVar) {
            C0833hg.C0834a<?> aVar = igVar.f3265a.get(data.getClass());
            if (aVar == null) {
                Iterator<C0833hg.C0834a<?>> it = igVar.f3265a.values().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    C0833hg.C0834a<?> next = it.next();
                    if (next.mo1983a().isAssignableFrom(data.getClass())) {
                        aVar = next;
                        break;
                    }
                }
            }
            if (aVar == null) {
                aVar = C0890ig.f3264b;
            }
            b = aVar.mo1984b(data);
        }
        try {
            return d.mo5255a(b, yfVar2, this.f2273o, this.f2274p, new C0562b(kfVar));
        } finally {
            b.mo1980b();
        }
    }

    /* renamed from: g */
    public final void mo3056g() {
        C1675rh<R> rhVar;
        C0563c<?> cVar;
        boolean a;
        if (Log.isLoggable("DecodeJob", 2)) {
            long j = this.f2281w;
            StringBuilder d = C1012kd.m3195d("data: ");
            d.append(this.f2255C);
            d.append(", cache key: ");
            d.append(this.f2253A);
            d.append(", fetcher: ");
            d.append(this.f2257E);
            mo3059j("Retrieved data", j, d.toString());
        }
        C1613qh<R> qhVar = null;
        try {
            rhVar = mo3054e(this.f2257E, this.f2255C, this.f2256D);
        } catch (C1182mh e) {
            C2005wf wfVar = this.f2254B;
            C1017kf kfVar = this.f2256D;
            e.f4058e = wfVar;
            e.f4059f = kfVar;
            e.f4060g = null;
            this.f2263e.add(e);
            rhVar = null;
        }
        if (rhVar != null) {
            C1017kf kfVar2 = this.f2256D;
            boolean z = this.f2261I;
            if (rhVar instanceof C1256nh) {
                ((C1256nh) rhVar).mo3626a();
            }
            if (this.f2267i.f2289c != null) {
                qhVar = C1613qh.m4629f(rhVar);
                rhVar = qhVar;
            }
            mo3064o();
            C0835hh hhVar = (C0835hh) this.f2277s;
            synchronized (hhVar) {
                hhVar.f3125t = rhVar;
                hhVar.f3126u = kfVar2;
                hhVar.f3108B = z;
            }
            synchronized (hhVar) {
                hhVar.f3110e.mo6134a();
                if (hhVar.f3107A) {
                    hhVar.f3125t.mo1717e();
                    hhVar.mo3938g();
                } else if (hhVar.f3109d.isEmpty()) {
                    throw new IllegalStateException("Received a resource without any callbacks to notify");
                } else if (!hhVar.f3127v) {
                    C0835hh.C0838c cVar2 = hhVar.f3113h;
                    C1675rh<?> rhVar2 = hhVar.f3125t;
                    boolean z2 = hhVar.f3121p;
                    C2005wf wfVar2 = hhVar.f3120o;
                    C1117lh.C1118a aVar = hhVar.f3111f;
                    Objects.requireNonNull(cVar2);
                    hhVar.f3130y = new C1117lh(rhVar2, z2, true, wfVar2, aVar);
                    hhVar.f3127v = true;
                    C0835hh.C0840e eVar = hhVar.f3109d;
                    Objects.requireNonNull(eVar);
                    ArrayList arrayList = new ArrayList(eVar.f3138d);
                    hhVar.mo3936e(arrayList.size() + 1);
                    C2005wf wfVar3 = hhVar.f3120o;
                    C1117lh<?> lhVar = hhVar.f3130y;
                    ((C0770gh) hhVar.f3114i).mo3807e(hhVar, wfVar3, lhVar);
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        C0835hh.C0839d dVar = (C0835hh.C0839d) it.next();
                        dVar.f3137b.execute(new C0835hh.C0837b(dVar.f3136a));
                    }
                    hhVar.mo3935d();
                } else {
                    throw new IllegalStateException("Already have resource");
                }
            }
            this.f2279u = C0567g.ENCODE;
            try {
                cVar = this.f2267i;
                if (cVar.f2289c != null) {
                    ((C0770gh.C0775c) this.f2265g).mo3811a().mo4281a(cVar.f2287a, new C0055ah(cVar.f2288b, cVar.f2289c, this.f2276r));
                    cVar.f2289c.mo5599g();
                }
                if (qhVar != null) {
                    qhVar.mo5599g();
                }
                C0565e eVar2 = this.f2268j;
                synchronized (eVar2) {
                    eVar2.f2291b = true;
                    a = eVar2.mo3066a(false);
                }
                if (a) {
                    mo3061l();
                }
            } catch (Throwable th) {
                if (qhVar != null) {
                    qhVar.mo5599g();
                }
                throw th;
            }
        } else {
            mo3062m();
        }
    }

    /* renamed from: h */
    public final C0289bh mo3057h() {
        int ordinal = this.f2279u.ordinal();
        if (ordinal == 1) {
            return new C1739sh(this.f2262d, this);
        }
        if (ordinal == 2) {
            return new C2151yg(this.f2262d, this);
        }
        if (ordinal == 3) {
            return new C2007wh(this.f2262d, this);
        }
        if (ordinal == 5) {
            return null;
        }
        StringBuilder d = C1012kd.m3195d("Unrecognized stage: ");
        d.append(this.f2279u);
        throw new IllegalStateException(d.toString());
    }

    /* renamed from: i */
    public final C0567g mo3058i(C0567g gVar) {
        C0567g gVar2 = C0567g.RESOURCE_CACHE;
        C0567g gVar3 = C0567g.DATA_CACHE;
        C0567g gVar4 = C0567g.FINISHED;
        int ordinal = gVar.ordinal();
        if (ordinal == 0) {
            return this.f2275q.mo3600b() ? gVar2 : mo3058i(gVar2);
        }
        if (ordinal == 1) {
            return this.f2275q.mo3599a() ? gVar3 : mo3058i(gVar3);
        }
        if (ordinal == 2) {
            return this.f2282x ? gVar4 : C0567g.SOURCE;
        }
        if (ordinal == 3 || ordinal == 5) {
            return gVar4;
        }
        throw new IllegalArgumentException("Unrecognized stage: " + gVar);
    }

    /* renamed from: j */
    public final void mo3059j(String str, long j, String str2) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(" in ");
        sb.append(C1198mo.m3727a(j));
        sb.append(", load key: ");
        sb.append(this.f2272n);
        sb.append(str2 != null ? C1012kd.m3202k(", ", str2) : "");
        sb.append(", thread: ");
        sb.append(Thread.currentThread().getName());
        Log.v("DecodeJob", sb.toString());
    }

    /* renamed from: k */
    public final void mo3060k() {
        boolean a;
        mo3064o();
        C1182mh mhVar = new C1182mh("Failed to load resource", (List<Throwable>) new ArrayList(this.f2263e));
        C0835hh hhVar = (C0835hh) this.f2277s;
        synchronized (hhVar) {
            hhVar.f3128w = mhVar;
        }
        synchronized (hhVar) {
            hhVar.f3110e.mo6134a();
            if (hhVar.f3107A) {
                hhVar.mo3938g();
            } else if (hhVar.f3109d.isEmpty()) {
                throw new IllegalStateException("Received an exception without any callbacks to notify");
            } else if (!hhVar.f3129x) {
                hhVar.f3129x = true;
                C2005wf wfVar = hhVar.f3120o;
                C0835hh.C0840e eVar = hhVar.f3109d;
                Objects.requireNonNull(eVar);
                ArrayList arrayList = new ArrayList(eVar.f3138d);
                hhVar.mo3936e(arrayList.size() + 1);
                ((C0770gh) hhVar.f3114i).mo3807e(hhVar, wfVar, (C1117lh<?>) null);
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    C0835hh.C0839d dVar = (C0835hh.C0839d) it.next();
                    dVar.f3137b.execute(new C0835hh.C0836a(dVar.f3136a));
                }
                hhVar.mo3935d();
            } else {
                throw new IllegalStateException("Already failed once");
            }
        }
        C0565e eVar2 = this.f2268j;
        synchronized (eVar2) {
            eVar2.f2292c = true;
            a = eVar2.mo3066a(false);
        }
        if (a) {
            mo3061l();
        }
    }

    /* renamed from: l */
    public final void mo3061l() {
        C0565e eVar = this.f2268j;
        synchronized (eVar) {
            eVar.f2291b = false;
            eVar.f2290a = false;
            eVar.f2292c = false;
        }
        C0563c<?> cVar = this.f2267i;
        cVar.f2287a = null;
        cVar.f2288b = null;
        cVar.f2289c = null;
        C0364ch<R> chVar = this.f2262d;
        chVar.f1593c = null;
        chVar.f1594d = null;
        chVar.f1604n = null;
        chVar.f1597g = null;
        chVar.f1601k = null;
        chVar.f1599i = null;
        chVar.f1605o = null;
        chVar.f1600j = null;
        chVar.f1606p = null;
        chVar.f1591a.clear();
        chVar.f1602l = false;
        chVar.f1592b.clear();
        chVar.f1603m = false;
        this.f2259G = false;
        this.f2269k = null;
        this.f2270l = null;
        this.f2276r = null;
        this.f2271m = null;
        this.f2272n = null;
        this.f2277s = null;
        this.f2279u = null;
        this.f2258F = null;
        this.f2284z = null;
        this.f2253A = null;
        this.f2255C = null;
        this.f2256D = null;
        this.f2257E = null;
        this.f2281w = 0;
        this.f2260H = false;
        this.f2283y = null;
        this.f2263e.clear();
        this.f2266h.mo4123a(this);
    }

    /* renamed from: m */
    public final void mo3062m() {
        this.f2284z = Thread.currentThread();
        int i = C1198mo.f4090b;
        this.f2281w = SystemClock.elapsedRealtimeNanos();
        boolean z = false;
        while (!this.f2260H && this.f2258F != null && !(z = this.f2258F.mo1706a())) {
            this.f2279u = mo3058i(this.f2279u);
            this.f2258F = mo3057h();
            if (this.f2279u == C0567g.SOURCE) {
                this.f2280v = C0566f.SWITCH_TO_SOURCE_SERVICE;
                ((C0835hh) this.f2277s).mo3940i(this);
                return;
            }
        }
        if ((this.f2279u == C0567g.FINISHED || this.f2260H) && !z) {
            mo3060k();
        }
    }

    /* renamed from: n */
    public final void mo3063n() {
        int ordinal = this.f2280v.ordinal();
        if (ordinal == 0) {
            this.f2279u = mo3058i(C0567g.INITIALIZE);
            this.f2258F = mo3057h();
        } else if (ordinal != 1) {
            if (ordinal == 2) {
                mo3056g();
                return;
            }
            StringBuilder d = C1012kd.m3195d("Unrecognized run reason: ");
            d.append(this.f2280v);
            throw new IllegalStateException(d.toString());
        }
        mo3062m();
    }

    /* renamed from: o */
    public final void mo3064o() {
        Throwable th;
        this.f2264f.mo6134a();
        if (this.f2259G) {
            if (this.f2263e.isEmpty()) {
                th = null;
            } else {
                List<Throwable> list = this.f2263e;
                th = list.get(list.size() - 1);
            }
            throw new IllegalStateException("Already notified", th);
        }
        this.f2259G = true;
    }

    public void run() {
        C0768gg<?> ggVar = this.f2257E;
        try {
            if (this.f2260H) {
                mo3060k();
                if (ggVar != null) {
                    ggVar.mo135b();
                    return;
                }
                return;
            }
            mo3063n();
            if (ggVar != null) {
                ggVar.mo135b();
            }
        } catch (C2070xg e) {
            throw e;
        } catch (Throwable th) {
            if (ggVar != null) {
                ggVar.mo135b();
            }
            throw th;
        }
    }
}
