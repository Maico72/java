package p000;

import android.util.Log;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.Objects;

/* renamed from: if */
public class C0889if {

    /* renamed from: a */
    public final byte[] f3258a = new byte[256];

    /* renamed from: b */
    public ByteBuffer f3259b;

    /* renamed from: c */
    public C0832hf f3260c;

    /* renamed from: d */
    public int f3261d = 0;

    /* renamed from: a */
    public final boolean mo4038a() {
        return this.f3260c.f3093b != 0;
    }

    /* renamed from: b */
    public C0832hf mo4039b() {
        if (this.f3259b == null) {
            throw new IllegalStateException("You must call setData() before parseHeader()");
        } else if (mo4038a()) {
            return this.f3260c;
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) {
                sb.append((char) mo4040c());
            }
            if (!sb.toString().startsWith("GIF")) {
                this.f3260c.f3093b = 1;
            } else {
                this.f3260c.f3097f = mo4043f();
                this.f3260c.f3098g = mo4043f();
                int c = mo4040c();
                C0832hf hfVar = this.f3260c;
                hfVar.f3099h = (c & 128) != 0;
                hfVar.f3100i = (int) Math.pow(2.0d, (double) ((c & 7) + 1));
                this.f3260c.f3101j = mo4040c();
                C0832hf hfVar2 = this.f3260c;
                mo4040c();
                Objects.requireNonNull(hfVar2);
                if (this.f3260c.f3099h && !mo4038a()) {
                    C0832hf hfVar3 = this.f3260c;
                    hfVar3.f3092a = mo4042e(hfVar3.f3100i);
                    C0832hf hfVar4 = this.f3260c;
                    hfVar4.f3102k = hfVar4.f3092a[hfVar4.f3101j];
                }
            }
            if (!mo4038a()) {
                boolean z = false;
                while (!z && !mo4038a() && this.f3260c.f3094c <= Integer.MAX_VALUE) {
                    int c2 = mo4040c();
                    if (c2 == 33) {
                        int c3 = mo4040c();
                        if (c3 != 1) {
                            if (c3 == 249) {
                                this.f3260c.f3095d = new C0767gf();
                                mo4040c();
                                int c4 = mo4040c();
                                C0767gf gfVar = this.f3260c.f3095d;
                                int i2 = (c4 & 28) >> 2;
                                gfVar.f2929g = i2;
                                if (i2 == 0) {
                                    gfVar.f2929g = 1;
                                }
                                gfVar.f2928f = (c4 & 1) != 0;
                                int f = mo4043f();
                                if (f < 2) {
                                    f = 10;
                                }
                                C0767gf gfVar2 = this.f3260c.f3095d;
                                gfVar2.f2931i = f * 10;
                                gfVar2.f2930h = mo4040c();
                                mo4040c();
                            } else if (c3 != 254 && c3 == 255) {
                                mo4041d();
                                StringBuilder sb2 = new StringBuilder();
                                for (int i3 = 0; i3 < 11; i3++) {
                                    sb2.append((char) this.f3258a[i3]);
                                }
                                if (sb2.toString().equals("NETSCAPE2.0")) {
                                    do {
                                        mo4041d();
                                        byte[] bArr = this.f3258a;
                                        if (bArr[0] == 1) {
                                            byte b = bArr[1];
                                            byte b2 = bArr[2];
                                            Objects.requireNonNull(this.f3260c);
                                        }
                                        if (this.f3261d <= 0) {
                                            break;
                                        }
                                    } while (mo4038a());
                                }
                            }
                        }
                        mo4044g();
                    } else if (c2 == 44) {
                        C0832hf hfVar5 = this.f3260c;
                        if (hfVar5.f3095d == null) {
                            hfVar5.f3095d = new C0767gf();
                        }
                        hfVar5.f3095d.f2923a = mo4043f();
                        this.f3260c.f3095d.f2924b = mo4043f();
                        this.f3260c.f3095d.f2925c = mo4043f();
                        this.f3260c.f3095d.f2926d = mo4043f();
                        int c5 = mo4040c();
                        boolean z2 = (c5 & 128) != 0;
                        int pow = (int) Math.pow(2.0d, (double) ((c5 & 7) + 1));
                        C0767gf gfVar3 = this.f3260c.f3095d;
                        gfVar3.f2927e = (c5 & 64) != 0;
                        if (z2) {
                            gfVar3.f2933k = mo4042e(pow);
                        } else {
                            gfVar3.f2933k = null;
                        }
                        this.f3260c.f3095d.f2932j = this.f3259b.position();
                        mo4040c();
                        mo4044g();
                        if (!mo4038a()) {
                            C0832hf hfVar6 = this.f3260c;
                            hfVar6.f3094c++;
                            hfVar6.f3096e.add(hfVar6.f3095d);
                        }
                    } else if (c2 != 59) {
                        this.f3260c.f3093b = 1;
                    } else {
                        z = true;
                    }
                }
                C0832hf hfVar7 = this.f3260c;
                if (hfVar7.f3094c < 0) {
                    hfVar7.f3093b = 1;
                }
            }
            return this.f3260c;
        }
    }

    /* renamed from: c */
    public final int mo4040c() {
        try {
            return this.f3259b.get() & 255;
        } catch (Exception unused) {
            this.f3260c.f3093b = 1;
            return 0;
        }
    }

    /* renamed from: d */
    public final void mo4041d() {
        int c = mo4040c();
        this.f3261d = c;
        if (c > 0) {
            int i = 0;
            int i2 = 0;
            while (true) {
                try {
                    int i3 = this.f3261d;
                    if (i < i3) {
                        i2 = i3 - i;
                        this.f3259b.get(this.f3258a, i, i2);
                        i += i2;
                    } else {
                        return;
                    }
                } catch (Exception e) {
                    if (Log.isLoggable("GifHeaderParser", 3)) {
                        Log.d("GifHeaderParser", "Error Reading Block n: " + i + " count: " + i2 + " blockSize: " + this.f3261d, e);
                    }
                    this.f3260c.f3093b = 1;
                    return;
                }
            }
        }
    }

    /* renamed from: e */
    public final int[] mo4042e(int i) {
        byte[] bArr = new byte[(i * 3)];
        int[] iArr = null;
        try {
            this.f3259b.get(bArr);
            iArr = new int[256];
            int i2 = 0;
            int i3 = 0;
            while (i2 < i) {
                int i4 = i3 + 1;
                int i5 = i4 + 1;
                int i6 = i5 + 1;
                int i7 = i2 + 1;
                iArr[i2] = ((bArr[i3] & 255) << 16) | -16777216 | ((bArr[i4] & 255) << 8) | (bArr[i5] & 255);
                i3 = i6;
                i2 = i7;
            }
        } catch (BufferUnderflowException e) {
            if (Log.isLoggable("GifHeaderParser", 3)) {
                Log.d("GifHeaderParser", "Format Error Reading Color Table", e);
            }
            this.f3260c.f3093b = 1;
        }
        return iArr;
    }

    /* renamed from: f */
    public final int mo4043f() {
        return this.f3259b.getShort();
    }

    /* renamed from: g */
    public final void mo4044g() {
        int c;
        do {
            c = mo4040c();
            this.f3259b.position(Math.min(this.f3259b.position() + c, this.f3259b.limit()));
        } while (c > 0);
    }
}
