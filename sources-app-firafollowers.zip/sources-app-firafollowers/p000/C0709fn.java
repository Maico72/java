package p000;

import com.bumptech.glide.load.ImageHeaderParser;
import java.util.ArrayList;
import java.util.List;

/* renamed from: fn */
public final class C0709fn {

    /* renamed from: a */
    public final List<ImageHeaderParser> f2771a = new ArrayList();
}
