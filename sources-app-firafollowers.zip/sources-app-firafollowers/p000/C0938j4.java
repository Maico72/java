package p000;

import org.fasaroid.fira.R;

/* renamed from: j4 */
public final class C0938j4 {

    /* renamed from: a */
    public static final int[] f3355a = {16843173, 16843551, R.attr.alpha};

    /* renamed from: b */
    public static final int[] f3356b = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};

    /* renamed from: c */
    public static final int[] f3357c = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: d */
    public static final int[] f3358d = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};

    /* renamed from: e */
    public static final int[] f3359e = {16843173, 16844052};
}
