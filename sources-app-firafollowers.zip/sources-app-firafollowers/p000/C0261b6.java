package p000;

import p000.C0332c6;
import p000.C0534d6;

/* renamed from: b6 */
public class C0261b6 implements C0534d6.C0537c<C0332c6.C0336d> {

    /* renamed from: a */
    public final /* synthetic */ String f1255a;

    public C0261b6(String str) {
        this.f1255a = str;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001c, code lost:
        if (r0 >= r2.size()) goto L_0x002a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001e, code lost:
        ((p000.C0534d6.C0537c) r2.get(r0)).mo26a(r5);
        r0 = r0 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002a, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0017, code lost:
        r0 = 0;
     */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo26a(p000.C0332c6.C0336d r5) {
        /*
            r4 = this;
            java.lang.Object r0 = p000.C0332c6.f1447c
            monitor-enter(r0)
            e4<java.lang.String, java.util.ArrayList<d6$c<c6$d>>> r1 = p000.C0332c6.f1448d     // Catch:{ all -> 0x002b }
            java.lang.String r2 = r4.f1255a     // Catch:{ all -> 0x002b }
            java.lang.Object r2 = r1.get(r2)     // Catch:{ all -> 0x002b }
            java.util.ArrayList r2 = (java.util.ArrayList) r2     // Catch:{ all -> 0x002b }
            if (r2 != 0) goto L_0x0011
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            return
        L_0x0011:
            java.lang.String r3 = r4.f1255a     // Catch:{ all -> 0x002b }
            r1.remove(r3)     // Catch:{ all -> 0x002b }
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            r0 = 0
        L_0x0018:
            int r1 = r2.size()
            if (r0 >= r1) goto L_0x002a
            java.lang.Object r1 = r2.get(r0)
            d6$c r1 = (p000.C0534d6.C0537c) r1
            r1.mo26a(r5)
            int r0 = r0 + 1
            goto L_0x0018
        L_0x002a:
            return
        L_0x002b:
            r5 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            goto L_0x002f
        L_0x002e:
            throw r5
        L_0x002f:
            goto L_0x002e
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0261b6.mo26a(c6$d):void");
    }
}
