package p000;

import androidx.activity.OnBackPressedDispatcher;

/* renamed from: c */
public interface C0320c extends C1725s9 {
    /* renamed from: c */
    OnBackPressedDispatcher mo151c();
}
