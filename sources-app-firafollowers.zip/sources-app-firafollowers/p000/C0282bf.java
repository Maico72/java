package p000;

import p000.C0282bf;

/* renamed from: bf */
public abstract class C0282bf<CHILD extends C0282bf<CHILD, TranscodeType>, TranscodeType> implements Cloneable {
    /* renamed from: a */
    public final CHILD mo1699a() {
        try {
            return (C0282bf) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    public Object clone() {
        try {
            return (C0282bf) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}
