package p000;

import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Objects;

/* renamed from: j7 */
public class C0943j7 {

    /* renamed from: b */
    public static final C0943j7 f3370b;

    /* renamed from: a */
    public final C0951h f3371a;

    /* renamed from: j7$a */
    public static class C0944a extends C0946c {

        /* renamed from: c */
        public static Field f3372c;

        /* renamed from: d */
        public static boolean f3373d;

        /* renamed from: e */
        public static Constructor<WindowInsets> f3374e;

        /* renamed from: f */
        public static boolean f3375f;

        /* renamed from: b */
        public WindowInsets f3376b;

        public C0944a() {
            if (!f3373d) {
                try {
                    f3372c = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e);
                }
                f3373d = true;
            }
            Field field = f3372c;
            WindowInsets windowInsets = null;
            if (field != null) {
                try {
                    WindowInsets windowInsets2 = (WindowInsets) field.get((Object) null);
                    if (windowInsets2 != null) {
                        windowInsets = new WindowInsets(windowInsets2);
                        this.f3376b = windowInsets;
                    }
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e2);
                }
            }
            if (!f3375f) {
                try {
                    f3374e = WindowInsets.class.getConstructor(new Class[]{Rect.class});
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e3);
                }
                f3375f = true;
            }
            Constructor<WindowInsets> constructor = f3374e;
            if (constructor != null) {
                try {
                    windowInsets = constructor.newInstance(new Object[]{new Rect()});
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e4);
                }
            }
            this.f3376b = windowInsets;
        }

        public C0944a(C0943j7 j7Var) {
            this.f3376b = j7Var.mo4134i();
        }

        /* renamed from: a */
        public C0943j7 mo4135a() {
            return C0943j7.m2927j(this.f3376b);
        }

        /* renamed from: c */
        public void mo4136c(C0672f5 f5Var) {
            WindowInsets windowInsets = this.f3376b;
            if (windowInsets != null) {
                this.f3376b = windowInsets.replaceSystemWindowInsets(f5Var.f2685a, f5Var.f2686b, f5Var.f2687c, f5Var.f2688d);
            }
        }
    }

    /* renamed from: j7$b */
    public static class C0945b extends C0946c {

        /* renamed from: b */
        public final WindowInsets.Builder f3377b;

        public C0945b() {
            this.f3377b = new WindowInsets.Builder();
        }

        public C0945b(C0943j7 j7Var) {
            WindowInsets.Builder builder;
            WindowInsets i = j7Var.mo4134i();
            if (i == null) {
                builder = new WindowInsets.Builder();
            }
            this.f3377b = builder;
        }

        /* renamed from: a */
        public C0943j7 mo4135a() {
            return C0943j7.m2927j(this.f3377b.build());
        }

        /* renamed from: b */
        public void mo4137b(C0672f5 f5Var) {
            this.f3377b.setStableInsets(Insets.of(f5Var.f2685a, f5Var.f2686b, f5Var.f2687c, f5Var.f2688d));
        }

        /* renamed from: c */
        public void mo4136c(C0672f5 f5Var) {
            this.f3377b.setSystemWindowInsets(Insets.of(f5Var.f2685a, f5Var.f2686b, f5Var.f2687c, f5Var.f2688d));
        }
    }

    /* renamed from: j7$c */
    public static class C0946c {

        /* renamed from: a */
        public final C0943j7 f3378a;

        public C0946c() {
            this.f3378a = new C0943j7((C0943j7) null);
        }

        public C0946c(C0943j7 j7Var) {
            this.f3378a = j7Var;
        }

        /* renamed from: a */
        public C0943j7 mo4135a() {
            return this.f3378a;
        }

        /* renamed from: b */
        public void mo4137b(C0672f5 f5Var) {
        }

        /* renamed from: c */
        public void mo4136c(C0672f5 f5Var) {
        }
    }

    /* renamed from: j7$d */
    public static class C0947d extends C0951h {

        /* renamed from: b */
        public final WindowInsets f3379b;

        /* renamed from: c */
        public C0672f5 f3380c = null;

        public C0947d(C0943j7 j7Var, WindowInsets windowInsets) {
            super(j7Var);
            this.f3379b = windowInsets;
        }

        /* renamed from: f */
        public final C0672f5 mo4138f() {
            if (this.f3380c == null) {
                this.f3380c = C0672f5.m2163a(this.f3379b.getSystemWindowInsetLeft(), this.f3379b.getSystemWindowInsetTop(), this.f3379b.getSystemWindowInsetRight(), this.f3379b.getSystemWindowInsetBottom());
            }
            return this.f3380c;
        }

        /* renamed from: g */
        public C0943j7 mo4139g(int i, int i2, int i3, int i4) {
            C0943j7 j = C0943j7.m2927j(this.f3379b);
            int i5 = Build.VERSION.SDK_INT;
            C0946c bVar = i5 >= 29 ? new C0945b(j) : i5 >= 20 ? new C0944a(j) : new C0946c(j);
            bVar.mo4136c(C0943j7.m2926f(mo4138f(), i, i2, i3, i4));
            bVar.mo4137b(C0943j7.m2926f(mo4143e(), i, i2, i3, i4));
            return bVar.mo4135a();
        }

        /* renamed from: i */
        public boolean mo4140i() {
            return this.f3379b.isRound();
        }
    }

    /* renamed from: j7$e */
    public static class C0948e extends C0947d {

        /* renamed from: d */
        public C0672f5 f3381d = null;

        public C0948e(C0943j7 j7Var, WindowInsets windowInsets) {
            super(j7Var, windowInsets);
        }

        /* renamed from: b */
        public C0943j7 mo4141b() {
            return C0943j7.m2927j(this.f3379b.consumeStableInsets());
        }

        /* renamed from: c */
        public C0943j7 mo4142c() {
            return C0943j7.m2927j(this.f3379b.consumeSystemWindowInsets());
        }

        /* renamed from: e */
        public final C0672f5 mo4143e() {
            if (this.f3381d == null) {
                this.f3381d = C0672f5.m2163a(this.f3379b.getStableInsetLeft(), this.f3379b.getStableInsetTop(), this.f3379b.getStableInsetRight(), this.f3379b.getStableInsetBottom());
            }
            return this.f3381d;
        }

        /* renamed from: h */
        public boolean mo4144h() {
            return this.f3379b.isConsumed();
        }
    }

    /* renamed from: j7$f */
    public static class C0949f extends C0948e {
        public C0949f(C0943j7 j7Var, WindowInsets windowInsets) {
            super(j7Var, windowInsets);
        }

        /* renamed from: a */
        public C0943j7 mo4145a() {
            return C0943j7.m2927j(this.f3379b.consumeDisplayCutout());
        }

        /* renamed from: d */
        public C1306o6 mo4146d() {
            DisplayCutout displayCutout = this.f3379b.getDisplayCutout();
            if (displayCutout == null) {
                return null;
            }
            return new C1306o6(displayCutout);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0949f)) {
                return false;
            }
            return Objects.equals(this.f3379b, ((C0949f) obj).f3379b);
        }

        public int hashCode() {
            return this.f3379b.hashCode();
        }
    }

    /* renamed from: j7$g */
    public static class C0950g extends C0949f {
        public C0950g(C0943j7 j7Var, WindowInsets windowInsets) {
            super(j7Var, windowInsets);
        }

        /* renamed from: g */
        public C0943j7 mo4139g(int i, int i2, int i3, int i4) {
            return C0943j7.m2927j(this.f3379b.inset(i, i2, i3, i4));
        }
    }

    /* renamed from: j7$h */
    public static class C0951h {

        /* renamed from: a */
        public final C0943j7 f3382a;

        public C0951h(C0943j7 j7Var) {
            this.f3382a = j7Var;
        }

        /* renamed from: a */
        public C0943j7 mo4145a() {
            return this.f3382a;
        }

        /* renamed from: b */
        public C0943j7 mo4141b() {
            return this.f3382a;
        }

        /* renamed from: c */
        public C0943j7 mo4142c() {
            return this.f3382a;
        }

        /* renamed from: d */
        public C1306o6 mo4146d() {
            return null;
        }

        /* renamed from: e */
        public C0672f5 mo4143e() {
            return C0672f5.f2684e;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0951h)) {
                return false;
            }
            C0951h hVar = (C0951h) obj;
            if (mo4140i() != hVar.mo4140i() || mo4144h() != hVar.mo4144h() || !Objects.equals(mo4138f(), hVar.mo4138f()) || !Objects.equals(mo4143e(), hVar.mo4143e()) || !Objects.equals(mo4146d(), hVar.mo4146d())) {
                return false;
            }
            return true;
        }

        /* renamed from: f */
        public C0672f5 mo4138f() {
            return C0672f5.f2684e;
        }

        /* renamed from: g */
        public C0943j7 mo4139g(int i, int i2, int i3, int i4) {
            return C0943j7.f3370b;
        }

        /* renamed from: h */
        public boolean mo4144h() {
            return false;
        }

        public int hashCode() {
            return Objects.hash(new Object[]{Boolean.valueOf(mo4140i()), Boolean.valueOf(mo4144h()), mo4138f(), mo4143e(), mo4146d()});
        }

        /* renamed from: i */
        public boolean mo4140i() {
            return false;
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
        f3370b = (i >= 29 ? new C0945b() : i >= 20 ? new C0944a() : new C0946c()).mo4135a().f3371a.mo4145a().f3371a.mo4141b().f3371a.mo4142c();
    }

    public C0943j7(WindowInsets windowInsets) {
        C0951h hVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            hVar = new C0950g(this, windowInsets);
        } else if (i >= 28) {
            hVar = new C0949f(this, windowInsets);
        } else if (i >= 21) {
            hVar = new C0948e(this, windowInsets);
        } else if (i >= 20) {
            hVar = new C0947d(this, windowInsets);
        } else {
            this.f3371a = new C0951h(this);
            return;
        }
        this.f3371a = hVar;
    }

    public C0943j7(C0943j7 j7Var) {
        this.f3371a = new C0951h(this);
    }

    /* renamed from: f */
    public static C0672f5 m2926f(C0672f5 f5Var, int i, int i2, int i3, int i4) {
        int max = Math.max(0, f5Var.f2685a - i);
        int max2 = Math.max(0, f5Var.f2686b - i2);
        int max3 = Math.max(0, f5Var.f2687c - i3);
        int max4 = Math.max(0, f5Var.f2688d - i4);
        return (max == i && max2 == i2 && max3 == i3 && max4 == i4) ? f5Var : C0672f5.m2163a(max, max2, max3, max4);
    }

    /* renamed from: j */
    public static C0943j7 m2927j(WindowInsets windowInsets) {
        Objects.requireNonNull(windowInsets);
        return new C0943j7(windowInsets);
    }

    /* renamed from: a */
    public int mo4125a() {
        return mo4129e().f2688d;
    }

    /* renamed from: b */
    public int mo4126b() {
        return mo4129e().f2685a;
    }

    /* renamed from: c */
    public int mo4127c() {
        return mo4129e().f2687c;
    }

    /* renamed from: d */
    public int mo4128d() {
        return mo4129e().f2686b;
    }

    /* renamed from: e */
    public C0672f5 mo4129e() {
        return this.f3371a.mo4138f();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0943j7)) {
            return false;
        }
        return Objects.equals(this.f3371a, ((C0943j7) obj).f3371a);
    }

    /* renamed from: g */
    public boolean mo4131g() {
        return this.f3371a.mo4144h();
    }

    @Deprecated
    /* renamed from: h */
    public C0943j7 mo4132h(int i, int i2, int i3, int i4) {
        int i5 = Build.VERSION.SDK_INT;
        C0946c bVar = i5 >= 29 ? new C0945b(this) : i5 >= 20 ? new C0944a(this) : new C0946c(this);
        bVar.mo4136c(C0672f5.m2163a(i, i2, i3, i4));
        return bVar.mo4135a();
    }

    public int hashCode() {
        C0951h hVar = this.f3371a;
        if (hVar == null) {
            return 0;
        }
        return hVar.hashCode();
    }

    /* renamed from: i */
    public WindowInsets mo4134i() {
        C0951h hVar = this.f3371a;
        if (hVar instanceof C0947d) {
            return ((C0947d) hVar).f3379b;
        }
        return null;
    }
}
