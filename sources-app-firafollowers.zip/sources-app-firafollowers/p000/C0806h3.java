package p000;

import android.content.res.Resources;

/* renamed from: h3 */
public class C0806h3 extends Resources {

    /* renamed from: a */
    public static final /* synthetic */ int f3017a = 0;
}
