package p000;

import android.view.View;
import android.view.Window;

/* renamed from: d3 */
public class C0525d3 implements View.OnClickListener {

    /* renamed from: d */
    public final C1286o0 f2138d;

    /* renamed from: e */
    public final /* synthetic */ C0600e3 f2139e;

    public C0525d3(C0600e3 e3Var) {
        this.f2139e = e3Var;
        this.f2138d = new C1286o0(e3Var.f2446a.getContext(), 0, 16908332, 0, e3Var.f2454i);
    }

    public void onClick(View view) {
        C0600e3 e3Var = this.f2139e;
        Window.Callback callback = e3Var.f2457l;
        if (callback != null && e3Var.f2458m) {
            callback.onMenuItemSelected(0, this.f2138d);
        }
    }
}
