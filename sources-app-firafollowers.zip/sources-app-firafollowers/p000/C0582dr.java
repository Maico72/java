package p000;

/* renamed from: dr */
public final class C0582dr {

    /* renamed from: a */
    public static final String f2348a = String.valueOf(Long.MIN_VALUE).substring(1);

    /* renamed from: b */
    public static final String f2349b = String.valueOf(Long.MAX_VALUE);
}
