package p000;

import android.annotation.SuppressLint;
import android.os.Trace;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* renamed from: ab */
public final class C0021ab implements Runnable {

    /* renamed from: h */
    public static final ThreadLocal<C0021ab> f60h = new ThreadLocal<>();

    /* renamed from: i */
    public static Comparator<C0024c> f61i = new C0022a();

    /* renamed from: d */
    public ArrayList<RecyclerView> f62d = new ArrayList<>();

    /* renamed from: e */
    public long f63e;

    /* renamed from: f */
    public long f64f;

    /* renamed from: g */
    public ArrayList<C0024c> f65g = new ArrayList<>();

    /* renamed from: ab$a */
    public class C0022a implements Comparator<C0024c> {
        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0017, code lost:
            if (r0 == null) goto L_0x0023;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0020, code lost:
            if (r0 != false) goto L_0x0022;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int compare(java.lang.Object r7, java.lang.Object r8) {
            /*
                r6 = this;
                ab$c r7 = (p000.C0021ab.C0024c) r7
                ab$c r8 = (p000.C0021ab.C0024c) r8
                androidx.recyclerview.widget.RecyclerView r0 = r7.f73d
                r1 = 1
                r2 = 0
                if (r0 != 0) goto L_0x000c
                r3 = 1
                goto L_0x000d
            L_0x000c:
                r3 = 0
            L_0x000d:
                androidx.recyclerview.widget.RecyclerView r4 = r8.f73d
                if (r4 != 0) goto L_0x0013
                r4 = 1
                goto L_0x0014
            L_0x0013:
                r4 = 0
            L_0x0014:
                r5 = -1
                if (r3 == r4) goto L_0x001a
                if (r0 != 0) goto L_0x0022
                goto L_0x0023
            L_0x001a:
                boolean r0 = r7.f70a
                boolean r3 = r8.f70a
                if (r0 == r3) goto L_0x0025
                if (r0 == 0) goto L_0x0023
            L_0x0022:
                r1 = -1
            L_0x0023:
                r2 = r1
                goto L_0x0036
            L_0x0025:
                int r0 = r8.f71b
                int r1 = r7.f71b
                int r0 = r0 - r1
                if (r0 == 0) goto L_0x002e
                r2 = r0
                goto L_0x0036
            L_0x002e:
                int r7 = r7.f72c
                int r8 = r8.f72c
                int r7 = r7 - r8
                if (r7 == 0) goto L_0x0036
                r2 = r7
            L_0x0036:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0021ab.C0022a.compare(java.lang.Object, java.lang.Object):int");
        }
    }

    @SuppressLint({"VisibleForTests"})
    /* renamed from: ab$b */
    public static class C0023b implements RecyclerView.C0162m.C0165c {

        /* renamed from: a */
        public int f66a;

        /* renamed from: b */
        public int f67b;

        /* renamed from: c */
        public int[] f68c;

        /* renamed from: d */
        public int f69d;

        /* renamed from: a */
        public void mo73a(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            } else if (i2 >= 0) {
                int i3 = this.f69d * 2;
                int[] iArr = this.f68c;
                if (iArr == null) {
                    int[] iArr2 = new int[4];
                    this.f68c = iArr2;
                    Arrays.fill(iArr2, -1);
                } else if (i3 >= iArr.length) {
                    int[] iArr3 = new int[(i3 * 2)];
                    this.f68c = iArr3;
                    System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                }
                int[] iArr4 = this.f68c;
                iArr4[i3] = i;
                iArr4[i3 + 1] = i2;
                this.f69d++;
            } else {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
        }

        /* renamed from: b */
        public void mo74b(RecyclerView recyclerView, boolean z) {
            this.f69d = 0;
            int[] iArr = this.f68c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            RecyclerView.C0162m mVar = recyclerView.f826p;
            if (recyclerView.f824o != null && mVar != null && mVar.f874j) {
                if (z) {
                    if (!recyclerView.f808g.mo5030g()) {
                        mVar.mo907j(recyclerView.f824o.mo1085a(), this);
                    }
                } else if (!recyclerView.mo950M()) {
                    mVar.mo905i(this.f66a, this.f67b, recyclerView.f813i0, this);
                }
                int i = this.f69d;
                if (i > mVar.f875k) {
                    mVar.f875k = i;
                    mVar.f876l = z;
                    recyclerView.f804e.mo1195n();
                }
            }
        }

        /* renamed from: c */
        public boolean mo75c(int i) {
            if (this.f68c != null) {
                int i2 = this.f69d * 2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.f68c[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /* renamed from: ab$c */
    public static class C0024c {

        /* renamed from: a */
        public boolean f70a;

        /* renamed from: b */
        public int f71b;

        /* renamed from: c */
        public int f72c;

        /* renamed from: d */
        public RecyclerView f73d;

        /* renamed from: e */
        public int f74e;
    }

    /* renamed from: a */
    public void mo68a(RecyclerView recyclerView, int i, int i2) {
        if (recyclerView.isAttachedToWindow() && this.f63e == 0) {
            this.f63e = recyclerView.getNanoTime();
            recyclerView.post(this);
        }
        C0023b bVar = recyclerView.f811h0;
        bVar.f66a = i;
        bVar.f67b = i2;
    }

    /* renamed from: b */
    public void mo69b(long j) {
        C0024c cVar;
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        C0024c cVar2;
        int size = this.f62d.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            RecyclerView recyclerView3 = this.f62d.get(i2);
            if (recyclerView3.getWindowVisibility() == 0) {
                recyclerView3.f811h0.mo74b(recyclerView3, false);
                i += recyclerView3.f811h0.f69d;
            }
        }
        this.f65g.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView recyclerView4 = this.f62d.get(i4);
            if (recyclerView4.getWindowVisibility() == 0) {
                C0023b bVar = recyclerView4.f811h0;
                int abs = Math.abs(bVar.f67b) + Math.abs(bVar.f66a);
                for (int i5 = 0; i5 < bVar.f69d * 2; i5 += 2) {
                    if (i3 >= this.f65g.size()) {
                        cVar2 = new C0024c();
                        this.f65g.add(cVar2);
                    } else {
                        cVar2 = this.f65g.get(i3);
                    }
                    int[] iArr = bVar.f68c;
                    int i6 = iArr[i5 + 1];
                    cVar2.f70a = i6 <= abs;
                    cVar2.f71b = abs;
                    cVar2.f72c = i6;
                    cVar2.f73d = recyclerView4;
                    cVar2.f74e = iArr[i5];
                    i3++;
                }
            }
        }
        Collections.sort(this.f65g, f61i);
        for (int i7 = 0; i7 < this.f65g.size() && (recyclerView = cVar.f73d) != null; i7++) {
            RecyclerView.C0181z c = mo70c(recyclerView, (cVar = this.f65g.get(i7)).f74e, cVar.f70a ? Long.MAX_VALUE : j);
            if (!(c == null || c.f929b == null || !c.mo1214i() || c.mo1215j() || (recyclerView2 = (RecyclerView) c.f929b.get()) == null)) {
                if (recyclerView2.f781F && recyclerView2.f810h.mo5209h() != 0) {
                    recyclerView2.mo967c0();
                }
                C0023b bVar2 = recyclerView2.f811h0;
                bVar2.mo74b(recyclerView2, true);
                if (bVar2.f69d != 0) {
                    try {
                        int i8 = C2050x5.f6724a;
                        Trace.beginSection("RV Nested Prefetch");
                        RecyclerView.C0178w wVar = recyclerView2.f813i0;
                        RecyclerView.C0150e eVar = recyclerView2.f824o;
                        wVar.f909c = 1;
                        wVar.f910d = eVar.mo1085a();
                        wVar.f912f = false;
                        wVar.f913g = false;
                        wVar.f914h = false;
                        for (int i9 = 0; i9 < bVar2.f69d * 2; i9 += 2) {
                            mo70c(recyclerView2, bVar2.f68c[i9], j);
                        }
                        Trace.endSection();
                    } catch (Throwable th) {
                        int i10 = C2050x5.f6724a;
                        Trace.endSection();
                        throw th;
                    }
                }
            }
            cVar.f70a = false;
            cVar.f71b = 0;
            cVar.f72c = 0;
            cVar.f73d = null;
            cVar.f74e = 0;
        }
    }

    /* renamed from: c */
    public final RecyclerView.C0181z mo70c(RecyclerView recyclerView, int i, long j) {
        boolean z;
        int h = recyclerView.f810h.mo5209h();
        int i2 = 0;
        while (true) {
            if (i2 >= h) {
                z = false;
                break;
            }
            RecyclerView.C0181z K = RecyclerView.m512K(recyclerView.f810h.mo5208g(i2));
            if (K.f930c == i && !K.mo1215j()) {
                z = true;
                break;
            }
            i2++;
        }
        if (z) {
            return null;
        }
        RecyclerView.C0173s sVar = recyclerView.f804e;
        try {
            recyclerView.mo957T();
            RecyclerView.C0181z l = sVar.mo1193l(i, false, j);
            if (l != null) {
                if (!l.mo1214i() || l.mo1215j()) {
                    sVar.mo1182a(l, false);
                } else {
                    sVar.mo1190i(l.f928a);
                }
            }
            return l;
        } finally {
            recyclerView.mo958U(false);
        }
    }

    public void run() {
        try {
            int i = C2050x5.f6724a;
            Trace.beginSection("RV Prefetch");
            if (this.f62d.isEmpty()) {
                this.f63e = 0;
                Trace.endSection();
                return;
            }
            int size = this.f62d.size();
            long j = 0;
            for (int i2 = 0; i2 < size; i2++) {
                RecyclerView recyclerView = this.f62d.get(i2);
                if (recyclerView.getWindowVisibility() == 0) {
                    j = Math.max(recyclerView.getDrawingTime(), j);
                }
            }
            if (j == 0) {
                this.f63e = 0;
                Trace.endSection();
                return;
            }
            mo69b(TimeUnit.MILLISECONDS.toNanos(j) + this.f64f);
            this.f63e = 0;
            Trace.endSection();
        } catch (Throwable th) {
            this.f63e = 0;
            int i3 = C2050x5.f6724a;
            Trace.endSection();
            throw th;
        }
    }
}
