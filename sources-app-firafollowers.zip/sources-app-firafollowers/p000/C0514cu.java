package p000;

/* renamed from: cu */
public interface C0514cu {
}
