package p000;

import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Queue;

/* renamed from: ij */
public class C0895ij<A, B> {

    /* renamed from: a */
    public final C1272no<C0897b<A>, B> f3267a;

    /* renamed from: ij$a */
    public class C0896a extends C1272no<C0897b<A>, B> {
        public C0896a(C0895ij ijVar, long j) {
            super(j);
        }

        /* renamed from: c */
        public void mo4046c(Object obj, Object obj2) {
            C0897b bVar = (C0897b) obj;
            Objects.requireNonNull(bVar);
            Queue<C0897b<?>> queue = C0897b.f3268d;
            synchronized (queue) {
                queue.offer(bVar);
            }
        }
    }

    /* renamed from: ij$b */
    public static final class C0897b<A> {

        /* renamed from: d */
        public static final Queue<C0897b<?>> f3268d = new ArrayDeque(0);

        /* renamed from: a */
        public int f3269a;

        /* renamed from: b */
        public int f3270b;

        /* renamed from: c */
        public A f3271c;

        static {
            char[] cArr = C1624qo.f5335a;
        }

        /* renamed from: a */
        public static <A> C0897b<A> m2815a(A a, int i, int i2) {
            C0897b<A> poll;
            Queue<C0897b<?>> queue = f3268d;
            synchronized (queue) {
                poll = queue.poll();
            }
            if (poll == null) {
                poll = new C0897b<>();
            }
            poll.f3271c = a;
            poll.f3270b = i;
            poll.f3269a = i2;
            return poll;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0897b)) {
                return false;
            }
            C0897b bVar = (C0897b) obj;
            return this.f3270b == bVar.f3270b && this.f3269a == bVar.f3269a && this.f3271c.equals(bVar.f3271c);
        }

        public int hashCode() {
            return this.f3271c.hashCode() + (((this.f3269a * 31) + this.f3270b) * 31);
        }
    }

    public C0895ij(long j) {
        this.f3267a = new C0896a(this, j);
    }
}
