package p000;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.SparseArray;
import java.util.Objects;
import p000.C0594e0;

/* renamed from: c0 */
public class C0321c0 extends Drawable implements Drawable.Callback {

    /* renamed from: p */
    public static final /* synthetic */ int f1370p = 0;

    /* renamed from: d */
    public C0324c f1371d;

    /* renamed from: e */
    public Rect f1372e;

    /* renamed from: f */
    public Drawable f1373f;

    /* renamed from: g */
    public Drawable f1374g;

    /* renamed from: h */
    public int f1375h = 255;

    /* renamed from: i */
    public boolean f1376i;

    /* renamed from: j */
    public int f1377j = -1;

    /* renamed from: k */
    public boolean f1378k;

    /* renamed from: l */
    public Runnable f1379l;

    /* renamed from: m */
    public long f1380m;

    /* renamed from: n */
    public long f1381n;

    /* renamed from: o */
    public C0323b f1382o;

    /* renamed from: c0$a */
    public class C0322a implements Runnable {
        public C0322a() {
        }

        public void run() {
            C0321c0.this.mo1734a(true);
            C0321c0.this.invalidateSelf();
        }
    }

    /* renamed from: c0$b */
    public static class C0323b implements Drawable.Callback {

        /* renamed from: d */
        public Drawable.Callback f1384d;

        public void invalidateDrawable(Drawable drawable) {
        }

        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
            Drawable.Callback callback = this.f1384d;
            if (callback != null) {
                callback.scheduleDrawable(drawable, runnable, j);
            }
        }

        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            Drawable.Callback callback = this.f1384d;
            if (callback != null) {
                callback.unscheduleDrawable(drawable, runnable);
            }
        }
    }

    /* renamed from: c0$c */
    public static abstract class C0324c extends Drawable.ConstantState {

        /* renamed from: A */
        public int f1385A;

        /* renamed from: B */
        public int f1386B;

        /* renamed from: C */
        public boolean f1387C;

        /* renamed from: D */
        public ColorFilter f1388D;

        /* renamed from: E */
        public boolean f1389E;

        /* renamed from: F */
        public ColorStateList f1390F;

        /* renamed from: G */
        public PorterDuff.Mode f1391G;

        /* renamed from: H */
        public boolean f1392H;

        /* renamed from: I */
        public boolean f1393I;

        /* renamed from: a */
        public final C0321c0 f1394a;

        /* renamed from: b */
        public Resources f1395b;

        /* renamed from: c */
        public int f1396c = 160;

        /* renamed from: d */
        public int f1397d;

        /* renamed from: e */
        public int f1398e;

        /* renamed from: f */
        public SparseArray<Drawable.ConstantState> f1399f;

        /* renamed from: g */
        public Drawable[] f1400g;

        /* renamed from: h */
        public int f1401h;

        /* renamed from: i */
        public boolean f1402i;

        /* renamed from: j */
        public boolean f1403j;

        /* renamed from: k */
        public Rect f1404k;

        /* renamed from: l */
        public boolean f1405l;

        /* renamed from: m */
        public boolean f1406m;

        /* renamed from: n */
        public int f1407n;

        /* renamed from: o */
        public int f1408o;

        /* renamed from: p */
        public int f1409p;

        /* renamed from: q */
        public int f1410q;

        /* renamed from: r */
        public boolean f1411r;

        /* renamed from: s */
        public int f1412s;

        /* renamed from: t */
        public boolean f1413t;

        /* renamed from: u */
        public boolean f1414u;

        /* renamed from: v */
        public boolean f1415v;

        /* renamed from: w */
        public boolean f1416w;

        /* renamed from: x */
        public boolean f1417x;

        /* renamed from: y */
        public boolean f1418y;

        /* renamed from: z */
        public int f1419z;

        public C0324c(C0324c cVar, C0321c0 c0Var, Resources resources) {
            int i = 160;
            this.f1402i = false;
            this.f1405l = false;
            this.f1417x = true;
            this.f1385A = 0;
            this.f1386B = 0;
            this.f1394a = c0Var;
            this.f1395b = resources != null ? resources : cVar != null ? cVar.f1395b : null;
            int i2 = cVar != null ? cVar.f1396c : 0;
            int i3 = C0321c0.f1370p;
            i2 = resources != null ? resources.getDisplayMetrics().densityDpi : i2;
            i = i2 != 0 ? i2 : i;
            this.f1396c = i;
            if (cVar != null) {
                this.f1397d = cVar.f1397d;
                this.f1398e = cVar.f1398e;
                this.f1415v = true;
                this.f1416w = true;
                this.f1402i = cVar.f1402i;
                this.f1405l = cVar.f1405l;
                this.f1417x = cVar.f1417x;
                this.f1418y = cVar.f1418y;
                this.f1419z = cVar.f1419z;
                this.f1385A = cVar.f1385A;
                this.f1386B = cVar.f1386B;
                this.f1387C = cVar.f1387C;
                this.f1388D = cVar.f1388D;
                this.f1389E = cVar.f1389E;
                this.f1390F = cVar.f1390F;
                this.f1391G = cVar.f1391G;
                this.f1392H = cVar.f1392H;
                this.f1393I = cVar.f1393I;
                if (cVar.f1396c == i) {
                    if (cVar.f1403j) {
                        this.f1404k = new Rect(cVar.f1404k);
                        this.f1403j = true;
                    }
                    if (cVar.f1406m) {
                        this.f1407n = cVar.f1407n;
                        this.f1408o = cVar.f1408o;
                        this.f1409p = cVar.f1409p;
                        this.f1410q = cVar.f1410q;
                        this.f1406m = true;
                    }
                }
                if (cVar.f1411r) {
                    this.f1412s = cVar.f1412s;
                    this.f1411r = true;
                }
                if (cVar.f1413t) {
                    this.f1414u = cVar.f1414u;
                    this.f1413t = true;
                }
                Drawable[] drawableArr = cVar.f1400g;
                this.f1400g = new Drawable[drawableArr.length];
                this.f1401h = cVar.f1401h;
                SparseArray<Drawable.ConstantState> sparseArray = cVar.f1399f;
                this.f1399f = sparseArray != null ? sparseArray.clone() : new SparseArray<>(this.f1401h);
                int i4 = this.f1401h;
                for (int i5 = 0; i5 < i4; i5++) {
                    if (drawableArr[i5] != null) {
                        Drawable.ConstantState constantState = drawableArr[i5].getConstantState();
                        if (constantState != null) {
                            this.f1399f.put(i5, constantState);
                        } else {
                            this.f1400g[i5] = drawableArr[i5];
                        }
                    }
                }
                return;
            }
            this.f1400g = new Drawable[10];
            this.f1401h = 0;
        }

        /* renamed from: a */
        public final int mo1771a(Drawable drawable) {
            int i = this.f1401h;
            if (i >= this.f1400g.length) {
                int i2 = i + 10;
                C0594e0.C0595a aVar = (C0594e0.C0595a) this;
                Drawable[] drawableArr = new Drawable[i2];
                System.arraycopy(aVar.f1400g, 0, drawableArr, 0, i);
                aVar.f1400g = drawableArr;
                int[][] iArr = new int[i2][];
                System.arraycopy(aVar.f2399J, 0, iArr, 0, i);
                aVar.f2399J = iArr;
            }
            drawable.mutate();
            drawable.setVisible(false, true);
            drawable.setCallback(this.f1394a);
            this.f1400g[i] = drawable;
            this.f1401h++;
            this.f1398e = drawable.getChangingConfigurations() | this.f1398e;
            this.f1411r = false;
            this.f1413t = false;
            this.f1404k = null;
            this.f1403j = false;
            this.f1406m = false;
            this.f1415v = false;
            return i;
        }

        /* renamed from: b */
        public void mo1772b() {
            this.f1406m = true;
            mo1773c();
            int i = this.f1401h;
            Drawable[] drawableArr = this.f1400g;
            this.f1408o = -1;
            this.f1407n = -1;
            this.f1410q = 0;
            this.f1409p = 0;
            for (int i2 = 0; i2 < i; i2++) {
                Drawable drawable = drawableArr[i2];
                int intrinsicWidth = drawable.getIntrinsicWidth();
                if (intrinsicWidth > this.f1407n) {
                    this.f1407n = intrinsicWidth;
                }
                int intrinsicHeight = drawable.getIntrinsicHeight();
                if (intrinsicHeight > this.f1408o) {
                    this.f1408o = intrinsicHeight;
                }
                int minimumWidth = drawable.getMinimumWidth();
                if (minimumWidth > this.f1409p) {
                    this.f1409p = minimumWidth;
                }
                int minimumHeight = drawable.getMinimumHeight();
                if (minimumHeight > this.f1410q) {
                    this.f1410q = minimumHeight;
                }
            }
        }

        /* renamed from: c */
        public final void mo1773c() {
            SparseArray<Drawable.ConstantState> sparseArray = this.f1399f;
            if (sparseArray != null) {
                int size = sparseArray.size();
                for (int i = 0; i < size; i++) {
                    int keyAt = this.f1399f.keyAt(i);
                    Drawable[] drawableArr = this.f1400g;
                    Drawable newDrawable = this.f1399f.valueAt(i).newDrawable(this.f1395b);
                    if (Build.VERSION.SDK_INT >= 23) {
                        newDrawable.setLayoutDirection(this.f1419z);
                    }
                    Drawable mutate = newDrawable.mutate();
                    mutate.setCallback(this.f1394a);
                    drawableArr[keyAt] = mutate;
                }
                this.f1399f = null;
            }
        }

        public boolean canApplyTheme() {
            int i = this.f1401h;
            Drawable[] drawableArr = this.f1400g;
            for (int i2 = 0; i2 < i; i2++) {
                Drawable drawable = drawableArr[i2];
                if (drawable == null) {
                    Drawable.ConstantState constantState = this.f1399f.get(i2);
                    if (constantState != null && constantState.canApplyTheme()) {
                        return true;
                    }
                } else if (drawable.canApplyTheme()) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: d */
        public final Drawable mo1775d(int i) {
            int indexOfKey;
            Drawable drawable = this.f1400g[i];
            if (drawable != null) {
                return drawable;
            }
            SparseArray<Drawable.ConstantState> sparseArray = this.f1399f;
            if (sparseArray == null || (indexOfKey = sparseArray.indexOfKey(i)) < 0) {
                return null;
            }
            Drawable newDrawable = this.f1399f.valueAt(indexOfKey).newDrawable(this.f1395b);
            if (Build.VERSION.SDK_INT >= 23) {
                newDrawable.setLayoutDirection(this.f1419z);
            }
            Drawable mutate = newDrawable.mutate();
            mutate.setCallback(this.f1394a);
            this.f1400g[i] = mutate;
            this.f1399f.removeAt(indexOfKey);
            if (this.f1399f.size() == 0) {
                this.f1399f = null;
            }
            return mutate;
        }

        /* renamed from: e */
        public abstract void mo1501e();

        /* renamed from: f */
        public final void mo1776f(Resources resources) {
            if (resources != null) {
                this.f1395b = resources;
                int i = C0321c0.f1370p;
                int i2 = resources.getDisplayMetrics().densityDpi;
                if (i2 == 0) {
                    i2 = 160;
                }
                int i3 = this.f1396c;
                this.f1396c = i2;
                if (i3 != i2) {
                    this.f1406m = false;
                    this.f1403j = false;
                }
            }
        }

        public int getChangingConfigurations() {
            return this.f1397d | this.f1398e;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x003d  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0066 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1734a(boolean r14) {
        /*
            r13 = this;
            r0 = 1
            r13.f1376i = r0
            long r1 = android.os.SystemClock.uptimeMillis()
            android.graphics.drawable.Drawable r3 = r13.f1373f
            r4 = 255(0xff, double:1.26E-321)
            r6 = 0
            r7 = 0
            if (r3 == 0) goto L_0x0036
            long r9 = r13.f1380m
            int r11 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r11 == 0) goto L_0x0038
            int r11 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r11 > 0) goto L_0x0020
            int r9 = r13.f1375h
            r3.setAlpha(r9)
            goto L_0x0036
        L_0x0020:
            long r9 = r9 - r1
            long r9 = r9 * r4
            int r10 = (int) r9
            c0$c r9 = r13.f1371d
            int r9 = r9.f1385A
            int r10 = r10 / r9
            int r9 = 255 - r10
            int r10 = r13.f1375h
            int r9 = r9 * r10
            int r9 = r9 / 255
            r3.setAlpha(r9)
            r3 = 1
            goto L_0x0039
        L_0x0036:
            r13.f1380m = r7
        L_0x0038:
            r3 = 0
        L_0x0039:
            android.graphics.drawable.Drawable r9 = r13.f1374g
            if (r9 == 0) goto L_0x0061
            long r10 = r13.f1381n
            int r12 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1))
            if (r12 == 0) goto L_0x0063
            int r12 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r12 > 0) goto L_0x004e
            r9.setVisible(r6, r6)
            r0 = 0
            r13.f1374g = r0
            goto L_0x0061
        L_0x004e:
            long r10 = r10 - r1
            long r10 = r10 * r4
            int r3 = (int) r10
            c0$c r4 = r13.f1371d
            int r4 = r4.f1386B
            int r3 = r3 / r4
            int r4 = r13.f1375h
            int r3 = r3 * r4
            int r3 = r3 / 255
            r9.setAlpha(r3)
            goto L_0x0064
        L_0x0061:
            r13.f1381n = r7
        L_0x0063:
            r0 = r3
        L_0x0064:
            if (r14 == 0) goto L_0x0070
            if (r0 == 0) goto L_0x0070
            java.lang.Runnable r14 = r13.f1379l
            r3 = 16
            long r1 = r1 + r3
            r13.scheduleSelf(r14, r1)
        L_0x0070:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0321c0.mo1734a(boolean):void");
    }

    public void applyTheme(Resources.Theme theme) {
        C0324c cVar = this.f1371d;
        Objects.requireNonNull(cVar);
        if (theme != null) {
            cVar.mo1773c();
            int i = cVar.f1401h;
            Drawable[] drawableArr = cVar.f1400g;
            for (int i2 = 0; i2 < i; i2++) {
                if (drawableArr[i2] != null && drawableArr[i2].canApplyTheme()) {
                    drawableArr[i2].applyTheme(theme);
                    cVar.f1398e |= drawableArr[i2].getChangingConfigurations();
                }
            }
            cVar.mo1776f(theme.getResources());
        }
    }

    /* renamed from: b */
    public C0324c mo1491b() {
        throw null;
    }

    /* renamed from: c */
    public final void mo1736c(Drawable drawable) {
        if (this.f1382o == null) {
            this.f1382o = new C0323b();
        }
        C0323b bVar = this.f1382o;
        bVar.f1384d = drawable.getCallback();
        drawable.setCallback(bVar);
        try {
            if (this.f1371d.f1385A <= 0 && this.f1376i) {
                drawable.setAlpha(this.f1375h);
            }
            C0324c cVar = this.f1371d;
            if (cVar.f1389E) {
                drawable.setColorFilter(cVar.f1388D);
            } else {
                if (cVar.f1392H) {
                    C1401p4.m4367i0(drawable, cVar.f1390F);
                }
                C0324c cVar2 = this.f1371d;
                if (cVar2.f1393I) {
                    C1401p4.m4369j0(drawable, cVar2.f1391G);
                }
            }
            drawable.setVisible(isVisible(), true);
            drawable.setDither(this.f1371d.f1417x);
            drawable.setState(getState());
            drawable.setLevel(getLevel());
            drawable.setBounds(getBounds());
            int i = Build.VERSION.SDK_INT;
            if (i >= 23) {
                drawable.setLayoutDirection(getLayoutDirection());
            }
            drawable.setAutoMirrored(this.f1371d.f1387C);
            Rect rect = this.f1372e;
            if (i >= 21 && rect != null) {
                drawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom);
            }
        } finally {
            C0323b bVar2 = this.f1382o;
            Drawable.Callback callback = bVar2.f1384d;
            bVar2.f1384d = null;
            drawable.setCallback(callback);
        }
    }

    public boolean canApplyTheme() {
        return this.f1371d.canApplyTheme();
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x006b  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0073  */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1738d(int r10) {
        /*
            r9 = this;
            int r0 = r9.f1377j
            r1 = 0
            if (r10 != r0) goto L_0x0006
            return r1
        L_0x0006:
            long r2 = android.os.SystemClock.uptimeMillis()
            c0$c r0 = r9.f1371d
            int r0 = r0.f1386B
            r4 = 0
            r5 = 0
            if (r0 <= 0) goto L_0x002e
            android.graphics.drawable.Drawable r0 = r9.f1374g
            if (r0 == 0) goto L_0x001a
            r0.setVisible(r1, r1)
        L_0x001a:
            android.graphics.drawable.Drawable r0 = r9.f1373f
            if (r0 == 0) goto L_0x0029
            r9.f1374g = r0
            c0$c r0 = r9.f1371d
            int r0 = r0.f1386B
            long r0 = (long) r0
            long r0 = r0 + r2
            r9.f1381n = r0
            goto L_0x0035
        L_0x0029:
            r9.f1374g = r4
            r9.f1381n = r5
            goto L_0x0035
        L_0x002e:
            android.graphics.drawable.Drawable r0 = r9.f1373f
            if (r0 == 0) goto L_0x0035
            r0.setVisible(r1, r1)
        L_0x0035:
            if (r10 < 0) goto L_0x0055
            c0$c r0 = r9.f1371d
            int r1 = r0.f1401h
            if (r10 >= r1) goto L_0x0055
            android.graphics.drawable.Drawable r0 = r0.mo1775d(r10)
            r9.f1373f = r0
            r9.f1377j = r10
            if (r0 == 0) goto L_0x005a
            c0$c r10 = r9.f1371d
            int r10 = r10.f1385A
            if (r10 <= 0) goto L_0x0051
            long r7 = (long) r10
            long r2 = r2 + r7
            r9.f1380m = r2
        L_0x0051:
            r9.mo1736c(r0)
            goto L_0x005a
        L_0x0055:
            r9.f1373f = r4
            r10 = -1
            r9.f1377j = r10
        L_0x005a:
            long r0 = r9.f1380m
            r10 = 1
            int r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r2 != 0) goto L_0x0067
            long r0 = r9.f1381n
            int r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r2 == 0) goto L_0x0079
        L_0x0067:
            java.lang.Runnable r0 = r9.f1379l
            if (r0 != 0) goto L_0x0073
            c0$a r0 = new c0$a
            r0.<init>()
            r9.f1379l = r0
            goto L_0x0076
        L_0x0073:
            r9.unscheduleSelf(r0)
        L_0x0076:
            r9.mo1734a(r10)
        L_0x0079:
            r9.invalidateSelf()
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0321c0.mo1738d(int):boolean");
    }

    public void draw(Canvas canvas) {
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            drawable.draw(canvas);
        }
        Drawable drawable2 = this.f1374g;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
    }

    /* renamed from: e */
    public void mo1492e(C0324c cVar) {
        throw null;
    }

    public int getAlpha() {
        return this.f1375h;
    }

    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.f1371d.getChangingConfigurations();
    }

    public final Drawable.ConstantState getConstantState() {
        boolean z;
        C0324c cVar = this.f1371d;
        synchronized (cVar) {
            z = false;
            if (cVar.f1415v) {
                z = cVar.f1416w;
            } else {
                cVar.mo1773c();
                cVar.f1415v = true;
                int i = cVar.f1401h;
                Drawable[] drawableArr = cVar.f1400g;
                int i2 = 0;
                while (i2 < i) {
                    if (drawableArr[i2].getConstantState() == null) {
                        cVar.f1416w = false;
                    } else {
                        i2++;
                    }
                }
                cVar.f1416w = true;
                z = true;
            }
            break;
        }
        if (!z) {
            return null;
        }
        this.f1371d.f1397d = getChangingConfigurations();
        return this.f1371d;
    }

    public Drawable getCurrent() {
        return this.f1373f;
    }

    public void getHotspotBounds(Rect rect) {
        Rect rect2 = this.f1372e;
        if (rect2 != null) {
            rect.set(rect2);
        } else {
            super.getHotspotBounds(rect);
        }
    }

    public int getIntrinsicHeight() {
        C0324c cVar = this.f1371d;
        if (cVar.f1405l) {
            if (!cVar.f1406m) {
                cVar.mo1772b();
            }
            return cVar.f1408o;
        }
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        return -1;
    }

    public int getIntrinsicWidth() {
        C0324c cVar = this.f1371d;
        if (cVar.f1405l) {
            if (!cVar.f1406m) {
                cVar.mo1772b();
            }
            return cVar.f1407n;
        }
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        return -1;
    }

    public int getMinimumHeight() {
        C0324c cVar = this.f1371d;
        if (cVar.f1405l) {
            if (!cVar.f1406m) {
                cVar.mo1772b();
            }
            return cVar.f1410q;
        }
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            return drawable.getMinimumHeight();
        }
        return 0;
    }

    public int getMinimumWidth() {
        C0324c cVar = this.f1371d;
        if (cVar.f1405l) {
            if (!cVar.f1406m) {
                cVar.mo1772b();
            }
            return cVar.f1409p;
        }
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            return drawable.getMinimumWidth();
        }
        return 0;
    }

    public int getOpacity() {
        Drawable drawable = this.f1373f;
        int i = -2;
        if (drawable == null || !drawable.isVisible()) {
            return -2;
        }
        C0324c cVar = this.f1371d;
        if (cVar.f1411r) {
            return cVar.f1412s;
        }
        cVar.mo1773c();
        int i2 = cVar.f1401h;
        Drawable[] drawableArr = cVar.f1400g;
        if (i2 > 0) {
            i = drawableArr[0].getOpacity();
        }
        for (int i3 = 1; i3 < i2; i3++) {
            i = Drawable.resolveOpacity(i, drawableArr[i3].getOpacity());
        }
        cVar.f1412s = i;
        cVar.f1411r = true;
        return i;
    }

    public void getOutline(Outline outline) {
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            drawable.getOutline(outline);
        }
    }

    public boolean getPadding(Rect rect) {
        boolean z;
        C0324c cVar = this.f1371d;
        Rect rect2 = null;
        boolean z2 = true;
        if (!cVar.f1402i) {
            Rect rect3 = cVar.f1404k;
            if (rect3 != null || cVar.f1403j) {
                rect2 = rect3;
            } else {
                cVar.mo1773c();
                Rect rect4 = new Rect();
                int i = cVar.f1401h;
                Drawable[] drawableArr = cVar.f1400g;
                for (int i2 = 0; i2 < i; i2++) {
                    if (drawableArr[i2].getPadding(rect4)) {
                        if (rect2 == null) {
                            rect2 = new Rect(0, 0, 0, 0);
                        }
                        int i3 = rect4.left;
                        if (i3 > rect2.left) {
                            rect2.left = i3;
                        }
                        int i4 = rect4.top;
                        if (i4 > rect2.top) {
                            rect2.top = i4;
                        }
                        int i5 = rect4.right;
                        if (i5 > rect2.right) {
                            rect2.right = i5;
                        }
                        int i6 = rect4.bottom;
                        if (i6 > rect2.bottom) {
                            rect2.bottom = i6;
                        }
                    }
                }
                cVar.f1403j = true;
                cVar.f1404k = rect2;
            }
        }
        if (rect2 != null) {
            rect.set(rect2);
            z = (((rect2.left | rect2.top) | rect2.bottom) | rect2.right) != 0;
        } else {
            Drawable drawable = this.f1373f;
            z = drawable != null ? drawable.getPadding(rect) : super.getPadding(rect);
        }
        if (!this.f1371d.f1387C || C1401p4.m4392z(this) != 1) {
            z2 = false;
        }
        if (z2) {
            int i7 = rect.left;
            rect.left = rect.right;
            rect.right = i7;
        }
        return z;
    }

    public void invalidateDrawable(Drawable drawable) {
        C0324c cVar = this.f1371d;
        if (cVar != null) {
            cVar.f1411r = false;
            cVar.f1413t = false;
        }
        if (drawable == this.f1373f && getCallback() != null) {
            getCallback().invalidateDrawable(this);
        }
    }

    public boolean isAutoMirrored() {
        return this.f1371d.f1387C;
    }

    public void jumpToCurrentState() {
        boolean z;
        Drawable drawable = this.f1374g;
        boolean z2 = true;
        if (drawable != null) {
            drawable.jumpToCurrentState();
            this.f1374g = null;
            z = true;
        } else {
            z = false;
        }
        Drawable drawable2 = this.f1373f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
            if (this.f1376i) {
                this.f1373f.setAlpha(this.f1375h);
            }
        }
        if (this.f1381n != 0) {
            this.f1381n = 0;
            z = true;
        }
        if (this.f1380m != 0) {
            this.f1380m = 0;
        } else {
            z2 = z;
        }
        if (z2) {
            invalidateSelf();
        }
    }

    public Drawable mutate() {
        if (!this.f1378k && super.mutate() == this) {
            C0324c b = mo1491b();
            b.mo1501e();
            mo1492e(b);
            this.f1378k = true;
        }
        return this;
    }

    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f1374g;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
        Drawable drawable2 = this.f1373f;
        if (drawable2 != null) {
            drawable2.setBounds(rect);
        }
    }

    public boolean onLayoutDirectionChanged(int i) {
        C0324c cVar = this.f1371d;
        int i2 = this.f1377j;
        int i3 = cVar.f1401h;
        Drawable[] drawableArr = cVar.f1400g;
        boolean z = false;
        for (int i4 = 0; i4 < i3; i4++) {
            if (drawableArr[i4] != null) {
                boolean layoutDirection = Build.VERSION.SDK_INT >= 23 ? drawableArr[i4].setLayoutDirection(i) : false;
                if (i4 == i2) {
                    z = layoutDirection;
                }
            }
        }
        cVar.f1419z = i;
        return z;
    }

    public boolean onLevelChange(int i) {
        Drawable drawable = this.f1374g;
        if (drawable != null) {
            return drawable.setLevel(i);
        }
        Drawable drawable2 = this.f1373f;
        if (drawable2 != null) {
            return drawable2.setLevel(i);
        }
        return false;
    }

    public boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f1374g;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        Drawable drawable2 = this.f1373f;
        if (drawable2 != null) {
            return drawable2.setState(iArr);
        }
        return false;
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        if (drawable == this.f1373f && getCallback() != null) {
            getCallback().scheduleDrawable(this, runnable, j);
        }
    }

    public void setAlpha(int i) {
        if (!this.f1376i || this.f1375h != i) {
            this.f1376i = true;
            this.f1375h = i;
            Drawable drawable = this.f1373f;
            if (drawable == null) {
                return;
            }
            if (this.f1380m == 0) {
                drawable.setAlpha(i);
            } else {
                mo1734a(false);
            }
        }
    }

    public void setAutoMirrored(boolean z) {
        C0324c cVar = this.f1371d;
        if (cVar.f1387C != z) {
            cVar.f1387C = z;
            Drawable drawable = this.f1373f;
            if (drawable != null) {
                drawable.setAutoMirrored(z);
            }
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        C0324c cVar = this.f1371d;
        cVar.f1389E = true;
        if (cVar.f1388D != colorFilter) {
            cVar.f1388D = colorFilter;
            Drawable drawable = this.f1373f;
            if (drawable != null) {
                drawable.setColorFilter(colorFilter);
            }
        }
    }

    public void setDither(boolean z) {
        C0324c cVar = this.f1371d;
        if (cVar.f1417x != z) {
            cVar.f1417x = z;
            Drawable drawable = this.f1373f;
            if (drawable != null) {
                drawable.setDither(z);
            }
        }
    }

    public void setHotspot(float f, float f2) {
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            C1401p4.m4349Z(drawable, f, f2);
        }
    }

    public void setHotspotBounds(int i, int i2, int i3, int i4) {
        Rect rect = this.f1372e;
        if (rect == null) {
            this.f1372e = new Rect(i, i2, i3, i4);
        } else {
            rect.set(i, i2, i3, i4);
        }
        Drawable drawable = this.f1373f;
        if (drawable != null) {
            C1401p4.m4351a0(drawable, i, i2, i3, i4);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        C0324c cVar = this.f1371d;
        cVar.f1392H = true;
        if (cVar.f1390F != colorStateList) {
            cVar.f1390F = colorStateList;
            C1401p4.m4367i0(this.f1373f, colorStateList);
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        C0324c cVar = this.f1371d;
        cVar.f1393I = true;
        if (cVar.f1391G != mode) {
            cVar.f1391G = mode;
            C1401p4.m4369j0(this.f1373f, mode);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        Drawable drawable = this.f1374g;
        if (drawable != null) {
            drawable.setVisible(z, z2);
        }
        Drawable drawable2 = this.f1373f;
        if (drawable2 != null) {
            drawable2.setVisible(z, z2);
        }
        return visible;
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        if (drawable == this.f1373f && getCallback() != null) {
            getCallback().unscheduleDrawable(this, runnable);
        }
    }
}
