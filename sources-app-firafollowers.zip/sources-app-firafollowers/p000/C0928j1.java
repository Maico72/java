package p000;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatImageView;
import java.util.ArrayList;
import java.util.Objects;
import org.fasaroid.fira.R;
import p000.C0003a1;
import p000.C0243b1;
import p000.C1838u0;

/* renamed from: j1 */
public class C0928j1 extends C1390p0 {

    /* renamed from: A */
    public final C0935f f3329A = new C0935f();

    /* renamed from: l */
    public C0932d f3330l;

    /* renamed from: m */
    public Drawable f3331m;

    /* renamed from: n */
    public boolean f3332n;

    /* renamed from: o */
    public boolean f3333o;

    /* renamed from: p */
    public boolean f3334p;

    /* renamed from: q */
    public int f3335q;

    /* renamed from: r */
    public int f3336r;

    /* renamed from: s */
    public int f3337s;

    /* renamed from: t */
    public boolean f3338t;

    /* renamed from: u */
    public int f3339u;

    /* renamed from: v */
    public final SparseBooleanArray f3340v = new SparseBooleanArray();

    /* renamed from: w */
    public C0934e f3341w;

    /* renamed from: x */
    public C0929a f3342x;

    /* renamed from: y */
    public C0931c f3343y;

    /* renamed from: z */
    public C0930b f3344z;

    /* renamed from: j1$a */
    public class C0929a extends C2178z0 {
        public C0929a(Context context, C0662f1 f1Var, View view) {
            super(context, f1Var, view, false, R.attr.actionOverflowMenuStyle, 0);
            if (!f1Var.f2626A.mo6320g()) {
                View view2 = C0928j1.this.f3330l;
                this.f7028f = view2 == null ? (View) C0928j1.this.f4720k : view2;
            }
            mo6724d(C0928j1.this.f3329A);
        }

        /* renamed from: c */
        public void mo4115c() {
            C0928j1 j1Var = C0928j1.this;
            j1Var.f3342x = null;
            Objects.requireNonNull(j1Var);
            super.mo4115c();
        }
    }

    /* renamed from: j1$b */
    public class C0930b extends ActionMenuItemView.C0077b {
        public C0930b() {
        }
    }

    /* renamed from: j1$c */
    public class C0931c implements Runnable {

        /* renamed from: d */
        public C0934e f3347d;

        public C0931c(C0934e eVar) {
            this.f3347d = eVar;
        }

        public void run() {
            C1838u0.C1839a aVar;
            C1838u0 u0Var = C0928j1.this.f4715f;
            if (!(u0Var == null || (aVar = u0Var.f6080e) == null)) {
                aVar.mo331b(u0Var);
            }
            View view = (View) C0928j1.this.f4720k;
            if (!(view == null || view.getWindowToken() == null || !this.f3347d.mo6726f())) {
                C0928j1.this.f3341w = this.f3347d;
            }
            C0928j1.this.f3343y = null;
        }
    }

    /* renamed from: j1$d */
    public class C0932d extends AppCompatImageView implements ActionMenuView.C0084a {

        /* renamed from: j1$d$a */
        public class C0933a extends C1156m2 {
            public C0933a(View view, C0928j1 j1Var) {
                super(view);
            }

            /* renamed from: b */
            public C0522d1 mo18b() {
                C0934e eVar = C0928j1.this.f3341w;
                if (eVar == null) {
                    return null;
                }
                return eVar.mo6722a();
            }

            /* renamed from: c */
            public boolean mo19c() {
                C0928j1.this.mo4114n();
                return true;
            }

            /* renamed from: d */
            public boolean mo4119d() {
                C0928j1 j1Var = C0928j1.this;
                if (j1Var.f3343y != null) {
                    return false;
                }
                j1Var.mo4111k();
                return true;
            }
        }

        public C0932d(Context context) {
            super(context, (AttributeSet) null, R.attr.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            C0520d.m1654c(this, getContentDescription());
            setOnTouchListener(new C0933a(this, C0928j1.this));
        }

        /* renamed from: a */
        public boolean mo168a() {
            return false;
        }

        /* renamed from: b */
        public boolean mo169b() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0928j1.this.mo4114n();
            return true;
        }

        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                C1401p4.m4351a0(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: j1$e */
    public class C0934e extends C2178z0 {
        public C0934e(Context context, C1838u0 u0Var, View view, boolean z) {
            super(context, u0Var, view, z, R.attr.actionOverflowMenuStyle, 0);
            this.f7029g = 8388613;
            mo6724d(C0928j1.this.f3329A);
        }

        /* renamed from: c */
        public void mo4115c() {
            C1838u0 u0Var = C0928j1.this.f4715f;
            if (u0Var != null) {
                u0Var.mo6067c(true);
            }
            C0928j1.this.f3341w = null;
            super.mo4115c();
        }
    }

    /* renamed from: j1$f */
    public class C0935f implements C0003a1.C0004a {
        public C0935f() {
        }

        /* renamed from: a */
        public void mo14a(C1838u0 u0Var, boolean z) {
            if (u0Var instanceof C0662f1) {
                u0Var.mo3436k().mo6067c(false);
            }
            C0003a1.C0004a aVar = C0928j1.this.f4717h;
            if (aVar != null) {
                aVar.mo14a(u0Var, z);
            }
        }

        /* renamed from: b */
        public boolean mo15b(C1838u0 u0Var) {
            C0928j1 j1Var = C0928j1.this;
            if (u0Var == j1Var.f4715f) {
                return false;
            }
            int i = ((C0662f1) u0Var).f2626A.f6461a;
            C0003a1.C0004a aVar = j1Var.f4717h;
            if (aVar != null) {
                return aVar.mo15b(u0Var);
            }
            return false;
        }
    }

    public C0928j1(Context context) {
        super(context, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
    }

    /* renamed from: a */
    public void mo6a(C1838u0 u0Var, boolean z) {
        mo4109b();
        C0003a1.C0004a aVar = this.f4717h;
        if (aVar != null) {
            aVar.mo14a(u0Var, z);
        }
    }

    /* renamed from: b */
    public boolean mo4109b() {
        return mo4111k() | mo4112l();
    }

    /* renamed from: c */
    public boolean mo7c() {
        int i;
        ArrayList<C1967w0> arrayList;
        int i2;
        boolean z;
        C1838u0 u0Var = this.f4715f;
        if (u0Var != null) {
            arrayList = u0Var.mo6078l();
            i = arrayList.size();
        } else {
            arrayList = null;
            i = 0;
        }
        int i3 = this.f3337s;
        int i4 = this.f3336r;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.f4720k;
        int i5 = 0;
        boolean z2 = false;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            i2 = 2;
            z = true;
            if (i5 >= i) {
                break;
            }
            C1967w0 w0Var = arrayList.get(i5);
            int i8 = w0Var.f6485y;
            if ((i8 & 2) == 2) {
                i7++;
            } else {
                if ((i8 & 1) == 1) {
                    i6++;
                } else {
                    z2 = true;
                }
            }
            if (this.f3338t && w0Var.f6459C) {
                i3 = 0;
            }
            i5++;
        }
        if (this.f3333o && (z2 || i6 + i7 > i3)) {
            i3--;
        }
        int i9 = i3 - i7;
        SparseBooleanArray sparseBooleanArray = this.f3340v;
        sparseBooleanArray.clear();
        int i10 = 0;
        int i11 = 0;
        while (i10 < i) {
            C1967w0 w0Var2 = arrayList.get(i10);
            int i12 = w0Var2.f6485y;
            if ((i12 & 2) == i2) {
                View f = mo4110f(w0Var2, (View) null, viewGroup);
                f.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = f.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                int i13 = w0Var2.f6462b;
                if (i13 != 0) {
                    sparseBooleanArray.put(i13, z);
                }
                w0Var2.mo6341k(z);
            } else {
                if ((i12 & true) == z) {
                    int i14 = w0Var2.f6462b;
                    boolean z3 = sparseBooleanArray.get(i14);
                    boolean z4 = (i9 > 0 || z3) && i4 > 0;
                    if (z4) {
                        View f2 = mo4110f(w0Var2, (View) null, viewGroup);
                        f2.measure(makeMeasureSpec, makeMeasureSpec);
                        int measuredWidth2 = f2.getMeasuredWidth();
                        i4 -= measuredWidth2;
                        if (i11 == 0) {
                            i11 = measuredWidth2;
                        }
                        z4 &= i4 + i11 > 0;
                    }
                    if (z4 && i14 != 0) {
                        sparseBooleanArray.put(i14, true);
                    } else if (z3) {
                        sparseBooleanArray.put(i14, false);
                        for (int i15 = 0; i15 < i10; i15++) {
                            C1967w0 w0Var3 = arrayList.get(i15);
                            if (w0Var3.f6462b == i14) {
                                if (w0Var3.mo6320g()) {
                                    i9++;
                                }
                                w0Var3.mo6341k(false);
                            }
                        }
                    }
                    if (z4) {
                        i9--;
                    }
                    w0Var2.mo6341k(z4);
                } else {
                    w0Var2.mo6341k(false);
                    i10++;
                    i2 = 2;
                    z = true;
                }
            }
            i10++;
            i2 = 2;
            z = true;
        }
        return true;
    }

    /* renamed from: d */
    public void mo8d(Context context, C1838u0 u0Var) {
        this.f4714e = context;
        LayoutInflater.from(context);
        this.f4715f = u0Var;
        Resources resources = context.getResources();
        if (!this.f3334p) {
            this.f3333o = true;
        }
        int i = 2;
        this.f3335q = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i2 > 600 || ((i2 > 960 && i3 > 720) || (i2 > 720 && i3 > 960))) {
            i = 5;
        } else if (i2 >= 500 || ((i2 > 640 && i3 > 480) || (i2 > 480 && i3 > 640))) {
            i = 4;
        } else if (i2 >= 360) {
            i = 3;
        }
        this.f3337s = i;
        int i4 = this.f3335q;
        if (this.f3333o) {
            if (this.f3330l == null) {
                C0932d dVar = new C0932d(this.f4713d);
                this.f3330l = dVar;
                if (this.f3332n) {
                    dVar.setImageDrawable(this.f3331m);
                    this.f3331m = null;
                    this.f3332n = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f3330l.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i4 -= this.f3330l.getMeasuredWidth();
        } else {
            this.f3330l = null;
        }
        this.f3336r = i4;
        this.f3339u = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    /* renamed from: f */
    public View mo4110f(C1967w0 w0Var, View view, ViewGroup viewGroup) {
        C0243b1.C0244a aVar;
        View actionView = w0Var.getActionView();
        int i = 0;
        if (actionView == null || w0Var.mo6319f()) {
            if (view instanceof C0243b1.C0244a) {
                aVar = (C0243b1.C0244a) view;
            } else {
                aVar = (C0243b1.C0244a) this.f4716g.inflate(this.f4719j, viewGroup, false);
            }
            aVar.mo171d(w0Var, 0);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f4720k);
            if (this.f3344z == null) {
                this.f3344z = new C0930b();
            }
            actionMenuItemView.setPopupCallback(this.f3344z);
            actionView = (View) aVar;
        }
        if (w0Var.f6459C) {
            i = 8;
        }
        actionView.setVisibility(i);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.mo316j(layoutParams));
        }
        return actionView;
    }

    /* renamed from: i */
    public boolean mo12i(C0662f1 f1Var) {
        boolean z = false;
        if (!f1Var.hasVisibleItems()) {
            return false;
        }
        C0662f1 f1Var2 = f1Var;
        while (true) {
            C1838u0 u0Var = f1Var2.f2627z;
            if (u0Var == this.f4715f) {
                break;
            }
            f1Var2 = u0Var;
        }
        C1967w0 w0Var = f1Var2.f2626A;
        ViewGroup viewGroup = (ViewGroup) this.f4720k;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof C0243b1.C0244a) && ((C0243b1.C0244a) childAt).getItemData() == w0Var) {
                    view = childAt;
                    break;
                }
                i++;
            }
        }
        if (view == null) {
            return false;
        }
        int i2 = f1Var.f2626A.f6461a;
        int size = f1Var.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                break;
            }
            MenuItem item = f1Var.getItem(i3);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i3++;
        }
        C0929a aVar = new C0929a(this.f4714e, f1Var, view);
        this.f3342x = aVar;
        aVar.f7030h = z;
        C2107y0 y0Var = aVar.f7032j;
        if (y0Var != null) {
            y0Var.mo3170p(z);
        }
        if (this.f3342x.mo6726f()) {
            C0003a1.C0004a aVar2 = this.f4717h;
            if (aVar2 != null) {
                aVar2.mo15b(f1Var);
            }
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    /* renamed from: j */
    public void mo13j(boolean z) {
        C0243b1 b1Var;
        int i;
        boolean z2;
        ViewGroup viewGroup = (ViewGroup) this.f4720k;
        ArrayList<C1967w0> arrayList = null;
        boolean z3 = false;
        if (viewGroup != null) {
            C1838u0 u0Var = this.f4715f;
            if (u0Var != null) {
                u0Var.mo6076i();
                ArrayList<C1967w0> l = this.f4715f.mo6078l();
                int size = l.size();
                i = 0;
                for (int i2 = 0; i2 < size; i2++) {
                    C1967w0 w0Var = l.get(i2);
                    if (w0Var.mo6320g()) {
                        View childAt = viewGroup.getChildAt(i);
                        C1967w0 itemData = childAt instanceof C0243b1.C0244a ? ((C0243b1.C0244a) childAt).getItemData() : null;
                        View f = mo4110f(w0Var, childAt, viewGroup);
                        if (w0Var != itemData) {
                            f.setPressed(false);
                            f.jumpDrawablesToCurrentState();
                        }
                        if (f != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) f.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(f);
                            }
                            ((ViewGroup) this.f4720k).addView(f, i);
                        }
                        i++;
                    }
                }
            } else {
                i = 0;
            }
            while (i < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i) == this.f3330l) {
                    z2 = false;
                } else {
                    viewGroup.removeViewAt(i);
                    z2 = true;
                }
                if (!z2) {
                    i++;
                }
            }
        }
        ((View) this.f4720k).requestLayout();
        C1838u0 u0Var2 = this.f4715f;
        if (u0Var2 != null) {
            u0Var2.mo6076i();
            ArrayList<C1967w0> arrayList2 = u0Var2.f6084i;
            int size2 = arrayList2.size();
            for (int i3 = 0; i3 < size2; i3++) {
                C1224n6 n6Var = arrayList2.get(i3).f6457A;
            }
        }
        C1838u0 u0Var3 = this.f4715f;
        if (u0Var3 != null) {
            u0Var3.mo6076i();
            arrayList = u0Var3.f6085j;
        }
        if (this.f3333o && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z3 = !arrayList.get(0).f6459C;
            } else if (size3 > 0) {
                z3 = true;
            }
        }
        C0932d dVar = this.f3330l;
        if (z3) {
            if (dVar == null) {
                this.f3330l = new C0932d(this.f4713d);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f3330l.getParent();
            if (viewGroup3 != this.f4720k) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f3330l);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f4720k;
                C0932d dVar2 = this.f3330l;
                ActionMenuView.C0086c q = actionMenuView.mo314h();
                q.f383c = true;
                actionMenuView.addView(dVar2, q);
            }
        } else if (dVar != null && dVar.getParent() == (b1Var = this.f4720k)) {
            ((ViewGroup) b1Var).removeView(this.f3330l);
        }
        ((ActionMenuView) this.f4720k).setOverflowReserved(this.f3333o);
    }

    /* renamed from: k */
    public boolean mo4111k() {
        C0243b1 b1Var;
        C0931c cVar = this.f3343y;
        if (cVar == null || (b1Var = this.f4720k) == null) {
            C0934e eVar = this.f3341w;
            if (eVar == null) {
                return false;
            }
            if (eVar.mo6723b()) {
                eVar.f7032j.dismiss();
            }
            return true;
        }
        ((View) b1Var).removeCallbacks(cVar);
        this.f3343y = null;
        return true;
    }

    /* renamed from: l */
    public boolean mo4112l() {
        C0929a aVar = this.f3342x;
        if (aVar == null) {
            return false;
        }
        if (!aVar.mo6723b()) {
            return true;
        }
        aVar.f7032j.dismiss();
        return true;
    }

    /* renamed from: m */
    public boolean mo4113m() {
        C0934e eVar = this.f3341w;
        return eVar != null && eVar.mo6723b();
    }

    /* renamed from: n */
    public boolean mo4114n() {
        C1838u0 u0Var;
        if (!this.f3333o || mo4113m() || (u0Var = this.f4715f) == null || this.f4720k == null || this.f3343y != null) {
            return false;
        }
        u0Var.mo6076i();
        if (u0Var.f6085j.isEmpty()) {
            return false;
        }
        C0931c cVar = new C0931c(new C0934e(this.f4714e, this.f4715f, this.f3330l, true));
        this.f3343y = cVar;
        ((View) this.f4720k).post(cVar);
        return true;
    }
}
