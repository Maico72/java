package p000;

/* renamed from: du */
public interface C0587du {
}
