package p000;

import java.util.ArrayList;
import java.util.List;

/* renamed from: cm */
public class C0377cm {

    /* renamed from: a */
    public final List<C0378a<?, ?>> f1626a = new ArrayList();

    /* renamed from: cm$a */
    public static final class C0378a<Z, R> {

        /* renamed from: a */
        public final Class<Z> f1627a;

        /* renamed from: b */
        public final Class<R> f1628b;

        /* renamed from: c */
        public final C0303bm<Z, R> f1629c;

        public C0378a(Class<Z> cls, Class<R> cls2, C0303bm<Z, R> bmVar) {
            this.f1627a = cls;
            this.f1628b = cls2;
            this.f1629c = bmVar;
        }

        /* renamed from: a */
        public boolean mo1973a(Class<?> cls, Class<?> cls2) {
            return this.f1627a.isAssignableFrom(cls) && cls2.isAssignableFrom(this.f1628b);
        }
    }

    /* renamed from: a */
    public synchronized <Z, R> List<Class<R>> mo1972a(Class<Z> cls, Class<R> cls2) {
        ArrayList arrayList = new ArrayList();
        if (cls2.isAssignableFrom(cls)) {
            arrayList.add(cls2);
            return arrayList;
        }
        for (C0378a<?, ?> a : this.f1626a) {
            if (a.mo1973a(cls, cls2)) {
                arrayList.add(cls2);
            }
        }
        return arrayList;
    }
}
