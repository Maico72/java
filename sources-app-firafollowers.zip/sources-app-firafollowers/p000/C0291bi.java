package p000;

import android.graphics.Bitmap;

/* renamed from: bi */
public class C0291bi implements C0056ai {
    /* renamed from: a */
    public void mo127a(int i) {
    }

    /* renamed from: b */
    public void mo128b() {
    }

    /* renamed from: c */
    public Bitmap mo129c(int i, int i2, Bitmap.Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    /* renamed from: d */
    public Bitmap mo130d(int i, int i2, Bitmap.Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    /* renamed from: e */
    public void mo131e(Bitmap bitmap) {
        bitmap.recycle();
    }
}
