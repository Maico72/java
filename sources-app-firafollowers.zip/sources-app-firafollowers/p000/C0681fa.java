package p000;

/* renamed from: fa */
public interface C0681fa {
    /* renamed from: g */
    C0615ea mo153g();
}
