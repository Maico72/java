package p000;

/* renamed from: iu */
public abstract class C0917iu {

    /* renamed from: a */
    public static final C0917iu f3309a;

    static {
        C0917iu iuVar;
        try {
            iuVar = (C0917iu) s00.m4855g(Class.forName("ju"), false);
        } catch (Throwable unused) {
            iuVar = null;
        }
        f3309a = iuVar;
    }

    /* renamed from: a */
    public abstract C1957vs mo4094a(C2166yu yuVar);

    /* renamed from: b */
    public abstract Boolean mo4095b(C1279nu nuVar);

    /* renamed from: c */
    public abstract Boolean mo4096c(C1279nu nuVar);
}
