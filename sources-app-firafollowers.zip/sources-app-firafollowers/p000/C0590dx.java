package p000;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: dx */
public final class C0590dx {

    /* renamed from: a */
    public final HashMap<i10, C1462ps<Object>> f2361a = new HashMap<>(64);

    /* renamed from: b */
    public final AtomicReference<C1833tx> f2362b = new AtomicReference<>();

    /* renamed from: a */
    public C1462ps<Object> mo3160a(C1035ks ksVar) {
        C1462ps<Object> psVar;
        synchronized (this) {
            psVar = this.f2361a.get(new i10(ksVar, false));
        }
        return psVar;
    }

    /* renamed from: b */
    public C1462ps<Object> mo3161b(Class<?> cls) {
        C1462ps<Object> psVar;
        synchronized (this) {
            psVar = this.f2361a.get(new i10(cls, false));
        }
        return psVar;
    }
}
