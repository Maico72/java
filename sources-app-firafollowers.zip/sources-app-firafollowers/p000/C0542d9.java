package p000;

import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* renamed from: d9 */
public class C0542d9 implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ ArrayList f2200d;

    /* renamed from: e */
    public final /* synthetic */ Map f2201e;

    public C0542d9(C0680f9 f9Var, ArrayList arrayList, Map map) {
        this.f2200d = arrayList;
        this.f2201e = map;
    }

    public void run() {
        String str;
        int size = this.f2200d.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f2200d.get(i);
            String i2 = C0010a7.m36i(view);
            if (i2 != null) {
                Iterator it = this.f2201e.entrySet().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        str = null;
                        break;
                    }
                    Map.Entry entry = (Map.Entry) it.next();
                    if (i2.equals(entry.getValue())) {
                        str = (String) entry.getKey();
                        break;
                    }
                }
                C0010a7.m46s(view, str);
            }
        }
    }
}
