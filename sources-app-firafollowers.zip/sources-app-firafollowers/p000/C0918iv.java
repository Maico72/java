package p000;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import p000.C1206mu;

/* renamed from: iv */
public class C0918iv extends C1206mu {

    /* renamed from: a */
    public final C0919a f3310a;

    /* renamed from: b */
    public final boolean f3311b;

    /* renamed from: c */
    public final String f3312c;

    /* renamed from: d */
    public final String f3313d;

    /* renamed from: e */
    public final String f3314e;

    /* renamed from: iv$a */
    public interface C0919a {
        /* renamed from: a */
        boolean mo4102a(char c, String str, int i);
    }

    /* renamed from: iv$b */
    public static class C0920b extends C1206mu.C1207a implements Serializable {
    }

    /* renamed from: iv$c */
    public static class C0921c extends C0918iv {

        /* renamed from: f */
        public final Set<String> f3315f = new HashSet();

        public C0921c(C1757st<?> stVar, C1364ou ouVar) {
            super(stVar, ouVar, (String) null, "get", "is", (C0919a) null);
            Class<?> cls = ouVar.f4584e;
            RuntimeException runtimeException = C1831tv.f6055d;
            if (runtimeException == null) {
                C1831tv tvVar = C1831tv.f6054c;
                Objects.requireNonNull(tvVar);
                try {
                    Object[] objArr = (Object[]) tvVar.f6056a.invoke(cls, new Object[0]);
                    int length = objArr.length;
                    String[] strArr = new String[length];
                    int i = 0;
                    while (i < objArr.length) {
                        try {
                            strArr[i] = (String) tvVar.f6057b.invoke(objArr[i], new Object[0]);
                            i++;
                        } catch (Exception e) {
                            throw new IllegalArgumentException(String.format("Failed to access name of field #%d (of %d) of Record type %s", new Object[]{Integer.valueOf(i), Integer.valueOf(objArr.length), s00.m4869u(cls)}), e);
                        }
                    }
                    for (int i2 = 0; i2 < length; i2++) {
                        this.f3315f.add(strArr[i2]);
                    }
                } catch (Exception unused) {
                    StringBuilder d = C1012kd.m3195d("Failed to access RecordComponents of type ");
                    d.append(s00.m4869u(cls));
                    throw new IllegalArgumentException(d.toString());
                }
            } else {
                throw runtimeException;
            }
        }

        /* renamed from: c */
        public String mo4099c(C1959vu vuVar, String str) {
            return this.f3315f.contains(str) ? str : C0918iv.super.mo4099c(vuVar, str);
        }
    }

    public C0918iv(C1757st<?> stVar, C1364ou ouVar, String str, String str2, String str3, C0919a aVar) {
        this.f3311b = stVar.mo5872n(C1694rs.USE_STD_BEAN_NAMING);
        this.f3314e = str;
        this.f3312c = str2;
        this.f3313d = str3;
        this.f3310a = aVar;
    }

    /* renamed from: a */
    public String mo4097a(C1959vu vuVar, String str) {
        if (this.f3313d == null) {
            return null;
        }
        Class<?> d = vuVar.mo4874d();
        if ((d == Boolean.class || d == Boolean.TYPE) && str.startsWith(this.f3313d)) {
            return this.f3311b ? mo4101e(str, 2) : mo4100d(str, 2);
        }
        return null;
    }

    /* renamed from: b */
    public String mo4098b(C1959vu vuVar, String str) {
        String str2 = this.f3314e;
        if (str2 == null || !str.startsWith(str2)) {
            return null;
        }
        return this.f3311b ? mo4101e(str, this.f3314e.length()) : mo4100d(str, this.f3314e.length());
    }

    /* renamed from: c */
    public String mo4099c(C1959vu vuVar, String str) {
        String str2 = this.f3312c;
        if (str2 == null || !str.startsWith(str2)) {
            return null;
        }
        if ("getCallbacks".equals(str)) {
            Class<?> d = vuVar.mo4874d();
            boolean z = false;
            if (d.isArray()) {
                String name = d.getComponentType().getName();
                if (name.contains(".cglib") && (name.startsWith("net.sf.cglib") || name.startsWith("org.hibernate.repackage.cglib") || name.startsWith("org.springframework.cglib"))) {
                    z = true;
                }
            }
            if (z) {
                return null;
            }
        } else if ("getMetaClass".equals(str) && vuVar.mo4874d().getName().startsWith("groovy.lang")) {
            return null;
        }
        return this.f3311b ? mo4101e(str, this.f3312c.length()) : mo4100d(str, this.f3312c.length());
    }

    /* renamed from: d */
    public String mo4100d(String str, int i) {
        int length = str.length();
        if (length == i) {
            return null;
        }
        char charAt = str.charAt(i);
        C0919a aVar = this.f3310a;
        if (aVar != null && !aVar.mo4102a(charAt, str, i)) {
            return null;
        }
        char lowerCase = Character.toLowerCase(charAt);
        if (charAt == lowerCase) {
            return str.substring(i);
        }
        StringBuilder sb = new StringBuilder(length - i);
        sb.append(lowerCase);
        while (true) {
            i++;
            if (i >= length) {
                break;
            }
            char charAt2 = str.charAt(i);
            char lowerCase2 = Character.toLowerCase(charAt2);
            if (charAt2 == lowerCase2) {
                sb.append(str, i, length);
                break;
            }
            sb.append(lowerCase2);
        }
        return sb.toString();
    }

    /* renamed from: e */
    public String mo4101e(String str, int i) {
        int length = str.length();
        if (length == i) {
            return null;
        }
        char charAt = str.charAt(i);
        C0919a aVar = this.f3310a;
        if (aVar != null && !aVar.mo4102a(charAt, str, i)) {
            return null;
        }
        char lowerCase = Character.toLowerCase(charAt);
        if (charAt == lowerCase) {
            return str.substring(i);
        }
        int i2 = i + 1;
        if (i2 < length && Character.isUpperCase(str.charAt(i2))) {
            return str.substring(i);
        }
        StringBuilder sb = new StringBuilder(length - i);
        sb.append(lowerCase);
        sb.append(str, i2, length);
        return sb.toString();
    }
}
