package p000;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: cd */
public class C0351cd implements Interpolator {

    /* renamed from: a */
    public float[] f1548a;

    /* renamed from: b */
    public float[] f1549b;

    public C0351cd(Context context, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        TypedArray e = C0532d5.m1705e(context.getResources(), context.getTheme(), attributeSet, C2142yc.f6932l);
        if (C0532d5.m1704d(xmlPullParser, "pathData")) {
            String c = C0532d5.m1703c(e, xmlPullParser, "pathData", 4);
            Path s = C1401p4.m4385s(c);
            if (s != null) {
                mo1925a(s);
            } else {
                throw new InflateException(C1012kd.m3202k("The path is null, which is created from ", c));
            }
        } else if (!C0532d5.m1704d(xmlPullParser, "controlX1")) {
            throw new InflateException("pathInterpolator requires the controlX1 attribute");
        } else if (C0532d5.m1704d(xmlPullParser, "controlY1")) {
            float f = !C0532d5.m1704d(xmlPullParser, "controlX1") ? 0.0f : e.getFloat(0, 0.0f);
            float f2 = !C0532d5.m1704d(xmlPullParser, "controlY1") ? 0.0f : e.getFloat(1, 0.0f);
            boolean d = C0532d5.m1704d(xmlPullParser, "controlX2");
            if (d != C0532d5.m1704d(xmlPullParser, "controlY2")) {
                throw new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
            } else if (!d) {
                Path path = new Path();
                path.moveTo(0.0f, 0.0f);
                path.quadTo(f, f2, 1.0f, 1.0f);
                mo1925a(path);
            } else {
                float f3 = !C0532d5.m1704d(xmlPullParser, "controlX2") ? 0.0f : e.getFloat(2, 0.0f);
                float f4 = !C0532d5.m1704d(xmlPullParser, "controlY2") ? 0.0f : e.getFloat(3, 0.0f);
                Path path2 = new Path();
                path2.moveTo(0.0f, 0.0f);
                path2.cubicTo(f, f2, f3, f4, 1.0f, 1.0f);
                mo1925a(path2);
            }
        } else {
            throw new InflateException("pathInterpolator requires the controlY1 attribute");
        }
        e.recycle();
    }

    /* renamed from: a */
    public final void mo1925a(Path path) {
        int i = 0;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        float length = pathMeasure.getLength();
        int min = Math.min(3000, ((int) (length / 0.002f)) + 1);
        if (min > 0) {
            this.f1548a = new float[min];
            this.f1549b = new float[min];
            float[] fArr = new float[2];
            for (int i2 = 0; i2 < min; i2++) {
                pathMeasure.getPosTan((((float) i2) * length) / ((float) (min - 1)), fArr, (float[]) null);
                this.f1548a[i2] = fArr[0];
                this.f1549b[i2] = fArr[1];
            }
            if (((double) Math.abs(this.f1548a[0])) <= 1.0E-5d && ((double) Math.abs(this.f1549b[0])) <= 1.0E-5d) {
                int i3 = min - 1;
                if (((double) Math.abs(this.f1548a[i3] - 1.0f)) <= 1.0E-5d && ((double) Math.abs(this.f1549b[i3] - 1.0f)) <= 1.0E-5d) {
                    float f = 0.0f;
                    int i4 = 0;
                    while (i < min) {
                        float[] fArr2 = this.f1548a;
                        int i5 = i4 + 1;
                        float f2 = fArr2[i4];
                        if (f2 >= f) {
                            fArr2[i] = f2;
                            i++;
                            f = f2;
                            i4 = i5;
                        } else {
                            throw new IllegalArgumentException("The Path cannot loop back on itself, x :" + f2);
                        }
                    }
                    if (pathMeasure.nextContour()) {
                        throw new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
                    }
                    return;
                }
            }
            StringBuilder d = C1012kd.m3195d("The Path must start at (0,0) and end at (1,1) start: ");
            d.append(this.f1548a[0]);
            d.append(",");
            d.append(this.f1549b[0]);
            d.append(" end:");
            int i6 = min - 1;
            d.append(this.f1548a[i6]);
            d.append(",");
            d.append(this.f1549b[i6]);
            throw new IllegalArgumentException(d.toString());
        }
        throw new IllegalArgumentException("The Path has a invalid length " + length);
    }

    public float getInterpolation(float f) {
        if (f <= 0.0f) {
            return 0.0f;
        }
        if (f >= 1.0f) {
            return 1.0f;
        }
        int i = 0;
        int length = this.f1548a.length - 1;
        while (length - i > 1) {
            int i2 = (i + length) / 2;
            if (f < this.f1548a[i2]) {
                length = i2;
            } else {
                i = i2;
            }
        }
        float[] fArr = this.f1548a;
        float f2 = fArr[length] - fArr[i];
        if (f2 == 0.0f) {
            return this.f1549b[i];
        }
        float[] fArr2 = this.f1549b;
        float f3 = fArr2[i];
        return C1012kd.m3192a(fArr2[length], f3, (f - fArr[i]) / f2, f3);
    }
}
