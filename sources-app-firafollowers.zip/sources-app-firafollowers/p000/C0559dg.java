package p000;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import java.io.FileNotFoundException;

/* renamed from: dg */
public final class C0559dg extends C1341og<AssetFileDescriptor> {
    public C0559dg(ContentResolver contentResolver, Uri uri) {
        super(contentResolver, uri);
    }

    /* renamed from: a */
    public Class<AssetFileDescriptor> mo134a() {
        return AssetFileDescriptor.class;
    }

    /* renamed from: d */
    public void mo3050d(Object obj) {
        ((AssetFileDescriptor) obj).close();
    }

    /* renamed from: f */
    public Object mo3051f(Uri uri, ContentResolver contentResolver) {
        AssetFileDescriptor openAssetFileDescriptor = contentResolver.openAssetFileDescriptor(uri, "r");
        if (openAssetFileDescriptor != null) {
            return openAssetFileDescriptor;
        }
        throw new FileNotFoundException(C1012kd.m3200i("FileDescriptor is null for: ", uri));
    }
}
