package p000;

/* renamed from: cx */
public interface C0517cx {
    /* renamed from: b */
    void mo2817b(C0221at atVar);
}
