package p000;

/* renamed from: cs */
public abstract class C0510cs {
}
