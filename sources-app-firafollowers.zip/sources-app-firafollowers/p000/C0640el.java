package p000;

import java.nio.ByteBuffer;
import p000.C0833hg;

/* renamed from: el */
public class C0640el implements C0833hg<ByteBuffer> {

    /* renamed from: a */
    public final ByteBuffer f2606a;

    /* renamed from: el$a */
    public static class C0641a implements C0833hg.C0834a<ByteBuffer> {
        /* renamed from: a */
        public Class<ByteBuffer> mo1983a() {
            return ByteBuffer.class;
        }

        /* renamed from: b */
        public C0833hg mo1984b(Object obj) {
            return new C0640el((ByteBuffer) obj);
        }
    }

    public C0640el(ByteBuffer byteBuffer) {
        this.f2606a = byteBuffer;
    }

    /* renamed from: a */
    public Object mo1979a() {
        this.f2606a.position(0);
        return this.f2606a;
    }

    /* renamed from: b */
    public void mo1980b() {
    }
}
