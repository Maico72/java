package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p000.C0673f6;

/* renamed from: e2 */
public class C0599e2 extends TextView implements C2195z6, C1905v7, C1660r7 {

    /* renamed from: d */
    public final C1056l1 f2441d;

    /* renamed from: e */
    public final C0523d2 f2442e;

    /* renamed from: f */
    public final C0326c2 f2443f;

    /* renamed from: g */
    public Future<C0673f6> f2444g;

    public C0599e2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public C0599e2(Context context, AttributeSet attributeSet, int i) {
        super(C2182z2.m5945a(context), attributeSet, i);
        C2045x2.m5634a(this, getContext());
        C1056l1 l1Var = new C1056l1(this);
        this.f2441d = l1Var;
        l1Var.mo4390d(attributeSet, i);
        C0523d2 d2Var = new C0523d2(this);
        this.f2442e = d2Var;
        d2Var.mo2865e(attributeSet, i);
        d2Var.mo2863b();
        this.f2443f = new C0326c2(this);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            l1Var.mo4387a();
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C1660r7.f5446a) {
            return super.getAutoSizeMaxTextSize();
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            return Math.round(d2Var.f2128i.f2649e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C1660r7.f5446a) {
            return super.getAutoSizeMinTextSize();
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            return Math.round(d2Var.f2128i.f2648d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C1660r7.f5446a) {
            return super.getAutoSizeStepGranularity();
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            return Math.round(d2Var.f2128i.f2647c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C1660r7.f5446a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0523d2 d2Var = this.f2442e;
        return d2Var != null ? d2Var.f2128i.f2650f : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (C1660r7.f5446a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            return d2Var.f2128i.f2645a;
        }
        return 0;
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            return l1Var.mo4388b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            return l1Var.mo4389c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        C0006a3 a3Var = this.f2442e.f2127h;
        if (a3Var != null) {
            return a3Var.f15a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        C0006a3 a3Var = this.f2442e.f2127h;
        if (a3Var != null) {
            return a3Var.f16b;
        }
        return null;
    }

    public CharSequence getText() {
        Future<C0673f6> future = this.f2444g;
        if (future != null) {
            try {
                this.f2444g = null;
                C1401p4.m4361f0(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f2443f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            c2 r0 = r2.f2443f
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.mo1822a()
            return r0
        L_0x0010:
            android.view.textclassifier.TextClassifier r0 = super.getTextClassifier()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0599e2.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public C0673f6.C0674a getTextMetricsParamsCompat() {
        return C1401p4.m4330G(this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0520d.m1653b(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null && !C1660r7.f5446a) {
            d2Var.f2128i.mo3463a();
        }
    }

    public void onMeasure(int i, int i2) {
        Future<C0673f6> future = this.f2444g;
        if (future != null) {
            try {
                this.f2444g = null;
                C1401p4.m4361f0(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i, i2);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null && !C1660r7.f5446a && d2Var.mo2864d()) {
            this.f2442e.f2128i.mo3463a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (C1660r7.f5446a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2867g(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (C1660r7.f5446a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2868h(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C1660r7.f5446a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2869i(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            l1Var.mo4391e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            l1Var.mo4392f(i);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C0001a0.m1b(context, i) : null;
        Drawable b2 = i2 != 0 ? C0001a0.m1b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C0001a0.m1b(context, i3) : null;
        if (i4 != 0) {
            drawable = C0001a0.m1b(context, i4);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(b, b2, b3, drawable);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C0001a0.m1b(context, i) : null;
        Drawable b2 = i2 != 0 ? C0001a0.m1b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C0001a0.m1b(context, i3) : null;
        if (i4 != 0) {
            drawable = C0001a0.m1b(context, i4);
        }
        setCompoundDrawablesWithIntrinsicBounds(b, b2, b3, drawable);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C1401p4.m4383q0(this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            C1401p4.m4348Y(this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            C1401p4.m4353b0(this, i);
        }
    }

    public void setLineHeight(int i) {
        C1401p4.m4357d0(this, i);
    }

    public void setPrecomputedText(C0673f6 f6Var) {
        C1401p4.m4361f0(this, f6Var);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            l1Var.mo4394h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C1056l1 l1Var = this.f2441d;
        if (l1Var != null) {
            l1Var.mo4395i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f2442e.mo2870j(colorStateList);
        this.f2442e.mo2863b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f2442e.mo2871k(mode);
        this.f2442e.mo2863b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2866f(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C0326c2 c2Var;
        if (Build.VERSION.SDK_INT >= 28 || (c2Var = this.f2443f) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            c2Var.f1423b = textClassifier;
        }
    }

    public void setTextFuture(Future<C0673f6> future) {
        this.f2444g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C0673f6.C0674a aVar) {
        int i = Build.VERSION.SDK_INT;
        TextDirectionHeuristic textDirectionHeuristic = aVar.f2691b;
        int i2 = 1;
        if (!(textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL || textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i2 = 6;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        if (i < 23) {
            float textScaleX = aVar.f2690a.getTextScaleX();
            getPaint().set(aVar.f2690a);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
            return;
        }
        getPaint().set(aVar.f2690a);
        setBreakStrategy(aVar.f2692c);
        setHyphenationFrequency(aVar.f2693d);
    }

    public void setTextSize(int i, float f) {
        boolean z = C1660r7.f5446a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null && !z && !d2Var.mo2864d()) {
            d2Var.f2128i.mo3466f(i, f);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x003b, code lost:
        if (r0 != null) goto L_0x004b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setTypeface(android.graphics.Typeface r9, int r10) {
        /*
            r8 = this;
            r0 = 0
            if (r9 == 0) goto L_0x004b
            if (r10 <= 0) goto L_0x004b
            android.content.Context r1 = r8.getContext()
            n5 r2 = p000.C0808h5.f3033a
            if (r1 == 0) goto L_0x0043
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 21
            if (r2 >= r3) goto L_0x003e
            n5 r2 = p000.C0808h5.f3033a
            java.util.Objects.requireNonNull(r2)
            long r3 = p000.C1221n5.m3845g(r9)
            r5 = 0
            int r7 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r7 != 0) goto L_0x0024
            r3 = r0
            goto L_0x0030
        L_0x0024:
            java.util.concurrent.ConcurrentHashMap<java.lang.Long, y4> r5 = r2.f4189a
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            java.lang.Object r3 = r5.get(r3)
            y4 r3 = (p000.C2111y4) r3
        L_0x0030:
            if (r3 != 0) goto L_0x0033
            goto L_0x003b
        L_0x0033:
            android.content.res.Resources r0 = r1.getResources()
            android.graphics.Typeface r0 = r2.mo3999a(r1, r3, r0, r10)
        L_0x003b:
            if (r0 == 0) goto L_0x003e
            goto L_0x004b
        L_0x003e:
            android.graphics.Typeface r0 = android.graphics.Typeface.create(r9, r10)
            goto L_0x004b
        L_0x0043:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r10 = "Context cannot be null"
            r9.<init>(r10)
            throw r9
        L_0x004b:
            if (r0 == 0) goto L_0x004e
            r9 = r0
        L_0x004e:
            super.setTypeface(r9, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0599e2.setTypeface(android.graphics.Typeface, int):void");
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0523d2 d2Var = this.f2442e;
        if (d2Var != null) {
            d2Var.mo2863b();
        }
    }
}
