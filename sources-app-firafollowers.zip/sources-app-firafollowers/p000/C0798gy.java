package p000;

import p000.C0576dp;

@C0313bt
/* renamed from: gy */
public final class C0798gy extends C1703rz<Object> implements C2100xw {

    /* renamed from: f */
    public final boolean f2992f;

    /* renamed from: gy$a */
    public static final class C0799a extends C1703rz<Object> implements C2100xw {

        /* renamed from: f */
        public final boolean f2993f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0799a(boolean z) {
            super(z ? Boolean.TYPE : Boolean.class, false);
            this.f2993f = z;
        }

        /* renamed from: a */
        public C1462ps<?> mo2818a(C0221at atVar, C0714fs fsVar) {
            C0576dp.C0580d l = mo5883l(atVar, fsVar, Boolean.class);
            return (l == null || l.f2342e.mo3086a()) ? this : new C0798gy(this.f2993f);
        }

        /* renamed from: f */
        public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
            mqVar.mo3742t(Boolean.FALSE.equals(obj) ^ true ? 1 : 0);
        }

        /* renamed from: g */
        public final void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
            mqVar.mo3734l(Boolean.TRUE.equals(obj));
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0798gy(boolean z) {
        super(z ? Boolean.TYPE : Boolean.class, false);
        this.f2992f = z;
    }

    /* renamed from: a */
    public C1462ps<?> mo2818a(C0221at atVar, C0714fs fsVar) {
        C0576dp.C0580d l = mo5883l(atVar, fsVar, Boolean.class);
        return (l == null || !l.f2342e.mo3086a()) ? this : new C0799a(this.f2992f);
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3734l(Boolean.TRUE.equals(obj));
    }

    /* renamed from: g */
    public final void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        mqVar.mo3734l(Boolean.TRUE.equals(obj));
    }
}
