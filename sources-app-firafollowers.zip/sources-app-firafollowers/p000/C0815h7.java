package p000;

import android.view.View;

/* renamed from: h7 */
public class C0815h7 implements C0738g7 {
    public void onAnimationCancel(View view) {
    }

    public void onAnimationEnd(View view) {
        throw null;
    }

    public void onAnimationStart(View view) {
    }
}
