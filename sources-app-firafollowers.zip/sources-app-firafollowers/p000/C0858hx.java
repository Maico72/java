package p000;

/* renamed from: hx */
public class C0858hx extends C0797gx {

    /* renamed from: w */
    public final String f3164w;

    public C0858hx(String str, C0652ev evVar, o00 o00, C1035ks ksVar) {
        super(evVar, o00, ksVar, (C1462ps<?>) null, (C0230aw) null, (C1035ks) null, evVar.mo3179b(), (Class<?>[]) null);
        this.f3164w = str;
    }

    /* renamed from: l */
    public Object mo3843l(Object obj, C1200mq mqVar, C0221at atVar) {
        return atVar.mo1465x(this.f3164w);
    }

    /* renamed from: m */
    public C0797gx mo3844m(C1757st<?> stVar, C1364ou ouVar, C0652ev evVar, C1035ks ksVar) {
        throw new IllegalStateException("Should not be called on this type");
    }
}
