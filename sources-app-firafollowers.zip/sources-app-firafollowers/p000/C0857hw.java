package p000;

import p000.C2031wv;

/* renamed from: hw */
public final class C0857hw extends C2031wv.C2032a {

    /* renamed from: d */
    public static final C0857hw f3163d = new C0857hw();
}
