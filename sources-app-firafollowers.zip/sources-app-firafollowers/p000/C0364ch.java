package p000;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import p000.C0377cm;
import p000.C0560dh;
import p000.C0643en;
import p000.C0770gh;
import p000.C0902in;
import p000.C0969jj;
import p000.C2144ye;

/* renamed from: ch */
public final class C0364ch<Transcode> {

    /* renamed from: a */
    public final List<C0969jj.C0970a<?>> f1591a = new ArrayList();

    /* renamed from: b */
    public final List<C2005wf> f1592b = new ArrayList();

    /* renamed from: c */
    public C1933ve f1593c;

    /* renamed from: d */
    public Object f1594d;

    /* renamed from: e */
    public int f1595e;

    /* renamed from: f */
    public int f1596f;

    /* renamed from: g */
    public Class<?> f1597g;

    /* renamed from: h */
    public C0560dh.C0564d f1598h;

    /* renamed from: i */
    public C2150yf f1599i;

    /* renamed from: j */
    public Map<Class<?>, C0363cg<?>> f1600j;

    /* renamed from: k */
    public Class<Transcode> f1601k;

    /* renamed from: l */
    public boolean f1602l;

    /* renamed from: m */
    public boolean f1603m;

    /* renamed from: n */
    public C2005wf f1604n;

    /* renamed from: o */
    public C2066xe f1605o;

    /* renamed from: p */
    public C0696fh f1606p;

    /* renamed from: q */
    public boolean f1607q;

    /* renamed from: r */
    public boolean f1608r;

    /* renamed from: a */
    public List<C2005wf> mo1953a() {
        if (!this.f1603m) {
            this.f1603m = true;
            this.f1592b.clear();
            List<C0969jj.C0970a<?>> c = mo1955c();
            int size = c.size();
            for (int i = 0; i < size; i++) {
                C0969jj.C0970a aVar = c.get(i);
                if (!this.f1592b.contains(aVar.f3455a)) {
                    this.f1592b.add(aVar.f3455a);
                }
                for (int i2 = 0; i2 < aVar.f3456b.size(); i2++) {
                    if (!this.f1592b.contains(aVar.f3456b.get(i2))) {
                        this.f1592b.add(aVar.f3456b.get(i2));
                    }
                }
            }
        }
        return this.f1592b;
    }

    /* renamed from: b */
    public C1020ki mo1954b() {
        return ((C0770gh.C0775c) this.f1598h).mo3811a();
    }

    /* renamed from: c */
    public List<C0969jj.C0970a<?>> mo1955c() {
        if (!this.f1602l) {
            this.f1602l = true;
            this.f1591a.clear();
            List f = this.f1593c.f6371b.mo6695f(this.f1594d);
            int size = f.size();
            for (int i = 0; i < size; i++) {
                C0969jj.C0970a a = ((C0969jj) f.get(i)).mo132a(this.f1594d, this.f1595e, this.f1596f, this.f1599i);
                if (a != null) {
                    this.f1591a.add(a);
                }
            }
        }
        return this.f1591a;
    }

    /* renamed from: d */
    public <Data> C1448ph<Data, ?, Transcode> mo1956d(Class<Data> cls) {
        C1448ph<Data, ?, Transcode> orDefault;
        ArrayList arrayList;
        C0303bm bmVar;
        C0303bm bmVar2;
        Class<Data> cls2 = cls;
        C2144ye yeVar = this.f1593c.f6371b;
        Class<?> cls3 = this.f1597g;
        Class<Transcode> cls4 = this.f1601k;
        C0787gn gnVar = yeVar.f6943i;
        C1456po andSet = gnVar.f2979b.getAndSet((Object) null);
        if (andSet == null) {
            andSet = new C1456po();
        }
        andSet.f4914a = cls2;
        andSet.f4915b = cls3;
        andSet.f4916c = cls4;
        synchronized (gnVar.f2978a) {
            orDefault = gnVar.f2978a.getOrDefault(andSet, null);
        }
        gnVar.f2979b.set(andSet);
        Objects.requireNonNull(yeVar.f6943i);
        if (C0787gn.f2977c.equals(orDefault)) {
            return null;
        }
        if (orDefault != null) {
            return orDefault;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = ((ArrayList) yeVar.f6937c.mo4052b(cls2, cls3)).iterator();
        while (it.hasNext()) {
            Class cls5 = (Class) it.next();
            Iterator it2 = ((ArrayList) yeVar.f6940f.mo1972a(cls5, cls4)).iterator();
            while (true) {
                if (it2.hasNext()) {
                    Class cls6 = (Class) it2.next();
                    C0902in inVar = yeVar.f6937c;
                    synchronized (inVar) {
                        arrayList = new ArrayList();
                        for (String str : inVar.f3279a) {
                            List<C0902in.C0903a> list = inVar.f3280b.get(str);
                            if (list != null) {
                                for (C0902in.C0903a aVar : list) {
                                    if (aVar.mo4053a(cls2, cls5)) {
                                        arrayList.add(aVar.f3283c);
                                    }
                                }
                            }
                        }
                    }
                    C0377cm cmVar = yeVar.f6940f;
                    synchronized (cmVar) {
                        if (cls6.isAssignableFrom(cls5)) {
                            bmVar = C0573dm.f2315a;
                        } else {
                            for (C0377cm.C0378a next : cmVar.f1626a) {
                                if (next.mo1973a(cls5, cls6)) {
                                    bmVar = next.f1629c;
                                }
                            }
                            throw new IllegalArgumentException("No transcoder registered to transcode from " + cls5 + " to " + cls6);
                        }
                        bmVar2 = bmVar;
                    }
                    C0635eh ehVar = r2;
                    C0635eh ehVar2 = new C0635eh(cls, cls5, cls6, arrayList, bmVar2, yeVar.f6944j);
                    arrayList2.add(ehVar);
                }
            }
        }
        C1448ph<Data, ?, Transcode> phVar = arrayList2.isEmpty() ? null : new C1448ph<>(cls, cls3, cls4, arrayList2, yeVar.f6944j);
        C0787gn gnVar2 = yeVar.f6943i;
        synchronized (gnVar2.f2978a) {
            gnVar2.f2978a.put(new C1456po(cls2, cls3, cls4), phVar != null ? phVar : C0787gn.f2977c);
        }
        return phVar;
    }

    /* renamed from: e */
    public <X> C1253nf<X> mo1957e(X x) {
        C1253nf<T> nfVar;
        C0643en enVar = this.f1593c.f6371b.f6936b;
        Class<?> cls = x.getClass();
        synchronized (enVar) {
            Iterator<C0643en.C0644a<?>> it = enVar.f2610a.iterator();
            while (true) {
                if (!it.hasNext()) {
                    nfVar = null;
                    break;
                }
                C0643en.C0644a next = it.next();
                if (next.f2611a.isAssignableFrom(cls)) {
                    nfVar = next.f2612b;
                    break;
                }
            }
        }
        if (nfVar != null) {
            return nfVar;
        }
        throw new C2144ye.C2149e(x.getClass());
    }

    /* renamed from: f */
    public <Z> C0363cg<Z> mo1958f(Class<Z> cls) {
        C0363cg<Z> cgVar = this.f1600j.get(cls);
        if (cgVar == null) {
            Iterator<Map.Entry<Class<?>, C0363cg<?>>> it = this.f1600j.entrySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Map.Entry next = it.next();
                if (((Class) next.getKey()).isAssignableFrom(cls)) {
                    cgVar = (C0363cg) next.getValue();
                    break;
                }
            }
        }
        if (cgVar != null) {
            return cgVar;
        }
        if (!this.f1600j.isEmpty() || !this.f1607q) {
            return (C0062ak) C0062ak.f192b;
        }
        throw new IllegalArgumentException("Missing transformation for " + cls + ". If you wish to ignore unknown resource types, use the optional transformation methods.");
    }

    /* renamed from: g */
    public boolean mo1959g(Class<?> cls) {
        return mo1956d(cls) != null;
    }
}
