package p000;

import p000.C2090xp;

/* renamed from: ew */
public class C0653ew extends C0316bw {

    /* renamed from: c */
    public final String f2618c;

    public C0653ew(C2167yv yvVar, C0714fs fsVar, String str) {
        super(yvVar, fsVar);
        this.f2618c = str;
    }

    /* renamed from: b */
    public String mo1475b() {
        return this.f2618c;
    }

    /* renamed from: c */
    public C2090xp.C2091a mo1476c() {
        return C2090xp.C2091a.PROPERTY;
    }

    /* renamed from: h */
    public C0653ew mo1731g(C0714fs fsVar) {
        return this.f4378b == fsVar ? this : new C0653ew(this.f4377a, fsVar, this.f2618c);
    }
}
