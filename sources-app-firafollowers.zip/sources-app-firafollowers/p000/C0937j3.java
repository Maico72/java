package p000;

/* renamed from: j3 */
public interface C0937j3 {
    /* renamed from: a */
    CharSequence mo4121a();
}
