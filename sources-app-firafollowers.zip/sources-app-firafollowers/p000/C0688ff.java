package p000;

import android.graphics.Bitmap;
import java.nio.ByteBuffer;

/* renamed from: ff */
public interface C0688ff {

    /* renamed from: ff$a */
    public interface C0689a {
    }

    /* renamed from: a */
    int mo3581a();

    /* renamed from: b */
    int mo3582b();

    /* renamed from: c */
    Bitmap mo3583c();

    void clear();

    /* renamed from: d */
    void mo3585d();

    /* renamed from: e */
    int mo3586e();

    /* renamed from: f */
    int mo3587f();

    /* renamed from: g */
    ByteBuffer mo3588g();
}
