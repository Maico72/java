package p000;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: fc */
public class C0683fc extends AnimatorListenerAdapter {

    /* renamed from: a */
    public final /* synthetic */ C0545dc f2727a;

    public C0683fc(C0545dc dcVar) {
        this.f2727a = dcVar;
    }

    public void onAnimationEnd(Animator animator) {
        this.f2727a.mo3004m();
        animator.removeListener(this);
    }
}
