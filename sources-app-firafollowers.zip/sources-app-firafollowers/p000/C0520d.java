package p000;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.lang.reflect.Field;

/* renamed from: d */
public final class C0520d {

    /* renamed from: a */
    public static Field f2110a;

    /* renamed from: b */
    public static boolean f2111b;

    /* renamed from: c */
    public static Class<?> f2112c;

    /* renamed from: d */
    public static boolean f2113d;

    /* renamed from: e */
    public static Field f2114e;

    /* renamed from: f */
    public static boolean f2115f;

    /* renamed from: g */
    public static Field f2116g;

    /* renamed from: h */
    public static boolean f2117h;

    /* renamed from: a */
    public static void m1652a(Object obj) {
        if (!f2113d) {
            try {
                f2112c = Class.forName("android.content.res.ThemedResourceCache");
            } catch (ClassNotFoundException e) {
                Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e);
            }
            f2113d = true;
        }
        Class<?> cls = f2112c;
        if (cls != null) {
            if (!f2115f) {
                try {
                    Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                    f2114e = declaredField;
                    declaredField.setAccessible(true);
                } catch (NoSuchFieldException e2) {
                    Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e2);
                }
                f2115f = true;
            }
            Field field = f2114e;
            if (field != null) {
                LongSparseArray longSparseArray = null;
                try {
                    longSparseArray = (LongSparseArray) field.get(obj);
                } catch (IllegalAccessException e3) {
                    Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e3);
                }
                if (longSparseArray != null) {
                    longSparseArray.clear();
                }
            }
        }
    }

    /* renamed from: b */
    public static InputConnection m1653b(InputConnection inputConnection, EditorInfo editorInfo, View view) {
        if (inputConnection != null && editorInfo.hintText == null) {
            ViewParent parent = view.getParent();
            while (true) {
                if (!(parent instanceof View)) {
                    break;
                } else if (parent instanceof C0937j3) {
                    editorInfo.hintText = ((C0937j3) parent).mo4121a();
                    break;
                } else {
                    parent = parent.getParent();
                }
            }
        }
        return inputConnection;
    }

    /* renamed from: c */
    public static void m1654c(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
            return;
        }
        C0667f3 f3Var = C0667f3.f2657m;
        if (f3Var != null && f3Var.f2659d == view) {
            C0667f3.m2139c((C0667f3) null);
        }
        if (TextUtils.isEmpty(charSequence)) {
            C0667f3 f3Var2 = C0667f3.f2658n;
            if (f3Var2 != null && f3Var2.f2659d == view) {
                f3Var2.mo3475b();
            }
            view.setOnLongClickListener((View.OnLongClickListener) null);
            view.setLongClickable(false);
            view.setOnHoverListener((View.OnHoverListener) null);
            return;
        }
        new C0667f3(view, charSequence);
    }
}
