package p000;

import android.view.View;
import androidx.appcompat.app.AlertController;

/* renamed from: h */
public class C0801h implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ View f2994d;

    /* renamed from: e */
    public final /* synthetic */ View f2995e;

    /* renamed from: f */
    public final /* synthetic */ AlertController f2996f;

    public C0801h(AlertController alertController, View view, View view2) {
        this.f2996f = alertController;
        this.f2994d = view;
        this.f2995e = view2;
    }

    public void run() {
        AlertController.m141c(this.f2996f.f218A, this.f2994d, this.f2995e);
    }
}
