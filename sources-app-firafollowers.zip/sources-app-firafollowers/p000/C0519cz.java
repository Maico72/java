package p000;

import p000.C1356oq;

@C0313bt
/* renamed from: cz */
public class C0519cz extends C2171yy<Object> {
    public C0519cz(Class<?> cls) {
        super(cls, C1356oq.C1358b.INT, "integer");
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3742t(((Integer) obj).intValue());
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        mo1481f(obj, mqVar, atVar);
    }
}
