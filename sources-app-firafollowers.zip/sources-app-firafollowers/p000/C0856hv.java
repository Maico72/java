package p000;

import java.io.Serializable;
import p000.C1029kp;

/* renamed from: hv */
public abstract class C0856hv implements C0714fs, Serializable {

    /* renamed from: d */
    public final C1884us f3162d;

    public C0856hv(C0856hv hvVar) {
        this.f3162d = hvVar.f3162d;
    }

    public C0856hv(C1884us usVar) {
        this.f3162d = usVar == null ? C1884us.f6198m : usVar;
    }

    /* renamed from: b */
    public C1029kp.C1031b mo3645b(C1757st<?> stVar, Class<?> cls) {
        C0583ds e = stVar.mo5863e();
        C1887uu a = mo3644a();
        if (a == null) {
            return stVar.mo5867i(cls);
        }
        C1029kp.C1031b g = stVar.mo5865g(cls, a.mo4874d());
        if (e == null) {
            return g;
        }
        C1029kp.C1031b z = e.mo3157z(a);
        return g == null ? z : g.mo4315a(z);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        r0 = mo3644a();
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C0576dp.C0580d mo3647d(p000.C1757st<?> r2, java.lang.Class<?> r3) {
        /*
            r1 = this;
            dp$d r3 = r2.mo5866h(r3)
            ds r2 = r2.mo5863e()
            if (r2 == 0) goto L_0x0015
            uu r0 = r1.mo3644a()
            if (r0 == 0) goto L_0x0015
            dp$d r2 = r2.mo3139h(r0)
            goto L_0x0016
        L_0x0015:
            r2 = 0
        L_0x0016:
            if (r3 != 0) goto L_0x001d
            if (r2 != 0) goto L_0x001c
            dp$d r2 = p000.C0714fs.f2775c
        L_0x001c:
            return r2
        L_0x001d:
            if (r2 != 0) goto L_0x0020
            goto L_0x0024
        L_0x0020:
            dp$d r3 = r3.mo3092f(r2)
        L_0x0024:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0856hv.mo3647d(st, java.lang.Class):dp$d");
    }
}
