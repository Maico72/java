package p000;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: c3 */
public class C0327c3 {

    /* renamed from: a */
    public final Context f1429a;

    /* renamed from: b */
    public final TypedArray f1430b;

    /* renamed from: c */
    public TypedValue f1431c;

    public C0327c3(Context context, TypedArray typedArray) {
        this.f1429a = context;
        this.f1430b = typedArray;
    }

    /* renamed from: q */
    public static C0327c3 m1243q(Context context, int i, int[] iArr) {
        return new C0327c3(context, context.obtainStyledAttributes(i, iArr));
    }

    /* renamed from: r */
    public static C0327c3 m1244r(Context context, AttributeSet attributeSet, int[] iArr) {
        return new C0327c3(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    /* renamed from: s */
    public static C0327c3 m1245s(Context context, AttributeSet attributeSet, int[] iArr, int i, int i2) {
        return new C0327c3(context, context.obtainStyledAttributes(attributeSet, iArr, i, i2));
    }

    /* renamed from: a */
    public boolean mo1824a(int i, boolean z) {
        return this.f1430b.getBoolean(i, z);
    }

    /* renamed from: b */
    public int mo1825b(int i, int i2) {
        return this.f1430b.getColor(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0011, code lost:
        r0 = p000.C0001a0.m0a(r2.f1429a, (r0 = r2.f1430b.getResourceId(r3, 0)));
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.content.res.ColorStateList mo1826c(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1430b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x001a
            android.content.res.TypedArray r0 = r2.f1430b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x001a
            android.content.Context r1 = r2.f1429a
            android.content.res.ColorStateList r0 = p000.C0001a0.m0a(r1, r0)
            if (r0 == 0) goto L_0x001a
            return r0
        L_0x001a:
            android.content.res.TypedArray r0 = r2.f1430b
            android.content.res.ColorStateList r3 = r0.getColorStateList(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0327c3.mo1826c(int):android.content.res.ColorStateList");
    }

    /* renamed from: d */
    public float mo1827d(int i, float f) {
        return this.f1430b.getDimension(i, f);
    }

    /* renamed from: e */
    public int mo1828e(int i, int i2) {
        return this.f1430b.getDimensionPixelOffset(i, i2);
    }

    /* renamed from: f */
    public int mo1829f(int i, int i2) {
        return this.f1430b.getDimensionPixelSize(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r2.f1430b.getResourceId(r3, 0);
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.drawable.Drawable mo1830g(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1430b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x0018
            android.content.res.TypedArray r0 = r2.f1430b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x0018
            android.content.Context r3 = r2.f1429a
            android.graphics.drawable.Drawable r3 = p000.C0001a0.m1b(r3, r0)
            return r3
        L_0x0018:
            android.content.res.TypedArray r0 = r2.f1430b
            android.graphics.drawable.Drawable r3 = r0.getDrawable(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0327c3.mo1830g(int):android.graphics.drawable.Drawable");
    }

    /* renamed from: h */
    public Drawable mo1831h(int i) {
        int resourceId;
        Drawable g;
        if (!this.f1430b.hasValue(i) || (resourceId = this.f1430b.getResourceId(i, 0)) == 0) {
            return null;
        }
        C1391p1 a = C1391p1.m4299a();
        Context context = this.f1429a;
        synchronized (a) {
            g = a.f4726a.mo5793g(context, resourceId, true);
        }
        return g;
    }

    /* renamed from: i */
    public float mo1832i(int i, float f) {
        return this.f1430b.getFloat(i, f);
    }

    /* renamed from: j */
    public Typeface mo1833j(int i, int i2, C0329c5 c5Var) {
        String str;
        StringBuilder sb;
        int resourceId = this.f1430b.getResourceId(i, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f1431c == null) {
            this.f1431c = new TypedValue();
        }
        Context context = this.f1429a;
        TypedValue typedValue = this.f1431c;
        if (context.isRestricted()) {
            return null;
        }
        Resources resources = context.getResources();
        resources.getValue(resourceId, typedValue, true);
        CharSequence charSequence = typedValue.string;
        if (charSequence != null) {
            String charSequence2 = charSequence.toString();
            if (charSequence2.startsWith("res/")) {
                Typeface a = C0808h5.f3034b.mo1840a(C0808h5.m2601c(resources, resourceId, i2));
                if (a != null) {
                    c5Var.mo1845b(a, (Handler) null);
                    return a;
                }
                try {
                    if (charSequence2.toLowerCase().endsWith(".xml")) {
                        C2049x4 R = C1401p4.m4341R(resources.getXml(resourceId), resources);
                        if (R != null) {
                            return C0808h5.m2599a(context, R, resources, resourceId, i2, c5Var, (Handler) null, true);
                        }
                        Log.e("ResourcesCompat", "Failed to find font-family tag");
                        c5Var.mo1844a(-3, (Handler) null);
                        return null;
                    }
                    Typeface b = C0808h5.m2600b(context, resources, resourceId, charSequence2, i2);
                    if (b != null) {
                        c5Var.mo1845b(b, (Handler) null);
                    } else {
                        c5Var.mo1844a(-3, (Handler) null);
                    }
                    return b;
                } catch (XmlPullParserException e) {
                    e = e;
                    sb = new StringBuilder();
                    str = "Failed to parse xml resource ";
                    sb.append(str);
                    sb.append(charSequence2);
                    Log.e("ResourcesCompat", sb.toString(), e);
                    c5Var.mo1844a(-3, (Handler) null);
                    return null;
                } catch (IOException e2) {
                    e = e2;
                    sb = new StringBuilder();
                    str = "Failed to read xml resource ";
                    sb.append(str);
                    sb.append(charSequence2);
                    Log.e("ResourcesCompat", sb.toString(), e);
                    c5Var.mo1844a(-3, (Handler) null);
                    return null;
                }
            }
            c5Var.mo1844a(-3, (Handler) null);
            return null;
        }
        StringBuilder d = C1012kd.m3195d("Resource \"");
        d.append(resources.getResourceName(resourceId));
        d.append("\" (");
        d.append(Integer.toHexString(resourceId));
        d.append(") is not a Font: ");
        d.append(typedValue);
        throw new Resources.NotFoundException(d.toString());
    }

    /* renamed from: k */
    public int mo1834k(int i, int i2) {
        return this.f1430b.getInt(i, i2);
    }

    /* renamed from: l */
    public int mo1835l(int i, int i2) {
        return this.f1430b.getLayoutDimension(i, i2);
    }

    /* renamed from: m */
    public int mo1836m(int i, int i2) {
        return this.f1430b.getResourceId(i, i2);
    }

    /* renamed from: n */
    public String mo1837n(int i) {
        return this.f1430b.getString(i);
    }

    /* renamed from: o */
    public CharSequence mo1838o(int i) {
        return this.f1430b.getText(i);
    }

    /* renamed from: p */
    public boolean mo1839p(int i) {
        return this.f1430b.hasValue(i);
    }
}
