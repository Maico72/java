package p000;

import android.view.View;
import p000.C0010a7;

/* renamed from: b7 */
public class C0263b7 extends C0010a7.C0012b<Boolean> {
    public C0263b7(int i, Class cls, int i2) {
        super(i, cls, i2);
    }

    /* renamed from: a */
    public Object mo30a(View view) {
        return Boolean.valueOf(view.isScreenReaderFocusable());
    }
}
