package p000;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Objects;

/* renamed from: ha */
public class C0820ha extends C0741ga {

    /* renamed from: a */
    public final C1725s9 f3054a;

    /* renamed from: b */
    public final C0822b f3055b;

    /* renamed from: ha$a */
    public static class C0821a<D> extends C2057x9<D> {
        /* renamed from: d */
        public void mo840d() {
            throw null;
        }

        /* renamed from: e */
        public void mo841e() {
            throw null;
        }

        /* renamed from: f */
        public void mo842f(C2128y9<? super D> y9Var) {
            super.mo842f(y9Var);
        }

        /* renamed from: g */
        public void mo3912g(D d) {
            super.mo3912g(d);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(0);
            sb.append(" : ");
            C1401p4.m4350a((Object) null, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* renamed from: ha$b */
    public static class C0822b extends C0273ba {

        /* renamed from: c */
        public static final C0347ca f3056c = new C0823a();

        /* renamed from: b */
        public C0670f4<C0821a> f3057b = new C0670f4<>(10);

        /* renamed from: ha$b$a */
        public static class C0823a implements C0347ca {
            /* renamed from: a */
            public <T extends C0273ba> T mo3914a(Class<T> cls) {
                return new C0822b();
            }
        }

        /* renamed from: a */
        public void mo1691a() {
            if (this.f3057b.mo3492i() <= 0) {
                C0670f4<C0821a> f4Var = this.f3057b;
                int i = f4Var.f2676g;
                Object[] objArr = f4Var.f2675f;
                for (int i2 = 0; i2 < i; i2++) {
                    objArr[i2] = null;
                }
                f4Var.f2676g = 0;
                f4Var.f2673d = false;
                return;
            }
            Objects.requireNonNull(this.f3057b.mo3493j(0));
            throw null;
        }
    }

    public C0820ha(C1725s9 s9Var, C0615ea eaVar) {
        this.f3054a = s9Var;
        C0347ca caVar = C0822b.f3056c;
        Class cls = C0822b.class;
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            String k = C1012kd.m3202k("androidx.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
            C0273ba baVar = eaVar.f2513a.get(k);
            if (!cls.isInstance(baVar)) {
                baVar = caVar instanceof C0543da ? ((C0543da) caVar).mo2970a(k, cls) : ((C0822b.C0823a) caVar).mo3914a(cls);
                C0273ba put = eaVar.f2513a.put(k, baVar);
                if (put != null) {
                    put.mo1691a();
                }
            }
            this.f3055b = (C0822b) baVar;
            return;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Deprecated
    /* renamed from: a */
    public void mo3766a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        C0822b bVar = this.f3055b;
        if (bVar.f3057b.mo3492i() > 0) {
            printWriter.print(str);
            printWriter.println("Loaders:");
            String str2 = str + "    ";
            if (bVar.f3057b.mo3492i() > 0) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(bVar.f3057b.mo3489f(0));
                printWriter.print(": ");
                printWriter.println(bVar.f3057b.mo3493j(0).toString());
                printWriter.print(str2);
                printWriter.print("mId=");
                printWriter.print(0);
                printWriter.print(" mArgs=");
                printWriter.println((Object) null);
                printWriter.print(str2);
                printWriter.print("mLoader=");
                printWriter.println((Object) null);
                throw null;
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        C1401p4.m4350a(this.f3054a, sb);
        sb.append("}}");
        return sb.toString();
    }
}
