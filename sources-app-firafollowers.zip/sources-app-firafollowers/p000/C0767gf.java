package p000;

/* renamed from: gf */
public class C0767gf {

    /* renamed from: a */
    public int f2923a;

    /* renamed from: b */
    public int f2924b;

    /* renamed from: c */
    public int f2925c;

    /* renamed from: d */
    public int f2926d;

    /* renamed from: e */
    public boolean f2927e;

    /* renamed from: f */
    public boolean f2928f;

    /* renamed from: g */
    public int f2929g;

    /* renamed from: h */
    public int f2930h;

    /* renamed from: i */
    public int f2931i;

    /* renamed from: j */
    public int f2932j;

    /* renamed from: k */
    public int[] f2933k;
}
