package p000;

/* renamed from: bu */
public interface C0314bu {
}
