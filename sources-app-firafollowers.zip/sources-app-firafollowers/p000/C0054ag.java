package p000;

/* renamed from: ag */
public interface C0054ag<T, Z> {
    /* renamed from: a */
    C1675rh<Z> mo122a(T t, int i, int i2, C2150yf yfVar);

    /* renamed from: b */
    boolean mo123b(T t, C2150yf yfVar);
}
