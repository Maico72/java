package p000;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;

/* renamed from: em */
public class C0642em implements C1454pm {

    /* renamed from: a */
    public final Set<C1622qm> f2607a = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: b */
    public boolean f2608b;

    /* renamed from: c */
    public boolean f2609c;

    /* renamed from: a */
    public void mo3402a(C1622qm qmVar) {
        this.f2607a.add(qmVar);
        if (this.f2609c) {
            qmVar.mo110k();
        } else if (this.f2608b) {
            qmVar.mo109i();
        } else {
            qmVar.mo108e();
        }
    }

    /* renamed from: b */
    public void mo3403b(C1622qm qmVar) {
        this.f2607a.remove(qmVar);
    }

    /* renamed from: c */
    public void mo3404c() {
        this.f2609c = true;
        Iterator it = ((ArrayList) C1624qo.m4654e(this.f2607a)).iterator();
        while (it.hasNext()) {
            ((C1622qm) it.next()).mo110k();
        }
    }

    /* renamed from: d */
    public void mo3405d() {
        this.f2608b = true;
        Iterator it = ((ArrayList) C1624qo.m4654e(this.f2607a)).iterator();
        while (it.hasNext()) {
            ((C1622qm) it.next()).mo109i();
        }
    }

    /* renamed from: e */
    public void mo3406e() {
        this.f2608b = false;
        Iterator it = ((ArrayList) C1624qo.m4654e(this.f2607a)).iterator();
        while (it.hasNext()) {
            ((C1622qm) it.next()).mo108e();
        }
    }
}
