package p000;

import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: b */
public abstract class C0234b {

    /* renamed from: a */
    public boolean f1160a;

    /* renamed from: b */
    public CopyOnWriteArrayList<C0000a> f1161b = new CopyOnWriteArrayList<>();

    public C0234b(boolean z) {
        this.f1160a = z;
    }

    /* renamed from: a */
    public abstract void mo1490a();
}
