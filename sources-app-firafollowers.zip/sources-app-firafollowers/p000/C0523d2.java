package p000;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* renamed from: d2 */
public class C0523d2 {

    /* renamed from: a */
    public final TextView f2120a;

    /* renamed from: b */
    public C0006a3 f2121b;

    /* renamed from: c */
    public C0006a3 f2122c;

    /* renamed from: d */
    public C0006a3 f2123d;

    /* renamed from: e */
    public C0006a3 f2124e;

    /* renamed from: f */
    public C0006a3 f2125f;

    /* renamed from: g */
    public C0006a3 f2126g;

    /* renamed from: h */
    public C0006a3 f2127h;

    /* renamed from: i */
    public final C0663f2 f2128i;

    /* renamed from: j */
    public int f2129j = 0;

    /* renamed from: k */
    public int f2130k = -1;

    /* renamed from: l */
    public Typeface f2131l;

    /* renamed from: m */
    public boolean f2132m;

    /* renamed from: d2$a */
    public class C0524a extends C0329c5 {

        /* renamed from: a */
        public final /* synthetic */ int f2133a;

        /* renamed from: b */
        public final /* synthetic */ int f2134b;

        /* renamed from: c */
        public final /* synthetic */ WeakReference f2135c;

        public C0524a(int i, int i2, WeakReference weakReference) {
            this.f2133a = i;
            this.f2134b = i2;
            this.f2135c = weakReference;
        }

        /* renamed from: c */
        public void mo1846c(Typeface typeface) {
            int i;
            if (Build.VERSION.SDK_INT >= 28 && (i = this.f2133a) != -1) {
                typeface = Typeface.create(typeface, i, (this.f2134b & 2) != 0);
            }
            C0523d2 d2Var = C0523d2.this;
            WeakReference weakReference = this.f2135c;
            if (d2Var.f2132m) {
                d2Var.f2131l = typeface;
                TextView textView = (TextView) weakReference.get();
                if (textView != null) {
                    textView.setTypeface(typeface, d2Var.f2129j);
                }
            }
        }
    }

    public C0523d2(TextView textView) {
        this.f2120a = textView;
        this.f2128i = new C0663f2(textView);
    }

    /* renamed from: c */
    public static C0006a3 m1672c(Context context, C1391p1 p1Var, int i) {
        ColorStateList d = p1Var.mo5156d(context, i);
        if (d == null) {
            return null;
        }
        C0006a3 a3Var = new C0006a3();
        a3Var.f18d = true;
        a3Var.f15a = d;
        return a3Var;
    }

    /* renamed from: a */
    public final void mo2862a(Drawable drawable, C0006a3 a3Var) {
        if (drawable != null && a3Var != null) {
            C1391p1.m4302f(drawable, a3Var, this.f2120a.getDrawableState());
        }
    }

    /* renamed from: b */
    public void mo2863b() {
        if (!(this.f2121b == null && this.f2122c == null && this.f2123d == null && this.f2124e == null)) {
            Drawable[] compoundDrawables = this.f2120a.getCompoundDrawables();
            mo2862a(compoundDrawables[0], this.f2121b);
            mo2862a(compoundDrawables[1], this.f2122c);
            mo2862a(compoundDrawables[2], this.f2123d);
            mo2862a(compoundDrawables[3], this.f2124e);
        }
        if (this.f2125f != null || this.f2126g != null) {
            Drawable[] compoundDrawablesRelative = this.f2120a.getCompoundDrawablesRelative();
            mo2862a(compoundDrawablesRelative[0], this.f2125f);
            mo2862a(compoundDrawablesRelative[2], this.f2126g);
        }
    }

    /* renamed from: d */
    public boolean mo2864d() {
        C0663f2 f2Var = this.f2128i;
        return f2Var.mo3469i() && f2Var.f2645a != 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:113:0x024b  */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x025b  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0269  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x026f  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0278  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x028d  */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x02bb  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x02c5  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x02fd  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0304  */
    /* JADX WARNING: Removed duplicated region for block: B:171:0x034d  */
    /* JADX WARNING: Removed duplicated region for block: B:172:0x0354  */
    /* JADX WARNING: Removed duplicated region for block: B:175:0x035f  */
    /* JADX WARNING: Removed duplicated region for block: B:176:0x0364  */
    /* JADX WARNING: Removed duplicated region for block: B:179:0x036d  */
    /* JADX WARNING: Removed duplicated region for block: B:180:0x0372  */
    /* JADX WARNING: Removed duplicated region for block: B:183:0x037a  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x037f  */
    /* JADX WARNING: Removed duplicated region for block: B:187:0x0388  */
    /* JADX WARNING: Removed duplicated region for block: B:188:0x038d  */
    /* JADX WARNING: Removed duplicated region for block: B:191:0x0395  */
    /* JADX WARNING: Removed duplicated region for block: B:192:0x039a  */
    /* JADX WARNING: Removed duplicated region for block: B:222:0x03fd  */
    /* JADX WARNING: Removed duplicated region for block: B:224:0x0404  */
    /* JADX WARNING: Removed duplicated region for block: B:226:0x0409  */
    /* JADX WARNING: Removed duplicated region for block: B:228:0x040f  */
    /* JADX WARNING: Removed duplicated region for block: B:232:0x041d  */
    /* JADX WARNING: Removed duplicated region for block: B:247:0x0453  */
    /* JADX WARNING: Removed duplicated region for block: B:255:0x0489  */
    /* JADX WARNING: Removed duplicated region for block: B:257:0x0490  */
    /* JADX WARNING: Removed duplicated region for block: B:259:0x0497  */
    /* JADX WARNING: Removed duplicated region for block: B:262:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x010e  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x011c  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0121  */
    @android.annotation.SuppressLint({"NewApi"})
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2865e(android.util.AttributeSet r28, int r29) {
        /*
            r27 = this;
            r0 = r27
            r8 = r28
            r9 = r29
            int[] r10 = p000.C0593e.f2379i
            int[] r11 = p000.C0593e.f2393w
            int r12 = android.os.Build.VERSION.SDK_INT
            android.widget.TextView r1 = r0.f2120a
            android.content.Context r13 = r1.getContext()
            p1 r14 = p000.C1391p1.m4299a()
            int[] r3 = p000.C0593e.f2378h
            r15 = 0
            c3 r7 = p000.C0327c3.m1245s(r13, r8, r3, r9, r15)
            android.widget.TextView r1 = r0.f2120a
            android.content.Context r2 = r1.getContext()
            android.content.res.TypedArray r5 = r7.f1430b
            r16 = 0
            r4 = r28
            r6 = r29
            r15 = r7
            r7 = r16
            p000.C0010a7.m42o(r1, r2, r3, r4, r5, r6, r7)
            r7 = -1
            r1 = 0
            int r2 = r15.mo1836m(r1, r7)
            r6 = 3
            boolean r3 = r15.mo1839p(r6)
            if (r3 == 0) goto L_0x0048
            int r3 = r15.mo1836m(r6, r1)
            a3 r3 = m1672c(r13, r14, r3)
            r0.f2121b = r3
        L_0x0048:
            r5 = 1
            boolean r3 = r15.mo1839p(r5)
            if (r3 == 0) goto L_0x0059
            int r3 = r15.mo1836m(r5, r1)
            a3 r3 = m1672c(r13, r14, r3)
            r0.f2122c = r3
        L_0x0059:
            r4 = 4
            boolean r3 = r15.mo1839p(r4)
            if (r3 == 0) goto L_0x006a
            int r3 = r15.mo1836m(r4, r1)
            a3 r3 = m1672c(r13, r14, r3)
            r0.f2123d = r3
        L_0x006a:
            r3 = 2
            boolean r16 = r15.mo1839p(r3)
            if (r16 == 0) goto L_0x007b
            int r5 = r15.mo1836m(r3, r1)
            a3 r5 = m1672c(r13, r14, r5)
            r0.f2124e = r5
        L_0x007b:
            r5 = 5
            boolean r17 = r15.mo1839p(r5)
            if (r17 == 0) goto L_0x008c
            int r3 = r15.mo1836m(r5, r1)
            a3 r3 = m1672c(r13, r14, r3)
            r0.f2125f = r3
        L_0x008c:
            r3 = 6
            boolean r17 = r15.mo1839p(r3)
            if (r17 == 0) goto L_0x009d
            int r5 = r15.mo1836m(r3, r1)
            a3 r1 = m1672c(r13, r14, r5)
            r0.f2126g = r1
        L_0x009d:
            android.content.res.TypedArray r1 = r15.f1430b
            r1.recycle()
            android.widget.TextView r1 = r0.f2120a
            android.text.method.TransformationMethod r1 = r1.getTransformationMethod()
            boolean r1 = r1 instanceof android.text.method.PasswordTransformationMethod
            r5 = 23
            r15 = 14
            if (r2 == r7) goto L_0x0129
            c3 r3 = new c3
            android.content.res.TypedArray r2 = r13.obtainStyledAttributes(r2, r11)
            r3.<init>(r13, r2)
            if (r1 != 0) goto L_0x00c8
            boolean r2 = r3.mo1839p(r15)
            if (r2 == 0) goto L_0x00c8
            r2 = 0
            boolean r21 = r3.mo1824a(r15, r2)
            r2 = 1
            goto L_0x00cb
        L_0x00c8:
            r2 = 0
            r21 = 0
        L_0x00cb:
            r0.mo2872l(r13, r3)
            if (r12 >= r5) goto L_0x00f9
            boolean r22 = r3.mo1839p(r6)
            if (r22 == 0) goto L_0x00db
            android.content.res.ColorStateList r22 = r3.mo1826c(r6)
            goto L_0x00dd
        L_0x00db:
            r22 = 0
        L_0x00dd:
            boolean r23 = r3.mo1839p(r4)
            if (r23 == 0) goto L_0x00e9
            android.content.res.ColorStateList r23 = r3.mo1826c(r4)
            r7 = 5
            goto L_0x00ec
        L_0x00e9:
            r7 = 5
            r23 = 0
        L_0x00ec:
            boolean r18 = r3.mo1839p(r7)
            if (r18 == 0) goto L_0x00fd
            android.content.res.ColorStateList r24 = r3.mo1826c(r7)
            r7 = 15
            goto L_0x0101
        L_0x00f9:
            r22 = 0
            r23 = 0
        L_0x00fd:
            r7 = 15
            r24 = 0
        L_0x0101:
            boolean r19 = r3.mo1839p(r7)
            if (r19 == 0) goto L_0x010e
            java.lang.String r25 = r3.mo1837n(r7)
            r7 = 26
            goto L_0x0112
        L_0x010e:
            r7 = 26
            r25 = 0
        L_0x0112:
            if (r12 < r7) goto L_0x0121
            r7 = 13
            boolean r20 = r3.mo1839p(r7)
            if (r20 == 0) goto L_0x0121
            java.lang.String r26 = r3.mo1837n(r7)
            goto L_0x0123
        L_0x0121:
            r26 = 0
        L_0x0123:
            android.content.res.TypedArray r3 = r3.f1430b
            r3.recycle()
            goto L_0x0136
        L_0x0129:
            r2 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            r24 = 0
            r25 = 0
            r26 = 0
        L_0x0136:
            c3 r3 = new c3
            r7 = 0
            android.content.res.TypedArray r11 = r13.obtainStyledAttributes(r8, r11, r9, r7)
            r3.<init>(r13, r11)
            if (r1 != 0) goto L_0x0150
            boolean r11 = r3.mo1839p(r15)
            if (r11 == 0) goto L_0x0150
            boolean r21 = r3.mo1824a(r15, r7)
            r7 = r21
            r2 = 1
            goto L_0x0152
        L_0x0150:
            r7 = r21
        L_0x0152:
            if (r12 >= r5) goto L_0x0173
            boolean r5 = r3.mo1839p(r6)
            if (r5 == 0) goto L_0x015e
            android.content.res.ColorStateList r22 = r3.mo1826c(r6)
        L_0x015e:
            boolean r5 = r3.mo1839p(r4)
            if (r5 == 0) goto L_0x0168
            android.content.res.ColorStateList r23 = r3.mo1826c(r4)
        L_0x0168:
            r5 = 5
            boolean r11 = r3.mo1839p(r5)
            if (r11 == 0) goto L_0x0173
            android.content.res.ColorStateList r24 = r3.mo1826c(r5)
        L_0x0173:
            r11 = r22
            r4 = r23
            r5 = r24
            r6 = 15
            boolean r22 = r3.mo1839p(r6)
            if (r22 == 0) goto L_0x0185
            java.lang.String r25 = r3.mo1837n(r6)
        L_0x0185:
            r6 = r25
            r15 = 26
            if (r12 < r15) goto L_0x0198
            r15 = 13
            boolean r20 = r3.mo1839p(r15)
            if (r20 == 0) goto L_0x019a
            java.lang.String r26 = r3.mo1837n(r15)
            goto L_0x019a
        L_0x0198:
            r15 = 13
        L_0x019a:
            r22 = r14
            r15 = r26
            r14 = 28
            if (r12 < r14) goto L_0x01b6
            r14 = 0
            boolean r17 = r3.mo1839p(r14)
            if (r17 == 0) goto L_0x01b6
            r8 = -1
            int r17 = r3.mo1829f(r14, r8)
            if (r17 != 0) goto L_0x01b6
            android.widget.TextView r8 = r0.f2120a
            r9 = 0
            r8.setTextSize(r14, r9)
        L_0x01b6:
            r0.mo2872l(r13, r3)
            android.content.res.TypedArray r3 = r3.f1430b
            r3.recycle()
            if (r11 == 0) goto L_0x01c5
            android.widget.TextView r3 = r0.f2120a
            r3.setTextColor(r11)
        L_0x01c5:
            if (r4 == 0) goto L_0x01cc
            android.widget.TextView r3 = r0.f2120a
            r3.setHintTextColor(r4)
        L_0x01cc:
            if (r5 == 0) goto L_0x01d3
            android.widget.TextView r3 = r0.f2120a
            r3.setLinkTextColor(r5)
        L_0x01d3:
            if (r1 != 0) goto L_0x01dc
            if (r2 == 0) goto L_0x01dc
            android.widget.TextView r1 = r0.f2120a
            r1.setAllCaps(r7)
        L_0x01dc:
            android.graphics.Typeface r1 = r0.f2131l
            if (r1 == 0) goto L_0x01f3
            int r2 = r0.f2130k
            r7 = -1
            if (r2 != r7) goto L_0x01ed
            android.widget.TextView r2 = r0.f2120a
            int r3 = r0.f2129j
            r2.setTypeface(r1, r3)
            goto L_0x01f4
        L_0x01ed:
            android.widget.TextView r2 = r0.f2120a
            r2.setTypeface(r1)
            goto L_0x01f4
        L_0x01f3:
            r7 = -1
        L_0x01f4:
            if (r15 == 0) goto L_0x01fb
            android.widget.TextView r1 = r0.f2120a
            r1.setFontVariationSettings(r15)
        L_0x01fb:
            r8 = 24
            if (r6 == 0) goto L_0x0224
            if (r12 < r8) goto L_0x020b
            android.widget.TextView r1 = r0.f2120a
            android.os.LocaleList r2 = android.os.LocaleList.forLanguageTags(r6)
            r1.setTextLocales(r2)
            goto L_0x0224
        L_0x020b:
            r1 = 21
            if (r12 < r1) goto L_0x0224
            r1 = 44
            int r1 = r6.indexOf(r1)
            r2 = 0
            java.lang.String r1 = r6.substring(r2, r1)
            android.widget.TextView r3 = r0.f2120a
            java.util.Locale r1 = java.util.Locale.forLanguageTag(r1)
            r3.setTextLocale(r1)
            goto L_0x0225
        L_0x0224:
            r2 = 0
        L_0x0225:
            f2 r9 = r0.f2128i
            android.content.Context r1 = r9.f2654j
            r11 = r28
            r6 = r29
            android.content.res.TypedArray r14 = r1.obtainStyledAttributes(r11, r10, r6, r2)
            android.widget.TextView r1 = r9.f2653i
            android.content.Context r2 = r1.getContext()
            r15 = 0
            r4 = 6
            r5 = 0
            r8 = 2
            r3 = r10
            r8 = 4
            r4 = r28
            r8 = 5
            r5 = r14
            r7 = r15
            p000.C0010a7.m42o(r1, r2, r3, r4, r5, r6, r7)
            boolean r1 = r14.hasValue(r8)
            if (r1 == 0) goto L_0x0252
            r1 = 0
            int r2 = r14.getInt(r8, r1)
            r9.f2645a = r2
        L_0x0252:
            r1 = 4
            boolean r2 = r14.hasValue(r1)
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r2 == 0) goto L_0x0260
            float r1 = r14.getDimension(r1, r3)
            goto L_0x0262
        L_0x0260:
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x0262:
            r2 = 2
            boolean r4 = r14.hasValue(r2)
            if (r4 == 0) goto L_0x026f
            float r4 = r14.getDimension(r2, r3)
            r2 = 1
            goto L_0x0272
        L_0x026f:
            r2 = 1
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x0272:
            boolean r5 = r14.hasValue(r2)
            if (r5 == 0) goto L_0x027d
            float r5 = r14.getDimension(r2, r3)
            goto L_0x027f
        L_0x027d:
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x027f:
            r6 = 3
            boolean r7 = r14.hasValue(r6)
            if (r7 == 0) goto L_0x02bb
            r7 = 0
            int r8 = r14.getResourceId(r6, r7)
            if (r8 <= 0) goto L_0x02bb
            android.content.res.Resources r7 = r14.getResources()
            android.content.res.TypedArray r7 = r7.obtainTypedArray(r8)
            int r8 = r7.length()
            int[] r15 = new int[r8]
            if (r8 <= 0) goto L_0x02b6
            r6 = 0
        L_0x029e:
            r3 = -1
            if (r6 >= r8) goto L_0x02ac
            int r16 = r7.getDimensionPixelSize(r6, r3)
            r15[r6] = r16
            int r6 = r6 + 1
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            goto L_0x029e
        L_0x02ac:
            int[] r6 = r9.mo3464b(r15)
            r9.f2650f = r6
            r9.mo3468h()
            goto L_0x02b7
        L_0x02b6:
            r3 = -1
        L_0x02b7:
            r7.recycle()
            goto L_0x02bc
        L_0x02bb:
            r3 = -1
        L_0x02bc:
            r14.recycle()
            boolean r6 = r9.mo3469i()
            if (r6 == 0) goto L_0x02fd
            int r6 = r9.f2645a
            if (r6 != r2) goto L_0x0300
            boolean r6 = r9.f2651g
            if (r6 != 0) goto L_0x02f9
            android.content.Context r6 = r9.f2654j
            android.content.res.Resources r6 = r6.getResources()
            android.util.DisplayMetrics r6 = r6.getDisplayMetrics()
            r7 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r8 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r8 != 0) goto L_0x02e5
            r4 = 1094713344(0x41400000, float:12.0)
            r8 = 2
            float r4 = android.util.TypedValue.applyDimension(r8, r4, r6)
            goto L_0x02e6
        L_0x02e5:
            r8 = 2
        L_0x02e6:
            int r14 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r14 != 0) goto L_0x02f0
            r5 = 1121976320(0x42e00000, float:112.0)
            float r5 = android.util.TypedValue.applyDimension(r8, r5, r6)
        L_0x02f0:
            int r6 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r6 != 0) goto L_0x02f6
            r1 = 1065353216(0x3f800000, float:1.0)
        L_0x02f6:
            r9.mo3470j(r4, r5, r1)
        L_0x02f9:
            r9.mo3467g()
            goto L_0x0300
        L_0x02fd:
            r1 = 0
            r9.f2645a = r1
        L_0x0300:
            boolean r1 = p000.C1660r7.f5446a
            if (r1 == 0) goto L_0x0341
            f2 r1 = r0.f2128i
            int r4 = r1.f2645a
            if (r4 == 0) goto L_0x0341
            int[] r1 = r1.f2650f
            int r4 = r1.length
            if (r4 <= 0) goto L_0x0341
            android.widget.TextView r4 = r0.f2120a
            int r4 = r4.getAutoSizeStepGranularity()
            float r4 = (float) r4
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 == 0) goto L_0x033b
            android.widget.TextView r1 = r0.f2120a
            f2 r4 = r0.f2128i
            float r4 = r4.f2648d
            int r4 = java.lang.Math.round(r4)
            f2 r5 = r0.f2128i
            float r5 = r5.f2649e
            int r5 = java.lang.Math.round(r5)
            f2 r6 = r0.f2128i
            float r6 = r6.f2647c
            int r6 = java.lang.Math.round(r6)
            r7 = 0
            r1.setAutoSizeTextTypeUniformWithConfiguration(r4, r5, r6, r7)
            goto L_0x0341
        L_0x033b:
            r7 = 0
            android.widget.TextView r4 = r0.f2120a
            r4.setAutoSizeTextTypeUniformWithPresetSizes(r1, r7)
        L_0x0341:
            android.content.res.TypedArray r1 = r13.obtainStyledAttributes(r11, r10)
            r4 = 8
            int r4 = r1.getResourceId(r4, r3)
            if (r4 == r3) goto L_0x0354
            r5 = r22
            android.graphics.drawable.Drawable r4 = r5.mo5155b(r13, r4)
            goto L_0x0357
        L_0x0354:
            r5 = r22
            r4 = 0
        L_0x0357:
            r6 = 13
            int r6 = r1.getResourceId(r6, r3)
            if (r6 == r3) goto L_0x0364
            android.graphics.drawable.Drawable r6 = r5.mo5155b(r13, r6)
            goto L_0x0365
        L_0x0364:
            r6 = 0
        L_0x0365:
            r7 = 9
            int r7 = r1.getResourceId(r7, r3)
            if (r7 == r3) goto L_0x0372
            android.graphics.drawable.Drawable r7 = r5.mo5155b(r13, r7)
            goto L_0x0373
        L_0x0372:
            r7 = 0
        L_0x0373:
            r8 = 6
            int r8 = r1.getResourceId(r8, r3)
            if (r8 == r3) goto L_0x037f
            android.graphics.drawable.Drawable r8 = r5.mo5155b(r13, r8)
            goto L_0x0380
        L_0x037f:
            r8 = 0
        L_0x0380:
            r9 = 10
            int r9 = r1.getResourceId(r9, r3)
            if (r9 == r3) goto L_0x038d
            android.graphics.drawable.Drawable r9 = r5.mo5155b(r13, r9)
            goto L_0x038e
        L_0x038d:
            r9 = 0
        L_0x038e:
            r10 = 7
            int r10 = r1.getResourceId(r10, r3)
            if (r10 == r3) goto L_0x039a
            android.graphics.drawable.Drawable r5 = r5.mo5155b(r13, r10)
            goto L_0x039b
        L_0x039a:
            r5 = 0
        L_0x039b:
            if (r9 != 0) goto L_0x03f2
            if (r5 == 0) goto L_0x03a0
            goto L_0x03f2
        L_0x03a0:
            if (r4 != 0) goto L_0x03a8
            if (r6 != 0) goto L_0x03a8
            if (r7 != 0) goto L_0x03a8
            if (r8 == 0) goto L_0x0415
        L_0x03a8:
            android.widget.TextView r5 = r0.f2120a
            android.graphics.drawable.Drawable[] r5 = r5.getCompoundDrawablesRelative()
            r9 = 0
            r10 = r5[r9]
            if (r10 != 0) goto L_0x03db
            r10 = 2
            r11 = r5[r10]
            if (r11 == 0) goto L_0x03b9
            goto L_0x03db
        L_0x03b9:
            android.widget.TextView r5 = r0.f2120a
            android.graphics.drawable.Drawable[] r5 = r5.getCompoundDrawables()
            android.widget.TextView r10 = r0.f2120a
            if (r4 == 0) goto L_0x03c4
            goto L_0x03c6
        L_0x03c4:
            r4 = r5[r9]
        L_0x03c6:
            if (r6 == 0) goto L_0x03c9
            goto L_0x03cb
        L_0x03c9:
            r6 = r5[r2]
        L_0x03cb:
            if (r7 == 0) goto L_0x03ce
            goto L_0x03d1
        L_0x03ce:
            r2 = 2
            r7 = r5[r2]
        L_0x03d1:
            if (r8 == 0) goto L_0x03d4
            goto L_0x03d7
        L_0x03d4:
            r2 = 3
            r8 = r5[r2]
        L_0x03d7:
            r10.setCompoundDrawablesWithIntrinsicBounds(r4, r6, r7, r8)
            goto L_0x0415
        L_0x03db:
            android.widget.TextView r4 = r0.f2120a
            r7 = 0
            r9 = r5[r7]
            if (r6 == 0) goto L_0x03e3
            goto L_0x03e5
        L_0x03e3:
            r6 = r5[r2]
        L_0x03e5:
            r2 = 2
            r2 = r5[r2]
            if (r8 == 0) goto L_0x03eb
            goto L_0x03ee
        L_0x03eb:
            r7 = 3
            r8 = r5[r7]
        L_0x03ee:
            r4.setCompoundDrawablesRelativeWithIntrinsicBounds(r9, r6, r2, r8)
            goto L_0x0415
        L_0x03f2:
            android.widget.TextView r4 = r0.f2120a
            android.graphics.drawable.Drawable[] r4 = r4.getCompoundDrawablesRelative()
            android.widget.TextView r7 = r0.f2120a
            if (r9 == 0) goto L_0x03fd
            goto L_0x0401
        L_0x03fd:
            r9 = 0
            r10 = r4[r9]
            r9 = r10
        L_0x0401:
            if (r6 == 0) goto L_0x0404
            goto L_0x0406
        L_0x0404:
            r6 = r4[r2]
        L_0x0406:
            if (r5 == 0) goto L_0x0409
            goto L_0x040c
        L_0x0409:
            r2 = 2
            r5 = r4[r2]
        L_0x040c:
            if (r8 == 0) goto L_0x040f
            goto L_0x0412
        L_0x040f:
            r2 = 3
            r8 = r4[r2]
        L_0x0412:
            r7.setCompoundDrawablesRelativeWithIntrinsicBounds(r9, r6, r5, r8)
        L_0x0415:
            r2 = 11
            boolean r4 = r1.hasValue(r2)
            if (r4 == 0) goto L_0x044b
            boolean r4 = r1.hasValue(r2)
            if (r4 == 0) goto L_0x0431
            r4 = 0
            int r4 = r1.getResourceId(r2, r4)
            if (r4 == 0) goto L_0x0431
            android.content.res.ColorStateList r4 = p000.C0001a0.m0a(r13, r4)
            if (r4 == 0) goto L_0x0431
            goto L_0x0435
        L_0x0431:
            android.content.res.ColorStateList r4 = r1.getColorStateList(r2)
        L_0x0435:
            android.widget.TextView r2 = r0.f2120a
            java.util.Objects.requireNonNull(r2)
            r5 = 24
            if (r12 < r5) goto L_0x0442
            r2.setCompoundDrawableTintList(r4)
            goto L_0x044b
        L_0x0442:
            boolean r5 = r2 instanceof p000.C1905v7
            if (r5 == 0) goto L_0x044b
            v7 r2 = (p000.C1905v7) r2
            r2.setSupportCompoundDrawablesTintList(r4)
        L_0x044b:
            r2 = 12
            boolean r4 = r1.hasValue(r2)
            if (r4 == 0) goto L_0x0472
            int r2 = r1.getInt(r2, r3)
            r4 = 0
            android.graphics.PorterDuff$Mode r2 = p000.C0936j2.m2914c(r2, r4)
            android.widget.TextView r4 = r0.f2120a
            java.util.Objects.requireNonNull(r4)
            r5 = 24
            if (r12 < r5) goto L_0x0469
            r4.setCompoundDrawableTintMode(r2)
            goto L_0x0472
        L_0x0469:
            boolean r5 = r4 instanceof p000.C1905v7
            if (r5 == 0) goto L_0x0472
            v7 r4 = (p000.C1905v7) r4
            r4.setSupportCompoundDrawablesTintMode(r2)
        L_0x0472:
            r2 = 14
            int r2 = r1.getDimensionPixelSize(r2, r3)
            r4 = 17
            int r4 = r1.getDimensionPixelSize(r4, r3)
            r5 = 18
            int r5 = r1.getDimensionPixelSize(r5, r3)
            r1.recycle()
            if (r2 == r3) goto L_0x048e
            android.widget.TextView r1 = r0.f2120a
            p000.C1401p4.m4348Y(r1, r2)
        L_0x048e:
            if (r4 == r3) goto L_0x0495
            android.widget.TextView r1 = r0.f2120a
            p000.C1401p4.m4353b0(r1, r4)
        L_0x0495:
            if (r5 == r3) goto L_0x049c
            android.widget.TextView r1 = r0.f2120a
            p000.C1401p4.m4357d0(r1, r5)
        L_0x049c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0523d2.mo2865e(android.util.AttributeSet, int):void");
    }

    /* renamed from: f */
    public void mo2866f(Context context, int i) {
        String n;
        ColorStateList c;
        C0327c3 c3Var = new C0327c3(context, context.obtainStyledAttributes(i, C0593e.f2393w));
        if (c3Var.mo1839p(14)) {
            this.f2120a.setAllCaps(c3Var.mo1824a(14, false));
        }
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 23 && c3Var.mo1839p(3) && (c = c3Var.mo1826c(3)) != null) {
            this.f2120a.setTextColor(c);
        }
        if (c3Var.mo1839p(0) && c3Var.mo1829f(0, -1) == 0) {
            this.f2120a.setTextSize(0, 0.0f);
        }
        mo2872l(context, c3Var);
        if (i2 >= 26 && c3Var.mo1839p(13) && (n = c3Var.mo1837n(13)) != null) {
            this.f2120a.setFontVariationSettings(n);
        }
        c3Var.f1430b.recycle();
        Typeface typeface = this.f2131l;
        if (typeface != null) {
            this.f2120a.setTypeface(typeface, this.f2129j);
        }
    }

    /* renamed from: g */
    public void mo2867g(int i, int i2, int i3, int i4) {
        C0663f2 f2Var = this.f2128i;
        if (f2Var.mo3469i()) {
            DisplayMetrics displayMetrics = f2Var.f2654j.getResources().getDisplayMetrics();
            f2Var.mo3470j(TypedValue.applyDimension(i4, (float) i, displayMetrics), TypedValue.applyDimension(i4, (float) i2, displayMetrics), TypedValue.applyDimension(i4, (float) i3, displayMetrics));
            if (f2Var.mo3467g()) {
                f2Var.mo3463a();
            }
        }
    }

    /* renamed from: h */
    public void mo2868h(int[] iArr, int i) {
        C0663f2 f2Var = this.f2128i;
        if (f2Var.mo3469i()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = f2Var.f2654j.getResources().getDisplayMetrics();
                    for (int i2 = 0; i2 < length; i2++) {
                        iArr2[i2] = Math.round(TypedValue.applyDimension(i, (float) iArr[i2], displayMetrics));
                    }
                }
                f2Var.f2650f = f2Var.mo3464b(iArr2);
                if (!f2Var.mo3468h()) {
                    StringBuilder d = C1012kd.m3195d("None of the preset sizes is valid: ");
                    d.append(Arrays.toString(iArr));
                    throw new IllegalArgumentException(d.toString());
                }
            } else {
                f2Var.f2651g = false;
            }
            if (f2Var.mo3467g()) {
                f2Var.mo3463a();
            }
        }
    }

    /* renamed from: i */
    public void mo2869i(int i) {
        C0663f2 f2Var = this.f2128i;
        if (!f2Var.mo3469i()) {
            return;
        }
        if (i == 0) {
            f2Var.f2645a = 0;
            f2Var.f2648d = -1.0f;
            f2Var.f2649e = -1.0f;
            f2Var.f2647c = -1.0f;
            f2Var.f2650f = new int[0];
            f2Var.f2646b = false;
        } else if (i == 1) {
            DisplayMetrics displayMetrics = f2Var.f2654j.getResources().getDisplayMetrics();
            f2Var.mo3470j(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (f2Var.mo3467g()) {
                f2Var.mo3463a();
            }
        } else {
            throw new IllegalArgumentException(C1012kd.m3199h("Unknown auto-size text type: ", i));
        }
    }

    /* renamed from: j */
    public void mo2870j(ColorStateList colorStateList) {
        if (this.f2127h == null) {
            this.f2127h = new C0006a3();
        }
        C0006a3 a3Var = this.f2127h;
        a3Var.f15a = colorStateList;
        a3Var.f18d = colorStateList != null;
        this.f2121b = a3Var;
        this.f2122c = a3Var;
        this.f2123d = a3Var;
        this.f2124e = a3Var;
        this.f2125f = a3Var;
        this.f2126g = a3Var;
    }

    /* renamed from: k */
    public void mo2871k(PorterDuff.Mode mode) {
        if (this.f2127h == null) {
            this.f2127h = new C0006a3();
        }
        C0006a3 a3Var = this.f2127h;
        a3Var.f16b = mode;
        a3Var.f17c = mode != null;
        this.f2121b = a3Var;
        this.f2122c = a3Var;
        this.f2123d = a3Var;
        this.f2124e = a3Var;
        this.f2125f = a3Var;
        this.f2126g = a3Var;
    }

    /* renamed from: l */
    public final void mo2872l(Context context, C0327c3 c3Var) {
        String n;
        Typeface typeface;
        Typeface typeface2;
        int i = Build.VERSION.SDK_INT;
        this.f2129j = c3Var.mo1834k(2, this.f2129j);
        boolean z = false;
        if (i >= 28) {
            int k = c3Var.mo1834k(11, -1);
            this.f2130k = k;
            if (k != -1) {
                this.f2129j = (this.f2129j & 2) | 0;
            }
        }
        int i2 = 10;
        if (c3Var.mo1839p(10) || c3Var.mo1839p(12)) {
            this.f2131l = null;
            if (c3Var.mo1839p(12)) {
                i2 = 12;
            }
            int i3 = this.f2130k;
            int i4 = this.f2129j;
            if (!context.isRestricted()) {
                try {
                    Typeface j = c3Var.mo1833j(i2, this.f2129j, new C0524a(i3, i4, new WeakReference(this.f2120a)));
                    if (j != null) {
                        if (i >= 28 && this.f2130k != -1) {
                            j = Typeface.create(Typeface.create(j, 0), this.f2130k, (this.f2129j & 2) != 0);
                        }
                        this.f2131l = j;
                    }
                    this.f2132m = this.f2131l == null;
                } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f2131l == null && (n = c3Var.mo1837n(i2)) != null) {
                if (i < 28 || this.f2130k == -1) {
                    typeface = Typeface.create(n, this.f2129j);
                } else {
                    Typeface create = Typeface.create(n, 0);
                    int i5 = this.f2130k;
                    if ((this.f2129j & 2) != 0) {
                        z = true;
                    }
                    typeface = Typeface.create(create, i5, z);
                }
                this.f2131l = typeface;
            }
        } else if (c3Var.mo1839p(1)) {
            this.f2132m = false;
            int k2 = c3Var.mo1834k(1, 1);
            if (k2 == 1) {
                typeface2 = Typeface.SANS_SERIF;
            } else if (k2 == 2) {
                typeface2 = Typeface.SERIF;
            } else if (k2 == 3) {
                typeface2 = Typeface.MONOSPACE;
            } else {
                return;
            }
            this.f2131l = typeface2;
        }
    }
}
