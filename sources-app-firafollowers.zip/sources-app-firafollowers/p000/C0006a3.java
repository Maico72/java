package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* renamed from: a3 */
public class C0006a3 {

    /* renamed from: a */
    public ColorStateList f15a;

    /* renamed from: b */
    public PorterDuff.Mode f16b;

    /* renamed from: c */
    public boolean f17c;

    /* renamed from: d */
    public boolean f18d;
}
