package p000;

import android.content.Context;
import android.graphics.Bitmap;

/* renamed from: gk */
public abstract class C0783gk implements C0363cg<Bitmap> {
    /* renamed from: b */
    public final C1675rh<Bitmap> mo142b(Context context, C1675rh<Bitmap> rhVar, int i, int i2) {
        if (C1624qo.m4659j(i, i2)) {
            C0056ai aiVar = C1798te.m5104b(context).f5949d;
            Bitmap b = rhVar.mo1714b();
            if (i == Integer.MIN_VALUE) {
                i = b.getWidth();
            }
            if (i2 == Integer.MIN_VALUE) {
                i2 = b.getHeight();
            }
            Bitmap c = mo3816c(aiVar, b, i, i2);
            return b.equals(c) ? rhVar : C0706fk.m2298f(c, aiVar);
        }
        throw new IllegalArgumentException("Cannot apply transformation on width: " + i + " or height: " + i2 + " less than or equal to zero and not Target.SIZE_ORIGINAL");
    }

    /* renamed from: c */
    public abstract Bitmap mo3816c(C0056ai aiVar, Bitmap bitmap, int i, int i2);
}
