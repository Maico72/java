package p000;

import android.view.View;
import androidx.fragment.app.Fragment;

/* renamed from: g8 */
public class C0739g8 extends C0875i8 {

    /* renamed from: a */
    public final /* synthetic */ Fragment f2847a;

    public C0739g8(Fragment fragment) {
        this.f2847a = fragment;
    }

    /* renamed from: b */
    public View mo3761b(int i) {
        View view = this.f2847a.f647H;
        if (view != null) {
            return view.findViewById(i);
        }
        throw new IllegalStateException("Fragment " + this + " does not have a view");
    }

    /* renamed from: e */
    public boolean mo3762e() {
        return this.f2847a.f647H != null;
    }
}
