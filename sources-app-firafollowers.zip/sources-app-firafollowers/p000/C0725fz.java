package p000;

import p000.C1762sx;

@C0313bt
/* renamed from: fz */
public class C0725fz extends C0518cy<Object[]> implements C2100xw {

    /* renamed from: h */
    public final boolean f2798h;

    /* renamed from: i */
    public final C1035ks f2799i;

    /* renamed from: j */
    public final C0230aw f2800j;

    /* renamed from: k */
    public C1462ps<Object> f2801k;

    /* renamed from: l */
    public C1762sx f2802l = C1762sx.C1764b.f5795b;

    public C0725fz(C0725fz fzVar, C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, Boolean bool) {
        super(fzVar, fsVar, bool);
        this.f2799i = fzVar.f2799i;
        this.f2800j = awVar;
        this.f2798h = fzVar.f2798h;
        this.f2801k = psVar;
    }

    public C0725fz(C1035ks ksVar, boolean z, C0230aw awVar, C1462ps<Object> psVar) {
        super(Object[].class);
        this.f2799i = ksVar;
        this.f2798h = z;
        this.f2800j = awVar;
        this.f2801k = psVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003b, code lost:
        r1 = r7.f2799i;
     */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0051  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0066  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0068  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<?> mo2818a(p000.C0221at r8, p000.C0714fs r9) {
        /*
            r7 = this;
            aw r0 = r7.f2800j
            if (r0 == 0) goto L_0x0008
            aw r0 = r0.mo1474a(r9)
        L_0x0008:
            r4 = r0
            r0 = 0
            if (r9 == 0) goto L_0x0021
            uu r1 = r9.mo3644a()
            ds r2 = r8.mo1464w()
            if (r1 == 0) goto L_0x0021
            java.lang.Object r2 = r2.mo3130c(r1)
            if (r2 == 0) goto L_0x0021
            ps r1 = r8.mo1446I(r1, r2)
            goto L_0x0022
        L_0x0021:
            r1 = r0
        L_0x0022:
            java.lang.Class<T> r2 = r7.f5804d
            dp$d r2 = r7.mo5883l(r8, r9, r2)
            if (r2 == 0) goto L_0x0030
            dp$a r0 = p000.C0576dp.C0577a.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED
            java.lang.Boolean r0 = r2.mo3087b(r0)
        L_0x0030:
            r6 = r0
            if (r1 != 0) goto L_0x0035
            ps<java.lang.Object> r1 = r7.f2801k
        L_0x0035:
            ps r0 = r7.mo5882k(r8, r9, r1)
            if (r0 != 0) goto L_0x0051
            ks r1 = r7.f2799i
            if (r1 == 0) goto L_0x0051
            boolean r2 = r7.f2798h
            if (r2 == 0) goto L_0x0051
            boolean r1 = r1.mo4349z()
            if (r1 != 0) goto L_0x0051
            ks r0 = r7.f2799i
            ps r8 = r8.mo1455n(r0, r9)
            r5 = r8
            goto L_0x0052
        L_0x0051:
            r5 = r0
        L_0x0052:
            fs r8 = r7.f2108f
            if (r8 != r9) goto L_0x0068
            ps<java.lang.Object> r8 = r7.f2801k
            if (r5 != r8) goto L_0x0068
            aw r8 = r7.f2800j
            if (r8 != r4) goto L_0x0068
            java.lang.Boolean r8 = r7.f2109g
            boolean r8 = java.util.Objects.equals(r8, r6)
            if (r8 == 0) goto L_0x0068
            r8 = r7
            goto L_0x0070
        L_0x0068:
            fz r8 = new fz
            r1 = r8
            r2 = r7
            r3 = r9
            r1.<init>(r2, r3, r4, r5, r6)
        L_0x0070:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0725fz.mo2818a(at, fs):ps");
    }

    /* renamed from: d */
    public boolean mo3672d(C0221at atVar, Object obj) {
        return ((Object[]) obj).length == 0;
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        Object[] objArr = (Object[]) obj;
        int length = objArr.length;
        if (length != 1 || ((this.f2109g != null || !atVar.mo1442E(C2237zs.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) && this.f2109g != Boolean.TRUE)) {
            mqVar.mo3713H(objArr, length);
            mo2821s(objArr, mqVar, atVar);
            mqVar.mo3735m();
            return;
        }
        mo2821s(objArr, mqVar, atVar);
    }

    /* renamed from: p */
    public C2033ww<?> mo3673p(C0230aw awVar) {
        return new C0725fz(this.f2799i, this.f2798h, awVar, this.f2801k);
    }

    /* renamed from: r */
    public C1462ps<?> mo2820r(C0714fs fsVar, Boolean bool) {
        return new C0725fz(this, fsVar, this.f2800j, this.f2801k, bool);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0046, code lost:
        r7 = r11.mo1456o(r6, r8.f2108f);
     */
    /* renamed from: t */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2821s(java.lang.Object[] r9, p000.C1200mq r10, p000.C0221at r11) {
        /*
            r8 = this;
            int r0 = r9.length
            if (r0 != 0) goto L_0x0004
            return
        L_0x0004:
            ps<java.lang.Object> r1 = r8.f2801k
            r2 = 0
            r3 = 0
            if (r1 == 0) goto L_0x002a
            int r0 = r9.length
            aw r4 = r8.f2800j
            r5 = r3
        L_0x000e:
            if (r2 >= r0) goto L_0x0029
            r5 = r9[r2]     // Catch:{ Exception -> 0x0024 }
            if (r5 != 0) goto L_0x0018
            r11.mo1454m(r10)     // Catch:{ Exception -> 0x0024 }
            goto L_0x0021
        L_0x0018:
            if (r4 != 0) goto L_0x001e
            r1.mo1481f(r5, r10, r11)     // Catch:{ Exception -> 0x0024 }
            goto L_0x0021
        L_0x001e:
            r1.mo1482g(r5, r10, r11, r4)     // Catch:{ Exception -> 0x0024 }
        L_0x0021:
            int r2 = r2 + 1
            goto L_0x000e
        L_0x0024:
            r9 = move-exception
            r8.mo5885n(r11, r9, r5, r2)
            throw r3
        L_0x0029:
            return
        L_0x002a:
            aw r1 = r8.f2800j
            if (r1 == 0) goto L_0x0063
            int r0 = r9.length
            sx r4 = r8.f2802l     // Catch:{ Exception -> 0x005d }
            r5 = r3
        L_0x0032:
            if (r2 >= r0) goto L_0x005c
            r5 = r9[r2]     // Catch:{ Exception -> 0x005a }
            if (r5 != 0) goto L_0x003c
            r11.mo1454m(r10)     // Catch:{ Exception -> 0x005a }
            goto L_0x0057
        L_0x003c:
            java.lang.Class r6 = r5.getClass()     // Catch:{ Exception -> 0x005a }
            ps r7 = r4.mo5880c(r6)     // Catch:{ Exception -> 0x005a }
            if (r7 != 0) goto L_0x0054
            fs r7 = r8.f2108f     // Catch:{ Exception -> 0x005a }
            ps r7 = r11.mo1456o(r6, r7)     // Catch:{ Exception -> 0x005a }
            sx r6 = r4.mo5879b(r6, r7)     // Catch:{ Exception -> 0x005a }
            if (r4 == r6) goto L_0x0054
            r8.f2802l = r6     // Catch:{ Exception -> 0x005a }
        L_0x0054:
            r7.mo1482g(r5, r10, r11, r1)     // Catch:{ Exception -> 0x005a }
        L_0x0057:
            int r2 = r2 + 1
            goto L_0x0032
        L_0x005a:
            r9 = move-exception
            goto L_0x005f
        L_0x005c:
            return
        L_0x005d:
            r9 = move-exception
            r5 = r3
        L_0x005f:
            r8.mo5885n(r11, r9, r5, r2)
            throw r3
        L_0x0063:
            sx r1 = r8.f2802l     // Catch:{ Exception -> 0x00ae }
            r4 = r3
        L_0x0066:
            if (r2 >= r0) goto L_0x00ad
            r4 = r9[r2]     // Catch:{ Exception -> 0x00ab }
            if (r4 != 0) goto L_0x0070
            r11.mo1454m(r10)     // Catch:{ Exception -> 0x00ab }
            goto L_0x00a8
        L_0x0070:
            java.lang.Class r5 = r4.getClass()     // Catch:{ Exception -> 0x00ab }
            ps r6 = r1.mo5880c(r5)     // Catch:{ Exception -> 0x00ab }
            if (r6 != 0) goto L_0x00a5
            ks r6 = r8.f2799i     // Catch:{ Exception -> 0x00ab }
            boolean r6 = r6.mo4344r()     // Catch:{ Exception -> 0x00ab }
            if (r6 == 0) goto L_0x0097
            ks r6 = r8.f2799i     // Catch:{ Exception -> 0x00ab }
            ks r5 = r11.mo1453l(r6, r5)     // Catch:{ Exception -> 0x00ab }
            fs r6 = r8.f2108f     // Catch:{ Exception -> 0x00ab }
            sx$d r5 = r1.mo5878a(r5, r11, r6)     // Catch:{ Exception -> 0x00ab }
            sx r6 = r5.f5798b     // Catch:{ Exception -> 0x00ab }
            if (r1 == r6) goto L_0x0094
            r8.f2802l = r6     // Catch:{ Exception -> 0x00ab }
        L_0x0094:
            ps<java.lang.Object> r6 = r5.f5797a     // Catch:{ Exception -> 0x00ab }
            goto L_0x00a5
        L_0x0097:
            fs r6 = r8.f2108f     // Catch:{ Exception -> 0x00ab }
            ps r6 = r11.mo1456o(r5, r6)     // Catch:{ Exception -> 0x00ab }
            sx r5 = r1.mo5879b(r5, r6)     // Catch:{ Exception -> 0x00ab }
            if (r1 == r5) goto L_0x00a5
            r8.f2802l = r5     // Catch:{ Exception -> 0x00ab }
        L_0x00a5:
            r6.mo1481f(r4, r10, r11)     // Catch:{ Exception -> 0x00ab }
        L_0x00a8:
            int r2 = r2 + 1
            goto L_0x0066
        L_0x00ab:
            r9 = move-exception
            goto L_0x00b0
        L_0x00ad:
            return
        L_0x00ae:
            r9 = move-exception
            r4 = r3
        L_0x00b0:
            r8.mo5885n(r11, r9, r4, r2)
            goto L_0x00b5
        L_0x00b4:
            throw r3
        L_0x00b5:
            goto L_0x00b4
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0725fz.mo2821s(java.lang.Object[], mq, at):void");
    }
}
