package p000;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import java.util.Arrays;
import java.util.Objects;

/* renamed from: b8 */
public class C0264b8 {

    /* renamed from: v */
    public static final Interpolator f1263v = new C0265a();

    /* renamed from: a */
    public int f1264a;

    /* renamed from: b */
    public int f1265b;

    /* renamed from: c */
    public int f1266c = -1;

    /* renamed from: d */
    public float[] f1267d;

    /* renamed from: e */
    public float[] f1268e;

    /* renamed from: f */
    public float[] f1269f;

    /* renamed from: g */
    public float[] f1270g;

    /* renamed from: h */
    public int[] f1271h;

    /* renamed from: i */
    public int[] f1272i;

    /* renamed from: j */
    public int[] f1273j;

    /* renamed from: k */
    public int f1274k;

    /* renamed from: l */
    public VelocityTracker f1275l;

    /* renamed from: m */
    public float f1276m;

    /* renamed from: n */
    public float f1277n;

    /* renamed from: o */
    public int f1278o;

    /* renamed from: p */
    public OverScroller f1279p;

    /* renamed from: q */
    public final C0267c f1280q;

    /* renamed from: r */
    public View f1281r;

    /* renamed from: s */
    public boolean f1282s;

    /* renamed from: t */
    public final ViewGroup f1283t;

    /* renamed from: u */
    public final Runnable f1284u = new C0266b();

    /* renamed from: b8$a */
    public static class C0265a implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* renamed from: b8$b */
    public class C0266b implements Runnable {
        public C0266b() {
        }

        public void run() {
            C0264b8.this.mo1644s(0);
        }
    }

    /* renamed from: b8$c */
    public static abstract class C0267c {
        /* renamed from: a */
        public abstract int mo1651a(View view, int i, int i2);

        /* renamed from: b */
        public abstract int mo1652b(View view, int i, int i2);

        /* renamed from: c */
        public int mo1653c(View view) {
            return 0;
        }

        /* renamed from: d */
        public int mo1654d(View view) {
            return 0;
        }

        /* renamed from: e */
        public void mo1655e(View view, int i) {
        }

        /* renamed from: f */
        public abstract void mo1656f(int i);

        /* renamed from: g */
        public abstract void mo1657g(View view, int i, int i2, int i3, int i4);

        /* renamed from: h */
        public abstract void mo1658h(View view, float f, float f2);

        /* renamed from: i */
        public abstract boolean mo1659i(View view, int i);
    }

    public C0264b8(Context context, ViewGroup viewGroup, C0267c cVar) {
        if (cVar != null) {
            this.f1283t = viewGroup;
            this.f1280q = cVar;
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            this.f1278o = (int) ((context.getResources().getDisplayMetrics().density * 20.0f) + 0.5f);
            this.f1265b = viewConfiguration.getScaledTouchSlop();
            this.f1276m = (float) viewConfiguration.getScaledMaximumFlingVelocity();
            this.f1277n = (float) viewConfiguration.getScaledMinimumFlingVelocity();
            this.f1279p = new OverScroller(context, f1263v);
            return;
        }
        throw new IllegalArgumentException("Callback may not be null");
    }

    /* renamed from: a */
    public void mo1626a() {
        this.f1266c = -1;
        float[] fArr = this.f1267d;
        if (fArr != null) {
            Arrays.fill(fArr, 0.0f);
            Arrays.fill(this.f1268e, 0.0f);
            Arrays.fill(this.f1269f, 0.0f);
            Arrays.fill(this.f1270g, 0.0f);
            Arrays.fill(this.f1271h, 0);
            Arrays.fill(this.f1272i, 0);
            Arrays.fill(this.f1273j, 0);
            this.f1274k = 0;
        }
        VelocityTracker velocityTracker = this.f1275l;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f1275l = null;
        }
    }

    /* renamed from: b */
    public void mo1627b(View view, int i) {
        if (view.getParent() == this.f1283t) {
            this.f1281r = view;
            this.f1266c = i;
            this.f1280q.mo1655e(view, i);
            mo1644s(1);
            return;
        }
        StringBuilder d = C1012kd.m3195d("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
        d.append(this.f1283t);
        d.append(")");
        throw new IllegalArgumentException(d.toString());
    }

    /* renamed from: c */
    public final boolean mo1628c(float f, float f2, int i, int i2) {
        float abs = Math.abs(f);
        float abs2 = Math.abs(f2);
        if ((this.f1271h[i] & i2) != i2 || (0 & i2) == 0 || (this.f1273j[i] & i2) == i2 || (this.f1272i[i] & i2) == i2) {
            return false;
        }
        int i3 = this.f1265b;
        if (abs <= ((float) i3) && abs2 <= ((float) i3)) {
            return false;
        }
        if (abs < abs2 * 0.5f) {
            Objects.requireNonNull(this.f1280q);
        }
        return (this.f1272i[i] & i2) == 0 && abs > ((float) this.f1265b);
    }

    /* renamed from: d */
    public final boolean mo1629d(View view, float f, float f2) {
        if (view == null) {
            return false;
        }
        boolean z = this.f1280q.mo1653c(view) > 0;
        boolean z2 = this.f1280q.mo1654d(view) > 0;
        if (!z || !z2) {
            return z ? Math.abs(f) > ((float) this.f1265b) : z2 && Math.abs(f2) > ((float) this.f1265b);
        }
        float f3 = f2 * f2;
        int i = this.f1265b;
        return f3 + (f * f) > ((float) (i * i));
    }

    /* renamed from: e */
    public final float mo1630e(float f, float f2, float f3) {
        float abs = Math.abs(f);
        if (abs < f2) {
            return 0.0f;
        }
        return abs > f3 ? f > 0.0f ? f3 : -f3 : f;
    }

    /* renamed from: f */
    public final int mo1631f(int i, int i2, int i3) {
        int abs = Math.abs(i);
        if (abs < i2) {
            return 0;
        }
        return abs > i3 ? i > 0 ? i3 : -i3 : i;
    }

    /* renamed from: g */
    public final void mo1632g(int i) {
        float[] fArr = this.f1267d;
        if (fArr != null) {
            int i2 = this.f1274k;
            boolean z = true;
            int i3 = 1 << i;
            if ((i3 & i2) == 0) {
                z = false;
            }
            if (z) {
                fArr[i] = 0.0f;
                this.f1268e[i] = 0.0f;
                this.f1269f[i] = 0.0f;
                this.f1270g[i] = 0.0f;
                this.f1271h[i] = 0;
                this.f1272i[i] = 0;
                this.f1273j[i] = 0;
                this.f1274k = (i3 ^ -1) & i2;
            }
        }
    }

    /* renamed from: h */
    public final int mo1633h(int i, int i2, int i3) {
        if (i == 0) {
            return 0;
        }
        int width = this.f1283t.getWidth();
        float f = (float) (width / 2);
        float sin = (((float) Math.sin((double) ((Math.min(1.0f, ((float) Math.abs(i)) / ((float) width)) - 0.5f) * 0.47123894f))) * f) + f;
        int abs = Math.abs(i2);
        return Math.min(abs > 0 ? Math.round(Math.abs(sin / ((float) abs)) * 1000.0f) * 4 : (int) (((((float) Math.abs(i)) / ((float) i3)) + 1.0f) * 256.0f), 600);
    }

    /* renamed from: i */
    public boolean mo1634i(boolean z) {
        if (this.f1264a == 2) {
            boolean computeScrollOffset = this.f1279p.computeScrollOffset();
            int currX = this.f1279p.getCurrX();
            int currY = this.f1279p.getCurrY();
            int left = currX - this.f1281r.getLeft();
            int top = currY - this.f1281r.getTop();
            if (left != 0) {
                C0010a7.m38k(this.f1281r, left);
            }
            if (top != 0) {
                C0010a7.m39l(this.f1281r, top);
            }
            if (!(left == 0 && top == 0)) {
                this.f1280q.mo1657g(this.f1281r, currX, currY, left, top);
            }
            if (computeScrollOffset && currX == this.f1279p.getFinalX() && currY == this.f1279p.getFinalY()) {
                this.f1279p.abortAnimation();
                computeScrollOffset = false;
            }
            if (!computeScrollOffset) {
                if (z) {
                    this.f1283t.post(this.f1284u);
                } else {
                    mo1644s(0);
                }
            }
        }
        return this.f1264a == 2;
    }

    /* renamed from: j */
    public final void mo1635j(float f, float f2) {
        this.f1282s = true;
        this.f1280q.mo1658h(this.f1281r, f, f2);
        this.f1282s = false;
        if (this.f1264a == 1) {
            mo1644s(0);
        }
    }

    /* renamed from: k */
    public View mo1636k(int i, int i2) {
        for (int childCount = this.f1283t.getChildCount() - 1; childCount >= 0; childCount--) {
            ViewGroup viewGroup = this.f1283t;
            Objects.requireNonNull(this.f1280q);
            View childAt = viewGroup.getChildAt(childCount);
            if (i >= childAt.getLeft() && i < childAt.getRight() && i2 >= childAt.getTop() && i2 < childAt.getBottom()) {
                return childAt;
            }
        }
        return null;
    }

    /* renamed from: l */
    public final boolean mo1637l(int i, int i2, int i3, int i4) {
        float f;
        float f2;
        float f3;
        float f4;
        int left = this.f1281r.getLeft();
        int top = this.f1281r.getTop();
        int i5 = i - left;
        int i6 = i2 - top;
        if (i5 == 0 && i6 == 0) {
            this.f1279p.abortAnimation();
            mo1644s(0);
            return false;
        }
        View view = this.f1281r;
        int f5 = mo1631f(i3, (int) this.f1277n, (int) this.f1276m);
        int f6 = mo1631f(i4, (int) this.f1277n, (int) this.f1276m);
        int abs = Math.abs(i5);
        int abs2 = Math.abs(i6);
        int abs3 = Math.abs(f5);
        int abs4 = Math.abs(f6);
        int i7 = abs3 + abs4;
        int i8 = abs + abs2;
        if (f5 != 0) {
            f = (float) abs3;
            f2 = (float) i7;
        } else {
            f = (float) abs;
            f2 = (float) i8;
        }
        float f7 = f / f2;
        if (f6 != 0) {
            f4 = (float) abs4;
            f3 = (float) i7;
        } else {
            f4 = (float) abs2;
            f3 = (float) i8;
        }
        int h = mo1633h(i5, f5, this.f1280q.mo1653c(view));
        float h2 = ((float) mo1633h(i6, f6, this.f1280q.mo1654d(view))) * (f4 / f3);
        this.f1279p.startScroll(left, top, i5, i6, (int) (h2 + (((float) h) * f7)));
        mo1644s(2);
        return true;
    }

    /* renamed from: m */
    public final boolean mo1638m(int i) {
        if ((this.f1274k & (1 << i)) != 0) {
            return true;
        }
        Log.e("ViewDragHelper", "Ignoring pointerId=" + i + " because ACTION_DOWN was not received " + "for this pointer before ACTION_MOVE. It likely happened because " + " ViewDragHelper did not receive all the events in the event stream.");
        return false;
    }

    /* renamed from: n */
    public void mo1639n(MotionEvent motionEvent) {
        int i;
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            mo1626a();
        }
        if (this.f1275l == null) {
            this.f1275l = VelocityTracker.obtain();
        }
        this.f1275l.addMovement(motionEvent);
        int i2 = 0;
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    if (this.f1264a != 1) {
                        int pointerCount = motionEvent.getPointerCount();
                        while (i2 < pointerCount) {
                            int pointerId = motionEvent.getPointerId(i2);
                            if (mo1638m(pointerId)) {
                                float x = motionEvent.getX(i2);
                                float y = motionEvent.getY(i2);
                                float f = x - this.f1267d[pointerId];
                                float f2 = y - this.f1268e[pointerId];
                                mo1641p(f, f2, pointerId);
                                if (this.f1264a != 1) {
                                    View k = mo1636k((int) x, (int) y);
                                    if (mo1629d(k, f, f2) && mo1648w(k, pointerId)) {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                            i2++;
                        }
                    } else if (mo1638m(this.f1266c)) {
                        int findPointerIndex = motionEvent.findPointerIndex(this.f1266c);
                        float x2 = motionEvent.getX(findPointerIndex);
                        float y2 = motionEvent.getY(findPointerIndex);
                        float[] fArr = this.f1269f;
                        int i3 = this.f1266c;
                        int i4 = (int) (x2 - fArr[i3]);
                        int i5 = (int) (y2 - this.f1270g[i3]);
                        int left = this.f1281r.getLeft() + i4;
                        int top = this.f1281r.getTop() + i5;
                        int left2 = this.f1281r.getLeft();
                        int top2 = this.f1281r.getTop();
                        if (i4 != 0) {
                            left = this.f1280q.mo1651a(this.f1281r, left, i4);
                            C0010a7.m38k(this.f1281r, left - left2);
                        }
                        int i6 = left;
                        if (i5 != 0) {
                            top = this.f1280q.mo1652b(this.f1281r, top, i5);
                            C0010a7.m39l(this.f1281r, top - top2);
                        }
                        int i7 = top;
                        if (!(i4 == 0 && i5 == 0)) {
                            this.f1280q.mo1657g(this.f1281r, i6, i7, i6 - left2, i7 - top2);
                        }
                    } else {
                        return;
                    }
                    mo1643r(motionEvent);
                    return;
                } else if (actionMasked != 3) {
                    if (actionMasked == 5) {
                        int pointerId2 = motionEvent.getPointerId(actionIndex);
                        float x3 = motionEvent.getX(actionIndex);
                        float y3 = motionEvent.getY(actionIndex);
                        mo1642q(x3, y3, pointerId2);
                        if (this.f1264a == 0) {
                            mo1648w(mo1636k((int) x3, (int) y3), pointerId2);
                            if ((this.f1271h[pointerId2] & 0) == 0) {
                                return;
                            }
                        } else {
                            int i8 = (int) x3;
                            int i9 = (int) y3;
                            View view = this.f1281r;
                            if (view != null && i8 >= view.getLeft() && i8 < view.getRight() && i9 >= view.getTop() && i9 < view.getBottom()) {
                                i2 = 1;
                            }
                            if (i2 != 0) {
                                mo1648w(this.f1281r, pointerId2);
                                return;
                            }
                            return;
                        }
                    } else if (actionMasked == 6) {
                        int pointerId3 = motionEvent.getPointerId(actionIndex);
                        if (this.f1264a == 1 && pointerId3 == this.f1266c) {
                            int pointerCount2 = motionEvent.getPointerCount();
                            while (true) {
                                if (i2 >= pointerCount2) {
                                    i = -1;
                                    break;
                                }
                                int pointerId4 = motionEvent.getPointerId(i2);
                                if (pointerId4 != this.f1266c) {
                                    View k2 = mo1636k((int) motionEvent.getX(i2), (int) motionEvent.getY(i2));
                                    View view2 = this.f1281r;
                                    if (k2 == view2 && mo1648w(view2, pointerId4)) {
                                        i = this.f1266c;
                                        break;
                                    }
                                }
                                i2++;
                            }
                            if (i == -1) {
                                mo1640o();
                            }
                        }
                        mo1632g(pointerId3);
                        return;
                    } else {
                        return;
                    }
                } else if (this.f1264a == 1) {
                    mo1635j(0.0f, 0.0f);
                }
            } else if (this.f1264a == 1) {
                mo1640o();
            }
            mo1626a();
            return;
        }
        float x4 = motionEvent.getX();
        float y4 = motionEvent.getY();
        int pointerId5 = motionEvent.getPointerId(0);
        View k3 = mo1636k((int) x4, (int) y4);
        mo1642q(x4, y4, pointerId5);
        mo1648w(k3, pointerId5);
        if ((this.f1271h[pointerId5] & 0) == 0) {
            return;
        }
        Objects.requireNonNull(this.f1280q);
    }

    /* renamed from: o */
    public final void mo1640o() {
        this.f1275l.computeCurrentVelocity(1000, this.f1276m);
        mo1635j(mo1630e(this.f1275l.getXVelocity(this.f1266c), this.f1277n, this.f1276m), mo1630e(this.f1275l.getYVelocity(this.f1266c), this.f1277n, this.f1276m));
    }

    /* renamed from: p */
    public final void mo1641p(float f, float f2, int i) {
        int i2 = 1;
        if (!mo1628c(f, f2, i, 1)) {
            i2 = 0;
        }
        if (mo1628c(f2, f, i, 4)) {
            i2 |= 4;
        }
        if (mo1628c(f, f2, i, 2)) {
            i2 |= 2;
        }
        if (mo1628c(f2, f, i, 8)) {
            i2 |= 8;
        }
        if (i2 != 0) {
            int[] iArr = this.f1272i;
            iArr[i] = iArr[i] | i2;
            Objects.requireNonNull(this.f1280q);
        }
    }

    /* renamed from: q */
    public final void mo1642q(float f, float f2, int i) {
        float[] fArr = this.f1267d;
        int i2 = 0;
        if (fArr == null || fArr.length <= i) {
            int i3 = i + 1;
            float[] fArr2 = new float[i3];
            float[] fArr3 = new float[i3];
            float[] fArr4 = new float[i3];
            float[] fArr5 = new float[i3];
            int[] iArr = new int[i3];
            int[] iArr2 = new int[i3];
            int[] iArr3 = new int[i3];
            if (fArr != null) {
                System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
                float[] fArr6 = this.f1268e;
                System.arraycopy(fArr6, 0, fArr3, 0, fArr6.length);
                float[] fArr7 = this.f1269f;
                System.arraycopy(fArr7, 0, fArr4, 0, fArr7.length);
                float[] fArr8 = this.f1270g;
                System.arraycopy(fArr8, 0, fArr5, 0, fArr8.length);
                int[] iArr4 = this.f1271h;
                System.arraycopy(iArr4, 0, iArr, 0, iArr4.length);
                int[] iArr5 = this.f1272i;
                System.arraycopy(iArr5, 0, iArr2, 0, iArr5.length);
                int[] iArr6 = this.f1273j;
                System.arraycopy(iArr6, 0, iArr3, 0, iArr6.length);
            }
            this.f1267d = fArr2;
            this.f1268e = fArr3;
            this.f1269f = fArr4;
            this.f1270g = fArr5;
            this.f1271h = iArr;
            this.f1272i = iArr2;
            this.f1273j = iArr3;
        }
        float[] fArr9 = this.f1267d;
        this.f1269f[i] = f;
        fArr9[i] = f;
        float[] fArr10 = this.f1268e;
        this.f1270g[i] = f2;
        fArr10[i] = f2;
        int[] iArr7 = this.f1271h;
        int i4 = (int) f;
        int i5 = (int) f2;
        if (i4 < this.f1283t.getLeft() + this.f1278o) {
            i2 = 1;
        }
        if (i5 < this.f1283t.getTop() + this.f1278o) {
            i2 |= 4;
        }
        if (i4 > this.f1283t.getRight() - this.f1278o) {
            i2 |= 2;
        }
        if (i5 > this.f1283t.getBottom() - this.f1278o) {
            i2 |= 8;
        }
        iArr7[i] = i2;
        this.f1274k |= 1 << i;
    }

    /* renamed from: r */
    public final void mo1643r(MotionEvent motionEvent) {
        int pointerCount = motionEvent.getPointerCount();
        for (int i = 0; i < pointerCount; i++) {
            int pointerId = motionEvent.getPointerId(i);
            if (mo1638m(pointerId)) {
                float x = motionEvent.getX(i);
                float y = motionEvent.getY(i);
                this.f1269f[pointerId] = x;
                this.f1270g[pointerId] = y;
            }
        }
    }

    /* renamed from: s */
    public void mo1644s(int i) {
        this.f1283t.removeCallbacks(this.f1284u);
        if (this.f1264a != i) {
            this.f1264a = i;
            this.f1280q.mo1656f(i);
            if (this.f1264a == 0) {
                this.f1281r = null;
            }
        }
    }

    /* renamed from: t */
    public boolean mo1645t(int i, int i2) {
        if (this.f1282s) {
            return mo1637l(i, i2, (int) this.f1275l.getXVelocity(this.f1266c), (int) this.f1275l.getYVelocity(this.f1266c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00dd, code lost:
        if (r12 != r11) goto L_0x00e6;
     */
    /* renamed from: u */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1646u(android.view.MotionEvent r17) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            int r2 = r17.getActionMasked()
            int r3 = r17.getActionIndex()
            if (r2 != 0) goto L_0x0011
            r16.mo1626a()
        L_0x0011:
            android.view.VelocityTracker r4 = r0.f1275l
            if (r4 != 0) goto L_0x001b
            android.view.VelocityTracker r4 = android.view.VelocityTracker.obtain()
            r0.f1275l = r4
        L_0x001b:
            android.view.VelocityTracker r4 = r0.f1275l
            r4.addMovement(r1)
            r4 = 2
            r5 = 1
            r6 = 0
            if (r2 == 0) goto L_0x0104
            if (r2 == r5) goto L_0x00ff
            if (r2 == r4) goto L_0x006f
            r7 = 3
            if (r2 == r7) goto L_0x00ff
            r7 = 5
            if (r2 == r7) goto L_0x003d
            r4 = 6
            if (r2 == r4) goto L_0x0034
            goto L_0x0102
        L_0x0034:
            int r1 = r1.getPointerId(r3)
            r0.mo1632g(r1)
            goto L_0x0102
        L_0x003d:
            int r2 = r1.getPointerId(r3)
            float r7 = r1.getX(r3)
            float r1 = r1.getY(r3)
            r0.mo1642q(r7, r1, r2)
            int r3 = r0.f1264a
            if (r3 != 0) goto L_0x005e
            int[] r1 = r0.f1271h
            r1 = r1[r2]
            r1 = r1 & r6
            if (r1 == 0) goto L_0x0102
            b8$c r1 = r0.f1280q
            java.util.Objects.requireNonNull(r1)
            goto L_0x0102
        L_0x005e:
            if (r3 != r4) goto L_0x0102
            int r3 = (int) r7
            int r1 = (int) r1
            android.view.View r1 = r0.mo1636k(r3, r1)
            android.view.View r3 = r0.f1281r
            if (r1 != r3) goto L_0x0102
            r0.mo1648w(r1, r2)
            goto L_0x0102
        L_0x006f:
            float[] r2 = r0.f1267d
            if (r2 == 0) goto L_0x0102
            float[] r2 = r0.f1268e
            if (r2 != 0) goto L_0x0079
            goto L_0x0102
        L_0x0079:
            int r2 = r17.getPointerCount()
            r3 = 0
        L_0x007e:
            if (r3 >= r2) goto L_0x00fb
            int r4 = r1.getPointerId(r3)
            boolean r7 = r0.mo1638m(r4)
            if (r7 != 0) goto L_0x008c
            goto L_0x00f7
        L_0x008c:
            float r7 = r1.getX(r3)
            float r8 = r1.getY(r3)
            float[] r9 = r0.f1267d
            r9 = r9[r4]
            float r9 = r7 - r9
            float[] r10 = r0.f1268e
            r10 = r10[r4]
            float r10 = r8 - r10
            int r7 = (int) r7
            int r8 = (int) r8
            android.view.View r7 = r0.mo1636k(r7, r8)
            if (r7 == 0) goto L_0x00b0
            boolean r8 = r0.mo1629d(r7, r9, r10)
            if (r8 == 0) goto L_0x00b0
            r8 = 1
            goto L_0x00b1
        L_0x00b0:
            r8 = 0
        L_0x00b1:
            if (r8 == 0) goto L_0x00e6
            int r11 = r7.getLeft()
            int r12 = (int) r9
            int r13 = r11 + r12
            b8$c r14 = r0.f1280q
            int r12 = r14.mo1651a(r7, r13, r12)
            int r13 = r7.getTop()
            int r14 = (int) r10
            int r15 = r13 + r14
            b8$c r6 = r0.f1280q
            int r6 = r6.mo1652b(r7, r15, r14)
            b8$c r14 = r0.f1280q
            int r14 = r14.mo1653c(r7)
            b8$c r15 = r0.f1280q
            int r15 = r15.mo1654d(r7)
            if (r14 == 0) goto L_0x00df
            if (r14 <= 0) goto L_0x00e6
            if (r12 != r11) goto L_0x00e6
        L_0x00df:
            if (r15 == 0) goto L_0x00fb
            if (r15 <= 0) goto L_0x00e6
            if (r6 != r13) goto L_0x00e6
            goto L_0x00fb
        L_0x00e6:
            r0.mo1641p(r9, r10, r4)
            int r6 = r0.f1264a
            if (r6 != r5) goto L_0x00ee
            goto L_0x00fb
        L_0x00ee:
            if (r8 == 0) goto L_0x00f7
            boolean r4 = r0.mo1648w(r7, r4)
            if (r4 == 0) goto L_0x00f7
            goto L_0x00fb
        L_0x00f7:
            int r3 = r3 + 1
            r6 = 0
            goto L_0x007e
        L_0x00fb:
            r16.mo1643r(r17)
            goto L_0x0102
        L_0x00ff:
            r16.mo1626a()
        L_0x0102:
            r2 = 0
            goto L_0x0132
        L_0x0104:
            float r2 = r17.getX()
            float r3 = r17.getY()
            r6 = 0
            int r1 = r1.getPointerId(r6)
            r0.mo1642q(r2, r3, r1)
            int r2 = (int) r2
            int r3 = (int) r3
            android.view.View r2 = r0.mo1636k(r2, r3)
            android.view.View r3 = r0.f1281r
            if (r2 != r3) goto L_0x0125
            int r3 = r0.f1264a
            if (r3 != r4) goto L_0x0125
            r0.mo1648w(r2, r1)
        L_0x0125:
            int[] r2 = r0.f1271h
            r1 = r2[r1]
            r2 = 0
            r1 = r1 & r2
            if (r1 == 0) goto L_0x0132
            b8$c r1 = r0.f1280q
            java.util.Objects.requireNonNull(r1)
        L_0x0132:
            int r1 = r0.f1264a
            if (r1 != r5) goto L_0x0137
            goto L_0x0138
        L_0x0137:
            r5 = 0
        L_0x0138:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0264b8.mo1646u(android.view.MotionEvent):boolean");
    }

    /* renamed from: v */
    public boolean mo1647v(View view, int i, int i2) {
        this.f1281r = view;
        this.f1266c = -1;
        boolean l = mo1637l(i, i2, 0, 0);
        if (!l && this.f1264a == 0 && this.f1281r != null) {
            this.f1281r = null;
        }
        return l;
    }

    /* renamed from: w */
    public boolean mo1648w(View view, int i) {
        if (view == this.f1281r && this.f1266c == i) {
            return true;
        }
        if (view == null || !this.f1280q.mo1659i(view, i)) {
            return false;
        }
        this.f1266c = i;
        mo1627b(view, i);
        return true;
    }
}
