package p000;

import java.io.Serializable;

/* renamed from: gr */
public class C0791gr implements C1882uq, Serializable {

    /* renamed from: f */
    public static final C0509cr f2985f = C0509cr.f2098b;

    /* renamed from: d */
    public final String f2986d;

    /* renamed from: e */
    public char[] f2987e;

    public C0791gr(String str) {
        if (str != null) {
            this.f2986d = str;
            return;
        }
        throw new IllegalStateException("Null String illegal for SerializedString");
    }

    /* renamed from: a */
    public final char[] mo3820a() {
        char[] cArr = this.f2987e;
        if (cArr != null) {
            return cArr;
        }
        char[] a = f2985f.mo2796a(this.f2986d);
        this.f2987e = a;
        return a;
    }

    /* renamed from: b */
    public int mo3821b(char[] cArr, int i) {
        char[] cArr2 = this.f2987e;
        if (cArr2 == null) {
            cArr2 = f2985f.mo2796a(this.f2986d);
            this.f2987e = cArr2;
        }
        int length = cArr2.length;
        if (i + length > cArr.length) {
            return -1;
        }
        System.arraycopy(cArr2, 0, cArr, i, length);
        return length;
    }

    /* renamed from: c */
    public int mo3822c(char[] cArr, int i) {
        String str = this.f2986d;
        int length = str.length();
        if (i + length > cArr.length) {
            return -1;
        }
        str.getChars(0, length, cArr, i);
        return length;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != C0791gr.class) {
            return false;
        }
        return this.f2986d.equals(((C0791gr) obj).f2986d);
    }

    public final String getValue() {
        return this.f2986d;
    }

    public final int hashCode() {
        return this.f2986d.hashCode();
    }

    public final String toString() {
        return this.f2986d;
    }
}
