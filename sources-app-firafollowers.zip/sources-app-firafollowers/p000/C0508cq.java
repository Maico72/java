package p000;

/* renamed from: cq */
public enum C0508cq {
    SET,
    SKIP,
    FAIL,
    AS_EMPTY,
    DEFAULT
}
