package p000;

/* renamed from: cc */
public class C0350cc {
}
