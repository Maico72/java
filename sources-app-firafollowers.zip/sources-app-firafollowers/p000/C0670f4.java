package p000;

/* renamed from: f4 */
public class C0670f4<E> implements Cloneable {

    /* renamed from: h */
    public static final Object f2672h = new Object();

    /* renamed from: d */
    public boolean f2673d;

    /* renamed from: e */
    public int[] f2674e;

    /* renamed from: f */
    public Object[] f2675f;

    /* renamed from: g */
    public int f2676g;

    public C0670f4() {
        this(10);
    }

    public C0670f4(int i) {
        this.f2673d = false;
        if (i == 0) {
            this.f2674e = C0007a4.f19a;
            this.f2675f = C0007a4.f21c;
            return;
        }
        int e = C0007a4.m21e(i);
        this.f2674e = new int[e];
        this.f2675f = new Object[e];
    }

    /* renamed from: a */
    public void mo3483a(int i, E e) {
        int i2 = this.f2676g;
        if (i2 == 0 || i > this.f2674e[i2 - 1]) {
            if (this.f2673d && i2 >= this.f2674e.length) {
                mo3485c();
            }
            int i3 = this.f2676g;
            if (i3 >= this.f2674e.length) {
                int e2 = C0007a4.m21e(i3 + 1);
                int[] iArr = new int[e2];
                Object[] objArr = new Object[e2];
                int[] iArr2 = this.f2674e;
                System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
                Object[] objArr2 = this.f2675f;
                System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
                this.f2674e = iArr;
                this.f2675f = objArr;
            }
            this.f2674e[i3] = i;
            this.f2675f[i3] = e;
            this.f2676g = i3 + 1;
            return;
        }
        mo3490g(i, e);
    }

    /* renamed from: b */
    public C0670f4<E> clone() {
        try {
            C0670f4<E> f4Var = (C0670f4) super.clone();
            f4Var.f2674e = (int[]) this.f2674e.clone();
            f4Var.f2675f = (Object[]) this.f2675f.clone();
            return f4Var;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    /* renamed from: c */
    public final void mo3485c() {
        int i = this.f2676g;
        int[] iArr = this.f2674e;
        Object[] objArr = this.f2675f;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f2672h) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f2673d = false;
        this.f2676g = i2;
    }

    /* renamed from: d */
    public E mo3487d(int i) {
        return mo3488e(i, (Object) null);
    }

    /* renamed from: e */
    public E mo3488e(int i, E e) {
        int a = C0007a4.m17a(this.f2674e, this.f2676g, i);
        if (a >= 0) {
            E[] eArr = this.f2675f;
            if (eArr[a] != f2672h) {
                return eArr[a];
            }
        }
        return e;
    }

    /* renamed from: f */
    public int mo3489f(int i) {
        if (this.f2673d) {
            mo3485c();
        }
        return this.f2674e[i];
    }

    /* renamed from: g */
    public void mo3490g(int i, E e) {
        int a = C0007a4.m17a(this.f2674e, this.f2676g, i);
        if (a >= 0) {
            this.f2675f[a] = e;
            return;
        }
        int i2 = a ^ -1;
        int i3 = this.f2676g;
        if (i2 < i3) {
            Object[] objArr = this.f2675f;
            if (objArr[i2] == f2672h) {
                this.f2674e[i2] = i;
                objArr[i2] = e;
                return;
            }
        }
        if (this.f2673d && i3 >= this.f2674e.length) {
            mo3485c();
            i2 = C0007a4.m17a(this.f2674e, this.f2676g, i) ^ -1;
        }
        int i4 = this.f2676g;
        if (i4 >= this.f2674e.length) {
            int e2 = C0007a4.m21e(i4 + 1);
            int[] iArr = new int[e2];
            Object[] objArr2 = new Object[e2];
            int[] iArr2 = this.f2674e;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr3 = this.f2675f;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f2674e = iArr;
            this.f2675f = objArr2;
        }
        int i5 = this.f2676g;
        if (i5 - i2 != 0) {
            int[] iArr3 = this.f2674e;
            int i6 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i6, i5 - i2);
            Object[] objArr4 = this.f2675f;
            System.arraycopy(objArr4, i2, objArr4, i6, this.f2676g - i2);
        }
        this.f2674e[i2] = i;
        this.f2675f[i2] = e;
        this.f2676g++;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        r0 = r3.f2675f;
     */
    /* renamed from: h */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3491h(int r4) {
        /*
            r3 = this;
            int[] r0 = r3.f2674e
            int r1 = r3.f2676g
            int r4 = p000.C0007a4.m17a(r0, r1, r4)
            if (r4 < 0) goto L_0x0017
            java.lang.Object[] r0 = r3.f2675f
            r1 = r0[r4]
            java.lang.Object r2 = f2672h
            if (r1 == r2) goto L_0x0017
            r0[r4] = r2
            r4 = 1
            r3.f2673d = r4
        L_0x0017:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0670f4.mo3491h(int):void");
    }

    /* renamed from: i */
    public int mo3492i() {
        if (this.f2673d) {
            mo3485c();
        }
        return this.f2676g;
    }

    /* renamed from: j */
    public E mo3493j(int i) {
        if (this.f2673d) {
            mo3485c();
        }
        return this.f2675f[i];
    }

    public String toString() {
        if (mo3492i() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f2676g * 28);
        sb.append('{');
        for (int i = 0; i < this.f2676g; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(mo3489f(i));
            sb.append('=');
            Object j = mo3493j(i);
            if (j != this) {
                sb.append(j);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
