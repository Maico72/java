package p000;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import java.util.Objects;

/* renamed from: f6 */
public class C0673f6 implements Spannable {

    /* renamed from: f6$a */
    public static final class C0674a {

        /* renamed from: a */
        public final TextPaint f2690a;

        /* renamed from: b */
        public final TextDirectionHeuristic f2691b;

        /* renamed from: c */
        public final int f2692c;

        /* renamed from: d */
        public final int f2693d;

        public C0674a(PrecomputedText.Params params) {
            this.f2690a = params.getTextPaint();
            this.f2691b = params.getTextDirection();
            this.f2692c = params.getBreakStrategy();
            this.f2693d = params.getHyphenationFrequency();
            int i = Build.VERSION.SDK_INT;
        }

        @SuppressLint({"NewApi"})
        public C0674a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i, int i2) {
            if (Build.VERSION.SDK_INT >= 29) {
                new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i).setHyphenationFrequency(i2).setTextDirection(textDirectionHeuristic).build();
            }
            this.f2690a = textPaint;
            this.f2691b = textDirectionHeuristic;
            this.f2692c = i;
            this.f2693d = i2;
        }

        /* renamed from: a */
        public boolean mo3513a(C0674a aVar) {
            int i = Build.VERSION.SDK_INT;
            if ((i >= 23 && (this.f2692c != aVar.f2692c || this.f2693d != aVar.f2693d)) || this.f2690a.getTextSize() != aVar.f2690a.getTextSize() || this.f2690a.getTextScaleX() != aVar.f2690a.getTextScaleX() || this.f2690a.getTextSkewX() != aVar.f2690a.getTextSkewX()) {
                return false;
            }
            if ((i >= 21 && (this.f2690a.getLetterSpacing() != aVar.f2690a.getLetterSpacing() || !TextUtils.equals(this.f2690a.getFontFeatureSettings(), aVar.f2690a.getFontFeatureSettings()))) || this.f2690a.getFlags() != aVar.f2690a.getFlags()) {
                return false;
            }
            if (i >= 24) {
                if (!this.f2690a.getTextLocales().equals(aVar.f2690a.getTextLocales())) {
                    return false;
                }
            } else if (!this.f2690a.getTextLocale().equals(aVar.f2690a.getTextLocale())) {
                return false;
            }
            if (this.f2690a.getTypeface() == null) {
                if (aVar.f2690a.getTypeface() != null) {
                    return false;
                }
                return true;
            } else if (!this.f2690a.getTypeface().equals(aVar.f2690a.getTypeface())) {
                return false;
            } else {
                return true;
            }
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0674a)) {
                return false;
            }
            C0674a aVar = (C0674a) obj;
            return mo3513a(aVar) && this.f2691b == aVar.f2691b;
        }

        public int hashCode() {
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                return Objects.hash(new Object[]{Float.valueOf(this.f2690a.getTextSize()), Float.valueOf(this.f2690a.getTextScaleX()), Float.valueOf(this.f2690a.getTextSkewX()), Float.valueOf(this.f2690a.getLetterSpacing()), Integer.valueOf(this.f2690a.getFlags()), this.f2690a.getTextLocales(), this.f2690a.getTypeface(), Boolean.valueOf(this.f2690a.isElegantTextHeight()), this.f2691b, Integer.valueOf(this.f2692c), Integer.valueOf(this.f2693d)});
            } else if (i >= 21) {
                return Objects.hash(new Object[]{Float.valueOf(this.f2690a.getTextSize()), Float.valueOf(this.f2690a.getTextScaleX()), Float.valueOf(this.f2690a.getTextSkewX()), Float.valueOf(this.f2690a.getLetterSpacing()), Integer.valueOf(this.f2690a.getFlags()), this.f2690a.getTextLocale(), this.f2690a.getTypeface(), Boolean.valueOf(this.f2690a.isElegantTextHeight()), this.f2691b, Integer.valueOf(this.f2692c), Integer.valueOf(this.f2693d)});
            } else {
                return Objects.hash(new Object[]{Float.valueOf(this.f2690a.getTextSize()), Float.valueOf(this.f2690a.getTextScaleX()), Float.valueOf(this.f2690a.getTextSkewX()), Integer.valueOf(this.f2690a.getFlags()), this.f2690a.getTextLocale(), this.f2690a.getTypeface(), this.f2691b, Integer.valueOf(this.f2692c), Integer.valueOf(this.f2693d)});
            }
        }

        public String toString() {
            Object obj;
            StringBuilder sb;
            StringBuilder sb2 = new StringBuilder("{");
            StringBuilder d = C1012kd.m3195d("textSize=");
            d.append(this.f2690a.getTextSize());
            sb2.append(d.toString());
            sb2.append(", textScaleX=" + this.f2690a.getTextScaleX());
            sb2.append(", textSkewX=" + this.f2690a.getTextSkewX());
            int i = Build.VERSION.SDK_INT;
            if (i >= 21) {
                StringBuilder d2 = C1012kd.m3195d(", letterSpacing=");
                d2.append(this.f2690a.getLetterSpacing());
                sb2.append(d2.toString());
                sb2.append(", elegantTextHeight=" + this.f2690a.isElegantTextHeight());
            }
            if (i >= 24) {
                sb = C1012kd.m3195d(", textLocale=");
                obj = this.f2690a.getTextLocales();
            } else {
                sb = C1012kd.m3195d(", textLocale=");
                obj = this.f2690a.getTextLocale();
            }
            sb.append(obj);
            sb2.append(sb.toString());
            StringBuilder d3 = C1012kd.m3195d(", typeface=");
            d3.append(this.f2690a.getTypeface());
            sb2.append(d3.toString());
            if (i >= 26) {
                StringBuilder d4 = C1012kd.m3195d(", variationSettings=");
                d4.append(this.f2690a.getFontVariationSettings());
                sb2.append(d4.toString());
            }
            StringBuilder d5 = C1012kd.m3195d(", textDir=");
            d5.append(this.f2691b);
            sb2.append(d5.toString());
            sb2.append(", breakStrategy=" + this.f2692c);
            sb2.append(", hyphenationFrequency=" + this.f2693d);
            sb2.append("}");
            return sb2.toString();
        }
    }

    public char charAt(int i) {
        throw null;
    }

    public int getSpanEnd(Object obj) {
        throw null;
    }

    public int getSpanFlags(Object obj) {
        throw null;
    }

    public int getSpanStart(Object obj) {
        throw null;
    }

    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i, int i2, Class<T> cls) {
        int i3 = Build.VERSION.SDK_INT;
        throw null;
    }

    public int length() {
        throw null;
    }

    public int nextSpanTransition(int i, int i2, Class cls) {
        throw null;
    }

    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (!(obj instanceof MetricAffectingSpan)) {
            int i = Build.VERSION.SDK_INT;
            throw null;
        }
        throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
    }

    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i, int i2, int i3) {
        if (!(obj instanceof MetricAffectingSpan)) {
            int i4 = Build.VERSION.SDK_INT;
            throw null;
        }
        throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
    }

    public CharSequence subSequence(int i, int i2) {
        throw null;
    }

    public String toString() {
        throw null;
    }
}
