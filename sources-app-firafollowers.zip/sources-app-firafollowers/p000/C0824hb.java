package p000;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import p000.C1321oa;

/* renamed from: hb */
public class C0824hb implements C1321oa.C1322a {

    /* renamed from: a */
    public final /* synthetic */ RecyclerView f3058a;

    public C0824hb(RecyclerView recyclerView) {
        this.f3058a = recyclerView;
    }

    /* renamed from: a */
    public void mo3918a(C1321oa.C1323b bVar) {
        int i = bVar.f4488a;
        if (i == 1) {
            RecyclerView recyclerView = this.f3058a;
            recyclerView.f826p.mo873r0(recyclerView, bVar.f4489b, bVar.f4491d);
        } else if (i == 2) {
            RecyclerView recyclerView2 = this.f3058a;
            recyclerView2.f826p.mo878u0(recyclerView2, bVar.f4489b, bVar.f4491d);
        } else if (i == 4) {
            RecyclerView recyclerView3 = this.f3058a;
            recyclerView3.f826p.mo882w0(recyclerView3, bVar.f4489b, bVar.f4491d, bVar.f4490c);
        } else if (i == 8) {
            RecyclerView recyclerView4 = this.f3058a;
            recyclerView4.f826p.mo875t0(recyclerView4, bVar.f4489b, bVar.f4491d, 1);
        }
    }

    /* renamed from: b */
    public RecyclerView.C0181z mo3919b(int i) {
        RecyclerView recyclerView = this.f3058a;
        int h = recyclerView.f810h.mo5209h();
        int i2 = 0;
        RecyclerView.C0181z zVar = null;
        while (true) {
            if (i2 >= h) {
                break;
            }
            RecyclerView.C0181z K = RecyclerView.m512K(recyclerView.f810h.mo5208g(i2));
            if (K != null && !K.mo1217l() && K.f930c == i) {
                if (!recyclerView.f810h.mo5212k(K.f928a)) {
                    zVar = K;
                    break;
                }
                zVar = K;
            }
            i2++;
        }
        if (zVar != null && !this.f3058a.f810h.mo5212k(zVar.f928a)) {
            return zVar;
        }
        return null;
    }

    /* renamed from: c */
    public void mo3920c(int i, int i2, Object obj) {
        int i3;
        int i4;
        RecyclerView recyclerView = this.f3058a;
        int h = recyclerView.f810h.mo5209h();
        int i5 = i2 + i;
        for (int i6 = 0; i6 < h; i6++) {
            View g = recyclerView.f810h.mo5208g(i6);
            RecyclerView.C0181z K = RecyclerView.m512K(g);
            if (K != null && !K.mo1225t() && (i4 = K.f930c) >= i && i4 < i5) {
                K.mo1207b(2);
                K.mo1206a(obj);
                ((RecyclerView.C0167n) g.getLayoutParams()).f889f = true;
            }
        }
        RecyclerView.C0173s sVar = recyclerView.f804e;
        int size = sVar.f899c.size();
        while (true) {
            size--;
            if (size >= 0) {
                RecyclerView.C0181z zVar = sVar.f899c.get(size);
                if (zVar != null && (i3 = zVar.f930c) >= i && i3 < i5) {
                    zVar.mo1207b(2);
                    sVar.mo1189h(size);
                }
            } else {
                this.f3058a.f821m0 = true;
                return;
            }
        }
    }

    /* renamed from: d */
    public void mo3921d(int i, int i2) {
        RecyclerView recyclerView = this.f3058a;
        int h = recyclerView.f810h.mo5209h();
        for (int i3 = 0; i3 < h; i3++) {
            RecyclerView.C0181z K = RecyclerView.m512K(recyclerView.f810h.mo5208g(i3));
            if (K != null && !K.mo1225t() && K.f930c >= i) {
                K.mo1221p(i2, false);
                recyclerView.f813i0.f911e = true;
            }
        }
        RecyclerView.C0173s sVar = recyclerView.f804e;
        int size = sVar.f899c.size();
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView.C0181z zVar = sVar.f899c.get(i4);
            if (zVar != null && zVar.f930c >= i) {
                zVar.mo1221p(i2, true);
            }
        }
        recyclerView.requestLayout();
        this.f3058a.f819l0 = true;
    }

    /* renamed from: e */
    public void mo3922e(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        RecyclerView recyclerView = this.f3058a;
        int h = recyclerView.f810h.mo5209h();
        int i10 = -1;
        if (i < i2) {
            i5 = i;
            i4 = i2;
            i3 = -1;
        } else {
            i4 = i;
            i5 = i2;
            i3 = 1;
        }
        for (int i11 = 0; i11 < h; i11++) {
            RecyclerView.C0181z K = RecyclerView.m512K(recyclerView.f810h.mo5208g(i11));
            if (K != null && (i9 = K.f930c) >= i5 && i9 <= i4) {
                if (i9 == i) {
                    K.mo1221p(i2 - i, false);
                } else {
                    K.mo1221p(i3, false);
                }
                recyclerView.f813i0.f911e = true;
            }
        }
        RecyclerView.C0173s sVar = recyclerView.f804e;
        if (i < i2) {
            i7 = i;
            i6 = i2;
        } else {
            i6 = i;
            i7 = i2;
            i10 = 1;
        }
        int size = sVar.f899c.size();
        for (int i12 = 0; i12 < size; i12++) {
            RecyclerView.C0181z zVar = sVar.f899c.get(i12);
            if (zVar != null && (i8 = zVar.f930c) >= i7 && i8 <= i6) {
                if (i8 == i) {
                    zVar.mo1221p(i2 - i, false);
                } else {
                    zVar.mo1221p(i10, false);
                }
            }
        }
        recyclerView.requestLayout();
        this.f3058a.f819l0 = true;
    }
}
