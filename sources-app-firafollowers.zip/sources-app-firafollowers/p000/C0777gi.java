package p000;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/* renamed from: gi */
public class C0777gi implements C0056ai {

    /* renamed from: j */
    public static final Bitmap.Config f2961j = Bitmap.Config.ARGB_8888;

    /* renamed from: a */
    public final C0841hi f2962a;

    /* renamed from: b */
    public final Set<Bitmap.Config> f2963b;

    /* renamed from: c */
    public final C0778a f2964c;

    /* renamed from: d */
    public long f2965d;

    /* renamed from: e */
    public long f2966e;

    /* renamed from: f */
    public int f2967f;

    /* renamed from: g */
    public int f2968g;

    /* renamed from: h */
    public int f2969h;

    /* renamed from: i */
    public int f2970i;

    /* renamed from: gi$a */
    public interface C0778a {
    }

    /* renamed from: gi$b */
    public static final class C0779b implements C0778a {
    }

    public C0777gi(long j) {
        C0965ji jiVar = new C0965ji();
        HashSet hashSet = new HashSet(Arrays.asList(Bitmap.Config.values()));
        int i = Build.VERSION.SDK_INT;
        hashSet.add((Object) null);
        if (i >= 26) {
            hashSet.remove(Bitmap.Config.HARDWARE);
        }
        Set<Bitmap.Config> unmodifiableSet = Collections.unmodifiableSet(hashSet);
        this.f2965d = j;
        this.f2962a = jiVar;
        this.f2963b = unmodifiableSet;
        this.f2964c = new C0779b();
    }

    @SuppressLint({"InlinedApi"})
    /* renamed from: a */
    public void mo127a(int i) {
        if (Log.isLoggable("LruBitmapPool", 3)) {
            Log.d("LruBitmapPool", "trimMemory, level=" + i);
        }
        if (i >= 40 || (Build.VERSION.SDK_INT >= 23 && i >= 20)) {
            if (Log.isLoggable("LruBitmapPool", 3)) {
                Log.d("LruBitmapPool", "clearMemory");
            }
            mo3815i(0);
        } else if (i >= 20 || i == 15) {
            mo3815i(this.f2965d / 2);
        }
    }

    /* renamed from: b */
    public void mo128b() {
        if (Log.isLoggable("LruBitmapPool", 3)) {
            Log.d("LruBitmapPool", "clearMemory");
        }
        mo3815i(0);
    }

    /* renamed from: c */
    public Bitmap mo129c(int i, int i2, Bitmap.Config config) {
        Bitmap h = mo3814h(i, i2, config);
        if (h != null) {
            return h;
        }
        if (config == null) {
            config = f2961j;
        }
        return Bitmap.createBitmap(i, i2, config);
    }

    /* renamed from: d */
    public Bitmap mo130d(int i, int i2, Bitmap.Config config) {
        Bitmap h = mo3814h(i, i2, config);
        if (h != null) {
            h.eraseColor(0);
            return h;
        }
        if (config == null) {
            config = f2961j;
        }
        return Bitmap.createBitmap(i, i2, config);
    }

    /* renamed from: e */
    public synchronized void mo131e(Bitmap bitmap) {
        if (bitmap != null) {
            try {
                if (!bitmap.isRecycled()) {
                    if (bitmap.isMutable()) {
                        Objects.requireNonNull((C0965ji) this.f2962a);
                        if (((long) C1624qo.m4653d(bitmap)) <= this.f2965d) {
                            if (this.f2963b.contains(bitmap.getConfig())) {
                                Objects.requireNonNull((C0965ji) this.f2962a);
                                int d = C1624qo.m4653d(bitmap);
                                ((C0965ji) this.f2962a).mo4174f(bitmap);
                                Objects.requireNonNull((C0779b) this.f2964c);
                                this.f2969h++;
                                this.f2966e += (long) d;
                                if (Log.isLoggable("LruBitmapPool", 2)) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append("Put bitmap in pool=");
                                    sb.append(((C0965ji) this.f2962a).mo4173e(bitmap));
                                    Log.v("LruBitmapPool", sb.toString());
                                }
                                mo3812f();
                                mo3815i(this.f2965d);
                                return;
                            }
                        }
                    }
                    if (Log.isLoggable("LruBitmapPool", 2)) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("Reject bitmap from pool, bitmap: ");
                        sb2.append(((C0965ji) this.f2962a).mo4173e(bitmap));
                        sb2.append(", is mutable: ");
                        sb2.append(bitmap.isMutable());
                        sb2.append(", is allowed config: ");
                        sb2.append(this.f2963b.contains(bitmap.getConfig()));
                        Log.v("LruBitmapPool", sb2.toString());
                    }
                    bitmap.recycle();
                    return;
                }
                throw new IllegalStateException("Cannot pool recycled bitmap");
            } catch (Throwable th) {
                throw th;
            }
        } else {
            throw new NullPointerException("Bitmap must not be null");
        }
    }

    /* renamed from: f */
    public final void mo3812f() {
        if (Log.isLoggable("LruBitmapPool", 2)) {
            mo3813g();
        }
    }

    /* renamed from: g */
    public final void mo3813g() {
        StringBuilder d = C1012kd.m3195d("Hits=");
        d.append(this.f2967f);
        d.append(", misses=");
        d.append(this.f2968g);
        d.append(", puts=");
        d.append(this.f2969h);
        d.append(", evictions=");
        d.append(this.f2970i);
        d.append(", currentSize=");
        d.append(this.f2966e);
        d.append(", maxSize=");
        d.append(this.f2965d);
        d.append("\nStrategy=");
        d.append(this.f2962a);
        Log.v("LruBitmapPool", d.toString());
    }

    /* renamed from: h */
    public final synchronized Bitmap mo3814h(int i, int i2, Bitmap.Config config) {
        Bitmap b;
        if (Build.VERSION.SDK_INT >= 26) {
            if (config == Bitmap.Config.HARDWARE) {
                throw new IllegalArgumentException("Cannot create a mutable Bitmap with config: " + config + ". Consider setting Downsampler#ALLOW_HARDWARE_CONFIG to false in your RequestOptions and/or in GlideBuilder.setDefaultRequestOptions");
            }
        }
        b = ((C0965ji) this.f2962a).mo4171b(i, i2, config != null ? config : f2961j);
        if (b == null) {
            if (Log.isLoggable("LruBitmapPool", 3)) {
                StringBuilder sb = new StringBuilder();
                sb.append("Missing bitmap=");
                Objects.requireNonNull((C0965ji) this.f2962a);
                sb.append(C0965ji.m3007c(C1624qo.m4652c(i, i2, config), config));
                Log.d("LruBitmapPool", sb.toString());
            }
            this.f2968g++;
        } else {
            this.f2967f++;
            long j = this.f2966e;
            Objects.requireNonNull((C0965ji) this.f2962a);
            this.f2966e = j - ((long) C1624qo.m4653d(b));
            Objects.requireNonNull((C0779b) this.f2964c);
            b.setHasAlpha(true);
            b.setPremultiplied(true);
        }
        if (Log.isLoggable("LruBitmapPool", 2)) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Get bitmap=");
            Objects.requireNonNull((C0965ji) this.f2962a);
            sb2.append(C0965ji.m3007c(C1624qo.m4652c(i, i2, config), config));
            Log.v("LruBitmapPool", sb2.toString());
        }
        mo3812f();
        return b;
    }

    /* renamed from: i */
    public final synchronized void mo3815i(long j) {
        while (this.f2966e > j) {
            C0965ji jiVar = (C0965ji) this.f2962a;
            Bitmap c = jiVar.f3449b.mo3069c();
            if (c != null) {
                jiVar.mo4170a(Integer.valueOf(C1624qo.m4653d(c)), c);
            }
            if (c == null) {
                if (Log.isLoggable("LruBitmapPool", 5)) {
                    Log.w("LruBitmapPool", "Size mismatch, resetting");
                    mo3813g();
                }
                this.f2966e = 0;
                return;
            }
            Objects.requireNonNull((C0779b) this.f2964c);
            long j2 = this.f2966e;
            Objects.requireNonNull((C0965ji) this.f2962a);
            this.f2966e = j2 - ((long) C1624qo.m4653d(c));
            this.f2970i++;
            if (Log.isLoggable("LruBitmapPool", 3)) {
                StringBuilder sb = new StringBuilder();
                sb.append("Evicting bitmap=");
                sb.append(((C0965ji) this.f2962a).mo4173e(c));
                Log.d("LruBitmapPool", sb.toString());
            }
            mo3812f();
            c.recycle();
        }
    }
}
