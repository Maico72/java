package p000;

import java.util.ArrayList;
import java.util.List;

/* renamed from: hf */
public class C0832hf {

    /* renamed from: a */
    public int[] f3092a = null;

    /* renamed from: b */
    public int f3093b = 0;

    /* renamed from: c */
    public int f3094c = 0;

    /* renamed from: d */
    public C0767gf f3095d;

    /* renamed from: e */
    public final List<C0767gf> f3096e = new ArrayList();

    /* renamed from: f */
    public int f3097f;

    /* renamed from: g */
    public int f3098g;

    /* renamed from: h */
    public boolean f3099h;

    /* renamed from: i */
    public int f3100i;

    /* renamed from: j */
    public int f3101j;

    /* renamed from: k */
    public int f3102k;
}
