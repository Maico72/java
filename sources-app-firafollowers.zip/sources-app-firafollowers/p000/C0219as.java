package p000;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: as */
public class C0219as {

    /* renamed from: a */
    public final Map<SoftReference<C1628qr>, Boolean> f1129a = new ConcurrentHashMap();

    /* renamed from: b */
    public final ReferenceQueue<C1628qr> f1130b = new ReferenceQueue<>();

    /* renamed from: as$a */
    public static final class C0220a {

        /* renamed from: a */
        public static final C0219as f1131a = new C0219as();
    }
}
