package p000;

import java.lang.reflect.Field;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import p000.s00;

/* renamed from: gw */
public class C0796gw extends C1145lw {
    public C0796gw(C1035ks ksVar, n00 n00, C2031wv wvVar) {
        super(ksVar, n00);
    }

    /* renamed from: a */
    public String mo3838a(Object obj, Class<?> cls) {
        return mo3840d(obj, cls, this.f3934a);
    }

    /* renamed from: b */
    public String mo3839b(Object obj) {
        return mo3840d(obj, obj.getClass(), this.f3934a);
    }

    /* renamed from: d */
    public String mo3840d(Object obj, Class<?> cls, n00 n00) {
        Class cls2;
        C1035ks ksVar;
        C1035ks ksVar2;
        m00 m00;
        Class cls3;
        m00 m002;
        Object obj2 = obj;
        n00 n002 = n00;
        Class<? super Object> superclass = (!s00.m4865q(cls) || cls.isEnum()) ? cls : cls.getSuperclass();
        String name = superclass.getName();
        if (!name.startsWith("java.util.")) {
            return (name.indexOf(36) < 0 || s00.m4861m(superclass) == null || s00.m4861m(this.f3935b.f3696d) != null) ? name : this.f3935b.f3696d.getName();
        }
        if (obj2 instanceof EnumSet) {
            EnumSet enumSet = (EnumSet) obj2;
            if (!enumSet.isEmpty()) {
                cls3 = ((Enum) enumSet.iterator().next()).getDeclaringClass();
            } else {
                Field field = s00.C1708b.f5652c.f5653a;
                if (field != null) {
                    try {
                        cls3 = (Class) field.get(enumSet);
                    } catch (Exception e) {
                        throw new IllegalArgumentException(e);
                    }
                } else {
                    throw new IllegalStateException("Cannot figure out type for EnumSet (odd JDK platform?)");
                }
            }
            Class<EnumSet> cls4 = EnumSet.class;
            C1035ks c = n002.mo4663c((b00) null, cls3, n00.f4138g);
            String[] strArr = m00.f3951h;
            TypeVariable[] typeParameters = cls4.getTypeParameters();
            int length = typeParameters == null ? 0 : typeParameters.length;
            if (length == 0) {
                m002 = m00.f3953j;
            } else if (length == 1) {
                m002 = new m00(new String[]{typeParameters[0].getName()}, new C1035ks[]{c}, (String[]) null);
            } else {
                StringBuilder d = C1012kd.m3195d("Cannot create TypeBindings for class ");
                d.append(cls4.getName());
                d.append(" with 1 type parameter: class expects ");
                d.append(length);
                throw new IllegalArgumentException(d.toString());
            }
            d00 d00 = (d00) n002.mo4663c((b00) null, cls4, m002);
            if (m002.mo4508f()) {
                C1035ks k = d00.mo4342i(Collection.class).mo1791k();
                if (!k.equals(c)) {
                    throw new IllegalArgumentException(String.format("Non-generic Collection class %s did not resolve to something with element type %s but %s ", new Object[]{s00.m4869u(cls4), c, k}));
                }
            }
            return d00.mo1785L();
        } else if (!(obj2 instanceof EnumMap)) {
            return name;
        } else {
            EnumMap enumMap = (EnumMap) obj2;
            if (!enumMap.isEmpty()) {
                cls2 = ((Enum) enumMap.keySet().iterator().next()).getDeclaringClass();
            } else {
                Field field2 = s00.C1708b.f5652c.f5654b;
                if (field2 != null) {
                    try {
                        cls2 = (Class) field2.get(enumMap);
                    } catch (Exception e2) {
                        throw new IllegalArgumentException(e2);
                    }
                } else {
                    throw new IllegalStateException("Cannot figure out type for EnumMap (odd JDK platform?)");
                }
            }
            Class<Object> cls5 = Object.class;
            Class<EnumMap> cls6 = EnumMap.class;
            Objects.requireNonNull(n00);
            if (cls6 == Properties.class) {
                ksVar2 = n00.f4151t;
                ksVar = ksVar2;
            } else {
                m00 m003 = n00.f4138g;
                ksVar2 = n002.mo4663c((b00) null, cls2, m003);
                ksVar = n002.mo4663c((b00) null, cls5, m003);
            }
            C1035ks[] ksVarArr = {ksVar2, ksVar};
            String[] strArr2 = m00.f3951h;
            TypeVariable[] typeParameters2 = cls6.getTypeParameters();
            if (typeParameters2 == null || typeParameters2.length == 0) {
                m00 = m00.f3953j;
            } else {
                int length2 = typeParameters2.length;
                String[] strArr3 = new String[length2];
                for (int i = 0; i < length2; i++) {
                    strArr3[i] = typeParameters2[i].getName();
                }
                if (length2 == 2) {
                    m00 = new m00(strArr3, ksVarArr, (String[]) null);
                } else {
                    StringBuilder d2 = C1012kd.m3195d("Cannot create TypeBindings for class ");
                    d2.append(cls6.getName());
                    d2.append(" with ");
                    d2.append(2);
                    d2.append(" type parameter");
                    d2.append("s");
                    d2.append(": class expects ");
                    d2.append(length2);
                    throw new IllegalArgumentException(d2.toString());
                }
            }
            g00 g00 = (g00) n002.mo4663c((b00) null, cls6, m00);
            if (m00.mo4508f()) {
                C1035ks i2 = g00.mo4342i(Map.class);
                C1035ks o = i2.mo3429o();
                if (o.equals(ksVar2)) {
                    C1035ks k2 = i2.mo1791k();
                    if (!k2.equals(ksVar)) {
                        throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with value type %s but %s ", new Object[]{s00.m4869u(cls6), ksVar, k2}));
                    }
                } else {
                    throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with key type %s but %s ", new Object[]{s00.m4869u(cls6), ksVar2, o}));
                }
            }
            return g00.mo1785L();
        }
    }
}
