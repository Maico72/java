package p000;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import p000.C0534d6;

/* renamed from: c6 */
public class C0332c6 {

    /* renamed from: a */
    public static final C0328c4<String, Typeface> f1445a = new C0328c4<>(16);

    /* renamed from: b */
    public static final C0534d6 f1446b = new C0534d6("fonts", 10, 10000);

    /* renamed from: c */
    public static final Object f1447c = new Object();

    /* renamed from: d */
    public static final C0604e4<String, ArrayList<C0534d6.C0537c<C0336d>>> f1448d = new C0604e4<>();

    /* renamed from: e */
    public static final Comparator<byte[]> f1449e = new C0333a();

    /* renamed from: c6$a */
    public class C0333a implements Comparator<byte[]> {
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v2, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v5, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v5, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v6, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v6, resolved type: byte} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int compare(java.lang.Object r5, java.lang.Object r6) {
            /*
                r4 = this;
                byte[] r5 = (byte[]) r5
                byte[] r6 = (byte[]) r6
                int r0 = r5.length
                int r1 = r6.length
                r2 = 0
                if (r0 == r1) goto L_0x000c
                int r5 = r5.length
                int r6 = r6.length
                goto L_0x001a
            L_0x000c:
                r0 = 0
            L_0x000d:
                int r1 = r5.length
                if (r0 >= r1) goto L_0x0020
                byte r1 = r5[r0]
                byte r3 = r6[r0]
                if (r1 == r3) goto L_0x001d
                byte r5 = r5[r0]
                byte r6 = r6[r0]
            L_0x001a:
                int r2 = r5 - r6
                goto L_0x0020
            L_0x001d:
                int r0 = r0 + 1
                goto L_0x000d
            L_0x0020:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0332c6.C0333a.compare(java.lang.Object, java.lang.Object):int");
        }
    }

    /* renamed from: c6$b */
    public static class C0334b {

        /* renamed from: a */
        public final int f1450a;

        /* renamed from: b */
        public final C0335c[] f1451b;

        public C0334b(int i, C0335c[] cVarArr) {
            this.f1450a = i;
            this.f1451b = cVarArr;
        }
    }

    /* renamed from: c6$c */
    public static class C0335c {

        /* renamed from: a */
        public final Uri f1452a;

        /* renamed from: b */
        public final int f1453b;

        /* renamed from: c */
        public final int f1454c;

        /* renamed from: d */
        public final boolean f1455d;

        /* renamed from: e */
        public final int f1456e;

        public C0335c(Uri uri, int i, int i2, boolean z, int i3) {
            Objects.requireNonNull(uri);
            this.f1452a = uri;
            this.f1453b = i;
            this.f1454c = i2;
            this.f1455d = z;
            this.f1456e = i3;
        }
    }

    /* renamed from: c6$d */
    public static final class C0336d {

        /* renamed from: a */
        public final Typeface f1457a;

        /* renamed from: b */
        public final int f1458b;

        public C0336d(Typeface typeface, int i) {
            this.f1457a = typeface;
            this.f1458b = i;
        }
    }

    /* JADX WARNING: type inference failed for: r7v2, types: [android.database.Cursor, c6$c[]] */
    /* renamed from: a */
    public static C0334b m1273a(Context context, CancellationSignal cancellationSignal, C2115y5 y5Var) {
        Cursor cursor;
        boolean z;
        C2115y5 y5Var2 = y5Var;
        PackageManager packageManager = context.getPackageManager();
        Resources resources = context.getResources();
        String str = y5Var2.f6851a;
        ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(str, 0);
        if (resolveContentProvider == null) {
            throw new PackageManager.NameNotFoundException(C1012kd.m3202k("No package found for authority: ", str));
        } else if (resolveContentProvider.packageName.equals(y5Var2.f6852b)) {
            Signature[] signatureArr = packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures;
            ArrayList arrayList = new ArrayList();
            for (Signature byteArray : signatureArr) {
                arrayList.add(byteArray.toByteArray());
            }
            Collections.sort(arrayList, f1449e);
            List<List<byte[]>> list = y5Var2.f6854d;
            if (list == null) {
                list = C1401p4.m4346W(resources, 0);
            }
            int i = 0;
            while (true) {
                cursor = 0;
                if (i >= list.size()) {
                    resolveContentProvider = cursor;
                    break;
                }
                ArrayList arrayList2 = new ArrayList(list.get(i));
                Collections.sort(arrayList2, f1449e);
                if (arrayList.size() == arrayList2.size()) {
                    int i2 = 0;
                    while (true) {
                        if (i2 >= arrayList.size()) {
                            z = true;
                            break;
                        } else if (!Arrays.equals((byte[]) arrayList.get(i2), (byte[]) arrayList2.get(i2))) {
                            break;
                        } else {
                            i2++;
                        }
                    }
                }
                z = false;
                if (z) {
                    break;
                }
                i++;
            }
            if (resolveContentProvider == null) {
                return new C0334b(1, cursor);
            }
            String str2 = resolveContentProvider.authority;
            ArrayList arrayList3 = new ArrayList();
            Uri build = new Uri.Builder().scheme("content").authority(str2).build();
            Uri build2 = new Uri.Builder().scheme("content").authority(str2).appendPath("file").build();
            try {
                cursor = context.getContentResolver().query(build, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{y5Var2.f6853c}, (String) null, (CancellationSignal) null);
                if (cursor != null && cursor.getCount() > 0) {
                    int columnIndex = cursor.getColumnIndex("result_code");
                    arrayList3 = new ArrayList();
                    int columnIndex2 = cursor.getColumnIndex("_id");
                    int columnIndex3 = cursor.getColumnIndex("file_id");
                    int columnIndex4 = cursor.getColumnIndex("font_ttc_index");
                    int columnIndex5 = cursor.getColumnIndex("font_weight");
                    int columnIndex6 = cursor.getColumnIndex("font_italic");
                    while (cursor.moveToNext()) {
                        arrayList3.add(new C0335c(columnIndex3 == -1 ? ContentUris.withAppendedId(build, cursor.getLong(columnIndex2)) : ContentUris.withAppendedId(build2, cursor.getLong(columnIndex3)), columnIndex4 != -1 ? cursor.getInt(columnIndex4) : 0, columnIndex5 != -1 ? cursor.getInt(columnIndex5) : 400, columnIndex6 != -1 && cursor.getInt(columnIndex6) == 1, columnIndex != -1 ? cursor.getInt(columnIndex) : 0));
                    }
                }
                return new C0334b(0, (C0335c[]) arrayList3.toArray(new C0335c[0]));
            } finally {
                if (cursor != 0) {
                    cursor.close();
                }
            }
        } else {
            throw new PackageManager.NameNotFoundException("Found content provider " + str + ", but package was not " + y5Var2.f6852b);
        }
    }

    /* renamed from: b */
    public static C0336d m1274b(Context context, C2115y5 y5Var, int i) {
        try {
            C0334b a = m1273a(context, (CancellationSignal) null, y5Var);
            int i2 = a.f1450a;
            int i3 = -3;
            if (i2 == 0) {
                Typeface b = C0808h5.f3033a.mo4000b(context, (CancellationSignal) null, a.f1451b, i);
                if (b != null) {
                    i3 = 0;
                }
                return new C0336d(b, i3);
            }
            if (i2 == 1) {
                i3 = -2;
            }
            return new C0336d((Typeface) null, i3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new C0336d((Typeface) null, -1);
        }
    }
}
