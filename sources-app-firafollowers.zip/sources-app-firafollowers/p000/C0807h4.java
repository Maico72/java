package p000;

import java.util.ArrayList;
import java.util.HashSet;

/* renamed from: h4 */
public final class C0807h4<T> {

    /* renamed from: a */
    public final C0940j6<ArrayList<T>> f3028a = new C1001k6(10);

    /* renamed from: b */
    public final C0604e4<T, ArrayList<T>> f3029b = new C0604e4<>();

    /* renamed from: c */
    public final ArrayList<T> f3030c = new ArrayList<>();

    /* renamed from: d */
    public final HashSet<T> f3031d = new HashSet<>();

    /* renamed from: a */
    public void mo3857a(T t) {
        if (!(this.f3029b.mo3272e(t) >= 0)) {
            this.f3029b.put(t, null);
        }
    }

    /* renamed from: b */
    public final void mo3858b(T t, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (!arrayList.contains(t)) {
            if (!hashSet.contains(t)) {
                hashSet.add(t);
                ArrayList orDefault = this.f3029b.getOrDefault(t, null);
                if (orDefault != null) {
                    int size = orDefault.size();
                    for (int i = 0; i < size; i++) {
                        mo3858b(orDefault.get(i), arrayList, hashSet);
                    }
                }
                hashSet.remove(t);
                arrayList.add(t);
                return;
            }
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
    }
}
