package p000;

/* renamed from: au */
public abstract class C0222au {
}
