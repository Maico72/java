package p000;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Build;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: f2 */
public class C0663f2 {

    /* renamed from: l */
    public static final RectF f2642l = new RectF();

    /* renamed from: m */
    public static ConcurrentHashMap<String, Method> f2643m = new ConcurrentHashMap<>();

    /* renamed from: n */
    public static ConcurrentHashMap<String, Field> f2644n = new ConcurrentHashMap<>();

    /* renamed from: a */
    public int f2645a = 0;

    /* renamed from: b */
    public boolean f2646b = false;

    /* renamed from: c */
    public float f2647c = -1.0f;

    /* renamed from: d */
    public float f2648d = -1.0f;

    /* renamed from: e */
    public float f2649e = -1.0f;

    /* renamed from: f */
    public int[] f2650f = new int[0];

    /* renamed from: g */
    public boolean f2651g = false;

    /* renamed from: h */
    public TextPaint f2652h;

    /* renamed from: i */
    public final TextView f2653i;

    /* renamed from: j */
    public final Context f2654j;

    /* renamed from: k */
    public final C0666c f2655k;

    /* renamed from: f2$a */
    public static class C0664a extends C0666c {
        /* renamed from: a */
        public void mo3471a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection((TextDirectionHeuristic) C0663f2.m2125e(textView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
        }
    }

    /* renamed from: f2$b */
    public static class C0665b extends C0664a {
        /* renamed from: a */
        public void mo3471a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection(textView.getTextDirectionHeuristic());
        }

        /* renamed from: b */
        public boolean mo3472b(TextView textView) {
            return textView.isHorizontallyScrollable();
        }
    }

    /* renamed from: f2$c */
    public static class C0666c {
        /* renamed from: a */
        public void mo3471a(StaticLayout.Builder builder, TextView textView) {
        }

        /* renamed from: b */
        public boolean mo3472b(TextView textView) {
            return ((Boolean) C0663f2.m2125e(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        }
    }

    public C0663f2(TextView textView) {
        this.f2653i = textView;
        this.f2654j = textView.getContext();
        int i = Build.VERSION.SDK_INT;
        this.f2655k = i >= 29 ? new C0665b() : i >= 23 ? new C0664a() : new C0666c();
    }

    /* renamed from: d */
    public static Method m2124d(String str) {
        try {
            Method method = f2643m.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                f2643m.put(str, method);
            }
            return method;
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e);
            return null;
        }
    }

    /* renamed from: e */
    public static <T> T m2125e(Object obj, String str, T t) {
        try {
            return m2124d(str).invoke(obj, new Object[0]);
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e);
            return t;
        }
    }

    /* renamed from: a */
    public void mo3463a() {
        if (mo3469i() && this.f2645a != 0) {
            if (this.f2646b) {
                if (this.f2653i.getMeasuredHeight() > 0 && this.f2653i.getMeasuredWidth() > 0) {
                    int measuredWidth = this.f2655k.mo3472b(this.f2653i) ? 1048576 : (this.f2653i.getMeasuredWidth() - this.f2653i.getTotalPaddingLeft()) - this.f2653i.getTotalPaddingRight();
                    int height = (this.f2653i.getHeight() - this.f2653i.getCompoundPaddingBottom()) - this.f2653i.getCompoundPaddingTop();
                    if (measuredWidth > 0 && height > 0) {
                        RectF rectF = f2642l;
                        synchronized (rectF) {
                            rectF.setEmpty();
                            rectF.right = (float) measuredWidth;
                            rectF.bottom = (float) height;
                            float c = (float) mo3465c(rectF);
                            if (c != this.f2653i.getTextSize()) {
                                mo3466f(0, c);
                            }
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f2646b = true;
        }
    }

    /* renamed from: b */
    public final int[] mo3464b(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i)) < 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr2[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0104, code lost:
        if (r7.getLineEnd(r7.getLineCount() - 1) != r8.length()) goto L_0x0115;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x011a  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0125  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int mo3465c(android.graphics.RectF r21) {
        /*
            r20 = this;
            r0 = r20
            r1 = r21
            int[] r2 = r0.f2650f
            int r2 = r2.length
            if (r2 == 0) goto L_0x0131
            r3 = 1
            int r2 = r2 - r3
            r4 = 0
            r5 = 1
            r6 = 0
        L_0x000e:
            if (r5 > r2) goto L_0x012c
            int r6 = r5 + r2
            int r6 = r6 / 2
            int[] r7 = r0.f2650f
            r7 = r7[r6]
            android.widget.TextView r8 = r0.f2653i
            java.lang.CharSequence r8 = r8.getText()
            android.widget.TextView r9 = r0.f2653i
            android.text.method.TransformationMethod r9 = r9.getTransformationMethod()
            if (r9 == 0) goto L_0x002f
            android.widget.TextView r10 = r0.f2653i
            java.lang.CharSequence r9 = r9.getTransformation(r8, r10)
            if (r9 == 0) goto L_0x002f
            r8 = r9
        L_0x002f:
            int r9 = android.os.Build.VERSION.SDK_INT
            android.widget.TextView r10 = r0.f2653i
            int r15 = r10.getMaxLines()
            android.text.TextPaint r10 = r0.f2652h
            if (r10 != 0) goto L_0x0043
            android.text.TextPaint r10 = new android.text.TextPaint
            r10.<init>()
            r0.f2652h = r10
            goto L_0x0046
        L_0x0043:
            r10.reset()
        L_0x0046:
            android.text.TextPaint r10 = r0.f2652h
            android.widget.TextView r11 = r0.f2653i
            android.text.TextPaint r11 = r11.getPaint()
            r10.set(r11)
            android.text.TextPaint r10 = r0.f2652h
            float r7 = (float) r7
            r10.setTextSize(r7)
            android.widget.TextView r7 = r0.f2653i
            android.text.Layout$Alignment r10 = android.text.Layout.Alignment.ALIGN_NORMAL
            java.lang.String r11 = "getLayoutAlignment"
            java.lang.Object r7 = m2125e(r7, r11, r10)
            r14 = r7
            android.text.Layout$Alignment r14 = (android.text.Layout.Alignment) r14
            float r7 = r1.right
            int r13 = java.lang.Math.round(r7)
            r7 = 23
            r12 = -1
            if (r9 < r7) goto L_0x00cb
            int r7 = r8.length()
            android.text.TextPaint r9 = r0.f2652h
            android.text.StaticLayout$Builder r7 = android.text.StaticLayout.Builder.obtain(r8, r4, r7, r9, r13)
            android.text.StaticLayout$Builder r9 = r7.setAlignment(r14)
            android.widget.TextView r10 = r0.f2653i
            float r10 = r10.getLineSpacingExtra()
            android.widget.TextView r11 = r0.f2653i
            float r11 = r11.getLineSpacingMultiplier()
            android.text.StaticLayout$Builder r9 = r9.setLineSpacing(r10, r11)
            android.widget.TextView r10 = r0.f2653i
            boolean r10 = r10.getIncludeFontPadding()
            android.text.StaticLayout$Builder r9 = r9.setIncludePad(r10)
            android.widget.TextView r10 = r0.f2653i
            int r10 = r10.getBreakStrategy()
            android.text.StaticLayout$Builder r9 = r9.setBreakStrategy(r10)
            android.widget.TextView r10 = r0.f2653i
            int r10 = r10.getHyphenationFrequency()
            android.text.StaticLayout$Builder r9 = r9.setHyphenationFrequency(r10)
            if (r15 != r12) goto L_0x00b1
            r10 = 2147483647(0x7fffffff, float:NaN)
            goto L_0x00b2
        L_0x00b1:
            r10 = r15
        L_0x00b2:
            r9.setMaxLines(r10)
            f2$c r9 = r0.f2655k     // Catch:{ ClassCastException -> 0x00bd }
            android.widget.TextView r10 = r0.f2653i     // Catch:{ ClassCastException -> 0x00bd }
            r9.mo3471a(r7, r10)     // Catch:{ ClassCastException -> 0x00bd }
            goto L_0x00c4
        L_0x00bd:
            java.lang.String r9 = "ACTVAutoSizeHelper"
            java.lang.String r10 = "Failed to obtain TextDirectionHeuristic, auto size may be incorrect"
            android.util.Log.w(r9, r10)
        L_0x00c4:
            android.text.StaticLayout r7 = r7.build()
            r3 = r15
            r4 = -1
            goto L_0x00ee
        L_0x00cb:
            android.widget.TextView r7 = r0.f2653i
            float r7 = r7.getLineSpacingMultiplier()
            android.widget.TextView r9 = r0.f2653i
            float r16 = r9.getLineSpacingExtra()
            android.widget.TextView r9 = r0.f2653i
            boolean r17 = r9.getIncludeFontPadding()
            android.text.StaticLayout r9 = new android.text.StaticLayout
            android.text.TextPaint r11 = r0.f2652h
            r10 = r9
            r18 = r11
            r11 = r8
            r4 = -1
            r12 = r18
            r3 = r15
            r15 = r7
            r10.<init>(r11, r12, r13, r14, r15, r16, r17)
            r7 = r9
        L_0x00ee:
            if (r3 == r4) goto L_0x0109
            int r4 = r7.getLineCount()
            if (r4 > r3) goto L_0x0107
            int r3 = r7.getLineCount()
            r4 = 1
            int r3 = r3 - r4
            int r3 = r7.getLineEnd(r3)
            int r8 = r8.length()
            if (r3 == r8) goto L_0x010a
            goto L_0x0115
        L_0x0107:
            r4 = 1
            goto L_0x0115
        L_0x0109:
            r4 = 1
        L_0x010a:
            int r3 = r7.getHeight()
            float r3 = (float) r3
            float r7 = r1.bottom
            int r3 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r3 <= 0) goto L_0x0117
        L_0x0115:
            r3 = 0
            goto L_0x0118
        L_0x0117:
            r3 = 1
        L_0x0118:
            if (r3 == 0) goto L_0x0125
            int r6 = r6 + 1
            r3 = 1
            r4 = 0
            r19 = r6
            r6 = r5
            r5 = r19
            goto L_0x000e
        L_0x0125:
            int r6 = r6 + -1
            r2 = r6
            r3 = 1
            r4 = 0
            goto L_0x000e
        L_0x012c:
            int[] r1 = r0.f2650f
            r1 = r1[r6]
            return r1
        L_0x0131:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "No available text sizes to choose from."
            r1.<init>(r2)
            goto L_0x013a
        L_0x0139:
            throw r1
        L_0x013a:
            goto L_0x0139
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0663f2.mo3465c(android.graphics.RectF):int");
    }

    /* renamed from: f */
    public void mo3466f(int i, float f) {
        Context context = this.f2654j;
        float applyDimension = TypedValue.applyDimension(i, f, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        if (applyDimension != this.f2653i.getPaint().getTextSize()) {
            this.f2653i.getPaint().setTextSize(applyDimension);
            boolean isInLayout = this.f2653i.isInLayout();
            if (this.f2653i.getLayout() != null) {
                this.f2646b = false;
                try {
                    Method d = m2124d("nullLayouts");
                    if (d != null) {
                        d.invoke(this.f2653i, new Object[0]);
                    }
                } catch (Exception e) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e);
                }
                if (!isInLayout) {
                    this.f2653i.requestLayout();
                } else {
                    this.f2653i.forceLayout();
                }
                this.f2653i.invalidate();
            }
        }
    }

    /* renamed from: g */
    public final boolean mo3467g() {
        if (!mo3469i() || this.f2645a != 1) {
            this.f2646b = false;
        } else {
            if (!this.f2651g || this.f2650f.length == 0) {
                int floor = ((int) Math.floor((double) ((this.f2649e - this.f2648d) / this.f2647c))) + 1;
                int[] iArr = new int[floor];
                for (int i = 0; i < floor; i++) {
                    iArr[i] = Math.round((((float) i) * this.f2647c) + this.f2648d);
                }
                this.f2650f = mo3464b(iArr);
            }
            this.f2646b = true;
        }
        return this.f2646b;
    }

    /* renamed from: h */
    public final boolean mo3468h() {
        int[] iArr = this.f2650f;
        int length = iArr.length;
        boolean z = length > 0;
        this.f2651g = z;
        if (z) {
            this.f2645a = 1;
            this.f2648d = (float) iArr[0];
            this.f2649e = (float) iArr[length - 1];
            this.f2647c = -1.0f;
        }
        return z;
    }

    /* renamed from: i */
    public final boolean mo3469i() {
        return !(this.f2653i instanceof C1473q1);
    }

    /* renamed from: j */
    public final void mo3470j(float f, float f2, float f3) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f + "px) is less or equal to (0px)");
        } else if (f2 <= f) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f2 + "px) is less or equal to minimum auto-size text size (" + f + "px)");
        } else if (f3 > 0.0f) {
            this.f2645a = 1;
            this.f2648d = f;
            this.f2649e = f2;
            this.f2647c = f3;
            this.f2651g = false;
        } else {
            throw new IllegalArgumentException("The auto-size step granularity (" + f3 + "px) is less or equal to (0px)");
        }
    }
}
