package p000;

import p000.C1460pr;
import p000.C2090xp;

/* renamed from: aw */
public abstract class C0230aw {
    /* renamed from: a */
    public abstract C0230aw mo1474a(C0714fs fsVar);

    /* renamed from: b */
    public abstract String mo1475b();

    /* renamed from: c */
    public abstract C2090xp.C2091a mo1476c();

    /* renamed from: d */
    public C1460pr mo1477d(Object obj, C1692rq rqVar) {
        C1460pr.C1461a aVar;
        C1460pr.C1461a aVar2;
        C1460pr prVar = new C1460pr(obj, rqVar);
        int ordinal = mo1476c().ordinal();
        if (ordinal != 0) {
            if (ordinal == 1) {
                aVar2 = C1460pr.C1461a.WRAPPER_OBJECT;
            } else if (ordinal == 2) {
                aVar2 = C1460pr.C1461a.WRAPPER_ARRAY;
            } else if (ordinal == 3) {
                aVar = C1460pr.C1461a.PARENT_PROPERTY;
            } else if (ordinal == 4) {
                aVar = C1460pr.C1461a.PAYLOAD_PROPERTY;
            } else {
                int i = C0312bs.f1364a;
                throw new RuntimeException("Internal error: this code path should never get executed");
            }
            prVar.f4927e = aVar2;
            return prVar;
        }
        aVar = C1460pr.C1461a.METADATA_PROPERTY;
        prVar.f4927e = aVar;
        prVar.f4926d = mo1475b();
        return prVar;
    }

    /* renamed from: e */
    public abstract C1460pr mo1478e(C1200mq mqVar, C1460pr prVar);

    /* renamed from: f */
    public abstract C1460pr mo1479f(C1200mq mqVar, C1460pr prVar);
}
