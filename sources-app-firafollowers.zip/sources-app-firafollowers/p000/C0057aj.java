package p000;

import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import p000.C0768gg;
import p000.C0969jj;

/* renamed from: aj */
public final class C0057aj<Model, Data> implements C0969jj<Model, Data> {

    /* renamed from: a */
    public final C0058a<Data> f187a;

    /* renamed from: aj$a */
    public interface C0058a<Data> {
    }

    /* renamed from: aj$b */
    public static final class C0059b<Data> implements C0768gg<Data> {

        /* renamed from: d */
        public final String f188d;

        /* renamed from: e */
        public final C0058a<Data> f189e;

        /* renamed from: f */
        public Data f190f;

        public C0059b(String str, C0058a<Data> aVar) {
            this.f188d = str;
            this.f189e = aVar;
        }

        /* renamed from: a */
        public Class<Data> mo134a() {
            Objects.requireNonNull((C0060c.C0061a) this.f189e);
            return InputStream.class;
        }

        /* renamed from: b */
        public void mo135b() {
            try {
                C0058a<Data> aVar = this.f189e;
                Data data = this.f190f;
                Objects.requireNonNull((C0060c.C0061a) aVar);
                ((InputStream) data).close();
            } catch (IOException unused) {
            }
        }

        /* renamed from: c */
        public C1017kf mo136c() {
            return C1017kf.LOCAL;
        }

        public void cancel() {
        }

        /* renamed from: e */
        public void mo138e(C2066xe xeVar, C0768gg.C0769a<? super Data> aVar) {
            try {
                Data a = ((C0060c.C0061a) this.f189e).mo140a(this.f188d);
                this.f190f = a;
                aVar.mo3803f(a);
            } catch (IllegalArgumentException e) {
                aVar.mo3802d(e);
            }
        }
    }

    /* renamed from: aj$c */
    public static final class C0060c<Model> implements C1023kj<Model, InputStream> {

        /* renamed from: a */
        public final C0058a<InputStream> f191a = new C0061a(this);

        /* renamed from: aj$c$a */
        public class C0061a implements C0058a<InputStream> {
            public C0061a(C0060c cVar) {
            }

            /* renamed from: a */
            public Object mo140a(String str) {
                if (str.startsWith("data:image")) {
                    int indexOf = str.indexOf(44);
                    if (indexOf == -1) {
                        throw new IllegalArgumentException("Missing comma in data URL.");
                    } else if (str.substring(0, indexOf).endsWith(";base64")) {
                        return new ByteArrayInputStream(Base64.decode(str.substring(indexOf + 1), 0));
                    } else {
                        throw new IllegalArgumentException("Not a base64 image data URL.");
                    }
                } else {
                    throw new IllegalArgumentException("Not a valid image data URL.");
                }
            }
        }

        /* renamed from: b */
        public C0969jj<Model, InputStream> mo139b(C1259nj njVar) {
            return new C0057aj(this.f191a);
        }
    }

    public C0057aj(C0058a<Data> aVar) {
        this.f187a = aVar;
    }

    /* renamed from: a */
    public C0969jj.C0970a<Data> mo132a(Model model, int i, int i2, C2150yf yfVar) {
        return new C0969jj.C0970a<>(new C0788go(model), new C0059b(model.toString(), this.f187a));
    }

    /* renamed from: b */
    public boolean mo133b(Model model) {
        return model.toString().startsWith("data:image");
    }
}
