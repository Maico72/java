package p000;

import p000.C1175md;

/* renamed from: be */
public class C0279be<T> {

    /* renamed from: a */
    public final T f1320a;

    /* renamed from: b */
    public final C1175md.C1176a f1321b;

    /* renamed from: c */
    public final C0685fe f1322c;

    /* renamed from: d */
    public boolean f1323d;

    /* renamed from: be$a */
    public interface C0280a {
    }

    /* renamed from: be$b */
    public interface C0281b<T> {
    }

    public C0279be(C0685fe feVar) {
        this.f1323d = false;
        this.f1320a = null;
        this.f1321b = null;
        this.f1322c = feVar;
    }

    public C0279be(T t, C1175md.C1176a aVar) {
        this.f1323d = false;
        this.f1320a = t;
        this.f1321b = aVar;
        this.f1322c = null;
    }
}
