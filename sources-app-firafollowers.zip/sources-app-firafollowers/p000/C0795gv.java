package p000;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import p000.C0223av;

/* renamed from: gv */
public class C0795gv {

    /* renamed from: b */
    public static final C0315bv[] f2989b = new C0315bv[0];

    /* renamed from: c */
    public static final Annotation[] f2990c = new Annotation[0];

    /* renamed from: a */
    public final C0583ds f2991a;

    public C0795gv(C0583ds dsVar) {
        this.f2991a = dsVar;
    }

    /* renamed from: a */
    public static C0315bv[] m2546a(int i) {
        if (i == 0) {
            return f2989b;
        }
        C0315bv[] bvVarArr = new C0315bv[i];
        for (int i2 = 0; i2 < i; i2++) {
            bvVarArr[i2] = new C0315bv();
        }
        return bvVarArr;
    }

    /* renamed from: b */
    public final C0223av mo3834b(C0223av avVar, Annotation[] annotationArr) {
        for (Annotation annotation : annotationArr) {
            avVar = avVar.mo1468a(annotation);
            if (this.f2991a.mo3129b0(annotation)) {
                avVar = mo3837e(avVar, annotation);
            }
        }
        return avVar;
    }

    /* renamed from: c */
    public final C0223av mo3835c(Annotation[] annotationArr) {
        C0223av avVar = C0223av.C0224a.f1148c;
        for (Annotation annotation : annotationArr) {
            avVar = avVar.mo1468a(annotation);
            if (this.f2991a.mo3129b0(annotation)) {
                avVar = mo3837e(avVar, annotation);
            }
        }
        return avVar;
    }

    /* renamed from: d */
    public final C0223av mo3836d(C0223av avVar, Annotation[] annotationArr) {
        for (Annotation annotation : annotationArr) {
            if (!avVar.mo1471d(annotation)) {
                avVar = avVar.mo1468a(annotation);
                if (this.f2991a.mo3129b0(annotation)) {
                    for (Annotation annotation2 : s00.m4857i(annotation.annotationType())) {
                        if (!((annotation2 instanceof Target) || (annotation2 instanceof Retention)) && !avVar.mo1471d(annotation2)) {
                            avVar = avVar.mo1468a(annotation2);
                            if (this.f2991a.mo3129b0(annotation2)) {
                                avVar = mo3837e(avVar, annotation2);
                            }
                        }
                    }
                }
            }
        }
        return avVar;
    }

    /* renamed from: e */
    public final C0223av mo3837e(C0223av avVar, Annotation annotation) {
        for (Annotation annotation2 : s00.m4857i(annotation.annotationType())) {
            if (!((annotation2 instanceof Target) || (annotation2 instanceof Retention))) {
                if (!this.f2991a.mo3129b0(annotation2)) {
                    avVar = avVar.mo1468a(annotation2);
                } else if (!avVar.mo1471d(annotation2)) {
                    avVar = mo3837e(avVar.mo1468a(annotation2), annotation2);
                }
            }
        }
        return avVar;
    }
}
