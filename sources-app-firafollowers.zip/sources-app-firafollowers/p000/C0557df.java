package p000;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

/* renamed from: df */
public class C0557df implements Closeable {

    /* renamed from: d */
    public final InputStream f2244d;

    /* renamed from: e */
    public final Charset f2245e;

    /* renamed from: f */
    public byte[] f2246f;

    /* renamed from: g */
    public int f2247g;

    /* renamed from: h */
    public int f2248h;

    /* renamed from: df$a */
    public class C0558a extends ByteArrayOutputStream {
        public C0558a(int i) {
            super(i);
        }

        public String toString() {
            int i = this.count;
            if (i > 0 && this.buf[i - 1] == 13) {
                i--;
            }
            try {
                return new String(this.buf, 0, i, C0557df.this.f2245e.name());
            } catch (UnsupportedEncodingException e) {
                throw new AssertionError(e);
            }
        }
    }

    public C0557df(InputStream inputStream, Charset charset) {
        if (charset == null) {
            throw null;
        } else if (charset.equals(C0633ef.f2596a)) {
            this.f2244d = inputStream;
            this.f2245e = charset;
            this.f2246f = new byte[8192];
        } else {
            throw new IllegalArgumentException("Unsupported encoding");
        }
    }

    /* renamed from: a */
    public final void mo3046a() {
        InputStream inputStream = this.f2244d;
        byte[] bArr = this.f2246f;
        int read = inputStream.read(bArr, 0, bArr.length);
        if (read != -1) {
            this.f2247g = 0;
            this.f2248h = read;
            return;
        }
        throw new EOFException();
    }

    /* renamed from: b */
    public String mo3047b() {
        int i;
        byte[] bArr;
        int i2;
        synchronized (this.f2244d) {
            if (this.f2246f != null) {
                if (this.f2247g >= this.f2248h) {
                    mo3046a();
                }
                for (int i3 = this.f2247g; i3 != this.f2248h; i3++) {
                    byte[] bArr2 = this.f2246f;
                    if (bArr2[i3] == 10) {
                        if (i3 != this.f2247g) {
                            i2 = i3 - 1;
                            if (bArr2[i2] == 13) {
                                byte[] bArr3 = this.f2246f;
                                int i4 = this.f2247g;
                                String str = new String(bArr3, i4, i2 - i4, this.f2245e.name());
                                this.f2247g = i3 + 1;
                                return str;
                            }
                        }
                        i2 = i3;
                        byte[] bArr32 = this.f2246f;
                        int i42 = this.f2247g;
                        String str2 = new String(bArr32, i42, i2 - i42, this.f2245e.name());
                        this.f2247g = i3 + 1;
                        return str2;
                    }
                }
                C0558a aVar = new C0558a((this.f2248h - this.f2247g) + 80);
                loop1:
                while (true) {
                    byte[] bArr4 = this.f2246f;
                    int i5 = this.f2247g;
                    aVar.write(bArr4, i5, this.f2248h - i5);
                    this.f2248h = -1;
                    mo3046a();
                    i = this.f2247g;
                    while (true) {
                        if (i != this.f2248h) {
                            bArr = this.f2246f;
                            if (bArr[i] == 10) {
                                break loop1;
                            }
                            i++;
                        }
                    }
                }
                int i6 = this.f2247g;
                if (i != i6) {
                    aVar.write(bArr, i6, i - i6);
                }
                this.f2247g = i + 1;
                String aVar2 = aVar.toString();
                return aVar2;
            }
            throw new IOException("LineReader is closed");
        }
    }

    public void close() {
        synchronized (this.f2244d) {
            if (this.f2246f != null) {
                this.f2246f = null;
                this.f2244d.close();
            }
        }
    }
}
