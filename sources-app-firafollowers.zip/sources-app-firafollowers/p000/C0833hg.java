package p000;

/* renamed from: hg */
public interface C0833hg<T> {

    /* renamed from: hg$a */
    public interface C0834a<T> {
        /* renamed from: a */
        Class<T> mo1983a();

        /* renamed from: b */
        C0833hg<T> mo1984b(T t);
    }

    /* renamed from: a */
    T mo1979a();

    /* renamed from: b */
    void mo1980b();
}
