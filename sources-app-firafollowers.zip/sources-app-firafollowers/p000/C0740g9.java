package p000;

/* renamed from: g9 */
public class C0740g9 implements C1725s9 {

    /* renamed from: d */
    public C1785t9 f2852d = null;

    /* renamed from: a */
    public C1409p9 mo150a() {
        if (this.f2852d == null) {
            this.f2852d = new C1785t9(this);
        }
        return this.f2852d;
    }
}
