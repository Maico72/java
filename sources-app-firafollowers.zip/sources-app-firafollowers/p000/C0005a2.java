package p000;

import android.annotation.SuppressLint;
import android.view.View;
import p000.C0247b2;

/* renamed from: a2 */
public class C0005a2 extends C1156m2 {

    /* renamed from: m */
    public final /* synthetic */ C0247b2.C0251d f9m;

    /* renamed from: n */
    public final /* synthetic */ C0247b2 f10n;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0005a2(C0247b2 b2Var, View view, C0247b2.C0251d dVar) {
        super(view);
        this.f10n = b2Var;
        this.f9m = dVar;
    }

    /* renamed from: b */
    public C0522d1 mo18b() {
        return this.f9m;
    }

    @SuppressLint({"SyntheticAccessor"})
    /* renamed from: c */
    public boolean mo19c() {
        if (this.f10n.getInternalPopup().mo1538b()) {
            return true;
        }
        this.f10n.mo1511b();
        return true;
    }
}
