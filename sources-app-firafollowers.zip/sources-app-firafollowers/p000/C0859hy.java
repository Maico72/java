package p000;

@C0313bt
/* renamed from: hy */
public class C0859hy extends C1770sz<byte[]> {
    public C0859hy() {
        super(byte[].class);
    }

    /* renamed from: d */
    public boolean mo3672d(C0221at atVar, Object obj) {
        return ((byte[]) obj).length == 0;
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        byte[] bArr = (byte[]) obj;
        mqVar.mo3733j(atVar.f1134d.f5782e.f3515n, bArr, 0, bArr.length);
    }

    /* renamed from: g */
    public void mo1482g(Object obj, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        byte[] bArr = (byte[]) obj;
        C1460pr e = awVar.mo1478e(mqVar, awVar.mo1477d(bArr, C1692rq.VALUE_EMBEDDED_OBJECT));
        mqVar.mo3733j(atVar.f1134d.f5782e.f3515n, bArr, 0, bArr.length);
        awVar.mo1479f(mqVar, e);
    }
}
