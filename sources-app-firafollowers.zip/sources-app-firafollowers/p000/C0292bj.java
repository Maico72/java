package p000;

import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import p000.C0768gg;
import p000.C0969jj;

/* renamed from: bj */
public class C0292bj<Data> implements C0969jj<File, Data> {

    /* renamed from: a */
    public final C0297d<Data> f1339a;

    /* renamed from: bj$a */
    public static class C0293a<Data> implements C1023kj<File, Data> {

        /* renamed from: a */
        public final C0297d<Data> f1340a;

        public C0293a(C0297d<Data> dVar) {
            this.f1340a = dVar;
        }

        /* renamed from: b */
        public final C0969jj<File, Data> mo139b(C1259nj njVar) {
            return new C0292bj(this.f1340a);
        }
    }

    /* renamed from: bj$b */
    public static class C0294b extends C0293a<ParcelFileDescriptor> {

        /* renamed from: bj$b$a */
        public class C0295a implements C0297d<ParcelFileDescriptor> {
            /* renamed from: a */
            public Class<ParcelFileDescriptor> mo1711a() {
                return ParcelFileDescriptor.class;
            }

            /* renamed from: b */
            public Object mo1712b(File file) {
                return ParcelFileDescriptor.open(file, 268435456);
            }

            /* renamed from: c */
            public void mo1713c(Object obj) {
                ((ParcelFileDescriptor) obj).close();
            }
        }

        public C0294b() {
            super(new C0295a());
        }
    }

    /* renamed from: bj$c */
    public static final class C0296c<Data> implements C0768gg<Data> {

        /* renamed from: d */
        public final File f1341d;

        /* renamed from: e */
        public final C0297d<Data> f1342e;

        /* renamed from: f */
        public Data f1343f;

        public C0296c(File file, C0297d<Data> dVar) {
            this.f1341d = file;
            this.f1342e = dVar;
        }

        /* renamed from: a */
        public Class<Data> mo134a() {
            return this.f1342e.mo1711a();
        }

        /* renamed from: b */
        public void mo135b() {
            Data data = this.f1343f;
            if (data != null) {
                try {
                    this.f1342e.mo1713c(data);
                } catch (IOException unused) {
                }
            }
        }

        /* renamed from: c */
        public C1017kf mo136c() {
            return C1017kf.LOCAL;
        }

        public void cancel() {
        }

        /* renamed from: e */
        public void mo138e(C2066xe xeVar, C0768gg.C0769a<? super Data> aVar) {
            try {
                Data b = this.f1342e.mo1712b(this.f1341d);
                this.f1343f = b;
                aVar.mo3803f(b);
            } catch (FileNotFoundException e) {
                if (Log.isLoggable("FileLoader", 3)) {
                    Log.d("FileLoader", "Failed to open file", e);
                }
                aVar.mo3802d(e);
            }
        }
    }

    /* renamed from: bj$d */
    public interface C0297d<Data> {
        /* renamed from: a */
        Class<Data> mo1711a();

        /* renamed from: b */
        Data mo1712b(File file);

        /* renamed from: c */
        void mo1713c(Data data);
    }

    /* renamed from: bj$e */
    public static class C0298e extends C0293a<InputStream> {

        /* renamed from: bj$e$a */
        public class C0299a implements C0297d<InputStream> {
            /* renamed from: a */
            public Class<InputStream> mo1711a() {
                return InputStream.class;
            }

            /* renamed from: b */
            public Object mo1712b(File file) {
                return new FileInputStream(file);
            }

            /* renamed from: c */
            public void mo1713c(Object obj) {
                ((InputStream) obj).close();
            }
        }

        public C0298e() {
            super(new C0299a());
        }
    }

    public C0292bj(C0297d<Data> dVar) {
        this.f1339a = dVar;
    }

    /* renamed from: a */
    public C0969jj.C0970a mo132a(Object obj, int i, int i2, C2150yf yfVar) {
        File file = (File) obj;
        return new C0969jj.C0970a(new C0788go(file), new C0296c(file, this.f1339a));
    }

    /* renamed from: b */
    public /* bridge */ /* synthetic */ boolean mo133b(Object obj) {
        File file = (File) obj;
        return true;
    }
}
