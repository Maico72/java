package p000;

import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: ga */
public abstract class C0741ga {
    /* renamed from: b */
    public static <T extends C1725s9 & C0681fa> C0741ga m2445b(T t) {
        return new C0820ha(t, ((C0681fa) t).mo153g());
    }

    @Deprecated
    /* renamed from: a */
    public abstract void mo3766a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
