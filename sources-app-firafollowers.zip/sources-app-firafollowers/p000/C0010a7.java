package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.fasaroid.fira.R;
import p000.C1163m6;

/* renamed from: a7 */
public class C0010a7 {

    /* renamed from: a */
    public static WeakHashMap<View, String> f28a;

    /* renamed from: b */
    public static WeakHashMap<View, C0675f7> f29b = null;

    /* renamed from: c */
    public static Field f30c;

    /* renamed from: d */
    public static boolean f31d = false;

    /* renamed from: e */
    public static ThreadLocal<Rect> f32e;

    /* renamed from: a7$a */
    public class C0011a implements View.OnApplyWindowInsetsListener {

        /* renamed from: a */
        public final /* synthetic */ C2052x6 f33a;

        public C0011a(C2052x6 x6Var) {
            this.f33a = x6Var;
        }

        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            Objects.requireNonNull(windowInsets);
            return this.f33a.mo650a(view, new C0943j7(windowInsets)).mo4134i();
        }
    }

    /* renamed from: a7$b */
    public static abstract class C0012b<T> {

        /* renamed from: a */
        public final int f34a;

        /* renamed from: b */
        public final Class<T> f35b;

        /* renamed from: c */
        public final int f36c;

        public C0012b(int i, Class<T> cls, int i2) {
            this.f34a = i;
            this.f35b = cls;
            this.f36c = i2;
        }

        public C0012b(int i, Class<T> cls, int i2, int i3) {
            this.f34a = i;
            this.f35b = cls;
            this.f36c = i3;
        }

        /* renamed from: a */
        public abstract T mo30a(View view);

        /* renamed from: b */
        public T mo31b(View view) {
            if (Build.VERSION.SDK_INT >= this.f36c) {
                return mo30a(view);
            }
            T tag = view.getTag(this.f34a);
            if (this.f35b.isInstance(tag)) {
                return tag;
            }
            return null;
        }
    }

    /* renamed from: a7$c */
    public interface C0013c {
        /* renamed from: a */
        boolean mo32a(View view, KeyEvent keyEvent);
    }

    /* renamed from: a7$d */
    public static class C0014d {

        /* renamed from: d */
        public static final ArrayList<WeakReference<View>> f37d = new ArrayList<>();

        /* renamed from: a */
        public WeakHashMap<View, Boolean> f38a = null;

        /* renamed from: b */
        public SparseArray<WeakReference<View>> f39b = null;

        /* renamed from: c */
        public WeakReference<KeyEvent> f40c = null;

        /* renamed from: a */
        public final View mo33a(View view, KeyEvent keyEvent) {
            WeakHashMap<View, Boolean> weakHashMap = this.f38a;
            if (weakHashMap != null && weakHashMap.containsKey(view)) {
                if (view instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view;
                    for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                        View a = mo33a(viewGroup.getChildAt(childCount), keyEvent);
                        if (a != null) {
                            return a;
                        }
                    }
                }
                if (mo34b(view, keyEvent)) {
                    return view;
                }
            }
            return null;
        }

        /* renamed from: b */
        public final boolean mo34b(View view, KeyEvent keyEvent) {
            ArrayList arrayList = (ArrayList) view.getTag(R.id.tag_unhandled_key_listeners);
            if (arrayList == null) {
                return false;
            }
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (((C0013c) arrayList.get(size)).mo32a(view, keyEvent)) {
                    return true;
                }
            }
            return false;
        }
    }

    static {
        new AtomicInteger(1);
        new WeakHashMap();
    }

    /* renamed from: a */
    public static C0675f7 m28a(View view) {
        if (f29b == null) {
            f29b = new WeakHashMap<>();
        }
        C0675f7 f7Var = f29b.get(view);
        if (f7Var != null) {
            return f7Var;
        }
        C0675f7 f7Var2 = new C0675f7(view);
        f29b.put(view, f7Var2);
        return f7Var2;
    }

    /* renamed from: b */
    public static void m29b(View view, int i) {
        view.offsetLeftAndRight(i);
        if (view.getVisibility() == 0) {
            float translationY = view.getTranslationY();
            view.setTranslationY(1.0f + translationY);
            view.setTranslationY(translationY);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                m47t((View) parent);
            }
        }
    }

    /* renamed from: c */
    public static void m30c(View view, int i) {
        view.offsetTopAndBottom(i);
        if (view.getVisibility() == 0) {
            float translationY = view.getTranslationY();
            view.setTranslationY(1.0f + translationY);
            view.setTranslationY(translationY);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                m47t((View) parent);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r3.mo4134i();
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static p000.C0943j7 m31d(android.view.View r2, p000.C0943j7 r3) {
        /*
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 21
            if (r0 < r1) goto L_0x001c
            android.view.WindowInsets r0 = r3.mo4134i()
            if (r0 == 0) goto L_0x001c
            android.view.WindowInsets r2 = r2.dispatchApplyWindowInsets(r0)
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L_0x001c
            j7 r2 = new j7
            r2.<init>((android.view.WindowInsets) r0)
            return r2
        L_0x001c:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0010a7.m31d(android.view.View, j7):j7");
    }

    /* renamed from: e */
    public static boolean m32e(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList<WeakReference<View>> arrayList = C0014d.f37d;
        C0014d dVar = (C0014d) view.getTag(R.id.tag_unhandled_key_event_manager);
        if (dVar == null) {
            dVar = new C0014d();
            view.setTag(R.id.tag_unhandled_key_event_manager, dVar);
        }
        if (keyEvent.getAction() == 0) {
            Boolean bool = Boolean.TRUE;
            WeakHashMap<View, Boolean> weakHashMap = dVar.f38a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList<WeakReference<View>> arrayList2 = C0014d.f37d;
            if (!arrayList2.isEmpty()) {
                synchronized (arrayList2) {
                    if (dVar.f38a == null) {
                        dVar.f38a = new WeakHashMap<>();
                    }
                    int size = arrayList2.size();
                    while (true) {
                        size--;
                        if (size < 0) {
                            break;
                        }
                        ArrayList<WeakReference<View>> arrayList3 = C0014d.f37d;
                        View view2 = (View) arrayList3.get(size).get();
                        if (view2 == null) {
                            arrayList3.remove(size);
                        } else {
                            dVar.f38a.put(view2, bool);
                            for (ViewParent parent = view2.getParent(); parent instanceof View; parent = parent.getParent()) {
                                dVar.f38a.put((View) parent, bool);
                            }
                        }
                    }
                }
            }
        }
        View a = dVar.mo33a(view, keyEvent);
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (a != null && !KeyEvent.isModifierKey(keyCode)) {
                if (dVar.f39b == null) {
                    dVar.f39b = new SparseArray<>();
                }
                dVar.f39b.put(keyCode, new WeakReference(a));
            }
        }
        if (a != null) {
            return true;
        }
        return false;
    }

    /* renamed from: f */
    public static View.AccessibilityDelegate m33f(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return view.getAccessibilityDelegate();
        }
        if (f31d) {
            return null;
        }
        if (f30c == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f30c = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f31d = true;
                return null;
            }
        }
        Object obj = f30c.get(view);
        if (obj instanceof View.AccessibilityDelegate) {
            return (View.AccessibilityDelegate) obj;
        }
        return null;
    }

    /* renamed from: g */
    public static ColorStateList m34g(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.getBackgroundTintList();
        }
        if (view instanceof C2195z6) {
            return ((C2195z6) view).getSupportBackgroundTintList();
        }
        return null;
    }

    /* renamed from: h */
    public static Rect m35h() {
        if (f32e == null) {
            f32e = new ThreadLocal<>();
        }
        Rect rect = f32e.get();
        if (rect == null) {
            rect = new Rect();
            f32e.set(rect);
        }
        rect.setEmpty();
        return rect;
    }

    /* renamed from: i */
    public static String m36i(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.getTransitionName();
        }
        WeakHashMap<View, String> weakHashMap = f28a;
        if (weakHashMap == null) {
            return null;
        }
        return weakHashMap.get(view);
    }

    /* renamed from: j */
    public static boolean m37j(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            return view.isNestedScrollingEnabled();
        }
        if (view instanceof C1659r6) {
            return ((C1659r6) view).isNestedScrollingEnabled();
        }
        return false;
    }

    /* renamed from: k */
    public static void m38k(View view, int i) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23) {
            view.offsetLeftAndRight(i);
        } else if (i2 >= 21) {
            Rect h = m35h();
            boolean z = false;
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                View view2 = (View) parent;
                h.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
                z = !h.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
            m29b(view, i);
            if (z && h.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
                ((View) parent).invalidate(h);
            }
        } else {
            m29b(view, i);
        }
    }

    /* renamed from: l */
    public static void m39l(View view, int i) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23) {
            view.offsetTopAndBottom(i);
        } else if (i2 >= 21) {
            Rect h = m35h();
            boolean z = false;
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                View view2 = (View) parent;
                h.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
                z = !h.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
            m30c(view, i);
            if (z && h.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
                ((View) parent).invalidate(h);
            }
        } else {
            m30c(view, i);
        }
    }

    /* renamed from: m */
    public static C0943j7 m40m(View view, C0943j7 j7Var) {
        WindowInsets i;
        if (Build.VERSION.SDK_INT < 21 || (i = j7Var.mo4134i()) == null) {
            return j7Var;
        }
        WindowInsets onApplyWindowInsets = view.onApplyWindowInsets(i);
        return !onApplyWindowInsets.equals(i) ? new C0943j7(onApplyWindowInsets) : j7Var;
    }

    /* renamed from: n */
    public static void m41n(View view) {
        if (Build.VERSION.SDK_INT >= 20) {
            view.requestApplyInsets();
        } else {
            view.requestFitSystemWindows();
        }
    }

    /* renamed from: o */
    public static void m42o(View view, @SuppressLint({"ContextFirst"}) Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i, int i2) {
        if (Build.VERSION.SDK_INT >= 29) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i, i2);
        }
    }

    /* renamed from: p */
    public static void m43p(View view, C1163m6 m6Var) {
        if (m6Var == null && (m33f(view) instanceof C1163m6.C1164a)) {
            m6Var = new C1163m6();
        }
        view.setAccessibilityDelegate(m6Var == null ? null : m6Var.f4002b);
    }

    /* renamed from: q */
    public static void m44q(View view, float f) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setElevation(f);
        }
    }

    /* renamed from: r */
    public static void m45r(View view, C2052x6 x6Var) {
        if (Build.VERSION.SDK_INT < 21) {
            return;
        }
        if (x6Var == null) {
            view.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) null);
        } else {
            view.setOnApplyWindowInsetsListener(new C0011a(x6Var));
        }
    }

    /* renamed from: s */
    public static void m46s(View view, String str) {
        if (Build.VERSION.SDK_INT >= 21) {
            view.setTransitionName(str);
            return;
        }
        if (f28a == null) {
            f28a = new WeakHashMap<>();
        }
        f28a.put(view, str);
    }

    /* renamed from: t */
    public static void m47t(View view) {
        float translationY = view.getTranslationY();
        view.setTranslationY(1.0f + translationY);
        view.setTranslationY(translationY);
    }
}
