package p000;

import android.view.View;
import p000.C0010a7;

/* renamed from: c7 */
public class C0338c7 extends C0010a7.C0012b<CharSequence> {
    public C0338c7(int i, Class cls, int i2, int i3) {
        super(i, cls, i2, i3);
    }

    /* renamed from: a */
    public Object mo30a(View view) {
        return view.getAccessibilityPaneTitle();
    }
}
