package p000;

import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import java.util.Objects;
import p000.C0523d2;

/* renamed from: c5 */
public abstract class C0329c5 {

    /* renamed from: c5$a */
    public class C0330a implements Runnable {

        /* renamed from: d */
        public final /* synthetic */ Typeface f1441d;

        public C0330a(Typeface typeface) {
            this.f1441d = typeface;
        }

        public void run() {
            C0329c5.this.mo1846c(this.f1441d);
        }
    }

    /* renamed from: c5$b */
    public class C0331b implements Runnable {

        /* renamed from: d */
        public final /* synthetic */ int f1443d;

        public C0331b(int i) {
            this.f1443d = i;
        }

        public void run() {
            Objects.requireNonNull((C0523d2.C0524a) C0329c5.this);
        }
    }

    /* renamed from: a */
    public final void mo1844a(int i, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0331b(i));
    }

    /* renamed from: b */
    public final void mo1845b(Typeface typeface, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0330a(typeface));
    }

    /* renamed from: c */
    public abstract void mo1846c(Typeface typeface);
}
