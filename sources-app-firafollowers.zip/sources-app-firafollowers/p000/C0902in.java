package p000;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: in */
public class C0902in {

    /* renamed from: a */
    public final List<String> f3279a = new ArrayList();

    /* renamed from: b */
    public final Map<String, List<C0903a<?, ?>>> f3280b = new HashMap();

    /* renamed from: in$a */
    public static class C0903a<T, R> {

        /* renamed from: a */
        public final Class<T> f3281a;

        /* renamed from: b */
        public final Class<R> f3282b;

        /* renamed from: c */
        public final C0054ag<T, R> f3283c;

        public C0903a(Class<T> cls, Class<R> cls2, C0054ag<T, R> agVar) {
            this.f3281a = cls;
            this.f3282b = cls2;
            this.f3283c = agVar;
        }

        /* renamed from: a */
        public boolean mo4053a(Class<?> cls, Class<?> cls2) {
            return this.f3281a.isAssignableFrom(cls) && cls2.isAssignableFrom(this.f3282b);
        }
    }

    /* renamed from: a */
    public final synchronized List<C0903a<?, ?>> mo4051a(String str) {
        List<C0903a<?, ?>> list;
        if (!this.f3279a.contains(str)) {
            this.f3279a.add(str);
        }
        list = this.f3280b.get(str);
        if (list == null) {
            list = new ArrayList<>();
            this.f3280b.put(str, list);
        }
        return list;
    }

    /* renamed from: b */
    public synchronized <T, R> List<Class<R>> mo4052b(Class<T> cls, Class<R> cls2) {
        ArrayList arrayList;
        arrayList = new ArrayList();
        for (String str : this.f3279a) {
            List<C0903a> list = this.f3280b.get(str);
            if (list != null) {
                for (C0903a aVar : list) {
                    if (aVar.mo4053a(cls, cls2) && !arrayList.contains(aVar.f3282b)) {
                        arrayList.add(aVar.f3282b);
                    }
                }
            }
        }
        return arrayList;
    }
}
