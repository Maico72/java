package p000;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.zip.ZipException;

/* renamed from: ia */
public final class C0880ia {

    /* renamed from: a */
    public static final Set<File> f3239a = new HashSet();

    /* renamed from: b */
    public static final boolean f3240b;

    /* renamed from: ia$a */
    public static final class C0881a {
        /* renamed from: a */
        public static C1170ma m2774a(RandomAccessFile randomAccessFile) {
            long length = randomAccessFile.length() - 22;
            long j = 0;
            if (length >= 0) {
                long j2 = length - 65536;
                if (j2 >= 0) {
                    j = j2;
                }
                int reverseBytes = Integer.reverseBytes(101010256);
                do {
                    randomAccessFile.seek(length);
                    if (randomAccessFile.readInt() == reverseBytes) {
                        randomAccessFile.skipBytes(2);
                        randomAccessFile.skipBytes(2);
                        randomAccessFile.skipBytes(2);
                        randomAccessFile.skipBytes(2);
                        C1170ma maVar = new C1170ma();
                        maVar.f4020b = ((long) Integer.reverseBytes(randomAccessFile.readInt())) & 4294967295L;
                        maVar.f4019a = ((long) Integer.reverseBytes(randomAccessFile.readInt())) & 4294967295L;
                        return maVar;
                    }
                    length--;
                } while (length >= j);
                throw new ZipException("End Of Central Directory signature not found");
            }
            StringBuilder d = C1012kd.m3195d("File too short to be a zip file: ");
            d.append(randomAccessFile.length());
            throw new ZipException(d.toString());
        }
    }

    static {
        String property = System.getProperty("java.vm.version");
        boolean z = false;
        if (property != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(property, ".");
            String str = null;
            String nextToken = stringTokenizer.hasMoreTokens() ? stringTokenizer.nextToken() : null;
            if (stringTokenizer.hasMoreTokens()) {
                str = stringTokenizer.nextToken();
            }
            if (!(nextToken == null || str == null)) {
                try {
                    int parseInt = Integer.parseInt(nextToken);
                    int parseInt2 = Integer.parseInt(str);
                    if (parseInt > 2 || (parseInt == 2 && parseInt2 >= 1)) {
                        z = true;
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("VM with version ");
        sb.append(property);
        sb.append(z ? " has multidex support" : " does not have multidex support");
        Log.i("MultiDex", sb.toString());
        f3240b = z;
    }

    /* renamed from: a */
    public static void m2768a(Object obj, String str, Object[] objArr) {
        Field d = m2771d(obj, str);
        Object[] objArr2 = (Object[]) d.get(obj);
        Object[] objArr3 = (Object[]) Array.newInstance(objArr2.getClass().getComponentType(), objArr2.length + objArr.length);
        System.arraycopy(objArr2, 0, objArr3, 0, objArr2.length);
        System.arraycopy(objArr, 0, objArr3, objArr2.length, objArr.length);
        d.set(obj, objArr3);
    }

    /* renamed from: b */
    public static void m2769b(Context context) {
        File file = new File(context.getFilesDir(), "secondary-dexes");
        if (file.isDirectory()) {
            StringBuilder d = C1012kd.m3195d("Clearing old secondary dex dir (");
            d.append(file.getPath());
            d.append(").");
            Log.i("MultiDex", d.toString());
            File[] listFiles = file.listFiles();
            if (listFiles == null) {
                StringBuilder d2 = C1012kd.m3195d("Failed to list secondary dex dir content (");
                d2.append(file.getPath());
                d2.append(").");
                Log.w("MultiDex", d2.toString());
                return;
            }
            for (File file2 : listFiles) {
                StringBuilder d3 = C1012kd.m3195d("Trying to delete old file ");
                d3.append(file2.getPath());
                d3.append(" of size ");
                d3.append(file2.length());
                Log.i("MultiDex", d3.toString());
                if (!file2.delete()) {
                    StringBuilder d4 = C1012kd.m3195d("Failed to delete old file ");
                    d4.append(file2.getPath());
                    Log.w("MultiDex", d4.toString());
                } else {
                    StringBuilder d5 = C1012kd.m3195d("Deleted old file ");
                    d5.append(file2.getPath());
                    Log.i("MultiDex", d5.toString());
                }
            }
            if (!file.delete()) {
                StringBuilder d6 = C1012kd.m3195d("Failed to delete secondary dex dir ");
                d6.append(file.getPath());
                Log.w("MultiDex", d6.toString());
                return;
            }
            StringBuilder d7 = C1012kd.m3195d("Deleted old secondary dex dir ");
            d7.append(file.getPath());
            Log.i("MultiDex", d7.toString());
        }
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:34:0x0083 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:60:0x00c6 */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x006a A[Catch:{ RuntimeException -> 0x0061 }, DONT_GENERATE] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x006c A[SYNTHETIC, Splitter:B:25:0x006c] */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m2770c(android.content.Context r6, java.io.File r7, java.io.File r8, java.lang.String r9, java.lang.String r10, boolean r11) {
        /*
            java.util.Set<java.io.File> r0 = f3239a
            monitor-enter(r0)
            boolean r1 = r0.contains(r7)     // Catch:{ all -> 0x00c7 }
            if (r1 == 0) goto L_0x000b
            monitor-exit(r0)     // Catch:{ all -> 0x00c7 }
            return
        L_0x000b:
            r0.add(r7)     // Catch:{ all -> 0x00c7 }
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x00c7 }
            r2 = 20
            if (r1 <= r2) goto L_0x004f
            java.lang.String r3 = "MultiDex"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00c7 }
            r4.<init>()     // Catch:{ all -> 0x00c7 }
            java.lang.String r5 = "MultiDex is not guaranteed to work in SDK version "
            r4.append(r5)     // Catch:{ all -> 0x00c7 }
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = ": SDK version higher than "
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            r4.append(r2)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = " should be backed by "
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = "runtime with built-in multidex capabilty but it's not the "
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = "case here: java.vm.version=\""
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = "java.vm.version"
            java.lang.String r1 = java.lang.System.getProperty(r1)     // Catch:{ all -> 0x00c7 }
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = "\""
            r4.append(r1)     // Catch:{ all -> 0x00c7 }
            java.lang.String r1 = r4.toString()     // Catch:{ all -> 0x00c7 }
            android.util.Log.w(r3, r1)     // Catch:{ all -> 0x00c7 }
        L_0x004f:
            java.lang.String r1 = "MultiDex"
            r2 = 0
            java.lang.ClassLoader r3 = r6.getClassLoader()     // Catch:{ RuntimeException -> 0x0061 }
            boolean r4 = r3 instanceof dalvik.system.BaseDexClassLoader     // Catch:{ all -> 0x00c7 }
            if (r4 == 0) goto L_0x005b
            goto L_0x0068
        L_0x005b:
            java.lang.String r3 = "Context class loader is null or not dex-capable. Must be running in test mode. Skip patching."
            android.util.Log.e(r1, r3)     // Catch:{ all -> 0x00c7 }
            goto L_0x0067
        L_0x0061:
            r3 = move-exception
            java.lang.String r4 = "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching."
            android.util.Log.w(r1, r4, r3)     // Catch:{ all -> 0x00c7 }
        L_0x0067:
            r3 = r2
        L_0x0068:
            if (r3 != 0) goto L_0x006c
            monitor-exit(r0)     // Catch:{ all -> 0x00c7 }
            return
        L_0x006c:
            m2769b(r6)     // Catch:{ all -> 0x0070 }
            goto L_0x0078
        L_0x0070:
            r1 = move-exception
            java.lang.String r4 = "MultiDex"
            java.lang.String r5 = "Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning."
            android.util.Log.w(r4, r5, r1)     // Catch:{ all -> 0x00c7 }
        L_0x0078:
            java.io.File r1 = new java.io.File     // Catch:{ all -> 0x00c7 }
            java.lang.String r4 = "code_cache"
            r1.<init>(r8, r4)     // Catch:{ all -> 0x00c7 }
            m2773f(r1)     // Catch:{ IOException -> 0x0083 }
            goto L_0x008f
        L_0x0083:
            java.io.File r1 = new java.io.File     // Catch:{ all -> 0x00c7 }
            java.io.File r8 = r6.getFilesDir()     // Catch:{ all -> 0x00c7 }
            r1.<init>(r8, r4)     // Catch:{ all -> 0x00c7 }
            m2773f(r1)     // Catch:{ all -> 0x00c7 }
        L_0x008f:
            java.io.File r8 = new java.io.File     // Catch:{ all -> 0x00c7 }
            r8.<init>(r1, r9)     // Catch:{ all -> 0x00c7 }
            m2773f(r8)     // Catch:{ all -> 0x00c7 }
            la r9 = new la     // Catch:{ all -> 0x00c7 }
            r9.<init>(r7, r8)     // Catch:{ all -> 0x00c7 }
            r7 = 0
            java.util.List r7 = r9.mo4409e(r6, r10, r7)     // Catch:{ all -> 0x00c2 }
            m2772e(r3, r8, r7)     // Catch:{ IOException -> 0x00a5 }
            goto L_0x00b7
        L_0x00a5:
            r7 = move-exception
            if (r11 == 0) goto L_0x00c1
            java.lang.String r11 = "MultiDex"
            java.lang.String r1 = "Failed to install extracted secondary dex files, retrying with forced extraction"
            android.util.Log.w(r11, r1, r7)     // Catch:{ all -> 0x00c2 }
            r7 = 1
            java.util.List r6 = r9.mo4409e(r6, r10, r7)     // Catch:{ all -> 0x00c2 }
            m2772e(r3, r8, r6)     // Catch:{ all -> 0x00c2 }
        L_0x00b7:
            r9.close()     // Catch:{ IOException -> 0x00bb }
            goto L_0x00bc
        L_0x00bb:
            r2 = move-exception
        L_0x00bc:
            if (r2 != 0) goto L_0x00c0
            monitor-exit(r0)     // Catch:{ all -> 0x00c7 }
            return
        L_0x00c0:
            throw r2     // Catch:{ all -> 0x00c7 }
        L_0x00c1:
            throw r7     // Catch:{ all -> 0x00c2 }
        L_0x00c2:
            r6 = move-exception
            r9.close()     // Catch:{ IOException -> 0x00c6 }
        L_0x00c6:
            throw r6     // Catch:{ all -> 0x00c7 }
        L_0x00c7:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00c7 }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0880ia.m2770c(android.content.Context, java.io.File, java.io.File, java.lang.String, java.lang.String, boolean):void");
    }

    /* renamed from: d */
    public static Field m2771d(Object obj, String str) {
        Class cls = obj.getClass();
        while (cls != null) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                if (!declaredField.isAccessible()) {
                    declaredField.setAccessible(true);
                }
                return declaredField;
            } catch (NoSuchFieldException unused) {
                cls = cls.getSuperclass();
            }
        }
        throw new NoSuchFieldException("Field " + str + " not found in " + obj.getClass());
    }

    /* renamed from: e */
    public static void m2772e(ClassLoader classLoader, File file, List<? extends File> list) {
        IOException[] iOExceptionArr;
        if (!list.isEmpty()) {
            Object obj = m2771d(classLoader, "pathList").get(classLoader);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList(list);
            Class[] clsArr = {ArrayList.class, File.class, ArrayList.class};
            Class cls = obj.getClass();
            while (cls != null) {
                try {
                    Method declaredMethod = cls.getDeclaredMethod("makeDexElements", clsArr);
                    if (!declaredMethod.isAccessible()) {
                        declaredMethod.setAccessible(true);
                    }
                    m2768a(obj, "dexElements", (Object[]) declaredMethod.invoke(obj, new Object[]{arrayList2, file, arrayList}));
                    if (arrayList.size() > 0) {
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            Log.w("MultiDex", "Exception in makeDexElement", (IOException) it.next());
                        }
                        Field d = m2771d(obj, "dexElementsSuppressedExceptions");
                        IOException[] iOExceptionArr2 = (IOException[]) d.get(obj);
                        if (iOExceptionArr2 == null) {
                            iOExceptionArr = (IOException[]) arrayList.toArray(new IOException[arrayList.size()]);
                        } else {
                            IOException[] iOExceptionArr3 = new IOException[(arrayList.size() + iOExceptionArr2.length)];
                            arrayList.toArray(iOExceptionArr3);
                            System.arraycopy(iOExceptionArr2, 0, iOExceptionArr3, arrayList.size(), iOExceptionArr2.length);
                            iOExceptionArr = iOExceptionArr3;
                        }
                        d.set(obj, iOExceptionArr);
                        IOException iOException = new IOException("I/O exception during makeDexElement");
                        iOException.initCause((Throwable) arrayList.get(0));
                        throw iOException;
                    }
                    return;
                } catch (NoSuchMethodException unused) {
                    cls = cls.getSuperclass();
                }
            }
            throw new NoSuchMethodException("Method " + "makeDexElements" + " with parameters " + Arrays.asList(clsArr) + " not found in " + obj.getClass());
        }
    }

    /* renamed from: f */
    public static void m2773f(File file) {
        String str;
        file.mkdir();
        if (!file.isDirectory()) {
            File parentFile = file.getParentFile();
            if (parentFile == null) {
                StringBuilder d = C1012kd.m3195d("Failed to create dir ");
                d.append(file.getPath());
                d.append(". Parent file is null.");
                str = d.toString();
            } else {
                StringBuilder d2 = C1012kd.m3195d("Failed to create dir ");
                d2.append(file.getPath());
                d2.append(". parent file is a dir ");
                d2.append(parentFile.isDirectory());
                d2.append(", a file ");
                d2.append(parentFile.isFile());
                d2.append(", exists ");
                d2.append(parentFile.exists());
                d2.append(", readable ");
                d2.append(parentFile.canRead());
                d2.append(", writable ");
                d2.append(parentFile.canWrite());
                str = d2.toString();
            }
            Log.e("MultiDex", str);
            StringBuilder d3 = C1012kd.m3195d("Failed to create directory ");
            d3.append(file.getPath());
            throw new IOException(d3.toString());
        }
    }
}
