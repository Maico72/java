package p000;

import android.content.Context;
import android.graphics.Point;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import org.fasaroid.fira.R;

@Deprecated
/* renamed from: bo */
public abstract class C0305bo<T extends View, Z> extends C1819tn<Z> {

    /* renamed from: d */
    public final T f1347d;

    /* renamed from: e */
    public final C0306a f1348e;

    /* renamed from: bo$a */
    public static final class C0306a {

        /* renamed from: d */
        public static Integer f1349d;

        /* renamed from: a */
        public final View f1350a;

        /* renamed from: b */
        public final List<C2231zn> f1351b = new ArrayList();

        /* renamed from: c */
        public C0307a f1352c;

        /* renamed from: bo$a$a */
        public static final class C0307a implements ViewTreeObserver.OnPreDrawListener {

            /* renamed from: d */
            public final WeakReference<C0306a> f1353d;

            public C0307a(C0306a aVar) {
                this.f1353d = new WeakReference<>(aVar);
            }

            public boolean onPreDraw() {
                if (Log.isLoggable("ViewTarget", 2)) {
                    Log.v("ViewTarget", "OnGlobalLayoutListener called attachStateListener=" + this);
                }
                C0306a aVar = (C0306a) this.f1353d.get();
                if (aVar == null || aVar.f1351b.isEmpty()) {
                    return true;
                }
                int d = aVar.mo1723d();
                int c = aVar.mo1722c();
                if (!aVar.mo1724e(d, c)) {
                    return true;
                }
                Iterator it = new ArrayList(aVar.f1351b).iterator();
                while (it.hasNext()) {
                    ((C2231zn) it.next()).mo5720b(d, c);
                }
                aVar.mo1720a();
                return true;
            }
        }

        public C0306a(View view) {
            this.f1350a = view;
        }

        /* renamed from: a */
        public void mo1720a() {
            ViewTreeObserver viewTreeObserver = this.f1350a.getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeOnPreDrawListener(this.f1352c);
            }
            this.f1352c = null;
            this.f1351b.clear();
        }

        /* renamed from: b */
        public final int mo1721b(int i, int i2, int i3) {
            int i4 = i2 - i3;
            if (i4 > 0) {
                return i4;
            }
            int i5 = i - i3;
            if (i5 > 0) {
                return i5;
            }
            if (this.f1350a.isLayoutRequested() || i2 != -2) {
                return 0;
            }
            if (Log.isLoggable("ViewTarget", 4)) {
                Log.i("ViewTarget", "Glide treats LayoutParams.WRAP_CONTENT as a request for an image the size of this device's screen dimensions. If you want to load the original image and are ok with the corresponding memory cost and OOMs (depending on the input size), use override(Target.SIZE_ORIGINAL). Otherwise, use LayoutParams.MATCH_PARENT, set layout_width and layout_height to fixed dimension, or use .override() with fixed dimensions.");
            }
            Context context = this.f1350a.getContext();
            if (f1349d == null) {
                WindowManager windowManager = (WindowManager) context.getSystemService("window");
                Objects.requireNonNull(windowManager, "Argument must not be null");
                Display defaultDisplay = windowManager.getDefaultDisplay();
                Point point = new Point();
                defaultDisplay.getSize(point);
                f1349d = Integer.valueOf(Math.max(point.x, point.y));
            }
            return f1349d.intValue();
        }

        /* renamed from: c */
        public final int mo1722c() {
            int paddingBottom = this.f1350a.getPaddingBottom() + this.f1350a.getPaddingTop();
            ViewGroup.LayoutParams layoutParams = this.f1350a.getLayoutParams();
            return mo1721b(this.f1350a.getHeight(), layoutParams != null ? layoutParams.height : 0, paddingBottom);
        }

        /* renamed from: d */
        public final int mo1723d() {
            int paddingRight = this.f1350a.getPaddingRight() + this.f1350a.getPaddingLeft();
            ViewGroup.LayoutParams layoutParams = this.f1350a.getLayoutParams();
            return mo1721b(this.f1350a.getWidth(), layoutParams != null ? layoutParams.width : 0, paddingRight);
        }

        /* renamed from: e */
        public final boolean mo1724e(int i, int i2) {
            if (i > 0 || i == Integer.MIN_VALUE) {
                if (i2 > 0 || i2 == Integer.MIN_VALUE) {
                    return true;
                }
            }
            return false;
        }
    }

    public C0305bo(T t) {
        Objects.requireNonNull(t, "Argument must not be null");
        this.f1347d = t;
        this.f1348e = new C0306a(t);
    }

    /* renamed from: a */
    public void mo1428a(C2231zn znVar) {
        this.f1348e.f1351b.remove(znVar);
    }

    /* renamed from: f */
    public C1197mn mo1432f() {
        Object tag = this.f1347d.getTag(R.id.glide_custom_view_target_tag);
        if (tag == null) {
            return null;
        }
        if (tag instanceof C1197mn) {
            return (C1197mn) tag;
        }
        throw new IllegalArgumentException("You must not call setTag() on a view Glide is targeting");
    }

    /* renamed from: h */
    public void mo1434h(C2231zn znVar) {
        C0306a aVar = this.f1348e;
        int d = aVar.mo1723d();
        int c = aVar.mo1722c();
        if (aVar.mo1724e(d, c)) {
            ((C1683rn) znVar).mo5720b(d, c);
            return;
        }
        if (!aVar.f1351b.contains(znVar)) {
            aVar.f1351b.add(znVar);
        }
        if (aVar.f1352c == null) {
            ViewTreeObserver viewTreeObserver = aVar.f1350a.getViewTreeObserver();
            C0306a.C0307a aVar2 = new C0306a.C0307a(aVar);
            aVar.f1352c = aVar2;
            viewTreeObserver.addOnPreDrawListener(aVar2);
        }
    }

    /* renamed from: j */
    public void mo1435j(C1197mn mnVar) {
        this.f1347d.setTag(R.id.glide_custom_view_target_tag, mnVar);
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("Target for: ");
        d.append(this.f1347d);
        return d.toString();
    }
}
