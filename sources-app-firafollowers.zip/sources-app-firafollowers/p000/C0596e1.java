package p000;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;
import org.fasaroid.fira.R;
import p000.C0003a1;

/* renamed from: e1 */
public final class C0596e1 extends C2107y0 implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, C0003a1, View.OnKeyListener {

    /* renamed from: e */
    public final Context f2414e;

    /* renamed from: f */
    public final C1838u0 f2415f;

    /* renamed from: g */
    public final C1773t0 f2416g;

    /* renamed from: h */
    public final boolean f2417h;

    /* renamed from: i */
    public final int f2418i;

    /* renamed from: j */
    public final int f2419j;

    /* renamed from: k */
    public final int f2420k;

    /* renamed from: l */
    public final C1653r2 f2421l;

    /* renamed from: m */
    public final ViewTreeObserver.OnGlobalLayoutListener f2422m = new C0597a();

    /* renamed from: n */
    public final View.OnAttachStateChangeListener f2423n = new C0598b();

    /* renamed from: o */
    public PopupWindow.OnDismissListener f2424o;

    /* renamed from: p */
    public View f2425p;

    /* renamed from: q */
    public View f2426q;

    /* renamed from: r */
    public C0003a1.C0004a f2427r;

    /* renamed from: s */
    public ViewTreeObserver f2428s;

    /* renamed from: t */
    public boolean f2429t;

    /* renamed from: u */
    public boolean f2430u;

    /* renamed from: v */
    public int f2431v;

    /* renamed from: w */
    public int f2432w = 0;

    /* renamed from: x */
    public boolean f2433x;

    /* renamed from: e1$a */
    public class C0597a implements ViewTreeObserver.OnGlobalLayoutListener {
        public C0597a() {
        }

        public void onGlobalLayout() {
            if (C0596e1.this.mo2858b()) {
                C0596e1 e1Var = C0596e1.this;
                if (!e1Var.f2421l.f4742B) {
                    View view = e1Var.f2426q;
                    if (view == null || !view.isShown()) {
                        C0596e1.this.dismiss();
                    } else {
                        C0596e1.this.f2421l.mo2860f();
                    }
                }
            }
        }
    }

    /* renamed from: e1$b */
    public class C0598b implements View.OnAttachStateChangeListener {
        public C0598b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = C0596e1.this.f2428s;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    C0596e1.this.f2428s = view.getViewTreeObserver();
                }
                C0596e1 e1Var = C0596e1.this;
                e1Var.f2428s.removeGlobalOnLayoutListener(e1Var.f2422m);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public C0596e1(Context context, C1838u0 u0Var, View view, int i, int i2, boolean z) {
        this.f2414e = context;
        this.f2415f = u0Var;
        this.f2417h = z;
        this.f2416g = new C1773t0(u0Var, LayoutInflater.from(context), z, R.layout.abc_popup_menu_item_layout);
        this.f2419j = i;
        this.f2420k = i2;
        Resources resources = context.getResources();
        this.f2418i = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f2425p = view;
        this.f2421l = new C1653r2(context, (AttributeSet) null, i, i2);
        u0Var.mo6066b(this, context);
    }

    /* renamed from: a */
    public void mo6a(C1838u0 u0Var, boolean z) {
        if (u0Var == this.f2415f) {
            dismiss();
            C0003a1.C0004a aVar = this.f2427r;
            if (aVar != null) {
                aVar.mo14a(u0Var, z);
            }
        }
    }

    /* renamed from: b */
    public boolean mo2858b() {
        return !this.f2429t && this.f2421l.mo2858b();
    }

    /* renamed from: c */
    public boolean mo7c() {
        return false;
    }

    public void dismiss() {
        if (mo2858b()) {
            this.f2421l.dismiss();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x00c9 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00ca  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2860f() {
        /*
            r7 = this;
            boolean r0 = r7.mo2858b()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x000b
        L_0x0008:
            r1 = 1
            goto L_0x00c7
        L_0x000b:
            boolean r0 = r7.f2429t
            if (r0 != 0) goto L_0x00c7
            android.view.View r0 = r7.f2425p
            if (r0 != 0) goto L_0x0015
            goto L_0x00c7
        L_0x0015:
            r7.f2426q = r0
            r2 r0 = r7.f2421l
            android.widget.PopupWindow r0 = r0.f4743C
            r0.setOnDismissListener(r7)
            r2 r0 = r7.f2421l
            r0.f4760t = r7
            r0.mo5169s(r2)
            android.view.View r0 = r7.f2426q
            android.view.ViewTreeObserver r3 = r7.f2428s
            if (r3 != 0) goto L_0x002d
            r3 = 1
            goto L_0x002e
        L_0x002d:
            r3 = 0
        L_0x002e:
            android.view.ViewTreeObserver r4 = r0.getViewTreeObserver()
            r7.f2428s = r4
            if (r3 == 0) goto L_0x003b
            android.view.ViewTreeObserver$OnGlobalLayoutListener r3 = r7.f2422m
            r4.addOnGlobalLayoutListener(r3)
        L_0x003b:
            android.view.View$OnAttachStateChangeListener r3 = r7.f2423n
            r0.addOnAttachStateChangeListener(r3)
            r2 r3 = r7.f2421l
            r3.f4759s = r0
            int r0 = r7.f2432w
            r3.f4755o = r0
            boolean r0 = r7.f2430u
            r3 = 0
            if (r0 != 0) goto L_0x005b
            t0 r0 = r7.f2416g
            android.content.Context r4 = r7.f2414e
            int r5 = r7.f2418i
            int r0 = p000.C2107y0.m5756n(r0, r3, r4, r5)
            r7.f2431v = r0
            r7.f2430u = r2
        L_0x005b:
            r2 r0 = r7.f2421l
            int r4 = r7.f2431v
            r0.mo5168r(r4)
            r2 r0 = r7.f2421l
            r4 = 2
            android.widget.PopupWindow r0 = r0.f4743C
            r0.setInputMethodMode(r4)
            r2 r0 = r7.f2421l
            android.graphics.Rect r4 = r7.f6834d
            java.util.Objects.requireNonNull(r0)
            if (r4 == 0) goto L_0x0079
            android.graphics.Rect r5 = new android.graphics.Rect
            r5.<init>(r4)
            goto L_0x007a
        L_0x0079:
            r5 = r3
        L_0x007a:
            r0.f4741A = r5
            r2 r0 = r7.f2421l
            r0.mo2860f()
            r2 r0 = r7.f2421l
            k2 r0 = r0.f4746f
            r0.setOnKeyListener(r7)
            boolean r4 = r7.f2433x
            if (r4 == 0) goto L_0x00b9
            u0 r4 = r7.f2415f
            java.lang.CharSequence r4 = r4.f6088m
            if (r4 == 0) goto L_0x00b9
            android.content.Context r4 = r7.f2414e
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r5 = 2131492882(0x7f0c0012, float:1.8609228E38)
            android.view.View r4 = r4.inflate(r5, r0, r1)
            android.widget.FrameLayout r4 = (android.widget.FrameLayout) r4
            r5 = 16908310(0x1020016, float:2.387729E-38)
            android.view.View r5 = r4.findViewById(r5)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x00b3
            u0 r6 = r7.f2415f
            java.lang.CharSequence r6 = r6.f6088m
            r5.setText(r6)
        L_0x00b3:
            r4.setEnabled(r1)
            r0.addHeaderView(r4, r3, r1)
        L_0x00b9:
            r2 r0 = r7.f2421l
            t0 r1 = r7.f2416g
            r0.mo1548o(r1)
            r2 r0 = r7.f2421l
            r0.mo2860f()
            goto L_0x0008
        L_0x00c7:
            if (r1 == 0) goto L_0x00ca
            return
        L_0x00ca:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "StandardMenuPopup cannot be used without an anchor"
            r0.<init>(r1)
            goto L_0x00d3
        L_0x00d2:
            throw r0
        L_0x00d3:
            goto L_0x00d2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0596e1.mo2860f():void");
    }

    /* renamed from: h */
    public void mo11h(C0003a1.C0004a aVar) {
        this.f2427r = aVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0070  */
    /* renamed from: i */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo12i(p000.C0662f1 r10) {
        /*
            r9 = this;
            boolean r0 = r10.hasVisibleItems()
            r1 = 0
            if (r0 == 0) goto L_0x0078
            z0 r0 = new z0
            android.content.Context r3 = r9.f2414e
            android.view.View r5 = r9.f2426q
            boolean r6 = r9.f2417h
            int r7 = r9.f2419j
            int r8 = r9.f2420k
            r2 = r0
            r4 = r10
            r2.<init>(r3, r4, r5, r6, r7, r8)
            a1$a r2 = r9.f2427r
            r0.mo6724d(r2)
            boolean r2 = p000.C2107y0.m5757v(r10)
            r0.f7030h = r2
            y0 r3 = r0.f7032j
            if (r3 == 0) goto L_0x002a
            r3.mo3170p(r2)
        L_0x002a:
            android.widget.PopupWindow$OnDismissListener r2 = r9.f2424o
            r0.f7033k = r2
            r2 = 0
            r9.f2424o = r2
            u0 r2 = r9.f2415f
            r2.mo6067c(r1)
            r2 r2 = r9.f2421l
            int r3 = r2.f4749i
            boolean r4 = r2.f4752l
            if (r4 != 0) goto L_0x0040
            r2 = 0
            goto L_0x0042
        L_0x0040:
            int r2 = r2.f4750j
        L_0x0042:
            int r4 = r9.f2432w
            android.view.View r5 = r9.f2425p
            java.util.WeakHashMap<android.view.View, java.lang.String> r6 = p000.C0010a7.f28a
            int r5 = r5.getLayoutDirection()
            int r4 = android.view.Gravity.getAbsoluteGravity(r4, r5)
            r4 = r4 & 7
            r5 = 5
            if (r4 != r5) goto L_0x005c
            android.view.View r4 = r9.f2425p
            int r4 = r4.getWidth()
            int r3 = r3 + r4
        L_0x005c:
            boolean r4 = r0.mo6723b()
            r5 = 1
            if (r4 == 0) goto L_0x0064
            goto L_0x006d
        L_0x0064:
            android.view.View r4 = r0.f7028f
            if (r4 != 0) goto L_0x006a
            r0 = 0
            goto L_0x006e
        L_0x006a:
            r0.mo6725e(r3, r2, r5, r5)
        L_0x006d:
            r0 = 1
        L_0x006e:
            if (r0 == 0) goto L_0x0078
            a1$a r0 = r9.f2427r
            if (r0 == 0) goto L_0x0077
            r0.mo15b(r10)
        L_0x0077:
            return r5
        L_0x0078:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0596e1.mo12i(f1):boolean");
    }

    /* renamed from: j */
    public void mo13j(boolean z) {
        this.f2430u = false;
        C1773t0 t0Var = this.f2416g;
        if (t0Var != null) {
            t0Var.notifyDataSetChanged();
        }
    }

    /* renamed from: k */
    public ListView mo2861k() {
        return this.f2421l.f4746f;
    }

    /* renamed from: l */
    public void mo3166l(C1838u0 u0Var) {
    }

    /* renamed from: o */
    public void mo3167o(View view) {
        this.f2425p = view;
    }

    public void onDismiss() {
        this.f2429t = true;
        this.f2415f.mo6067c(true);
        ViewTreeObserver viewTreeObserver = this.f2428s;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f2428s = this.f2426q.getViewTreeObserver();
            }
            this.f2428s.removeGlobalOnLayoutListener(this.f2422m);
            this.f2428s = null;
        }
        this.f2426q.removeOnAttachStateChangeListener(this.f2423n);
        PopupWindow.OnDismissListener onDismissListener = this.f2424o;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    /* renamed from: p */
    public void mo3170p(boolean z) {
        this.f2416g.f5809f = z;
    }

    /* renamed from: q */
    public void mo3171q(int i) {
        this.f2432w = i;
    }

    /* renamed from: r */
    public void mo3172r(int i) {
        this.f2421l.f4749i = i;
    }

    /* renamed from: s */
    public void mo3173s(PopupWindow.OnDismissListener onDismissListener) {
        this.f2424o = onDismissListener;
    }

    /* renamed from: t */
    public void mo3174t(boolean z) {
        this.f2433x = z;
    }

    /* renamed from: u */
    public void mo3175u(int i) {
        C1653r2 r2Var = this.f2421l;
        r2Var.f4750j = i;
        r2Var.f4752l = true;
    }
}
