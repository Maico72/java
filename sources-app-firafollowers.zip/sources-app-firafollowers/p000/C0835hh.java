package p000;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import p000.C0560dh;
import p000.C1117lh;
import p000.C1685ro;
import p000.C1877uo;

/* renamed from: hh */
public class C0835hh<R> implements C0560dh.C0561a<R>, C1685ro.C1689d {

    /* renamed from: C */
    public static final C0838c f3106C = new C0838c();

    /* renamed from: A */
    public volatile boolean f3107A;

    /* renamed from: B */
    public boolean f3108B;

    /* renamed from: d */
    public final C0840e f3109d = new C0840e();

    /* renamed from: e */
    public final C1877uo f3110e = new C1877uo.C1879b();

    /* renamed from: f */
    public final C1117lh.C1118a f3111f;

    /* renamed from: g */
    public final C0940j6<C0835hh<?>> f3112g;

    /* renamed from: h */
    public final C0838c f3113h;

    /* renamed from: i */
    public final C0893ih f3114i;

    /* renamed from: j */
    public final C1941vi f3115j;

    /* renamed from: k */
    public final C1941vi f3116k;

    /* renamed from: l */
    public final C1941vi f3117l;

    /* renamed from: m */
    public final C1941vi f3118m;

    /* renamed from: n */
    public final AtomicInteger f3119n = new AtomicInteger();

    /* renamed from: o */
    public C2005wf f3120o;

    /* renamed from: p */
    public boolean f3121p;

    /* renamed from: q */
    public boolean f3122q;

    /* renamed from: r */
    public boolean f3123r;

    /* renamed from: s */
    public boolean f3124s;

    /* renamed from: t */
    public C1675rh<?> f3125t;

    /* renamed from: u */
    public C1017kf f3126u;

    /* renamed from: v */
    public boolean f3127v;

    /* renamed from: w */
    public C1182mh f3128w;

    /* renamed from: x */
    public boolean f3129x;

    /* renamed from: y */
    public C1117lh<?> f3130y;

    /* renamed from: z */
    public C0560dh<R> f3131z;

    /* renamed from: hh$a */
    public class C0836a implements Runnable {

        /* renamed from: d */
        public final C1623qn f3132d;

        public C0836a(C1623qn qnVar) {
            this.f3132d = qnVar;
        }

        public void run() {
            C1683rn rnVar = (C1683rn) this.f3132d;
            rnVar.f5491b.mo6134a();
            synchronized (rnVar.f5492c) {
                synchronized (C0835hh.this) {
                    if (C0835hh.this.f3109d.f3138d.contains(new C0839d(this.f3132d, C1132lo.f3924b))) {
                        C0835hh hhVar = C0835hh.this;
                        C1623qn qnVar = this.f3132d;
                        Objects.requireNonNull(hhVar);
                        try {
                            ((C1683rn) qnVar).mo5728o(hhVar.f3128w, 5);
                        } catch (Throwable th) {
                            throw new C2070xg(th);
                        }
                    }
                    C0835hh.this.mo3935d();
                }
            }
        }
    }

    /* renamed from: hh$b */
    public class C0837b implements Runnable {

        /* renamed from: d */
        public final C1623qn f3134d;

        public C0837b(C1623qn qnVar) {
            this.f3134d = qnVar;
        }

        public void run() {
            C1683rn rnVar = (C1683rn) this.f3134d;
            rnVar.f5491b.mo6134a();
            synchronized (rnVar.f5492c) {
                synchronized (C0835hh.this) {
                    if (C0835hh.this.f3109d.f3138d.contains(new C0839d(this.f3134d, C1132lo.f3924b))) {
                        C0835hh.this.f3130y.mo4439a();
                        C0835hh hhVar = C0835hh.this;
                        C1623qn qnVar = this.f3134d;
                        Objects.requireNonNull(hhVar);
                        try {
                            ((C1683rn) qnVar).mo5729p(hhVar.f3130y, hhVar.f3126u, hhVar.f3108B);
                            C0835hh.this.mo3939h(this.f3134d);
                        } catch (Throwable th) {
                            throw new C2070xg(th);
                        }
                    }
                    C0835hh.this.mo3935d();
                }
            }
        }
    }

    /* renamed from: hh$c */
    public static class C0838c {
    }

    /* renamed from: hh$d */
    public static final class C0839d {

        /* renamed from: a */
        public final C1623qn f3136a;

        /* renamed from: b */
        public final Executor f3137b;

        public C0839d(C1623qn qnVar, Executor executor) {
            this.f3136a = qnVar;
            this.f3137b = executor;
        }

        public boolean equals(Object obj) {
            if (obj instanceof C0839d) {
                return this.f3136a.equals(((C0839d) obj).f3136a);
            }
            return false;
        }

        public int hashCode() {
            return this.f3136a.hashCode();
        }
    }

    /* renamed from: hh$e */
    public static final class C0840e implements Iterable<C0839d> {

        /* renamed from: d */
        public final List<C0839d> f3138d = new ArrayList(2);

        public boolean isEmpty() {
            return this.f3138d.isEmpty();
        }

        public Iterator<C0839d> iterator() {
            return this.f3138d.iterator();
        }
    }

    public C0835hh(C1941vi viVar, C1941vi viVar2, C1941vi viVar3, C1941vi viVar4, C0893ih ihVar, C1117lh.C1118a aVar, C0940j6<C0835hh<?>> j6Var) {
        C0838c cVar = f3106C;
        this.f3115j = viVar;
        this.f3116k = viVar2;
        this.f3117l = viVar3;
        this.f3118m = viVar4;
        this.f3114i = ihVar;
        this.f3111f = aVar;
        this.f3112g = j6Var;
        this.f3113h = cVar;
    }

    /* renamed from: a */
    public C1877uo mo3052a() {
        return this.f3110e;
    }

    /* renamed from: b */
    public synchronized void mo3933b(C1623qn qnVar, Executor executor) {
        Runnable runnable;
        this.f3110e.mo6134a();
        this.f3109d.f3138d.add(new C0839d(qnVar, executor));
        boolean z = true;
        if (this.f3127v) {
            mo3936e(1);
            runnable = new C0837b(qnVar);
        } else if (this.f3129x) {
            mo3936e(1);
            runnable = new C0836a(qnVar);
        } else {
            if (this.f3107A) {
                z = false;
            }
            C1401p4.m4354c(z, "Cannot add callbacks to a cancelled EngineJob");
        }
        executor.execute(runnable);
    }

    /* renamed from: c */
    public void mo3934c() {
        if (!mo3937f()) {
            this.f3107A = true;
            C0560dh<R> dhVar = this.f3131z;
            dhVar.f2260H = true;
            C0289bh bhVar = dhVar.f2258F;
            if (bhVar != null) {
                bhVar.cancel();
            }
            C0893ih ihVar = this.f3114i;
            C2005wf wfVar = this.f3120o;
            C0770gh ghVar = (C0770gh) ihVar;
            synchronized (ghVar) {
                C1342oh ohVar = ghVar.f2936a;
                Objects.requireNonNull(ohVar);
                Map<C2005wf, C0835hh<?>> a = ohVar.mo5057a(this.f3124s);
                if (equals(a.get(wfVar))) {
                    a.remove(wfVar);
                }
            }
        }
    }

    /* renamed from: d */
    public void mo3935d() {
        C1117lh<?> lhVar;
        synchronized (this) {
            this.f3110e.mo6134a();
            C1401p4.m4354c(mo3937f(), "Not yet complete!");
            int decrementAndGet = this.f3119n.decrementAndGet();
            C1401p4.m4354c(decrementAndGet >= 0, "Can't decrement below 0");
            if (decrementAndGet == 0) {
                lhVar = this.f3130y;
                mo3938g();
            } else {
                lhVar = null;
            }
        }
        if (lhVar != null) {
            lhVar.mo4440f();
        }
    }

    /* renamed from: e */
    public synchronized void mo3936e(int i) {
        C1117lh<?> lhVar;
        C1401p4.m4354c(mo3937f(), "Not yet complete!");
        if (this.f3119n.getAndAdd(i) == 0 && (lhVar = this.f3130y) != null) {
            lhVar.mo4439a();
        }
    }

    /* renamed from: f */
    public final boolean mo3937f() {
        return this.f3129x || this.f3127v || this.f3107A;
    }

    /* renamed from: g */
    public final synchronized void mo3938g() {
        boolean a;
        if (this.f3120o != null) {
            this.f3109d.f3138d.clear();
            this.f3120o = null;
            this.f3130y = null;
            this.f3125t = null;
            this.f3129x = false;
            this.f3107A = false;
            this.f3127v = false;
            this.f3108B = false;
            C0560dh<R> dhVar = this.f3131z;
            C0560dh.C0565e eVar = dhVar.f2268j;
            synchronized (eVar) {
                eVar.f2290a = true;
                a = eVar.mo3066a(false);
            }
            if (a) {
                dhVar.mo3061l();
            }
            this.f3131z = null;
            this.f3128w = null;
            this.f3126u = null;
            this.f3112g.mo4123a(this);
        } else {
            throw new IllegalArgumentException();
        }
    }

    /* renamed from: h */
    public synchronized void mo3939h(C1623qn qnVar) {
        boolean z;
        this.f3110e.mo6134a();
        this.f3109d.f3138d.remove(new C0839d(qnVar, C1132lo.f3924b));
        if (this.f3109d.isEmpty()) {
            mo3934c();
            if (!this.f3127v) {
                if (!this.f3129x) {
                    z = false;
                    if (z && this.f3119n.get() == 0) {
                        mo3938g();
                    }
                }
            }
            z = true;
            mo3938g();
        }
    }

    /* renamed from: i */
    public void mo3940i(C0560dh<?> dhVar) {
        (this.f3122q ? this.f3117l : this.f3123r ? this.f3118m : this.f3116k).f6395a.execute(dhVar);
    }
}
