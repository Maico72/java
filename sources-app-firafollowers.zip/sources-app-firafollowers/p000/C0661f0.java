package p000;

/* renamed from: f0 */
public final class C0661f0 {

    /* renamed from: a */
    public static final int[] f2621a = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};

    /* renamed from: b */
    public static final int[] f2622b = {16842960, 16843161};

    /* renamed from: c */
    public static final int[] f2623c = {16843161, 16843849, 16843850, 16843851};
}
