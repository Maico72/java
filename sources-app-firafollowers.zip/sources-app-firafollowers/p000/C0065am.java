package p000;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicReference;
import p000.C0847ho;

/* renamed from: am */
public class C0065am implements C0303bm<C1452pl, byte[]> {
    /* renamed from: a */
    public C1675rh<byte[]> mo149a(C1675rh<C1452pl> rhVar, C2150yf yfVar) {
        byte[] bArr;
        ByteBuffer asReadOnlyBuffer = rhVar.mo1714b().f4903d.f4913a.f5987a.mo3588g().asReadOnlyBuffer();
        AtomicReference<byte[]> atomicReference = C0847ho.f3143a;
        C0847ho.C0849b bVar = (asReadOnlyBuffer.isReadOnly() || !asReadOnlyBuffer.hasArray()) ? null : new C0847ho.C0849b(asReadOnlyBuffer.array(), asReadOnlyBuffer.arrayOffset(), asReadOnlyBuffer.limit());
        if (bVar != null && bVar.f3146a == 0 && bVar.f3147b == bVar.f3148c.length) {
            bArr = asReadOnlyBuffer.array();
        } else {
            ByteBuffer asReadOnlyBuffer2 = asReadOnlyBuffer.asReadOnlyBuffer();
            byte[] bArr2 = new byte[asReadOnlyBuffer2.limit()];
            asReadOnlyBuffer2.position(0);
            asReadOnlyBuffer2.get(bArr2);
            bArr = bArr2;
        }
        return new C0707fl(bArr);
    }
}
