package p000;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import p000.C1029kp;

@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: ct */
public @interface C0511ct {

    /* renamed from: ct$a */
    public @interface C0512a {
        C1029kp.C1030a include() default C1029kp.C1030a.f3661e;

        String propName() default "";

        String propNamespace() default "";

        boolean required() default false;

        String value();
    }

    /* renamed from: ct$b */
    public @interface C0513b {
        C1029kp.C1030a include() default C1029kp.C1030a.f3661e;

        String name() default "";

        String namespace() default "";

        boolean required() default false;

        Class<?> type() default Object.class;

        Class<? extends C0797gx> value();
    }

    C0512a[] attrs() default {};

    boolean prepend() default false;

    C0513b[] props() default {};
}
