package p000;

import p000.C2090xp;

/* renamed from: fw */
public class C0722fw extends C1281nw {
    public C0722fw(C2167yv yvVar, C0714fs fsVar) {
        super(yvVar, fsVar);
    }

    /* renamed from: a */
    public C0230aw mo1474a(C0714fs fsVar) {
        return this.f4378b == fsVar ? this : new C0722fw(this.f4377a, fsVar);
    }

    /* renamed from: c */
    public C2090xp.C2091a mo1476c() {
        return C2090xp.C2091a.WRAPPER_OBJECT;
    }
}
