package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: g1 */
public class C0729g1 extends C0325c1 implements SubMenu {

    /* renamed from: e */
    public final C1981w5 f2807e;

    public C0729g1(Context context, C1981w5 w5Var) {
        super(context, w5Var);
        this.f2807e = w5Var;
    }

    public void clearHeader() {
        this.f2807e.clearHeader();
    }

    public MenuItem getItem() {
        return mo5297c(this.f2807e.getItem());
    }

    public SubMenu setHeaderIcon(int i) {
        this.f2807e.setHeaderIcon(i);
        return this;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        this.f2807e.setHeaderIcon(drawable);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        this.f2807e.setHeaderTitle(i);
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        this.f2807e.setHeaderTitle(charSequence);
        return this;
    }

    public SubMenu setHeaderView(View view) {
        this.f2807e.setHeaderView(view);
        return this;
    }

    public SubMenu setIcon(int i) {
        this.f2807e.setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f2807e.setIcon(drawable);
        return this;
    }
}
