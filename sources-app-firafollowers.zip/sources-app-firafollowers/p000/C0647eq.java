package p000;

/* renamed from: eq */
public abstract class C0647eq extends C0581dq<Object> {
}
