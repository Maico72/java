package p000;

/* renamed from: ca */
public interface C0347ca {
}
