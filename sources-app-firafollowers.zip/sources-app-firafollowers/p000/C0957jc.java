package p000;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;
import p000.C0545dc;

/* renamed from: jc */
public class C0957jc extends C0545dc {

    /* renamed from: A */
    public ArrayList<C0545dc> f3393A = new ArrayList<>();

    /* renamed from: B */
    public boolean f3394B = true;

    /* renamed from: C */
    public int f3395C;

    /* renamed from: D */
    public boolean f3396D = false;

    /* renamed from: E */
    public int f3397E = 0;

    /* renamed from: jc$a */
    public class C0958a extends C0743gc {

        /* renamed from: a */
        public final /* synthetic */ C0545dc f3398a;

        public C0958a(C0957jc jcVar, C0545dc dcVar) {
            this.f3398a = dcVar;
        }

        /* renamed from: d */
        public void mo3021d(C0545dc dcVar) {
            this.f3398a.mo3015y();
            dcVar.mo3012v(this);
        }
    }

    /* renamed from: jc$b */
    public static class C0959b extends C0743gc {

        /* renamed from: a */
        public C0957jc f3399a;

        public C0959b(C0957jc jcVar) {
            this.f3399a = jcVar;
        }

        /* renamed from: c */
        public void mo3020c(C0545dc dcVar) {
            C0957jc jcVar = this.f3399a;
            if (!jcVar.f3396D) {
                jcVar.mo2990F();
                this.f3399a.f3396D = true;
            }
        }

        /* renamed from: d */
        public void mo3021d(C0545dc dcVar) {
            C0957jc jcVar = this.f3399a;
            int i = jcVar.f3395C - 1;
            jcVar.f3395C = i;
            if (i == 0) {
                jcVar.f3396D = false;
                jcVar.mo3004m();
            }
            dcVar.mo3012v(this);
        }
    }

    /* renamed from: A */
    public void mo2985A(C0545dc.C0548c cVar) {
        this.f2224v = cVar;
        this.f3397E |= 8;
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            this.f3393A.get(i).mo2985A(cVar);
        }
    }

    /* renamed from: B */
    public C0545dc mo2986B(TimeInterpolator timeInterpolator) {
        this.f3397E |= 1;
        ArrayList<C0545dc> arrayList = this.f3393A;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.f3393A.get(i).mo2986B(timeInterpolator);
            }
        }
        this.f2209g = timeInterpolator;
        return this;
    }

    /* renamed from: C */
    public void mo2987C(C2204zb zbVar) {
        this.f2225w = zbVar == null ? C0545dc.f2204y : zbVar;
        this.f3397E |= 4;
        for (int i = 0; i < this.f3393A.size(); i++) {
            this.f3393A.get(i).mo2987C(zbVar);
        }
    }

    /* renamed from: D */
    public void mo2988D(C0884ic icVar) {
        this.f3397E |= 2;
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            this.f3393A.get(i).mo2988D(icVar);
        }
    }

    /* renamed from: E */
    public C0545dc mo2989E(long j) {
        this.f2207e = j;
        return this;
    }

    /* renamed from: G */
    public String mo2991G(String str) {
        String G = super.mo2991G(str);
        for (int i = 0; i < this.f3393A.size(); i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(G);
            sb.append("\n");
            sb.append(this.f3393A.get(i).mo2991G(str + "  "));
            G = sb.toString();
        }
        return G;
    }

    /* renamed from: H */
    public C0957jc mo4154H(C0545dc dcVar) {
        this.f3393A.add(dcVar);
        dcVar.f2214l = this;
        long j = this.f2208f;
        if (j >= 0) {
            dcVar.mo3016z(j);
        }
        if ((this.f3397E & 1) != 0) {
            dcVar.mo2986B(this.f2209g);
        }
        if ((this.f3397E & 2) != 0) {
            dcVar.mo2988D((C0884ic) null);
        }
        if ((this.f3397E & 4) != 0) {
            dcVar.mo2987C(this.f2225w);
        }
        if ((this.f3397E & 8) != 0) {
            dcVar.mo2985A(this.f2224v);
        }
        return this;
    }

    /* renamed from: I */
    public C0545dc mo4155I(int i) {
        if (i < 0 || i >= this.f3393A.size()) {
            return null;
        }
        return this.f3393A.get(i);
    }

    /* renamed from: J */
    public C0957jc mo4156J(int i) {
        if (i == 0) {
            this.f3394B = true;
        } else if (i == 1) {
            this.f3394B = false;
        } else {
            throw new AndroidRuntimeException(C1012kd.m3199h("Invalid parameter for TransitionSet ordering: ", i));
        }
        return this;
    }

    /* renamed from: a */
    public C0545dc mo2992a(C0545dc.C0549d dVar) {
        super.mo2992a(dVar);
        return this;
    }

    /* renamed from: b */
    public C0545dc mo2993b(View view) {
        for (int i = 0; i < this.f3393A.size(); i++) {
            this.f3393A.get(i).mo2993b(view);
        }
        this.f2211i.add(view);
        return this;
    }

    /* renamed from: d */
    public void mo2995d(C1104lc lcVar) {
        if (mo3009s(lcVar.f3869b)) {
            Iterator<C0545dc> it = this.f3393A.iterator();
            while (it.hasNext()) {
                C0545dc next = it.next();
                if (next.mo3009s(lcVar.f3869b)) {
                    next.mo2995d(lcVar);
                    lcVar.f3870c.add(next);
                }
            }
        }
    }

    /* renamed from: f */
    public void mo2997f(C1104lc lcVar) {
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            this.f3393A.get(i).mo2997f(lcVar);
        }
    }

    /* renamed from: g */
    public void mo2998g(C1104lc lcVar) {
        if (mo3009s(lcVar.f3869b)) {
            Iterator<C0545dc> it = this.f3393A.iterator();
            while (it.hasNext()) {
                C0545dc next = it.next();
                if (next.mo3009s(lcVar.f3869b)) {
                    next.mo2998g(lcVar);
                    lcVar.f3870c.add(next);
                }
            }
        }
    }

    /* renamed from: j */
    public C0545dc clone() {
        C0957jc jcVar = (C0957jc) super.clone();
        jcVar.f3393A = new ArrayList<>();
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            jcVar.mo4154H(this.f3393A.get(i).clone());
        }
        return jcVar;
    }

    /* renamed from: l */
    public void mo3003l(ViewGroup viewGroup, C1174mc mcVar, C1174mc mcVar2, ArrayList<C1104lc> arrayList, ArrayList<C1104lc> arrayList2) {
        long j = this.f2207e;
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            C0545dc dcVar = this.f3393A.get(i);
            if (j > 0 && (this.f3394B || i == 0)) {
                long j2 = dcVar.f2207e;
                if (j2 > 0) {
                    dcVar.mo2989E(j2 + j);
                } else {
                    dcVar.mo2989E(j);
                }
            }
            dcVar.mo3003l(viewGroup, mcVar, mcVar2, arrayList, arrayList2);
        }
    }

    /* renamed from: u */
    public void mo3011u(View view) {
        super.mo3011u(view);
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            this.f3393A.get(i).mo3011u(view);
        }
    }

    /* renamed from: v */
    public C0545dc mo3012v(C0545dc.C0549d dVar) {
        super.mo3012v(dVar);
        return this;
    }

    /* renamed from: w */
    public C0545dc mo3013w(View view) {
        for (int i = 0; i < this.f3393A.size(); i++) {
            this.f3393A.get(i).mo3013w(view);
        }
        this.f2211i.remove(view);
        return this;
    }

    /* renamed from: x */
    public void mo3014x(View view) {
        super.mo3014x(view);
        int size = this.f3393A.size();
        for (int i = 0; i < size; i++) {
            this.f3393A.get(i).mo3014x(view);
        }
    }

    /* renamed from: y */
    public void mo3015y() {
        if (this.f3393A.isEmpty()) {
            mo2990F();
            mo3004m();
            return;
        }
        C0959b bVar = new C0959b(this);
        Iterator<C0545dc> it = this.f3393A.iterator();
        while (it.hasNext()) {
            it.next().mo2992a(bVar);
        }
        this.f3395C = this.f3393A.size();
        if (!this.f3394B) {
            for (int i = 1; i < this.f3393A.size(); i++) {
                this.f3393A.get(i - 1).mo2992a(new C0958a(this, this.f3393A.get(i)));
            }
            C0545dc dcVar = this.f3393A.get(0);
            if (dcVar != null) {
                dcVar.mo3015y();
                return;
            }
            return;
        }
        Iterator<C0545dc> it2 = this.f3393A.iterator();
        while (it2.hasNext()) {
            it2.next().mo3015y();
        }
    }

    /* renamed from: z */
    public C0545dc mo3016z(long j) {
        this.f2208f = j;
        if (j >= 0) {
            int size = this.f3393A.size();
            for (int i = 0; i < size; i++) {
                this.f3393A.get(i).mo3016z(j);
            }
        }
        return this;
    }
}
