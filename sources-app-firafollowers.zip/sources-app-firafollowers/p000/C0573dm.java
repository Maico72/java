package p000;

/* renamed from: dm */
public class C0573dm<Z> implements C0303bm<Z, Z> {

    /* renamed from: a */
    public static final C0573dm<?> f2315a = new C0573dm<>();

    /* renamed from: a */
    public C1675rh<Z> mo149a(C1675rh<Z> rhVar, C2150yf yfVar) {
        return rhVar;
    }
}
