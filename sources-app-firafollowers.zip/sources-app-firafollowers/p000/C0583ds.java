package p000;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.util.List;
import p000.C0308bp;
import p000.C0576dp;
import p000.C0716ft;
import p000.C0910ip;
import p000.C1029kp;
import p000.C1135lp;
import p000.C1457pp;
import p000.C1880up;
import p000.C2019wo;

/* renamed from: ds */
public abstract class C0583ds implements Serializable {

    /* renamed from: ds$a */
    public static class C0584a {

        /* renamed from: a */
        public final C0585a f2350a;

        /* renamed from: ds$a$a */
        public enum C0585a {
            MANAGED_REFERENCE,
            BACK_REFERENCE
        }

        public C0584a(C0585a aVar, String str) {
            this.f2350a = aVar;
        }
    }

    /* renamed from: A */
    public C1135lp.C1136a mo3100A(C1757st<?> stVar, C1279nu nuVar) {
        return C1135lp.C1136a.f3925e;
    }

    /* renamed from: B */
    public Integer mo3101B(C1279nu nuVar) {
        return null;
    }

    /* renamed from: C */
    public C2240zv<?> mo3102C(C1757st<?> stVar, C1887uu uuVar, C1035ks ksVar) {
        return null;
    }

    /* renamed from: D */
    public C0584a mo3103D(C1887uu uuVar) {
        return null;
    }

    /* renamed from: E */
    public C1957vs mo3104E(C1757st<?> stVar, C1758su suVar, C1957vs vsVar) {
        return null;
    }

    /* renamed from: F */
    public C1957vs mo3105F(C1364ou ouVar) {
        return null;
    }

    /* renamed from: G */
    public Object mo3106G(C1887uu uuVar) {
        return null;
    }

    /* renamed from: H */
    public Object mo3107H(C1279nu nuVar) {
        return null;
    }

    /* renamed from: I */
    public String[] mo3108I(C1364ou ouVar) {
        return null;
    }

    /* renamed from: J */
    public Boolean mo3109J(C1279nu nuVar) {
        return null;
    }

    /* renamed from: K */
    public C0716ft.C0718b mo3110K(C1279nu nuVar) {
        return null;
    }

    /* renamed from: L */
    public Object mo3111L(C1279nu nuVar) {
        return null;
    }

    /* renamed from: M */
    public C1880up.C1881a mo3112M(C1279nu nuVar) {
        return C1880up.C1881a.f6193f;
    }

    /* renamed from: N */
    public List<C1960vv> mo3113N(C1279nu nuVar) {
        return null;
    }

    /* renamed from: O */
    public String mo3114O(C1364ou ouVar) {
        return null;
    }

    /* renamed from: P */
    public C2240zv<?> mo3115P(C1757st<?> stVar, C1364ou ouVar, C1035ks ksVar) {
        return null;
    }

    /* renamed from: Q */
    public b10 mo3116Q(C1887uu uuVar) {
        return null;
    }

    /* renamed from: R */
    public Class<?>[] mo3117R(C1279nu nuVar) {
        return null;
    }

    /* renamed from: S */
    public Boolean mo3118S(C1279nu nuVar) {
        if (!(nuVar instanceof C1959vu) || !mo3119T((C1959vu) nuVar)) {
            return null;
        }
        return Boolean.TRUE;
    }

    @Deprecated
    /* renamed from: T */
    public boolean mo3119T(C1959vu vuVar) {
        return false;
    }

    /* renamed from: U */
    public Boolean mo3120U(C1279nu nuVar) {
        return null;
    }

    /* renamed from: V */
    public Boolean mo3121V(C1757st<?> stVar, C1279nu nuVar) {
        return null;
    }

    /* renamed from: W */
    public Boolean mo3122W(C1279nu nuVar) {
        if (!(nuVar instanceof C1959vu) || !mo3123X((C1959vu) nuVar)) {
            return null;
        }
        return Boolean.TRUE;
    }

    @Deprecated
    /* renamed from: X */
    public boolean mo3123X(C1959vu vuVar) {
        return false;
    }

    @Deprecated
    /* renamed from: Y */
    public boolean mo3124Y(C1279nu nuVar) {
        return false;
    }

    /* renamed from: Z */
    public boolean mo3125Z(C1887uu uuVar) {
        return false;
    }

    /* renamed from: a */
    public void mo3126a(C1757st<?> stVar, C1364ou ouVar, List<C1700rw> list) {
    }

    /* renamed from: a0 */
    public Boolean mo3127a0(C1887uu uuVar) {
        return null;
    }

    /* renamed from: b */
    public C1759sv<?> mo3128b(C1364ou ouVar, C1759sv<?> svVar) {
        return svVar;
    }

    /* renamed from: b0 */
    public boolean mo3129b0(Annotation annotation) {
        return false;
    }

    /* renamed from: c */
    public Object mo3130c(C1279nu nuVar) {
        return null;
    }

    /* renamed from: c0 */
    public Boolean mo3131c0(C1364ou ouVar) {
        return null;
    }

    /* renamed from: d */
    public C0308bp.C0309a mo3132d(C1757st<?> stVar, C1279nu nuVar) {
        if (!mo3124Y(nuVar)) {
            return null;
        }
        C0308bp.C0309a e = mo3134e(nuVar);
        return e == null ? C0308bp.C0309a.DEFAULT : e;
    }

    /* renamed from: d0 */
    public Boolean mo3133d0(C1887uu uuVar) {
        return null;
    }

    @Deprecated
    /* renamed from: e */
    public C0308bp.C0309a mo3134e(C1279nu nuVar) {
        return null;
    }

    /* renamed from: e0 */
    public C1035ks mo3135e0(C1757st<?> stVar, C1279nu nuVar, C1035ks ksVar) {
        return ksVar;
    }

    /* renamed from: f */
    public String[] mo3136f(Class<?> cls, Enum<?>[] enumArr, String[] strArr) {
        return strArr;
    }

    /* renamed from: f0 */
    public C1959vu mo3137f0(C1757st<?> stVar, C1959vu vuVar, C1959vu vuVar2) {
        return null;
    }

    /* renamed from: g */
    public Object mo3138g(C1279nu nuVar) {
        return null;
    }

    /* renamed from: h */
    public C0576dp.C0580d mo3139h(C1279nu nuVar) {
        return C0576dp.C0580d.f2340k;
    }

    /* renamed from: i */
    public String mo3140i(C1887uu uuVar) {
        return null;
    }

    /* renamed from: j */
    public C2019wo.C2020a mo3141j(C1887uu uuVar) {
        Object k = mo3142k(uuVar);
        if (k != null) {
            return C2019wo.C2020a.m5593a(k, (Boolean) null);
        }
        return null;
    }

    @Deprecated
    /* renamed from: k */
    public Object mo3142k(C1887uu uuVar) {
        return null;
    }

    /* renamed from: l */
    public Object mo3143l(C1279nu nuVar) {
        return null;
    }

    /* renamed from: m */
    public Boolean mo3144m(C1279nu nuVar) {
        return null;
    }

    /* renamed from: n */
    public C1957vs mo3145n(C1279nu nuVar) {
        return null;
    }

    /* renamed from: o */
    public C1957vs mo3146o(C1279nu nuVar) {
        return null;
    }

    /* renamed from: p */
    public Object mo3147p(C1364ou ouVar) {
        return null;
    }

    /* renamed from: q */
    public Object mo3148q(C1279nu nuVar) {
        return null;
    }

    /* renamed from: r */
    public C1208mv mo3149r(C1279nu nuVar) {
        return null;
    }

    /* renamed from: s */
    public C1208mv mo3150s(C1279nu nuVar, C1208mv mvVar) {
        return mvVar;
    }

    /* renamed from: t */
    public C1457pp.C1458a mo3151t(C1279nu nuVar) {
        return null;
    }

    /* renamed from: u */
    public C2240zv<?> mo3152u(C1757st<?> stVar, C1887uu uuVar, C1035ks ksVar) {
        return null;
    }

    /* renamed from: v */
    public String mo3153v(C1279nu nuVar) {
        return null;
    }

    /* renamed from: w */
    public String mo3154w(C1279nu nuVar) {
        return null;
    }

    /* renamed from: x */
    public C0910ip.C0911a mo3155x(C1757st<?> stVar, C1279nu nuVar) {
        return mo3156y(nuVar);
    }

    @Deprecated
    /* renamed from: y */
    public C0910ip.C0911a mo3156y(C1279nu nuVar) {
        return C0910ip.C0911a.f3285i;
    }

    /* renamed from: z */
    public C1029kp.C1031b mo3157z(C1279nu nuVar) {
        C1029kp.C1031b bVar = C1029kp.C1031b.f3668h;
        return C1029kp.C1031b.f3668h;
    }
}
