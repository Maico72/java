package p000;

import android.content.Context;
import java.security.MessageDigest;

/* renamed from: ak */
public final class C0062ak<T> implements C0363cg<T> {

    /* renamed from: b */
    public static final C0363cg<?> f192b = new C0062ak();

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
    }

    /* renamed from: b */
    public C1675rh<T> mo142b(Context context, C1675rh<T> rhVar, int i, int i2) {
        return rhVar;
    }
}
