package p000;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import p000.C1409p9;

/* renamed from: aa */
public class C0020aa extends Fragment {
    /* renamed from: b */
    public static void m68b(Activity activity) {
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new C0020aa(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    /* renamed from: a */
    public final void mo57a(C1409p9.C1410a aVar) {
        Activity activity = getActivity();
        if (activity instanceof C1850u9) {
            ((C1850u9) activity).mo150a().mo5979d(aVar);
        } else if (activity instanceof C1725s9) {
            C1409p9 a = ((C1725s9) activity).mo150a();
            if (a instanceof C1785t9) {
                ((C1785t9) a).mo5979d(aVar);
            }
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        mo57a(C1409p9.C1410a.ON_CREATE);
    }

    public void onDestroy() {
        super.onDestroy();
        mo57a(C1409p9.C1410a.ON_DESTROY);
    }

    public void onPause() {
        super.onPause();
        mo57a(C1409p9.C1410a.ON_PAUSE);
    }

    public void onResume() {
        super.onResume();
        mo57a(C1409p9.C1410a.ON_RESUME);
    }

    public void onStart() {
        super.onStart();
        mo57a(C1409p9.C1410a.ON_START);
    }

    public void onStop() {
        super.onStop();
        mo57a(C1409p9.C1410a.ON_STOP);
    }
}
