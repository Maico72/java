package p000;

import java.io.Serializable;

/* renamed from: dq */
public abstract class C0581dq<T> implements Serializable {
    /* renamed from: a */
    public abstract boolean mo3095a(C0581dq<?> dqVar);

    /* renamed from: b */
    public abstract C0581dq<T> mo3096b(Class<?> cls);

    /* renamed from: c */
    public abstract T mo3097c(Object obj);

    /* renamed from: d */
    public abstract Class<?> mo3098d();

    /* renamed from: e */
    public abstract C0581dq<T> mo3099e(Object obj);
}
