package p000;

import android.os.SystemClock;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* renamed from: ge */
public class C0746ge {

    /* renamed from: a */
    public static boolean f2867a = Log.isLoggable("Volley", 2);

    /* renamed from: b */
    public static final String f2868b = C0746ge.class.getName();

    /* renamed from: ge$a */
    public static class C0747a {

        /* renamed from: c */
        public static final boolean f2869c = C0746ge.f2867a;

        /* renamed from: a */
        public final List<C0748a> f2870a = new ArrayList();

        /* renamed from: b */
        public boolean f2871b = false;

        /* renamed from: ge$a$a */
        public static class C0748a {

            /* renamed from: a */
            public final String f2872a;

            /* renamed from: b */
            public final long f2873b;

            /* renamed from: c */
            public final long f2874c;

            public C0748a(String str, long j, long j2) {
                this.f2872a = str;
                this.f2873b = j;
                this.f2874c = j2;
            }
        }

        /* renamed from: a */
        public synchronized void mo3775a(String str, long j) {
            if (!this.f2871b) {
                this.f2870a.add(new C0748a(str, j, SystemClock.elapsedRealtime()));
            } else {
                throw new IllegalStateException("Marker added to finished log");
            }
        }

        /* renamed from: b */
        public synchronized void mo3776b(String str) {
            long j;
            this.f2871b = true;
            if (this.f2870a.size() == 0) {
                j = 0;
            } else {
                long j2 = this.f2870a.get(0).f2874c;
                List<C0748a> list = this.f2870a;
                j = list.get(list.size() - 1).f2874c - j2;
            }
            if (j > 0) {
                long j3 = this.f2870a.get(0).f2874c;
                C0746ge.m2471b("(%-4d ms) %s", Long.valueOf(j), str);
                for (C0748a next : this.f2870a) {
                    long j4 = next.f2874c;
                    C0746ge.m2471b("(+%-4d) [%2d] %s", Long.valueOf(j4 - j3), Long.valueOf(next.f2873b), next.f2872a);
                    j3 = j4;
                }
            }
        }

        public void finalize() {
            if (!this.f2871b) {
                mo3776b("Request on the loose");
                C0746ge.m2472c("Marker log finalized without finish() - uncaught exit point for request", new Object[0]);
            }
        }
    }

    /* renamed from: a */
    public static String m2470a(String str, Object... objArr) {
        String str2;
        if (objArr != null) {
            str = String.format(Locale.US, str, objArr);
        }
        StackTraceElement[] stackTrace = new Throwable().fillInStackTrace().getStackTrace();
        int i = 2;
        while (true) {
            if (i >= stackTrace.length) {
                str2 = "<unknown>";
                break;
            } else if (!stackTrace[i].getClassName().equals(f2868b)) {
                String className = stackTrace[i].getClassName();
                String substring = className.substring(className.lastIndexOf(46) + 1);
                str2 = substring.substring(substring.lastIndexOf(36) + 1) + "." + stackTrace[i].getMethodName();
                break;
            } else {
                i++;
            }
        }
        return String.format(Locale.US, "[%d] %s: %s", new Object[]{Long.valueOf(Thread.currentThread().getId()), str2, str});
    }

    /* renamed from: b */
    public static void m2471b(String str, Object... objArr) {
        Log.d("Volley", m2470a(str, objArr));
    }

    /* renamed from: c */
    public static void m2472c(String str, Object... objArr) {
        Log.e("Volley", m2470a(str, objArr));
    }

    /* renamed from: d */
    public static void m2473d(String str, Object... objArr) {
        if (f2867a) {
            Log.v("Volley", m2470a(str, objArr));
        }
    }
}
