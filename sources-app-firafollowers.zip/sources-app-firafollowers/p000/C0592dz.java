package p000;

import p000.C1356oq;

@C0313bt
/* renamed from: dz */
public class C0592dz extends C2171yy<Object> {
    public C0592dz(Class<?> cls) {
        super(cls, C1356oq.C1358b.LONG, "number");
    }

    /* renamed from: f */
    public void mo1481f(Object obj, C1200mq mqVar, C0221at atVar) {
        mqVar.mo3744u(((Long) obj).longValue());
    }
}
