package p000;

import java.security.MessageDigest;

/* renamed from: fo */
public final class C0710fo implements C2005wf {

    /* renamed from: b */
    public static final C0710fo f2772b = new C0710fo();

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
    }

    public String toString() {
        return "EmptySignature";
    }
}
