package p000;

/* renamed from: jm */
public class C0973jm implements C0845hm {
}
