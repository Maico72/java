package p000;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: jo */
public final class C0976jo extends FilterInputStream {

    /* renamed from: d */
    public final long f3463d;

    /* renamed from: e */
    public int f3464e;

    public C0976jo(InputStream inputStream, long j) {
        super(inputStream);
        this.f3463d = j;
    }

    /* renamed from: a */
    public final int mo4182a(int i) {
        if (i >= 0) {
            this.f3464e += i;
        } else if (this.f3463d - ((long) this.f3464e) > 0) {
            StringBuilder d = C1012kd.m3195d("Failed to read all expected data, expected: ");
            d.append(this.f3463d);
            d.append(", but read: ");
            d.append(this.f3464e);
            throw new IOException(d.toString());
        }
        return i;
    }

    public synchronized int available() {
        return (int) Math.max(this.f3463d - ((long) this.f3464e), (long) this.in.available());
    }

    public synchronized int read() {
        int read;
        read = super.read();
        mo4182a(read >= 0 ? 1 : -1);
        return read;
    }

    public int read(byte[] bArr) {
        return read(bArr, 0, bArr.length);
    }

    public synchronized int read(byte[] bArr, int i, int i2) {
        int read;
        read = super.read(bArr, i, i2);
        mo4182a(read);
        return read;
    }
}
