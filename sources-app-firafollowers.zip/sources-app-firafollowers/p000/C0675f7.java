package p000;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.View;
import java.lang.ref.WeakReference;

/* renamed from: f7 */
public final class C0675f7 {

    /* renamed from: a */
    public WeakReference<View> f2700a;

    /* renamed from: b */
    public int f2701b = -1;

    /* renamed from: f7$a */
    public class C0676a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ C0738g7 f2702a;

        /* renamed from: b */
        public final /* synthetic */ View f2703b;

        public C0676a(C0675f7 f7Var, C0738g7 g7Var, View view) {
            this.f2702a = g7Var;
            this.f2703b = view;
        }

        public void onAnimationCancel(Animator animator) {
            this.f2702a.onAnimationCancel(this.f2703b);
        }

        public void onAnimationEnd(Animator animator) {
            this.f2702a.onAnimationEnd(this.f2703b);
        }

        public void onAnimationStart(Animator animator) {
            this.f2702a.onAnimationStart(this.f2703b);
        }
    }

    /* renamed from: f7$b */
    public class C0677b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a */
        public final /* synthetic */ C0874i7 f2704a;

        /* renamed from: b */
        public final /* synthetic */ View f2705b;

        public C0677b(C0675f7 f7Var, C0874i7 i7Var, View view) {
            this.f2704a = i7Var;
            this.f2705b = view;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((View) C2173z.this.f6993d.getParent()).invalidate();
        }
    }

    public C0675f7(View view) {
        this.f2700a = new WeakReference<>(view);
    }

    /* renamed from: a */
    public C0675f7 mo3520a(float f) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
        return this;
    }

    /* renamed from: b */
    public void mo3521b() {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    /* renamed from: c */
    public C0675f7 mo3522c(float f) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().scaleX(f);
        }
        return this;
    }

    /* renamed from: d */
    public C0675f7 mo3523d(float f) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().scaleY(f);
        }
        return this;
    }

    /* renamed from: e */
    public C0675f7 mo3524e(long j) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().setDuration(j);
        }
        return this;
    }

    /* renamed from: f */
    public C0675f7 mo3525f(C0738g7 g7Var) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            mo3526g(view, g7Var);
        }
        return this;
    }

    /* renamed from: g */
    public final void mo3526g(View view, C0738g7 g7Var) {
        if (g7Var != null) {
            view.animate().setListener(new C0676a(this, g7Var, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    /* renamed from: h */
    public C0675f7 mo3527h(C0874i7 i7Var) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            C0677b bVar = null;
            if (i7Var != null) {
                bVar = new C0677b(this, i7Var, view);
            }
            view.animate().setUpdateListener(bVar);
        }
        return this;
    }

    /* renamed from: i */
    public void mo3528i() {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    /* renamed from: j */
    public C0675f7 mo3529j(float f) {
        View view = (View) this.f2700a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
        return this;
    }
}
