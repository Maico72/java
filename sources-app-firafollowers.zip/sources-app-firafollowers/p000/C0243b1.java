package p000;

/* renamed from: b1 */
public interface C0243b1 {

    /* renamed from: b1$a */
    public interface C0244a {
        /* renamed from: d */
        void mo171d(C1967w0 w0Var, int i);

        C1967w0 getItemData();
    }

    /* renamed from: b */
    void mo189b(C1838u0 u0Var);
}
