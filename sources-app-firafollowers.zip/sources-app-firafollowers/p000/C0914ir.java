package p000;

import p000.C1200mq;

/* renamed from: ir */
public abstract class C0914ir extends C2162yq {

    /* renamed from: q */
    public static final int[] f3303q = C0217ar.f1125f;

    /* renamed from: l */
    public final C0311br f3304l;

    /* renamed from: m */
    public int[] f3305m = f3303q;

    /* renamed from: n */
    public int f3306n;

    /* renamed from: o */
    public C1882uq f3307o = C1823tr.f6020k;

    /* renamed from: p */
    public boolean f3308p;

    public C0914ir(C0311br brVar, int i, C1754sq sqVar) {
        super(i, sqVar);
        this.f3304l = brVar;
        boolean z = false;
        if ((C1200mq.C1201a.ESCAPE_NON_ASCII.f4106e & i) != 0) {
            this.f3306n = 127;
        }
        this.f3308p = !((C1200mq.C1201a.QUOTE_FIELD_NAMES.f4106e & i) != 0 ? true : z);
    }

    /* renamed from: Q */
    public void mo4091Q(int i, int i2) {
        C0852hr hrVar;
        boolean z = false;
        if ((C2162yq.f6965k & i2) != 0) {
            this.f6968i = (C1200mq.C1201a.WRITE_NUMBERS_AS_STRINGS.f4106e & i) != 0;
            int i3 = C1200mq.C1201a.ESCAPE_NON_ASCII.f4106e;
            if ((i2 & i3) != 0) {
                if ((i3 & i) != 0) {
                    mo4093U(127);
                } else {
                    mo4093U(0);
                }
            }
            int i4 = C1200mq.C1201a.STRICT_DUPLICATE_DETECTION.f4106e;
            if ((i2 & i4) != 0) {
                boolean z2 = (i & i4) != 0;
                C0979jr jrVar = this.f6969j;
                if (!z2) {
                    hrVar = null;
                } else if (jrVar.f3468d == null) {
                    hrVar = new C0852hr(this);
                }
                jrVar.f3468d = hrVar;
                this.f6969j = jrVar;
            }
        }
        if ((i & C1200mq.C1201a.QUOTE_FIELD_NAMES.f4106e) != 0) {
            z = true;
        }
        this.f3308p = !z;
    }

    /* renamed from: T */
    public void mo4092T(String str) {
        throw new C1137lq(String.format("Can not %s, expecting field name (context: %s)", new Object[]{str, this.f6969j.mo5603e()}), this);
    }

    /* renamed from: U */
    public C1200mq mo4093U(int i) {
        if (i < 0) {
            i = 0;
        }
        this.f3306n = i;
        return this;
    }

    /* renamed from: e */
    public C1200mq mo3728e(C1200mq.C1201a aVar) {
        int i = aVar.f4106e;
        this.f6967h &= i ^ -1;
        if ((i & C2162yq.f6965k) != 0) {
            if (aVar == C1200mq.C1201a.WRITE_NUMBERS_AS_STRINGS) {
                this.f6968i = false;
            } else if (aVar == C1200mq.C1201a.ESCAPE_NON_ASCII) {
                mo4093U(0);
            } else if (aVar == C1200mq.C1201a.STRICT_DUPLICATE_DETECTION) {
                C0979jr jrVar = this.f6969j;
                jrVar.f3468d = null;
                this.f6969j = jrVar;
            }
        }
        if (aVar == C1200mq.C1201a.QUOTE_FIELD_NAMES) {
            this.f3308p = true;
        }
        return this;
    }
}
