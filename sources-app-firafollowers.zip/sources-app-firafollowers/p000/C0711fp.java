package p000;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: fp */
public @interface C0711fp {
    Class<? extends C0581dq<?>> generator();

    String property() default "@id";

    Class<? extends Object> resolver() default C0851hq.class;

    Class<?> scope() default Object.class;
}
