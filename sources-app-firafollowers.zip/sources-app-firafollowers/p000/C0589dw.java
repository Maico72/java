package p000;

import p000.C2090xp;

/* renamed from: dw */
public class C0589dw extends C1281nw {

    /* renamed from: c */
    public final String f2360c;

    public C0589dw(C2167yv yvVar, C0714fs fsVar, String str) {
        super(yvVar, fsVar);
        this.f2360c = str;
    }

    /* renamed from: a */
    public C0230aw mo1474a(C0714fs fsVar) {
        return this.f4378b == fsVar ? this : new C0589dw(this.f4377a, fsVar, this.f2360c);
    }

    /* renamed from: b */
    public String mo1475b() {
        return this.f2360c;
    }

    /* renamed from: c */
    public C2090xp.C2091a mo1476c() {
        return C2090xp.C2091a.EXTERNAL_PROPERTY;
    }
}
