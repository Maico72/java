package p000;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;
import com.roughike.bottombar.C0446R;

/* renamed from: i0 */
public class C0862i0 extends ContextWrapper {

    /* renamed from: a */
    public int f3175a;

    /* renamed from: b */
    public Resources.Theme f3176b;

    /* renamed from: c */
    public LayoutInflater f3177c;

    /* renamed from: d */
    public Configuration f3178d;

    /* renamed from: e */
    public Resources f3179e;

    public C0862i0() {
        super((Context) null);
    }

    public C0862i0(Context context, int i) {
        super(context);
        this.f3175a = i;
    }

    public C0862i0(Context context, Resources.Theme theme) {
        super(context);
        this.f3176b = theme;
    }

    /* renamed from: a */
    public void mo3962a(Configuration configuration) {
        if (this.f3179e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        } else if (this.f3178d == null) {
            this.f3178d = new Configuration(configuration);
        } else {
            throw new IllegalStateException("Override configuration has already been set");
        }
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    /* renamed from: b */
    public final void mo3964b() {
        if (this.f3176b == null) {
            this.f3176b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f3176b.setTo(theme);
            }
        }
        this.f3176b.applyStyle(this.f3175a, true);
    }

    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public Resources getResources() {
        if (this.f3179e == null) {
            Configuration configuration = this.f3178d;
            this.f3179e = configuration == null ? super.getResources() : createConfigurationContext(configuration).getResources();
        }
        return this.f3179e;
    }

    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f3177c == null) {
            this.f3177c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f3177c;
    }

    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f3176b;
        if (theme != null) {
            return theme;
        }
        if (this.f3175a == 0) {
            this.f3175a = C0446R.style.Theme_AppCompat_Light;
        }
        mo3964b();
        return this.f3176b;
    }

    public void setTheme(int i) {
        if (this.f3175a != i) {
            this.f3175a = i;
            mo3964b();
        }
    }
}
