package p000;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* renamed from: av */
public abstract class C0223av {

    /* renamed from: b */
    public static final o00 f1146b = new C0226c();

    /* renamed from: a */
    public final Object f1147a;

    /* renamed from: av$a */
    public static class C0224a extends C0223av {

        /* renamed from: c */
        public static final C0224a f1148c = new C0224a((Object) null);

        public C0224a(Object obj) {
            super((Object) null);
        }

        /* renamed from: a */
        public C0223av mo1468a(Annotation annotation) {
            return new C0228e(this.f1147a, annotation.annotationType(), annotation);
        }

        /* renamed from: b */
        public C0315bv mo1469b() {
            return new C0315bv();
        }

        /* renamed from: c */
        public o00 mo1470c() {
            return C0223av.f1146b;
        }

        /* renamed from: d */
        public boolean mo1471d(Annotation annotation) {
            return false;
        }
    }

    /* renamed from: av$b */
    public static class C0225b extends C0223av {

        /* renamed from: c */
        public final HashMap<Class<?>, Annotation> f1149c;

        public C0225b(Object obj, Class<?> cls, Annotation annotation, Class<?> cls2, Annotation annotation2) {
            super(obj);
            HashMap<Class<?>, Annotation> hashMap = new HashMap<>();
            this.f1149c = hashMap;
            hashMap.put(cls, annotation);
            hashMap.put(cls2, annotation2);
        }

        /* renamed from: a */
        public C0223av mo1468a(Annotation annotation) {
            this.f1149c.put(annotation.annotationType(), annotation);
            return this;
        }

        /* renamed from: b */
        public C0315bv mo1469b() {
            C0315bv bvVar = new C0315bv();
            for (Annotation next : this.f1149c.values()) {
                if (bvVar.f1365d == null) {
                    bvVar.f1365d = new HashMap<>();
                }
                Annotation put = bvVar.f1365d.put(next.annotationType(), next);
                if (put != null) {
                    boolean equals = put.equals(next);
                }
            }
            return bvVar;
        }

        /* renamed from: c */
        public o00 mo1470c() {
            if (this.f1149c.size() != 2) {
                return new C0315bv(this.f1149c);
            }
            Iterator<Map.Entry<Class<?>, Annotation>> it = this.f1149c.entrySet().iterator();
            Map.Entry next = it.next();
            Map.Entry next2 = it.next();
            return new C0229f((Class) next.getKey(), (Annotation) next.getValue(), (Class) next2.getKey(), (Annotation) next2.getValue());
        }

        /* renamed from: d */
        public boolean mo1471d(Annotation annotation) {
            return this.f1149c.containsKey(annotation.annotationType());
        }
    }

    /* renamed from: av$c */
    public static class C0226c implements o00, Serializable {
        /* renamed from: a */
        public <A extends Annotation> A mo1472a(Class<A> cls) {
            return null;
        }

        public int size() {
            return 0;
        }
    }

    /* renamed from: av$d */
    public static class C0227d implements o00, Serializable {

        /* renamed from: d */
        public final Class<?> f1150d;

        /* renamed from: e */
        public final Annotation f1151e;

        public C0227d(Class<?> cls, Annotation annotation) {
            this.f1150d = cls;
            this.f1151e = annotation;
        }

        /* renamed from: a */
        public <A extends Annotation> A mo1472a(Class<A> cls) {
            if (this.f1150d == cls) {
                return this.f1151e;
            }
            return null;
        }

        public int size() {
            return 1;
        }
    }

    /* renamed from: av$e */
    public static class C0228e extends C0223av {

        /* renamed from: c */
        public Class<?> f1152c;

        /* renamed from: d */
        public Annotation f1153d;

        public C0228e(Object obj, Class<?> cls, Annotation annotation) {
            super(obj);
            this.f1152c = cls;
            this.f1153d = annotation;
        }

        /* renamed from: a */
        public C0223av mo1468a(Annotation annotation) {
            Class<? extends Annotation> annotationType = annotation.annotationType();
            Class<?> cls = this.f1152c;
            if (cls != annotationType) {
                return new C0225b(this.f1147a, cls, this.f1153d, annotationType, annotation);
            }
            this.f1153d = annotation;
            return this;
        }

        /* renamed from: b */
        public C0315bv mo1469b() {
            Class<?> cls = this.f1152c;
            Annotation annotation = this.f1153d;
            HashMap hashMap = new HashMap(4);
            hashMap.put(cls, annotation);
            return new C0315bv(hashMap);
        }

        /* renamed from: c */
        public o00 mo1470c() {
            return new C0227d(this.f1152c, this.f1153d);
        }

        /* renamed from: d */
        public boolean mo1471d(Annotation annotation) {
            return annotation.annotationType() == this.f1152c;
        }
    }

    /* renamed from: av$f */
    public static class C0229f implements o00, Serializable {

        /* renamed from: d */
        public final Class<?> f1154d;

        /* renamed from: e */
        public final Class<?> f1155e;

        /* renamed from: f */
        public final Annotation f1156f;

        /* renamed from: g */
        public final Annotation f1157g;

        public C0229f(Class<?> cls, Annotation annotation, Class<?> cls2, Annotation annotation2) {
            this.f1154d = cls;
            this.f1156f = annotation;
            this.f1155e = cls2;
            this.f1157g = annotation2;
        }

        /* renamed from: a */
        public <A extends Annotation> A mo1472a(Class<A> cls) {
            if (this.f1154d == cls) {
                return this.f1156f;
            }
            if (this.f1155e == cls) {
                return this.f1157g;
            }
            return null;
        }

        public int size() {
            return 2;
        }
    }

    public C0223av(Object obj) {
        this.f1147a = obj;
    }

    /* renamed from: a */
    public abstract C0223av mo1468a(Annotation annotation);

    /* renamed from: b */
    public abstract C0315bv mo1469b();

    /* renamed from: c */
    public abstract o00 mo1470c();

    /* renamed from: d */
    public abstract boolean mo1471d(Annotation annotation);
}
