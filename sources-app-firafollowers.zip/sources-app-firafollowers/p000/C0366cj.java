package p000;

import android.net.Uri;
import android.text.TextUtils;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Objects;

/* renamed from: cj */
public class C0366cj implements C2005wf {

    /* renamed from: b */
    public final C0570dj f1609b;

    /* renamed from: c */
    public final URL f1610c;

    /* renamed from: d */
    public final String f1611d;

    /* renamed from: e */
    public String f1612e;

    /* renamed from: f */
    public URL f1613f;

    /* renamed from: g */
    public volatile byte[] f1614g;

    /* renamed from: h */
    public int f1615h;

    public C0366cj(String str) {
        C0570dj djVar = C0570dj.f2310a;
        this.f1610c = null;
        if (!TextUtils.isEmpty(str)) {
            this.f1611d = str;
            Objects.requireNonNull(djVar, "Argument must not be null");
            this.f1609b = djVar;
            return;
        }
        throw new IllegalArgumentException("Must not be null or empty");
    }

    /* renamed from: a */
    public void mo141a(MessageDigest messageDigest) {
        if (this.f1614g == null) {
            this.f1614g = mo1964c().getBytes(C2005wf.f6654a);
        }
        messageDigest.update(this.f1614g);
    }

    /* renamed from: c */
    public String mo1964c() {
        String str = this.f1611d;
        if (str != null) {
            return str;
        }
        URL url = this.f1610c;
        Objects.requireNonNull(url, "Argument must not be null");
        return url.toString();
    }

    /* renamed from: d */
    public URL mo1965d() {
        if (this.f1613f == null) {
            if (TextUtils.isEmpty(this.f1612e)) {
                String str = this.f1611d;
                if (TextUtils.isEmpty(str)) {
                    URL url = this.f1610c;
                    Objects.requireNonNull(url, "Argument must not be null");
                    str = url.toString();
                }
                this.f1612e = Uri.encode(str, "@#&=*+-_.,:!?()/~'%;$");
            }
            this.f1613f = new URL(this.f1612e);
        }
        return this.f1613f;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0366cj)) {
            return false;
        }
        C0366cj cjVar = (C0366cj) obj;
        return mo1964c().equals(cjVar.mo1964c()) && this.f1609b.equals(cjVar.f1609b);
    }

    public int hashCode() {
        if (this.f1615h == 0) {
            int hashCode = mo1964c().hashCode();
            this.f1615h = hashCode;
            this.f1615h = this.f1609b.hashCode() + (hashCode * 31);
        }
        return this.f1615h;
    }

    public String toString() {
        return mo1964c();
    }

    public C0366cj(URL url) {
        C0570dj djVar = C0570dj.f2310a;
        Objects.requireNonNull(url, "Argument must not be null");
        this.f1610c = url;
        this.f1611d = null;
        Objects.requireNonNull(djVar, "Argument must not be null");
        this.f1609b = djVar;
    }
}
