package p000;

/* renamed from: ci */
public final class C0365ci implements C2071xh<byte[]> {
    /* renamed from: a */
    public String mo1960a() {
        return "ByteArrayPool";
    }

    /* renamed from: b */
    public int mo1961b(Object obj) {
        return ((byte[]) obj).length;
    }

    /* renamed from: c */
    public int mo1962c() {
        return 1;
    }

    public Object newArray(int i) {
        return new byte[i];
    }
}
