package p000;

import java.util.concurrent.atomic.AtomicReference;
import p000.C1029kp;
import p000.C1762sx;
import p000.b10;

/* renamed from: hz */
public abstract class C0860hz<T> extends C1770sz<T> implements C2100xw {

    /* renamed from: f */
    public final C1035ks f3165f;

    /* renamed from: g */
    public final C0714fs f3166g;

    /* renamed from: h */
    public final C0230aw f3167h;

    /* renamed from: i */
    public final C1462ps<Object> f3168i;

    /* renamed from: j */
    public final b10 f3169j;

    /* renamed from: k */
    public transient C1762sx f3170k;

    /* renamed from: l */
    public final Object f3171l;

    /* renamed from: m */
    public final boolean f3172m;

    public C0860hz(C0860hz<?> hzVar, C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, b10 b10, Object obj, boolean z) {
        super((C1770sz<?>) hzVar);
        this.f3165f = hzVar.f3165f;
        this.f3170k = C1762sx.C1764b.f5795b;
        this.f3166g = fsVar;
        this.f3167h = awVar;
        this.f3168i = psVar;
        this.f3169j = b10;
        this.f3171l = obj;
        this.f3172m = z;
    }

    public C0860hz(i00 i00, C0230aw awVar, C1462ps psVar) {
        super((C1035ks) i00);
        this.f3165f = i00.f3180m;
        this.f3166g = null;
        this.f3167h = awVar;
        this.f3168i = psVar;
        this.f3169j = null;
        this.f3171l = null;
        this.f3172m = false;
        this.f3170k = C1762sx.C1764b.f5795b;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:31:0x005f, code lost:
        if (r6 == p000.C0716ft.C0718b.DYNAMIC) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x00db, code lost:
        if (r8.f3165f.mo3977d() != false) goto L_0x00d3;
     */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x006a  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0083  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x00e8  */
    /* JADX WARNING: Removed duplicated region for block: B:80:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:81:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1462ps<?> mo2818a(p000.C0221at r9, p000.C0714fs r10) {
        /*
            r8 = this;
            kp$a r0 = p000.C1029kp.C1030a.NON_EMPTY
            aw r1 = r8.f3167h
            if (r1 == 0) goto L_0x000a
            aw r1 = r1.mo1474a(r10)
        L_0x000a:
            r2 = 0
            if (r10 == 0) goto L_0x0022
            uu r3 = r10.mo3644a()
            ds r4 = r9.mo1464w()
            if (r3 == 0) goto L_0x0022
            java.lang.Object r4 = r4.mo3130c(r3)
            if (r4 == 0) goto L_0x0022
            ps r3 = r9.mo1446I(r3, r4)
            goto L_0x0023
        L_0x0022:
            r3 = r2
        L_0x0023:
            r4 = 0
            r5 = 1
            if (r3 != 0) goto L_0x0075
            ps<java.lang.Object> r3 = r8.f3168i
            if (r3 != 0) goto L_0x0071
            ks r6 = r8.f3165f
            boolean r7 = r6.mo4349z()
            if (r7 == 0) goto L_0x0035
        L_0x0033:
            r6 = 0
            goto L_0x0068
        L_0x0035:
            boolean r7 = r6.mo4348y()
            if (r7 == 0) goto L_0x003d
        L_0x003b:
            r6 = 1
            goto L_0x0068
        L_0x003d:
            boolean r6 = r6.f3700h
            if (r6 == 0) goto L_0x0042
            goto L_0x003b
        L_0x0042:
            ds r6 = r9.mo1464w()
            if (r6 == 0) goto L_0x0062
            if (r10 == 0) goto L_0x0062
            uu r7 = r10.mo3644a()
            if (r7 == 0) goto L_0x0062
            uu r7 = r10.mo3644a()
            ft$b r6 = r6.mo3110K(r7)
            ft$b r7 = p000.C0716ft.C0718b.STATIC
            if (r6 != r7) goto L_0x005d
            goto L_0x003b
        L_0x005d:
            ft$b r7 = p000.C0716ft.C0718b.DYNAMIC
            if (r6 != r7) goto L_0x0062
            goto L_0x0033
        L_0x0062:
            rs r6 = p000.C1694rs.USE_STATIC_TYPING
            boolean r6 = r9.mo1441D(r6)
        L_0x0068:
            if (r6 == 0) goto L_0x0075
            ks r3 = r8.f3165f
            ps r3 = r9.mo1459r(r3, r10)
            goto L_0x0075
        L_0x0071:
            ps r3 = r9.mo1467z(r3, r10)
        L_0x0075:
            fs r6 = r8.f3166g
            if (r6 != r10) goto L_0x0083
            aw r6 = r8.f3167h
            if (r6 != r1) goto L_0x0083
            ps<java.lang.Object> r6 = r8.f3168i
            if (r6 != r3) goto L_0x0083
            r1 = r8
            goto L_0x0089
        L_0x0083:
            b10 r6 = r8.f3169j
            hz r1 = r8.mo3417r(r10, r1, r3, r6)
        L_0x0089:
            if (r10 == 0) goto L_0x00ec
            ys r3 = r9.f1134d
            java.lang.Class<T> r6 = r8.f5804d
            kp$b r10 = r10.mo3645b(r3, r6)
            if (r10 == 0) goto L_0x00ec
            kp$a r3 = r10.f3670e
            kp$a r6 = p000.C1029kp.C1030a.USE_DEFAULTS
            if (r3 == r6) goto L_0x00ec
            int r3 = r3.ordinal()
            if (r3 == r5) goto L_0x00de
            r6 = 2
            if (r3 == r6) goto L_0x00d5
            r6 = 3
            if (r3 == r6) goto L_0x00d3
            r0 = 4
            if (r3 == r0) goto L_0x00bd
            r0 = 5
            if (r3 == r0) goto L_0x00af
            r0 = r2
            goto L_0x00e0
        L_0x00af:
            java.lang.Class<?> r10 = r10.f3672g
            java.lang.Object r0 = r9.mo1439B(r2, r10)
            if (r0 != 0) goto L_0x00b8
            goto L_0x00d3
        L_0x00b8:
            boolean r4 = r9.mo1440C(r0)
            goto L_0x00e0
        L_0x00bd:
            ks r9 = r8.f3165f
            java.lang.Object r0 = p000.C1401p4.m4391y(r9)
            if (r0 == 0) goto L_0x00d3
            java.lang.Class r9 = r0.getClass()
            boolean r9 = r9.isArray()
            if (r9 == 0) goto L_0x00d3
            java.lang.Object r0 = p000.C1401p4.m4388v(r0)
        L_0x00d3:
            r4 = 1
            goto L_0x00e0
        L_0x00d5:
            ks r9 = r8.f3165f
            boolean r9 = r9.mo3977d()
            if (r9 == 0) goto L_0x00de
            goto L_0x00d3
        L_0x00de:
            r0 = r2
            goto L_0x00d3
        L_0x00e0:
            java.lang.Object r9 = r8.f3171l
            if (r9 != r0) goto L_0x00e8
            boolean r9 = r8.f3172m
            if (r9 == r4) goto L_0x00ec
        L_0x00e8:
            hz r1 = r1.mo3416q(r0, r4)
        L_0x00ec:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0860hz.mo2818a(at, fs):ps");
    }

    /* renamed from: d */
    public boolean mo3672d(C0221at atVar, T t) {
        AtomicReference atomicReference = (AtomicReference) t;
        if (!(atomicReference.get() != null)) {
            return true;
        }
        Object obj = atomicReference.get();
        if (obj == null) {
            return this.f3172m;
        }
        if (this.f3171l == null) {
            return false;
        }
        C1462ps<Object> psVar = this.f3168i;
        if (psVar == null) {
            try {
                psVar = mo3959p(atVar, obj.getClass());
            } catch (C1203ms e) {
                throw new C2096xs(e);
            }
        }
        Object obj2 = this.f3171l;
        return obj2 == C1029kp.C1030a.NON_EMPTY ? psVar.mo3672d(atVar, obj) : obj2.equals(obj);
    }

    /* renamed from: e */
    public boolean mo1480e() {
        return this.f3169j != null;
    }

    /* renamed from: f */
    public void mo1481f(T t, C1200mq mqVar, C0221at atVar) {
        Object obj = ((AtomicReference) t).get();
        if (obj != null) {
            C1462ps<Object> psVar = this.f3168i;
            if (psVar == null) {
                psVar = mo3959p(atVar, obj.getClass());
            }
            C0230aw awVar = this.f3167h;
            if (awVar != null) {
                psVar.mo1482g(obj, mqVar, atVar, awVar);
            } else {
                psVar.mo1481f(obj, mqVar, atVar);
            }
        } else if (this.f3169j == null) {
            atVar.mo1454m(mqVar);
        }
    }

    /* renamed from: g */
    public void mo1482g(T t, C1200mq mqVar, C0221at atVar, C0230aw awVar) {
        Object obj = ((AtomicReference) t).get();
        if (obj != null) {
            C1462ps<Object> psVar = this.f3168i;
            if (psVar == null) {
                psVar = mo3959p(atVar, obj.getClass());
            }
            psVar.mo1482g(obj, mqVar, atVar, awVar);
        } else if (this.f3169j == null) {
            atVar.mo1454m(mqVar);
        }
    }

    /* renamed from: h */
    public C1462ps<T> mo1483h(b10 b10) {
        C1462ps<Object> psVar = this.f3168i;
        if (psVar != null && (psVar = psVar.mo1483h(b10)) == this.f3168i) {
            return this;
        }
        b10 b102 = this.f3169j;
        if (b102 != null) {
            b10 = new b10.C0245a(b10, b102);
        }
        return (this.f3168i == psVar && b102 == b10) ? this : mo3417r(this.f3166g, this.f3167h, psVar, b10);
    }

    /* renamed from: p */
    public final C1462ps<Object> mo3959p(C0221at atVar, Class<?> cls) {
        C1462ps<Object> c = this.f3170k.mo5880c(cls);
        if (c != null) {
            return c;
        }
        C1462ps<Object> r = this.f3165f.mo4344r() ? atVar.mo1459r(atVar.mo1453l(this.f3165f, cls), this.f3166g) : atVar.mo1460s(cls, this.f3166g);
        b10 b10 = this.f3169j;
        if (b10 != null) {
            r = r.mo1483h(b10);
        }
        C1462ps<Object> psVar = r;
        this.f3170k = this.f3170k.mo5879b(cls, psVar);
        return psVar;
    }

    /* renamed from: q */
    public abstract C0860hz<T> mo3416q(Object obj, boolean z);

    /* renamed from: r */
    public abstract C0860hz<T> mo3417r(C0714fs fsVar, C0230aw awVar, C1462ps<?> psVar, b10 b10);
}
