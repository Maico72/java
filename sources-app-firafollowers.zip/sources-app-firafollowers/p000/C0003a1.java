package p000;

import android.content.Context;

/* renamed from: a1 */
public interface C0003a1 {

    /* renamed from: a1$a */
    public interface C0004a {
        /* renamed from: a */
        void mo14a(C1838u0 u0Var, boolean z);

        /* renamed from: b */
        boolean mo15b(C1838u0 u0Var);
    }

    /* renamed from: a */
    void mo6a(C1838u0 u0Var, boolean z);

    /* renamed from: c */
    boolean mo7c();

    /* renamed from: d */
    void mo8d(Context context, C1838u0 u0Var);

    /* renamed from: e */
    boolean mo9e(C1838u0 u0Var, C1967w0 w0Var);

    /* renamed from: g */
    boolean mo10g(C1838u0 u0Var, C1967w0 w0Var);

    /* renamed from: h */
    void mo11h(C0004a aVar);

    /* renamed from: i */
    boolean mo12i(C0662f1 f1Var);

    /* renamed from: j */
    void mo13j(boolean z);
}
