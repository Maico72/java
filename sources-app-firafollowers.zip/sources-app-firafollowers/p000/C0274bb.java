package p000;

/* renamed from: bb */
public class C0274bb {

    /* renamed from: a */
    public boolean f1300a = true;

    /* renamed from: b */
    public int f1301b;

    /* renamed from: c */
    public int f1302c;

    /* renamed from: d */
    public int f1303d;

    /* renamed from: e */
    public int f1304e;

    /* renamed from: f */
    public int f1305f = 0;

    /* renamed from: g */
    public int f1306g = 0;

    /* renamed from: h */
    public boolean f1307h;

    /* renamed from: i */
    public boolean f1308i;

    public String toString() {
        StringBuilder d = C1012kd.m3195d("LayoutState{mAvailable=");
        d.append(this.f1301b);
        d.append(", mCurrentPosition=");
        d.append(this.f1302c);
        d.append(", mItemDirection=");
        d.append(this.f1303d);
        d.append(", mLayoutDirection=");
        d.append(this.f1304e);
        d.append(", mStartLine=");
        d.append(this.f1305f);
        d.append(", mEndLine=");
        d.append(this.f1306g);
        d.append('}');
        return d.toString();
    }
}
