package p000;

import java.io.Serializable;

/* renamed from: bx */
public abstract class C0317bx extends C0856hv implements Serializable {
    public C0317bx(C0317bx bxVar) {
        super((C0856hv) bxVar);
    }

    public C0317bx(C0652ev evVar) {
        super(evVar.mo3184j());
    }

    public C0317bx(C1884us usVar) {
        super(usVar);
    }
}
