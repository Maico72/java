package p000;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;

/* renamed from: g2 */
public class C0731g2 extends ToggleButton {

    /* renamed from: d */
    public final C0523d2 f2815d;

    public C0731g2(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842827);
        C2045x2.m5634a(this, getContext());
        C0523d2 d2Var = new C0523d2(this);
        this.f2815d = d2Var;
        d2Var.mo2865e(attributeSet, 16842827);
    }
}
