package p000;

/* renamed from: fv */
public abstract class C0720fv {

    /* renamed from: fv$a */
    public interface C0721a {
        /* renamed from: a */
        Class<?> mo3659a(Class<?> cls);
    }
}
