package p000;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: db */
public class C0544db extends C0682fb {
    public C0544db(RecyclerView.C0162m mVar) {
        super(mVar, (C0544db) null);
    }

    /* renamed from: b */
    public int mo2971b(View view) {
        return this.f2724a.mo1116H(view) + ((RecyclerView.C0167n) view.getLayoutParams()).rightMargin;
    }

    /* renamed from: c */
    public int mo2972c(View view) {
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
        return this.f2724a.mo1114G(view) + nVar.leftMargin + nVar.rightMargin;
    }

    /* renamed from: d */
    public int mo2973d(View view) {
        RecyclerView.C0167n nVar = (RecyclerView.C0167n) view.getLayoutParams();
        return this.f2724a.mo1112F(view) + nVar.topMargin + nVar.bottomMargin;
    }

    /* renamed from: e */
    public int mo2974e(View view) {
        return this.f2724a.mo1110E(view) - ((RecyclerView.C0167n) view.getLayoutParams()).leftMargin;
    }

    /* renamed from: f */
    public int mo2975f() {
        return this.f2724a.f879o;
    }

    /* renamed from: g */
    public int mo2976g() {
        RecyclerView.C0162m mVar = this.f2724a;
        return mVar.f879o - mVar.mo1132Q();
    }

    /* renamed from: h */
    public int mo2977h() {
        return this.f2724a.mo1132Q();
    }

    /* renamed from: i */
    public int mo2978i() {
        return this.f2724a.f877m;
    }

    /* renamed from: j */
    public int mo2979j() {
        return this.f2724a.f878n;
    }

    /* renamed from: k */
    public int mo2980k() {
        return this.f2724a.mo1131P();
    }

    /* renamed from: l */
    public int mo2981l() {
        RecyclerView.C0162m mVar = this.f2724a;
        return (mVar.f879o - mVar.mo1131P()) - this.f2724a.mo1132Q();
    }

    /* renamed from: n */
    public int mo2982n(View view) {
        this.f2724a.mo1143Y(view, true, this.f2726c);
        return this.f2726c.right;
    }

    /* renamed from: o */
    public int mo2983o(View view) {
        this.f2724a.mo1143Y(view, true, this.f2726c);
        return this.f2726c.left;
    }

    /* renamed from: p */
    public void mo2984p(int i) {
        this.f2724a.mo1151e0(i);
    }
}
