package com.suke.widget;

import android.animation.Animator;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.Checkable;
import java.util.Objects;

public class SwitchButton extends View implements Checkable {

    /* renamed from: b0 */
    public static final int f2033b0 = m1621c(58.0f);

    /* renamed from: c0 */
    public static final int f2034c0 = m1621c(36.0f);

    /* renamed from: A */
    public float f2035A;

    /* renamed from: B */
    public float f2036B;

    /* renamed from: C */
    public float f2037C;

    /* renamed from: D */
    public Paint f2038D;

    /* renamed from: E */
    public Paint f2039E;

    /* renamed from: F */
    public C0453e f2040F;

    /* renamed from: G */
    public C0453e f2041G;

    /* renamed from: H */
    public C0453e f2042H;

    /* renamed from: I */
    public RectF f2043I = new RectF();

    /* renamed from: J */
    public int f2044J = 0;

    /* renamed from: K */
    public ValueAnimator f2045K;

    /* renamed from: L */
    public final ArgbEvaluator f2046L = new ArgbEvaluator();

    /* renamed from: M */
    public boolean f2047M;

    /* renamed from: N */
    public boolean f2048N;

    /* renamed from: O */
    public boolean f2049O;

    /* renamed from: P */
    public boolean f2050P;

    /* renamed from: Q */
    public boolean f2051Q = false;

    /* renamed from: R */
    public boolean f2052R = false;

    /* renamed from: S */
    public boolean f2053S = false;

    /* renamed from: T */
    public C0452d f2054T;

    /* renamed from: U */
    public long f2055U;

    /* renamed from: V */
    public Runnable f2056V = new C0449a();

    /* renamed from: W */
    public ValueAnimator.AnimatorUpdateListener f2057W = new C0450b();

    /* renamed from: a0 */
    public Animator.AnimatorListener f2058a0 = new C0451c();

    /* renamed from: d */
    public int f2059d;

    /* renamed from: e */
    public int f2060e;

    /* renamed from: f */
    public int f2061f;

    /* renamed from: g */
    public float f2062g;

    /* renamed from: h */
    public float f2063h;

    /* renamed from: i */
    public float f2064i;

    /* renamed from: j */
    public float f2065j;

    /* renamed from: k */
    public float f2066k;

    /* renamed from: l */
    public float f2067l;

    /* renamed from: m */
    public float f2068m;

    /* renamed from: n */
    public float f2069n;

    /* renamed from: o */
    public int f2070o;

    /* renamed from: p */
    public int f2071p;

    /* renamed from: q */
    public int f2072q;

    /* renamed from: r */
    public int f2073r;

    /* renamed from: s */
    public int f2074s;

    /* renamed from: t */
    public int f2075t;

    /* renamed from: u */
    public float f2076u;

    /* renamed from: v */
    public int f2077v;

    /* renamed from: w */
    public int f2078w;

    /* renamed from: x */
    public float f2079x;

    /* renamed from: y */
    public float f2080y;

    /* renamed from: z */
    public float f2081z;

    /* renamed from: com.suke.widget.SwitchButton$a */
    public class C0449a implements Runnable {
        public C0449a() {
        }

        public void run() {
            SwitchButton switchButton = SwitchButton.this;
            int i = switchButton.f2044J;
            boolean z = false;
            if (!(i != 0)) {
                if (i != 0) {
                    z = true;
                }
                if (!z && switchButton.f2051Q) {
                    if (switchButton.f2045K.isRunning()) {
                        switchButton.f2045K.cancel();
                    }
                    switchButton.f2044J = 1;
                    C0453e.m1632a(switchButton.f2041G, switchButton.f2040F);
                    C0453e.m1632a(switchButton.f2042H, switchButton.f2040F);
                    if (switchButton.isChecked()) {
                        C0453e eVar = switchButton.f2042H;
                        int i2 = switchButton.f2072q;
                        eVar.f2086b = i2;
                        eVar.f2085a = switchButton.f2037C;
                        eVar.f2087c = i2;
                    } else {
                        C0453e eVar2 = switchButton.f2042H;
                        eVar2.f2086b = switchButton.f2071p;
                        eVar2.f2085a = switchButton.f2036B;
                        eVar2.f2088d = switchButton.f2062g;
                    }
                    switchButton.f2045K.start();
                }
            }
        }
    }

    /* renamed from: com.suke.widget.SwitchButton$b */
    public class C0450b implements ValueAnimator.AnimatorUpdateListener {
        public C0450b() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            SwitchButton switchButton = SwitchButton.this;
            int i = switchButton.f2044J;
            if (i == 1 || i == 3 || i == 4) {
                switchButton.f2040F.f2087c = ((Integer) switchButton.f2046L.evaluate(floatValue, Integer.valueOf(switchButton.f2041G.f2087c), Integer.valueOf(SwitchButton.this.f2042H.f2087c))).intValue();
                SwitchButton switchButton2 = SwitchButton.this;
                C0453e eVar = switchButton2.f2040F;
                C0453e eVar2 = switchButton2.f2041G;
                float f = eVar2.f2088d;
                C0453e eVar3 = switchButton2.f2042H;
                eVar.f2088d = C1012kd.m3192a(eVar3.f2088d, f, floatValue, f);
                if (switchButton2.f2044J != 1) {
                    float f2 = eVar2.f2085a;
                    eVar.f2085a = C1012kd.m3192a(eVar3.f2085a, f2, floatValue, f2);
                }
                eVar.f2086b = ((Integer) switchButton2.f2046L.evaluate(floatValue, Integer.valueOf(eVar2.f2086b), Integer.valueOf(SwitchButton.this.f2042H.f2086b))).intValue();
            } else if (i == 5) {
                C0453e eVar4 = switchButton.f2040F;
                float f3 = switchButton.f2041G.f2085a;
                float a = C1012kd.m3192a(switchButton.f2042H.f2085a, f3, floatValue, f3);
                eVar4.f2085a = a;
                float f4 = switchButton.f2036B;
                float f5 = (a - f4) / (switchButton.f2037C - f4);
                eVar4.f2086b = ((Integer) switchButton.f2046L.evaluate(f5, Integer.valueOf(switchButton.f2071p), Integer.valueOf(SwitchButton.this.f2072q))).intValue();
                SwitchButton switchButton3 = SwitchButton.this;
                C0453e eVar5 = switchButton3.f2040F;
                eVar5.f2088d = switchButton3.f2062g * f5;
                eVar5.f2087c = ((Integer) switchButton3.f2046L.evaluate(f5, 0, Integer.valueOf(SwitchButton.this.f2074s))).intValue();
            }
            SwitchButton.this.postInvalidate();
        }
    }

    /* renamed from: com.suke.widget.SwitchButton$c */
    public class C0451c implements Animator.AnimatorListener {
        public C0451c() {
        }

        public void onAnimationCancel(Animator animator) {
        }

        public void onAnimationEnd(Animator animator) {
            SwitchButton switchButton = SwitchButton.this;
            int i = switchButton.f2044J;
            if (i == 1) {
                switchButton.f2044J = 2;
                C0453e eVar = switchButton.f2040F;
                eVar.f2087c = 0;
                eVar.f2088d = switchButton.f2062g;
            } else if (i != 3) {
                if (i != 4) {
                    if (i == 5) {
                        switchButton.f2047M = !switchButton.f2047M;
                    } else {
                        return;
                    }
                }
                switchButton.f2044J = 0;
                switchButton.postInvalidate();
                SwitchButton.this.mo2670a();
                return;
            } else {
                switchButton.f2044J = 0;
            }
            switchButton.postInvalidate();
        }

        public void onAnimationRepeat(Animator animator) {
        }

        public void onAnimationStart(Animator animator) {
        }
    }

    /* renamed from: com.suke.widget.SwitchButton$d */
    public interface C0452d {
        /* renamed from: a */
        void mo2695a(SwitchButton switchButton, boolean z);
    }

    /* renamed from: com.suke.widget.SwitchButton$e */
    public static class C0453e {

        /* renamed from: a */
        public float f2085a;

        /* renamed from: b */
        public int f2086b;

        /* renamed from: c */
        public int f2087c;

        /* renamed from: d */
        public float f2088d;

        /* renamed from: a */
        public static void m1632a(C0453e eVar, C0453e eVar2) {
            Objects.requireNonNull(eVar);
            eVar.f2085a = eVar2.f2085a;
            eVar.f2086b = eVar2.f2086b;
            eVar.f2087c = eVar2.f2087c;
            eVar.f2088d = eVar2.f2088d;
        }
    }

    public SwitchButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = attributeSet != null ? context.obtainStyledAttributes(attributeSet, d80.f2199a) : null;
        this.f2049O = m1622g(obtainStyledAttributes, 10, true);
        this.f2077v = m1623h(obtainStyledAttributes, 15, -5592406);
        this.f2078w = m1624i(obtainStyledAttributes, 17, m1621c(1.5f));
        this.f2079x = m1620b(10.0f);
        float b = m1620b(4.0f);
        this.f2080y = obtainStyledAttributes != null ? obtainStyledAttributes.getDimension(16, b) : b;
        this.f2081z = m1620b(4.0f);
        this.f2035A = m1620b(4.0f);
        this.f2059d = m1624i(obtainStyledAttributes, 12, m1621c(2.5f));
        this.f2060e = m1624i(obtainStyledAttributes, 11, m1621c(1.5f));
        this.f2061f = m1623h(obtainStyledAttributes, 9, 855638016);
        this.f2071p = m1623h(obtainStyledAttributes, 14, -2236963);
        this.f2072q = m1623h(obtainStyledAttributes, 4, -11414681);
        this.f2073r = m1624i(obtainStyledAttributes, 1, m1621c(1.0f));
        this.f2074s = m1623h(obtainStyledAttributes, 5, -1);
        this.f2075t = m1624i(obtainStyledAttributes, 6, m1621c(1.0f));
        this.f2076u = m1620b(6.0f);
        int h = m1623h(obtainStyledAttributes, 2, -1);
        int i = obtainStyledAttributes != null ? obtainStyledAttributes.getInt(7, 300) : 300;
        this.f2047M = m1622g(obtainStyledAttributes, 3, false);
        this.f2050P = m1622g(obtainStyledAttributes, 13, true);
        this.f2070o = m1623h(obtainStyledAttributes, 0, -1);
        this.f2048N = m1622g(obtainStyledAttributes, 8, true);
        if (obtainStyledAttributes != null) {
            obtainStyledAttributes.recycle();
        }
        this.f2039E = new Paint(1);
        Paint paint = new Paint(1);
        this.f2038D = paint;
        paint.setColor(h);
        if (this.f2049O) {
            this.f2038D.setShadowLayer((float) this.f2059d, 0.0f, (float) this.f2060e, this.f2061f);
        }
        this.f2040F = new C0453e();
        this.f2041G = new C0453e();
        this.f2042H = new C0453e();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        this.f2045K = ofFloat;
        ofFloat.setDuration((long) i);
        this.f2045K.setRepeatCount(0);
        this.f2045K.addUpdateListener(this.f2057W);
        this.f2045K.addListener(this.f2058a0);
        super.setClickable(true);
        setPadding(0, 0, 0, 0);
        setLayerType(1, (Paint) null);
    }

    /* renamed from: b */
    public static float m1620b(float f) {
        return TypedValue.applyDimension(1, f, Resources.getSystem().getDisplayMetrics());
    }

    /* renamed from: c */
    public static int m1621c(float f) {
        return (int) m1620b(f);
    }

    /* renamed from: g */
    public static boolean m1622g(TypedArray typedArray, int i, boolean z) {
        return typedArray == null ? z : typedArray.getBoolean(i, z);
    }

    /* renamed from: h */
    public static int m1623h(TypedArray typedArray, int i, int i2) {
        return typedArray == null ? i2 : typedArray.getColor(i, i2);
    }

    /* renamed from: i */
    public static int m1624i(TypedArray typedArray, int i, int i2) {
        return typedArray == null ? i2 : typedArray.getDimensionPixelOffset(i, i2);
    }

    private void setCheckedViewState(C0453e eVar) {
        eVar.f2088d = this.f2062g;
        eVar.f2086b = this.f2072q;
        eVar.f2087c = this.f2074s;
        eVar.f2085a = this.f2037C;
    }

    private void setUncheckViewState(C0453e eVar) {
        eVar.f2088d = 0.0f;
        eVar.f2086b = this.f2071p;
        eVar.f2087c = 0;
        eVar.f2085a = this.f2036B;
    }

    /* renamed from: a */
    public final void mo2670a() {
        C0452d dVar = this.f2054T;
        if (dVar != null) {
            this.f2053S = true;
            dVar.mo2695a(this, isChecked());
        }
        this.f2053S = false;
    }

    /* renamed from: d */
    public final void mo2671d(Canvas canvas, float f, float f2, float f3, float f4, float f5, Paint paint) {
        if (Build.VERSION.SDK_INT >= 21) {
            canvas.drawRoundRect(f, f2, f3, f4, f5, f5, paint);
            return;
        }
        this.f2043I.set(f, f2, f3, f4);
        canvas.drawRoundRect(this.f2043I, f5, f5, paint);
    }

    /* renamed from: e */
    public final boolean mo2672e() {
        return this.f2044J == 2;
    }

    /* renamed from: f */
    public final boolean mo2673f() {
        int i = this.f2044J;
        return i == 1 || i == 3;
    }

    public boolean isChecked() {
        return this.f2047M;
    }

    /* renamed from: j */
    public final void mo2675j() {
        if (mo2672e() || mo2673f()) {
            if (this.f2045K.isRunning()) {
                this.f2045K.cancel();
            }
            this.f2044J = 3;
            C0453e.m1632a(this.f2041G, this.f2040F);
            if (isChecked()) {
                setCheckedViewState(this.f2042H);
            } else {
                setUncheckViewState(this.f2042H);
            }
            this.f2045K.start();
        }
    }

    /* renamed from: k */
    public final void mo2676k(boolean z, boolean z2) {
        if (isEnabled()) {
            if (this.f2053S) {
                throw new RuntimeException("should NOT switch the state in method: [onCheckedChanged]!");
            } else if (!this.f2052R) {
                this.f2047M = !this.f2047M;
                if (z2) {
                    mo2670a();
                }
            } else {
                if (this.f2045K.isRunning()) {
                    this.f2045K.cancel();
                }
                if (!this.f2048N || !z) {
                    this.f2047M = !this.f2047M;
                    if (isChecked()) {
                        setCheckedViewState(this.f2040F);
                    } else {
                        setUncheckViewState(this.f2040F);
                    }
                    postInvalidate();
                    if (z2) {
                        mo2670a();
                        return;
                    }
                    return;
                }
                this.f2044J = 5;
                C0453e.m1632a(this.f2041G, this.f2040F);
                if (isChecked()) {
                    setUncheckViewState(this.f2042H);
                } else {
                    setCheckedViewState(this.f2042H);
                }
                this.f2045K.start();
            }
        }
    }

    public void onDraw(Canvas canvas) {
        Canvas canvas2;
        Canvas canvas3 = canvas;
        super.onDraw(canvas);
        this.f2039E.setStrokeWidth((float) this.f2073r);
        this.f2039E.setStyle(Paint.Style.FILL);
        this.f2039E.setColor(this.f2070o);
        mo2671d(canvas, this.f2065j, this.f2066k, this.f2067l, this.f2068m, this.f2062g, this.f2039E);
        this.f2039E.setStyle(Paint.Style.STROKE);
        this.f2039E.setColor(this.f2071p);
        mo2671d(canvas, this.f2065j, this.f2066k, this.f2067l, this.f2068m, this.f2062g, this.f2039E);
        if (this.f2050P) {
            int i = this.f2077v;
            float f = this.f2067l - this.f2079x;
            float f2 = this.f2069n;
            float f3 = this.f2080y;
            Paint paint = this.f2039E;
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(i);
            paint.setStrokeWidth((float) this.f2078w);
            canvas3.drawCircle(f, f2, f3, paint);
        }
        float f4 = this.f2040F.f2088d * 0.5f;
        this.f2039E.setStyle(Paint.Style.STROKE);
        this.f2039E.setColor(this.f2040F.f2086b);
        this.f2039E.setStrokeWidth((f4 * 2.0f) + ((float) this.f2073r));
        mo2671d(canvas, this.f2065j + f4, this.f2066k + f4, this.f2067l - f4, this.f2068m - f4, this.f2062g, this.f2039E);
        this.f2039E.setStyle(Paint.Style.FILL);
        this.f2039E.setStrokeWidth(1.0f);
        float f5 = this.f2065j;
        float f6 = this.f2066k;
        float f7 = this.f2062g;
        float f8 = (f7 * 2.0f) + f5;
        float f9 = (f7 * 2.0f) + f6;
        Paint paint2 = this.f2039E;
        if (Build.VERSION.SDK_INT >= 21) {
            canvas2 = canvas3;
            canvas.drawArc(f5, f6, f8, f9, 90.0f, 180.0f, true, paint2);
        } else {
            canvas2 = canvas3;
            this.f2043I.set(f5, f6, f8, f9);
            canvas.drawArc(this.f2043I, 90.0f, 180.0f, true, paint2);
        }
        float f10 = this.f2065j;
        float f11 = this.f2062g;
        float f12 = this.f2066k;
        canvas.drawRect(f10 + f11, f12, this.f2040F.f2085a, (f11 * 2.0f) + f12, this.f2039E);
        if (this.f2050P) {
            int i2 = this.f2040F.f2087c;
            float f13 = this.f2065j + this.f2062g;
            float f14 = f13 - this.f2081z;
            float f15 = this.f2069n;
            float f16 = this.f2076u;
            float f17 = f15 - f16;
            float f18 = f13 - this.f2035A;
            float f19 = f15 + f16;
            Paint paint3 = this.f2039E;
            paint3.setStyle(Paint.Style.STROKE);
            paint3.setColor(i2);
            paint3.setStrokeWidth((float) this.f2075t);
            canvas.drawLine(f14, f17, f18, f19, paint3);
        }
        float f20 = this.f2040F.f2085a;
        float f21 = this.f2069n;
        canvas2.drawCircle(f20, f21, this.f2063h, this.f2038D);
        this.f2039E.setStyle(Paint.Style.STROKE);
        this.f2039E.setStrokeWidth(1.0f);
        this.f2039E.setColor(-2236963);
        canvas2.drawCircle(f20, f21, this.f2063h, this.f2039E);
    }

    public void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        if (mode == 0 || mode == Integer.MIN_VALUE) {
            i = View.MeasureSpec.makeMeasureSpec(f2033b0, 1073741824);
        }
        if (mode2 == 0 || mode2 == Integer.MIN_VALUE) {
            i2 = View.MeasureSpec.makeMeasureSpec(f2034c0, 1073741824);
        }
        super.onMeasure(i, i2);
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        float max = (float) Math.max(this.f2059d + this.f2060e, this.f2073r);
        float f = ((float) i2) - max;
        float f2 = f - max;
        this.f2064i = f2;
        float f3 = ((float) i) - max;
        float f4 = f2 * 0.5f;
        this.f2062g = f4;
        this.f2063h = f4 - ((float) this.f2073r);
        this.f2065j = max;
        this.f2066k = max;
        this.f2067l = f3;
        this.f2068m = f;
        this.f2069n = (f + max) * 0.5f;
        this.f2036B = max + f4;
        this.f2037C = f3 - f4;
        if (isChecked()) {
            setCheckedViewState(this.f2040F);
        } else {
            setUncheckViewState(this.f2040F);
        }
        this.f2052R = true;
        postInvalidate();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002d, code lost:
        if (mo2672e() == false) goto L_0x0123;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0109, code lost:
        if (mo2673f() != false) goto L_0x010b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
            r9 = this;
            boolean r0 = r9.isEnabled()
            r1 = 0
            if (r0 != 0) goto L_0x0008
            return r1
        L_0x0008:
            int r0 = r10.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L_0x010f
            r3 = 1065353216(0x3f800000, float:1.0)
            r4 = 0
            if (r0 == r2) goto L_0x0096
            r5 = 2
            if (r0 == r5) goto L_0x0031
            r10 = 3
            if (r0 == r10) goto L_0x001c
            goto L_0x0123
        L_0x001c:
            r9.f2051Q = r1
            java.lang.Runnable r10 = r9.f2056V
            r9.removeCallbacks(r10)
            boolean r10 = r9.mo2673f()
            if (r10 != 0) goto L_0x010b
            boolean r10 = r9.mo2672e()
            if (r10 == 0) goto L_0x0123
            goto L_0x010b
        L_0x0031:
            float r10 = r10.getX()
            boolean r0 = r9.mo2673f()
            if (r0 == 0) goto L_0x0057
            int r0 = r9.getWidth()
            float r0 = (float) r0
            float r10 = r10 / r0
            float r10 = java.lang.Math.min(r3, r10)
            float r10 = java.lang.Math.max(r4, r10)
            com.suke.widget.SwitchButton$e r0 = r9.f2040F
            float r1 = r9.f2036B
            float r3 = r9.f2037C
            float r10 = p000.C1012kd.m3192a(r3, r1, r10, r1)
            r0.f2085a = r10
            goto L_0x0123
        L_0x0057:
            boolean r0 = r9.mo2672e()
            if (r0 == 0) goto L_0x0123
            int r0 = r9.getWidth()
            float r0 = (float) r0
            float r10 = r10 / r0
            float r10 = java.lang.Math.min(r3, r10)
            float r10 = java.lang.Math.max(r4, r10)
            com.suke.widget.SwitchButton$e r0 = r9.f2040F
            float r1 = r9.f2036B
            float r3 = r9.f2037C
            float r1 = p000.C1012kd.m3192a(r3, r1, r10, r1)
            r0.f2085a = r1
            android.animation.ArgbEvaluator r1 = r9.f2046L
            int r3 = r9.f2071p
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            int r4 = r9.f2072q
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            java.lang.Object r10 = r1.evaluate(r10, r3, r4)
            java.lang.Integer r10 = (java.lang.Integer) r10
            int r10 = r10.intValue()
            r0.f2086b = r10
            r9.postInvalidate()
            goto L_0x0123
        L_0x0096:
            r9.f2051Q = r1
            java.lang.Runnable r0 = r9.f2056V
            r9.removeCallbacks(r0)
            long r5 = java.lang.System.currentTimeMillis()
            long r7 = r9.f2055U
            long r5 = r5 - r7
            r7 = 300(0x12c, double:1.48E-321)
            int r0 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r0 > 0) goto L_0x00af
            r9.toggle()
            goto L_0x0123
        L_0x00af:
            boolean r0 = r9.mo2672e()
            if (r0 == 0) goto L_0x0105
            float r10 = r10.getX()
            int r0 = r9.getWidth()
            float r0 = (float) r0
            float r10 = r10 / r0
            float r10 = java.lang.Math.min(r3, r10)
            float r10 = java.lang.Math.max(r4, r10)
            r0 = 1056964608(0x3f000000, float:0.5)
            int r10 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
            if (r10 <= 0) goto L_0x00ce
            r1 = 1
        L_0x00ce:
            boolean r10 = r9.isChecked()
            if (r1 != r10) goto L_0x00d5
            goto L_0x010b
        L_0x00d5:
            r9.f2047M = r1
            android.animation.ValueAnimator r10 = r9.f2045K
            boolean r10 = r10.isRunning()
            if (r10 == 0) goto L_0x00e4
            android.animation.ValueAnimator r10 = r9.f2045K
            r10.cancel()
        L_0x00e4:
            r10 = 4
            r9.f2044J = r10
            com.suke.widget.SwitchButton$e r10 = r9.f2041G
            com.suke.widget.SwitchButton$e r0 = r9.f2040F
            com.suke.widget.SwitchButton.C0453e.m1632a(r10, r0)
            boolean r10 = r9.isChecked()
            if (r10 == 0) goto L_0x00fa
            com.suke.widget.SwitchButton$e r10 = r9.f2042H
            r9.setCheckedViewState(r10)
            goto L_0x00ff
        L_0x00fa:
            com.suke.widget.SwitchButton$e r10 = r9.f2042H
            r9.setUncheckViewState(r10)
        L_0x00ff:
            android.animation.ValueAnimator r10 = r9.f2045K
            r10.start()
            goto L_0x0123
        L_0x0105:
            boolean r10 = r9.mo2673f()
            if (r10 == 0) goto L_0x0123
        L_0x010b:
            r9.mo2675j()
            goto L_0x0123
        L_0x010f:
            r9.f2051Q = r2
            long r0 = java.lang.System.currentTimeMillis()
            r9.f2055U = r0
            java.lang.Runnable r10 = r9.f2056V
            r9.removeCallbacks(r10)
            java.lang.Runnable r10 = r9.f2056V
            r0 = 100
            r9.postDelayed(r10, r0)
        L_0x0123:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.suke.widget.SwitchButton.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setChecked(boolean z) {
        if (z == isChecked()) {
            postInvalidate();
        } else {
            mo2676k(this.f2048N, false);
        }
    }

    public void setEnableEffect(boolean z) {
        this.f2048N = z;
    }

    public void setOnCheckedChangeListener(C0452d dVar) {
        this.f2054T = dVar;
    }

    public final void setOnClickListener(View.OnClickListener onClickListener) {
    }

    public final void setOnLongClickListener(View.OnLongClickListener onLongClickListener) {
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
        super.setPadding(0, 0, 0, 0);
    }

    public void setShadowEffect(boolean z) {
        if (this.f2049O != z) {
            this.f2049O = z;
            if (z) {
                this.f2038D.setShadowLayer((float) this.f2059d, 0.0f, (float) this.f2060e, this.f2061f);
            } else {
                this.f2038D.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
            }
        }
    }

    public void toggle() {
        mo2676k(true, true);
    }
}
