package com.roughike.bottombar;

import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import java.util.WeakHashMap;

public class BottomBarTab extends LinearLayout {
    private static final float ACTIVE_SHIFTING_TITLELESS_ICON_SCALE = 1.24f;
    private static final float ACTIVE_TITLE_SCALE = 1.0f;
    private static final long ANIMATION_DURATION = 150;
    private static final float INACTIVE_FIXED_TITLE_SCALE = 0.86f;
    private static final float INACTIVE_SHIFTING_TITLELESS_ICON_SCALE = 1.0f;
    public static final String STATE_BADGE_COUNT = "STATE_BADGE_COUNT_FOR_TAB_";
    private float activeAlpha;
    private int activeColor;
    public BottomBarBadge badge;
    private int badgeBackgroundColor;
    private boolean badgeHidesWhenActive;
    private int barColorWhenSelected;
    private final int eightDps;
    private int iconResId;
    /* access modifiers changed from: private */
    public AppCompatImageView iconView;
    private float inActiveAlpha;
    private int inActiveColor;
    private int indexInContainer;
    /* access modifiers changed from: private */
    public boolean isActive;
    private boolean isTitleless;
    private final int sixDps;
    private final int sixteenDps;
    private String title;
    private int titleTextAppearanceResId;
    private Typeface titleTypeFace;
    private TextView titleView;
    private Type type = Type.FIXED;

    /* renamed from: com.roughike.bottombar.BottomBarTab$5 */
    public static /* synthetic */ class C04445 {
        public static final /* synthetic */ int[] $SwitchMap$com$roughike$bottombar$BottomBarTab$Type;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|(2:1|2)|3|5|6|7|8|10) */
        /* JADX WARNING: Code restructure failed: missing block: B:11:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0015 */
        static {
            /*
                com.roughike.bottombar.BottomBarTab.Type.values()
                r0 = 3
                int[] r1 = new int[r0]
                $SwitchMap$com$roughike$bottombar$BottomBarTab$Type = r1
                r2 = 1
                com.roughike.bottombar.BottomBarTab$Type r3 = com.roughike.bottombar.BottomBarTab.Type.FIXED     // Catch:{ NoSuchFieldError -> 0x000e }
                r3 = 0
                r1[r3] = r2     // Catch:{ NoSuchFieldError -> 0x000e }
            L_0x000e:
                r1 = 2
                int[] r3 = $SwitchMap$com$roughike$bottombar$BottomBarTab$Type     // Catch:{ NoSuchFieldError -> 0x0015 }
                com.roughike.bottombar.BottomBarTab$Type r4 = com.roughike.bottombar.BottomBarTab.Type.SHIFTING     // Catch:{ NoSuchFieldError -> 0x0015 }
                r3[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0015 }
            L_0x0015:
                int[] r2 = $SwitchMap$com$roughike$bottombar$BottomBarTab$Type     // Catch:{ NoSuchFieldError -> 0x001b }
                com.roughike.bottombar.BottomBarTab$Type r3 = com.roughike.bottombar.BottomBarTab.Type.TABLET     // Catch:{ NoSuchFieldError -> 0x001b }
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x001b }
            L_0x001b:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.roughike.bottombar.BottomBarTab.C04445.<clinit>():void");
        }
    }

    public static class Config {
        /* access modifiers changed from: private */
        public final float activeTabAlpha;
        /* access modifiers changed from: private */
        public final int activeTabColor;
        /* access modifiers changed from: private */
        public final int badgeBackgroundColor;
        /* access modifiers changed from: private */
        public boolean badgeHidesWhenSelected;
        /* access modifiers changed from: private */
        public final int barColorWhenSelected;
        /* access modifiers changed from: private */
        public final float inActiveTabAlpha;
        /* access modifiers changed from: private */
        public final int inActiveTabColor;
        /* access modifiers changed from: private */
        public final int titleTextAppearance;
        /* access modifiers changed from: private */
        public final Typeface titleTypeFace;

        public static class Builder {
            /* access modifiers changed from: private */
            public float activeTabAlpha;
            /* access modifiers changed from: private */
            public int activeTabColor;
            /* access modifiers changed from: private */
            public int badgeBackgroundColor;
            /* access modifiers changed from: private */
            public int barColorWhenSelected;
            /* access modifiers changed from: private */
            public boolean hidesBadgeWhenSelected = true;
            /* access modifiers changed from: private */
            public float inActiveTabAlpha;
            /* access modifiers changed from: private */
            public int inActiveTabColor;
            /* access modifiers changed from: private */
            public int titleTextAppearance;
            /* access modifiers changed from: private */
            public Typeface titleTypeFace;

            public Builder activeTabAlpha(float f) {
                this.activeTabAlpha = f;
                return this;
            }

            public Builder activeTabColor(int i) {
                this.activeTabColor = i;
                return this;
            }

            public Builder badgeBackgroundColor(int i) {
                this.badgeBackgroundColor = i;
                return this;
            }

            public Builder barColorWhenSelected(int i) {
                this.barColorWhenSelected = i;
                return this;
            }

            public Config build() {
                return new Config(this);
            }

            public Builder hideBadgeWhenSelected(boolean z) {
                this.hidesBadgeWhenSelected = z;
                return this;
            }

            public Builder inActiveTabAlpha(float f) {
                this.inActiveTabAlpha = f;
                return this;
            }

            public Builder inActiveTabColor(int i) {
                this.inActiveTabColor = i;
                return this;
            }

            public Builder titleTextAppearance(int i) {
                this.titleTextAppearance = i;
                return this;
            }

            public Builder titleTypeFace(Typeface typeface) {
                this.titleTypeFace = typeface;
                return this;
            }
        }

        private Config(Builder builder) {
            this.badgeHidesWhenSelected = true;
            this.inActiveTabAlpha = builder.inActiveTabAlpha;
            this.activeTabAlpha = builder.activeTabAlpha;
            this.inActiveTabColor = builder.inActiveTabColor;
            this.activeTabColor = builder.activeTabColor;
            this.barColorWhenSelected = builder.barColorWhenSelected;
            this.badgeBackgroundColor = builder.badgeBackgroundColor;
            this.badgeHidesWhenSelected = builder.hidesBadgeWhenSelected;
            this.titleTextAppearance = builder.titleTextAppearance;
            this.titleTypeFace = builder.titleTypeFace;
        }
    }

    public enum Type {
        FIXED,
        SHIFTING,
        TABLET
    }

    public BottomBarTab(Context context) {
        super(context);
        this.sixDps = MiscUtils.dpToPixel(context, 6.0f);
        this.eightDps = MiscUtils.dpToPixel(context, 8.0f);
        this.sixteenDps = MiscUtils.dpToPixel(context, 16.0f);
    }

    private void animateColors(int i, int i2) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(new int[]{i, i2});
        valueAnimator.setEvaluator(new ArgbEvaluator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                BottomBarTab.this.setColors(((Integer) valueAnimator.getAnimatedValue()).intValue());
            }
        });
        valueAnimator.setDuration(ANIMATION_DURATION);
        valueAnimator.start();
    }

    private void animateIcon(float f, float f2) {
        C0675f7 a = C0010a7.m28a(this.iconView);
        a.mo3524e(ANIMATION_DURATION);
        a.mo3520a(f);
        a.mo3528i();
        if (this.isTitleless && this.type == Type.SHIFTING) {
            animateIconScale(f2);
        }
    }

    private void animateIconScale(float f) {
        C0675f7 a = C0010a7.m28a(this.iconView);
        a.mo3524e(ANIMATION_DURATION);
        a.mo3522c(f);
        a.mo3523d(f);
        a.mo3528i();
    }

    private void animateTitle(int i, float f, float f2) {
        if (this.type != Type.TABLET || !this.isTitleless) {
            setTopPaddingAnimated(this.iconView.getPaddingTop(), i);
            C0675f7 a = C0010a7.m28a(this.titleView);
            a.mo3524e(ANIMATION_DURATION);
            a.mo3522c(f);
            a.mo3523d(f);
            a.mo3520a(f2);
            a.mo3528i();
        }
    }

    private void setAlphas(float f) {
        AppCompatImageView appCompatImageView = this.iconView;
        if (appCompatImageView != null) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            appCompatImageView.setAlpha(f);
        }
        TextView textView = this.titleView;
        if (textView != null) {
            WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
            textView.setAlpha(f);
        }
    }

    /* access modifiers changed from: private */
    public void setColors(int i) {
        AppCompatImageView appCompatImageView = this.iconView;
        if (appCompatImageView != null) {
            appCompatImageView.setColorFilter(i);
            this.iconView.setTag(C0446R.C0448id.bb_bottom_bar_color_id, Integer.valueOf(i));
        }
        TextView textView = this.titleView;
        if (textView != null) {
            textView.setTextColor(i);
        }
    }

    private void setIconScale(float f) {
        if (this.isTitleless && this.type == Type.SHIFTING) {
            AppCompatImageView appCompatImageView = this.iconView;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            appCompatImageView.setScaleX(f);
            this.iconView.setScaleY(f);
        }
    }

    private void setTitleScale(float f) {
        if (this.type != Type.TABLET && !this.isTitleless) {
            TextView textView = this.titleView;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            textView.setScaleX(f);
            this.titleView.setScaleY(f);
        }
    }

    private void setTopPadding(int i) {
        if (this.type != Type.TABLET && !this.isTitleless) {
            AppCompatImageView appCompatImageView = this.iconView;
            appCompatImageView.setPadding(appCompatImageView.getPaddingLeft(), i, this.iconView.getPaddingRight(), this.iconView.getPaddingBottom());
        }
    }

    private void setTopPaddingAnimated(int i, int i2) {
        if (this.type != Type.TABLET && !this.isTitleless) {
            ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{i, i2});
            ofInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    BottomBarTab.this.iconView.setPadding(BottomBarTab.this.iconView.getPaddingLeft(), ((Integer) valueAnimator.getAnimatedValue()).intValue(), BottomBarTab.this.iconView.getPaddingRight(), BottomBarTab.this.iconView.getPaddingBottom());
                }
            });
            ofInt.setDuration(ANIMATION_DURATION);
            ofInt.start();
        }
    }

    private void updateBadgePosition() {
        BottomBarBadge bottomBarBadge = this.badge;
        if (bottomBarBadge != null) {
            bottomBarBadge.adjustPositionAndSize(this);
        }
    }

    private void updateCustomTextAppearance() {
        int i;
        TextView textView = this.titleView;
        if (textView != null && (i = this.titleTextAppearanceResId) != 0) {
            if (Build.VERSION.SDK_INT >= 23) {
                textView.setTextAppearance(i);
            } else {
                textView.setTextAppearance(getContext(), this.titleTextAppearanceResId);
            }
            this.titleView.setTag(C0446R.C0448id.bb_bottom_bar_appearance_id, Integer.valueOf(this.titleTextAppearanceResId));
        }
    }

    private void updateCustomTypeface() {
        TextView textView;
        Typeface typeface = this.titleTypeFace;
        if (typeface != null && (textView = this.titleView) != null) {
            textView.setTypeface(typeface);
        }
    }

    private void updateTitle() {
        TextView textView = this.titleView;
        if (textView != null) {
            textView.setText(this.title);
        }
    }

    public void deselect(boolean z) {
        BottomBarBadge bottomBarBadge;
        this.isActive = false;
        boolean z2 = this.type == Type.SHIFTING;
        float f = z2 ? 0.0f : INACTIVE_FIXED_TITLE_SCALE;
        int i = z2 ? this.sixteenDps : this.eightDps;
        if (z) {
            animateTitle(i, f, this.inActiveAlpha);
            animateIcon(this.inActiveAlpha, 1.0f);
            animateColors(this.activeColor, this.inActiveColor);
        } else {
            setTitleScale(f);
            setTopPadding(i);
            setIconScale(1.0f);
            setColors(this.inActiveColor);
            setAlphas(this.inActiveAlpha);
        }
        setSelected(false);
        if (!z2 && (bottomBarBadge = this.badge) != null && !bottomBarBadge.isVisible()) {
            this.badge.show();
        }
    }

    public float getActiveAlpha() {
        return this.activeAlpha;
    }

    public int getActiveColor() {
        return this.activeColor;
    }

    public int getBadgeBackgroundColor() {
        return this.badgeBackgroundColor;
    }

    public boolean getBadgeHidesWhenActive() {
        return this.badgeHidesWhenActive;
    }

    public int getBarColorWhenSelected() {
        return this.barColorWhenSelected;
    }

    public int getCurrentDisplayedIconColor() {
        Object tag = this.iconView.getTag(C0446R.C0448id.bb_bottom_bar_color_id);
        if (tag instanceof Integer) {
            return ((Integer) tag).intValue();
        }
        return 0;
    }

    public int getCurrentDisplayedTextAppearance() {
        Object tag = this.titleView.getTag(C0446R.C0448id.bb_bottom_bar_appearance_id);
        if (this.titleView == null || !(tag instanceof Integer)) {
            return 0;
        }
        return ((Integer) tag).intValue();
    }

    public int getCurrentDisplayedTitleColor() {
        TextView textView = this.titleView;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return 0;
    }

    public int getIconResId() {
        return this.iconResId;
    }

    public AppCompatImageView getIconView() {
        return this.iconView;
    }

    public float getInActiveAlpha() {
        return this.inActiveAlpha;
    }

    public int getInActiveColor() {
        return this.inActiveColor;
    }

    public int getIndexInTabContainer() {
        return this.indexInContainer;
    }

    public int getLayoutResource() {
        int ordinal = this.type.ordinal();
        if (ordinal == 0) {
            return C0446R.layout.bb_bottom_bar_item_fixed;
        }
        if (ordinal == 1) {
            return C0446R.layout.bb_bottom_bar_item_shifting;
        }
        if (ordinal == 2) {
            return C0446R.layout.bb_bottom_bar_item_fixed_tablet;
        }
        throw new RuntimeException("Unknown BottomBarTab type.");
    }

    public ViewGroup getOuterView() {
        return (ViewGroup) getParent();
    }

    public String getTitle() {
        return this.title;
    }

    public int getTitleTextAppearance() {
        return this.titleTextAppearanceResId;
    }

    public Typeface getTitleTypeFace() {
        return this.titleTypeFace;
    }

    public TextView getTitleView() {
        return this.titleView;
    }

    public Type getType() {
        return this.type;
    }

    public boolean hasActiveBadge() {
        return this.badge != null;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public boolean isTitleless() {
        return this.isTitleless;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            restoreState(bundle);
            parcelable = bundle.getParcelable("superstate");
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        if (this.badge == null) {
            return super.onSaveInstanceState();
        }
        Bundle saveState = saveState();
        saveState.putParcelable("superstate", super.onSaveInstanceState());
        return saveState;
    }

    public void prepareLayout() {
        LinearLayout.inflate(getContext(), getLayoutResource(), this);
        int i = 1;
        setOrientation(1);
        if (this.isTitleless) {
            i = 17;
        }
        setGravity(i);
        setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        setBackgroundResource(MiscUtils.getDrawableRes(getContext(), C0446R.attr.selectableItemBackgroundBorderless));
        AppCompatImageView appCompatImageView = (AppCompatImageView) findViewById(C0446R.C0448id.bb_bottom_bar_icon);
        this.iconView = appCompatImageView;
        appCompatImageView.setImageResource(this.iconResId);
        if (this.type != Type.TABLET && !this.isTitleless) {
            TextView textView = (TextView) findViewById(C0446R.C0448id.bb_bottom_bar_title);
            this.titleView = textView;
            textView.setVisibility(0);
            if (this.type == Type.SHIFTING) {
                findViewById(C0446R.C0448id.spacer).setVisibility(0);
            }
            updateTitle();
        }
        updateCustomTextAppearance();
        updateCustomTypeface();
    }

    public void removeBadge() {
        setBadgeCount(0);
    }

    public void restoreState(Bundle bundle) {
        StringBuilder d = C1012kd.m3195d(STATE_BADGE_COUNT);
        d.append(getIndexInTabContainer());
        setBadgeCount(bundle.getInt(d.toString()));
    }

    public Bundle saveState() {
        Bundle bundle = new Bundle();
        StringBuilder d = C1012kd.m3195d(STATE_BADGE_COUNT);
        d.append(getIndexInTabContainer());
        bundle.putInt(d.toString(), this.badge.getCount());
        return bundle;
    }

    public void select(boolean z) {
        this.isActive = true;
        if (z) {
            animateIcon(this.activeAlpha, ACTIVE_SHIFTING_TITLELESS_ICON_SCALE);
            animateTitle(this.sixDps, 1.0f, this.activeAlpha);
            animateColors(this.inActiveColor, this.activeColor);
        } else {
            setTitleScale(1.0f);
            setTopPadding(this.sixDps);
            setIconScale(ACTIVE_SHIFTING_TITLELESS_ICON_SCALE);
            setColors(this.activeColor);
            setAlphas(this.activeAlpha);
        }
        setSelected(true);
        BottomBarBadge bottomBarBadge = this.badge;
        if (bottomBarBadge != null && this.badgeHidesWhenActive) {
            bottomBarBadge.hide();
        }
    }

    public void setActiveAlpha(float f) {
        this.activeAlpha = f;
        if (this.isActive) {
            setAlphas(f);
        }
    }

    public void setActiveColor(int i) {
        this.activeColor = i;
        if (this.isActive) {
            setColors(i);
        }
    }

    public void setBadgeBackgroundColor(int i) {
        this.badgeBackgroundColor = i;
        BottomBarBadge bottomBarBadge = this.badge;
        if (bottomBarBadge != null) {
            bottomBarBadge.setColoredCircleBackground(i);
        }
    }

    public void setBadgeCount(int i) {
        if (i <= 0) {
            BottomBarBadge bottomBarBadge = this.badge;
            if (bottomBarBadge != null) {
                bottomBarBadge.removeFromTab(this);
                this.badge = null;
                return;
            }
            return;
        }
        if (this.badge == null) {
            BottomBarBadge bottomBarBadge2 = new BottomBarBadge(getContext());
            this.badge = bottomBarBadge2;
            bottomBarBadge2.attachToTab(this, this.badgeBackgroundColor);
        }
        this.badge.setCount(i);
        if (this.isActive && this.badgeHidesWhenActive) {
            this.badge.hide();
        }
    }

    public void setBadgeHidesWhenActive(boolean z) {
        this.badgeHidesWhenActive = z;
    }

    public void setBarColorWhenSelected(int i) {
        this.barColorWhenSelected = i;
    }

    public void setConfig(Config config) {
        setInActiveAlpha(config.inActiveTabAlpha);
        setActiveAlpha(config.activeTabAlpha);
        setInActiveColor(config.inActiveTabColor);
        setActiveColor(config.activeTabColor);
        setBarColorWhenSelected(config.barColorWhenSelected);
        setBadgeBackgroundColor(config.badgeBackgroundColor);
        setBadgeHidesWhenActive(config.badgeHidesWhenSelected);
        setTitleTextAppearance(config.titleTextAppearance);
        setTitleTypeface(config.titleTypeFace);
    }

    public void setIconResId(int i) {
        this.iconResId = i;
    }

    public void setIconTint(int i) {
        this.iconView.setColorFilter(i);
    }

    public void setInActiveAlpha(float f) {
        this.inActiveAlpha = f;
        if (!this.isActive) {
            setAlphas(f);
        }
    }

    public void setInActiveColor(int i) {
        this.inActiveColor = i;
        if (!this.isActive) {
            setColors(i);
        }
    }

    public void setIndexInContainer(int i) {
        this.indexInContainer = i;
    }

    public void setIsTitleless(boolean z) {
        if (!z || getIconResId() != 0) {
            this.isTitleless = z;
            return;
        }
        StringBuilder d = C1012kd.m3195d("This tab is supposed to be icon only, yet it has no icon specified. Index in container: ");
        d.append(getIndexInTabContainer());
        throw new IllegalStateException(d.toString());
    }

    public void setTitle(String str) {
        this.title = str;
        updateTitle();
    }

    public void setTitleTextAppearance(int i) {
        this.titleTextAppearanceResId = i;
        updateCustomTextAppearance();
    }

    public void setTitleTypeface(Typeface typeface) {
        this.titleTypeFace = typeface;
        updateCustomTypeface();
    }

    public void setType(Type type2) {
        this.type = type2;
    }

    public void updateWidth(float f, boolean z) {
        BottomBarBadge bottomBarBadge;
        if (!z) {
            getLayoutParams().width = (int) f;
            if (!this.isActive && (bottomBarBadge = this.badge) != null) {
                bottomBarBadge.adjustPositionAndSize(this);
                this.badge.show();
                return;
            }
            return;
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{(float) getWidth(), f});
        ofFloat.setDuration(ANIMATION_DURATION);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                ViewGroup.LayoutParams layoutParams = BottomBarTab.this.getLayoutParams();
                if (layoutParams != null) {
                    layoutParams.width = Math.round(((Float) valueAnimator.getAnimatedValue()).floatValue());
                    BottomBarTab.this.setLayoutParams(layoutParams);
                }
            }
        });
        ofFloat.addListener(new AnimatorListenerAdapter() {
            /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
                r2 = r1.this$0;
             */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void onAnimationEnd(android.animation.Animator r2) {
                /*
                    r1 = this;
                    com.roughike.bottombar.BottomBarTab r2 = com.roughike.bottombar.BottomBarTab.this
                    boolean r2 = r2.isActive
                    if (r2 != 0) goto L_0x0018
                    com.roughike.bottombar.BottomBarTab r2 = com.roughike.bottombar.BottomBarTab.this
                    com.roughike.bottombar.BottomBarBadge r0 = r2.badge
                    if (r0 == 0) goto L_0x0018
                    r0.adjustPositionAndSize(r2)
                    com.roughike.bottombar.BottomBarTab r2 = com.roughike.bottombar.BottomBarTab.this
                    com.roughike.bottombar.BottomBarBadge r2 = r2.badge
                    r2.show()
                L_0x0018:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.roughike.bottombar.BottomBarTab.C04423.onAnimationEnd(android.animation.Animator):void");
            }
        });
        ofFloat.start();
    }
}
