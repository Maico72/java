package com.roughike.bottombar;

public class BatchTabPropertyApplier {
    private final BottomBar bottomBar;

    public interface TabPropertyUpdater {
        void update(BottomBarTab bottomBarTab);
    }

    public BatchTabPropertyApplier(BottomBar bottomBar2) {
        this.bottomBar = bottomBar2;
    }

    public void applyToAllTabs(TabPropertyUpdater tabPropertyUpdater) {
        int tabCount = this.bottomBar.getTabCount();
        if (tabCount > 0) {
            for (int i = 0; i < tabCount; i++) {
                tabPropertyUpdater.update(this.bottomBar.getTabAtPosition(i));
            }
        }
    }
}
