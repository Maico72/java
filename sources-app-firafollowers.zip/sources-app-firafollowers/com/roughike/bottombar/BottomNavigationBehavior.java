package com.roughike.bottombar;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.snackbar.Snackbar$SnackbarLayout;
import java.util.WeakHashMap;

public class BottomNavigationBehavior<V extends View> extends VerticalScrollingBehavior<V> {
    private static final Interpolator INTERPOLATOR = new C1004k9();
    /* access modifiers changed from: private */
    public final int bottomNavHeight;
    /* access modifiers changed from: private */
    public final int defaultOffset;
    private boolean hidden = false;
    /* access modifiers changed from: private */
    public boolean isTablet = false;
    private boolean mScrollingEnabled;
    /* access modifiers changed from: private */
    public int mSnackbarHeight = -1;
    private C0675f7 mTranslationAnimator;
    private final BottomNavigationWithSnackbar mWithSnackBarImpl;

    public interface BottomNavigationWithSnackbar {
        void updateSnackbar(CoordinatorLayout coordinatorLayout, View view, View view2);
    }

    public class LollipopBottomNavWithSnackBarImpl implements BottomNavigationWithSnackbar {
        private LollipopBottomNavWithSnackBarImpl() {
        }

        public void updateSnackbar(CoordinatorLayout coordinatorLayout, View view, View view2) {
            if (!BottomNavigationBehavior.this.isTablet && (view instanceof Snackbar$SnackbarLayout)) {
                if (BottomNavigationBehavior.this.mSnackbarHeight == -1) {
                    int unused = BottomNavigationBehavior.this.mSnackbarHeight = view.getHeight();
                }
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (view2.getTranslationY() == 0.0f) {
                    view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), (BottomNavigationBehavior.this.bottomNavHeight + BottomNavigationBehavior.this.mSnackbarHeight) - BottomNavigationBehavior.this.defaultOffset);
                }
            }
        }
    }

    public class PreLollipopBottomNavWithSnackBarImpl implements BottomNavigationWithSnackbar {
        private PreLollipopBottomNavWithSnackBarImpl() {
        }

        public void updateSnackbar(CoordinatorLayout coordinatorLayout, View view, View view2) {
            if (!BottomNavigationBehavior.this.isTablet && (view instanceof Snackbar$SnackbarLayout)) {
                if (BottomNavigationBehavior.this.mSnackbarHeight == -1) {
                    int unused = BottomNavigationBehavior.this.mSnackbarHeight = view.getHeight();
                }
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (view2.getTranslationY() == 0.0f) {
                    ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).bottomMargin = (BottomNavigationBehavior.this.mSnackbarHeight + BottomNavigationBehavior.this.bottomNavHeight) - BottomNavigationBehavior.this.defaultOffset;
                    view2.bringToFront();
                    view2.getParent().requestLayout();
                }
            }
        }
    }

    public BottomNavigationBehavior(int i, int i2, boolean z) {
        this.mWithSnackBarImpl = Build.VERSION.SDK_INT >= 21 ? new LollipopBottomNavWithSnackBarImpl() : new PreLollipopBottomNavWithSnackBarImpl();
        this.mScrollingEnabled = true;
        this.bottomNavHeight = i;
        this.defaultOffset = i2;
        this.isTablet = z;
    }

    private void animateOffset(V v, int i) {
        ensureOrCancelAnimator(v);
        C0675f7 f7Var = this.mTranslationAnimator;
        f7Var.mo3529j((float) i);
        f7Var.mo3528i();
    }

    private void ensureOrCancelAnimator(V v) {
        C0675f7 f7Var = this.mTranslationAnimator;
        if (f7Var == null) {
            C0675f7 a = C0010a7.m28a(v);
            this.mTranslationAnimator = a;
            a.mo3524e(300);
            C0675f7 f7Var2 = this.mTranslationAnimator;
            Interpolator interpolator = INTERPOLATOR;
            View view = (View) f7Var2.f2700a.get();
            if (view != null) {
                view.animate().setInterpolator(interpolator);
                return;
            }
            return;
        }
        f7Var.mo3521b();
    }

    public static <V extends View> BottomNavigationBehavior<V> from(V v) {
        ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        if (layoutParams instanceof CoordinatorLayout.C0123f) {
            CoordinatorLayout.C0120c cVar = ((CoordinatorLayout.C0123f) layoutParams).f574a;
            if (cVar instanceof BottomNavigationBehavior) {
                return (BottomNavigationBehavior) cVar;
            }
            throw new IllegalArgumentException("The view is not associated with BottomNavigationBehavior");
        }
        throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
    }

    private void handleDirection(V v, int i) {
        int i2;
        if (this.mScrollingEnabled) {
            if (i == -1 && this.hidden) {
                this.hidden = false;
                i2 = this.defaultOffset;
            } else if (i == 1 && !this.hidden) {
                this.hidden = true;
                i2 = this.bottomNavHeight + this.defaultOffset;
            } else {
                return;
            }
            animateOffset(v, i2);
        }
    }

    private void updateScrollingForSnackbar(View view, boolean z) {
        if (!this.isTablet && (view instanceof Snackbar$SnackbarLayout)) {
            this.mScrollingEnabled = z;
        }
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, V v, View view) {
        this.mWithSnackBarImpl.updateSnackbar(coordinatorLayout, view, v);
        return view instanceof Snackbar$SnackbarLayout;
    }

    public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, V v, View view) {
        updateScrollingForSnackbar(view, false);
        return super.onDependentViewChanged(coordinatorLayout, v, view);
    }

    public void onDependentViewRemoved(CoordinatorLayout coordinatorLayout, V v, View view) {
        updateScrollingForSnackbar(view, true);
        super.onDependentViewRemoved(coordinatorLayout, v, view);
    }

    public void onDirectionNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
        handleDirection(v, i3);
    }

    public boolean onNestedDirectionFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, int i) {
        handleDirection(v, i);
        return true;
    }

    public void onNestedVerticalOverScroll(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3) {
    }

    public void setHidden(V v, boolean z) {
        int i;
        if (z || !this.hidden) {
            if (z && !this.hidden) {
                i = this.bottomNavHeight + this.defaultOffset;
            }
            this.hidden = z;
        }
        i = this.defaultOffset;
        animateOffset(v, i);
        this.hidden = z;
    }
}
