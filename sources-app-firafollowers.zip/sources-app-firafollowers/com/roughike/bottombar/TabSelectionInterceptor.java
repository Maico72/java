package com.roughike.bottombar;

public interface TabSelectionInterceptor {
    boolean shouldInterceptTabSelection(int i, int i2);
}
