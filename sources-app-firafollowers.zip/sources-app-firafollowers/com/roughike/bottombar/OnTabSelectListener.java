package com.roughike.bottombar;

public interface OnTabSelectListener {
    void onTabSelected(int i);
}
