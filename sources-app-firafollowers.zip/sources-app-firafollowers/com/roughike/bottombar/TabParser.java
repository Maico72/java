package com.roughike.bottombar;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.graphics.Color;
import com.roughike.bottombar.BottomBarTab;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParserException;

public class TabParser {
    private static final int AVG_NUMBER_OF_TABS = 5;
    private static final int COLOR_NOT_SET = -1;
    private static final int RESOURCE_NOT_FOUND = 0;
    private static final String TAB_TAG = "tab";
    private final Context context;
    private final BottomBarTab.Config defaultTabConfig;
    private final XmlResourceParser parser;
    private List<BottomBarTab> tabs = null;

    public static class TabParserException extends RuntimeException {
    }

    public TabParser(Context context2, BottomBarTab.Config config, int i) {
        this.context = context2;
        this.defaultTabConfig = config;
        this.parser = context2.getResources().getXml(i);
    }

    private int getColorValue(XmlResourceParser xmlResourceParser, int i) {
        int attributeResourceValue = xmlResourceParser.getAttributeResourceValue(i, 0);
        if (attributeResourceValue != 0) {
            return C1901v4.m5333b(this.context, attributeResourceValue);
        }
        try {
            return Color.parseColor(xmlResourceParser.getAttributeValue(i));
        } catch (Exception unused) {
            return -1;
        }
    }

    private String getTitleValue(XmlResourceParser xmlResourceParser, int i) {
        int attributeResourceValue = xmlResourceParser.getAttributeResourceValue(i, 0);
        return attributeResourceValue == 0 ? xmlResourceParser.getAttributeValue(i) : this.context.getString(attributeResourceValue);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.roughike.bottombar.BottomBarTab parseNewTab(android.content.res.XmlResourceParser r8, int r9) {
        /*
            r7 = this;
            com.roughike.bottombar.BottomBarTab r0 = r7.tabWithDefaults()
            r0.setIndexInContainer(r9)
            int r9 = r8.getAttributeCount()
            r1 = 0
            r2 = 0
        L_0x000d:
            if (r2 >= r9) goto L_0x00e1
            java.lang.String r3 = r8.getAttributeName(r2)
            r3.hashCode()
            int r4 = r3.hashCode()
            r5 = 1
            r6 = -1
            switch(r4) {
                case -1765033179: goto L_0x007c;
                case -1077332995: goto L_0x0071;
                case -738071611: goto L_0x0066;
                case -424740686: goto L_0x005b;
                case 3355: goto L_0x0050;
                case 3226745: goto L_0x0045;
                case 110371416: goto L_0x003a;
                case 1110315790: goto L_0x002f;
                case 1162188184: goto L_0x0022;
                default: goto L_0x001f;
            }
        L_0x001f:
            r3 = -1
            goto L_0x0086
        L_0x0022:
            java.lang.String r4 = "inActiveColor"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x002b
            goto L_0x001f
        L_0x002b:
            r3 = 8
            goto L_0x0086
        L_0x002f:
            java.lang.String r4 = "badgeHidesWhenActive"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x0038
            goto L_0x001f
        L_0x0038:
            r3 = 7
            goto L_0x0086
        L_0x003a:
            java.lang.String r4 = "title"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x0043
            goto L_0x001f
        L_0x0043:
            r3 = 6
            goto L_0x0086
        L_0x0045:
            java.lang.String r4 = "icon"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x004e
            goto L_0x001f
        L_0x004e:
            r3 = 5
            goto L_0x0086
        L_0x0050:
            java.lang.String r4 = "id"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x0059
            goto L_0x001f
        L_0x0059:
            r3 = 4
            goto L_0x0086
        L_0x005b:
            java.lang.String r4 = "badgeBackgroundColor"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x0064
            goto L_0x001f
        L_0x0064:
            r3 = 3
            goto L_0x0086
        L_0x0066:
            java.lang.String r4 = "iconOnly"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x006f
            goto L_0x001f
        L_0x006f:
            r3 = 2
            goto L_0x0086
        L_0x0071:
            java.lang.String r4 = "activeColor"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x007a
            goto L_0x001f
        L_0x007a:
            r3 = 1
            goto L_0x0086
        L_0x007c:
            java.lang.String r4 = "barColorWhenSelected"
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L_0x0085
            goto L_0x001f
        L_0x0085:
            r3 = 0
        L_0x0086:
            switch(r3) {
                case 0: goto L_0x00d3;
                case 1: goto L_0x00c8;
                case 2: goto L_0x00c0;
                case 3: goto L_0x00b5;
                case 4: goto L_0x00ad;
                case 5: goto L_0x00a5;
                case 6: goto L_0x009d;
                case 7: goto L_0x0095;
                case 8: goto L_0x008a;
                default: goto L_0x0089;
            }
        L_0x0089:
            goto L_0x00dd
        L_0x008a:
            int r3 = r7.getColorValue(r8, r2)
            if (r3 != r6) goto L_0x0091
            goto L_0x00dd
        L_0x0091:
            r0.setInActiveColor(r3)
            goto L_0x00dd
        L_0x0095:
            boolean r3 = r8.getAttributeBooleanValue(r2, r5)
            r0.setBadgeHidesWhenActive(r3)
            goto L_0x00dd
        L_0x009d:
            java.lang.String r3 = r7.getTitleValue(r8, r2)
            r0.setTitle(r3)
            goto L_0x00dd
        L_0x00a5:
            int r3 = r8.getAttributeResourceValue(r2, r1)
            r0.setIconResId(r3)
            goto L_0x00dd
        L_0x00ad:
            int r3 = r8.getIdAttributeResourceValue(r2)
            r0.setId(r3)
            goto L_0x00dd
        L_0x00b5:
            int r3 = r7.getColorValue(r8, r2)
            if (r3 != r6) goto L_0x00bc
            goto L_0x00dd
        L_0x00bc:
            r0.setBadgeBackgroundColor(r3)
            goto L_0x00dd
        L_0x00c0:
            boolean r3 = r8.getAttributeBooleanValue(r2, r1)
            r0.setIsTitleless(r3)
            goto L_0x00dd
        L_0x00c8:
            int r3 = r7.getColorValue(r8, r2)
            if (r3 != r6) goto L_0x00cf
            goto L_0x00dd
        L_0x00cf:
            r0.setActiveColor(r3)
            goto L_0x00dd
        L_0x00d3:
            int r3 = r7.getColorValue(r8, r2)
            if (r3 != r6) goto L_0x00da
            goto L_0x00dd
        L_0x00da:
            r0.setBarColorWhenSelected(r3)
        L_0x00dd:
            int r2 = r2 + 1
            goto L_0x000d
        L_0x00e1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.roughike.bottombar.TabParser.parseNewTab(android.content.res.XmlResourceParser, int):com.roughike.bottombar.BottomBarTab");
    }

    private BottomBarTab tabWithDefaults() {
        BottomBarTab bottomBarTab = new BottomBarTab(this.context);
        bottomBarTab.setConfig(this.defaultTabConfig);
        return bottomBarTab;
    }

    public List<BottomBarTab> parseTabs() {
        int next;
        if (this.tabs == null) {
            this.tabs = new ArrayList(5);
            do {
                try {
                    next = this.parser.next();
                    if (next == 2 && TAB_TAG.equals(this.parser.getName())) {
                        this.tabs.add(parseNewTab(this.parser, this.tabs.size()));
                    }
                } catch (IOException | XmlPullParserException e) {
                    e.printStackTrace();
                    throw new TabParserException();
                }
            } while (next != 1);
        }
        return this.tabs;
    }
}
