package com.roughike.bottombar;

import android.content.Context;
import android.widget.FrameLayout;

public class BadgeContainer extends FrameLayout {
    public BadgeContainer(Context context) {
        super(context);
    }
}
