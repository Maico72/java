package com.roughike.bottombar;

public class ShySettings {
    private BottomBar bottomBar;
    private Boolean pendingIsVisibleInShyMode;

    public ShySettings(BottomBar bottomBar2) {
        this.bottomBar = bottomBar2;
    }

    private void toggleIsVisibleInShyMode(boolean z) {
        if (this.bottomBar.isShy()) {
            if (this.bottomBar.isShyHeightAlreadyCalculated()) {
                BottomNavigationBehavior from = BottomNavigationBehavior.from(this.bottomBar);
                if (from != null) {
                    from.setHidden(this.bottomBar, !z);
                    return;
                }
                return;
            }
            this.pendingIsVisibleInShyMode = Boolean.TRUE;
        }
    }

    private void updatePendingShyVisibility() {
        Boolean bool = this.pendingIsVisibleInShyMode;
        if (bool != null) {
            toggleIsVisibleInShyMode(bool.booleanValue());
            this.pendingIsVisibleInShyMode = null;
        }
    }

    public void hideBar() {
        toggleIsVisibleInShyMode(false);
    }

    public void showBar() {
        toggleIsVisibleInShyMode(true);
    }

    public void shyHeightCalculated() {
        updatePendingShyVisibility();
    }
}
