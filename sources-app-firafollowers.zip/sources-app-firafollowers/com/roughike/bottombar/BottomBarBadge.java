package com.roughike.bottombar;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;

public class BottomBarBadge extends TextView {
    private int count;
    private boolean isVisible = false;

    public BottomBarBadge(Context context) {
        super(context);
    }

    private void setBackgroundCompat(Drawable drawable) {
        setBackground(drawable);
    }

    private void wrapTabAndBadgeInSameContainer(final BottomBarTab bottomBarTab) {
        ViewGroup viewGroup = (ViewGroup) bottomBarTab.getParent();
        viewGroup.removeView(bottomBarTab);
        final BadgeContainer badgeContainer = new BadgeContainer(getContext());
        badgeContainer.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        badgeContainer.addView(bottomBarTab);
        badgeContainer.addView(this);
        viewGroup.addView(badgeContainer, bottomBarTab.getIndexInTabContainer());
        badgeContainer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                badgeContainer.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                BottomBarBadge.this.adjustPositionAndSize(bottomBarTab);
            }
        });
    }

    public void adjustPositionAndSize(BottomBarTab bottomBarTab) {
        AppCompatImageView iconView = bottomBarTab.getIconView();
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        int max = Math.max(getWidth(), getHeight());
        double width = (double) iconView.getWidth();
        Double.isNaN(width);
        setX(iconView.getX() + ((float) (width / 1.25d)));
        setTranslationY(10.0f);
        if (layoutParams.width != max || layoutParams.height != max) {
            layoutParams.width = max;
            layoutParams.height = max;
            setLayoutParams(layoutParams);
        }
    }

    public void attachToTab(BottomBarTab bottomBarTab, int i) {
        setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        setGravity(17);
        MiscUtils.setTextAppearance(this, C0446R.style.BB_BottomBarBadge_Text);
        setColoredCircleBackground(i);
        wrapTabAndBadgeInSameContainer(bottomBarTab);
    }

    public int getCount() {
        return this.count;
    }

    public void hide() {
        this.isVisible = false;
        C0675f7 a = C0010a7.m28a(this);
        a.mo3524e(150);
        a.mo3520a(0.0f);
        a.mo3522c(0.0f);
        a.mo3523d(0.0f);
        a.mo3528i();
    }

    public boolean isVisible() {
        return this.isVisible;
    }

    public void removeFromTab(BottomBarTab bottomBarTab) {
        BadgeContainer badgeContainer = (BadgeContainer) getParent();
        ViewGroup viewGroup = (ViewGroup) badgeContainer.getParent();
        badgeContainer.removeView(bottomBarTab);
        viewGroup.removeView(badgeContainer);
        viewGroup.addView(bottomBarTab, bottomBarTab.getIndexInTabContainer());
    }

    public void setColoredCircleBackground(int i) {
        int dpToPixel = MiscUtils.dpToPixel(getContext(), 1.0f);
        ShapeDrawable make = BadgeCircle.make(dpToPixel * 3, i);
        setPadding(dpToPixel, dpToPixel, dpToPixel, dpToPixel);
        setBackgroundCompat(make);
    }

    public void setCount(int i) {
        this.count = i;
        setText(String.valueOf(i));
    }

    public void show() {
        this.isVisible = true;
        C0675f7 a = C0010a7.m28a(this);
        a.mo3524e(150);
        a.mo3520a(1.0f);
        a.mo3522c(1.0f);
        a.mo3523d(1.0f);
        a.mo3528i();
    }
}
