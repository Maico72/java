package com.roughike.bottombar;

public interface OnTabReselectListener {
    void onTabReSelected(int i);
}
