package com.roughike.bottombar;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

public abstract class VerticalScrollingBehavior<V extends View> extends CoordinatorLayout.C0120c<V> {
    private int overScrollDirection = 0;
    private int scrollDirection = 0;
    private int totalDy = 0;
    private int totalDyUnconsumed = 0;

    public VerticalScrollingBehavior() {
    }

    public VerticalScrollingBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public int getOverScrollDirection() {
        return this.overScrollDirection;
    }

    public int getScrollDirection() {
        return this.scrollDirection;
    }

    public C0943j7 onApplyWindowInsets(CoordinatorLayout coordinatorLayout, V v, C0943j7 j7Var) {
        return super.onApplyWindowInsets(coordinatorLayout, v, j7Var);
    }

    public abstract void onDirectionNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3);

    public abstract boolean onNestedDirectionFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, int i);

    public boolean onNestedFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, boolean z) {
        super.onNestedFling(coordinatorLayout, v, view, f, f2, z);
        int i = f2 > 0.0f ? 1 : -1;
        this.scrollDirection = i;
        return onNestedDirectionFling(coordinatorLayout, v, view, f, f2, i);
    }

    public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return super.onNestedPreFling(coordinatorLayout, v, view, f, f2);
    }

    public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr) {
        int i3;
        super.onNestedPreScroll(coordinatorLayout, v, view, i, i2, iArr);
        if (i2 <= 0 || this.totalDy >= 0) {
            if (i2 < 0 && this.totalDy > 0) {
                this.totalDy = 0;
                i3 = -1;
            }
            this.totalDy += i2;
            onDirectionNestedPreScroll(coordinatorLayout, v, view, i, i2, iArr, this.scrollDirection);
        }
        this.totalDy = 0;
        i3 = 1;
        this.scrollDirection = i3;
        this.totalDy += i2;
        onDirectionNestedPreScroll(coordinatorLayout, v, view, i, i2, iArr, this.scrollDirection);
    }

    public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        int i5;
        super.onNestedScroll(coordinatorLayout, v, view, i, i2, i3, i4);
        if (i4 <= 0 || this.totalDyUnconsumed >= 0) {
            if (i4 < 0 && this.totalDyUnconsumed > 0) {
                this.totalDyUnconsumed = 0;
                i5 = -1;
            }
            int i6 = this.totalDyUnconsumed + i4;
            this.totalDyUnconsumed = i6;
            onNestedVerticalOverScroll(coordinatorLayout, v, this.overScrollDirection, i2, i6);
        }
        this.totalDyUnconsumed = 0;
        i5 = 1;
        this.overScrollDirection = i5;
        int i62 = this.totalDyUnconsumed + i4;
        this.totalDyUnconsumed = i62;
        onNestedVerticalOverScroll(coordinatorLayout, v, this.overScrollDirection, i2, i62);
    }

    public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        super.onNestedScrollAccepted(coordinatorLayout, v, view, view2, i);
    }

    public abstract void onNestedVerticalOverScroll(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3);

    public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, V v) {
        return super.onSaveInstanceState(coordinatorLayout, v);
    }

    public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view) {
        super.onStopNestedScroll(coordinatorLayout, v, view);
    }
}
