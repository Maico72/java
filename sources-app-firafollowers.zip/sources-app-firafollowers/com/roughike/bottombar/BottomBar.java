package com.roughike.bottombar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewParent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.roughike.bottombar.BatchTabPropertyApplier;
import com.roughike.bottombar.BottomBarTab;
import java.util.List;
import java.util.WeakHashMap;

public class BottomBar extends LinearLayout implements View.OnClickListener, View.OnLongClickListener {
    private static final int BEHAVIOR_DRAW_UNDER_NAV = 4;
    private static final int BEHAVIOR_ICONS_ONLY = 8;
    private static final int BEHAVIOR_NONE = 0;
    private static final int BEHAVIOR_SHIFTING = 1;
    private static final int BEHAVIOR_SHY = 2;
    private static final float DEFAULT_INACTIVE_SHIFTING_TAB_ALPHA = 0.6f;
    private static final String STATE_CURRENT_SELECTED_TAB = "STATE_CURRENT_SELECTED_TAB";
    private int activeShiftingItemWidth;
    /* access modifiers changed from: private */
    public float activeTabAlpha;
    /* access modifiers changed from: private */
    public int activeTabColor;
    /* access modifiers changed from: private */
    public View backgroundOverlay;
    /* access modifiers changed from: private */
    public int badgeBackgroundColor;
    private BatchTabPropertyApplier batchPropertyApplier;
    private int behaviors;
    private int currentBackgroundColor;
    private int currentTabPosition;
    private BottomBarTab[] currentTabs;
    private int defaultBackgroundColor;
    private boolean hideBadgeWhenActive;
    private boolean ignoreTabReselectionListener;
    private int inActiveShiftingItemWidth;
    /* access modifiers changed from: private */
    public float inActiveTabAlpha;
    /* access modifiers changed from: private */
    public int inActiveTabColor;
    private boolean isComingFromRestoredState;
    private boolean isTabletMode;
    private boolean longPressHintsEnabled;
    private int maxFixedItemWidth;
    private boolean navBarAccountedHeightCalculated;
    private OnTabReselectListener onTabReselectListener;
    private OnTabSelectListener onTabSelectListener;
    /* access modifiers changed from: private */
    public ViewGroup outerContainer;
    private int primaryColor;
    private int screenWidth;
    private float shadowElevation;
    private View shadowView;
    private boolean showShadow;
    private boolean shyHeightAlreadyCalculated;
    private ShySettings shySettings;
    private ViewGroup tabContainer;
    private TabSelectionInterceptor tabSelectionInterceptor;
    private int tabXmlResource;
    private int tenDp;
    /* access modifiers changed from: private */
    public int titleTextAppearance;
    /* access modifiers changed from: private */
    public Typeface titleTypeFace;

    public BottomBar(Context context) {
        this(context, (AttributeSet) null);
    }

    public BottomBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public BottomBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.defaultBackgroundColor = -1;
        init(context, attributeSet, i, 0);
    }

    public BottomBar(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.defaultBackgroundColor = -1;
        init(context, attributeSet, i, i2);
    }

    private void animateBGColorChange(View view, int i) {
        prepareForBackgroundColorAnimation(i);
        if (Build.VERSION.SDK_INT < 21) {
            backgroundCrossfadeAnimation(i);
        } else if (this.outerContainer.isAttachedToWindow()) {
            backgroundCircularRevealAnimation(view, i);
        }
    }

    @TargetApi(21)
    private void backgroundCircularRevealAnimation(View view, final int i) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(this.backgroundOverlay, (int) (view.getX() + ((float) (view.getMeasuredWidth() / 2))), (view.getMeasuredHeight() / 2) + (this.isTabletMode ? (int) view.getY() : 0), (float) 0, (float) (this.isTabletMode ? this.outerContainer.getHeight() : this.outerContainer.getWidth()));
        if (this.isTabletMode) {
            createCircularReveal.setDuration(500);
        }
        createCircularReveal.addListener(new AnimatorListenerAdapter() {
            private void onEnd() {
                BottomBar.this.outerContainer.setBackgroundColor(i);
                BottomBar.this.backgroundOverlay.setVisibility(4);
                View access$800 = BottomBar.this.backgroundOverlay;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                access$800.setAlpha(1.0f);
            }

            public void onAnimationCancel(Animator animator) {
                onEnd();
            }

            public void onAnimationEnd(Animator animator) {
                onEnd();
            }
        });
        createCircularReveal.start();
    }

    private void backgroundCrossfadeAnimation(final int i) {
        View view = this.backgroundOverlay;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        view.setAlpha(0.0f);
        C0675f7 a = C0010a7.m28a(this.backgroundOverlay);
        a.mo3520a(1.0f);
        C043010 r1 = new C0815h7() {
            private void onEnd() {
                BottomBar.this.outerContainer.setBackgroundColor(i);
                BottomBar.this.backgroundOverlay.setVisibility(4);
                View access$800 = BottomBar.this.backgroundOverlay;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                access$800.setAlpha(1.0f);
            }

            public void onAnimationCancel(View view) {
                onEnd();
            }

            public void onAnimationEnd(View view) {
                onEnd();
            }
        };
        View view2 = (View) a.f2700a.get();
        if (view2 != null) {
            a.mo3526g(view2, r1);
        }
        a.mo3528i();
    }

    private void determineInitialBackgroundColor() {
        if (isShiftingMode()) {
            this.defaultBackgroundColor = this.primaryColor;
        }
        Drawable background = getBackground();
        if (background != null && (background instanceof ColorDrawable)) {
            this.defaultBackgroundColor = ((ColorDrawable) background).getColor();
            setBackgroundColor(0);
        }
    }

    private boolean drawUnderNav() {
        return !this.isTabletMode && hasBehavior(4) && NavbarUtils.shouldDrawBehindNavbar(getContext());
    }

    private BottomBarTab findTabInLayout(ViewGroup viewGroup) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt instanceof BottomBarTab) {
                return (BottomBarTab) childAt;
            }
        }
        return null;
    }

    private BottomBarTab.Config getTabConfig() {
        return new BottomBarTab.Config.Builder().inActiveTabAlpha(this.inActiveTabAlpha).activeTabAlpha(this.activeTabAlpha).inActiveTabColor(this.inActiveTabColor).activeTabColor(this.activeTabColor).barColorWhenSelected(this.defaultBackgroundColor).badgeBackgroundColor(this.badgeBackgroundColor).hideBadgeWhenSelected(this.hideBadgeWhenActive).titleTextAppearance(this.titleTextAppearance).titleTypeFace(this.titleTypeFace).build();
    }

    private Typeface getTypeFaceFromAsset(String str) {
        if (str != null) {
            return Typeface.createFromAsset(getContext().getAssets(), str);
        }
        return null;
    }

    private void handleBackgroundColorChange(BottomBarTab bottomBarTab, boolean z) {
        int barColorWhenSelected = bottomBarTab.getBarColorWhenSelected();
        if (this.currentBackgroundColor != barColorWhenSelected) {
            if (!z) {
                this.outerContainer.setBackgroundColor(barColorWhenSelected);
                return;
            }
            boolean hasActiveBadge = bottomBarTab.hasActiveBadge();
            View view = bottomBarTab;
            if (hasActiveBadge) {
                view = bottomBarTab.getOuterView();
            }
            animateBGColorChange(view, barColorWhenSelected);
            this.currentBackgroundColor = barColorWhenSelected;
        }
    }

    private void handleClick(BottomBarTab bottomBarTab) {
        BottomBarTab currentTab = getCurrentTab();
        TabSelectionInterceptor tabSelectionInterceptor2 = this.tabSelectionInterceptor;
        if (tabSelectionInterceptor2 == null || !tabSelectionInterceptor2.shouldInterceptTabSelection(currentTab.getId(), bottomBarTab.getId())) {
            currentTab.deselect(true);
            bottomBarTab.select(true);
            shiftingMagic(currentTab, bottomBarTab, true);
            handleBackgroundColorChange(bottomBarTab, true);
            updateSelectedTab(bottomBarTab.getIndexInTabContainer());
        }
    }

    private boolean handleLongClick(BottomBarTab bottomBarTab) {
        if ((isShiftingMode() || this.isTabletMode) && (bottomBarTab.isActive() ^ true) && this.longPressHintsEnabled) {
            Toast.makeText(getContext(), bottomBarTab.getTitle(), 0).show();
        }
        return true;
    }

    private boolean hasBehavior(int i) {
        int i2 = this.behaviors;
        return (i | i2) == i2;
    }

    private void init(Context context, AttributeSet attributeSet, int i, int i2) {
        this.batchPropertyApplier = new BatchTabPropertyApplier(this);
        populateAttributes(context, attributeSet, i, i2);
        initializeViews();
        determineInitialBackgroundColor();
        if (Build.VERSION.SDK_INT >= 21) {
            init21(context);
        }
        int i3 = this.tabXmlResource;
        if (i3 != 0) {
            setItems(i3);
        }
    }

    private void init21(Context context) {
        if (this.showShadow) {
            float elevation = getElevation();
            this.shadowElevation = elevation;
            if (elevation <= 0.0f) {
                elevation = (float) getResources().getDimensionPixelSize(C0446R.dimen.bb_default_elevation);
            }
            this.shadowElevation = elevation;
            setElevation((float) MiscUtils.dpToPixel(context, elevation));
            setOutlineProvider(ViewOutlineProvider.BOUNDS);
        }
    }

    private void initializeShyBehavior() {
        int height;
        ViewParent parent = getParent();
        if (!(parent != null && (parent instanceof CoordinatorLayout))) {
            throw new RuntimeException("In order to have shy behavior, the BottomBar must be a direct child of a CoordinatorLayout.");
        } else if (!this.shyHeightAlreadyCalculated && (height = getHeight()) != 0) {
            updateShyHeight(height);
            getShySettings().shyHeightCalculated();
            this.shyHeightAlreadyCalculated = true;
        }
    }

    private void initializeViews() {
        boolean z = this.isTabletMode;
        int i = -2;
        int i2 = z ? -2 : -1;
        if (z) {
            i = -1;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, i);
        setLayoutParams(layoutParams);
        setOrientation(this.isTabletMode ^ true ? 1 : 0);
        View inflate = LinearLayout.inflate(getContext(), this.isTabletMode ? C0446R.layout.bb_bottom_bar_item_container_tablet : C0446R.layout.bb_bottom_bar_item_container, this);
        inflate.setLayoutParams(layoutParams);
        this.backgroundOverlay = inflate.findViewById(C0446R.C0448id.bb_bottom_bar_background_overlay);
        this.outerContainer = (ViewGroup) inflate.findViewById(C0446R.C0448id.bb_bottom_bar_outer_container);
        this.tabContainer = (ViewGroup) inflate.findViewById(C0446R.C0448id.bb_bottom_bar_item_container);
        this.shadowView = findViewById(C0446R.C0448id.bb_bottom_bar_shadow);
    }

    private boolean isIconsOnlyMode() {
        return !this.isTabletMode && hasBehavior(8);
    }

    private boolean isShiftingMode() {
        return !this.isTabletMode && hasBehavior(1);
    }

    private void populateAttributes(Context context, AttributeSet attributeSet, int i, int i2) {
        this.primaryColor = MiscUtils.getColor(getContext(), C0446R.attr.colorPrimary);
        this.screenWidth = MiscUtils.getScreenWidth(getContext());
        this.tenDp = MiscUtils.dpToPixel(getContext(), 10.0f);
        this.maxFixedItemWidth = MiscUtils.dpToPixel(getContext(), 168.0f);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, C0446R.styleable.BottomBar, i, i2);
        try {
            this.tabXmlResource = obtainStyledAttributes.getResourceId(C0446R.styleable.BottomBar_bb_tabXmlResource, 0);
            this.isTabletMode = obtainStyledAttributes.getBoolean(C0446R.styleable.BottomBar_bb_tabletMode, false);
            this.behaviors = obtainStyledAttributes.getInteger(C0446R.styleable.BottomBar_bb_behavior, 0);
            this.inActiveTabAlpha = obtainStyledAttributes.getFloat(C0446R.styleable.BottomBar_bb_inActiveTabAlpha, isShiftingMode() ? DEFAULT_INACTIVE_SHIFTING_TAB_ALPHA : 1.0f);
            this.activeTabAlpha = obtainStyledAttributes.getFloat(C0446R.styleable.BottomBar_bb_activeTabAlpha, 1.0f);
            int i3 = -1;
            int b = isShiftingMode() ? -1 : C1901v4.m5333b(context, C0446R.color.bb_inActiveBottomBarItemColor);
            if (!isShiftingMode()) {
                i3 = this.primaryColor;
            }
            this.longPressHintsEnabled = obtainStyledAttributes.getBoolean(C0446R.styleable.BottomBar_bb_longPressHintsEnabled, true);
            this.inActiveTabColor = obtainStyledAttributes.getColor(C0446R.styleable.BottomBar_bb_inActiveTabColor, b);
            this.activeTabColor = obtainStyledAttributes.getColor(C0446R.styleable.BottomBar_bb_activeTabColor, i3);
            this.badgeBackgroundColor = obtainStyledAttributes.getColor(C0446R.styleable.BottomBar_bb_badgeBackgroundColor, -65536);
            this.hideBadgeWhenActive = obtainStyledAttributes.getBoolean(C0446R.styleable.BottomBar_bb_badgesHideWhenActive, true);
            this.titleTextAppearance = obtainStyledAttributes.getResourceId(C0446R.styleable.BottomBar_bb_titleTextAppearance, 0);
            this.titleTypeFace = getTypeFaceFromAsset(obtainStyledAttributes.getString(C0446R.styleable.BottomBar_bb_titleTypeFace));
            this.showShadow = obtainStyledAttributes.getBoolean(C0446R.styleable.BottomBar_bb_showShadow, true);
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    private void prepareForBackgroundColorAnimation(int i) {
        this.outerContainer.clearAnimation();
        this.backgroundOverlay.clearAnimation();
        this.backgroundOverlay.setBackgroundColor(i);
        this.backgroundOverlay.setVisibility(0);
    }

    private void resizeForDrawingUnderNavbar() {
        int height = getHeight();
        if (height != 0 && !this.navBarAccountedHeightCalculated) {
            this.navBarAccountedHeightCalculated = true;
            this.tabContainer.getLayoutParams().height = height;
            int navbarHeight = NavbarUtils.getNavbarHeight(getContext()) + height;
            getLayoutParams().height = navbarHeight;
            if (isShy()) {
                updateShyHeight(navbarHeight);
            }
        }
    }

    private void resizeTabsToCorrectSizes(BottomBarTab[] bottomBarTabArr) {
        int pixelToDp = MiscUtils.pixelToDp(getContext(), getWidth());
        if (pixelToDp <= 0 || pixelToDp > this.screenWidth) {
            pixelToDp = this.screenWidth;
        }
        int min = Math.min(MiscUtils.dpToPixel(getContext(), (float) (pixelToDp / bottomBarTabArr.length)), this.maxFixedItemWidth);
        double d = (double) min;
        Double.isNaN(d);
        this.inActiveShiftingItemWidth = (int) (0.9d * d);
        double length = (double) (bottomBarTabArr.length - 1);
        Double.isNaN(length);
        Double.isNaN(d);
        Double.isNaN(d);
        this.activeShiftingItemWidth = (int) ((length * 0.1d * d) + d);
        int round = Math.round(getContext().getResources().getDimension(C0446R.dimen.bb_height));
        for (BottomBarTab bottomBarTab : bottomBarTabArr) {
            ViewGroup.LayoutParams layoutParams = bottomBarTab.getLayoutParams();
            layoutParams.height = round;
            if (isShiftingMode()) {
                layoutParams.width = bottomBarTab.isActive() ? this.activeShiftingItemWidth : this.inActiveShiftingItemWidth;
            } else {
                layoutParams.width = min;
            }
            if (bottomBarTab.getParent() == null) {
                this.tabContainer.addView(bottomBarTab);
            }
            bottomBarTab.setLayoutParams(layoutParams);
        }
    }

    private void shiftingMagic(BottomBarTab bottomBarTab, BottomBarTab bottomBarTab2, boolean z) {
        if (isShiftingMode()) {
            bottomBarTab.updateWidth((float) this.inActiveShiftingItemWidth, z);
            bottomBarTab2.updateWidth((float) this.activeShiftingItemWidth, z);
        }
    }

    private void updateItems(List<BottomBarTab> list) {
        this.tabContainer.removeAllViews();
        BottomBarTab[] bottomBarTabArr = new BottomBarTab[list.size()];
        int i = 0;
        int i2 = 0;
        for (BottomBarTab next : list) {
            BottomBarTab.Type type = isShiftingMode() ? BottomBarTab.Type.SHIFTING : this.isTabletMode ? BottomBarTab.Type.TABLET : BottomBarTab.Type.FIXED;
            if (isIconsOnlyMode()) {
                next.setIsTitleless(true);
            }
            next.setType(type);
            next.prepareLayout();
            if (i == this.currentTabPosition) {
                next.select(false);
                handleBackgroundColorChange(next, false);
            } else {
                next.deselect(false);
            }
            if (!this.isTabletMode) {
                if (next.getWidth() > i2) {
                    i2 = next.getWidth();
                }
                bottomBarTabArr[i] = next;
            } else {
                this.tabContainer.addView(next);
            }
            next.setOnClickListener(this);
            next.setOnLongClickListener(this);
            i++;
        }
        this.currentTabs = bottomBarTabArr;
        if (!this.isTabletMode) {
            resizeTabsToCorrectSizes(bottomBarTabArr);
        }
    }

    private void updateSelectedTab(int i) {
        int id = getTabAtPosition(i).getId();
        if (i != this.currentTabPosition) {
            OnTabSelectListener onTabSelectListener2 = this.onTabSelectListener;
            if (onTabSelectListener2 != null) {
                onTabSelectListener2.onTabSelected(id);
            }
        } else {
            OnTabReselectListener onTabReselectListener2 = this.onTabReselectListener;
            if (onTabReselectListener2 != null && !this.ignoreTabReselectionListener) {
                onTabReselectListener2.onTabReSelected(id);
            }
        }
        this.currentTabPosition = i;
        if (this.ignoreTabReselectionListener) {
            this.ignoreTabReselectionListener = false;
        }
    }

    private void updateShyHeight(int i) {
        ((CoordinatorLayout.C0123f) getLayoutParams()).mo684b(new BottomNavigationBehavior(i, 0, false));
    }

    private void updateTitleBottomPadding() {
        int height;
        if (!isIconsOnlyMode()) {
            int tabCount = getTabCount();
            if (this.tabContainer != null && tabCount != 0 && isShiftingMode()) {
                for (int i = 0; i < tabCount; i++) {
                    TextView titleView = getTabAtPosition(i).getTitleView();
                    if (titleView != null && (height = this.tenDp - (titleView.getHeight() - titleView.getBaseline())) > 0) {
                        titleView.setPadding(titleView.getPaddingLeft(), titleView.getPaddingTop(), titleView.getPaddingRight(), titleView.getPaddingBottom() + height);
                    }
                }
            }
        }
    }

    public int findPositionForTabWithId(int i) {
        return getTabWithId(i).getIndexInTabContainer();
    }

    public BottomBarTab getCurrentTab() {
        return getTabAtPosition(getCurrentTabPosition());
    }

    public int getCurrentTabId() {
        return getCurrentTab().getId();
    }

    public int getCurrentTabPosition() {
        return this.currentTabPosition;
    }

    public ShySettings getShySettings() {
        if (!isShy()) {
            Log.e("BottomBar", "Tried to get shy settings for a BottomBar that is not shy.");
        }
        if (this.shySettings == null) {
            this.shySettings = new ShySettings(this);
        }
        return this.shySettings;
    }

    public BottomBarTab getTabAtPosition(int i) {
        View childAt = this.tabContainer.getChildAt(i);
        return childAt instanceof BadgeContainer ? findTabInLayout((BadgeContainer) childAt) : (BottomBarTab) childAt;
    }

    public int getTabCount() {
        return this.tabContainer.getChildCount();
    }

    public BottomBarTab getTabWithId(int i) {
        return (BottomBarTab) this.tabContainer.findViewById(i);
    }

    public boolean isShy() {
        return !this.isTabletMode && hasBehavior(2);
    }

    public boolean isShyHeightAlreadyCalculated() {
        return this.shyHeightAlreadyCalculated;
    }

    public void onAttachedToWindow() {
        View view;
        super.onAttachedToWindow();
        if (Build.VERSION.SDK_INT < 21 && this.showShadow && (view = this.shadowView) != null) {
            view.setVisibility(0);
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
                marginLayoutParams.setMargins(marginLayoutParams.leftMargin, marginLayoutParams.topMargin - getResources().getDimensionPixelSize(C0446R.dimen.bb_fake_shadow_height), marginLayoutParams.rightMargin, marginLayoutParams.bottomMargin);
                setLayoutParams(layoutParams);
            }
        }
    }

    public void onClick(View view) {
        if (view instanceof BottomBarTab) {
            handleClick((BottomBarTab) view);
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            if (!this.isTabletMode) {
                resizeTabsToCorrectSizes(this.currentTabs);
            }
            updateTitleBottomPadding();
            if (isShy()) {
                initializeShyBehavior();
            }
            if (drawUnderNav()) {
                resizeForDrawingUnderNavbar();
            }
        }
    }

    public boolean onLongClick(View view) {
        return !(view instanceof BottomBarTab) || handleLongClick((BottomBarTab) view);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            restoreState(bundle);
            parcelable = bundle.getParcelable("superstate");
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        Bundle saveState = saveState();
        saveState.putParcelable("superstate", super.onSaveInstanceState());
        return saveState;
    }

    public void removeOnTabReselectListener() {
        this.onTabReselectListener = null;
    }

    public void removeOnTabSelectListener() {
        this.onTabSelectListener = null;
    }

    public void removeOverrideTabSelectionListener() {
        this.tabSelectionInterceptor = null;
    }

    public void restoreState(Bundle bundle) {
        if (bundle != null) {
            this.isComingFromRestoredState = true;
            this.ignoreTabReselectionListener = true;
            selectTabAtPosition(bundle.getInt(STATE_CURRENT_SELECTED_TAB, this.currentTabPosition), false);
        }
    }

    public Bundle saveState() {
        Bundle bundle = new Bundle();
        bundle.putInt(STATE_CURRENT_SELECTED_TAB, this.currentTabPosition);
        return bundle;
    }

    public void selectTabAtPosition(int i) {
        selectTabAtPosition(i, false);
    }

    public void selectTabAtPosition(int i, boolean z) {
        if (i > getTabCount() - 1 || i < 0) {
            throw new IndexOutOfBoundsException("Can't select tab at position " + i + ". This BottomBar has no items at that position.");
        }
        BottomBarTab currentTab = getCurrentTab();
        BottomBarTab tabAtPosition = getTabAtPosition(i);
        currentTab.deselect(z);
        tabAtPosition.select(z);
        updateSelectedTab(i);
        shiftingMagic(currentTab, tabAtPosition, z);
        handleBackgroundColorChange(tabAtPosition, z);
    }

    public void selectTabWithId(int i) {
        selectTabAtPosition(findPositionForTabWithId(i));
    }

    public void setActiveTabAlpha(float f) {
        this.activeTabAlpha = f;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setActiveAlpha(BottomBar.this.activeTabAlpha);
            }
        });
    }

    public void setActiveTabColor(int i) {
        this.activeTabColor = i;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setActiveColor(BottomBar.this.activeTabColor);
            }
        });
    }

    public void setBadgeBackgroundColor(int i) {
        this.badgeBackgroundColor = i;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setBadgeBackgroundColor(BottomBar.this.badgeBackgroundColor);
            }
        });
    }

    public void setBadgesHideWhenActive(final boolean z) {
        this.hideBadgeWhenActive = z;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setBadgeHidesWhenActive(z);
            }
        });
    }

    public void setDefaultTab(int i) {
        setDefaultTabPosition(findPositionForTabWithId(i));
    }

    public void setDefaultTabPosition(int i) {
        if (!this.isComingFromRestoredState) {
            selectTabAtPosition(i);
        }
    }

    public void setInActiveTabAlpha(float f) {
        this.inActiveTabAlpha = f;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setInActiveAlpha(BottomBar.this.inActiveTabAlpha);
            }
        });
    }

    public void setInActiveTabColor(int i) {
        this.inActiveTabColor = i;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setInActiveColor(BottomBar.this.inActiveTabColor);
            }
        });
    }

    public void setItems(int i) {
        setItems(i, (BottomBarTab.Config) null);
    }

    public void setItems(int i, BottomBarTab.Config config) {
        if (i != 0) {
            if (config == null) {
                config = getTabConfig();
            }
            updateItems(new TabParser(getContext(), config, i).parseTabs());
            return;
        }
        throw new RuntimeException("No items specified for the BottomBar!");
    }

    public void setLongPressHintsEnabled(boolean z) {
        this.longPressHintsEnabled = z;
    }

    public void setOnTabReselectListener(OnTabReselectListener onTabReselectListener2) {
        this.onTabReselectListener = onTabReselectListener2;
    }

    public void setOnTabSelectListener(OnTabSelectListener onTabSelectListener2) {
        setOnTabSelectListener(onTabSelectListener2, true);
    }

    public void setOnTabSelectListener(OnTabSelectListener onTabSelectListener2, boolean z) {
        this.onTabSelectListener = onTabSelectListener2;
        if (z && getTabCount() > 0) {
            onTabSelectListener2.onTabSelected(getCurrentTabId());
        }
    }

    public void setTabSelectionInterceptor(TabSelectionInterceptor tabSelectionInterceptor2) {
        this.tabSelectionInterceptor = tabSelectionInterceptor2;
    }

    public void setTabTitleTextAppearance(int i) {
        this.titleTextAppearance = i;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setTitleTextAppearance(BottomBar.this.titleTextAppearance);
            }
        });
    }

    public void setTabTitleTypeface(Typeface typeface) {
        this.titleTypeFace = typeface;
        this.batchPropertyApplier.applyToAllTabs(new BatchTabPropertyApplier.TabPropertyUpdater() {
            public void update(BottomBarTab bottomBarTab) {
                bottomBarTab.setTitleTypeface(BottomBar.this.titleTypeFace);
            }
        });
    }

    public void setTabTitleTypeface(String str) {
        setTabTitleTypeface(getTypeFaceFromAsset(str));
    }
}
