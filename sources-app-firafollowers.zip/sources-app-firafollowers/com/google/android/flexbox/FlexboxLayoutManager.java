package com.google.android.flexbox;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import p000.m10;

public class FlexboxLayoutManager extends RecyclerView.C0162m implements j10 {

    /* renamed from: O */
    public static final Rect f1635O = new Rect();

    /* renamed from: A */
    public C0387d f1636A;

    /* renamed from: B */
    public C0384b f1637B = new C0384b((C0383a) null);

    /* renamed from: C */
    public C0682fb f1638C;

    /* renamed from: D */
    public C0682fb f1639D;

    /* renamed from: E */
    public C0388e f1640E;

    /* renamed from: F */
    public int f1641F = -1;

    /* renamed from: G */
    public int f1642G = Integer.MIN_VALUE;

    /* renamed from: H */
    public int f1643H = Integer.MIN_VALUE;

    /* renamed from: I */
    public int f1644I = Integer.MIN_VALUE;

    /* renamed from: J */
    public SparseArray<View> f1645J = new SparseArray<>();

    /* renamed from: K */
    public final Context f1646K;

    /* renamed from: L */
    public View f1647L;

    /* renamed from: M */
    public int f1648M = -1;

    /* renamed from: N */
    public m10.C1155a f1649N = new m10.C1155a();

    /* renamed from: q */
    public int f1650q;

    /* renamed from: r */
    public int f1651r;

    /* renamed from: s */
    public int f1652s;

    /* renamed from: t */
    public int f1653t = -1;

    /* renamed from: u */
    public boolean f1654u;

    /* renamed from: v */
    public boolean f1655v;

    /* renamed from: w */
    public List<l10> f1656w = new ArrayList();

    /* renamed from: x */
    public final m10 f1657x = new m10(this);

    /* renamed from: y */
    public RecyclerView.C0173s f1658y;

    /* renamed from: z */
    public RecyclerView.C0178w f1659z;

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$b */
    public class C0384b {

        /* renamed from: a */
        public int f1660a;

        /* renamed from: b */
        public int f1661b;

        /* renamed from: c */
        public int f1662c;

        /* renamed from: d */
        public int f1663d = 0;

        /* renamed from: e */
        public boolean f1664e;

        /* renamed from: f */
        public boolean f1665f;

        /* renamed from: g */
        public boolean f1666g;

        public C0384b(C0383a aVar) {
        }

        /* renamed from: a */
        public static void m1448a(C0384b bVar) {
            int i;
            FlexboxLayoutManager flexboxLayoutManager;
            if (!FlexboxLayoutManager.this.mo2008v1()) {
                flexboxLayoutManager = FlexboxLayoutManager.this;
                if (flexboxLayoutManager.f1654u) {
                    if (!bVar.f1664e) {
                        i = flexboxLayoutManager.f879o - flexboxLayoutManager.f1638C.mo2980k();
                        bVar.f1662c = i;
                    }
                    i = flexboxLayoutManager.f1638C.mo2976g();
                    bVar.f1662c = i;
                }
            }
            if (bVar.f1664e) {
                flexboxLayoutManager = FlexboxLayoutManager.this;
                i = flexboxLayoutManager.f1638C.mo2976g();
                bVar.f1662c = i;
            }
            i = FlexboxLayoutManager.this.f1638C.mo2980k();
            bVar.f1662c = i;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0018, code lost:
            r1 = r5.f1667h;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:7:0x0026, code lost:
            r1 = r5.f1667h;
         */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static void m1449b(com.google.android.flexbox.FlexboxLayoutManager.C0384b r5) {
            /*
                r0 = -1
                r5.f1660a = r0
                r5.f1661b = r0
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                r5.f1662c = r0
                r0 = 0
                r5.f1665f = r0
                r5.f1666g = r0
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                boolean r1 = r1.mo2008v1()
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L_0x0026
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                int r4 = r1.f1651r
                if (r4 != 0) goto L_0x0023
                int r1 = r1.f1650q
                if (r1 != r3) goto L_0x0035
                goto L_0x0034
            L_0x0023:
                if (r4 != r2) goto L_0x0035
                goto L_0x0034
            L_0x0026:
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                int r4 = r1.f1651r
                if (r4 != 0) goto L_0x0032
                int r1 = r1.f1650q
                r2 = 3
                if (r1 != r2) goto L_0x0035
                goto L_0x0034
            L_0x0032:
                if (r4 != r2) goto L_0x0035
            L_0x0034:
                r0 = 1
            L_0x0035:
                r5.f1664e = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.C0384b.m1449b(com.google.android.flexbox.FlexboxLayoutManager$b):void");
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("AnchorInfo{mPosition=");
            d.append(this.f1660a);
            d.append(", mFlexLinePosition=");
            d.append(this.f1661b);
            d.append(", mCoordinate=");
            d.append(this.f1662c);
            d.append(", mPerpendicularCoordinate=");
            d.append(this.f1663d);
            d.append(", mLayoutFromEnd=");
            d.append(this.f1664e);
            d.append(", mValid=");
            d.append(this.f1665f);
            d.append(", mAssignedFromSavedState=");
            d.append(this.f1666g);
            d.append('}');
            return d.toString();
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$c */
    public static class C0385c extends RecyclerView.C0167n implements k10 {
        public static final Parcelable.Creator<C0385c> CREATOR = new C0386a();

        /* renamed from: h */
        public float f1668h = 0.0f;

        /* renamed from: i */
        public float f1669i = 1.0f;

        /* renamed from: j */
        public int f1670j = -1;

        /* renamed from: k */
        public float f1671k = -1.0f;

        /* renamed from: l */
        public int f1672l;

        /* renamed from: m */
        public int f1673m;

        /* renamed from: n */
        public int f1674n = 16777215;

        /* renamed from: o */
        public int f1675o = 16777215;

        /* renamed from: p */
        public boolean f1676p;

        /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$c$a */
        public class C0386a implements Parcelable.Creator<C0385c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0385c(parcel);
            }

            public Object[] newArray(int i) {
                return new C0385c[i];
            }
        }

        public C0385c(int i, int i2) {
            super(i, i2);
        }

        public C0385c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0385c(Parcel parcel) {
            super(-2, -2);
            this.f1668h = parcel.readFloat();
            this.f1669i = parcel.readFloat();
            this.f1670j = parcel.readInt();
            this.f1671k = parcel.readFloat();
            this.f1672l = parcel.readInt();
            this.f1673m = parcel.readInt();
            this.f1674n = parcel.readInt();
            this.f1675o = parcel.readInt();
            this.f1676p = parcel.readByte() != 0;
            this.bottomMargin = parcel.readInt();
            this.leftMargin = parcel.readInt();
            this.rightMargin = parcel.readInt();
            this.topMargin = parcel.readInt();
            this.height = parcel.readInt();
            this.width = parcel.readInt();
        }

        /* renamed from: a */
        public int mo2014a() {
            return this.rightMargin;
        }

        /* renamed from: b */
        public int mo2015b() {
            return this.f1673m;
        }

        /* renamed from: c */
        public int mo2016c() {
            return this.f1672l;
        }

        /* renamed from: d */
        public void mo2017d(int i) {
            this.f1673m = i;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: e */
        public boolean mo2019e() {
            return this.f1676p;
        }

        /* renamed from: f */
        public float mo2020f() {
            return this.f1668h;
        }

        /* renamed from: g */
        public int mo2021g() {
            return this.width;
        }

        /* renamed from: h */
        public int mo2022h() {
            return this.height;
        }

        /* renamed from: i */
        public int mo2023i() {
            return this.f1675o;
        }

        /* renamed from: j */
        public void mo2024j(int i) {
            this.f1672l = i;
        }

        /* renamed from: k */
        public int mo2025k() {
            return this.bottomMargin;
        }

        /* renamed from: l */
        public float mo2026l() {
            return this.f1671k;
        }

        /* renamed from: m */
        public int mo2027m() {
            return this.leftMargin;
        }

        /* renamed from: n */
        public int mo2028n() {
            return this.f1670j;
        }

        /* renamed from: o */
        public float mo2029o() {
            return this.f1669i;
        }

        /* renamed from: p */
        public int mo2030p() {
            return this.f1674n;
        }

        /* renamed from: q */
        public int mo2031q() {
            return this.topMargin;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeFloat(this.f1668h);
            parcel.writeFloat(this.f1669i);
            parcel.writeInt(this.f1670j);
            parcel.writeFloat(this.f1671k);
            parcel.writeInt(this.f1672l);
            parcel.writeInt(this.f1673m);
            parcel.writeInt(this.f1674n);
            parcel.writeInt(this.f1675o);
            parcel.writeByte(this.f1676p ? (byte) 1 : 0);
            parcel.writeInt(this.bottomMargin);
            parcel.writeInt(this.leftMargin);
            parcel.writeInt(this.rightMargin);
            parcel.writeInt(this.topMargin);
            parcel.writeInt(this.height);
            parcel.writeInt(this.width);
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$d */
    public static class C0387d {

        /* renamed from: a */
        public int f1677a;

        /* renamed from: b */
        public boolean f1678b;

        /* renamed from: c */
        public int f1679c;

        /* renamed from: d */
        public int f1680d;

        /* renamed from: e */
        public int f1681e;

        /* renamed from: f */
        public int f1682f;

        /* renamed from: g */
        public int f1683g;

        /* renamed from: h */
        public int f1684h = 1;

        /* renamed from: i */
        public int f1685i = 1;

        /* renamed from: j */
        public boolean f1686j;

        public C0387d(C0383a aVar) {
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("LayoutState{mAvailable=");
            d.append(this.f1677a);
            d.append(", mFlexLinePosition=");
            d.append(this.f1679c);
            d.append(", mPosition=");
            d.append(this.f1680d);
            d.append(", mOffset=");
            d.append(this.f1681e);
            d.append(", mScrollingOffset=");
            d.append(this.f1682f);
            d.append(", mLastScrollDelta=");
            d.append(this.f1683g);
            d.append(", mItemDirection=");
            d.append(this.f1684h);
            d.append(", mLayoutDirection=");
            d.append(this.f1685i);
            d.append('}');
            return d.toString();
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$e */
    public static class C0388e implements Parcelable {
        public static final Parcelable.Creator<C0388e> CREATOR = new C0389a();

        /* renamed from: d */
        public int f1687d;

        /* renamed from: e */
        public int f1688e;

        /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$e$a */
        public class C0389a implements Parcelable.Creator<C0388e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0388e(parcel, (C0383a) null);
            }

            public Object[] newArray(int i) {
                return new C0388e[i];
            }
        }

        public C0388e() {
        }

        public C0388e(Parcel parcel, C0383a aVar) {
            this.f1687d = parcel.readInt();
            this.f1688e = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("SavedState{mAnchorPosition=");
            d.append(this.f1687d);
            d.append(", mAnchorOffset=");
            d.append(this.f1688e);
            d.append('}');
            return d.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f1687d);
            parcel.writeInt(this.f1688e);
        }

        public C0388e(C0388e eVar, C0383a aVar) {
            this.f1687d = eVar.f1687d;
            this.f1688e = eVar.f1688e;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0071  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public FlexboxLayoutManager(android.content.Context r4, android.util.AttributeSet r5, int r6, int r7) {
        /*
            r3 = this;
            r3.<init>()
            r0 = -1
            r3.f1653t = r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r3.f1656w = r1
            m10 r1 = new m10
            r1.<init>(r3)
            r3.f1657x = r1
            com.google.android.flexbox.FlexboxLayoutManager$b r1 = new com.google.android.flexbox.FlexboxLayoutManager$b
            r2 = 0
            r1.<init>(r2)
            r3.f1637B = r1
            r3.f1641F = r0
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r3.f1642G = r1
            r3.f1643H = r1
            r3.f1644I = r1
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r3.f1645J = r1
            r3.f1648M = r0
            m10$a r0 = new m10$a
            r0.<init>()
            r3.f1649N = r0
            androidx.recyclerview.widget.RecyclerView$m$d r5 = androidx.recyclerview.widget.RecyclerView.C0162m.m601T(r4, r5, r6, r7)
            int r6 = r5.f883a
            r7 = 1
            if (r6 == 0) goto L_0x004a
            if (r6 == r7) goto L_0x0042
            goto L_0x0056
        L_0x0042:
            boolean r5 = r5.f885c
            if (r5 == 0) goto L_0x0048
            r5 = 3
            goto L_0x0053
        L_0x0048:
            r5 = 2
            goto L_0x0053
        L_0x004a:
            boolean r5 = r5.f885c
            if (r5 == 0) goto L_0x0052
            r3.mo2011y1(r7)
            goto L_0x0056
        L_0x0052:
            r5 = 0
        L_0x0053:
            r3.mo2011y1(r5)
        L_0x0056:
            int r5 = r3.f1651r
            if (r5 == r7) goto L_0x006c
            if (r5 == 0) goto L_0x005d
            goto L_0x0063
        L_0x005d:
            r3.mo1117H0()
            r3.mo1987a1()
        L_0x0063:
            r3.f1651r = r7
            r3.f1638C = r2
            r3.f1639D = r2
            r3.mo1129N0()
        L_0x006c:
            int r5 = r3.f1652s
            r6 = 4
            if (r5 == r6) goto L_0x007c
            r3.mo1117H0()
            r3.mo1987a1()
            r3.f1652s = r6
            r3.mo1129N0()
        L_0x007c:
            r3.f1646K = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.<init>(android.content.Context, android.util.AttributeSet, int, int):void");
    }

    /* renamed from: W0 */
    private boolean m1391W0(View view, int i, int i2, RecyclerView.C0167n nVar) {
        return view.isLayoutRequested() || !this.f873i || !m1392b0(view.getWidth(), i, nVar.width) || !m1392b0(view.getHeight(), i2, nVar.height);
    }

    /* renamed from: b0 */
    public static boolean m1392b0(int i, int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (i3 > 0 && i != i3) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i;
        }
        return true;
    }

    /* renamed from: A1 */
    public final void mo1985A1(C0384b bVar, boolean z, boolean z2) {
        C0387d dVar;
        int g;
        int i;
        int i2;
        if (z2) {
            mo2010x1();
        } else {
            this.f1636A.f1678b = false;
        }
        if (mo2008v1() || !this.f1654u) {
            dVar = this.f1636A;
            g = this.f1638C.mo2976g();
            i = bVar.f1662c;
        } else {
            dVar = this.f1636A;
            g = bVar.f1662c;
            i = mo1132Q();
        }
        dVar.f1677a = g - i;
        C0387d dVar2 = this.f1636A;
        dVar2.f1680d = bVar.f1660a;
        dVar2.f1684h = 1;
        dVar2.f1685i = 1;
        dVar2.f1681e = bVar.f1662c;
        dVar2.f1682f = Integer.MIN_VALUE;
        dVar2.f1679c = bVar.f1661b;
        if (z && this.f1656w.size() > 1 && (i2 = bVar.f1661b) >= 0 && i2 < this.f1656w.size() - 1) {
            C0387d dVar3 = this.f1636A;
            dVar3.f1679c++;
            dVar3.f1680d += this.f1656w.get(bVar.f1661b).f3773d;
        }
    }

    /* renamed from: B1 */
    public final void mo1986B1(C0384b bVar, boolean z, boolean z2) {
        C0387d dVar;
        int i;
        int i2;
        if (z2) {
            mo2010x1();
        } else {
            this.f1636A.f1678b = false;
        }
        if (mo2008v1() || !this.f1654u) {
            dVar = this.f1636A;
            i = bVar.f1662c;
        } else {
            dVar = this.f1636A;
            i = this.f1647L.getWidth() - bVar.f1662c;
        }
        dVar.f1677a = i - this.f1638C.mo2980k();
        C0387d dVar2 = this.f1636A;
        dVar2.f1680d = bVar.f1660a;
        dVar2.f1684h = 1;
        dVar2.f1685i = -1;
        dVar2.f1681e = bVar.f1662c;
        dVar2.f1682f = Integer.MIN_VALUE;
        int i3 = bVar.f1661b;
        dVar2.f1679c = i3;
        if (z && i3 > 0 && this.f1656w.size() > (i2 = bVar.f1661b)) {
            C0387d dVar3 = this.f1636A;
            dVar3.f1679c--;
            dVar3.f1680d -= this.f1656w.get(i2).f3773d;
        }
    }

    /* renamed from: C0 */
    public void mo887C0(Parcelable parcelable) {
        if (parcelable instanceof C0388e) {
            this.f1640E = (C0388e) parcelable;
            mo1129N0();
        }
    }

    /* renamed from: D0 */
    public Parcelable mo889D0() {
        C0388e eVar = this.f1640E;
        if (eVar != null) {
            return new C0388e(eVar, (C0383a) null);
        }
        C0388e eVar2 = new C0388e();
        if (mo1166z() > 0) {
            View y = mo1165y(0);
            eVar2.f1687d = mo1135S(y);
            eVar2.f1688e = this.f1638C.mo2974e(y) - this.f1638C.mo2980k();
        } else {
            eVar2.f1687d = -1;
        }
        return eVar2;
    }

    /* renamed from: O0 */
    public int mo858O0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (!mo2008v1() || this.f1651r == 0) {
            int t1 = mo2006t1(i, sVar, wVar);
            this.f1645J.clear();
            return t1;
        }
        int u1 = mo2007u1(i);
        this.f1637B.f1663d += u1;
        this.f1639D.mo2984p(-u1);
        return u1;
    }

    /* renamed from: P0 */
    public void mo892P0(int i) {
        this.f1641F = i;
        this.f1642G = Integer.MIN_VALUE;
        C0388e eVar = this.f1640E;
        if (eVar != null) {
            eVar.f1687d = -1;
        }
        mo1129N0();
    }

    /* renamed from: Q0 */
    public int mo860Q0(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar) {
        if (mo2008v1() || (this.f1651r == 0 && !mo2008v1())) {
            int t1 = mo2006t1(i, sVar, wVar);
            this.f1645J.clear();
            return t1;
        }
        int u1 = mo2007u1(i);
        this.f1637B.f1663d += u1;
        this.f1639D.mo2984p(-u1);
        return u1;
    }

    /* renamed from: Z */
    public boolean mo894Z() {
        return true;
    }

    /* renamed from: a1 */
    public final void mo1987a1() {
        this.f1656w.clear();
        C0384b.m1449b(this.f1637B);
        this.f1637B.f1663d = 0;
    }

    /* renamed from: b1 */
    public final int mo1988b1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        int b = wVar.mo1202b();
        mo1991e1();
        View g1 = mo1993g1(b);
        View i1 = mo1995i1(b);
        if (wVar.mo1202b() == 0 || g1 == null || i1 == null) {
            return 0;
        }
        return Math.min(this.f1638C.mo2981l(), this.f1638C.mo2971b(i1) - this.f1638C.mo2974e(g1));
    }

    /* renamed from: c1 */
    public final int mo1989c1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        int b = wVar.mo1202b();
        View g1 = mo1993g1(b);
        View i1 = mo1995i1(b);
        if (!(wVar.mo1202b() == 0 || g1 == null || i1 == null)) {
            int S = mo1135S(g1);
            int S2 = mo1135S(i1);
            int abs = Math.abs(this.f1638C.mo2971b(i1) - this.f1638C.mo2974e(g1));
            int[] iArr = this.f1657x.f3973c;
            int i = iArr[S];
            if (!(i == 0 || i == -1)) {
                return Math.round((((float) i) * (((float) abs) / ((float) ((iArr[S2] - i) + 1)))) + ((float) (this.f1638C.mo2980k() - this.f1638C.mo2974e(g1))));
            }
        }
        return 0;
    }

    /* renamed from: d1 */
    public final int mo1990d1(RecyclerView.C0178w wVar) {
        if (mo1166z() == 0) {
            return 0;
        }
        int b = wVar.mo1202b();
        View g1 = mo1993g1(b);
        View i1 = mo1995i1(b);
        if (wVar.mo1202b() == 0 || g1 == null || i1 == null) {
            return 0;
        }
        View l1 = mo1998l1(0, mo1166z(), false);
        return (int) ((((float) Math.abs(this.f1638C.mo2971b(i1) - this.f1638C.mo2974e(g1))) / ((float) ((mo1997k1() - (l1 == null ? -1 : mo1135S(l1))) + 1))) * ((float) wVar.mo1202b()));
    }

    /* renamed from: e */
    public boolean mo899e() {
        if (this.f1651r == 0) {
            return mo2008v1();
        }
        if (mo2008v1()) {
            int i = this.f879o;
            View view = this.f1647L;
            if (i > (view != null ? view.getWidth() : 0)) {
                return true;
            }
            return false;
        }
        return true;
    }

    /* renamed from: e1 */
    public final void mo1991e1() {
        C0682fb fbVar;
        if (this.f1638C == null) {
            if (mo2008v1()) {
                if (this.f1651r == 0) {
                    this.f1638C = new C0544db(this);
                    fbVar = new C0616eb(this);
                } else {
                    this.f1638C = new C0616eb(this);
                    fbVar = new C0544db(this);
                }
            } else if (this.f1651r == 0) {
                this.f1638C = new C0616eb(this);
                fbVar = new C0544db(this);
            } else {
                this.f1638C = new C0544db(this);
                fbVar = new C0616eb(this);
            }
            this.f1639D = fbVar;
        }
    }

    /* renamed from: f */
    public boolean mo901f() {
        if (this.f1651r == 0) {
            return !mo2008v1();
        }
        if (mo2008v1()) {
            return true;
        }
        int i = this.f880p;
        View view = this.f1647L;
        if (i > (view != null ? view.getHeight() : 0)) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0033, code lost:
        r10 = r2.f1679c;
     */
    /* renamed from: f1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int mo1992f1(androidx.recyclerview.widget.RecyclerView.C0173s r34, androidx.recyclerview.widget.RecyclerView.C0178w r35, com.google.android.flexbox.FlexboxLayoutManager.C0387d r36) {
        /*
            r33 = this;
            r0 = r33
            r1 = r34
            r2 = r36
            int r3 = r2.f1682f
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r4) goto L_0x0016
            int r5 = r2.f1677a
            if (r5 >= 0) goto L_0x0013
            int r3 = r3 + r5
            r2.f1682f = r3
        L_0x0013:
            r0.mo2009w1(r1, r2)
        L_0x0016:
            int r3 = r2.f1677a
            boolean r5 = r33.mo2008v1()
            r7 = r3
            r8 = 0
        L_0x001e:
            if (r7 > 0) goto L_0x0026
            com.google.android.flexbox.FlexboxLayoutManager$d r9 = r0.f1636A
            boolean r9 = r9.f1678b
            if (r9 == 0) goto L_0x0318
        L_0x0026:
            java.util.List<l10> r9 = r0.f1656w
            int r10 = r2.f1680d
            r11 = 1
            if (r10 < 0) goto L_0x003f
            int r12 = r35.mo1202b()
            if (r10 >= r12) goto L_0x003f
            int r10 = r2.f1679c
            if (r10 < 0) goto L_0x003f
            int r9 = r9.size()
            if (r10 >= r9) goto L_0x003f
            r9 = 1
            goto L_0x0040
        L_0x003f:
            r9 = 0
        L_0x0040:
            if (r9 == 0) goto L_0x0318
            java.util.List<l10> r9 = r0.f1656w
            int r10 = r2.f1679c
            java.lang.Object r9 = r9.get(r10)
            l10 r9 = (p000.l10) r9
            int r10 = r9.f3780k
            r2.f1680d = r10
            boolean r10 = r33.mo2008v1()
            r12 = 0
            r15 = -1
            if (r10 == 0) goto L_0x0181
            int r10 = r33.mo1131P()
            int r13 = r33.mo1132Q()
            int r14 = r0.f879o
            int r4 = r2.f1681e
            int r6 = r2.f1685i
            if (r6 != r15) goto L_0x006b
            int r6 = r9.f3772c
            int r4 = r4 - r6
        L_0x006b:
            int r6 = r2.f1680d
            float r10 = (float) r10
            int r14 = r14 - r13
            float r13 = (float) r14
            com.google.android.flexbox.FlexboxLayoutManager$b r14 = r0.f1637B
            int r14 = r14.f1663d
            float r14 = (float) r14
            float r10 = r10 - r14
            float r13 = r13 - r14
            float r19 = java.lang.Math.max(r12, r12)
            int r14 = r9.f3773d
            r12 = r6
            r21 = 0
        L_0x0080:
            int r15 = r6 + r14
            if (r12 >= r15) goto L_0x016e
            android.view.View r15 = r0.mo2003q1(r12)
            if (r15 != 0) goto L_0x0099
            r29 = r4
            r22 = r6
            r24 = r7
            r25 = r8
            r26 = r12
            r27 = r14
            r4 = -1
            goto L_0x015f
        L_0x0099:
            r22 = r6
            int r6 = r2.f1685i
            if (r6 != r11) goto L_0x00aa
            android.graphics.Rect r6 = f1635O
            r0.mo1149d(r15, r6)
            r6 = -1
            r11 = 0
            r0.mo1147b(r15, r6, r11)
            goto L_0x00b7
        L_0x00aa:
            r11 = 0
            android.graphics.Rect r6 = f1635O
            r0.mo1149d(r15, r6)
            r6 = r21
            r0.mo1147b(r15, r6, r11)
            int r21 = r6 + 1
        L_0x00b7:
            m10 r6 = r0.f1657x
            long[] r11 = r6.f3974d
            r24 = r7
            r25 = r8
            r7 = r11[r12]
            int r11 = (int) r7
            int r6 = r6.mo4541j(r7)
            android.view.ViewGroup$LayoutParams r7 = r15.getLayoutParams()
            com.google.android.flexbox.FlexboxLayoutManager$c r7 = (com.google.android.flexbox.FlexboxLayoutManager.C0385c) r7
            boolean r8 = r0.m1391W0(r15, r11, r6, r7)
            if (r8 == 0) goto L_0x00d5
            r15.measure(r11, r6)
        L_0x00d5:
            int r6 = r7.leftMargin
            int r8 = r0.mo1124L(r15)
            int r8 = r8 + r6
            float r6 = (float) r8
            float r10 = r10 + r6
            int r6 = r7.rightMargin
            int r8 = r0.mo1137U(r15)
            int r8 = r8 + r6
            float r6 = (float) r8
            float r6 = r13 - r6
            int r8 = r0.mo1142X(r15)
            int r8 = r8 + r4
            boolean r11 = r0.f1654u
            if (r11 == 0) goto L_0x010c
            m10 r11 = r0.f1657x
            int r13 = java.lang.Math.round(r6)
            int r17 = r15.getMeasuredWidth()
            int r13 = r13 - r17
            int r17 = java.lang.Math.round(r6)
            int r18 = r15.getMeasuredHeight()
            int r18 = r18 + r8
            r26 = r12
            r12 = r11
            r11 = r13
            goto L_0x012c
        L_0x010c:
            m10 r11 = r0.f1657x
            int r13 = java.lang.Math.round(r10)
            int r17 = java.lang.Math.round(r10)
            int r18 = r15.getMeasuredWidth()
            int r18 = r18 + r17
            int r17 = r15.getMeasuredHeight()
            int r17 = r17 + r8
            r26 = r12
            r12 = r11
            r11 = r13
            r32 = r18
            r18 = r17
            r17 = r32
        L_0x012c:
            r13 = r15
            r27 = r14
            r14 = r9
            r29 = r4
            r28 = r15
            r4 = -1
            r15 = r11
            r16 = r8
            r12.mo4549r(r13, r14, r15, r16, r17, r18)
            int r8 = r28.getMeasuredWidth()
            int r11 = r7.rightMargin
            int r8 = r8 + r11
            r11 = r28
            int r12 = r0.mo1137U(r11)
            int r12 = r12 + r8
            float r8 = (float) r12
            float r8 = r8 + r19
            float r8 = r8 + r10
            int r10 = r11.getMeasuredWidth()
            int r7 = r7.leftMargin
            int r10 = r10 + r7
            int r7 = r0.mo1124L(r11)
            int r7 = r7 + r10
            float r7 = (float) r7
            float r7 = r7 + r19
            float r6 = r6 - r7
            r13 = r6
            r10 = r8
        L_0x015f:
            int r12 = r26 + 1
            r6 = r22
            r7 = r24
            r8 = r25
            r14 = r27
            r4 = r29
            r11 = 1
            goto L_0x0080
        L_0x016e:
            r24 = r7
            r25 = r8
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1685i
            int r6 = r2.f1679c
            int r6 = r6 + r4
            r2.f1679c = r6
            int r4 = r9.f3772c
            r30 = 0
            goto L_0x02f1
        L_0x0181:
            r24 = r7
            r25 = r8
            r4 = -1
            int r6 = r33.mo1133R()
            int r7 = r33.mo1130O()
            int r8 = r0.f880p
            int r10 = r2.f1681e
            int r11 = r2.f1685i
            if (r11 != r4) goto L_0x019e
            int r11 = r9.f3772c
            int r13 = r10 - r11
            int r10 = r10 + r11
            r11 = r10
            r10 = r13
            goto L_0x019f
        L_0x019e:
            r11 = r10
        L_0x019f:
            int r15 = r2.f1680d
            float r6 = (float) r6
            int r8 = r8 - r7
            float r7 = (float) r8
            com.google.android.flexbox.FlexboxLayoutManager$b r8 = r0.f1637B
            int r8 = r8.f1663d
            float r8 = (float) r8
            float r6 = r6 - r8
            float r7 = r7 - r8
            float r8 = java.lang.Math.max(r12, r12)
            int r14 = r9.f3773d
            r13 = r15
            r12 = 0
        L_0x01b3:
            int r4 = r15 + r14
            if (r13 >= r4) goto L_0x02e2
            android.view.View r4 = r0.mo2003q1(r13)
            if (r4 != 0) goto L_0x01cd
            r26 = r8
            r22 = r9
            r29 = r13
            r20 = r14
            r23 = r15
            r30 = 0
            r31 = 1
            goto L_0x02d6
        L_0x01cd:
            r16 = r14
            m10 r14 = r0.f1657x
            r17 = r15
            long[] r15 = r14.f3974d
            r26 = r8
            r22 = r9
            r8 = r15[r13]
            int r15 = (int) r8
            int r8 = r14.mo4541j(r8)
            android.view.ViewGroup$LayoutParams r9 = r4.getLayoutParams()
            com.google.android.flexbox.FlexboxLayoutManager$c r9 = (com.google.android.flexbox.FlexboxLayoutManager.C0385c) r9
            boolean r14 = r0.m1391W0(r4, r15, r8, r9)
            if (r14 == 0) goto L_0x01ef
            r4.measure(r15, r8)
        L_0x01ef:
            int r8 = r9.topMargin
            int r14 = r0.mo1142X(r4)
            int r14 = r14 + r8
            float r8 = (float) r14
            float r6 = r6 + r8
            int r8 = r9.rightMargin
            int r14 = r0.mo1164x(r4)
            int r14 = r14 + r8
            float r8 = (float) r14
            float r7 = r7 - r8
            int r8 = r2.f1685i
            r15 = 1
            if (r8 != r15) goto L_0x0211
            android.graphics.Rect r8 = f1635O
            r0.mo1149d(r4, r8)
            r8 = -1
            r14 = 0
            r0.mo1147b(r4, r8, r14)
            goto L_0x021c
        L_0x0211:
            r14 = 0
            android.graphics.Rect r8 = f1635O
            r0.mo1149d(r4, r8)
            r0.mo1147b(r4, r12, r14)
            int r12 = r12 + 1
        L_0x021c:
            r8 = r12
            int r12 = r0.mo1124L(r4)
            int r12 = r12 + r10
            int r18 = r0.mo1137U(r4)
            int r18 = r11 - r18
            boolean r15 = r0.f1654u
            if (r15 == 0) goto L_0x0264
            boolean r12 = r0.f1655v
            if (r12 == 0) goto L_0x0247
            m10 r12 = r0.f1657x
            int r19 = r4.getMeasuredWidth()
            int r19 = r18 - r19
            int r20 = java.lang.Math.round(r7)
            int r27 = r4.getMeasuredHeight()
            int r20 = r20 - r27
            int r27 = java.lang.Math.round(r7)
            goto L_0x025d
        L_0x0247:
            m10 r12 = r0.f1657x
            int r19 = r4.getMeasuredWidth()
            int r19 = r18 - r19
            int r20 = java.lang.Math.round(r6)
            int r27 = java.lang.Math.round(r6)
            int r28 = r4.getMeasuredHeight()
            int r27 = r28 + r27
        L_0x025d:
            r28 = r27
            r27 = r18
            r18 = r20
            goto L_0x029c
        L_0x0264:
            boolean r14 = r0.f1655v
            if (r14 == 0) goto L_0x027f
            m10 r14 = r0.f1657x
            int r18 = java.lang.Math.round(r7)
            int r19 = r4.getMeasuredHeight()
            int r18 = r18 - r19
            int r19 = r4.getMeasuredWidth()
            int r19 = r19 + r12
            int r27 = java.lang.Math.round(r7)
            goto L_0x0295
        L_0x027f:
            m10 r14 = r0.f1657x
            int r18 = java.lang.Math.round(r6)
            int r19 = r4.getMeasuredWidth()
            int r19 = r19 + r12
            int r27 = java.lang.Math.round(r6)
            int r28 = r4.getMeasuredHeight()
            int r27 = r28 + r27
        L_0x0295:
            r28 = r27
            r27 = r19
            r19 = r12
            r12 = r14
        L_0x029c:
            r29 = r13
            r13 = r4
            r20 = r16
            r30 = 0
            r14 = r22
            r23 = r17
            r31 = 1
            r16 = r19
            r17 = r18
            r18 = r27
            r19 = r28
            r12.mo4550s(r13, r14, r15, r16, r17, r18, r19)
            int r12 = r4.getMeasuredHeight()
            int r13 = r9.topMargin
            int r12 = r12 + r13
            int r13 = r0.mo1164x(r4)
            int r13 = r13 + r12
            float r12 = (float) r13
            float r12 = r12 + r26
            float r12 = r12 + r6
            int r6 = r4.getMeasuredHeight()
            int r9 = r9.bottomMargin
            int r6 = r6 + r9
            int r4 = r0.mo1142X(r4)
            int r4 = r4 + r6
            float r4 = (float) r4
            float r4 = r4 + r26
            float r7 = r7 - r4
            r6 = r12
            r12 = r8
        L_0x02d6:
            int r13 = r29 + 1
            r14 = r20
            r9 = r22
            r15 = r23
            r8 = r26
            goto L_0x01b3
        L_0x02e2:
            r22 = r9
            r30 = 0
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1685i
            int r6 = r2.f1679c
            int r6 = r6 + r4
            r2.f1679c = r6
            int r4 = r9.f3772c
        L_0x02f1:
            int r8 = r25 + r4
            if (r5 != 0) goto L_0x0305
            boolean r4 = r0.f1654u
            if (r4 == 0) goto L_0x0305
            int r4 = r9.f3772c
            int r6 = r2.f1685i
            int r4 = r4 * r6
            int r6 = r2.f1681e
            int r6 = r6 - r4
            r2.f1681e = r6
            goto L_0x0310
        L_0x0305:
            int r4 = r9.f3772c
            int r6 = r2.f1685i
            int r4 = r4 * r6
            int r6 = r2.f1681e
            int r6 = r6 + r4
            r2.f1681e = r6
        L_0x0310:
            int r4 = r9.f3772c
            int r7 = r24 - r4
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x001e
        L_0x0318:
            r25 = r8
            int r4 = r2.f1677a
            int r4 = r4 - r25
            r2.f1677a = r4
            int r5 = r2.f1682f
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r5 == r6) goto L_0x0332
            int r5 = r5 + r25
            r2.f1682f = r5
            if (r4 >= 0) goto L_0x032f
            int r5 = r5 + r4
            r2.f1682f = r5
        L_0x032f:
            r0.mo2009w1(r1, r2)
        L_0x0332:
            int r1 = r2.f1677a
            int r3 = r3 - r1
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo1992f1(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w, com.google.android.flexbox.FlexboxLayoutManager$d):int");
    }

    /* renamed from: g */
    public boolean mo865g(RecyclerView.C0167n nVar) {
        return nVar instanceof C0385c;
    }

    /* renamed from: g0 */
    public void mo1153g0(RecyclerView.C0150e eVar, RecyclerView.C0150e eVar2) {
        mo1117H0();
    }

    /* renamed from: g1 */
    public final View mo1993g1(int i) {
        int i2;
        View m1 = mo1999m1(0, mo1166z(), i);
        if (m1 == null || (i2 = this.f1657x.f3973c[mo1135S(m1)]) == -1) {
            return null;
        }
        return mo1994h1(m1, this.f1656w.get(i2));
    }

    /* renamed from: h1 */
    public final View mo1994h1(View view, l10 l10) {
        boolean v1 = mo2008v1();
        int i = l10.f3773d;
        for (int i2 = 1; i2 < i; i2++) {
            View y = mo1165y(i2);
            if (!(y == null || y.getVisibility() == 8)) {
                if (!this.f1654u || v1) {
                    if (this.f1638C.mo2974e(view) <= this.f1638C.mo2974e(y)) {
                    }
                } else if (this.f1638C.mo2971b(view) >= this.f1638C.mo2971b(y)) {
                }
                view = y;
            }
        }
        return view;
    }

    /* renamed from: i0 */
    public void mo1155i0(RecyclerView recyclerView) {
        this.f1647L = (View) recyclerView.getParent();
    }

    /* renamed from: i1 */
    public final View mo1995i1(int i) {
        View m1 = mo1999m1(mo1166z() - 1, -1, i);
        if (m1 == null) {
            return null;
        }
        return mo1996j1(m1, this.f1656w.get(this.f1657x.f3973c[mo1135S(m1)]));
    }

    /* renamed from: j1 */
    public final View mo1996j1(View view, l10 l10) {
        boolean v1 = mo2008v1();
        int z = (mo1166z() - l10.f3773d) - 1;
        for (int z2 = mo1166z() - 2; z2 > z; z2--) {
            View y = mo1165y(z2);
            if (!(y == null || y.getVisibility() == 8)) {
                if (!this.f1654u || v1) {
                    if (this.f1638C.mo2971b(view) >= this.f1638C.mo2971b(y)) {
                    }
                } else if (this.f1638C.mo2974e(view) <= this.f1638C.mo2974e(y)) {
                }
                view = y;
            }
        }
        return view;
    }

    /* renamed from: k */
    public int mo909k(RecyclerView.C0178w wVar) {
        return mo1988b1(wVar);
    }

    /* renamed from: k0 */
    public void mo910k0(RecyclerView recyclerView, RecyclerView.C0173s sVar) {
        mo1156j0();
    }

    /* renamed from: k1 */
    public int mo1997k1() {
        View l1 = mo1998l1(mo1166z() - 1, -1, false);
        if (l1 == null) {
            return -1;
        }
        return mo1135S(l1);
    }

    /* renamed from: l */
    public int mo866l(RecyclerView.C0178w wVar) {
        return mo1989c1(wVar);
    }

    /* renamed from: l1 */
    public final View mo1998l1(int i, int i2, boolean z) {
        int i3 = i2;
        int i4 = i;
        int i5 = i3 > i4 ? 1 : -1;
        while (i4 != i3) {
            View y = mo1165y(i4);
            int P = mo1131P();
            int R = mo1133R();
            int Q = this.f879o - mo1132Q();
            int O = this.f880p - mo1130O();
            int E = mo1110E(y) - ((RecyclerView.C0167n) y.getLayoutParams()).leftMargin;
            int I = mo1118I(y) - ((RecyclerView.C0167n) y.getLayoutParams()).topMargin;
            int H = mo1116H(y) + ((RecyclerView.C0167n) y.getLayoutParams()).rightMargin;
            int C = mo1108C(y) + ((RecyclerView.C0167n) y.getLayoutParams()).bottomMargin;
            boolean z2 = false;
            boolean z3 = P <= E && Q >= H;
            boolean z4 = E >= Q || H >= P;
            boolean z5 = R <= I && O >= C;
            boolean z6 = I >= O || C >= R;
            if (!z ? !(!z4 || !z6) : !(!z3 || !z5)) {
                z2 = true;
            }
            if (z2) {
                return y;
            }
            i4 += i5;
        }
        return null;
    }

    /* renamed from: m */
    public int mo868m(RecyclerView.C0178w wVar) {
        return mo1990d1(wVar);
    }

    /* renamed from: m1 */
    public final View mo1999m1(int i, int i2, int i3) {
        int S;
        mo1991e1();
        View view = null;
        if (this.f1636A == null) {
            this.f1636A = new C0387d((C0383a) null);
        }
        int k = this.f1638C.mo2980k();
        int g = this.f1638C.mo2976g();
        int i4 = i2 > i ? 1 : -1;
        View view2 = null;
        while (i != i2) {
            View y = mo1165y(i);
            if (y != null && (S = mo1135S(y)) >= 0 && S < i3) {
                if (((RecyclerView.C0167n) y.getLayoutParams()).mo1175t()) {
                    if (view2 == null) {
                        view2 = y;
                    }
                } else if (this.f1638C.mo2974e(y) >= k && this.f1638C.mo2971b(y) <= g) {
                    return y;
                } else {
                    if (view == null) {
                        view = y;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: n */
    public int mo915n(RecyclerView.C0178w wVar) {
        return mo1988b1(wVar);
    }

    /* renamed from: n1 */
    public final int mo2000n1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int i2;
        int g;
        if (!mo2008v1() && this.f1654u) {
            int k = i - this.f1638C.mo2980k();
            if (k <= 0) {
                return 0;
            }
            i2 = mo2006t1(k, sVar, wVar);
        } else {
            int g2 = this.f1638C.mo2976g() - i;
            if (g2 <= 0) {
                return 0;
            }
            i2 = -mo2006t1(-g2, sVar, wVar);
        }
        int i3 = i + i2;
        if (!z || (g = this.f1638C.mo2976g() - i3) <= 0) {
            return i2;
        }
        this.f1638C.mo2984p(g);
        return g + i2;
    }

    /* renamed from: o */
    public int mo870o(RecyclerView.C0178w wVar) {
        return mo1989c1(wVar);
    }

    /* renamed from: o1 */
    public final int mo2001o1(int i, RecyclerView.C0173s sVar, RecyclerView.C0178w wVar, boolean z) {
        int i2;
        int k;
        if (mo2008v1() || !this.f1654u) {
            int k2 = i - this.f1638C.mo2980k();
            if (k2 <= 0) {
                return 0;
            }
            i2 = -mo2006t1(k2, sVar, wVar);
        } else {
            int g = this.f1638C.mo2976g() - i;
            if (g <= 0) {
                return 0;
            }
            i2 = mo2006t1(-g, sVar, wVar);
        }
        int i3 = i + i2;
        if (!z || (k = i3 - this.f1638C.mo2980k()) <= 0) {
            return i2;
        }
        this.f1638C.mo2984p(-k);
        return i2 - k;
    }

    /* renamed from: p */
    public int mo871p(RecyclerView.C0178w wVar) {
        return mo1990d1(wVar);
    }

    /* renamed from: p1 */
    public int mo2002p1(View view) {
        int i;
        int i2;
        if (mo2008v1()) {
            i2 = mo1142X(view);
            i = mo1164x(view);
        } else {
            i2 = mo1124L(view);
            i = mo1137U(view);
        }
        return i + i2;
    }

    /* renamed from: q1 */
    public View mo2003q1(int i) {
        View view = this.f1645J.get(i);
        return view != null ? view : this.f1658y.mo1193l(i, false, Long.MAX_VALUE).f928a;
    }

    /* renamed from: r0 */
    public void mo873r0(RecyclerView recyclerView, int i, int i2) {
        mo2012z1(i);
    }

    /* renamed from: r1 */
    public int mo2004r1() {
        return this.f1659z.mo1202b();
    }

    /* renamed from: s1 */
    public int mo2005s1() {
        if (this.f1656w.size() == 0) {
            return 0;
        }
        int i = Integer.MIN_VALUE;
        int size = this.f1656w.size();
        for (int i2 = 0; i2 < size; i2++) {
            i = Math.max(i, this.f1656w.get(i2).f3770a);
        }
        return i;
    }

    /* renamed from: t0 */
    public void mo875t0(RecyclerView recyclerView, int i, int i2, int i3) {
        mo2012z1(Math.min(i, i2));
    }

    /* JADX WARNING: Removed duplicated region for block: B:63:0x01d6 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x01d7  */
    /* renamed from: t1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int mo2006t1(int r19, androidx.recyclerview.widget.RecyclerView.C0173s r20, androidx.recyclerview.widget.RecyclerView.C0178w r21) {
        /*
            r18 = this;
            r0 = r18
            int r1 = r18.mo1166z()
            r2 = 0
            if (r1 == 0) goto L_0x01f1
            if (r19 != 0) goto L_0x000d
            goto L_0x01f1
        L_0x000d:
            r18.mo1991e1()
            com.google.android.flexbox.FlexboxLayoutManager$d r1 = r0.f1636A
            r3 = 1
            r1.f1686j = r3
            boolean r1 = r18.mo2008v1()
            if (r1 != 0) goto L_0x0021
            boolean r1 = r0.f1654u
            if (r1 == 0) goto L_0x0021
            r1 = 1
            goto L_0x0022
        L_0x0021:
            r1 = 0
        L_0x0022:
            r4 = -1
            if (r1 == 0) goto L_0x0028
            if (r19 >= 0) goto L_0x002c
            goto L_0x002a
        L_0x0028:
            if (r19 <= 0) goto L_0x002c
        L_0x002a:
            r5 = 1
            goto L_0x002d
        L_0x002c:
            r5 = -1
        L_0x002d:
            int r6 = java.lang.Math.abs(r19)
            com.google.android.flexbox.FlexboxLayoutManager$d r7 = r0.f1636A
            r7.f1685i = r5
            boolean r7 = r18.mo2008v1()
            int r8 = r0.f879o
            int r9 = r0.f877m
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r9)
            int r9 = r0.f880p
            int r10 = r0.f878n
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r10)
            if (r7 != 0) goto L_0x0051
            boolean r10 = r0.f1654u
            if (r10 == 0) goto L_0x0051
            r10 = 1
            goto L_0x0052
        L_0x0051:
            r10 = 0
        L_0x0052:
            if (r5 != r3) goto L_0x012d
            int r11 = r18.mo1166z()
            int r11 = r11 - r3
            android.view.View r11 = r0.mo1165y(r11)
            if (r11 != 0) goto L_0x0061
            goto L_0x01c7
        L_0x0061:
            com.google.android.flexbox.FlexboxLayoutManager$d r12 = r0.f1636A
            fb r13 = r0.f1638C
            int r13 = r13.mo2971b(r11)
            r12.f1681e = r13
            int r12 = r0.mo1135S(r11)
            m10 r13 = r0.f1657x
            int[] r13 = r13.f3973c
            r13 = r13[r12]
            java.util.List<l10> r14 = r0.f1656w
            java.lang.Object r13 = r14.get(r13)
            l10 r13 = (p000.l10) r13
            android.view.View r11 = r0.mo1996j1(r11, r13)
            com.google.android.flexbox.FlexboxLayoutManager$d r13 = r0.f1636A
            r13.f1684h = r3
            int r12 = r12 + r3
            r13.f1680d = r12
            m10 r14 = r0.f1657x
            int[] r14 = r14.f3973c
            int r15 = r14.length
            if (r15 > r12) goto L_0x0092
            r13.f1679c = r4
            goto L_0x0096
        L_0x0092:
            r12 = r14[r12]
            r13.f1679c = r12
        L_0x0096:
            if (r10 == 0) goto L_0x00bb
            fb r10 = r0.f1638C
            int r10 = r10.mo2974e(r11)
            r13.f1681e = r10
            com.google.android.flexbox.FlexboxLayoutManager$d r10 = r0.f1636A
            fb r12 = r0.f1638C
            int r11 = r12.mo2974e(r11)
            int r11 = -r11
            fb r12 = r0.f1638C
            int r12 = r12.mo2980k()
            int r12 = r12 + r11
            r10.f1682f = r12
            com.google.android.flexbox.FlexboxLayoutManager$d r10 = r0.f1636A
            int r11 = r10.f1682f
            int r11 = java.lang.Math.max(r11, r2)
            goto L_0x00d2
        L_0x00bb:
            fb r10 = r0.f1638C
            int r10 = r10.mo2971b(r11)
            r13.f1681e = r10
            com.google.android.flexbox.FlexboxLayoutManager$d r10 = r0.f1636A
            fb r12 = r0.f1638C
            int r11 = r12.mo2971b(r11)
            fb r12 = r0.f1638C
            int r12 = r12.mo2976g()
            int r11 = r11 - r12
        L_0x00d2:
            r10.f1682f = r11
            com.google.android.flexbox.FlexboxLayoutManager$d r10 = r0.f1636A
            int r10 = r10.f1679c
            if (r10 == r4) goto L_0x00e3
            java.util.List<l10> r4 = r0.f1656w
            int r4 = r4.size()
            int r4 = r4 - r3
            if (r10 <= r4) goto L_0x01bf
        L_0x00e3:
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r3 = r3.f1680d
            int r4 = r18.mo2004r1()
            if (r3 > r4) goto L_0x01bf
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r4 = r3.f1682f
            int r14 = r6 - r4
            m10$a r11 = r0.f1649N
            r4 = 0
            r11.f3976a = r4
            if (r14 <= 0) goto L_0x01bf
            m10 r10 = r0.f1657x
            if (r7 == 0) goto L_0x010c
            int r15 = r3.f1680d
            java.util.List<l10> r3 = r0.f1656w
            r16 = -1
            r12 = r8
            r13 = r9
            r17 = r3
            r10.mo4533b(r11, r12, r13, r14, r15, r16, r17)
            goto L_0x0119
        L_0x010c:
            int r15 = r3.f1680d
            java.util.List<l10> r3 = r0.f1656w
            r16 = -1
            r12 = r9
            r13 = r8
            r17 = r3
            r10.mo4533b(r11, r12, r13, r14, r15, r16, r17)
        L_0x0119:
            m10 r3 = r0.f1657x
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1680d
            r3.mo4536e(r8, r9, r4)
            m10 r3 = r0.f1657x
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1680d
            r3.mo4554w(r4)
            goto L_0x01bf
        L_0x012d:
            android.view.View r7 = r0.mo1165y(r2)
            if (r7 != 0) goto L_0x0135
            goto L_0x01c7
        L_0x0135:
            com.google.android.flexbox.FlexboxLayoutManager$d r8 = r0.f1636A
            fb r9 = r0.f1638C
            int r9 = r9.mo2974e(r7)
            r8.f1681e = r9
            int r8 = r0.mo1135S(r7)
            m10 r9 = r0.f1657x
            int[] r9 = r9.f3973c
            r9 = r9[r8]
            java.util.List<l10> r11 = r0.f1656w
            java.lang.Object r9 = r11.get(r9)
            l10 r9 = (p000.l10) r9
            android.view.View r7 = r0.mo1994h1(r7, r9)
            com.google.android.flexbox.FlexboxLayoutManager$d r9 = r0.f1636A
            r9.f1684h = r3
            m10 r11 = r0.f1657x
            int[] r11 = r11.f3973c
            r11 = r11[r8]
            if (r11 != r4) goto L_0x0162
            r11 = 0
        L_0x0162:
            if (r11 <= 0) goto L_0x0176
            java.util.List<l10> r4 = r0.f1656w
            int r9 = r11 + -1
            java.lang.Object r4 = r4.get(r9)
            l10 r4 = (p000.l10) r4
            com.google.android.flexbox.FlexboxLayoutManager$d r9 = r0.f1636A
            int r4 = r4.f3773d
            int r8 = r8 - r4
            r9.f1680d = r8
            goto L_0x0178
        L_0x0176:
            r9.f1680d = r4
        L_0x0178:
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            if (r11 <= 0) goto L_0x017e
            int r11 = r11 - r3
            goto L_0x017f
        L_0x017e:
            r11 = 0
        L_0x017f:
            r4.f1679c = r11
            fb r3 = r0.f1638C
            if (r10 == 0) goto L_0x01a7
            int r3 = r3.mo2971b(r7)
            r4.f1681e = r3
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            fb r4 = r0.f1638C
            int r4 = r4.mo2971b(r7)
            fb r7 = r0.f1638C
            int r7 = r7.mo2976g()
            int r4 = r4 - r7
            r3.f1682f = r4
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r4 = r3.f1682f
            int r4 = java.lang.Math.max(r4, r2)
            r3.f1682f = r4
            goto L_0x01bf
        L_0x01a7:
            int r3 = r3.mo2974e(r7)
            r4.f1681e = r3
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            fb r4 = r0.f1638C
            int r4 = r4.mo2974e(r7)
            int r4 = -r4
            fb r7 = r0.f1638C
            int r7 = r7.mo2980k()
            int r7 = r7 + r4
            r3.f1682f = r7
        L_0x01bf:
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r4 = r3.f1682f
            int r4 = r6 - r4
            r3.f1677a = r4
        L_0x01c7:
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r4 = r3.f1682f
            r7 = r20
            r8 = r21
            int r3 = r0.mo1992f1(r7, r8, r3)
            int r3 = r3 + r4
            if (r3 >= 0) goto L_0x01d7
            return r2
        L_0x01d7:
            if (r1 == 0) goto L_0x01df
            if (r6 <= r3) goto L_0x01e4
            int r1 = -r5
            int r1 = r1 * r3
            goto L_0x01e6
        L_0x01df:
            if (r6 <= r3) goto L_0x01e4
            int r1 = r5 * r3
            goto L_0x01e6
        L_0x01e4:
            r1 = r19
        L_0x01e6:
            fb r2 = r0.f1638C
            int r3 = -r1
            r2.mo2984p(r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r2 = r0.f1636A
            r2.f1683g = r1
            return r1
        L_0x01f1:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo2006t1(int, androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w):int");
    }

    /* renamed from: u */
    public RecyclerView.C0167n mo877u() {
        return new C0385c(-2, -2);
    }

    /* renamed from: u0 */
    public void mo878u0(RecyclerView recyclerView, int i, int i2) {
        mo2012z1(i);
    }

    /* renamed from: u1 */
    public final int mo2007u1(int i) {
        int i2;
        int i3;
        boolean z = false;
        if (mo1166z() == 0 || i == 0) {
            return 0;
        }
        mo1991e1();
        boolean v1 = mo2008v1();
        View view = this.f1647L;
        int width = v1 ? view.getWidth() : view.getHeight();
        if (v1) {
            i2 = this.f879o;
        } else {
            i2 = this.f880p;
        }
        if (mo1122K() == 1) {
            z = true;
        }
        if (z) {
            int abs = Math.abs(i);
            if (i < 0) {
                return -Math.min((i2 + this.f1637B.f1663d) - width, abs);
            }
            i3 = this.f1637B.f1663d;
            if (i3 + i <= 0) {
                return i;
            }
        } else if (i > 0) {
            return Math.min((i2 - this.f1637B.f1663d) - width, i);
        } else {
            i3 = this.f1637B.f1663d;
            if (i3 + i >= 0) {
                return i;
            }
        }
        return -i3;
    }

    /* renamed from: v */
    public RecyclerView.C0167n mo880v(Context context, AttributeSet attributeSet) {
        return new C0385c(context, attributeSet);
    }

    /* renamed from: v0 */
    public void mo1163v0(RecyclerView recyclerView, int i, int i2) {
        mo2012z1(i);
    }

    /* renamed from: v1 */
    public boolean mo2008v1() {
        int i = this.f1650q;
        return i == 0 || i == 1;
    }

    /* renamed from: w0 */
    public void mo882w0(RecyclerView recyclerView, int i, int i2, Object obj) {
        mo1163v0(recyclerView, i, i2);
        mo2012z1(i);
    }

    /* renamed from: w1 */
    public final void mo2009w1(RecyclerView.C0173s sVar, C0387d dVar) {
        int z;
        View y;
        int i;
        int z2;
        int i2;
        View y2;
        int i3;
        if (dVar.f1686j) {
            int i4 = -1;
            if (dVar.f1685i == -1) {
                if (dVar.f1682f >= 0 && (z2 = mo1166z()) != 0 && (y2 = mo1165y(i2)) != null && (i3 = this.f1657x.f3973c[mo1135S(y2)]) != -1) {
                    l10 l10 = this.f1656w.get(i3);
                    int i5 = z2 - 1;
                    while (true) {
                        if (i5 < 0) {
                            break;
                        }
                        View y3 = mo1165y(i5);
                        if (y3 != null) {
                            int i6 = dVar.f1682f;
                            if (!(mo2008v1() || !this.f1654u ? this.f1638C.mo2974e(y3) >= this.f1638C.mo2975f() - i6 : this.f1638C.mo2971b(y3) <= i6)) {
                                break;
                            } else if (l10.f3780k != mo1135S(y3)) {
                                continue;
                            } else if (i3 <= 0) {
                                z2 = i5;
                                break;
                            } else {
                                i3 += dVar.f1685i;
                                l10 = this.f1656w.get(i3);
                                z2 = i5;
                            }
                        }
                        i5--;
                    }
                    while (i2 >= z2) {
                        mo1125L0(i2, sVar);
                        i2--;
                    }
                }
            } else if (dVar.f1682f >= 0 && (z = mo1166z()) != 0 && (y = mo1165y(0)) != null && (i = this.f1657x.f3973c[mo1135S(y)]) != -1) {
                l10 l102 = this.f1656w.get(i);
                int i7 = 0;
                while (true) {
                    if (i7 >= z) {
                        break;
                    }
                    View y4 = mo1165y(i7);
                    if (y4 != null) {
                        int i8 = dVar.f1682f;
                        if (!(mo2008v1() || !this.f1654u ? this.f1638C.mo2971b(y4) <= i8 : this.f1638C.mo2975f() - this.f1638C.mo2974e(y4) <= i8)) {
                            break;
                        } else if (l102.f3781l != mo1135S(y4)) {
                            continue;
                        } else if (i >= this.f1656w.size() - 1) {
                            i4 = i7;
                            break;
                        } else {
                            i += dVar.f1685i;
                            l102 = this.f1656w.get(i);
                            i4 = i7;
                        }
                    }
                    i7++;
                }
                while (i4 >= 0) {
                    mo1125L0(i4, sVar);
                    i4--;
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0053, code lost:
        if (r0.f1651r == 2) goto L_0x0061;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x005f, code lost:
        if (r0.f1651r == 2) goto L_0x0061;
     */
    /* JADX WARNING: Removed duplicated region for block: B:106:0x019c  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x01a5  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x0212  */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x0218  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0225  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x0239  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x02b2  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x0320  */
    /* JADX WARNING: Removed duplicated region for block: B:185:0x0329  */
    /* JADX WARNING: Removed duplicated region for block: B:188:0x0337  */
    /* JADX WARNING: Removed duplicated region for block: B:192:0x0370  */
    /* JADX WARNING: Removed duplicated region for block: B:200:0x03cc  */
    /* JADX WARNING: Removed duplicated region for block: B:201:0x03dd  */
    /* JADX WARNING: Removed duplicated region for block: B:204:0x03f8  */
    /* JADX WARNING: Removed duplicated region for block: B:209:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x006e  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x00c3  */
    /* renamed from: x0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo883x0(androidx.recyclerview.widget.RecyclerView.C0173s r23, androidx.recyclerview.widget.RecyclerView.C0178w r24) {
        /*
            r22 = this;
            r0 = r22
            r1 = r23
            r2 = r24
            r0.f1658y = r1
            r0.f1659z = r2
            int r3 = r24.mo1202b()
            if (r3 != 0) goto L_0x0015
            boolean r4 = r2.f912f
            if (r4 == 0) goto L_0x0015
            return
        L_0x0015:
            int r4 = r22.mo1122K()
            int r5 = r0.f1650q
            r6 = 2
            r7 = 1
            r8 = 0
            if (r5 == 0) goto L_0x0056
            if (r5 == r7) goto L_0x004a
            if (r5 == r6) goto L_0x003b
            r9 = 3
            if (r5 == r9) goto L_0x002a
            r0.f1654u = r8
            goto L_0x0063
        L_0x002a:
            if (r4 != r7) goto L_0x002e
            r4 = 1
            goto L_0x002f
        L_0x002e:
            r4 = 0
        L_0x002f:
            r0.f1654u = r4
            int r5 = r0.f1651r
            if (r5 != r6) goto L_0x0038
            r4 = r4 ^ r7
            r0.f1654u = r4
        L_0x0038:
            r0.f1655v = r7
            goto L_0x0066
        L_0x003b:
            if (r4 != r7) goto L_0x003f
            r4 = 1
            goto L_0x0040
        L_0x003f:
            r4 = 0
        L_0x0040:
            r0.f1654u = r4
            int r5 = r0.f1651r
            if (r5 != r6) goto L_0x0063
            r4 = r4 ^ r7
            r0.f1654u = r4
            goto L_0x0063
        L_0x004a:
            if (r4 == r7) goto L_0x004e
            r4 = 1
            goto L_0x004f
        L_0x004e:
            r4 = 0
        L_0x004f:
            r0.f1654u = r4
            int r4 = r0.f1651r
            if (r4 != r6) goto L_0x0063
            goto L_0x0061
        L_0x0056:
            if (r4 != r7) goto L_0x005a
            r4 = 1
            goto L_0x005b
        L_0x005a:
            r4 = 0
        L_0x005b:
            r0.f1654u = r4
            int r4 = r0.f1651r
            if (r4 != r6) goto L_0x0063
        L_0x0061:
            r4 = 1
            goto L_0x0064
        L_0x0063:
            r4 = 0
        L_0x0064:
            r0.f1655v = r4
        L_0x0066:
            r22.mo1991e1()
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            r5 = 0
            if (r4 != 0) goto L_0x0075
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = new com.google.android.flexbox.FlexboxLayoutManager$d
            r4.<init>(r5)
            r0.f1636A = r4
        L_0x0075:
            m10 r4 = r0.f1657x
            r4.mo4538g(r3)
            m10 r4 = r0.f1657x
            r4.mo4539h(r3)
            m10 r4 = r0.f1657x
            r4.mo4537f(r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            r4.f1686j = r8
            com.google.android.flexbox.FlexboxLayoutManager$e r4 = r0.f1640E
            if (r4 == 0) goto L_0x0099
            int r6 = r4.f1687d
            if (r6 < 0) goto L_0x0094
            if (r6 >= r3) goto L_0x0094
            r9 = 1
            goto L_0x0095
        L_0x0094:
            r9 = 0
        L_0x0095:
            if (r9 == 0) goto L_0x0099
            r0.f1641F = r6
        L_0x0099:
            com.google.android.flexbox.FlexboxLayoutManager$b r6 = r0.f1637B
            boolean r9 = r6.f1665f
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            r11 = -1
            if (r9 == 0) goto L_0x00a8
            int r9 = r0.f1641F
            if (r9 != r11) goto L_0x00a8
            if (r4 == 0) goto L_0x0244
        L_0x00a8:
            com.google.android.flexbox.FlexboxLayoutManager.C0384b.m1449b(r6)
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f1637B
            com.google.android.flexbox.FlexboxLayoutManager$e r6 = r0.f1640E
            boolean r9 = r2.f912f
            if (r9 != 0) goto L_0x01a0
            int r9 = r0.f1641F
            if (r9 != r11) goto L_0x00b9
            goto L_0x01a0
        L_0x00b9:
            if (r9 < 0) goto L_0x019c
            int r12 = r24.mo1202b()
            if (r9 < r12) goto L_0x00c3
            goto L_0x019c
        L_0x00c3:
            int r9 = r0.f1641F
            r4.f1660a = r9
            m10 r12 = r0.f1657x
            int[] r12 = r12.f3973c
            r9 = r12[r9]
            r4.f1661b = r9
            com.google.android.flexbox.FlexboxLayoutManager$e r9 = r0.f1640E
            if (r9 == 0) goto L_0x00f3
            int r12 = r24.mo1202b()
            int r9 = r9.f1687d
            if (r9 < 0) goto L_0x00df
            if (r9 >= r12) goto L_0x00df
            r9 = 1
            goto L_0x00e0
        L_0x00df:
            r9 = 0
        L_0x00e0:
            if (r9 == 0) goto L_0x00f3
            fb r9 = r0.f1638C
            int r9 = r9.mo2980k()
            int r6 = r6.f1688e
            int r9 = r9 + r6
            r4.f1662c = r9
            r4.f1666g = r7
            r4.f1661b = r11
            goto L_0x019a
        L_0x00f3:
            int r6 = r0.f1642G
            if (r6 != r10) goto L_0x017b
            int r6 = r0.f1641F
            android.view.View r6 = r0.mo921t(r6)
            if (r6 == 0) goto L_0x015e
            fb r9 = r0.f1638C
            int r9 = r9.mo2972c(r6)
            fb r12 = r0.f1638C
            int r12 = r12.mo2981l()
            if (r9 <= r12) goto L_0x010e
            goto L_0x0177
        L_0x010e:
            fb r9 = r0.f1638C
            int r9 = r9.mo2974e(r6)
            fb r12 = r0.f1638C
            int r12 = r12.mo2980k()
            int r9 = r9 - r12
            if (r9 >= 0) goto L_0x0129
            fb r6 = r0.f1638C
            int r6 = r6.mo2980k()
            r4.f1662c = r6
            r4.f1664e = r8
            goto L_0x019a
        L_0x0129:
            fb r9 = r0.f1638C
            int r9 = r9.mo2976g()
            fb r12 = r0.f1638C
            int r12 = r12.mo2971b(r6)
            int r9 = r9 - r12
            if (r9 >= 0) goto L_0x0143
            fb r6 = r0.f1638C
            int r6 = r6.mo2976g()
            r4.f1662c = r6
            r4.f1664e = r7
            goto L_0x019a
        L_0x0143:
            boolean r9 = r4.f1664e
            if (r9 == 0) goto L_0x0155
            fb r9 = r0.f1638C
            int r6 = r9.mo2971b(r6)
            fb r9 = r0.f1638C
            int r9 = r9.mo3550m()
            int r9 = r9 + r6
            goto L_0x015b
        L_0x0155:
            fb r9 = r0.f1638C
            int r9 = r9.mo2974e(r6)
        L_0x015b:
            r4.f1662c = r9
            goto L_0x019a
        L_0x015e:
            int r6 = r22.mo1166z()
            if (r6 <= 0) goto L_0x0177
            android.view.View r6 = r0.mo1165y(r8)
            if (r6 == 0) goto L_0x0177
            int r6 = r0.mo1135S(r6)
            int r9 = r0.f1641F
            if (r9 >= r6) goto L_0x0174
            r6 = 1
            goto L_0x0175
        L_0x0174:
            r6 = 0
        L_0x0175:
            r4.f1664e = r6
        L_0x0177:
            com.google.android.flexbox.FlexboxLayoutManager.C0384b.m1448a(r4)
            goto L_0x019a
        L_0x017b:
            boolean r6 = r22.mo2008v1()
            if (r6 != 0) goto L_0x018f
            boolean r6 = r0.f1654u
            if (r6 == 0) goto L_0x018f
            int r6 = r0.f1642G
            fb r9 = r0.f1638C
            int r9 = r9.mo2977h()
            int r6 = r6 - r9
            goto L_0x0198
        L_0x018f:
            fb r6 = r0.f1638C
            int r6 = r6.mo2980k()
            int r9 = r0.f1642G
            int r6 = r6 + r9
        L_0x0198:
            r4.f1662c = r6
        L_0x019a:
            r6 = 1
            goto L_0x01a1
        L_0x019c:
            r0.f1641F = r11
            r0.f1642G = r10
        L_0x01a0:
            r6 = 0
        L_0x01a1:
            if (r6 == 0) goto L_0x01a5
            goto L_0x0240
        L_0x01a5:
            int r6 = r22.mo1166z()
            if (r6 != 0) goto L_0x01ad
            goto L_0x0235
        L_0x01ad:
            boolean r6 = r4.f1664e
            if (r6 == 0) goto L_0x01ba
            int r6 = r24.mo1202b()
            android.view.View r6 = r0.mo1995i1(r6)
            goto L_0x01c2
        L_0x01ba:
            int r6 = r24.mo1202b()
            android.view.View r6 = r0.mo1993g1(r6)
        L_0x01c2:
            if (r6 == 0) goto L_0x0235
            com.google.android.flexbox.FlexboxLayoutManager r9 = com.google.android.flexbox.FlexboxLayoutManager.this
            int r12 = r9.f1651r
            if (r12 != 0) goto L_0x01cd
            fb r12 = r9.f1639D
            goto L_0x01cf
        L_0x01cd:
            fb r12 = r9.f1638C
        L_0x01cf:
            boolean r9 = r9.mo2008v1()
            if (r9 != 0) goto L_0x01e9
            com.google.android.flexbox.FlexboxLayoutManager r9 = com.google.android.flexbox.FlexboxLayoutManager.this
            boolean r9 = r9.f1654u
            if (r9 == 0) goto L_0x01e9
            boolean r9 = r4.f1664e
            if (r9 == 0) goto L_0x01e4
            int r9 = r12.mo2974e(r6)
            goto L_0x01f1
        L_0x01e4:
            int r9 = r12.mo2971b(r6)
            goto L_0x01fd
        L_0x01e9:
            boolean r9 = r4.f1664e
            if (r9 == 0) goto L_0x01f9
            int r9 = r12.mo2971b(r6)
        L_0x01f1:
            int r12 = r12.mo3550m()
            int r12 = r12 + r9
            r4.f1662c = r12
            goto L_0x01ff
        L_0x01f9:
            int r9 = r12.mo2974e(r6)
        L_0x01fd:
            r4.f1662c = r9
        L_0x01ff:
            com.google.android.flexbox.FlexboxLayoutManager r9 = com.google.android.flexbox.FlexboxLayoutManager.this
            int r6 = r9.mo1135S(r6)
            r4.f1660a = r6
            r4.f1666g = r8
            com.google.android.flexbox.FlexboxLayoutManager r9 = com.google.android.flexbox.FlexboxLayoutManager.this
            m10 r12 = r9.f1657x
            int[] r12 = r12.f3973c
            if (r6 == r11) goto L_0x0212
            goto L_0x0213
        L_0x0212:
            r6 = 0
        L_0x0213:
            r6 = r12[r6]
            if (r6 == r11) goto L_0x0218
            goto L_0x0219
        L_0x0218:
            r6 = 0
        L_0x0219:
            r4.f1661b = r6
            java.util.List<l10> r6 = r9.f1656w
            int r6 = r6.size()
            int r9 = r4.f1661b
            if (r6 <= r9) goto L_0x0233
            com.google.android.flexbox.FlexboxLayoutManager r6 = com.google.android.flexbox.FlexboxLayoutManager.this
            java.util.List<l10> r6 = r6.f1656w
            java.lang.Object r6 = r6.get(r9)
            l10 r6 = (p000.l10) r6
            int r6 = r6.f3780k
            r4.f1660a = r6
        L_0x0233:
            r6 = 1
            goto L_0x0236
        L_0x0235:
            r6 = 0
        L_0x0236:
            if (r6 == 0) goto L_0x0239
            goto L_0x0240
        L_0x0239:
            com.google.android.flexbox.FlexboxLayoutManager.C0384b.m1448a(r4)
            r4.f1660a = r8
            r4.f1661b = r8
        L_0x0240:
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f1637B
            r4.f1665f = r7
        L_0x0244:
            r22.mo1159q(r23)
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f1637B
            boolean r6 = r4.f1664e
            if (r6 == 0) goto L_0x0251
            r0.mo1986B1(r4, r8, r7)
            goto L_0x0254
        L_0x0251:
            r0.mo1985A1(r4, r8, r7)
        L_0x0254:
            int r4 = r0.f879o
            int r6 = r0.f877m
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r6)
            int r6 = r0.f880p
            int r9 = r0.f878n
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r9)
            int r9 = r0.f879o
            int r12 = r0.f880p
            boolean r13 = r22.mo2008v1()
            if (r13 == 0) goto L_0x028a
            int r13 = r0.f1643H
            if (r13 == r10) goto L_0x0276
            if (r13 == r9) goto L_0x0276
            r10 = 1
            goto L_0x0277
        L_0x0276:
            r10 = 0
        L_0x0277:
            com.google.android.flexbox.FlexboxLayoutManager$d r13 = r0.f1636A
            boolean r14 = r13.f1678b
            if (r14 == 0) goto L_0x02a6
            android.content.Context r13 = r0.f1646K
            android.content.res.Resources r13 = r13.getResources()
            android.util.DisplayMetrics r13 = r13.getDisplayMetrics()
            int r13 = r13.heightPixels
            goto L_0x02a8
        L_0x028a:
            int r13 = r0.f1644I
            if (r13 == r10) goto L_0x0292
            if (r13 == r12) goto L_0x0292
            r10 = 1
            goto L_0x0293
        L_0x0292:
            r10 = 0
        L_0x0293:
            com.google.android.flexbox.FlexboxLayoutManager$d r13 = r0.f1636A
            boolean r14 = r13.f1678b
            if (r14 == 0) goto L_0x02a6
            android.content.Context r13 = r0.f1646K
            android.content.res.Resources r13 = r13.getResources()
            android.util.DisplayMetrics r13 = r13.getDisplayMetrics()
            int r13 = r13.widthPixels
            goto L_0x02a8
        L_0x02a6:
            int r13 = r13.f1677a
        L_0x02a8:
            r17 = r13
            r0.f1643H = r9
            r0.f1644I = r12
            int r9 = r0.f1648M
            if (r9 != r11) goto L_0x031e
            int r12 = r0.f1641F
            if (r12 != r11) goto L_0x02b8
            if (r10 == 0) goto L_0x031e
        L_0x02b8:
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f1637B
            boolean r3 = r3.f1664e
            if (r3 == 0) goto L_0x02c0
            goto L_0x03c1
        L_0x02c0:
            java.util.List<l10> r3 = r0.f1656w
            r3.clear()
            m10$a r3 = r0.f1649N
            r3.f3976a = r5
            boolean r3 = r22.mo2008v1()
            m10 r12 = r0.f1657x
            m10$a r13 = r0.f1649N
            if (r3 == 0) goto L_0x02e8
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f1637B
            int r3 = r3.f1660a
            java.util.List<l10> r5 = r0.f1656w
            r9 = 0
            r14 = r4
            r15 = r6
            r16 = r17
            r17 = r9
            r18 = r3
            r19 = r5
            r12.mo4533b(r13, r14, r15, r16, r17, r18, r19)
            goto L_0x02fc
        L_0x02e8:
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f1637B
            int r3 = r3.f1660a
            java.util.List<l10> r5 = r0.f1656w
            r9 = 0
            r14 = r6
            r15 = r4
            r16 = r17
            r17 = r9
            r18 = r3
            r19 = r5
            r12.mo4533b(r13, r14, r15, r16, r17, r18, r19)
        L_0x02fc:
            m10$a r3 = r0.f1649N
            java.util.List<l10> r3 = r3.f3976a
            r0.f1656w = r3
            m10 r3 = r0.f1657x
            r3.mo4536e(r4, r6, r8)
            m10 r3 = r0.f1657x
            r3.mo4554w(r8)
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f1637B
            m10 r4 = r0.f1657x
            int[] r4 = r4.f3973c
            int r5 = r3.f1660a
            r4 = r4[r5]
            r3.f1661b = r4
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            r3.f1679c = r4
            goto L_0x03c1
        L_0x031e:
            if (r9 == r11) goto L_0x0329
            com.google.android.flexbox.FlexboxLayoutManager$b r10 = r0.f1637B
            int r10 = r10.f1660a
            int r9 = java.lang.Math.min(r9, r10)
            goto L_0x032d
        L_0x0329:
            com.google.android.flexbox.FlexboxLayoutManager$b r9 = r0.f1637B
            int r9 = r9.f1660a
        L_0x032d:
            m10$a r10 = r0.f1649N
            r10.f3976a = r5
            boolean r5 = r22.mo2008v1()
            if (r5 == 0) goto L_0x0370
            java.util.List<l10> r5 = r0.f1656w
            int r5 = r5.size()
            if (r5 <= 0) goto L_0x0356
            m10 r3 = r0.f1657x
            java.util.List<l10> r5 = r0.f1656w
            r3.mo4535d(r5, r9)
            m10 r3 = r0.f1657x
            m10$a r5 = r0.f1649N
            com.google.android.flexbox.FlexboxLayoutManager$b r10 = r0.f1637B
            int r10 = r10.f1660a
            java.util.List<l10> r11 = r0.f1656w
            r13 = r3
            r15 = r4
            r14 = r5
            r16 = r6
            goto L_0x038e
        L_0x0356:
            m10 r5 = r0.f1657x
            r5.mo4537f(r3)
            m10 r12 = r0.f1657x
            m10$a r13 = r0.f1649N
            r3 = 0
            java.util.List<l10> r5 = r0.f1656w
            r18 = -1
            r14 = r4
            r15 = r6
            r16 = r17
            r17 = r3
            r19 = r5
            r12.mo4533b(r13, r14, r15, r16, r17, r18, r19)
            goto L_0x03b1
        L_0x0370:
            java.util.List<l10> r5 = r0.f1656w
            int r5 = r5.size()
            if (r5 <= 0) goto L_0x0398
            m10 r3 = r0.f1657x
            java.util.List<l10> r5 = r0.f1656w
            r3.mo4535d(r5, r9)
            m10 r3 = r0.f1657x
            m10$a r5 = r0.f1649N
            com.google.android.flexbox.FlexboxLayoutManager$b r10 = r0.f1637B
            int r10 = r10.f1660a
            java.util.List<l10> r11 = r0.f1656w
            r13 = r3
            r16 = r4
            r14 = r5
            r15 = r6
        L_0x038e:
            r19 = r10
            r20 = r11
            r18 = r9
            r13.mo4533b(r14, r15, r16, r17, r18, r19, r20)
            goto L_0x03b1
        L_0x0398:
            m10 r5 = r0.f1657x
            r5.mo4537f(r3)
            m10 r12 = r0.f1657x
            m10$a r13 = r0.f1649N
            r3 = 0
            java.util.List<l10> r5 = r0.f1656w
            r18 = -1
            r14 = r6
            r15 = r4
            r16 = r17
            r17 = r3
            r19 = r5
            r12.mo4533b(r13, r14, r15, r16, r17, r18, r19)
        L_0x03b1:
            m10$a r3 = r0.f1649N
            java.util.List<l10> r3 = r3.f3976a
            r0.f1656w = r3
            m10 r3 = r0.f1657x
            r3.mo4536e(r4, r6, r9)
            m10 r3 = r0.f1657x
            r3.mo4554w(r9)
        L_0x03c1:
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            r0.mo1992f1(r1, r2, r3)
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f1637B
            boolean r4 = r3.f1664e
            if (r4 == 0) goto L_0x03dd
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1681e
            r0.mo1985A1(r3, r7, r8)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            r0.mo1992f1(r1, r2, r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r3 = r3.f1681e
            goto L_0x03f2
        L_0x03dd:
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f1636A
            int r4 = r4.f1681e
            r0.mo1986B1(r3, r7, r8)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            r0.mo1992f1(r1, r2, r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f1636A
            int r3 = r3.f1681e
            r21 = r4
            r4 = r3
            r3 = r21
        L_0x03f2:
            int r5 = r22.mo1166z()
            if (r5 <= 0) goto L_0x040f
            com.google.android.flexbox.FlexboxLayoutManager$b r5 = r0.f1637B
            boolean r5 = r5.f1664e
            if (r5 == 0) goto L_0x0407
            int r3 = r0.mo2000n1(r3, r1, r2, r7)
            int r3 = r3 + r4
            r0.mo2001o1(r3, r1, r2, r8)
            goto L_0x040f
        L_0x0407:
            int r4 = r0.mo2001o1(r4, r1, r2, r7)
            int r4 = r4 + r3
            r0.mo2000n1(r4, r1, r2, r8)
        L_0x040f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo883x0(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$w):void");
    }

    /* renamed from: x1 */
    public final void mo2010x1() {
        int i;
        if (mo2008v1()) {
            i = this.f878n;
        } else {
            i = this.f877m;
        }
        this.f1636A.f1678b = i == 0 || i == Integer.MIN_VALUE;
    }

    /* renamed from: y0 */
    public void mo884y0(RecyclerView.C0178w wVar) {
        this.f1640E = null;
        this.f1641F = -1;
        this.f1642G = Integer.MIN_VALUE;
        this.f1648M = -1;
        C0384b.m1449b(this.f1637B);
        this.f1645J.clear();
    }

    /* renamed from: y1 */
    public void mo2011y1(int i) {
        if (this.f1650q != i) {
            mo1117H0();
            this.f1650q = i;
            this.f1638C = null;
            this.f1639D = null;
            mo1987a1();
            mo1129N0();
        }
    }

    /* renamed from: z1 */
    public final void mo2012z1(int i) {
        if (i < mo1997k1()) {
            int z = mo1166z();
            this.f1657x.mo4538g(z);
            this.f1657x.mo4539h(z);
            this.f1657x.mo4537f(z);
            if (i < this.f1657x.f3973c.length) {
                this.f1648M = i;
                View y = mo1165y(0);
                if (y != null) {
                    this.f1641F = mo1135S(y);
                    if (mo2008v1() || !this.f1654u) {
                        this.f1642G = this.f1638C.mo2974e(y) - this.f1638C.mo2980k();
                        return;
                    }
                    this.f1642G = this.f1638C.mo2977h() + this.f1638C.mo2971b(y);
                }
            }
        }
    }
}
