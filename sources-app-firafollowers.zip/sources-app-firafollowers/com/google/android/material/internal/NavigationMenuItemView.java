package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0243b1;
import p000.C1216n2;

public class NavigationMenuItemView extends d30 implements C0243b1.C0244a {

    /* renamed from: I */
    public static final int[] f1799I = {16842912};

    /* renamed from: A */
    public boolean f1800A;

    /* renamed from: B */
    public final CheckedTextView f1801B;

    /* renamed from: C */
    public FrameLayout f1802C;

    /* renamed from: D */
    public C1967w0 f1803D;

    /* renamed from: E */
    public ColorStateList f1804E;

    /* renamed from: F */
    public boolean f1805F;

    /* renamed from: G */
    public Drawable f1806G;

    /* renamed from: H */
    public final C1163m6 f1807H;

    /* renamed from: y */
    public final int f1808y;

    /* renamed from: z */
    public boolean f1809z;

    /* renamed from: com.google.android.material.internal.NavigationMenuItemView$a */
    public class C0406a extends C1163m6 {
        public C0406a() {
        }

        /* renamed from: d */
        public void mo773d(View view, C1226n7 n7Var) {
            this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
            n7Var.f4196a.setCheckable(NavigationMenuItemView.this.f1800A);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        C0406a aVar = new C0406a();
        this.f1807H = aVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(R.layout.design_navigation_menu_item, this, true);
        this.f1808y = context.getResources().getDimensionPixelSize(R.dimen.design_navigation_icon_size);
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(R.id.design_menu_item_text);
        this.f1801B = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        C0010a7.m43p(checkedTextView, aVar);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f1802C == null) {
                this.f1802C = (FrameLayout) ((ViewStub) findViewById(R.id.design_menu_item_action_area_stub)).inflate();
            }
            this.f1802C.removeAllViews();
            this.f1802C.addView(view);
        }
    }

    /* renamed from: d */
    public void mo171d(C1967w0 w0Var, int i) {
        int i2;
        C1216n2.C1217a aVar;
        StateListDrawable stateListDrawable;
        this.f1803D = w0Var;
        setVisibility(w0Var.isVisible() ? 0 : 8);
        boolean z = true;
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(R.attr.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(f1799I, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            setBackground(stateListDrawable);
        }
        setCheckable(w0Var.isCheckable());
        setChecked(w0Var.isChecked());
        setEnabled(w0Var.isEnabled());
        setTitle(w0Var.f6465e);
        setIcon(w0Var.getIcon());
        setActionView(w0Var.getActionView());
        setContentDescription(w0Var.f6477q);
        C0520d.m1654c(this, w0Var.f6478r);
        C1967w0 w0Var2 = this.f1803D;
        if (!(w0Var2.f6465e == null && w0Var2.getIcon() == null && this.f1803D.getActionView() != null)) {
            z = false;
        }
        if (z) {
            this.f1801B.setVisibility(8);
            FrameLayout frameLayout = this.f1802C;
            if (frameLayout != null) {
                aVar = (C1216n2.C1217a) frameLayout.getLayoutParams();
                i2 = -1;
            } else {
                return;
            }
        } else {
            this.f1801B.setVisibility(0);
            FrameLayout frameLayout2 = this.f1802C;
            if (frameLayout2 != null) {
                aVar = (C1216n2.C1217a) frameLayout2.getLayoutParams();
                i2 = -2;
            } else {
                return;
            }
        }
        aVar.width = i2;
        this.f1802C.setLayoutParams(aVar);
    }

    public C1967w0 getItemData() {
        return this.f1803D;
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        C1967w0 w0Var = this.f1803D;
        if (w0Var != null && w0Var.isCheckable() && this.f1803D.isChecked()) {
            ViewGroup.mergeDrawableStates(onCreateDrawableState, f1799I);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.f1800A != z) {
            this.f1800A = z;
            this.f1807H.mo4021h(this.f1801B, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.f1801B.setChecked(z);
    }

    public void setHorizontalPadding(int i) {
        setPadding(i, 0, i, 0);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.f1805F) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = C1401p4.m4381p0(drawable).mutate();
                C1401p4.m4367i0(drawable, this.f1804E);
            }
            int i = this.f1808y;
            drawable.setBounds(0, 0, i, i);
        } else if (this.f1809z) {
            if (this.f1806G == null) {
                Drawable a = C0532d5.m1701a(getResources(), R.drawable.navigation_empty_icon, getContext().getTheme());
                this.f1806G = a;
                if (a != null) {
                    int i2 = this.f1808y;
                    a.setBounds(0, 0, i2, i2);
                }
            }
            drawable = this.f1806G;
        }
        this.f1801B.setCompoundDrawablesRelative(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public void setIconPadding(int i) {
        this.f1801B.setCompoundDrawablePadding(i);
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.f1804E = colorStateList;
        this.f1805F = colorStateList != null;
        C1967w0 w0Var = this.f1803D;
        if (w0Var != null) {
            setIcon(w0Var.getIcon());
        }
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.f1809z = z;
    }

    public void setTextAppearance(int i) {
        C1401p4.m4363g0(this.f1801B, i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f1801B.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.f1801B.setText(charSequence);
    }
}
