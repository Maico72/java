package com.google.android.material.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.ImageButton;
import org.fasaroid.fira.R;

public class CheckableImageButton extends C1652r1 implements Checkable {

    /* renamed from: g */
    public static final int[] f1797g = {16842912};

    /* renamed from: f */
    public boolean f1798f;

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.imageButtonStyle);
        C0010a7.m43p(this, new y20(this));
    }

    public boolean isChecked() {
        return this.f1798f;
    }

    public int[] onCreateDrawableState(int i) {
        if (!this.f1798f) {
            return super.onCreateDrawableState(i);
        }
        int[] iArr = f1797g;
        return ImageButton.mergeDrawableStates(super.onCreateDrawableState(i + iArr.length), iArr);
    }

    public void setChecked(boolean z) {
        if (this.f1798f != z) {
            this.f1798f = z;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public void toggle() {
        setChecked(!this.f1798f);
    }
}
