package com.google.android.material.snackbar;

import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.SwipeDismissBehavior;
import java.util.Objects;

public class BaseTransientBottomBar$Behavior extends SwipeDismissBehavior<View> {

    /* renamed from: h */
    public final k30 f1811h = new k30(this);

    /* renamed from: a */
    public boolean mo2082a(View view) {
        Objects.requireNonNull(this.f1811h);
        return view instanceof n30;
    }

    public boolean onInterceptTouchEvent(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        Objects.requireNonNull(this.f1811h);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked == 1 || actionMasked == 3) {
                if (o30.f4439c == null) {
                    o30.f4439c = new o30();
                }
                synchronized (o30.f4439c.f4440a) {
                }
            }
        } else if (coordinatorLayout.mo631q(view, (int) motionEvent.getX(), (int) motionEvent.getY())) {
            if (o30.f4439c == null) {
                o30.f4439c = new o30();
            }
            synchronized (o30.f4439c.f4440a) {
            }
        }
        return super.onInterceptTouchEvent(coordinatorLayout, view, motionEvent);
    }
}
