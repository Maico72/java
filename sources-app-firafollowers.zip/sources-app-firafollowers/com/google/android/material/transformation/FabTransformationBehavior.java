package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.o20;

public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {

    /* renamed from: c */
    public final Rect f1884c = new Rect();

    /* renamed from: d */
    public final RectF f1885d = new RectF();

    /* renamed from: e */
    public final RectF f1886e = new RectF();

    /* renamed from: f */
    public final int[] f1887f = new int[2];

    /* renamed from: com.google.android.material.transformation.FabTransformationBehavior$a */
    public class C0415a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ boolean f1888a;

        /* renamed from: b */
        public final /* synthetic */ View f1889b;

        /* renamed from: c */
        public final /* synthetic */ View f1890c;

        public C0415a(FabTransformationBehavior fabTransformationBehavior, boolean z, View view, View view2) {
            this.f1888a = z;
            this.f1889b = view;
            this.f1890c = view2;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f1888a) {
                this.f1889b.setVisibility(4);
                this.f1890c.setAlpha(1.0f);
                this.f1890c.setVisibility(0);
            }
        }

        public void onAnimationStart(Animator animator) {
            if (this.f1888a) {
                this.f1889b.setVisibility(0);
                this.f1890c.setAlpha(0.0f);
                this.f1890c.setVisibility(4);
            }
        }
    }

    /* renamed from: com.google.android.material.transformation.FabTransformationBehavior$b */
    public static class C0416b {

        /* renamed from: a */
        public v10 f1891a;

        /* renamed from: b */
        public x10 f1892b;
    }

    public FabTransformationBehavior() {
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: c */
    public AnimatorSet mo2336c(View view, View view2, boolean z, boolean z2) {
        C0416b bVar;
        o20 o20;
        Animator animator;
        w10 w10;
        ObjectAnimator objectAnimator;
        View view3 = view;
        View view4 = view2;
        boolean z3 = z;
        int i = Build.VERSION.SDK_INT;
        C0416b m = mo2347m(view2.getContext(), z3);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (i >= 21) {
            mo2344j(view, view2, z, z2, m, arrayList);
        }
        RectF rectF = this.f1885d;
        int i2 = i;
        mo2346l(view, view2, z, z2, m, arrayList, rectF);
        float width = rectF.width();
        float height = rectF.height();
        boolean z4 = view4 instanceof o20;
        if (z4 && (view3 instanceof ImageView)) {
            o20 o202 = (o20) view4;
            Drawable drawable = ((ImageView) view3).getDrawable();
            if (drawable != null) {
                drawable.mutate();
                if (z3) {
                    if (!z2) {
                        drawable.setAlpha(255);
                    }
                    objectAnimator = ObjectAnimator.ofInt(drawable, s10.f5658b, new int[]{0});
                } else {
                    objectAnimator = ObjectAnimator.ofInt(drawable, s10.f5658b, new int[]{255});
                }
                objectAnimator.addUpdateListener(new s30(this, view4));
                m.f1891a.mo6170d("iconFade").mo6371a(objectAnimator);
                arrayList.add(objectAnimator);
                arrayList2.add(new t30(this, o202, drawable));
            }
        }
        if (!z4) {
            bVar = m;
        } else {
            o20 o203 = (o20) view4;
            x10 x10 = m.f1892b;
            RectF rectF2 = this.f1885d;
            RectF rectF3 = this.f1886e;
            mo2341g(view3, rectF2);
            mo2341g(view4, rectF3);
            rectF3.offset(-mo2338d(view3, view4, x10), 0.0f);
            float centerX = rectF2.centerX() - rectF3.left;
            x10 x102 = m.f1892b;
            RectF rectF4 = this.f1885d;
            RectF rectF5 = this.f1886e;
            mo2341g(view3, rectF4);
            mo2341g(view4, rectF5);
            rectF5.offset(0.0f, -mo2339e(view3, view4, x102));
            float centerY = rectF4.centerY() - rectF5.top;
            ((FloatingActionButton) view3).mo2161f(this.f1884c);
            float width2 = ((float) this.f1884c.width()) / 2.0f;
            w10 d = m.f1891a.mo6170d("expansion");
            if (z3) {
                if (!z2) {
                    o203.setRevealInfo(new o20.C1293e(centerX, centerY, width2));
                }
                if (z2) {
                    width2 = o203.getRevealInfo().f4425c;
                }
                float f = n10.m3810f(centerX, centerY, 0.0f, 0.0f);
                float f2 = n10.m3810f(centerX, centerY, width, 0.0f);
                float f3 = n10.m3810f(centerX, centerY, width, height);
                float f4 = n10.m3810f(centerX, centerY, 0.0f, height);
                if (f <= f2 || f <= f3 || f <= f4) {
                    f = (f2 <= f3 || f2 <= f4) ? f3 > f4 ? f3 : f4 : f2;
                }
                Animator c = n10.m3807c(o203, centerX, centerY, f);
                c.addListener(new u30(this, o203));
                mo2345k(view2, d.f6493a, (int) centerX, (int) centerY, width2, arrayList);
                w10 = d;
                bVar = m;
                animator = c;
                o20 = o203;
            } else {
                o20 o204 = o203;
                float f5 = o204.getRevealInfo().f4425c;
                o20 o205 = o204;
                Animator c2 = n10.m3807c(o205, centerX, centerY, width2);
                int i3 = (int) centerX;
                int i4 = (int) centerY;
                int i5 = i3;
                o20 = o205;
                float f6 = width2;
                mo2345k(view2, d.f6493a, i3, i4, f5, arrayList);
                long j = d.f6493a;
                long j2 = d.f6494b;
                v10 v10 = m.f1891a;
                int i6 = v10.f6232a.f2478f;
                long j3 = 0;
                int i7 = 0;
                while (i7 < i6) {
                    int i8 = i6;
                    w10 l = v10.f6232a.mo3284l(i7);
                    j3 = Math.max(j3, l.f6493a + l.f6494b);
                    i7++;
                    i6 = i8;
                    m = m;
                    d = d;
                    v10 = v10;
                }
                w10 w102 = d;
                bVar = m;
                if (i2 >= 21) {
                    long j4 = j + j2;
                    if (j4 < j3) {
                        Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view4, i5, i4, f6, f6);
                        createCircularReveal.setStartDelay(j4);
                        createCircularReveal.setDuration(j3 - j4);
                        arrayList.add(createCircularReveal);
                    }
                }
                animator = c2;
                w10 = w102;
            }
            w10.mo6371a(animator);
            arrayList.add(animator);
            arrayList2.add(new l20(o20));
        }
        mo2343i(view, view2, z, z2, bVar, arrayList);
        mo2342h(view2, z, z2, bVar, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        n10.m3823s(animatorSet, arrayList);
        animatorSet.addListener(new C0415a(this, z, view4, view));
        int size = arrayList2.size();
        for (int i9 = 0; i9 < size; i9++) {
            animatorSet.addListener((Animator.AnimatorListener) arrayList2.get(i9));
        }
        return animatorSet;
    }

    /* renamed from: d */
    public final float mo2338d(View view, View view2, x10 x10) {
        RectF rectF = this.f1885d;
        RectF rectF2 = this.f1886e;
        mo2341g(view, rectF);
        mo2341g(view2, rectF2);
        Objects.requireNonNull(x10);
        return (rectF2.centerX() - rectF.centerX()) + 0.0f;
    }

    /* renamed from: e */
    public final float mo2339e(View view, View view2, x10 x10) {
        RectF rectF = this.f1885d;
        RectF rectF2 = this.f1886e;
        mo2341g(view, rectF);
        mo2341g(view2, rectF2);
        Objects.requireNonNull(x10);
        return (rectF2.centerY() - rectF.centerY()) + 0.0f;
    }

    /* renamed from: f */
    public final float mo2340f(C0416b bVar, w10 w10, float f, float f2) {
        long j = w10.f6493a;
        long j2 = w10.f6494b;
        w10 d = bVar.f1891a.mo6170d("expansion");
        float interpolation = w10.mo6372b().getInterpolation(((float) (((d.f6493a + d.f6494b) + 17) - j)) / ((float) j2));
        TimeInterpolator timeInterpolator = p10.f4733a;
        return C1012kd.m3192a(f2, f, interpolation, f);
    }

    /* renamed from: g */
    public final void mo2341g(View view, RectF rectF) {
        rectF.set(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
        int[] iArr = this.f1887f;
        view.getLocationInWindow(iArr);
        rectF.offsetTo((float) iArr[0], (float) iArr[1]);
        rectF.offset((float) ((int) (-view.getTranslationX())), (float) ((int) (-view.getTranslationY())));
    }

    /* renamed from: h */
    public final void mo2342h(View view, boolean z, boolean z2, C0416b bVar, List list) {
        ViewGroup viewGroup;
        ObjectAnimator objectAnimator;
        if (view instanceof ViewGroup) {
            if (!(view instanceof o20) || n20.f4179a != 0) {
                View findViewById = view.findViewById(R.id.mtrl_child_content_container);
                if (findViewById != null) {
                    viewGroup = mo2348n(findViewById);
                } else {
                    if ((view instanceof w30) || (view instanceof v30)) {
                        view = ((ViewGroup) view).getChildAt(0);
                    }
                    viewGroup = mo2348n(view);
                }
                if (viewGroup != null) {
                    if (z) {
                        if (!z2) {
                            r10.f5405a.set(viewGroup, Float.valueOf(0.0f));
                        }
                        objectAnimator = ObjectAnimator.ofFloat(viewGroup, r10.f5405a, new float[]{1.0f});
                    } else {
                        objectAnimator = ObjectAnimator.ofFloat(viewGroup, r10.f5405a, new float[]{0.0f});
                    }
                    bVar.f1891a.mo6170d("contentFade").mo6371a(objectAnimator);
                    list.add(objectAnimator);
                }
            }
        }
    }

    /* renamed from: i */
    public final void mo2343i(View view, View view2, boolean z, boolean z2, C0416b bVar, List list) {
        ObjectAnimator objectAnimator;
        if (view2 instanceof o20) {
            o20 o20 = (o20) view2;
            ColorStateList g = C0010a7.m34g(view);
            int colorForState = g != null ? g.getColorForState(view.getDrawableState(), g.getDefaultColor()) : 0;
            int i = 16777215 & colorForState;
            if (z) {
                if (!z2) {
                    o20.setCircularRevealScrimColor(colorForState);
                }
                objectAnimator = ObjectAnimator.ofInt(o20, o20.C1292d.f4422a, new int[]{i});
            } else {
                objectAnimator = ObjectAnimator.ofInt(o20, o20.C1292d.f4422a, new int[]{colorForState});
            }
            objectAnimator.setEvaluator(q10.f4974a);
            bVar.f1891a.mo6170d("color").mo6371a(objectAnimator);
            list.add(objectAnimator);
        }
    }

    @TargetApi(21)
    /* renamed from: j */
    public final void mo2344j(View view, View view2, boolean z, boolean z2, C0416b bVar, List list) {
        ObjectAnimator objectAnimator;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int i = Build.VERSION.SDK_INT;
        float elevation = (i >= 21 ? view2.getElevation() : 0.0f) - (i >= 21 ? view.getElevation() : 0.0f);
        if (z) {
            if (!z2) {
                view2.setTranslationZ(-elevation);
            }
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{0.0f});
        } else {
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{-elevation});
        }
        bVar.f1891a.mo6170d("elevation").mo6371a(objectAnimator);
        list.add(objectAnimator);
    }

    /* renamed from: k */
    public final void mo2345k(View view, long j, int i, int i2, float f, List<Animator> list) {
        if (Build.VERSION.SDK_INT >= 21 && j > 0) {
            Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view, i, i2, f, f);
            createCircularReveal.setStartDelay(0);
            createCircularReveal.setDuration(j);
            list.add(createCircularReveal);
        }
    }

    /* renamed from: l */
    public final void mo2346l(View view, View view2, boolean z, boolean z2, C0416b bVar, List list, RectF rectF) {
        String str;
        v10 v10;
        w10 w10;
        ObjectAnimator objectAnimator;
        ObjectAnimator objectAnimator2;
        float d = mo2338d(view, view2, bVar.f1892b);
        float e = mo2339e(view, view2, bVar.f1892b);
        if (d == 0.0f || e == 0.0f) {
            w10 = bVar.f1891a.mo6170d("translationXLinear");
            v10 = bVar.f1891a;
            str = "translationYLinear";
        } else if ((!z || e >= 0.0f) && (z || e <= 0.0f)) {
            w10 = bVar.f1891a.mo6170d("translationXCurveDownwards");
            v10 = bVar.f1891a;
            str = "translationYCurveDownwards";
        } else {
            w10 = bVar.f1891a.mo6170d("translationXCurveUpwards");
            v10 = bVar.f1891a;
            str = "translationYCurveUpwards";
        }
        w10 d2 = v10.mo6170d(str);
        if (z) {
            if (!z2) {
                view2.setTranslationX(-d);
                view2.setTranslationY(-e);
            }
            objectAnimator2 = ObjectAnimator.ofFloat(view2, View.TRANSLATION_X, new float[]{0.0f});
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Y, new float[]{0.0f});
            float f = mo2340f(bVar, w10, -d, 0.0f);
            float f2 = mo2340f(bVar, d2, -e, 0.0f);
            Rect rect = this.f1884c;
            view2.getWindowVisibleDisplayFrame(rect);
            RectF rectF2 = this.f1885d;
            rectF2.set(rect);
            RectF rectF3 = this.f1886e;
            mo2341g(view2, rectF3);
            rectF3.offset(f, f2);
            rectF3.intersect(rectF2);
            rectF.set(rectF3);
        } else {
            objectAnimator2 = ObjectAnimator.ofFloat(view2, View.TRANSLATION_X, new float[]{-d});
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Y, new float[]{-e});
        }
        w10.mo6371a(objectAnimator2);
        d2.mo6371a(objectAnimator);
        list.add(objectAnimator2);
        list.add(objectAnimator);
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() == 8) {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        } else if (!(view2 instanceof FloatingActionButton)) {
            return false;
        } else {
            int expandedComponentIdHint = ((FloatingActionButton) view2).getExpandedComponentIdHint();
            return expandedComponentIdHint == 0 || expandedComponentIdHint == view.getId();
        }
    }

    /* renamed from: m */
    public abstract C0416b mo2347m(Context context, boolean z);

    /* renamed from: n */
    public final ViewGroup mo2348n(View view) {
        if (view instanceof ViewGroup) {
            return (ViewGroup) view;
        }
        return null;
    }

    public void onAttachedToLayoutParams(CoordinatorLayout.C0123f fVar) {
        if (fVar.f581h == 0) {
            fVar.f581h = 80;
        }
    }
}
