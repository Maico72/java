package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class FabTransformationScrimBehavior extends ExpandableTransformationBehavior {

    /* renamed from: c */
    public final w10 f1893c = new w10(75, 150);

    /* renamed from: d */
    public final w10 f1894d = new w10(0, 150);

    /* renamed from: com.google.android.material.transformation.FabTransformationScrimBehavior$a */
    public class C0417a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ boolean f1895a;

        /* renamed from: b */
        public final /* synthetic */ View f1896b;

        public C0417a(FabTransformationScrimBehavior fabTransformationScrimBehavior, boolean z, View view) {
            this.f1895a = z;
            this.f1896b = view;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f1895a) {
                this.f1896b.setVisibility(4);
            }
        }

        public void onAnimationStart(Animator animator) {
            if (this.f1895a) {
                this.f1896b.setVisibility(0);
            }
        }
    }

    public FabTransformationScrimBehavior() {
    }

    public FabTransformationScrimBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: c */
    public AnimatorSet mo2336c(View view, View view2, boolean z, boolean z2) {
        ArrayList arrayList = new ArrayList();
        new ArrayList();
        mo2351d(view2, z, z2, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        n10.m3823s(animatorSet, arrayList);
        animatorSet.addListener(new C0417a(this, z, view2));
        return animatorSet;
    }

    /* renamed from: d */
    public final void mo2351d(View view, boolean z, boolean z2, List list) {
        ObjectAnimator objectAnimator;
        w10 w10 = z ? this.f1893c : this.f1894d;
        if (z) {
            if (!z2) {
                view.setAlpha(0.0f);
            }
            objectAnimator = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{1.0f});
        } else {
            objectAnimator = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{0.0f});
        }
        w10.mo6371a(objectAnimator);
        list.add(objectAnimator);
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
        return view2 instanceof FloatingActionButton;
    }

    public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        return super.onTouchEvent(coordinatorLayout, view, motionEvent);
    }
}
