package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.transformation.FabTransformationBehavior;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

public class FabTransformationSheetBehavior extends FabTransformationBehavior {

    /* renamed from: g */
    public Map<View, Integer> f1897g;

    public FabTransformationSheetBehavior() {
    }

    public FabTransformationSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: b */
    public boolean mo2334b(View view, View view2, boolean z, boolean z2) {
        int i;
        ViewParent parent = view2.getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            if (z) {
                this.f1897g = new HashMap(childCount);
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                boolean z3 = (childAt.getLayoutParams() instanceof CoordinatorLayout.C0123f) && (((CoordinatorLayout.C0123f) childAt.getLayoutParams()).f574a instanceof FabTransformationScrimBehavior);
                if (childAt != view2 && !z3) {
                    Map<View, Integer> map = this.f1897g;
                    if (z) {
                        map.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                        i = 4;
                    } else if (map != null && map.containsKey(childAt)) {
                        i = this.f1897g.get(childAt).intValue();
                    }
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    childAt.setImportantForAccessibility(i);
                }
            }
            if (!z) {
                this.f1897g = null;
            }
        }
        super.mo2334b(view, view2, z, z2);
        return true;
    }

    /* renamed from: m */
    public FabTransformationBehavior.C0416b mo2347m(Context context, boolean z) {
        int i = z ? R.animator.mtrl_fab_transformation_sheet_expand_spec : R.animator.mtrl_fab_transformation_sheet_collapse_spec;
        FabTransformationBehavior.C0416b bVar = new FabTransformationBehavior.C0416b();
        bVar.f1891a = v10.m5326b(context, i);
        bVar.f1892b = new x10(17, 0.0f, 0.0f);
        return bVar;
    }
}
