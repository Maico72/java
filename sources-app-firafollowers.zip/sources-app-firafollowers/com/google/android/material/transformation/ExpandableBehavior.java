package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.List;
import java.util.WeakHashMap;

public abstract class ExpandableBehavior extends CoordinatorLayout.C0120c<View> {

    /* renamed from: a */
    public int f1877a = 0;

    /* renamed from: com.google.android.material.transformation.ExpandableBehavior$a */
    public class C0413a implements ViewTreeObserver.OnPreDrawListener {

        /* renamed from: d */
        public final /* synthetic */ View f1878d;

        /* renamed from: e */
        public final /* synthetic */ int f1879e;

        /* renamed from: f */
        public final /* synthetic */ q20 f1880f;

        public C0413a(View view, int i, q20 q20) {
            this.f1878d = view;
            this.f1879e = i;
            this.f1880f = q20;
        }

        public boolean onPreDraw() {
            this.f1878d.getViewTreeObserver().removeOnPreDrawListener(this);
            ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
            if (expandableBehavior.f1877a == this.f1879e) {
                q20 q20 = this.f1880f;
                expandableBehavior.mo2334b((View) q20, this.f1878d, q20.mo2157a(), false);
            }
            return false;
        }
    }

    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public final boolean mo2333a(boolean z) {
        if (!z) {
            return this.f1877a == 1;
        }
        int i = this.f1877a;
        return i == 0 || i == 2;
    }

    /* renamed from: b */
    public abstract boolean mo2334b(View view, View view2, boolean z, boolean z2);

    public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, View view, View view2) {
        q20 q20 = (q20) view2;
        if (!mo2333a(q20.mo2157a())) {
            return false;
        }
        this.f1877a = q20.mo2157a() ? 1 : 2;
        return mo2334b((View) q20, view, q20.mo2157a(), true);
    }

    public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, View view, int i) {
        q20 q20;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (!view.isLaidOut()) {
            List<View> e = coordinatorLayout.mo607e(view);
            int size = e.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    q20 = null;
                    break;
                }
                View view2 = e.get(i2);
                if (layoutDependsOn(coordinatorLayout, view, view2)) {
                    q20 = (q20) view2;
                    break;
                }
                i2++;
            }
            if (q20 != null && mo2333a(q20.mo2157a())) {
                int i3 = q20.mo2157a() ? 1 : 2;
                this.f1877a = i3;
                view.getViewTreeObserver().addOnPreDrawListener(new C0413a(view, i3, q20));
            }
        }
        return false;
    }
}
