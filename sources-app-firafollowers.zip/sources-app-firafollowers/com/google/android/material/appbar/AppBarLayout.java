package com.google.android.material.appbar;

import android.animation.AnimatorInflater;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.roughike.bottombar.C0446R;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

@CoordinatorLayout.C0121d(Behavior.class)
public class AppBarLayout extends LinearLayout {

    /* renamed from: d */
    public int f1689d = -1;

    /* renamed from: e */
    public int f1690e = -1;

    /* renamed from: f */
    public int f1691f = -1;

    /* renamed from: g */
    public boolean f1692g;

    /* renamed from: h */
    public int f1693h = 0;

    /* renamed from: i */
    public C0943j7 f1694i;

    /* renamed from: j */
    public boolean f1695j;

    /* renamed from: k */
    public boolean f1696k;

    /* renamed from: l */
    public boolean f1697l;

    /* renamed from: m */
    public int[] f1698m;

    public static class BaseBehavior<T extends AppBarLayout> extends z10<T> {

        /* renamed from: j */
        public int f1699j;

        /* renamed from: k */
        public int f1700k;

        /* renamed from: l */
        public ValueAnimator f1701l;

        /* renamed from: m */
        public int f1702m = -1;

        /* renamed from: n */
        public boolean f1703n;

        /* renamed from: o */
        public float f1704o;

        /* renamed from: p */
        public WeakReference<View> f1705p;

        /* renamed from: com.google.android.material.appbar.AppBarLayout$BaseBehavior$a */
        public static class C0390a extends C0015a8 {
            public static final Parcelable.Creator<C0390a> CREATOR = new C0391a();

            /* renamed from: f */
            public int f1706f;

            /* renamed from: g */
            public float f1707g;

            /* renamed from: h */
            public boolean f1708h;

            /* renamed from: com.google.android.material.appbar.AppBarLayout$BaseBehavior$a$a */
            public static class C0391a implements Parcelable.ClassLoaderCreator<C0390a> {
                public Object createFromParcel(Parcel parcel) {
                    return new C0390a(parcel, (ClassLoader) null);
                }

                public Object[] newArray(int i) {
                    return new C0390a[i];
                }

                public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return new C0390a(parcel, classLoader);
                }
            }

            public C0390a(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                this.f1706f = parcel.readInt();
                this.f1707g = parcel.readFloat();
                this.f1708h = parcel.readByte() != 0;
            }

            public C0390a(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeParcelable(this.f43d, i);
                parcel.writeInt(this.f1706f);
                parcel.writeFloat(this.f1707g);
                parcel.writeByte(this.f1708h ? (byte) 1 : 0);
            }
        }

        public BaseBehavior() {
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: j */
        public static boolean m1471j(int i, int i2) {
            return (i & i2) == i2;
        }

        /* renamed from: d */
        public boolean mo2064d(View view) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            WeakReference<View> weakReference = this.f1705p;
            if (weakReference == null) {
                return true;
            }
            View view2 = (View) weakReference.get();
            return view2 != null && view2.isShown() && !view2.canScrollVertically(-1);
        }

        /* renamed from: e */
        public int mo2065e() {
            return mo1571a() + this.f1699j;
        }

        /* JADX WARNING: Removed duplicated region for block: B:34:0x00a2  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x00a5  */
        /* renamed from: h */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo2066h(androidx.coordinatorlayout.widget.CoordinatorLayout r8, android.view.View r9, int r10, int r11, int r12) {
            /*
                r7 = this;
                r2 = r9
                com.google.android.material.appbar.AppBarLayout r2 = (com.google.android.material.appbar.AppBarLayout) r2
                int r9 = r7.mo2065e()
                r0 = 0
                if (r11 == 0) goto L_0x00af
                if (r9 < r11) goto L_0x00af
                if (r9 > r12) goto L_0x00af
                int r3 = p000.C1401p4.m4362g(r10, r11, r12)
                if (r9 == r3) goto L_0x00b1
                boolean r10 = r2.f1692g
                if (r10 == 0) goto L_0x0089
                int r10 = java.lang.Math.abs(r3)
                int r11 = r2.getChildCount()
                r12 = 0
            L_0x0021:
                if (r12 >= r11) goto L_0x0089
                android.view.View r1 = r2.getChildAt(r12)
                android.view.ViewGroup$LayoutParams r4 = r1.getLayoutParams()
                com.google.android.material.appbar.AppBarLayout$b r4 = (com.google.android.material.appbar.AppBarLayout.C0393b) r4
                android.view.animation.Interpolator r5 = r4.f1711b
                int r6 = r1.getTop()
                if (r10 < r6) goto L_0x0086
                int r6 = r1.getBottom()
                if (r10 > r6) goto L_0x0086
                if (r5 == 0) goto L_0x0089
                int r11 = r4.f1710a
                r12 = r11 & 1
                if (r12 == 0) goto L_0x0059
                int r12 = r1.getHeight()
                int r6 = r4.topMargin
                int r12 = r12 + r6
                int r4 = r4.bottomMargin
                int r12 = r12 + r4
                int r0 = r0 + r12
                r11 = r11 & 2
                if (r11 == 0) goto L_0x0059
                java.util.WeakHashMap<android.view.View, java.lang.String> r11 = p000.C0010a7.f28a
                int r11 = r1.getMinimumHeight()
                int r0 = r0 - r11
            L_0x0059:
                java.util.WeakHashMap<android.view.View, java.lang.String> r11 = p000.C0010a7.f28a
                boolean r11 = r1.getFitsSystemWindows()
                if (r11 == 0) goto L_0x0066
                int r11 = r2.getTopInset()
                int r0 = r0 - r11
            L_0x0066:
                if (r0 <= 0) goto L_0x0089
                int r11 = r1.getTop()
                int r10 = r10 - r11
                float r11 = (float) r0
                float r10 = (float) r10
                float r10 = r10 / r11
                float r10 = r5.getInterpolation(r10)
                float r10 = r10 * r11
                int r10 = java.lang.Math.round(r10)
                int r11 = java.lang.Integer.signum(r3)
                int r12 = r1.getTop()
                int r12 = r12 + r10
                int r12 = r12 * r11
                goto L_0x008a
            L_0x0086:
                int r12 = r12 + 1
                goto L_0x0021
            L_0x0089:
                r12 = r3
            L_0x008a:
                boolean r10 = r7.mo1572c(r12)
                int r11 = r9 - r3
                int r12 = r3 - r12
                r7.f1699j = r12
                if (r10 != 0) goto L_0x009d
                boolean r10 = r2.f1692g
                if (r10 == 0) goto L_0x009d
                r8.mo602c(r2)
            L_0x009d:
                r7.mo1571a()
                if (r3 >= r9) goto L_0x00a5
                r9 = -1
                r4 = -1
                goto L_0x00a7
            L_0x00a5:
                r9 = 1
                r4 = 1
            L_0x00a7:
                r5 = 0
                r0 = r7
                r1 = r8
                r0.mo2073p(r1, r2, r3, r4, r5)
                r0 = r11
                goto L_0x00b1
            L_0x00af:
                r7.f1699j = r0
            L_0x00b1:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo2066h(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, int, int, int):int");
        }

        /* renamed from: i */
        public final void mo2067i(CoordinatorLayout coordinatorLayout, T t, int i, float f) {
            int abs = Math.abs(mo2065e() - i);
            float abs2 = Math.abs(f);
            int round = abs2 > 0.0f ? Math.round((((float) abs) / abs2) * 1000.0f) * 3 : (int) (((((float) abs) / ((float) t.getHeight())) + 1.0f) * 150.0f);
            int e = mo2065e();
            if (e == i) {
                ValueAnimator valueAnimator = this.f1701l;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.f1701l.cancel();
                    return;
                }
                return;
            }
            ValueAnimator valueAnimator2 = this.f1701l;
            if (valueAnimator2 == null) {
                ValueAnimator valueAnimator3 = new ValueAnimator();
                this.f1701l = valueAnimator3;
                valueAnimator3.setInterpolator(p10.f4737e);
                this.f1701l.addUpdateListener(new y10(this, coordinatorLayout, t));
            } else {
                valueAnimator2.cancel();
            }
            this.f1701l.setDuration((long) Math.min(round, 600));
            this.f1701l.setIntValues(new int[]{e, i});
            this.f1701l.start();
        }

        /* renamed from: k */
        public void mo2068k(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int[] iArr, int i2) {
            int i3;
            int i4;
            if (i != 0) {
                if (i < 0) {
                    int i5 = -appBarLayout.getTotalScrollRange();
                    i4 = i5;
                    i3 = appBarLayout.getDownNestedPreScrollRange() + i5;
                } else {
                    i4 = -appBarLayout.getUpNestedPreScrollRange();
                    i3 = 0;
                }
                if (i4 != i3) {
                    iArr[1] = mo6731f(coordinatorLayout, appBarLayout, i, i4, i3);
                    mo2072o(i, appBarLayout, view, i2);
                }
            }
        }

        /* renamed from: l */
        public void mo2069l(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int i2) {
            if (i < 0) {
                mo6731f(coordinatorLayout, appBarLayout, i, -appBarLayout.getDownNestedScrollRange(), 0);
                mo2072o(i, appBarLayout, view, i2);
            }
            if (appBarLayout.f1697l) {
                appBarLayout.mo2045d(view.getScrollY() > 0);
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
            if (((r4.getTotalScrollRange() != 0) && r3.getHeight() - r5.getHeight() <= r4.getHeight()) != false) goto L_0x002b;
         */
        /* renamed from: m */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo2070m(androidx.coordinatorlayout.widget.CoordinatorLayout r3, com.google.android.material.appbar.AppBarLayout r4, android.view.View r5, int r6, int r7) {
            /*
                r2 = this;
                r6 = r6 & 2
                r0 = 1
                r1 = 0
                if (r6 == 0) goto L_0x002a
                boolean r6 = r4.f1697l
                if (r6 != 0) goto L_0x002b
                int r6 = r4.getTotalScrollRange()
                if (r6 == 0) goto L_0x0012
                r6 = 1
                goto L_0x0013
            L_0x0012:
                r6 = 0
            L_0x0013:
                if (r6 == 0) goto L_0x0026
                int r3 = r3.getHeight()
                int r5 = r5.getHeight()
                int r3 = r3 - r5
                int r4 = r4.getHeight()
                if (r3 > r4) goto L_0x0026
                r3 = 1
                goto L_0x0027
            L_0x0026:
                r3 = 0
            L_0x0027:
                if (r3 == 0) goto L_0x002a
                goto L_0x002b
            L_0x002a:
                r0 = 0
            L_0x002b:
                if (r0 == 0) goto L_0x0034
                android.animation.ValueAnimator r3 = r2.f1701l
                if (r3 == 0) goto L_0x0034
                r3.cancel()
            L_0x0034:
                r3 = 0
                r2.f1705p = r3
                r2.f1700k = r7
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo2070m(androidx.coordinatorlayout.widget.CoordinatorLayout, com.google.android.material.appbar.AppBarLayout, android.view.View, int, int):boolean");
        }

        /* renamed from: n */
        public final void mo2071n(CoordinatorLayout coordinatorLayout, T t) {
            int e = mo2065e();
            int childCount = t.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    i = -1;
                    break;
                }
                View childAt = t.getChildAt(i);
                int top = childAt.getTop();
                int bottom = childAt.getBottom();
                C0393b bVar = (C0393b) childAt.getLayoutParams();
                if (m1471j(bVar.f1710a, 32)) {
                    top -= bVar.topMargin;
                    bottom += bVar.bottomMargin;
                }
                int i2 = -e;
                if (top <= i2 && bottom >= i2) {
                    break;
                }
                i++;
            }
            if (i >= 0) {
                View childAt2 = t.getChildAt(i);
                C0393b bVar2 = (C0393b) childAt2.getLayoutParams();
                int i3 = bVar2.f1710a;
                if ((i3 & 17) == 17) {
                    int i4 = -childAt2.getTop();
                    int i5 = -childAt2.getBottom();
                    if (i == t.getChildCount() - 1) {
                        i5 += t.getTopInset();
                    }
                    if (m1471j(i3, 2)) {
                        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                        i5 += childAt2.getMinimumHeight();
                    } else if (m1471j(i3, 5)) {
                        WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                        int minimumHeight = childAt2.getMinimumHeight() + i5;
                        if (e < minimumHeight) {
                            i4 = minimumHeight;
                        } else {
                            i5 = minimumHeight;
                        }
                    }
                    if (m1471j(i3, 32)) {
                        i4 += bVar2.topMargin;
                        i5 -= bVar2.bottomMargin;
                    }
                    if (e < (i5 + i4) / 2) {
                        i4 = i5;
                    }
                    mo2067i(coordinatorLayout, t, C1401p4.m4362g(i4, -t.getTotalScrollRange(), 0), 0.0f);
                }
            }
        }

        /* renamed from: o */
        public final void mo2072o(int i, T t, View view, int i2) {
            if (i2 == 1) {
                int e = mo2065e();
                if ((i < 0 && e == 0) || (i > 0 && e == (-t.getDownNestedScrollRange()))) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    if (view instanceof C1486q6) {
                        ((C1486q6) view).mo704a(1);
                    }
                }
            }
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            super.onLayoutChild(coordinatorLayout, appBarLayout, i);
            int pendingAction = appBarLayout.getPendingAction();
            int i2 = this.f1702m;
            if (i2 >= 0 && (pendingAction & 8) == 0) {
                View childAt = appBarLayout.getChildAt(i2);
                int i3 = -childAt.getBottom();
                mo6732g(coordinatorLayout, appBarLayout, this.f1703n ? appBarLayout.getTopInset() + childAt.getMinimumHeight() + i3 : Math.round(((float) childAt.getHeight()) * this.f1704o) + i3);
            } else if (pendingAction != 0) {
                boolean z = (pendingAction & 4) != 0;
                if ((pendingAction & 2) != 0) {
                    int i4 = -appBarLayout.getUpNestedPreScrollRange();
                    if (z) {
                        mo2067i(coordinatorLayout, appBarLayout, i4, 0.0f);
                    } else {
                        mo6732g(coordinatorLayout, appBarLayout, i4);
                    }
                } else if ((pendingAction & 1) != 0) {
                    if (z) {
                        mo2067i(coordinatorLayout, appBarLayout, 0, 0.0f);
                    } else {
                        mo6732g(coordinatorLayout, appBarLayout, 0);
                    }
                }
            }
            appBarLayout.f1693h = 0;
            this.f1702m = -1;
            mo1572c(C1401p4.m4362g(mo1571a(), -appBarLayout.getTotalScrollRange(), 0));
            mo2073p(coordinatorLayout, appBarLayout, mo1571a(), 0, true);
            mo1571a();
            return true;
        }

        public boolean onMeasureChild(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (((CoordinatorLayout.C0123f) appBarLayout.getLayoutParams()).height != -2) {
                return super.onMeasureChild(coordinatorLayout, appBarLayout, i, i2, i3, i4);
            }
            coordinatorLayout.mo642t(appBarLayout, i, i2, View.MeasureSpec.makeMeasureSpec(0, 0), i4);
            return true;
        }

        public /* bridge */ /* synthetic */ void onNestedPreScroll(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int[] iArr, int i3) {
            mo2068k(coordinatorLayout, (AppBarLayout) view, view2, i2, iArr, i3);
        }

        public /* bridge */ /* synthetic */ void onNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int i3, int i4, int i5) {
            mo2069l(coordinatorLayout, (AppBarLayout) view, view2, i4, i5);
        }

        public void onRestoreInstanceState(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (parcelable instanceof C0390a) {
                C0390a aVar = (C0390a) parcelable;
                super.onRestoreInstanceState(coordinatorLayout, appBarLayout, aVar.f43d);
                this.f1702m = aVar.f1706f;
                this.f1704o = aVar.f1707g;
                this.f1703n = aVar.f1708h;
                return;
            }
            super.onRestoreInstanceState(coordinatorLayout, appBarLayout, parcelable);
            this.f1702m = -1;
        }

        public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, View view) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            Parcelable onSaveInstanceState = super.onSaveInstanceState(coordinatorLayout, appBarLayout);
            int a = mo1571a();
            int childCount = appBarLayout.getChildCount();
            boolean z = false;
            int i = 0;
            while (i < childCount) {
                View childAt = appBarLayout.getChildAt(i);
                int bottom = childAt.getBottom() + a;
                if (childAt.getTop() + a > 0 || bottom < 0) {
                    i++;
                } else {
                    C0390a aVar = new C0390a(onSaveInstanceState);
                    aVar.f1706f = i;
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    if (bottom == appBarLayout.getTopInset() + childAt.getMinimumHeight()) {
                        z = true;
                    }
                    aVar.f1708h = z;
                    aVar.f1707g = ((float) bottom) / ((float) childAt.getHeight());
                    return aVar;
                }
            }
            return onSaveInstanceState;
        }

        public /* bridge */ /* synthetic */ boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i, int i2) {
            return mo2070m(coordinatorLayout, (AppBarLayout) view, view2, i, i2);
        }

        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (this.f1700k == 0 || i == 1) {
                mo2071n(coordinatorLayout, appBarLayout);
            }
            this.f1705p = new WeakReference<>(view2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:26:0x0063  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x0088  */
        /* renamed from: p */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo2073p(androidx.coordinatorlayout.widget.CoordinatorLayout r8, T r9, int r10, int r11, boolean r12) {
            /*
                r7 = this;
                int r0 = java.lang.Math.abs(r10)
                int r1 = r9.getChildCount()
                r2 = 0
                r3 = 0
            L_0x000a:
                r4 = 0
                if (r3 >= r1) goto L_0x0021
                android.view.View r5 = r9.getChildAt(r3)
                int r6 = r5.getTop()
                if (r0 < r6) goto L_0x001e
                int r6 = r5.getBottom()
                if (r0 > r6) goto L_0x001e
                goto L_0x0022
            L_0x001e:
                int r3 = r3 + 1
                goto L_0x000a
            L_0x0021:
                r5 = r4
            L_0x0022:
                if (r5 == 0) goto L_0x00b7
                android.view.ViewGroup$LayoutParams r0 = r5.getLayoutParams()
                com.google.android.material.appbar.AppBarLayout$b r0 = (com.google.android.material.appbar.AppBarLayout.C0393b) r0
                int r0 = r0.f1710a
                r1 = r0 & 1
                r3 = 1
                if (r1 == 0) goto L_0x005e
                java.util.WeakHashMap<android.view.View, java.lang.String> r1 = p000.C0010a7.f28a
                int r1 = r5.getMinimumHeight()
                if (r11 <= 0) goto L_0x004b
                r11 = r0 & 12
                if (r11 == 0) goto L_0x004b
                int r10 = -r10
                int r11 = r5.getBottom()
                int r11 = r11 - r1
                int r0 = r9.getTopInset()
                int r11 = r11 - r0
                if (r10 < r11) goto L_0x005e
                goto L_0x005c
            L_0x004b:
                r11 = r0 & 2
                if (r11 == 0) goto L_0x005e
                int r10 = -r10
                int r11 = r5.getBottom()
                int r11 = r11 - r1
                int r0 = r9.getTopInset()
                int r11 = r11 - r0
                if (r10 < r11) goto L_0x005e
            L_0x005c:
                r10 = 1
                goto L_0x005f
            L_0x005e:
                r10 = 0
            L_0x005f:
                boolean r11 = r9.f1697l
                if (r11 == 0) goto L_0x0082
                int r11 = r8.getChildCount()
                r0 = 0
            L_0x0068:
                if (r0 >= r11) goto L_0x0077
                android.view.View r1 = r8.getChildAt(r0)
                boolean r5 = r1 instanceof p000.C1659r6
                if (r5 == 0) goto L_0x0074
                r4 = r1
                goto L_0x0077
            L_0x0074:
                int r0 = r0 + 1
                goto L_0x0068
            L_0x0077:
                if (r4 == 0) goto L_0x0082
                int r10 = r4.getScrollY()
                if (r10 <= 0) goto L_0x0081
                r10 = 1
                goto L_0x0082
            L_0x0081:
                r10 = 0
            L_0x0082:
                boolean r10 = r9.mo2045d(r10)
                if (r12 != 0) goto L_0x00b4
                if (r10 == 0) goto L_0x00b7
                java.util.List r8 = r8.mo608f(r9)
                int r10 = r8.size()
                r11 = 0
            L_0x0093:
                if (r11 >= r10) goto L_0x00b2
                java.lang.Object r12 = r8.get(r11)
                android.view.View r12 = (android.view.View) r12
                android.view.ViewGroup$LayoutParams r12 = r12.getLayoutParams()
                androidx.coordinatorlayout.widget.CoordinatorLayout$f r12 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0123f) r12
                androidx.coordinatorlayout.widget.CoordinatorLayout$c r12 = r12.f574a
                boolean r0 = r12 instanceof com.google.android.material.appbar.AppBarLayout.ScrollingViewBehavior
                if (r0 == 0) goto L_0x00af
                com.google.android.material.appbar.AppBarLayout$ScrollingViewBehavior r12 = (com.google.android.material.appbar.AppBarLayout.ScrollingViewBehavior) r12
                int r8 = r12.f14f
                if (r8 == 0) goto L_0x00b2
                r2 = 1
                goto L_0x00b2
            L_0x00af:
                int r11 = r11 + 1
                goto L_0x0093
            L_0x00b2:
                if (r2 == 0) goto L_0x00b7
            L_0x00b4:
                r9.jumpDrawablesToCurrentState()
            L_0x00b7:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo2073p(androidx.coordinatorlayout.widget.CoordinatorLayout, com.google.android.material.appbar.AppBarLayout, int, int, boolean):void");
        }
    }

    public static class Behavior extends BaseBehavior<AppBarLayout> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public static class ScrollingViewBehavior extends a20 {
        public ScrollingViewBehavior() {
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o10.f4414h);
            this.f14f = obtainStyledAttributes.getDimensionPixelSize(0, 0);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: e */
        public AppBarLayout mo2077e(List<View> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = list.get(i);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 instanceof AppBarLayout;
        }

        public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, View view, View view2) {
            CoordinatorLayout.C0120c cVar = ((CoordinatorLayout.C0123f) view2.getLayoutParams()).f574a;
            if (cVar instanceof BaseBehavior) {
                C0010a7.m39l(view, (((view2.getBottom() - view.getTop()) + ((BaseBehavior) cVar).f1699j) + this.f13e) - mo21d(view2));
            }
            if (view2 instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view2;
                if (appBarLayout.f1697l) {
                    appBarLayout.mo2045d(view.getScrollY() > 0);
                }
            }
            return false;
        }

        public boolean onRequestChildRectangleOnScreen(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z) {
            AppBarLayout e = mo2077e(coordinatorLayout.mo607e(view));
            if (e != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = this.f11c;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    e.mo2043c(false, !z, true);
                    return true;
                }
            }
            return false;
        }
    }

    /* renamed from: com.google.android.material.appbar.AppBarLayout$a */
    public class C0392a implements C2052x6 {
        public C0392a() {
        }

        /* renamed from: a */
        public C0943j7 mo650a(View view, C0943j7 j7Var) {
            AppBarLayout appBarLayout = AppBarLayout.this;
            Objects.requireNonNull(appBarLayout);
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            C0943j7 j7Var2 = appBarLayout.getFitsSystemWindows() ? j7Var : null;
            if (!Objects.equals(appBarLayout.f1694i, j7Var2)) {
                appBarLayout.f1694i = j7Var2;
                appBarLayout.mo2042b();
            }
            return j7Var;
        }
    }

    /* renamed from: com.google.android.material.appbar.AppBarLayout$b */
    public static class C0393b extends LinearLayout.LayoutParams {

        /* renamed from: a */
        public int f1710a = 1;

        /* renamed from: b */
        public Interpolator f1711b;

        public C0393b(int i, int i2) {
            super(i, i2);
        }

        public C0393b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o10.f4408b);
            this.f1710a = obtainStyledAttributes.getInt(0, 0);
            if (obtainStyledAttributes.hasValue(1)) {
                this.f1711b = AnimationUtils.loadInterpolator(context, obtainStyledAttributes.getResourceId(1, 0));
            }
            obtainStyledAttributes.recycle();
        }

        public C0393b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0393b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0393b(LinearLayout.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public AppBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOrientation(1);
        int i = Build.VERSION.SDK_INT;
        if (i >= 21) {
            setOutlineProvider(ViewOutlineProvider.BOUNDS);
            Context context2 = getContext();
            TypedArray d = f30.m2146d(context2, attributeSet, d20.f2137a, 0, C0446R.style.Widget_Design_AppBarLayout, new int[0]);
            try {
                if (d.hasValue(0)) {
                    setStateListAnimator(AnimatorInflater.loadStateListAnimator(context2, d.getResourceId(0, 0)));
                }
            } finally {
                d.recycle();
            }
        }
        int[] iArr = o10.f4407a;
        f30.m2143a(context, attributeSet, 0, C0446R.style.Widget_Design_AppBarLayout);
        f30.m2144b(context, attributeSet, iArr, 0, C0446R.style.Widget_Design_AppBarLayout, new int[0]);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, C0446R.style.Widget_Design_AppBarLayout);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        setBackground(drawable);
        if (obtainStyledAttributes.hasValue(4)) {
            mo2043c(obtainStyledAttributes.getBoolean(4, false), false, false);
        }
        if (i >= 21 && obtainStyledAttributes.hasValue(3)) {
            d20.m1685a(this, (float) obtainStyledAttributes.getDimensionPixelSize(3, 0));
        }
        if (i >= 26) {
            if (obtainStyledAttributes.hasValue(2)) {
                setKeyboardNavigationCluster(obtainStyledAttributes.getBoolean(2, false));
            }
            if (obtainStyledAttributes.hasValue(1)) {
                setTouchscreenBlocksFocus(obtainStyledAttributes.getBoolean(1, false));
            }
        }
        this.f1697l = obtainStyledAttributes.getBoolean(5, false);
        obtainStyledAttributes.recycle();
        C0010a7.m45r(this, new C0392a());
    }

    /* renamed from: a */
    public C0393b generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LinearLayout.LayoutParams ? new C0393b((LinearLayout.LayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0393b((ViewGroup.MarginLayoutParams) layoutParams) : new C0393b(layoutParams);
    }

    /* renamed from: b */
    public final void mo2042b() {
        this.f1689d = -1;
        this.f1690e = -1;
        this.f1691f = -1;
    }

    /* renamed from: c */
    public final void mo2043c(boolean z, boolean z2, boolean z3) {
        int i = 0;
        int i2 = (z ? 1 : 2) | (z2 ? 4 : 0);
        if (z3) {
            i = 8;
        }
        this.f1693h = i2 | i;
        requestLayout();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0393b;
    }

    /* renamed from: d */
    public boolean mo2045d(boolean z) {
        if (this.f1696k == z) {
            return false;
        }
        this.f1696k = z;
        refreshDrawableState();
        return true;
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0393b(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0393b(getContext(), attributeSet);
    }

    public int getDownNestedPreScrollRange() {
        int i;
        int i2 = this.f1690e;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            C0393b bVar = (C0393b) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = bVar.f1710a;
            if ((i4 & 5) == 5) {
                int i5 = bVar.topMargin + bVar.bottomMargin + i3;
                if ((i4 & 8) != 0) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    i3 = childAt.getMinimumHeight() + i5;
                } else {
                    if ((i4 & 2) != 0) {
                        WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                        i = childAt.getMinimumHeight();
                    } else {
                        i = getTopInset();
                    }
                    i3 = (measuredHeight - i) + i5;
                }
            } else if (i3 > 0) {
                break;
            }
        }
        int max = Math.max(0, i3);
        this.f1690e = max;
        return max;
    }

    public int getDownNestedScrollRange() {
        int i = this.f1691f;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0393b bVar = (C0393b) childAt.getLayoutParams();
            int measuredHeight = bVar.topMargin + bVar.bottomMargin + childAt.getMeasuredHeight();
            int i4 = bVar.f1710a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight;
            if ((i4 & 2) != 0) {
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                i3 -= getTopInset() + childAt.getMinimumHeight();
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3);
        this.f1691f = max;
        return max;
    }

    public final int getMinimumHeightForVisibleOverlappingContent() {
        int topInset = getTopInset();
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int minimumHeight = getMinimumHeight();
        if (minimumHeight == 0) {
            int childCount = getChildCount();
            minimumHeight = childCount >= 1 ? getChildAt(childCount - 1).getMinimumHeight() : 0;
            if (minimumHeight == 0) {
                return getHeight() / 3;
            }
        }
        return (minimumHeight * 2) + topInset;
    }

    public int getPendingAction() {
        return this.f1693h;
    }

    @Deprecated
    public float getTargetElevation() {
        return 0.0f;
    }

    public final int getTopInset() {
        C0943j7 j7Var = this.f1694i;
        if (j7Var != null) {
            return j7Var.mo4128d();
        }
        return 0;
    }

    public final int getTotalScrollRange() {
        int i = this.f1689d;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0393b bVar = (C0393b) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = bVar.f1710a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight + bVar.topMargin + bVar.bottomMargin;
            if ((i4 & 2) != 0) {
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                i3 -= childAt.getMinimumHeight();
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3 - getTopInset());
        this.f1689d = max;
        return max;
    }

    public int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    public int[] onCreateDrawableState(int i) {
        if (this.f1698m == null) {
            this.f1698m = new int[4];
        }
        int[] iArr = this.f1698m;
        int[] onCreateDrawableState = super.onCreateDrawableState(i + iArr.length);
        boolean z = this.f1695j;
        iArr[0] = z ? R.attr.state_liftable : -2130903560;
        iArr[1] = (!z || !this.f1696k) ? -2130903561 : R.attr.state_lifted;
        iArr[2] = z ? R.attr.state_collapsible : -2130903559;
        iArr[3] = (!z || !this.f1696k) ? -2130903558 : R.attr.state_collapsed;
        return LinearLayout.mergeDrawableStates(onCreateDrawableState, iArr);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004f, code lost:
        if (r3 != false) goto L_0x0051;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r2, int r3, int r4, int r5, int r6) {
        /*
            r1 = this;
            super.onLayout(r2, r3, r4, r5, r6)
            r1.mo2042b()
            r2 = 0
            r1.f1692g = r2
            int r3 = r1.getChildCount()
            r4 = 0
        L_0x000e:
            r5 = 1
            if (r4 >= r3) goto L_0x0025
            android.view.View r6 = r1.getChildAt(r4)
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            com.google.android.material.appbar.AppBarLayout$b r6 = (com.google.android.material.appbar.AppBarLayout.C0393b) r6
            android.view.animation.Interpolator r6 = r6.f1711b
            if (r6 == 0) goto L_0x0022
            r1.f1692g = r5
            goto L_0x0025
        L_0x0022:
            int r4 = r4 + 1
            goto L_0x000e
        L_0x0025:
            boolean r3 = r1.f1697l
            if (r3 != 0) goto L_0x0051
            int r3 = r1.getChildCount()
            r4 = 0
        L_0x002e:
            if (r4 >= r3) goto L_0x004e
            android.view.View r6 = r1.getChildAt(r4)
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            com.google.android.material.appbar.AppBarLayout$b r6 = (com.google.android.material.appbar.AppBarLayout.C0393b) r6
            int r6 = r6.f1710a
            r0 = r6 & 1
            if (r0 != r5) goto L_0x0046
            r6 = r6 & 10
            if (r6 == 0) goto L_0x0046
            r6 = 1
            goto L_0x0047
        L_0x0046:
            r6 = 0
        L_0x0047:
            if (r6 == 0) goto L_0x004b
            r3 = 1
            goto L_0x004f
        L_0x004b:
            int r4 = r4 + 1
            goto L_0x002e
        L_0x004e:
            r3 = 0
        L_0x004f:
            if (r3 == 0) goto L_0x0052
        L_0x0051:
            r2 = 1
        L_0x0052:
            boolean r3 = r1.f1695j
            if (r3 == r2) goto L_0x005b
            r1.f1695j = r2
            r1.refreshDrawableState()
        L_0x005b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        mo2042b();
    }

    public void setExpanded(boolean z) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        mo2043c(z, isLaidOut(), true);
    }

    public void setLiftOnScroll(boolean z) {
        this.f1697l = z;
    }

    public void setOrientation(int i) {
        if (i == 1) {
            super.setOrientation(i);
            return;
        }
        throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
    }

    @Deprecated
    public void setTargetElevation(float f) {
        if (Build.VERSION.SDK_INT >= 21) {
            d20.m1685a(this, f);
        }
    }

    /* renamed from: generateDefaultLayoutParams  reason: collision with other method in class */
    public LinearLayout.LayoutParams m6073generateDefaultLayoutParams() {
        return new C0393b(-1, -2);
    }

    /* renamed from: generateLayoutParams  reason: collision with other method in class */
    public LinearLayout.LayoutParams m6074generateLayoutParams(AttributeSet attributeSet) {
        return new C0393b(getContext(), attributeSet);
    }
}
