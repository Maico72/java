package com.google.android.material.textfield;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.internal.CheckableImageButton;
import com.roughike.bottombar.C0446R;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

public class TextInputLayout extends LinearLayout {

    /* renamed from: A */
    public final int f1816A;

    /* renamed from: B */
    public final int f1817B;

    /* renamed from: C */
    public int f1818C;

    /* renamed from: D */
    public int f1819D;

    /* renamed from: E */
    public Drawable f1820E;

    /* renamed from: F */
    public final Rect f1821F = new Rect();

    /* renamed from: G */
    public final RectF f1822G = new RectF();

    /* renamed from: H */
    public Typeface f1823H;

    /* renamed from: I */
    public boolean f1824I;

    /* renamed from: J */
    public Drawable f1825J;

    /* renamed from: K */
    public CharSequence f1826K;

    /* renamed from: L */
    public CheckableImageButton f1827L;

    /* renamed from: M */
    public boolean f1828M;

    /* renamed from: N */
    public Drawable f1829N;

    /* renamed from: O */
    public Drawable f1830O;

    /* renamed from: P */
    public ColorStateList f1831P;

    /* renamed from: Q */
    public boolean f1832Q;

    /* renamed from: R */
    public PorterDuff.Mode f1833R;

    /* renamed from: S */
    public boolean f1834S;

    /* renamed from: T */
    public ColorStateList f1835T;

    /* renamed from: U */
    public ColorStateList f1836U;

    /* renamed from: V */
    public final int f1837V;

    /* renamed from: W */
    public final int f1838W;

    /* renamed from: a0 */
    public int f1839a0;

    /* renamed from: b0 */
    public final int f1840b0;

    /* renamed from: c0 */
    public boolean f1841c0;

    /* renamed from: d */
    public final FrameLayout f1842d;

    /* renamed from: d0 */
    public final b30 f1843d0;

    /* renamed from: e */
    public EditText f1844e;

    /* renamed from: e0 */
    public boolean f1845e0;

    /* renamed from: f */
    public CharSequence f1846f;

    /* renamed from: f0 */
    public ValueAnimator f1847f0;

    /* renamed from: g */
    public final r30 f1848g = new r30(this);

    /* renamed from: g0 */
    public boolean f1849g0;

    /* renamed from: h */
    public boolean f1850h;

    /* renamed from: h0 */
    public boolean f1851h0;

    /* renamed from: i */
    public int f1852i;

    /* renamed from: i0 */
    public boolean f1853i0;

    /* renamed from: j */
    public boolean f1854j;

    /* renamed from: k */
    public TextView f1855k;

    /* renamed from: l */
    public final int f1856l;

    /* renamed from: m */
    public final int f1857m;

    /* renamed from: n */
    public boolean f1858n;

    /* renamed from: o */
    public CharSequence f1859o;

    /* renamed from: p */
    public boolean f1860p;

    /* renamed from: q */
    public GradientDrawable f1861q;

    /* renamed from: r */
    public final int f1862r;

    /* renamed from: s */
    public final int f1863s;

    /* renamed from: t */
    public int f1864t;

    /* renamed from: u */
    public final int f1865u;

    /* renamed from: v */
    public float f1866v;

    /* renamed from: w */
    public float f1867w;

    /* renamed from: x */
    public float f1868x;

    /* renamed from: y */
    public float f1869y;

    /* renamed from: z */
    public int f1870z;

    /* renamed from: com.google.android.material.textfield.TextInputLayout$a */
    public class C0407a implements TextWatcher {
        public C0407a() {
        }

        public void afterTextChanged(Editable editable) {
            TextInputLayout textInputLayout = TextInputLayout.this;
            textInputLayout.mo2285o(!textInputLayout.f1853i0, false);
            TextInputLayout textInputLayout2 = TextInputLayout.this;
            if (textInputLayout2.f1850h) {
                textInputLayout2.mo2282l(editable.length());
            }
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$b */
    public class C0408b implements View.OnClickListener {
        public C0408b() {
        }

        public void onClick(View view) {
            TextInputLayout.this.mo2280i(false);
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$c */
    public class C0409c implements ValueAnimator.AnimatorUpdateListener {
        public C0409c() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TextInputLayout.this.f1843d0.mo1583m(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$d */
    public static class C0410d extends C1163m6 {

        /* renamed from: d */
        public final TextInputLayout f1874d;

        public C0410d(TextInputLayout textInputLayout) {
            this.f1874d = textInputLayout;
        }

        /* renamed from: d */
        public void mo773d(View view, C1226n7 n7Var) {
            int i = Build.VERSION.SDK_INT;
            this.f4001a.onInitializeAccessibilityNodeInfo(view, n7Var.f4196a);
            EditText editText = this.f1874d.getEditText();
            Editable text = editText != null ? editText.getText() : null;
            CharSequence hint = this.f1874d.getHint();
            CharSequence error = this.f1874d.getError();
            CharSequence counterOverflowDescription = this.f1874d.getCounterOverflowDescription();
            boolean z = !TextUtils.isEmpty(text);
            boolean z2 = !TextUtils.isEmpty(hint);
            boolean z3 = !TextUtils.isEmpty(error);
            boolean z4 = false;
            boolean z5 = z3 || !TextUtils.isEmpty(counterOverflowDescription);
            if (z) {
                n7Var.f4196a.setText(text);
            } else if (z2) {
                n7Var.f4196a.setText(hint);
            }
            if (z2) {
                AccessibilityNodeInfo accessibilityNodeInfo = n7Var.f4196a;
                if (i >= 26) {
                    accessibilityNodeInfo.setHintText(hint);
                } else {
                    accessibilityNodeInfo.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.HINT_TEXT_KEY", hint);
                }
                if (!z && z2) {
                    z4 = true;
                }
                if (i >= 26) {
                    n7Var.f4196a.setShowingHintText(z4);
                } else {
                    n7Var.mo4736f(4, z4);
                }
            }
            if (z5) {
                if (!z3) {
                    error = counterOverflowDescription;
                }
                if (i >= 21) {
                    n7Var.f4196a.setError(error);
                }
                n7Var.f4196a.setContentInvalid(true);
            }
        }

        /* renamed from: e */
        public void mo2327e(View view, AccessibilityEvent accessibilityEvent) {
            this.f4001a.onPopulateAccessibilityEvent(view, accessibilityEvent);
            EditText editText = this.f1874d.getEditText();
            CharSequence text = editText != null ? editText.getText() : null;
            if (TextUtils.isEmpty(text)) {
                text = this.f1874d.getHint();
            }
            if (!TextUtils.isEmpty(text)) {
                accessibilityEvent.getText().add(text);
            }
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$e */
    public static class C0411e extends C0015a8 {
        public static final Parcelable.Creator<C0411e> CREATOR = new C0412a();

        /* renamed from: f */
        public CharSequence f1875f;

        /* renamed from: g */
        public boolean f1876g;

        /* renamed from: com.google.android.material.textfield.TextInputLayout$e$a */
        public static class C0412a implements Parcelable.ClassLoaderCreator<C0411e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0411e(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0411e[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0411e(parcel, classLoader);
            }
        }

        public C0411e(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1875f = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f1876g = parcel.readInt() != 1 ? false : true;
        }

        public C0411e(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder d = C1012kd.m3195d("TextInputLayout.SavedState{");
            d.append(Integer.toHexString(System.identityHashCode(this)));
            d.append(" error=");
            d.append(this.f1875f);
            d.append("}");
            return d.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            TextUtils.writeToParcel(this.f1875f, parcel, i);
            parcel.writeInt(this.f1876g ? 1 : 0);
        }
    }

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.textInputStyle);
        b30 b30 = new b30(this);
        this.f1843d0 = b30;
        setOrientation(1);
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        FrameLayout frameLayout = new FrameLayout(context);
        this.f1842d = frameLayout;
        frameLayout.setAddStatesFromChildren(true);
        addView(frameLayout);
        TimeInterpolator timeInterpolator = p10.f4733a;
        b30.f1217G = timeInterpolator;
        b30.mo1581j();
        b30.f1216F = timeInterpolator;
        b30.mo1581j();
        if (b30.f1229h != 8388659) {
            b30.f1229h = 8388659;
            b30.mo1581j();
        }
        int[] iArr = o10.f4416j;
        f30.m2143a(context, attributeSet, R.attr.textInputStyle, C0446R.style.Widget_Design_TextInputLayout);
        f30.m2144b(context, attributeSet, iArr, R.attr.textInputStyle, C0446R.style.Widget_Design_TextInputLayout, new int[0]);
        C0327c3 c3Var = new C0327c3(context, context.obtainStyledAttributes(attributeSet, iArr, R.attr.textInputStyle, C0446R.style.Widget_Design_TextInputLayout));
        this.f1858n = c3Var.mo1824a(21, true);
        setHint(c3Var.mo1838o(1));
        this.f1845e0 = c3Var.mo1824a(20, true);
        this.f1862r = context.getResources().getDimensionPixelOffset(R.dimen.mtrl_textinput_box_bottom_offset);
        this.f1863s = context.getResources().getDimensionPixelOffset(R.dimen.mtrl_textinput_box_label_cutout_padding);
        this.f1865u = c3Var.mo1828e(4, 0);
        this.f1866v = c3Var.mo1827d(8, 0.0f);
        this.f1867w = c3Var.mo1827d(7, 0.0f);
        this.f1868x = c3Var.mo1827d(5, 0.0f);
        this.f1869y = c3Var.mo1827d(6, 0.0f);
        this.f1819D = c3Var.mo1825b(2, 0);
        this.f1839a0 = c3Var.mo1825b(9, 0);
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(R.dimen.mtrl_textinput_box_stroke_width_default);
        this.f1816A = dimensionPixelSize;
        this.f1817B = context.getResources().getDimensionPixelSize(R.dimen.mtrl_textinput_box_stroke_width_focused);
        this.f1870z = dimensionPixelSize;
        setBoxBackgroundMode(c3Var.mo1834k(3, 0));
        if (c3Var.mo1839p(0)) {
            ColorStateList c = c3Var.mo1826c(0);
            this.f1836U = c;
            this.f1835T = c;
        }
        this.f1837V = C1901v4.m5333b(context, R.color.mtrl_textinput_default_box_stroke_color);
        this.f1840b0 = C1901v4.m5333b(context, R.color.mtrl_textinput_disabled_color);
        this.f1838W = C1901v4.m5333b(context, R.color.mtrl_textinput_hovered_box_stroke_color);
        if (c3Var.mo1836m(22, -1) != -1) {
            setHintTextAppearance(c3Var.mo1836m(22, 0));
        }
        int m = c3Var.mo1836m(16, 0);
        boolean a = c3Var.mo1824a(15, false);
        int m2 = c3Var.mo1836m(19, 0);
        boolean a2 = c3Var.mo1824a(18, false);
        CharSequence o = c3Var.mo1838o(17);
        boolean a3 = c3Var.mo1824a(11, false);
        setCounterMaxLength(c3Var.mo1834k(12, -1));
        this.f1857m = c3Var.mo1836m(14, 0);
        this.f1856l = c3Var.mo1836m(13, 0);
        this.f1824I = c3Var.mo1824a(25, false);
        this.f1825J = c3Var.mo1830g(24);
        this.f1826K = c3Var.mo1838o(23);
        if (c3Var.mo1839p(26)) {
            this.f1832Q = true;
            this.f1831P = c3Var.mo1826c(26);
        }
        if (c3Var.mo1839p(27)) {
            this.f1834S = true;
            this.f1833R = n10.m3822r(c3Var.mo1834k(27, -1), (PorterDuff.Mode) null);
        }
        c3Var.f1430b.recycle();
        setHelperTextEnabled(a2);
        setHelperText(o);
        setHelperTextTextAppearance(m2);
        setErrorEnabled(a);
        setErrorTextAppearance(m);
        setCounterEnabled(a3);
        mo2249c();
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        setImportantForAccessibility(2);
    }

    private Drawable getBoxBackground() {
        int i = this.f1864t;
        if (i == 1 || i == 2) {
            return this.f1861q;
        }
        throw new IllegalStateException();
    }

    private float[] getCornerRadiiAsArray() {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (!(getLayoutDirection() == 1)) {
            float f = this.f1866v;
            float f2 = this.f1867w;
            float f3 = this.f1868x;
            float f4 = this.f1869y;
            return new float[]{f, f, f2, f2, f3, f3, f4, f4};
        }
        float f5 = this.f1867w;
        float f6 = this.f1866v;
        float f7 = this.f1869y;
        float f8 = this.f1868x;
        return new float[]{f5, f5, f6, f6, f7, f7, f8, f8};
    }

    /* renamed from: j */
    public static void m1546j(ViewGroup viewGroup, boolean z) {
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            childAt.setEnabled(z);
            if (childAt instanceof ViewGroup) {
                m1546j((ViewGroup) childAt, z);
            }
        }
    }

    private void setEditText(EditText editText) {
        if (this.f1844e == null) {
            if (!(editText instanceof TextInputEditText)) {
                Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
            }
            this.f1844e = editText;
            mo2257g();
            setTextInputAccessibilityDelegate(new C0410d(this));
            if (!mo2256f()) {
                b30 b30 = this.f1843d0;
                Typeface typeface = this.f1844e.getTypeface();
                b30.f1241t = typeface;
                b30.f1240s = typeface;
                b30.mo1581j();
            }
            b30 b302 = this.f1843d0;
            float textSize = this.f1844e.getTextSize();
            if (b302.f1230i != textSize) {
                b302.f1230i = textSize;
                b302.mo1581j();
            }
            int gravity = this.f1844e.getGravity();
            b30 b303 = this.f1843d0;
            int i = (gravity & -113) | 48;
            if (b303.f1229h != i) {
                b303.f1229h = i;
                b303.mo1581j();
            }
            b30 b304 = this.f1843d0;
            if (b304.f1228g != gravity) {
                b304.f1228g = gravity;
                b304.mo1581j();
            }
            this.f1844e.addTextChangedListener(new C0407a());
            if (this.f1835T == null) {
                this.f1835T = this.f1844e.getHintTextColors();
            }
            if (this.f1858n) {
                if (TextUtils.isEmpty(this.f1859o)) {
                    CharSequence hint = this.f1844e.getHint();
                    this.f1846f = hint;
                    setHint(hint);
                    this.f1844e.setHint((CharSequence) null);
                }
                this.f1860p = true;
            }
            if (this.f1855k != null) {
                mo2282l(this.f1844e.getText().length());
            }
            this.f1848g.mo5654b();
            mo2290p();
            mo2285o(false, true);
            return;
        }
        throw new IllegalArgumentException("We already have an EditText, can only have one");
    }

    private void setHintInternal(CharSequence charSequence) {
        if (!TextUtils.equals(charSequence, this.f1859o)) {
            this.f1859o = charSequence;
            b30 b30 = this.f1843d0;
            if (charSequence == null || !charSequence.equals(b30.f1243v)) {
                b30.f1243v = charSequence;
                b30.f1244w = null;
                Bitmap bitmap = b30.f1246y;
                if (bitmap != null) {
                    bitmap.recycle();
                    b30.f1246y = null;
                }
                b30.mo1581j();
            }
            if (!this.f1841c0) {
                mo2279h();
            }
        }
    }

    /* renamed from: a */
    public void mo2246a(float f) {
        if (this.f1843d0.f1224c != f) {
            if (this.f1847f0 == null) {
                ValueAnimator valueAnimator = new ValueAnimator();
                this.f1847f0 = valueAnimator;
                valueAnimator.setInterpolator(p10.f4734b);
                this.f1847f0.setDuration(167);
                this.f1847f0.addUpdateListener(new C0409c());
            }
            this.f1847f0.setFloatValues(new float[]{this.f1843d0.f1224c, f});
            this.f1847f0.start();
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof EditText) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
            layoutParams2.gravity = (layoutParams2.gravity & -113) | 16;
            this.f1842d.addView(view, layoutParams2);
            this.f1842d.setLayoutParams(layoutParams);
            mo2284n();
            setEditText((EditText) view);
            return;
        }
        super.addView(view, i, layoutParams);
    }

    /* renamed from: b */
    public final void mo2248b() {
        int i;
        Drawable drawable;
        if (this.f1861q != null) {
            int i2 = this.f1864t;
            if (i2 == 1) {
                this.f1870z = 0;
            } else if (i2 == 2 && this.f1839a0 == 0) {
                this.f1839a0 = this.f1836U.getColorForState(getDrawableState(), this.f1836U.getDefaultColor());
            }
            EditText editText = this.f1844e;
            if (editText != null && this.f1864t == 2) {
                if (editText.getBackground() != null) {
                    this.f1820E = this.f1844e.getBackground();
                }
                EditText editText2 = this.f1844e;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                editText2.setBackground((Drawable) null);
            }
            EditText editText3 = this.f1844e;
            if (!(editText3 == null || this.f1864t != 1 || (drawable = this.f1820E) == null)) {
                WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
                editText3.setBackground(drawable);
            }
            int i3 = this.f1870z;
            if (i3 > -1 && (i = this.f1818C) != 0) {
                this.f1861q.setStroke(i3, i);
            }
            this.f1861q.setCornerRadii(getCornerRadiiAsArray());
            this.f1861q.setColor(this.f1819D);
            invalidate();
        }
    }

    /* renamed from: c */
    public final void mo2249c() {
        Drawable drawable;
        Drawable drawable2 = this.f1825J;
        if (drawable2 == null) {
            return;
        }
        if (this.f1832Q || this.f1834S) {
            Drawable mutate = C1401p4.m4381p0(drawable2).mutate();
            this.f1825J = mutate;
            if (this.f1832Q) {
                C1401p4.m4367i0(mutate, this.f1831P);
            }
            if (this.f1834S) {
                C1401p4.m4369j0(this.f1825J, this.f1833R);
            }
            CheckableImageButton checkableImageButton = this.f1827L;
            if (checkableImageButton != null && checkableImageButton.getDrawable() != (drawable = this.f1825J)) {
                this.f1827L.setImageDrawable(drawable);
            }
        }
    }

    /* renamed from: d */
    public final int mo2250d() {
        float f;
        if (!this.f1858n) {
            return 0;
        }
        int i = this.f1864t;
        if (i == 0 || i == 1) {
            f = this.f1843d0.mo1578f();
        } else if (i != 2) {
            return 0;
        } else {
            f = this.f1843d0.mo1578f() / 2.0f;
        }
        return (int) f;
    }

    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i) {
        EditText editText;
        if (this.f1846f == null || (editText = this.f1844e) == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i);
            return;
        }
        boolean z = this.f1860p;
        this.f1860p = false;
        CharSequence hint = editText.getHint();
        this.f1844e.setHint(this.f1846f);
        try {
            super.dispatchProvideAutofillStructure(viewStructure, i);
        } finally {
            this.f1844e.setHint(hint);
            this.f1860p = z;
        }
    }

    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.f1853i0 = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.f1853i0 = false;
    }

    public void draw(Canvas canvas) {
        GradientDrawable gradientDrawable = this.f1861q;
        if (gradientDrawable != null) {
            gradientDrawable.draw(canvas);
        }
        super.draw(canvas);
        if (this.f1858n) {
            b30 b30 = this.f1843d0;
            Objects.requireNonNull(b30);
            int save = canvas.save();
            if (b30.f1244w != null && b30.f1223b) {
                float f = b30.f1238q;
                float f2 = b30.f1239r;
                b30.f1214D.ascent();
                b30.f1214D.descent();
                float f3 = b30.f1247z;
                if (f3 != 1.0f) {
                    canvas.scale(f3, f3, f, f2);
                }
                CharSequence charSequence = b30.f1244w;
                canvas.drawText(charSequence, 0, charSequence.length(), f, f2, b30.f1214D);
            }
            canvas.restoreToCount(save);
        }
    }

    public void drawableStateChanged() {
        boolean z;
        ColorStateList colorStateList;
        if (!this.f1851h0) {
            boolean z2 = true;
            this.f1851h0 = true;
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            mo2285o(isLaidOut() && isEnabled(), false);
            mo2283m();
            mo2291q();
            mo2292r();
            b30 b30 = this.f1843d0;
            if (b30 != null) {
                b30.f1212B = drawableState;
                ColorStateList colorStateList2 = b30.f1233l;
                if ((colorStateList2 != null && colorStateList2.isStateful()) || ((colorStateList = b30.f1232k) != null && colorStateList.isStateful())) {
                    b30.mo1581j();
                } else {
                    z2 = false;
                }
                z = z2 | false;
            } else {
                z = false;
            }
            if (z) {
                invalidate();
            }
            this.f1851h0 = false;
        }
    }

    /* renamed from: e */
    public final boolean mo2255e() {
        return this.f1858n && !TextUtils.isEmpty(this.f1859o) && (this.f1861q instanceof q30);
    }

    /* renamed from: f */
    public final boolean mo2256f() {
        EditText editText = this.f1844e;
        return editText != null && (editText.getTransformationMethod() instanceof PasswordTransformationMethod);
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x002a  */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2257g() {
        /*
            r2 = this;
            int r0 = r2.f1864t
            if (r0 != 0) goto L_0x0006
            r0 = 0
            goto L_0x0024
        L_0x0006:
            r1 = 2
            if (r0 != r1) goto L_0x0019
            boolean r0 = r2.f1858n
            if (r0 == 0) goto L_0x0019
            android.graphics.drawable.GradientDrawable r0 = r2.f1861q
            boolean r0 = r0 instanceof p000.q30
            if (r0 != 0) goto L_0x0019
            q30 r0 = new q30
            r0.<init>()
            goto L_0x0024
        L_0x0019:
            android.graphics.drawable.GradientDrawable r0 = r2.f1861q
            boolean r0 = r0 instanceof android.graphics.drawable.GradientDrawable
            if (r0 != 0) goto L_0x0026
            android.graphics.drawable.GradientDrawable r0 = new android.graphics.drawable.GradientDrawable
            r0.<init>()
        L_0x0024:
            r2.f1861q = r0
        L_0x0026:
            int r0 = r2.f1864t
            if (r0 == 0) goto L_0x002d
            r2.mo2284n()
        L_0x002d:
            r2.mo2291q()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.mo2257g():void");
    }

    public int getBoxBackgroundColor() {
        return this.f1819D;
    }

    public float getBoxCornerRadiusBottomEnd() {
        return this.f1868x;
    }

    public float getBoxCornerRadiusBottomStart() {
        return this.f1869y;
    }

    public float getBoxCornerRadiusTopEnd() {
        return this.f1867w;
    }

    public float getBoxCornerRadiusTopStart() {
        return this.f1866v;
    }

    public int getBoxStrokeColor() {
        return this.f1839a0;
    }

    public int getCounterMaxLength() {
        return this.f1852i;
    }

    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (!this.f1850h || !this.f1854j || (textView = this.f1855k) == null) {
            return null;
        }
        return textView.getContentDescription();
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.f1835T;
    }

    public EditText getEditText() {
        return this.f1844e;
    }

    public CharSequence getError() {
        r30 r30 = this.f1848g;
        if (r30.f5426l) {
            return r30.f5425k;
        }
        return null;
    }

    public int getErrorCurrentTextColors() {
        return this.f1848g.mo5659g();
    }

    public final int getErrorTextCurrentColor() {
        return this.f1848g.mo5659g();
    }

    public CharSequence getHelperText() {
        r30 r30 = this.f1848g;
        if (r30.f5430p) {
            return r30.f5429o;
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        TextView textView = this.f1848g.f5431q;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return -1;
    }

    public CharSequence getHint() {
        if (this.f1858n) {
            return this.f1859o;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.f1843d0.mo1578f();
    }

    public final int getHintCurrentCollapsedTextColor() {
        return this.f1843d0.mo1579g();
    }

    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.f1826K;
    }

    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.f1825J;
    }

    public Typeface getTypeface() {
        return this.f1823H;
    }

    /* renamed from: h */
    public final void mo2279h() {
        if (mo2255e()) {
            RectF rectF = this.f1822G;
            b30 b30 = this.f1843d0;
            boolean c = b30.mo1575c(b30.f1243v);
            Rect rect = b30.f1226e;
            float b = !c ? (float) rect.left : ((float) rect.right) - b30.mo1574b();
            rectF.left = b;
            Rect rect2 = b30.f1226e;
            rectF.top = (float) rect2.top;
            rectF.right = !c ? b30.mo1574b() + b : (float) rect2.right;
            float f = b30.mo1578f() + ((float) b30.f1226e.top);
            rectF.bottom = f;
            float f2 = rectF.left;
            float f3 = (float) this.f1863s;
            rectF.left = f2 - f3;
            rectF.top -= f3;
            rectF.right += f3;
            rectF.bottom = f + f3;
            q30 q30 = (q30) this.f1861q;
            Objects.requireNonNull(q30);
            q30.mo5316a(rectF.left, rectF.top, rectF.right, rectF.bottom);
        }
    }

    /* renamed from: i */
    public void mo2280i(boolean z) {
        boolean z2;
        if (this.f1824I) {
            int selectionEnd = this.f1844e.getSelectionEnd();
            if (mo2256f()) {
                this.f1844e.setTransformationMethod((TransformationMethod) null);
                z2 = true;
            } else {
                this.f1844e.setTransformationMethod(PasswordTransformationMethod.getInstance());
                z2 = false;
            }
            this.f1828M = z2;
            this.f1827L.setChecked(this.f1828M);
            if (z) {
                this.f1827L.jumpDrawablesToCurrentState();
            }
            this.f1844e.setSelection(selectionEnd);
        }
    }

    /* renamed from: k */
    public void mo2281k(TextView textView, int i) {
        boolean z = true;
        try {
            C1401p4.m4363g0(textView, i);
            if (Build.VERSION.SDK_INT < 23 || textView.getTextColors().getDefaultColor() != -65281) {
                z = false;
            }
        } catch (Exception unused) {
        }
        if (z) {
            C1401p4.m4363g0(textView, C0446R.style.TextAppearance_AppCompat_Caption);
            textView.setTextColor(C1901v4.m5333b(getContext(), R.color.design_error));
        }
    }

    /* renamed from: l */
    public void mo2282l(int i) {
        boolean z = this.f1854j;
        if (this.f1852i == -1) {
            this.f1855k.setText(String.valueOf(i));
            this.f1855k.setContentDescription((CharSequence) null);
            this.f1854j = false;
        } else {
            TextView textView = this.f1855k;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            if (textView.getAccessibilityLiveRegion() == 1) {
                this.f1855k.setAccessibilityLiveRegion(0);
            }
            boolean z2 = i > this.f1852i;
            this.f1854j = z2;
            if (z != z2) {
                mo2281k(this.f1855k, z2 ? this.f1856l : this.f1857m);
                if (this.f1854j) {
                    this.f1855k.setAccessibilityLiveRegion(1);
                }
            }
            this.f1855k.setText(getContext().getString(R.string.character_counter_pattern, new Object[]{Integer.valueOf(i), Integer.valueOf(this.f1852i)}));
            this.f1855k.setContentDescription(getContext().getString(R.string.character_counter_content_description, new Object[]{Integer.valueOf(i), Integer.valueOf(this.f1852i)}));
        }
        if (this.f1844e != null && z != this.f1854j) {
            mo2285o(false, false);
            mo2292r();
            mo2283m();
        }
    }

    /* renamed from: m */
    public void mo2283m() {
        Drawable background;
        TextView textView;
        int currentTextColor;
        Drawable background2;
        EditText editText = this.f1844e;
        if (editText != null && (background = editText.getBackground()) != null) {
            int i = Build.VERSION.SDK_INT;
            if ((i == 21 || i == 22) && (background2 = this.f1844e.getBackground()) != null && !this.f1849g0) {
                Drawable newDrawable = background2.getConstantState().newDrawable();
                if (background2 instanceof DrawableContainer) {
                    DrawableContainer drawableContainer = (DrawableContainer) background2;
                    Drawable.ConstantState constantState = newDrawable.getConstantState();
                    boolean z = false;
                    if (!n10.f4161b) {
                        try {
                            Method declaredMethod = DrawableContainer.class.getDeclaredMethod("setConstantState", new Class[]{DrawableContainer.DrawableContainerState.class});
                            n10.f4160a = declaredMethod;
                            declaredMethod.setAccessible(true);
                        } catch (NoSuchMethodException unused) {
                            Log.e("DrawableUtils", "Could not fetch setConstantState(). Oh well.");
                        }
                        n10.f4161b = true;
                    }
                    Method method = n10.f4160a;
                    if (method != null) {
                        try {
                            method.invoke(drawableContainer, new Object[]{constantState});
                            z = true;
                        } catch (Exception unused2) {
                            Log.e("DrawableUtils", "Could not invoke setConstantState(). Oh well.");
                        }
                    }
                    this.f1849g0 = z;
                }
                if (!this.f1849g0) {
                    EditText editText2 = this.f1844e;
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    editText2.setBackground(newDrawable);
                    this.f1849g0 = true;
                    mo2257g();
                }
            }
            if (C0936j2.m2912a(background)) {
                background = background.mutate();
            }
            if (this.f1848g.mo5657e()) {
                currentTextColor = this.f1848g.mo5659g();
            } else if (!this.f1854j || (textView = this.f1855k) == null) {
                C1401p4.m4364h(background);
                this.f1844e.refreshDrawableState();
                return;
            } else {
                currentTextColor = textView.getCurrentTextColor();
            }
            background.setColorFilter(C1391p1.m4300c(currentTextColor, PorterDuff.Mode.SRC_IN));
        }
    }

    /* renamed from: n */
    public final void mo2284n() {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1842d.getLayoutParams();
        int d = mo2250d();
        if (d != layoutParams.topMargin) {
            layoutParams.topMargin = d;
            this.f1842d.requestLayout();
        }
    }

    /* renamed from: o */
    public final void mo2285o(boolean z, boolean z2) {
        b30 b30;
        ColorStateList colorStateList;
        TextView textView;
        boolean isEnabled = isEnabled();
        EditText editText = this.f1844e;
        boolean z3 = editText != null && !TextUtils.isEmpty(editText.getText());
        EditText editText2 = this.f1844e;
        boolean z4 = editText2 != null && editText2.hasFocus();
        boolean e = this.f1848g.mo5657e();
        ColorStateList colorStateList2 = this.f1835T;
        if (colorStateList2 != null) {
            b30 b302 = this.f1843d0;
            if (b302.f1233l != colorStateList2) {
                b302.f1233l = colorStateList2;
                b302.mo1581j();
            }
            b30 b303 = this.f1843d0;
            ColorStateList colorStateList3 = this.f1835T;
            if (b303.f1232k != colorStateList3) {
                b303.f1232k = colorStateList3;
                b303.mo1581j();
            }
        }
        if (!isEnabled) {
            this.f1843d0.mo1582l(ColorStateList.valueOf(this.f1840b0));
            b30 b304 = this.f1843d0;
            ColorStateList valueOf = ColorStateList.valueOf(this.f1840b0);
            if (b304.f1232k != valueOf) {
                b304.f1232k = valueOf;
                b304.mo1581j();
            }
        } else if (e) {
            b30 b305 = this.f1843d0;
            TextView textView2 = this.f1848g.f5427m;
            b305.mo1582l(textView2 != null ? textView2.getTextColors() : null);
        } else {
            if (this.f1854j && (textView = this.f1855k) != null) {
                b30 = this.f1843d0;
                colorStateList = textView.getTextColors();
            } else if (z4 && (colorStateList = this.f1836U) != null) {
                b30 = this.f1843d0;
            }
            b30.mo1582l(colorStateList);
        }
        if (z3 || (isEnabled() && (z4 || e))) {
            if (z2 || this.f1841c0) {
                ValueAnimator valueAnimator = this.f1847f0;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.f1847f0.cancel();
                }
                if (!z || !this.f1845e0) {
                    this.f1843d0.mo1583m(1.0f);
                } else {
                    mo2246a(1.0f);
                }
                this.f1841c0 = false;
                if (mo2255e()) {
                    mo2279h();
                }
            }
        } else if (z2 || !this.f1841c0) {
            ValueAnimator valueAnimator2 = this.f1847f0;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.f1847f0.cancel();
            }
            if (!z || !this.f1845e0) {
                this.f1843d0.mo1583m(0.0f);
            } else {
                mo2246a(0.0f);
            }
            if (mo2255e() && (!((q30) this.f1861q).f4976b.isEmpty()) && mo2255e()) {
                ((q30) this.f1861q).mo5316a(0.0f, 0.0f, 0.0f, 0.0f);
            }
            this.f1841c0 = true;
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        EditText editText;
        super.onLayout(z, i, i2, i3, i4);
        if (this.f1861q != null) {
            mo2291q();
        }
        if (this.f1858n && (editText = this.f1844e) != null) {
            Rect rect = this.f1821F;
            c30.m1262a(this, editText, rect);
            int compoundPaddingLeft = this.f1844e.getCompoundPaddingLeft() + rect.left;
            int compoundPaddingRight = rect.right - this.f1844e.getCompoundPaddingRight();
            int i5 = this.f1864t;
            int paddingTop = i5 != 1 ? i5 != 2 ? getPaddingTop() : getBoxBackground().getBounds().top - mo2250d() : getBoxBackground().getBounds().top + this.f1865u;
            b30 b30 = this.f1843d0;
            int compoundPaddingTop = this.f1844e.getCompoundPaddingTop() + rect.top;
            int compoundPaddingBottom = rect.bottom - this.f1844e.getCompoundPaddingBottom();
            if (!b30.m1043k(b30.f1225d, compoundPaddingLeft, compoundPaddingTop, compoundPaddingRight, compoundPaddingBottom)) {
                b30.f1225d.set(compoundPaddingLeft, compoundPaddingTop, compoundPaddingRight, compoundPaddingBottom);
                b30.f1213C = true;
                b30.mo1580i();
            }
            b30 b302 = this.f1843d0;
            int paddingBottom = (i4 - i2) - getPaddingBottom();
            if (!b30.m1043k(b302.f1226e, compoundPaddingLeft, paddingTop, compoundPaddingRight, paddingBottom)) {
                b302.f1226e.set(compoundPaddingLeft, paddingTop, compoundPaddingRight, paddingBottom);
                b302.f1213C = true;
                b302.mo1580i();
            }
            this.f1843d0.mo1581j();
            if (mo2255e() && !this.f1841c0) {
                mo2279h();
            }
        }
    }

    public void onMeasure(int i, int i2) {
        mo2290p();
        super.onMeasure(i, i2);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0411e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0411e eVar = (C0411e) parcelable;
        super.onRestoreInstanceState(eVar.f43d);
        setError(eVar.f1875f);
        if (eVar.f1876g) {
            mo2280i(true);
        }
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0411e eVar = new C0411e(super.onSaveInstanceState());
        if (this.f1848g.mo5657e()) {
            eVar.f1875f = getError();
        }
        eVar.f1876g = this.f1828M;
        return eVar;
    }

    /* renamed from: p */
    public final void mo2290p() {
        if (this.f1844e != null) {
            if (this.f1824I && (mo2256f() || this.f1828M)) {
                if (this.f1827L == null) {
                    CheckableImageButton checkableImageButton = (CheckableImageButton) LayoutInflater.from(getContext()).inflate(R.layout.design_text_input_password_icon, this.f1842d, false);
                    this.f1827L = checkableImageButton;
                    checkableImageButton.setImageDrawable(this.f1825J);
                    this.f1827L.setContentDescription(this.f1826K);
                    this.f1842d.addView(this.f1827L);
                    this.f1827L.setOnClickListener(new C0408b());
                }
                EditText editText = this.f1844e;
                if (editText != null) {
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    if (editText.getMinimumHeight() <= 0) {
                        this.f1844e.setMinimumHeight(this.f1827L.getMinimumHeight());
                    }
                }
                this.f1827L.setVisibility(0);
                this.f1827L.setChecked(this.f1828M);
                if (this.f1829N == null) {
                    this.f1829N = new ColorDrawable();
                }
                this.f1829N.setBounds(0, 0, this.f1827L.getMeasuredWidth(), 1);
                Drawable[] compoundDrawablesRelative = this.f1844e.getCompoundDrawablesRelative();
                Drawable drawable = compoundDrawablesRelative[2];
                Drawable drawable2 = this.f1829N;
                if (drawable != drawable2) {
                    this.f1830O = compoundDrawablesRelative[2];
                }
                this.f1844e.setCompoundDrawablesRelative(compoundDrawablesRelative[0], compoundDrawablesRelative[1], drawable2, compoundDrawablesRelative[3]);
                this.f1827L.setPadding(this.f1844e.getPaddingLeft(), this.f1844e.getPaddingTop(), this.f1844e.getPaddingRight(), this.f1844e.getPaddingBottom());
                return;
            }
            CheckableImageButton checkableImageButton2 = this.f1827L;
            if (checkableImageButton2 != null && checkableImageButton2.getVisibility() == 0) {
                this.f1827L.setVisibility(8);
            }
            if (this.f1829N != null) {
                Drawable[] compoundDrawablesRelative2 = this.f1844e.getCompoundDrawablesRelative();
                if (compoundDrawablesRelative2[2] == this.f1829N) {
                    this.f1844e.setCompoundDrawablesRelative(compoundDrawablesRelative2[0], compoundDrawablesRelative2[1], this.f1830O, compoundDrawablesRelative2[3]);
                    this.f1829N = null;
                }
            }
        }
    }

    /* renamed from: q */
    public final void mo2291q() {
        Drawable background;
        if (this.f1864t != 0 && this.f1861q != null && this.f1844e != null && getRight() != 0) {
            int left = this.f1844e.getLeft();
            EditText editText = this.f1844e;
            int i = 0;
            if (editText != null) {
                int i2 = this.f1864t;
                if (i2 == 1) {
                    i = editText.getTop();
                } else if (i2 == 2) {
                    i = mo2250d() + editText.getTop();
                }
            }
            int right = this.f1844e.getRight();
            int bottom = this.f1844e.getBottom() + this.f1862r;
            if (this.f1864t == 2) {
                int i3 = this.f1817B;
                left += i3 / 2;
                i -= i3 / 2;
                right -= i3 / 2;
                bottom += i3 / 2;
            }
            this.f1861q.setBounds(left, i, right, bottom);
            mo2248b();
            EditText editText2 = this.f1844e;
            if (editText2 != null && (background = editText2.getBackground()) != null) {
                if (C0936j2.m2912a(background)) {
                    background = background.mutate();
                }
                c30.m1262a(this, this.f1844e, new Rect());
                Rect bounds = background.getBounds();
                if (bounds.left != bounds.right) {
                    Rect rect = new Rect();
                    background.getPadding(rect);
                    int i4 = bounds.left - rect.left;
                    int i5 = bounds.right;
                    background.setBounds(i4, bounds.top, (rect.right * 2) + i5, this.f1844e.getBottom());
                }
            }
        }
    }

    /* renamed from: r */
    public void mo2292r() {
        TextView textView;
        if (this.f1861q != null && this.f1864t != 0) {
            EditText editText = this.f1844e;
            boolean z = true;
            boolean z2 = editText != null && editText.hasFocus();
            EditText editText2 = this.f1844e;
            if (editText2 == null || !editText2.isHovered()) {
                z = false;
            }
            if (this.f1864t == 2) {
                this.f1818C = !isEnabled() ? this.f1840b0 : this.f1848g.mo5657e() ? this.f1848g.mo5659g() : (!this.f1854j || (textView = this.f1855k) == null) ? z2 ? this.f1839a0 : z ? this.f1838W : this.f1837V : textView.getCurrentTextColor();
                this.f1870z = ((z || z2) && isEnabled()) ? this.f1817B : this.f1816A;
                mo2248b();
            }
        }
    }

    public void setBoxBackgroundColor(int i) {
        if (this.f1819D != i) {
            this.f1819D = i;
            mo2248b();
        }
    }

    public void setBoxBackgroundColorResource(int i) {
        setBoxBackgroundColor(C1901v4.m5333b(getContext(), i));
    }

    public void setBoxBackgroundMode(int i) {
        if (i != this.f1864t) {
            this.f1864t = i;
            mo2257g();
        }
    }

    public void setBoxStrokeColor(int i) {
        if (this.f1839a0 != i) {
            this.f1839a0 = i;
            mo2292r();
        }
    }

    public void setCounterEnabled(boolean z) {
        if (this.f1850h != z) {
            if (z) {
                C0599e2 e2Var = new C0599e2(getContext(), (AttributeSet) null);
                this.f1855k = e2Var;
                e2Var.setId(R.id.textinput_counter);
                Typeface typeface = this.f1823H;
                if (typeface != null) {
                    this.f1855k.setTypeface(typeface);
                }
                this.f1855k.setMaxLines(1);
                mo2281k(this.f1855k, this.f1857m);
                this.f1848g.mo5653a(this.f1855k, 2);
                EditText editText = this.f1844e;
                mo2282l(editText == null ? 0 : editText.getText().length());
            } else {
                this.f1848g.mo5661i(this.f1855k, 2);
                this.f1855k = null;
            }
            this.f1850h = z;
        }
    }

    public void setCounterMaxLength(int i) {
        if (this.f1852i != i) {
            if (i <= 0) {
                i = -1;
            }
            this.f1852i = i;
            if (this.f1850h) {
                EditText editText = this.f1844e;
                mo2282l(editText == null ? 0 : editText.getText().length());
            }
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.f1835T = colorStateList;
        this.f1836U = colorStateList;
        if (this.f1844e != null) {
            mo2285o(false, false);
        }
    }

    public void setEnabled(boolean z) {
        m1546j(this, z);
        super.setEnabled(z);
    }

    public void setError(CharSequence charSequence) {
        if (!this.f1848g.f5426l) {
            if (!TextUtils.isEmpty(charSequence)) {
                setErrorEnabled(true);
            } else {
                return;
            }
        }
        if (!TextUtils.isEmpty(charSequence)) {
            r30 r30 = this.f1848g;
            r30.mo5655c();
            r30.f5425k = charSequence;
            r30.f5427m.setText(charSequence);
            int i = r30.f5423i;
            if (i != 1) {
                r30.f5424j = 1;
            }
            r30.mo5663k(i, r30.f5424j, r30.mo5662j(r30.f5427m, charSequence));
            return;
        }
        this.f1848g.mo5660h();
    }

    public void setErrorEnabled(boolean z) {
        r30 r30 = this.f1848g;
        if (r30.f5426l != z) {
            r30.mo5655c();
            if (z) {
                C0599e2 e2Var = new C0599e2(r30.f5415a, (AttributeSet) null);
                r30.f5427m = e2Var;
                e2Var.setId(R.id.textinput_error);
                Typeface typeface = r30.f5433s;
                if (typeface != null) {
                    r30.f5427m.setTypeface(typeface);
                }
                int i = r30.f5428n;
                r30.f5428n = i;
                TextView textView = r30.f5427m;
                if (textView != null) {
                    r30.f5416b.mo2281k(textView, i);
                }
                r30.f5427m.setVisibility(4);
                TextView textView2 = r30.f5427m;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                textView2.setAccessibilityLiveRegion(1);
                r30.mo5653a(r30.f5427m, 0);
            } else {
                r30.mo5660h();
                r30.mo5661i(r30.f5427m, 0);
                r30.f5427m = null;
                r30.f5416b.mo2283m();
                r30.f5416b.mo2292r();
            }
            r30.f5426l = z;
        }
    }

    public void setErrorTextAppearance(int i) {
        r30 r30 = this.f1848g;
        r30.f5428n = i;
        TextView textView = r30.f5427m;
        if (textView != null) {
            r30.f5416b.mo2281k(textView, i);
        }
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        TextView textView = this.f1848g.f5427m;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (!this.f1848g.f5430p) {
                setHelperTextEnabled(true);
            }
            r30 r30 = this.f1848g;
            r30.mo5655c();
            r30.f5429o = charSequence;
            r30.f5431q.setText(charSequence);
            int i = r30.f5423i;
            if (i != 2) {
                r30.f5424j = 2;
            }
            r30.mo5663k(i, r30.f5424j, r30.mo5662j(r30.f5431q, charSequence));
        } else if (this.f1848g.f5430p) {
            setHelperTextEnabled(false);
        }
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        TextView textView = this.f1848g.f5431q;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setHelperTextEnabled(boolean z) {
        r30 r30 = this.f1848g;
        if (r30.f5430p != z) {
            r30.mo5655c();
            if (z) {
                C0599e2 e2Var = new C0599e2(r30.f5415a, (AttributeSet) null);
                r30.f5431q = e2Var;
                e2Var.setId(R.id.textinput_helper_text);
                Typeface typeface = r30.f5433s;
                if (typeface != null) {
                    r30.f5431q.setTypeface(typeface);
                }
                r30.f5431q.setVisibility(4);
                TextView textView = r30.f5431q;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                textView.setAccessibilityLiveRegion(1);
                int i = r30.f5432r;
                r30.f5432r = i;
                TextView textView2 = r30.f5431q;
                if (textView2 != null) {
                    C1401p4.m4363g0(textView2, i);
                }
                r30.mo5653a(r30.f5431q, 1);
            } else {
                r30.mo5655c();
                int i2 = r30.f5423i;
                if (i2 == 2) {
                    r30.f5424j = 0;
                }
                r30.mo5663k(i2, r30.f5424j, r30.mo5662j(r30.f5431q, (CharSequence) null));
                r30.mo5661i(r30.f5431q, 1);
                r30.f5431q = null;
                r30.f5416b.mo2283m();
                r30.f5416b.mo2292r();
            }
            r30.f5430p = z;
        }
    }

    public void setHelperTextTextAppearance(int i) {
        r30 r30 = this.f1848g;
        r30.f5432r = i;
        TextView textView = r30.f5431q;
        if (textView != null) {
            C1401p4.m4363g0(textView, i);
        }
    }

    public void setHint(CharSequence charSequence) {
        if (this.f1858n) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z) {
        this.f1845e0 = z;
    }

    public void setHintEnabled(boolean z) {
        if (z != this.f1858n) {
            this.f1858n = z;
            if (!z) {
                this.f1860p = false;
                if (!TextUtils.isEmpty(this.f1859o) && TextUtils.isEmpty(this.f1844e.getHint())) {
                    this.f1844e.setHint(this.f1859o);
                }
                setHintInternal((CharSequence) null);
            } else {
                CharSequence hint = this.f1844e.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.f1859o)) {
                        setHint(hint);
                    }
                    this.f1844e.setHint((CharSequence) null);
                }
                this.f1860p = true;
            }
            if (this.f1844e != null) {
                mo2284n();
            }
        }
    }

    public void setHintTextAppearance(int i) {
        Typeface typeface;
        b30 b30 = this.f1843d0;
        C0327c3 q = C0327c3.m1243q(b30.f1222a.getContext(), i, C0593e.f2393w);
        if (q.mo1839p(3)) {
            b30.f1233l = q.mo1826c(3);
        }
        if (q.mo1839p(0)) {
            b30.f1231j = (float) q.mo1829f(0, (int) b30.f1231j);
        }
        b30.f1221K = q.mo1834k(6, 0);
        b30.f1219I = q.mo1832i(7, 0.0f);
        b30.f1220J = q.mo1832i(8, 0.0f);
        b30.f1218H = q.mo1832i(9, 0.0f);
        q.f1430b.recycle();
        TypedArray obtainStyledAttributes = b30.f1222a.getContext().obtainStyledAttributes(i, new int[]{16843692});
        try {
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                typeface = Typeface.create(string, 0);
            } else {
                obtainStyledAttributes.recycle();
                typeface = null;
            }
            b30.f1240s = typeface;
            b30.mo1581j();
            this.f1836U = this.f1843d0.f1233l;
            if (this.f1844e != null) {
                mo2285o(false, false);
                mo2284n();
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public void setPasswordVisibilityToggleContentDescription(int i) {
        setPasswordVisibilityToggleContentDescription(i != 0 ? getResources().getText(i) : null);
    }

    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.f1826K = charSequence;
        CheckableImageButton checkableImageButton = this.f1827L;
        if (checkableImageButton != null) {
            checkableImageButton.setContentDescription(charSequence);
        }
    }

    public void setPasswordVisibilityToggleDrawable(int i) {
        setPasswordVisibilityToggleDrawable(i != 0 ? C0001a0.m1b(getContext(), i) : null);
    }

    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.f1825J = drawable;
        CheckableImageButton checkableImageButton = this.f1827L;
        if (checkableImageButton != null) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public void setPasswordVisibilityToggleEnabled(boolean z) {
        EditText editText;
        if (this.f1824I != z) {
            this.f1824I = z;
            if (!z && this.f1828M && (editText = this.f1844e) != null) {
                editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
            this.f1828M = false;
            mo2290p();
        }
    }

    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.f1831P = colorStateList;
        this.f1832Q = true;
        mo2249c();
    }

    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.f1833R = mode;
        this.f1834S = true;
        mo2249c();
    }

    public void setTextInputAccessibilityDelegate(C0410d dVar) {
        EditText editText = this.f1844e;
        if (editText != null) {
            C0010a7.m43p(editText, dVar);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.f1823H) {
            this.f1823H = typeface;
            b30 b30 = this.f1843d0;
            b30.f1241t = typeface;
            b30.f1240s = typeface;
            b30.mo1581j();
            r30 r30 = this.f1848g;
            if (typeface != r30.f5433s) {
                r30.f5433s = typeface;
                TextView textView = r30.f5427m;
                if (textView != null) {
                    textView.setTypeface(typeface);
                }
                TextView textView2 = r30.f5431q;
                if (textView2 != null) {
                    textView2.setTypeface(typeface);
                }
            }
            TextView textView3 = this.f1855k;
            if (textView3 != null) {
                textView3.setTypeface(typeface);
            }
        }
    }
}
