package com.google.android.material.button;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.Log;
import android.view.View;
import java.util.Objects;
import java.util.WeakHashMap;

public class MaterialButton extends C1154m1 {

    /* renamed from: f */
    public final k20 f1769f;

    /* renamed from: g */
    public int f1770g;

    /* renamed from: h */
    public PorterDuff.Mode f1771h;

    /* renamed from: i */
    public ColorStateList f1772i;

    /* renamed from: j */
    public Drawable f1773j;

    /* renamed from: k */
    public int f1774k;

    /* renamed from: l */
    public int f1775l;

    /* renamed from: m */
    public int f1776m;

    /* JADX WARNING: type inference failed for: r3v8, types: [android.graphics.drawable.Drawable] */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x005d, code lost:
        r2 = p000.C0001a0.m1b(r2, (r5 = r1.getResourceId(7, 0)));
     */
    /* JADX WARNING: Illegal instructions before constructor call */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MaterialButton(android.content.Context r20, android.util.AttributeSet r21) {
        /*
            r19 = this;
            r0 = r19
            r7 = r20
            r8 = r21
            r9 = 2130903383(0x7f030157, float:1.7413582E38)
            r0.<init>(r7, r8, r9)
            int[] r10 = p000.o10.f4413g
            r11 = 0
            int[] r6 = new int[r11]
            r12 = 2131689961(0x7f0f01e9, float:1.9008952E38)
            p000.f30.m2143a(r7, r8, r9, r12)
            r5 = 2131689961(0x7f0f01e9, float:1.9008952E38)
            r4 = 2130903383(0x7f030157, float:1.7413582E38)
            r1 = r20
            r2 = r21
            r3 = r10
            p000.f30.m2144b(r1, r2, r3, r4, r5, r6)
            android.content.res.TypedArray r1 = r7.obtainStyledAttributes(r8, r10, r9, r12)
            r2 = 9
            int r2 = r1.getDimensionPixelSize(r2, r11)
            r0.f1770g = r2
            r2 = 12
            r3 = -1
            int r2 = r1.getInt(r2, r3)
            android.graphics.PorterDuff$Mode r4 = android.graphics.PorterDuff.Mode.SRC_IN
            android.graphics.PorterDuff$Mode r2 = p000.n10.m3822r(r2, r4)
            r0.f1771h = r2
            android.content.Context r2 = r19.getContext()
            r4 = 11
            android.content.res.ColorStateList r2 = p000.n10.m3815k(r2, r1, r4)
            r0.f1772i = r2
            android.content.Context r2 = r19.getContext()
            r4 = 7
            boolean r5 = r1.hasValue(r4)
            if (r5 == 0) goto L_0x0064
            int r5 = r1.getResourceId(r4, r11)
            if (r5 == 0) goto L_0x0064
            android.graphics.drawable.Drawable r2 = p000.C0001a0.m1b(r2, r5)
            if (r2 == 0) goto L_0x0064
            goto L_0x0068
        L_0x0064:
            android.graphics.drawable.Drawable r2 = r1.getDrawable(r4)
        L_0x0068:
            r0.f1773j = r2
            r2 = 8
            r4 = 1
            int r2 = r1.getInteger(r2, r4)
            r0.f1776m = r2
            r2 = 10
            int r2 = r1.getDimensionPixelSize(r2, r11)
            r0.f1774k = r2
            k20 r2 = new k20
            r2.<init>(r0)
            r0.f1769f = r2
            int r5 = r1.getDimensionPixelOffset(r11, r11)
            r2.f3551b = r5
            int r5 = r1.getDimensionPixelOffset(r4, r11)
            r2.f3552c = r5
            r5 = 2
            int r6 = r1.getDimensionPixelOffset(r5, r11)
            r2.f3553d = r6
            r6 = 3
            int r6 = r1.getDimensionPixelOffset(r6, r11)
            r2.f3554e = r6
            r6 = 6
            int r6 = r1.getDimensionPixelSize(r6, r11)
            r2.f3555f = r6
            r6 = 15
            int r6 = r1.getDimensionPixelSize(r6, r11)
            r2.f3556g = r6
            r6 = 5
            int r6 = r1.getInt(r6, r3)
            android.graphics.PorterDuff$Mode r7 = android.graphics.PorterDuff.Mode.SRC_IN
            android.graphics.PorterDuff$Mode r6 = p000.n10.m3822r(r6, r7)
            r2.f3557h = r6
            com.google.android.material.button.MaterialButton r6 = r2.f3550a
            android.content.Context r6 = r6.getContext()
            r7 = 4
            android.content.res.ColorStateList r6 = p000.n10.m3815k(r6, r1, r7)
            r2.f3558i = r6
            com.google.android.material.button.MaterialButton r6 = r2.f3550a
            android.content.Context r6 = r6.getContext()
            r7 = 14
            android.content.res.ColorStateList r6 = p000.n10.m3815k(r6, r1, r7)
            r2.f3559j = r6
            com.google.android.material.button.MaterialButton r6 = r2.f3550a
            android.content.Context r6 = r6.getContext()
            r7 = 13
            android.content.res.ColorStateList r6 = p000.n10.m3815k(r6, r1, r7)
            r2.f3560k = r6
            android.graphics.Paint r6 = r2.f3561l
            android.graphics.Paint$Style r7 = android.graphics.Paint.Style.STROKE
            r6.setStyle(r7)
            android.graphics.Paint r6 = r2.f3561l
            int r7 = r2.f3556g
            float r7 = (float) r7
            r6.setStrokeWidth(r7)
            android.graphics.Paint r6 = r2.f3561l
            android.content.res.ColorStateList r7 = r2.f3559j
            if (r7 == 0) goto L_0x0101
            com.google.android.material.button.MaterialButton r8 = r2.f3550a
            int[] r8 = r8.getDrawableState()
            int r7 = r7.getColorForState(r8, r11)
            goto L_0x0102
        L_0x0101:
            r7 = 0
        L_0x0102:
            r6.setColor(r7)
            com.google.android.material.button.MaterialButton r6 = r2.f3550a
            java.util.WeakHashMap<android.view.View, java.lang.String> r7 = p000.C0010a7.f28a
            int r6 = r6.getPaddingStart()
            com.google.android.material.button.MaterialButton r7 = r2.f3550a
            int r7 = r7.getPaddingTop()
            com.google.android.material.button.MaterialButton r8 = r2.f3550a
            int r8 = r8.getPaddingEnd()
            com.google.android.material.button.MaterialButton r9 = r2.f3550a
            int r9 = r9.getPaddingBottom()
            com.google.android.material.button.MaterialButton r10 = r2.f3550a
            boolean r12 = p000.k20.f3549w
            if (r12 == 0) goto L_0x012a
            android.graphics.drawable.Drawable r3 = r2.mo4247a()
            goto L_0x0199
        L_0x012a:
            android.graphics.drawable.GradientDrawable r12 = new android.graphics.drawable.GradientDrawable
            r12.<init>()
            r2.f3564o = r12
            int r13 = r2.f3555f
            float r13 = (float) r13
            r14 = 925353388(0x3727c5ac, float:1.0E-5)
            float r13 = r13 + r14
            r12.setCornerRadius(r13)
            android.graphics.drawable.GradientDrawable r12 = r2.f3564o
            r12.setColor(r3)
            android.graphics.drawable.GradientDrawable r12 = r2.f3564o
            android.graphics.drawable.Drawable r12 = p000.C1401p4.m4381p0(r12)
            r2.f3565p = r12
            android.content.res.ColorStateList r13 = r2.f3558i
            p000.C1401p4.m4367i0(r12, r13)
            android.graphics.PorterDuff$Mode r12 = r2.f3557h
            if (r12 == 0) goto L_0x0156
            android.graphics.drawable.Drawable r13 = r2.f3565p
            p000.C1401p4.m4369j0(r13, r12)
        L_0x0156:
            android.graphics.drawable.GradientDrawable r12 = new android.graphics.drawable.GradientDrawable
            r12.<init>()
            r2.f3566q = r12
            int r13 = r2.f3555f
            float r13 = (float) r13
            float r13 = r13 + r14
            r12.setCornerRadius(r13)
            android.graphics.drawable.GradientDrawable r12 = r2.f3566q
            r12.setColor(r3)
            android.graphics.drawable.GradientDrawable r3 = r2.f3566q
            android.graphics.drawable.Drawable r3 = p000.C1401p4.m4381p0(r3)
            r2.f3567r = r3
            android.content.res.ColorStateList r12 = r2.f3560k
            p000.C1401p4.m4367i0(r3, r12)
            android.graphics.drawable.LayerDrawable r14 = new android.graphics.drawable.LayerDrawable
            android.graphics.drawable.Drawable[] r3 = new android.graphics.drawable.Drawable[r5]
            android.graphics.drawable.Drawable r5 = r2.f3565p
            r3[r11] = r5
            android.graphics.drawable.Drawable r5 = r2.f3567r
            r3[r4] = r5
            r14.<init>(r3)
            android.graphics.drawable.InsetDrawable r3 = new android.graphics.drawable.InsetDrawable
            int r15 = r2.f3551b
            int r4 = r2.f3553d
            int r5 = r2.f3552c
            int r11 = r2.f3554e
            r13 = r3
            r16 = r4
            r17 = r5
            r18 = r11
            r13.<init>(r14, r15, r16, r17, r18)
        L_0x0199:
            r10.setInternalBackground(r3)
            com.google.android.material.button.MaterialButton r3 = r2.f3550a
            int r4 = r2.f3551b
            int r6 = r6 + r4
            int r4 = r2.f3553d
            int r7 = r7 + r4
            int r4 = r2.f3552c
            int r8 = r8 + r4
            int r2 = r2.f3554e
            int r9 = r9 + r2
            r3.setPaddingRelative(r6, r7, r8, r9)
            r1.recycle()
            int r1 = r0.f1770g
            r0.setCompoundDrawablePadding(r1)
            r19.mo2118b()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.button.MaterialButton.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* renamed from: a */
    public final boolean mo2117a() {
        k20 k20 = this.f1769f;
        return k20 != null && !k20.f3571v;
    }

    /* renamed from: b */
    public final void mo2118b() {
        Drawable drawable = this.f1773j;
        if (drawable != null) {
            Drawable mutate = drawable.mutate();
            this.f1773j = mutate;
            C1401p4.m4367i0(mutate, this.f1772i);
            PorterDuff.Mode mode = this.f1771h;
            if (mode != null) {
                C1401p4.m4369j0(this.f1773j, mode);
            }
            int i = this.f1774k;
            if (i == 0) {
                i = this.f1773j.getIntrinsicWidth();
            }
            int i2 = this.f1774k;
            if (i2 == 0) {
                i2 = this.f1773j.getIntrinsicHeight();
            }
            Drawable drawable2 = this.f1773j;
            int i3 = this.f1775l;
            drawable2.setBounds(i3, 0, i + i3, i2);
        }
        setCompoundDrawablesRelative(this.f1773j, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (mo2117a()) {
            return this.f1769f.f3555f;
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.f1773j;
    }

    public int getIconGravity() {
        return this.f1776m;
    }

    public int getIconPadding() {
        return this.f1770g;
    }

    public int getIconSize() {
        return this.f1774k;
    }

    public ColorStateList getIconTint() {
        return this.f1772i;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f1771h;
    }

    public ColorStateList getRippleColor() {
        if (mo2117a()) {
            return this.f1769f.f3560k;
        }
        return null;
    }

    public ColorStateList getStrokeColor() {
        if (mo2117a()) {
            return this.f1769f.f3559j;
        }
        return null;
    }

    public int getStrokeWidth() {
        if (mo2117a()) {
            return this.f1769f.f3556g;
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (mo2117a()) {
            return this.f1769f.f3558i;
        }
        return super.getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        if (mo2117a()) {
            return this.f1769f.f3557h;
        }
        return super.getSupportBackgroundTintMode();
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (Build.VERSION.SDK_INT < 21 && mo2117a()) {
            k20 k20 = this.f1769f;
            Objects.requireNonNull(k20);
            if (canvas != null && k20.f3559j != null && k20.f3556g > 0) {
                k20.f3562m.set(k20.f3550a.getBackground().getBounds());
                RectF rectF = k20.f3563n;
                Rect rect = k20.f3562m;
                float f = ((float) k20.f3556g) / 2.0f;
                rectF.set(((float) rect.left) + f + ((float) k20.f3551b), ((float) rect.top) + f + ((float) k20.f3553d), (((float) rect.right) - f) - ((float) k20.f3552c), (((float) rect.bottom) - f) - ((float) k20.f3554e));
                float f2 = ((float) k20.f3555f) - (((float) k20.f3556g) / 2.0f);
                canvas.drawRoundRect(k20.f3563n, f2, f2, k20.f3561l);
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        k20 k20;
        super.onLayout(z, i, i2, i3, i4);
        if (Build.VERSION.SDK_INT == 21 && (k20 = this.f1769f) != null) {
            int i5 = i4 - i2;
            int i6 = i3 - i;
            GradientDrawable gradientDrawable = k20.f3570u;
            if (gradientDrawable != null) {
                gradientDrawable.setBounds(k20.f3551b, k20.f3553d, i6 - k20.f3552c, i5 - k20.f3554e);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1773j != null && this.f1776m == 2) {
            int measureText = (int) getPaint().measureText(getText().toString());
            int i3 = this.f1774k;
            if (i3 == 0) {
                i3 = this.f1773j.getIntrinsicWidth();
            }
            int measuredWidth = getMeasuredWidth() - measureText;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            int paddingEnd = ((((measuredWidth - getPaddingEnd()) - i3) - this.f1770g) - getPaddingStart()) / 2;
            boolean z = true;
            if (getLayoutDirection() != 1) {
                z = false;
            }
            if (z) {
                paddingEnd = -paddingEnd;
            }
            if (this.f1775l != paddingEnd) {
                this.f1775l = paddingEnd;
                mo2118b();
            }
        }
    }

    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    public void setBackgroundColor(int i) {
        GradientDrawable gradientDrawable;
        GradientDrawable gradientDrawable2;
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            Objects.requireNonNull(k20);
            boolean z = k20.f3549w;
            if (z && (gradientDrawable2 = k20.f3568s) != null) {
                gradientDrawable2.setColor(i);
            } else if (!z && (gradientDrawable = k20.f3564o) != null) {
                gradientDrawable.setColor(i);
            }
        } else {
            super.setBackgroundColor(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (mo2117a()) {
            if (drawable != getBackground()) {
                Log.i("MaterialButton", "Setting a custom background is not supported.");
                k20 k20 = this.f1769f;
                k20.f3571v = true;
                k20.f3550a.setSupportBackgroundTintList(k20.f3558i);
                k20.f3550a.setSupportBackgroundTintMode(k20.f3557h);
            } else {
                getBackground().setState(drawable.getState());
                return;
            }
        }
        super.setBackgroundDrawable(drawable);
    }

    public void setBackgroundResource(int i) {
        setBackgroundDrawable(i != 0 ? C0001a0.m1b(getContext(), i) : null);
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    /* JADX WARNING: type inference failed for: r1v15, types: [android.graphics.drawable.Drawable] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setCornerRadius(int r8) {
        /*
            r7 = this;
            boolean r0 = r7.mo2117a()
            if (r0 == 0) goto L_0x00a8
            k20 r0 = r7.f1769f
            int r1 = r0.f3555f
            if (r1 == r8) goto L_0x00a8
            r0.f3555f = r8
            boolean r1 = p000.k20.f3549w
            r2 = 925353388(0x3727c5ac, float:1.0E-5)
            if (r1 == 0) goto L_0x008f
            android.graphics.drawable.GradientDrawable r3 = r0.f3568s
            if (r3 == 0) goto L_0x008f
            android.graphics.drawable.GradientDrawable r3 = r0.f3569t
            if (r3 == 0) goto L_0x008f
            android.graphics.drawable.GradientDrawable r3 = r0.f3570u
            if (r3 == 0) goto L_0x008f
            int r3 = android.os.Build.VERSION.SDK_INT
            r4 = 21
            if (r3 != r4) goto L_0x007d
            r3 = 0
            r4 = 0
            if (r1 == 0) goto L_0x004e
            com.google.android.material.button.MaterialButton r5 = r0.f3550a
            android.graphics.drawable.Drawable r5 = r5.getBackground()
            if (r5 == 0) goto L_0x004e
            com.google.android.material.button.MaterialButton r5 = r0.f3550a
            android.graphics.drawable.Drawable r5 = r5.getBackground()
            android.graphics.drawable.RippleDrawable r5 = (android.graphics.drawable.RippleDrawable) r5
            android.graphics.drawable.Drawable r5 = r5.getDrawable(r3)
            android.graphics.drawable.InsetDrawable r5 = (android.graphics.drawable.InsetDrawable) r5
            android.graphics.drawable.Drawable r5 = r5.getDrawable()
            android.graphics.drawable.LayerDrawable r5 = (android.graphics.drawable.LayerDrawable) r5
            android.graphics.drawable.Drawable r5 = r5.getDrawable(r3)
            android.graphics.drawable.GradientDrawable r5 = (android.graphics.drawable.GradientDrawable) r5
            goto L_0x004f
        L_0x004e:
            r5 = r4
        L_0x004f:
            float r6 = (float) r8
            float r6 = r6 + r2
            r5.setCornerRadius(r6)
            if (r1 == 0) goto L_0x007a
            com.google.android.material.button.MaterialButton r1 = r0.f3550a
            android.graphics.drawable.Drawable r1 = r1.getBackground()
            if (r1 == 0) goto L_0x007a
            com.google.android.material.button.MaterialButton r1 = r0.f3550a
            android.graphics.drawable.Drawable r1 = r1.getBackground()
            android.graphics.drawable.RippleDrawable r1 = (android.graphics.drawable.RippleDrawable) r1
            android.graphics.drawable.Drawable r1 = r1.getDrawable(r3)
            android.graphics.drawable.InsetDrawable r1 = (android.graphics.drawable.InsetDrawable) r1
            android.graphics.drawable.Drawable r1 = r1.getDrawable()
            android.graphics.drawable.LayerDrawable r1 = (android.graphics.drawable.LayerDrawable) r1
            r3 = 1
            android.graphics.drawable.Drawable r1 = r1.getDrawable(r3)
            r4 = r1
            android.graphics.drawable.GradientDrawable r4 = (android.graphics.drawable.GradientDrawable) r4
        L_0x007a:
            r4.setCornerRadius(r6)
        L_0x007d:
            android.graphics.drawable.GradientDrawable r1 = r0.f3568s
            float r8 = (float) r8
            float r8 = r8 + r2
            r1.setCornerRadius(r8)
            android.graphics.drawable.GradientDrawable r1 = r0.f3569t
            r1.setCornerRadius(r8)
            android.graphics.drawable.GradientDrawable r0 = r0.f3570u
            r0.setCornerRadius(r8)
            goto L_0x00a8
        L_0x008f:
            if (r1 != 0) goto L_0x00a8
            android.graphics.drawable.GradientDrawable r1 = r0.f3564o
            if (r1 == 0) goto L_0x00a8
            android.graphics.drawable.GradientDrawable r3 = r0.f3566q
            if (r3 == 0) goto L_0x00a8
            float r8 = (float) r8
            float r8 = r8 + r2
            r1.setCornerRadius(r8)
            android.graphics.drawable.GradientDrawable r1 = r0.f3566q
            r1.setCornerRadius(r8)
            com.google.android.material.button.MaterialButton r8 = r0.f3550a
            r8.invalidate()
        L_0x00a8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.button.MaterialButton.setCornerRadius(int):void");
    }

    public void setCornerRadiusResource(int i) {
        if (mo2117a()) {
            setCornerRadius(getResources().getDimensionPixelSize(i));
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.f1773j != drawable) {
            this.f1773j = drawable;
            mo2118b();
        }
    }

    public void setIconGravity(int i) {
        this.f1776m = i;
    }

    public void setIconPadding(int i) {
        if (this.f1770g != i) {
            this.f1770g = i;
            setCompoundDrawablePadding(i);
        }
    }

    public void setIconResource(int i) {
        setIcon(i != 0 ? C0001a0.m1b(getContext(), i) : null);
    }

    public void setIconSize(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        } else if (this.f1774k != i) {
            this.f1774k = i;
            mo2118b();
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f1772i != colorStateList) {
            this.f1772i = colorStateList;
            mo2118b();
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f1771h != mode) {
            this.f1771h = mode;
            mo2118b();
        }
    }

    public void setIconTintResource(int i) {
        setIconTint(C0001a0.m0a(getContext(), i));
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        Drawable drawable;
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            if (k20.f3560k != colorStateList) {
                k20.f3560k = colorStateList;
                boolean z = k20.f3549w;
                if (z && (k20.f3550a.getBackground() instanceof RippleDrawable)) {
                    ((RippleDrawable) k20.f3550a.getBackground()).setColor(colorStateList);
                } else if (!z && (drawable = k20.f3567r) != null) {
                    C1401p4.m4367i0(drawable, colorStateList);
                }
            }
        }
    }

    public void setRippleColorResource(int i) {
        if (mo2117a()) {
            setRippleColor(C0001a0.m0a(getContext(), i));
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            if (k20.f3559j != colorStateList) {
                k20.f3559j = colorStateList;
                Paint paint = k20.f3561l;
                int i = 0;
                if (colorStateList != null) {
                    i = colorStateList.getColorForState(k20.f3550a.getDrawableState(), 0);
                }
                paint.setColor(i);
                k20.mo4248b();
            }
        }
    }

    public void setStrokeColorResource(int i) {
        if (mo2117a()) {
            setStrokeColor(C0001a0.m0a(getContext(), i));
        }
    }

    public void setStrokeWidth(int i) {
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            if (k20.f3556g != i) {
                k20.f3556g = i;
                k20.f3561l.setStrokeWidth((float) i);
                k20.mo4248b();
            }
        }
    }

    public void setStrokeWidthResource(int i) {
        if (mo2117a()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i));
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            if (k20.f3558i != colorStateList) {
                k20.f3558i = colorStateList;
                if (k20.f3549w) {
                    k20.mo4249c();
                    return;
                }
                Drawable drawable = k20.f3565p;
                if (drawable != null) {
                    C1401p4.m4367i0(drawable, colorStateList);
                }
            }
        } else if (this.f1769f != null) {
            super.setSupportBackgroundTintList(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (mo2117a()) {
            k20 k20 = this.f1769f;
            if (k20.f3557h != mode) {
                k20.f3557h = mode;
                if (k20.f3549w) {
                    k20.mo4249c();
                    return;
                }
                Drawable drawable = k20.f3565p;
                if (drawable != null && mode != null) {
                    C1401p4.m4369j0(drawable, mode);
                }
            }
        } else if (this.f1769f != null) {
            super.setSupportBackgroundTintMode(mode);
        }
    }
}
