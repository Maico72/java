package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.roughike.bottombar.C0446R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;

@CoordinatorLayout.C0121d(Behavior.class)
public class FloatingActionButton extends g30 implements C2195z6, C1983w7, q20 {

    /* renamed from: e */
    public ColorStateList f1777e;

    /* renamed from: f */
    public PorterDuff.Mode f1778f;

    /* renamed from: g */
    public ColorStateList f1779g;

    /* renamed from: h */
    public PorterDuff.Mode f1780h;

    /* renamed from: i */
    public int f1781i;

    /* renamed from: j */
    public ColorStateList f1782j;

    /* renamed from: k */
    public int f1783k;

    /* renamed from: l */
    public int f1784l;

    /* renamed from: m */
    public int f1785m;

    /* renamed from: n */
    public int f1786n;

    /* renamed from: o */
    public boolean f1787o;

    /* renamed from: p */
    public final Rect f1788p = new Rect();

    /* renamed from: q */
    public final Rect f1789q = new Rect();

    /* renamed from: r */
    public final C1709s1 f1790r;

    /* renamed from: s */
    public final r20 f1791s;

    /* renamed from: t */
    public w20 f1792t;

    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.C0120c<T> {

        /* renamed from: a */
        public Rect f1793a;

        /* renamed from: b */
        public boolean f1794b;

        public BaseBehavior() {
            this.f1794b = true;
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o10.f4411e);
            this.f1794b = obtainStyledAttributes.getBoolean(0, true);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public boolean mo2215a(FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.f1788p;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        /* renamed from: b */
        public final boolean mo2216b(View view, FloatingActionButton floatingActionButton) {
            CoordinatorLayout.C0123f fVar = (CoordinatorLayout.C0123f) floatingActionButton.getLayoutParams();
            if (this.f1794b && fVar.f579f == view.getId() && floatingActionButton.getUserSetVisibility() == 0) {
                return true;
            }
            return false;
        }

        /* renamed from: c */
        public final boolean mo2217c(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!mo2216b(appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f1793a == null) {
                this.f1793a = new Rect();
            }
            Rect rect = this.f1793a;
            c30.m1262a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.mo2178h((C0404a) null, false);
                return true;
            }
            floatingActionButton.mo2185o((C0404a) null, false);
            return true;
        }

        /* renamed from: d */
        public final boolean mo2218d(View view, FloatingActionButton floatingActionButton) {
            if (!mo2216b(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < (floatingActionButton.getHeight() / 2) + ((CoordinatorLayout.C0123f) floatingActionButton.getLayoutParams()).topMargin) {
                floatingActionButton.mo2178h((C0404a) null, false);
                return true;
            }
            floatingActionButton.mo2185o((C0404a) null, false);
            return true;
        }

        public /* bridge */ /* synthetic */ boolean getInsetDodgeRect(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            return mo2215a((FloatingActionButton) view, rect);
        }

        public void onAttachedToLayoutParams(CoordinatorLayout.C0123f fVar) {
            if (fVar.f581h == 0) {
                fVar.f581h = 80;
            }
        }

        public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, View view, View view2) {
            FloatingActionButton floatingActionButton = (FloatingActionButton) view;
            if (view2 instanceof AppBarLayout) {
                mo2217c(coordinatorLayout, (AppBarLayout) view2, floatingActionButton);
            } else {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                if (layoutParams instanceof CoordinatorLayout.C0123f ? ((CoordinatorLayout.C0123f) layoutParams).f574a instanceof BottomSheetBehavior : false) {
                    mo2218d(view2, floatingActionButton);
                }
            }
            return false;
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, View view, int i) {
            FloatingActionButton floatingActionButton = (FloatingActionButton) view;
            List<View> e = coordinatorLayout.mo607e(floatingActionButton);
            int size = e.size();
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                View view2 = e.get(i3);
                if (!(view2 instanceof AppBarLayout)) {
                    ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                    if ((layoutParams instanceof CoordinatorLayout.C0123f ? ((CoordinatorLayout.C0123f) layoutParams).f574a instanceof BottomSheetBehavior : false) && mo2218d(view2, floatingActionButton)) {
                        break;
                    }
                } else if (mo2217c(coordinatorLayout, (AppBarLayout) view2, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.mo635s(floatingActionButton, i);
            Rect rect = floatingActionButton.f1788p;
            if (rect == null || rect.centerX() <= 0 || rect.centerY() <= 0) {
                return true;
            }
            CoordinatorLayout.C0123f fVar = (CoordinatorLayout.C0123f) floatingActionButton.getLayoutParams();
            int i4 = floatingActionButton.getRight() >= coordinatorLayout.getWidth() - fVar.rightMargin ? rect.right : floatingActionButton.getLeft() <= fVar.leftMargin ? -rect.left : 0;
            if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - fVar.bottomMargin) {
                i2 = rect.bottom;
            } else if (floatingActionButton.getTop() <= fVar.topMargin) {
                i2 = -rect.top;
            }
            if (i2 != 0) {
                C0010a7.m39l(floatingActionButton, i2);
            }
            if (i4 == 0) {
                return true;
            }
            C0010a7.m38k(floatingActionButton, i4);
            return true;
        }
    }

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    /* renamed from: com.google.android.material.floatingactionbutton.FloatingActionButton$a */
    public static abstract class C0404a {
    }

    /* renamed from: com.google.android.material.floatingactionbutton.FloatingActionButton$b */
    public class C0405b implements j30 {
        public C0405b() {
        }
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.floatingActionButtonStyle);
        int[] iArr = o10.f4410d;
        f30.m2143a(context, attributeSet, R.attr.floatingActionButtonStyle, C0446R.style.Widget_Design_FloatingActionButton);
        f30.m2144b(context, attributeSet, iArr, R.attr.floatingActionButtonStyle, C0446R.style.Widget_Design_FloatingActionButton, new int[0]);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.floatingActionButtonStyle, C0446R.style.Widget_Design_FloatingActionButton);
        this.f1777e = n10.m3815k(context, obtainStyledAttributes, 0);
        this.f1778f = n10.m3822r(obtainStyledAttributes.getInt(1, -1), (PorterDuff.Mode) null);
        this.f1782j = n10.m3815k(context, obtainStyledAttributes, 10);
        this.f1783k = obtainStyledAttributes.getInt(5, -1);
        this.f1784l = obtainStyledAttributes.getDimensionPixelSize(4, 0);
        this.f1781i = obtainStyledAttributes.getDimensionPixelSize(2, 0);
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(7, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(9, 0.0f);
        this.f1787o = obtainStyledAttributes.getBoolean(12, false);
        this.f1786n = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        v10 a = v10.m5325a(context, obtainStyledAttributes, 11);
        v10 a2 = v10.m5325a(context, obtainStyledAttributes, 6);
        obtainStyledAttributes.recycle();
        C1709s1 s1Var = new C1709s1(this);
        this.f1790r = s1Var;
        s1Var.mo5782c(attributeSet, R.attr.floatingActionButtonStyle);
        this.f1791s = new r20(this);
        getImpl().mo6406q(this.f1777e, this.f1778f, this.f1782j, this.f1781i);
        w20 impl = getImpl();
        if (impl.f6538n != dimension) {
            impl.f6538n = dimension;
            impl.mo6403n(dimension, impl.f6539o, impl.f6540p);
        }
        w20 impl2 = getImpl();
        if (impl2.f6539o != dimension2) {
            impl2.f6539o = dimension2;
            impl2.mo6403n(impl2.f6538n, dimension2, impl2.f6540p);
        }
        w20 impl3 = getImpl();
        if (impl3.f6540p != dimension3) {
            impl3.f6540p = dimension3;
            impl3.mo6403n(impl3.f6538n, impl3.f6539o, dimension3);
        }
        w20 impl4 = getImpl();
        int i = this.f1786n;
        if (impl4.f6541q != i) {
            impl4.f6541q = i;
            impl4.mo6407r(impl4.f6542r);
        }
        getImpl().f6527c = a;
        getImpl().f6528d = a2;
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    private w20 getImpl() {
        if (this.f1792t == null) {
            this.f1792t = Build.VERSION.SDK_INT >= 21 ? new x20(this, new C0405b()) : new w20(this, new C0405b());
        }
        return this.f1792t;
    }

    /* renamed from: n */
    public static int m1524n(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            return Math.min(i, size);
        }
        if (mode == 0) {
            return i;
        }
        if (mode == 1073741824) {
            return size;
        }
        throw new IllegalArgumentException();
    }

    /* renamed from: a */
    public boolean mo2157a() {
        return this.f1791s.f5413b;
    }

    /* renamed from: d */
    public void mo2158d(Animator.AnimatorListener animatorListener) {
        w20 impl = getImpl();
        if (impl.f6544t == null) {
            impl.f6544t = new ArrayList<>();
        }
        impl.f6544t.add((Object) null);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().mo6402m(getDrawableState());
    }

    /* renamed from: e */
    public void mo2160e(Animator.AnimatorListener animatorListener) {
        w20 impl = getImpl();
        if (impl.f6543s == null) {
            impl.f6543s = new ArrayList<>();
        }
        impl.f6543s.add((Object) null);
    }

    @Deprecated
    /* renamed from: f */
    public boolean mo2161f(Rect rect) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        if (!isLaidOut()) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        mo2180j(rect);
        return true;
    }

    /* renamed from: g */
    public final int mo2162g(int i) {
        int i2 = this.f1784l;
        if (i2 != 0) {
            return i2;
        }
        Resources resources = getResources();
        if (i == -1) {
            return Math.max(resources.getConfiguration().screenWidthDp, resources.getConfiguration().screenHeightDp) < 470 ? mo2162g(1) : mo2162g(0);
        }
        return resources.getDimensionPixelSize(i != 1 ? R.dimen.design_fab_size_normal : R.dimen.design_fab_size_mini);
    }

    public ColorStateList getBackgroundTintList() {
        return this.f1777e;
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return this.f1778f;
    }

    public float getCompatElevation() {
        return getImpl().mo6395f();
    }

    public float getCompatHoveredFocusedTranslationZ() {
        return getImpl().f6539o;
    }

    public float getCompatPressedTranslationZ() {
        return getImpl().f6540p;
    }

    public Drawable getContentBackground() {
        return getImpl().f6537m;
    }

    public int getCustomSize() {
        return this.f1784l;
    }

    public int getExpandedComponentIdHint() {
        return this.f1791s.f5414c;
    }

    public v10 getHideMotionSpec() {
        return getImpl().f6528d;
    }

    @Deprecated
    public int getRippleColor() {
        ColorStateList colorStateList = this.f1782j;
        if (colorStateList != null) {
            return colorStateList.getDefaultColor();
        }
        return 0;
    }

    public ColorStateList getRippleColorStateList() {
        return this.f1782j;
    }

    public v10 getShowMotionSpec() {
        return getImpl().f6527c;
    }

    public int getSize() {
        return this.f1783k;
    }

    public int getSizeDimension() {
        return mo2162g(this.f1783k);
    }

    public ColorStateList getSupportBackgroundTintList() {
        return getBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return getBackgroundTintMode();
    }

    public ColorStateList getSupportImageTintList() {
        return this.f1779g;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        return this.f1780h;
    }

    public boolean getUseCompatPadding() {
        return this.f1787o;
    }

    /* renamed from: h */
    public void mo2178h(C0404a aVar, boolean z) {
        w20 impl = getImpl();
        s20 s20 = aVar == null ? null : new s20(this);
        boolean z2 = false;
        if (impl.f6545u.getVisibility() != 0 ? impl.f6525a != 2 : impl.f6525a == 1) {
            z2 = true;
        }
        if (!z2) {
            Animator animator = impl.f6526b;
            if (animator != null) {
                animator.cancel();
            }
            if (impl.mo6409t()) {
                v10 v10 = impl.f6528d;
                if (v10 == null) {
                    if (impl.f6530f == null) {
                        impl.f6530f = v10.m5326b(impl.f6545u.getContext(), R.animator.design_fab_hide_motion_spec);
                    }
                    v10 = impl.f6530f;
                }
                AnimatorSet b = impl.mo6391b(v10, 0.0f, 0.0f, 0.0f);
                b.addListener(new t20(impl, z, s20));
                ArrayList<Animator.AnimatorListener> arrayList = impl.f6544t;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        b.addListener(it.next());
                    }
                }
                b.start();
                return;
            }
            impl.f6545u.mo3755b(z ? 8 : 4, z);
            if (s20 != null) {
                throw null;
            }
        }
    }

    /* renamed from: i */
    public boolean mo2179i() {
        return getImpl().mo6397h();
    }

    /* renamed from: j */
    public final void mo2180j(Rect rect) {
        int i = rect.left;
        Rect rect2 = this.f1788p;
        rect.left = i + rect2.left;
        rect.top += rect2.top;
        rect.right -= rect2.right;
        rect.bottom -= rect2.bottom;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().mo6398i();
    }

    /* renamed from: k */
    public final void mo2182k() {
        Drawable drawable = getDrawable();
        if (drawable != null) {
            ColorStateList colorStateList = this.f1779g;
            if (colorStateList == null) {
                C1401p4.m4364h(drawable);
                return;
            }
            int colorForState = colorStateList.getColorForState(getDrawableState(), 0);
            PorterDuff.Mode mode = this.f1780h;
            if (mode == null) {
                mode = PorterDuff.Mode.SRC_IN;
            }
            drawable.mutate().setColorFilter(C1391p1.m4300c(colorForState, mode));
        }
    }

    /* renamed from: l */
    public void mo2183l(Animator.AnimatorListener animatorListener) {
        ArrayList<Animator.AnimatorListener> arrayList = getImpl().f6544t;
        if (arrayList != null) {
            arrayList.remove((Object) null);
        }
    }

    /* renamed from: m */
    public void mo2184m(Animator.AnimatorListener animatorListener) {
        ArrayList<Animator.AnimatorListener> arrayList = getImpl().f6543s;
        if (arrayList != null) {
            arrayList.remove((Object) null);
        }
    }

    /* renamed from: o */
    public void mo2185o(C0404a aVar, boolean z) {
        w20 impl = getImpl();
        s20 s20 = aVar == null ? null : new s20(this);
        if (!impl.mo6397h()) {
            Animator animator = impl.f6526b;
            if (animator != null) {
                animator.cancel();
            }
            if (impl.mo6409t()) {
                if (impl.f6545u.getVisibility() != 0) {
                    impl.f6545u.setAlpha(0.0f);
                    impl.f6545u.setScaleY(0.0f);
                    impl.f6545u.setScaleX(0.0f);
                    impl.mo6407r(0.0f);
                }
                v10 v10 = impl.f6527c;
                if (v10 == null) {
                    if (impl.f6529e == null) {
                        impl.f6529e = v10.m5326b(impl.f6545u.getContext(), R.animator.design_fab_show_motion_spec);
                    }
                    v10 = impl.f6529e;
                }
                AnimatorSet b = impl.mo6391b(v10, 1.0f, 1.0f, 1.0f);
                b.addListener(new u20(impl, z, s20));
                ArrayList<Animator.AnimatorListener> arrayList = impl.f6543s;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        b.addListener(it.next());
                    }
                }
                b.start();
                return;
            }
            impl.f6545u.mo3755b(0, z);
            impl.f6545u.setAlpha(1.0f);
            impl.f6545u.setScaleY(1.0f);
            impl.f6545u.setScaleX(1.0f);
            impl.mo6407r(1.0f);
            if (s20 != null) {
                throw null;
            }
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        w20 impl = getImpl();
        if (impl.mo6405p()) {
            if (impl.f6524A == null) {
                impl.f6524A = new v20(impl);
            }
            impl.f6545u.getViewTreeObserver().addOnPreDrawListener(impl.f6524A);
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        w20 impl = getImpl();
        if (impl.f6524A != null) {
            impl.f6545u.getViewTreeObserver().removeOnPreDrawListener(impl.f6524A);
            impl.f6524A = null;
        }
    }

    public void onMeasure(int i, int i2) {
        int sizeDimension = getSizeDimension();
        this.f1785m = (sizeDimension - this.f1786n) / 2;
        getImpl().mo6410u();
        int min = Math.min(m1524n(sizeDimension, i), m1524n(sizeDimension, i2));
        Rect rect = this.f1788p;
        setMeasuredDimension(rect.left + min + rect.right, min + rect.top + rect.bottom);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof p30)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        p30 p30 = (p30) parcelable;
        super.onRestoreInstanceState(p30.f43d);
        r20 r20 = this.f1791s;
        Bundle orDefault = p30.f4773f.getOrDefault("expandableWidgetHelper", null);
        Objects.requireNonNull(r20);
        r20.f5413b = orDefault.getBoolean("expanded", false);
        r20.f5414c = orDefault.getInt("expandedComponentIdHint", 0);
        if (r20.f5413b) {
            ViewParent parent = r20.f5412a.getParent();
            if (parent instanceof CoordinatorLayout) {
                ((CoordinatorLayout) parent).mo602c(r20.f5412a);
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        p30 p30 = new p30(super.onSaveInstanceState());
        C0604e4<String, Bundle> e4Var = p30.f4773f;
        r20 r20 = this.f1791s;
        Objects.requireNonNull(r20);
        Bundle bundle = new Bundle();
        bundle.putBoolean("expanded", r20.f5413b);
        bundle.putInt("expandedComponentIdHint", r20.f5414c);
        e4Var.put("expandableWidgetHelper", bundle);
        return p30;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 || !mo2161f(this.f1789q) || this.f1789q.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    public void setBackgroundColor(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundDrawable(Drawable drawable) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundResource(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f1777e != colorStateList) {
            this.f1777e = colorStateList;
            w20 impl = getImpl();
            Drawable drawable = impl.f6534j;
            if (drawable != null) {
                C1401p4.m4367i0(drawable, colorStateList);
            }
            z20 z20 = impl.f6536l;
            if (z20 != null) {
                z20.mo6738a(colorStateList);
            }
        }
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        if (this.f1778f != mode) {
            this.f1778f = mode;
            Drawable drawable = getImpl().f6534j;
            if (drawable != null) {
                C1401p4.m4369j0(drawable, mode);
            }
        }
    }

    public void setCompatElevation(float f) {
        w20 impl = getImpl();
        if (impl.f6538n != f) {
            impl.f6538n = f;
            impl.mo6403n(f, impl.f6539o, impl.f6540p);
        }
    }

    public void setCompatElevationResource(int i) {
        setCompatElevation(getResources().getDimension(i));
    }

    public void setCompatHoveredFocusedTranslationZ(float f) {
        w20 impl = getImpl();
        if (impl.f6539o != f) {
            impl.f6539o = f;
            impl.mo6403n(impl.f6538n, f, impl.f6540p);
        }
    }

    public void setCompatHoveredFocusedTranslationZResource(int i) {
        setCompatHoveredFocusedTranslationZ(getResources().getDimension(i));
    }

    public void setCompatPressedTranslationZ(float f) {
        w20 impl = getImpl();
        if (impl.f6540p != f) {
            impl.f6540p = f;
            impl.mo6403n(impl.f6538n, impl.f6539o, f);
        }
    }

    public void setCompatPressedTranslationZResource(int i) {
        setCompatPressedTranslationZ(getResources().getDimension(i));
    }

    public void setCustomSize(int i) {
        if (i >= 0) {
            this.f1784l = i;
            return;
        }
        throw new IllegalArgumentException("Custom size must be non-negative");
    }

    public void setExpandedComponentIdHint(int i) {
        this.f1791s.f5414c = i;
    }

    public void setHideMotionSpec(v10 v10) {
        getImpl().f6528d = v10;
    }

    public void setHideMotionSpecResource(int i) {
        setHideMotionSpec(v10.m5326b(getContext(), i));
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        w20 impl = getImpl();
        impl.mo6407r(impl.f6542r);
    }

    public void setImageResource(int i) {
        this.f1790r.mo5783d(i);
    }

    public void setRippleColor(int i) {
        setRippleColor(ColorStateList.valueOf(i));
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (this.f1782j != colorStateList) {
            this.f1782j = colorStateList;
            getImpl().mo6408s(this.f1782j);
        }
    }

    public void setShowMotionSpec(v10 v10) {
        getImpl().f6527c = v10;
    }

    public void setShowMotionSpecResource(int i) {
        setShowMotionSpec(v10.m5326b(getContext(), i));
    }

    public void setSize(int i) {
        this.f1784l = 0;
        if (i != this.f1783k) {
            this.f1783k = i;
            requestLayout();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        setBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        setBackgroundTintMode(mode);
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f1779g != colorStateList) {
            this.f1779g = colorStateList;
            mo2182k();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        if (this.f1780h != mode) {
            this.f1780h = mode;
            mo2182k();
        }
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f1787o != z) {
            this.f1787o = z;
            getImpl().mo6401l();
        }
    }
}
