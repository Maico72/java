package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.WeakHashMap;

public class BottomAppBar extends Toolbar implements CoordinatorLayout.C0119b {

    /* renamed from: V */
    public static final /* synthetic */ int f1729V = 0;

    /* renamed from: Q */
    public Animator f1730Q;

    /* renamed from: R */
    public Animator f1731R;

    /* renamed from: S */
    public int f1732S;

    /* renamed from: T */
    public boolean f1733T;

    /* renamed from: U */
    public boolean f1734U;

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: d */
        public final Rect f1735d = new Rect();

        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: b */
        public void mo2079b(View view) {
            BottomAppBar bottomAppBar = (BottomAppBar) view;
            super.mo2079b(bottomAppBar);
            int i = BottomAppBar.f1729V;
            FloatingActionButton x = bottomAppBar.mo2098x();
            if (x != null) {
                x.mo2161f(this.f1735d);
                x.clearAnimation();
                x.animate().translationY(((float) (-x.getPaddingBottom())) + ((float) (x.getMeasuredHeight() - this.f1735d.height()))).setInterpolator(p10.f4735c).setDuration(175);
            }
        }

        /* renamed from: c */
        public void mo2080c(View view) {
            BottomAppBar bottomAppBar = (BottomAppBar) view;
            super.mo2080c(bottomAppBar);
            int i = BottomAppBar.f1729V;
            FloatingActionButton x = bottomAppBar.mo2098x();
            if (x != null) {
                x.clearAnimation();
                x.animate().translationY(bottomAppBar.getFabTranslationY()).setInterpolator(p10.f4736d).setDuration(225);
            }
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, View view, int i) {
            Animator animator;
            BottomAppBar bottomAppBar = (BottomAppBar) view;
            int i2 = BottomAppBar.f1729V;
            FloatingActionButton x = bottomAppBar.mo2098x();
            boolean z = false;
            if (x != null) {
                ((CoordinatorLayout.C0123f) x.getLayoutParams()).f577d = 17;
                x.mo2183l((Animator.AnimatorListener) null);
                x.mo2184m((Animator.AnimatorListener) null);
                x.mo2158d((Animator.AnimatorListener) null);
                x.mo2160e((Animator.AnimatorListener) null);
                Rect rect = this.f1735d;
                rect.set(0, 0, x.getMeasuredWidth(), x.getMeasuredHeight());
                x.mo2180j(rect);
                bottomAppBar.setFabDiameter(this.f1735d.height());
            }
            Animator animator2 = bottomAppBar.f1731R;
            if ((animator2 != null && animator2.isRunning()) || ((animator = bottomAppBar.f1730Q) != null && animator.isRunning())) {
                z = true;
            }
            if (z) {
                coordinatorLayout.mo635s(bottomAppBar, i);
                return super.onLayoutChild(coordinatorLayout, bottomAppBar, i);
            }
            BottomAppBar.m1497v(bottomAppBar);
            throw null;
        }

        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i, int i2) {
            BottomAppBar bottomAppBar = (BottomAppBar) view;
            return bottomAppBar.getHideOnScroll() && super.onStartNestedScroll(coordinatorLayout, bottomAppBar, view2, view3, i, i2);
        }
    }

    /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$a */
    public static class C0397a extends C0015a8 {
        public static final Parcelable.Creator<C0397a> CREATOR = new C0398a();

        /* renamed from: f */
        public int f1736f;

        /* renamed from: g */
        public boolean f1737g;

        /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$a$a */
        public static class C0398a implements Parcelable.ClassLoaderCreator<C0397a> {
            public Object createFromParcel(Parcel parcel) {
                return new C0397a(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0397a[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0397a(parcel, classLoader);
            }
        }

        public C0397a(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1736f = parcel.readInt();
            this.f1737g = parcel.readInt() != 0;
        }

        public C0397a(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeInt(this.f1736f);
            parcel.writeInt(this.f1737g ? 1 : 0);
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    private float getFabTranslationX() {
        return (float) mo2099y(this.f1732S);
    }

    /* access modifiers changed from: private */
    public float getFabTranslationY() {
        boolean z = this.f1734U;
        FloatingActionButton x = mo2098x();
        if (x == null) {
            return 0.0f;
        }
        Rect rect = new Rect();
        x.mo2161f(rect);
        float height = (float) rect.height();
        if (height == 0.0f) {
            height = (float) x.getMeasuredHeight();
        }
        float height2 = (float) (x.getHeight() - rect.height());
        float height3 = (height / 2.0f) + (-getCradleVerticalOffset()) + ((float) (x.getHeight() - rect.bottom));
        float paddingBottom = height2 - ((float) x.getPaddingBottom());
        float f = (float) (-getMeasuredHeight());
        if (!z) {
            height3 = paddingBottom;
        }
        return f + height3;
    }

    /* renamed from: v */
    public static void m1497v(BottomAppBar bottomAppBar) {
        bottomAppBar.getFabTranslationX();
        throw null;
    }

    /* renamed from: A */
    public final void mo2084A(ActionMenuView actionMenuView, int i, boolean z) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        boolean z2 = getLayoutDirection() == 1;
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if ((childAt.getLayoutParams() instanceof Toolbar.C0112e) && (((Toolbar.C0112e) childAt.getLayoutParams()).f2620a & 8388615) == 8388611) {
                i2 = Math.max(i2, z2 ? childAt.getLeft() : childAt.getRight());
            }
        }
        actionMenuView.setTranslationX((i != 1 || !z) ? 0.0f : (float) (i2 - (z2 ? actionMenuView.getRight() : actionMenuView.getLeft())));
    }

    public ColorStateList getBackgroundTint() {
        throw null;
    }

    public CoordinatorLayout.C0120c<BottomAppBar> getBehavior() {
        return new Behavior();
    }

    public float getCradleVerticalOffset() {
        throw null;
    }

    public int getFabAlignmentMode() {
        return this.f1732S;
    }

    public float getFabCradleMargin() {
        throw null;
    }

    public float getFabCradleRoundedCornerRadius() {
        throw null;
    }

    public boolean getHideOnScroll() {
        return this.f1733T;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        Animator animator = this.f1731R;
        if (animator != null) {
            animator.cancel();
        }
        Animator animator2 = this.f1730Q;
        if (animator2 != null) {
            animator2.cancel();
        }
        getFabTranslationX();
        throw null;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0397a)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0397a aVar = (C0397a) parcelable;
        super.onRestoreInstanceState(aVar.f43d);
        this.f1732S = aVar.f1736f;
        this.f1734U = aVar.f1737g;
    }

    public Parcelable onSaveInstanceState() {
        C0397a aVar = new C0397a(super.onSaveInstanceState());
        aVar.f1736f = this.f1732S;
        aVar.f1737g = this.f1734U;
        return aVar;
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        C1401p4.m4367i0((Drawable) null, colorStateList);
    }

    public void setCradleVerticalOffset(float f) {
        if (f != getCradleVerticalOffset()) {
            throw null;
        }
    }

    public void setFabAlignmentMode(int i) {
        int i2;
        if (this.f1732S != i) {
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            if (isLaidOut()) {
                Animator animator = this.f1730Q;
                if (animator != null) {
                    animator.cancel();
                }
                ArrayList arrayList = new ArrayList();
                if (!this.f1734U) {
                    ObjectAnimator ofFloat = ObjectAnimator.ofFloat(mo2098x(), "translationX", new float[]{(float) mo2099y(i)});
                    ofFloat.setDuration(300);
                    arrayList.add(ofFloat);
                    AnimatorSet animatorSet = new AnimatorSet();
                    animatorSet.playTogether(arrayList);
                    this.f1730Q = animatorSet;
                    animatorSet.addListener(new e20(this));
                    this.f1730Q.start();
                } else {
                    throw null;
                }
            }
        }
        boolean z = this.f1734U;
        WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
        if (isLaidOut()) {
            Animator animator2 = this.f1731R;
            if (animator2 != null) {
                animator2.cancel();
            }
            ArrayList arrayList2 = new ArrayList();
            if (!mo2100z()) {
                z = false;
                i2 = 0;
            } else {
                i2 = i;
            }
            ActionMenuView actionMenuView = getActionMenuView();
            if (actionMenuView != null) {
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{1.0f});
                if ((this.f1734U || (z && mo2100z())) && (this.f1732S == 1 || i2 == 1)) {
                    ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{0.0f});
                    ofFloat3.addListener(new g20(this, actionMenuView, i2, z));
                    AnimatorSet animatorSet2 = new AnimatorSet();
                    animatorSet2.setDuration(150);
                    animatorSet2.playSequentially(new Animator[]{ofFloat3, ofFloat2});
                    arrayList2.add(animatorSet2);
                } else if (actionMenuView.getAlpha() < 1.0f) {
                    arrayList2.add(ofFloat2);
                }
            }
            AnimatorSet animatorSet3 = new AnimatorSet();
            animatorSet3.playTogether(arrayList2);
            this.f1731R = animatorSet3;
            animatorSet3.addListener(new f20(this));
            this.f1731R.start();
        }
        this.f1732S = i;
    }

    public void setFabCradleMargin(float f) {
        if (f != getFabCradleMargin()) {
            throw null;
        }
    }

    public void setFabCradleRoundedCornerRadius(float f) {
        if (f != getFabCradleRoundedCornerRadius()) {
            throw null;
        }
    }

    public void setFabDiameter(int i) {
        throw null;
    }

    public void setHideOnScroll(boolean z) {
        this.f1733T = z;
    }

    public void setSubtitle(CharSequence charSequence) {
    }

    public void setTitle(CharSequence charSequence) {
    }

    /* renamed from: x */
    public final FloatingActionButton mo2098x() {
        if (!(getParent() instanceof CoordinatorLayout)) {
            return null;
        }
        for (View next : ((CoordinatorLayout) getParent()).mo608f(this)) {
            if (next instanceof FloatingActionButton) {
                return (FloatingActionButton) next;
            }
        }
        return null;
    }

    /* renamed from: y */
    public final int mo2099y(int i) {
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        int i2 = 1;
        boolean z = getLayoutDirection() == 1;
        if (i != 1) {
            return 0;
        }
        int measuredWidth = (getMeasuredWidth() / 2) - 0;
        if (z) {
            i2 = -1;
        }
        return measuredWidth * i2;
    }

    /* renamed from: z */
    public final boolean mo2100z() {
        FloatingActionButton x = mo2098x();
        return x != null && x.mo2179i();
    }
}
