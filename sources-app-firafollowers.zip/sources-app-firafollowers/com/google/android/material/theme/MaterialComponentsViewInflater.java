package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;
import com.google.android.material.button.MaterialButton;

@Keep
public class MaterialComponentsViewInflater extends C1965w {
    public C1154m1 createButton(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }
}
