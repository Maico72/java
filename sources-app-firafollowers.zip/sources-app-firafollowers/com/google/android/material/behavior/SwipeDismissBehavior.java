package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.Objects;
import java.util.WeakHashMap;
import p000.C0264b8;

public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.C0120c<V> {

    /* renamed from: a */
    public C0264b8 f1716a;

    /* renamed from: b */
    public boolean f1717b;

    /* renamed from: c */
    public int f1718c = 2;

    /* renamed from: d */
    public float f1719d = 0.5f;

    /* renamed from: e */
    public float f1720e = 0.0f;

    /* renamed from: f */
    public float f1721f = 0.5f;

    /* renamed from: g */
    public final C0264b8.C0267c f1722g = new C0395a();

    /* renamed from: com.google.android.material.behavior.SwipeDismissBehavior$a */
    public class C0395a extends C0264b8.C0267c {

        /* renamed from: a */
        public int f1723a;

        /* renamed from: b */
        public int f1724b = -1;

        public C0395a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0028, code lost:
            if (r5 != false) goto L_0x001e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0012, code lost:
            if (r5 != false) goto L_0x0014;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:8:0x001e, code lost:
            r5 = r2.f1723a;
            r3 = r3.getWidth() + r5;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo1651a(android.view.View r3, int r4, int r5) {
            /*
                r2 = this;
                java.util.WeakHashMap<android.view.View, java.lang.String> r5 = p000.C0010a7.f28a
                int r5 = r3.getLayoutDirection()
                r0 = 1
                if (r5 != r0) goto L_0x000b
                r5 = 1
                goto L_0x000c
            L_0x000b:
                r5 = 0
            L_0x000c:
                com.google.android.material.behavior.SwipeDismissBehavior r1 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r1 = r1.f1718c
                if (r1 != 0) goto L_0x0026
                if (r5 == 0) goto L_0x001e
            L_0x0014:
                int r5 = r2.f1723a
                int r3 = r3.getWidth()
                int r5 = r5 - r3
                int r3 = r2.f1723a
                goto L_0x0039
            L_0x001e:
                int r5 = r2.f1723a
                int r3 = r3.getWidth()
                int r3 = r3 + r5
                goto L_0x0039
            L_0x0026:
                if (r1 != r0) goto L_0x002b
                if (r5 == 0) goto L_0x0014
                goto L_0x001e
            L_0x002b:
                int r5 = r2.f1723a
                int r0 = r3.getWidth()
                int r5 = r5 - r0
                int r0 = r2.f1723a
                int r3 = r3.getWidth()
                int r3 = r3 + r0
            L_0x0039:
                int r4 = java.lang.Math.max(r5, r4)
                int r3 = java.lang.Math.min(r4, r3)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.C0395a.mo1651a(android.view.View, int, int):int");
        }

        /* renamed from: b */
        public int mo1652b(View view, int i, int i2) {
            return view.getTop();
        }

        /* renamed from: c */
        public int mo1653c(View view) {
            return view.getWidth();
        }

        /* renamed from: e */
        public void mo1655e(View view, int i) {
            this.f1724b = i;
            this.f1723a = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        /* renamed from: f */
        public void mo1656f(int i) {
            Objects.requireNonNull(SwipeDismissBehavior.this);
        }

        /* renamed from: g */
        public void mo1657g(View view, int i, int i2, int i3, int i4) {
            float width = (((float) view.getWidth()) * SwipeDismissBehavior.this.f1720e) + ((float) this.f1723a);
            float width2 = (((float) view.getWidth()) * SwipeDismissBehavior.this.f1721f) + ((float) this.f1723a);
            float f = (float) i;
            if (f <= width) {
                view.setAlpha(1.0f);
            } else if (f >= width2) {
                view.setAlpha(0.0f);
            } else {
                view.setAlpha(SwipeDismissBehavior.m1487b(0.0f, 1.0f - ((f - width) / (width2 - width)), 1.0f));
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:23:0x005a, code lost:
            if (java.lang.Math.abs(r7.getLeft() - r6.f1723a) >= java.lang.Math.round(((float) r7.getWidth()) * r6.f1725c.f1719d)) goto L_0x002e;
         */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x005f  */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x006c  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x007c  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0089  */
        /* renamed from: h */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1658h(android.view.View r7, float r8, float r9) {
            /*
                r6 = this;
                r9 = -1
                r6.f1724b = r9
                int r9 = r7.getWidth()
                r0 = 0
                r1 = 0
                r2 = 1
                int r3 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r3 == 0) goto L_0x0040
                java.util.WeakHashMap<android.view.View, java.lang.String> r3 = p000.C0010a7.f28a
                int r3 = r7.getLayoutDirection()
                if (r3 != r2) goto L_0x0018
                r3 = 1
                goto L_0x0019
            L_0x0018:
                r3 = 0
            L_0x0019:
                com.google.android.material.behavior.SwipeDismissBehavior r4 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r4 = r4.f1718c
                r5 = 2
                if (r4 != r5) goto L_0x0021
                goto L_0x002e
            L_0x0021:
                if (r4 != 0) goto L_0x0032
                if (r3 == 0) goto L_0x002a
                int r8 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r8 >= 0) goto L_0x0030
                goto L_0x002e
            L_0x002a:
                int r8 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r8 <= 0) goto L_0x0030
            L_0x002e:
                r8 = 1
                goto L_0x005d
            L_0x0030:
                r8 = 0
                goto L_0x005d
            L_0x0032:
                if (r4 != r2) goto L_0x0030
                if (r3 == 0) goto L_0x003b
                int r8 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r8 <= 0) goto L_0x0030
                goto L_0x003f
            L_0x003b:
                int r8 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
                if (r8 >= 0) goto L_0x0030
            L_0x003f:
                goto L_0x002e
            L_0x0040:
                int r8 = r7.getLeft()
                int r0 = r6.f1723a
                int r8 = r8 - r0
                int r0 = r7.getWidth()
                float r0 = (float) r0
                com.google.android.material.behavior.SwipeDismissBehavior r3 = com.google.android.material.behavior.SwipeDismissBehavior.this
                float r3 = r3.f1719d
                float r0 = r0 * r3
                int r0 = java.lang.Math.round(r0)
                int r8 = java.lang.Math.abs(r8)
                if (r8 < r0) goto L_0x0030
                goto L_0x002e
            L_0x005d:
                if (r8 == 0) goto L_0x006c
                int r8 = r7.getLeft()
                int r0 = r6.f1723a
                if (r8 >= r0) goto L_0x0069
                int r0 = r0 - r9
                goto L_0x006a
            L_0x0069:
                int r0 = r0 + r9
            L_0x006a:
                r1 = 1
                goto L_0x006e
            L_0x006c:
                int r0 = r6.f1723a
            L_0x006e:
                com.google.android.material.behavior.SwipeDismissBehavior r8 = com.google.android.material.behavior.SwipeDismissBehavior.this
                b8 r8 = r8.f1716a
                int r9 = r7.getTop()
                boolean r8 = r8.mo1645t(r0, r9)
                if (r8 == 0) goto L_0x0089
                com.google.android.material.behavior.SwipeDismissBehavior$b r8 = new com.google.android.material.behavior.SwipeDismissBehavior$b
                com.google.android.material.behavior.SwipeDismissBehavior r9 = com.google.android.material.behavior.SwipeDismissBehavior.this
                r8.<init>(r7, r1)
                java.util.WeakHashMap<android.view.View, java.lang.String> r9 = p000.C0010a7.f28a
                r7.postOnAnimation(r8)
                goto L_0x0090
            L_0x0089:
                if (r1 == 0) goto L_0x0090
                com.google.android.material.behavior.SwipeDismissBehavior r7 = com.google.android.material.behavior.SwipeDismissBehavior.this
                java.util.Objects.requireNonNull(r7)
            L_0x0090:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.C0395a.mo1658h(android.view.View, float, float):void");
        }

        /* renamed from: i */
        public boolean mo1659i(View view, int i) {
            return this.f1724b == -1 && SwipeDismissBehavior.this.mo2082a(view);
        }
    }

    /* renamed from: com.google.android.material.behavior.SwipeDismissBehavior$b */
    public class C0396b implements Runnable {

        /* renamed from: d */
        public final View f1726d;

        /* renamed from: e */
        public final boolean f1727e;

        public C0396b(View view, boolean z) {
            this.f1726d = view;
            this.f1727e = z;
        }

        public void run() {
            C0264b8 b8Var = SwipeDismissBehavior.this.f1716a;
            if (b8Var != null && b8Var.mo1634i(true)) {
                View view = this.f1726d;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                view.postOnAnimation(this);
            } else if (this.f1727e) {
                Objects.requireNonNull(SwipeDismissBehavior.this);
            }
        }
    }

    /* renamed from: b */
    public static float m1487b(float f, float f2, float f3) {
        return Math.min(Math.max(f, f2), f3);
    }

    /* renamed from: a */
    public boolean mo2082a(View view) {
        return true;
    }

    public boolean onInterceptTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = this.f1717b;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            z = coordinatorLayout.mo631q(v, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.f1717b = z;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f1717b = false;
        }
        if (!z) {
            return false;
        }
        if (this.f1716a == null) {
            this.f1716a = new C0264b8(coordinatorLayout.getContext(), coordinatorLayout, this.f1722g);
        }
        return this.f1716a.mo1646u(motionEvent);
    }

    public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        C0264b8 b8Var = this.f1716a;
        if (b8Var == null) {
            return false;
        }
        b8Var.mo1639n(motionEvent);
        return true;
    }
}
