package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

public class HideBottomViewOnScrollBehavior<V extends View> extends CoordinatorLayout.C0120c<V> {

    /* renamed from: a */
    public int f1712a = 0;

    /* renamed from: b */
    public int f1713b = 2;

    /* renamed from: c */
    public ViewPropertyAnimator f1714c;

    /* renamed from: com.google.android.material.behavior.HideBottomViewOnScrollBehavior$a */
    public class C0394a extends AnimatorListenerAdapter {
        public C0394a() {
        }

        public void onAnimationEnd(Animator animator) {
            HideBottomViewOnScrollBehavior.this.f1714c = null;
        }
    }

    public HideBottomViewOnScrollBehavior() {
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public final void mo2078a(V v, int i, long j, TimeInterpolator timeInterpolator) {
        this.f1714c = v.animate().translationY((float) i).setInterpolator(timeInterpolator).setDuration(j).setListener(new C0394a());
    }

    /* renamed from: b */
    public void mo2079b(V v) {
        ViewPropertyAnimator viewPropertyAnimator = this.f1714c;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
            v.clearAnimation();
        }
        this.f1713b = 1;
        mo2078a(v, this.f1712a, 175, p10.f4735c);
    }

    /* renamed from: c */
    public void mo2080c(V v) {
        ViewPropertyAnimator viewPropertyAnimator = this.f1714c;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
            v.clearAnimation();
        }
        this.f1713b = 2;
        mo2078a(v, 0, 225, p10.f4736d);
    }

    public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, V v, int i) {
        this.f1712a = v.getMeasuredHeight();
        return super.onLayoutChild(coordinatorLayout, v, i);
    }

    public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        int i5 = this.f1713b;
        if (i5 != 1 && i2 > 0) {
            mo2079b(v);
        } else if (i5 != 2 && i2 < 0) {
            mo2080c(v);
        }
    }

    public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        return i == 2;
    }
}
