package com.google.android.material.bottomsheet;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import p000.C0264b8;
import p000.i20;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.C0120c<V> {

    /* renamed from: a */
    public boolean f1738a = true;

    /* renamed from: b */
    public float f1739b;

    /* renamed from: c */
    public int f1740c;

    /* renamed from: d */
    public boolean f1741d;

    /* renamed from: e */
    public int f1742e;

    /* renamed from: f */
    public int f1743f;

    /* renamed from: g */
    public int f1744g;

    /* renamed from: h */
    public int f1745h;

    /* renamed from: i */
    public int f1746i;

    /* renamed from: j */
    public boolean f1747j;

    /* renamed from: k */
    public boolean f1748k;

    /* renamed from: l */
    public int f1749l = 4;

    /* renamed from: m */
    public C0264b8 f1750m;

    /* renamed from: n */
    public boolean f1751n;

    /* renamed from: o */
    public int f1752o;

    /* renamed from: p */
    public boolean f1753p;

    /* renamed from: q */
    public int f1754q;

    /* renamed from: r */
    public WeakReference<V> f1755r;

    /* renamed from: s */
    public WeakReference<View> f1756s;

    /* renamed from: t */
    public C0400b f1757t;

    /* renamed from: u */
    public VelocityTracker f1758u;

    /* renamed from: v */
    public int f1759v;

    /* renamed from: w */
    public int f1760w;

    /* renamed from: x */
    public boolean f1761x;

    /* renamed from: y */
    public Map<View, Integer> f1762y;

    /* renamed from: z */
    public final C0264b8.C0267c f1763z = new C0399a();

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$a */
    public class C0399a extends C0264b8.C0267c {
        public C0399a() {
        }

        /* renamed from: a */
        public int mo1651a(View view, int i, int i2) {
            return view.getLeft();
        }

        /* renamed from: b */
        public int mo1652b(View view, int i, int i2) {
            int d = BottomSheetBehavior.this.mo2107d();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return C1401p4.m4362g(i, d, bottomSheetBehavior.f1747j ? bottomSheetBehavior.f1754q : bottomSheetBehavior.f1746i);
        }

        /* renamed from: d */
        public int mo1654d(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.f1747j ? bottomSheetBehavior.f1754q : bottomSheetBehavior.f1746i;
        }

        /* renamed from: f */
        public void mo1656f(int i) {
            if (i == 1) {
                BottomSheetBehavior.this.mo2109f(1);
            }
        }

        /* renamed from: g */
        public void mo1657g(View view, int i, int i2, int i3, int i4) {
            BottomSheetBehavior.this.mo2105b(i2);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:29:0x0088, code lost:
            if (r7 < java.lang.Math.abs(r7 - r8.f1746i)) goto L_0x008a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x008a, code lost:
            r7 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x009b, code lost:
            if (java.lang.Math.abs(r7 - r1) < java.lang.Math.abs(r7 - r5.f1764a.f1746i)) goto L_0x009d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0019, code lost:
            if (r7 > r8) goto L_0x00a1;
         */
        /* JADX WARNING: Removed duplicated region for block: B:37:0x00b2  */
        /* JADX WARNING: Removed duplicated region for block: B:38:0x00c5  */
        /* renamed from: h */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1658h(android.view.View r6, float r7, float r8) {
            /*
                r5 = this;
                r0 = 3
                r1 = 0
                r2 = 4
                int r3 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
                if (r3 >= 0) goto L_0x001d
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r8 = r7.f1738a
                if (r8 == 0) goto L_0x0011
            L_0x000d:
                int r7 = r7.f1744g
                goto L_0x00a4
            L_0x0011:
                int r7 = r6.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.f1745h
                if (r7 <= r8) goto L_0x008a
                goto L_0x00a1
            L_0x001d:
                com.google.android.material.bottomsheet.BottomSheetBehavior r3 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r4 = r3.f1747j
                if (r4 == 0) goto L_0x0045
                boolean r3 = r3.mo2110g(r6, r8)
                if (r3 == 0) goto L_0x0045
                int r3 = r6.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r4 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r4 = r4.f1746i
                if (r3 > r4) goto L_0x003f
                float r3 = java.lang.Math.abs(r7)
                float r4 = java.lang.Math.abs(r8)
                int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
                if (r3 >= 0) goto L_0x0045
            L_0x003f:
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r7 = r7.f1754q
                r0 = 5
                goto L_0x00a4
            L_0x0045:
                int r1 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
                if (r1 == 0) goto L_0x005c
                float r7 = java.lang.Math.abs(r7)
                float r8 = java.lang.Math.abs(r8)
                int r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
                if (r7 <= 0) goto L_0x0056
                goto L_0x005c
            L_0x0056:
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r7 = r7.f1746i
                r0 = 4
                goto L_0x00a4
            L_0x005c:
                int r7 = r6.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r1 = r8.f1738a
                if (r1 == 0) goto L_0x007c
                int r8 = r8.f1744g
                int r8 = r7 - r8
                int r8 = java.lang.Math.abs(r8)
                com.google.android.material.bottomsheet.BottomSheetBehavior r1 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r1 = r1.f1746i
                int r7 = r7 - r1
                int r7 = java.lang.Math.abs(r7)
                if (r8 >= r7) goto L_0x0056
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                goto L_0x000d
            L_0x007c:
                int r1 = r8.f1745h
                if (r7 >= r1) goto L_0x008c
                int r8 = r8.f1746i
                int r8 = r7 - r8
                int r8 = java.lang.Math.abs(r8)
                if (r7 >= r8) goto L_0x009d
            L_0x008a:
                r7 = 0
                goto L_0x00a4
            L_0x008c:
                int r8 = r7 - r1
                int r8 = java.lang.Math.abs(r8)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.f1746i
                int r7 = r7 - r0
                int r7 = java.lang.Math.abs(r7)
                if (r8 >= r7) goto L_0x0056
            L_0x009d:
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r7.f1745h
            L_0x00a1:
                r7 = 6
                r7 = r8
                r0 = 6
            L_0x00a4:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                b8 r8 = r8.f1750m
                int r1 = r6.getLeft()
                boolean r7 = r8.mo1645t(r1, r7)
                if (r7 == 0) goto L_0x00c5
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                r8 = 2
                r7.mo2109f(r8)
                com.google.android.material.bottomsheet.BottomSheetBehavior$d r7 = new com.google.android.material.bottomsheet.BottomSheetBehavior$d
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                r7.<init>(r6, r0)
                java.util.WeakHashMap<android.view.View, java.lang.String> r8 = p000.C0010a7.f28a
                r6.postOnAnimation(r7)
                goto L_0x00ca
            L_0x00c5:
                com.google.android.material.bottomsheet.BottomSheetBehavior r6 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                r6.mo2109f(r0)
            L_0x00ca:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.C0399a.mo1658h(android.view.View, float, float):void");
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0015, code lost:
            r7 = (android.view.View) r0.f1756s.get();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0027, code lost:
            r7 = r5.f1764a.f1755r;
         */
        /* renamed from: i */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1659i(android.view.View r6, int r7) {
            /*
                r5 = this;
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r1 = r0.f1749l
                r2 = 0
                r3 = 1
                if (r1 != r3) goto L_0x0009
                return r2
            L_0x0009:
                boolean r4 = r0.f1761x
                if (r4 == 0) goto L_0x000e
                return r2
            L_0x000e:
                r4 = 3
                if (r1 != r4) goto L_0x0027
                int r1 = r0.f1759v
                if (r1 != r7) goto L_0x0027
                java.lang.ref.WeakReference<android.view.View> r7 = r0.f1756s
                java.lang.Object r7 = r7.get()
                android.view.View r7 = (android.view.View) r7
                if (r7 == 0) goto L_0x0027
                r0 = -1
                boolean r7 = r7.canScrollVertically(r0)
                if (r7 == 0) goto L_0x0027
                return r2
            L_0x0027:
                com.google.android.material.bottomsheet.BottomSheetBehavior r7 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                java.lang.ref.WeakReference<V> r7 = r7.f1755r
                if (r7 == 0) goto L_0x0034
                java.lang.Object r7 = r7.get()
                if (r7 != r6) goto L_0x0034
                r2 = 1
            L_0x0034:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.C0399a.mo1659i(android.view.View, int):boolean");
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$b */
    public static abstract class C0400b {
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$c */
    public static class C0401c extends C0015a8 {
        public static final Parcelable.Creator<C0401c> CREATOR = new C0402a();

        /* renamed from: f */
        public final int f1765f;

        /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$c$a */
        public static class C0402a implements Parcelable.ClassLoaderCreator<C0401c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0401c(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0401c[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0401c(parcel, classLoader);
            }
        }

        public C0401c(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1765f = parcel.readInt();
        }

        public C0401c(Parcelable parcelable, int i) {
            super(parcelable);
            this.f1765f = i;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f43d, i);
            parcel.writeInt(this.f1765f);
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$d */
    public class C0403d implements Runnable {

        /* renamed from: d */
        public final View f1766d;

        /* renamed from: e */
        public final int f1767e;

        public C0403d(View view, int i) {
            this.f1766d = view;
            this.f1767e = i;
        }

        public void run() {
            C0264b8 b8Var = BottomSheetBehavior.this.f1750m;
            if (b8Var == null || !b8Var.mo1634i(true)) {
                BottomSheetBehavior.this.mo2109f(this.f1767e);
                return;
            }
            View view = this.f1766d;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            view.postOnAnimation(this);
        }
    }

    public BottomSheetBehavior() {
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o10.f4409c);
        TypedValue peekValue = obtainStyledAttributes.peekValue(2);
        if (peekValue == null || (i = peekValue.data) != -1) {
            mo2108e(obtainStyledAttributes.getDimensionPixelSize(2, -1));
        } else {
            mo2108e(i);
        }
        this.f1747j = obtainStyledAttributes.getBoolean(1, false);
        boolean z = obtainStyledAttributes.getBoolean(0, true);
        if (this.f1738a != z) {
            this.f1738a = z;
            if (this.f1755r != null) {
                mo2104a();
            }
            mo2109f((!this.f1738a || this.f1749l != 6) ? this.f1749l : 3);
        }
        this.f1748k = obtainStyledAttributes.getBoolean(3, false);
        obtainStyledAttributes.recycle();
        this.f1739b = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    /* renamed from: a */
    public final void mo2104a() {
        this.f1746i = this.f1738a ? Math.max(this.f1754q - this.f1743f, this.f1744g) : this.f1754q - this.f1743f;
    }

    /* renamed from: b */
    public void mo2105b(int i) {
        C0400b bVar;
        if (((View) this.f1755r.get()) != null && (bVar = this.f1757t) != null) {
            i20.C0868d dVar = (i20.C0868d) bVar;
        }
    }

    /* renamed from: c */
    public View mo2106c(View view) {
        if (C0010a7.m37j(view)) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View c = mo2106c(viewGroup.getChildAt(i));
            if (c != null) {
                return c;
            }
        }
        return null;
    }

    /* renamed from: d */
    public final int mo2107d() {
        if (this.f1738a) {
            return this.f1744g;
        }
        return 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2108e(int r4) {
        /*
            r3 = this;
            r0 = 1
            r1 = 0
            r2 = -1
            if (r4 != r2) goto L_0x000c
            boolean r4 = r3.f1741d
            if (r4 != 0) goto L_0x0015
            r3.f1741d = r0
            goto L_0x0024
        L_0x000c:
            boolean r2 = r3.f1741d
            if (r2 != 0) goto L_0x0017
            int r2 = r3.f1740c
            if (r2 == r4) goto L_0x0015
            goto L_0x0017
        L_0x0015:
            r0 = 0
            goto L_0x0024
        L_0x0017:
            r3.f1741d = r1
            int r1 = java.lang.Math.max(r1, r4)
            r3.f1740c = r1
            int r1 = r3.f1754q
            int r1 = r1 - r4
            r3.f1746i = r1
        L_0x0024:
            if (r0 == 0) goto L_0x003a
            int r4 = r3.f1749l
            r0 = 4
            if (r4 != r0) goto L_0x003a
            java.lang.ref.WeakReference<V> r4 = r3.f1755r
            if (r4 == 0) goto L_0x003a
            java.lang.Object r4 = r4.get()
            android.view.View r4 = (android.view.View) r4
            if (r4 == 0) goto L_0x003a
            r4.requestLayout()
        L_0x003a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.mo2108e(int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2109f(int r3) {
        /*
            r2 = this;
            int r0 = r2.f1749l
            if (r0 != r3) goto L_0x0005
            return
        L_0x0005:
            r2.f1749l = r3
            r0 = 6
            r1 = 5
            if (r3 == r0) goto L_0x0016
            r0 = 3
            if (r3 != r0) goto L_0x000f
            goto L_0x0016
        L_0x000f:
            if (r3 == r1) goto L_0x0014
            r0 = 4
            if (r3 != r0) goto L_0x001a
        L_0x0014:
            r0 = 0
            goto L_0x0017
        L_0x0016:
            r0 = 1
        L_0x0017:
            r2.mo2112i(r0)
        L_0x001a:
            java.lang.ref.WeakReference<V> r0 = r2.f1755r
            java.lang.Object r0 = r0.get()
            android.view.View r0 = (android.view.View) r0
            if (r0 == 0) goto L_0x0034
            com.google.android.material.bottomsheet.BottomSheetBehavior$b r0 = r2.f1757t
            if (r0 == 0) goto L_0x0034
            i20$d r0 = (p000.i20.C0868d) r0
            java.util.Objects.requireNonNull(r0)
            if (r3 != r1) goto L_0x0034
            i20 r3 = p000.i20.this
            r3.cancel()
        L_0x0034:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.mo2109f(int):void");
    }

    /* renamed from: g */
    public boolean mo2110g(View view, float f) {
        if (this.f1748k) {
            return true;
        }
        if (view.getTop() < this.f1746i) {
            return false;
        }
        return Math.abs(((f * 0.1f) + ((float) view.getTop())) - ((float) this.f1746i)) / ((float) this.f1740c) > 0.5f;
    }

    /* renamed from: h */
    public void mo2111h(View view, int i) {
        int i2;
        int i3;
        if (i == 4) {
            i2 = this.f1746i;
        } else if (i == 6) {
            i2 = this.f1745h;
            if (this.f1738a && i2 <= (i3 = this.f1744g)) {
                i = 3;
                i2 = i3;
            }
        } else if (i == 3) {
            i2 = mo2107d();
        } else if (!this.f1747j || i != 5) {
            throw new IllegalArgumentException(C1012kd.m3199h("Illegal state argument: ", i));
        } else {
            i2 = this.f1754q;
        }
        if (this.f1750m.mo1647v(view, view.getLeft(), i2)) {
            mo2109f(2);
            C0403d dVar = new C0403d(view, i);
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            view.postOnAnimation(dVar);
            return;
        }
        mo2109f(i);
    }

    /* renamed from: i */
    public final void mo2112i(boolean z) {
        int i;
        WeakReference<V> weakReference = this.f1755r;
        if (weakReference != null) {
            ViewParent parent = ((View) weakReference.get()).getParent();
            if (parent instanceof CoordinatorLayout) {
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
                int childCount = coordinatorLayout.getChildCount();
                if (z) {
                    if (this.f1762y == null) {
                        this.f1762y = new HashMap(childCount);
                    } else {
                        return;
                    }
                }
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = coordinatorLayout.getChildAt(i2);
                    if (childAt != this.f1755r.get()) {
                        Map<View, Integer> map = this.f1762y;
                        if (z) {
                            map.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                            i = 4;
                        } else if (map != null && map.containsKey(childAt)) {
                            i = this.f1762y.get(childAt).intValue();
                        }
                        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                        childAt.setImportantForAccessibility(i);
                    }
                }
                if (!z) {
                    this.f1762y = null;
                }
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v12, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(androidx.coordinatorlayout.widget.CoordinatorLayout r9, V r10, android.view.MotionEvent r11) {
        /*
            r8 = this;
            boolean r0 = r10.isShown()
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x000b
            r8.f1751n = r2
            return r1
        L_0x000b:
            int r0 = r11.getActionMasked()
            r3 = 0
            r4 = -1
            if (r0 != 0) goto L_0x001e
            r8.f1759v = r4
            android.view.VelocityTracker r5 = r8.f1758u
            if (r5 == 0) goto L_0x001e
            r5.recycle()
            r8.f1758u = r3
        L_0x001e:
            android.view.VelocityTracker r5 = r8.f1758u
            if (r5 != 0) goto L_0x0028
            android.view.VelocityTracker r5 = android.view.VelocityTracker.obtain()
            r8.f1758u = r5
        L_0x0028:
            android.view.VelocityTracker r5 = r8.f1758u
            r5.addMovement(r11)
            if (r0 == 0) goto L_0x0040
            if (r0 == r2) goto L_0x0035
            r10 = 3
            if (r0 == r10) goto L_0x0035
            goto L_0x007f
        L_0x0035:
            r8.f1761x = r1
            r8.f1759v = r4
            boolean r10 = r8.f1751n
            if (r10 == 0) goto L_0x007f
            r8.f1751n = r1
            return r1
        L_0x0040:
            float r5 = r11.getX()
            int r5 = (int) r5
            float r6 = r11.getY()
            int r6 = (int) r6
            r8.f1760w = r6
            java.lang.ref.WeakReference<android.view.View> r6 = r8.f1756s
            if (r6 == 0) goto L_0x0057
            java.lang.Object r6 = r6.get()
            android.view.View r6 = (android.view.View) r6
            goto L_0x0058
        L_0x0057:
            r6 = r3
        L_0x0058:
            if (r6 == 0) goto L_0x006e
            int r7 = r8.f1760w
            boolean r6 = r9.mo631q(r6, r5, r7)
            if (r6 == 0) goto L_0x006e
            int r6 = r11.getActionIndex()
            int r6 = r11.getPointerId(r6)
            r8.f1759v = r6
            r8.f1761x = r2
        L_0x006e:
            int r6 = r8.f1759v
            if (r6 != r4) goto L_0x007c
            int r4 = r8.f1760w
            boolean r10 = r9.mo631q(r10, r5, r4)
            if (r10 != 0) goto L_0x007c
            r10 = 1
            goto L_0x007d
        L_0x007c:
            r10 = 0
        L_0x007d:
            r8.f1751n = r10
        L_0x007f:
            boolean r10 = r8.f1751n
            if (r10 != 0) goto L_0x008e
            b8 r10 = r8.f1750m
            if (r10 == 0) goto L_0x008e
            boolean r10 = r10.mo1646u(r11)
            if (r10 == 0) goto L_0x008e
            return r2
        L_0x008e:
            java.lang.ref.WeakReference<android.view.View> r10 = r8.f1756s
            if (r10 == 0) goto L_0x0099
            java.lang.Object r10 = r10.get()
            r3 = r10
            android.view.View r3 = (android.view.View) r3
        L_0x0099:
            r10 = 2
            if (r0 != r10) goto L_0x00d0
            if (r3 == 0) goto L_0x00d0
            boolean r10 = r8.f1751n
            if (r10 != 0) goto L_0x00d0
            int r10 = r8.f1749l
            if (r10 == r2) goto L_0x00d0
            float r10 = r11.getX()
            int r10 = (int) r10
            float r0 = r11.getY()
            int r0 = (int) r0
            boolean r9 = r9.mo631q(r3, r10, r0)
            if (r9 != 0) goto L_0x00d0
            b8 r9 = r8.f1750m
            if (r9 == 0) goto L_0x00d0
            int r9 = r8.f1760w
            float r9 = (float) r9
            float r10 = r11.getY()
            float r9 = r9 - r10
            float r9 = java.lang.Math.abs(r9)
            b8 r10 = r8.f1750m
            int r10 = r10.f1265b
            float r10 = (float) r10
            int r9 = (r9 > r10 ? 1 : (r9 == r10 ? 0 : -1))
            if (r9 <= 0) goto L_0x00d0
            r1 = 1
        L_0x00d0:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.onInterceptTouchEvent(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:32:0x0094  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onLayoutChild(androidx.coordinatorlayout.widget.CoordinatorLayout r5, V r6, int r7) {
        /*
            r4 = this;
            java.util.WeakHashMap<android.view.View, java.lang.String> r0 = p000.C0010a7.f28a
            boolean r0 = r5.getFitsSystemWindows()
            r1 = 1
            if (r0 == 0) goto L_0x0012
            boolean r0 = r6.getFitsSystemWindows()
            if (r0 != 0) goto L_0x0012
            r6.setFitsSystemWindows(r1)
        L_0x0012:
            int r0 = r6.getTop()
            r5.mo635s(r6, r7)
            int r7 = r5.getHeight()
            r4.f1754q = r7
            boolean r7 = r4.f1741d
            if (r7 == 0) goto L_0x0046
            int r7 = r4.f1742e
            if (r7 != 0) goto L_0x0034
            android.content.res.Resources r7 = r5.getResources()
            r2 = 2131099752(0x7f060068, float:1.7811866E38)
            int r7 = r7.getDimensionPixelSize(r2)
            r4.f1742e = r7
        L_0x0034:
            int r7 = r4.f1742e
            int r2 = r4.f1754q
            int r3 = r5.getWidth()
            int r3 = r3 * 9
            int r3 = r3 / 16
            int r2 = r2 - r3
            int r7 = java.lang.Math.max(r7, r2)
            goto L_0x0048
        L_0x0046:
            int r7 = r4.f1740c
        L_0x0048:
            r4.f1743f = r7
            r7 = 0
            int r2 = r4.f1754q
            int r3 = r6.getHeight()
            int r2 = r2 - r3
            int r7 = java.lang.Math.max(r7, r2)
            r4.f1744g = r7
            int r7 = r4.f1754q
            r2 = 2
            int r7 = r7 / r2
            r4.f1745h = r7
            r4.mo2104a()
            int r7 = r4.f1749l
            r3 = 3
            if (r7 != r3) goto L_0x006b
            int r7 = r4.mo2107d()
            goto L_0x0080
        L_0x006b:
            r3 = 6
            if (r7 != r3) goto L_0x0071
            int r7 = r4.f1745h
            goto L_0x0080
        L_0x0071:
            boolean r3 = r4.f1747j
            if (r3 == 0) goto L_0x007b
            r3 = 5
            if (r7 != r3) goto L_0x007b
            int r7 = r4.f1754q
            goto L_0x0080
        L_0x007b:
            r3 = 4
            if (r7 != r3) goto L_0x0084
            int r7 = r4.f1746i
        L_0x0080:
            p000.C0010a7.m39l(r6, r7)
            goto L_0x0090
        L_0x0084:
            if (r7 == r1) goto L_0x0088
            if (r7 != r2) goto L_0x0090
        L_0x0088:
            int r7 = r6.getTop()
            int r0 = r0 - r7
            p000.C0010a7.m39l(r6, r0)
        L_0x0090:
            b8 r7 = r4.f1750m
            if (r7 != 0) goto L_0x00a1
            b8$c r7 = r4.f1763z
            b8 r0 = new b8
            android.content.Context r2 = r5.getContext()
            r0.<init>(r2, r5, r7)
            r4.f1750m = r0
        L_0x00a1:
            java.lang.ref.WeakReference r5 = new java.lang.ref.WeakReference
            r5.<init>(r6)
            r4.f1755r = r5
            java.lang.ref.WeakReference r5 = new java.lang.ref.WeakReference
            android.view.View r6 = r4.mo2106c(r6)
            r5.<init>(r6)
            r4.f1756s = r5
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.onLayoutChild(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, int):boolean");
    }

    public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return view == this.f1756s.get() && (this.f1749l != 3 || super.onNestedPreFling(coordinatorLayout, v, view, f, f2));
    }

    public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
        int i4;
        if (i3 != 1 && view == ((View) this.f1756s.get())) {
            int top = v.getTop();
            int i5 = top - i2;
            if (i2 <= 0) {
                if (i2 < 0 && !view.canScrollVertically(-1)) {
                    int i6 = this.f1746i;
                    if (i5 <= i6 || this.f1747j) {
                        iArr[1] = i2;
                        C0010a7.m39l(v, -i2);
                        mo2109f(1);
                    } else {
                        iArr[1] = top - i6;
                        C0010a7.m39l(v, -iArr[1]);
                        i4 = 4;
                    }
                }
                mo2105b(v.getTop());
                this.f1752o = i2;
                this.f1753p = true;
            } else if (i5 < mo2107d()) {
                iArr[1] = top - mo2107d();
                C0010a7.m39l(v, -iArr[1]);
                i4 = 3;
            } else {
                iArr[1] = i2;
                C0010a7.m39l(v, -i2);
                mo2109f(1);
                mo2105b(v.getTop());
                this.f1752o = i2;
                this.f1753p = true;
            }
            mo2109f(i4);
            mo2105b(v.getTop());
            this.f1752o = i2;
            this.f1753p = true;
        }
    }

    public void onRestoreInstanceState(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        C0401c cVar = (C0401c) parcelable;
        super.onRestoreInstanceState(coordinatorLayout, v, cVar.f43d);
        int i = cVar.f1765f;
        if (i == 1 || i == 2) {
            i = 4;
        }
        this.f1749l = i;
    }

    public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, V v) {
        return new C0401c(super.onSaveInstanceState(coordinatorLayout, v), this.f1749l);
    }

    public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
        this.f1752o = 0;
        this.f1753p = false;
        return (i & 2) != 0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0087, code lost:
        if (java.lang.Math.abs(r3 - r6) < java.lang.Math.abs(r3 - r2.f1746i)) goto L_0x0089;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onStopNestedScroll(androidx.coordinatorlayout.widget.CoordinatorLayout r3, V r4, android.view.View r5, int r6) {
        /*
            r2 = this;
            int r3 = r4.getTop()
            int r6 = r2.mo2107d()
            r0 = 3
            if (r3 != r6) goto L_0x000f
            r2.mo2109f(r0)
            return
        L_0x000f:
            java.lang.ref.WeakReference<android.view.View> r3 = r2.f1756s
            java.lang.Object r3 = r3.get()
            if (r5 != r3) goto L_0x00b0
            boolean r3 = r2.f1753p
            if (r3 != 0) goto L_0x001d
            goto L_0x00b0
        L_0x001d:
            int r3 = r2.f1752o
            r5 = 0
            if (r3 <= 0) goto L_0x0027
            int r3 = r2.mo2107d()
            goto L_0x0090
        L_0x0027:
            boolean r3 = r2.f1747j
            if (r3 == 0) goto L_0x004a
            android.view.VelocityTracker r3 = r2.f1758u
            if (r3 != 0) goto L_0x0031
            r3 = 0
            goto L_0x0040
        L_0x0031:
            r6 = 1000(0x3e8, float:1.401E-42)
            float r1 = r2.f1739b
            r3.computeCurrentVelocity(r6, r1)
            android.view.VelocityTracker r3 = r2.f1758u
            int r6 = r2.f1759v
            float r3 = r3.getYVelocity(r6)
        L_0x0040:
            boolean r3 = r2.mo2110g(r4, r3)
            if (r3 == 0) goto L_0x004a
            int r3 = r2.f1754q
            r0 = 5
            goto L_0x0090
        L_0x004a:
            int r3 = r2.f1752o
            if (r3 != 0) goto L_0x008d
            int r3 = r4.getTop()
            boolean r6 = r2.f1738a
            if (r6 == 0) goto L_0x006a
            int r6 = r2.f1744g
            int r6 = r3 - r6
            int r6 = java.lang.Math.abs(r6)
            int r1 = r2.f1746i
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r6 >= r3) goto L_0x008d
            int r3 = r2.f1744g
            goto L_0x0090
        L_0x006a:
            int r6 = r2.f1745h
            if (r3 >= r6) goto L_0x007a
            int r6 = r2.f1746i
            int r6 = r3 - r6
            int r6 = java.lang.Math.abs(r6)
            if (r3 >= r6) goto L_0x0089
            r3 = 0
            goto L_0x0090
        L_0x007a:
            int r6 = r3 - r6
            int r6 = java.lang.Math.abs(r6)
            int r0 = r2.f1746i
            int r3 = r3 - r0
            int r3 = java.lang.Math.abs(r3)
            if (r6 >= r3) goto L_0x008d
        L_0x0089:
            int r3 = r2.f1745h
            r0 = 6
            goto L_0x0090
        L_0x008d:
            int r3 = r2.f1746i
            r0 = 4
        L_0x0090:
            b8 r6 = r2.f1750m
            int r1 = r4.getLeft()
            boolean r3 = r6.mo1647v(r4, r1, r3)
            if (r3 == 0) goto L_0x00ab
            r3 = 2
            r2.mo2109f(r3)
            com.google.android.material.bottomsheet.BottomSheetBehavior$d r3 = new com.google.android.material.bottomsheet.BottomSheetBehavior$d
            r3.<init>(r4, r0)
            java.util.WeakHashMap<android.view.View, java.lang.String> r6 = p000.C0010a7.f28a
            r4.postOnAnimation(r3)
            goto L_0x00ae
        L_0x00ab:
            r2.mo2109f(r0)
        L_0x00ae:
            r2.f1753p = r5
        L_0x00b0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.onStopNestedScroll(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f1749l == 1 && actionMasked == 0) {
            return true;
        }
        C0264b8 b8Var = this.f1750m;
        if (b8Var != null) {
            b8Var.mo1639n(motionEvent);
        }
        if (actionMasked == 0) {
            this.f1759v = -1;
            VelocityTracker velocityTracker = this.f1758u;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.f1758u = null;
            }
        }
        if (this.f1758u == null) {
            this.f1758u = VelocityTracker.obtain();
        }
        this.f1758u.addMovement(motionEvent);
        if (actionMasked == 2 && !this.f1751n) {
            float abs = Math.abs(((float) this.f1760w) - motionEvent.getY());
            C0264b8 b8Var2 = this.f1750m;
            if (abs > ((float) b8Var2.f1265b)) {
                b8Var2.mo1627b(v, motionEvent.getPointerId(motionEvent.getActionIndex()));
            }
        }
        return !this.f1751n;
    }
}
