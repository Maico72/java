package com.hcaptcha.sdk;

import java.io.Serializable;
import java.util.Locale;
import java.util.Objects;
import lombok.NonNull;

public class HCaptchaConfig implements Serializable {
    private String apiEndpoint;
    private String assethost;
    private String customTheme;
    private String endpoint;
    private String host;
    private String imghost;
    private Boolean loading;
    private String locale;
    private String reportapi;
    private String rqdata;
    private Boolean sentry;
    @NonNull
    private String siteKey;
    private j70 size;
    private k70 theme;

    /* renamed from: com.hcaptcha.sdk.HCaptchaConfig$a */
    public static class C0418a {

        /* renamed from: a */
        public String f1898a;

        /* renamed from: b */
        public boolean f1899b;

        /* renamed from: c */
        public Boolean f1900c;

        /* renamed from: d */
        public boolean f1901d;

        /* renamed from: e */
        public Boolean f1902e;

        /* renamed from: f */
        public String f1903f;

        /* renamed from: g */
        public boolean f1904g;

        /* renamed from: h */
        public String f1905h;

        /* renamed from: i */
        public String f1906i;

        /* renamed from: j */
        public String f1907j;

        /* renamed from: k */
        public String f1908k;

        /* renamed from: l */
        public String f1909l;

        /* renamed from: m */
        public boolean f1910m;

        /* renamed from: n */
        public String f1911n;

        /* renamed from: o */
        public boolean f1912o;

        /* renamed from: p */
        public j70 f1913p;

        /* renamed from: q */
        public boolean f1914q;

        /* renamed from: r */
        public k70 f1915r;

        /* renamed from: s */
        public boolean f1916s;

        /* renamed from: t */
        public String f1917t;

        /* renamed from: u */
        public boolean f1918u;

        /* renamed from: v */
        public String f1919v;

        public String toString() {
            StringBuilder d = C1012kd.m3195d("HCaptchaConfig.HCaptchaConfigBuilder(siteKey=");
            d.append(this.f1898a);
            d.append(", sentry$value=");
            d.append(this.f1900c);
            d.append(", loading$value=");
            d.append(this.f1902e);
            d.append(", rqdata=");
            d.append(this.f1903f);
            d.append(", apiEndpoint$value=");
            d.append(this.f1905h);
            d.append(", endpoint=");
            d.append(this.f1906i);
            d.append(", reportapi=");
            d.append(this.f1907j);
            d.append(", assethost=");
            d.append(this.f1908k);
            d.append(", imghost=");
            d.append(this.f1909l);
            d.append(", locale$value=");
            d.append(this.f1911n);
            d.append(", size$value=");
            d.append(this.f1913p);
            d.append(", theme$value=");
            d.append(this.f1915r);
            d.append(", host$value=");
            d.append(this.f1917t);
            d.append(", customTheme$value=");
            return C1012kd.m3204m(d, this.f1919v, ")");
        }
    }

    /* access modifiers changed from: private */
    public static String $default$apiEndpoint() {
        return "https://js.hcaptcha.com/1/api.js";
    }

    /* access modifiers changed from: private */
    public static String $default$customTheme() {
        return null;
    }

    /* access modifiers changed from: private */
    public static String $default$host() {
        return null;
    }

    /* access modifiers changed from: private */
    public static Boolean $default$loading() {
        return Boolean.TRUE;
    }

    /* access modifiers changed from: private */
    public static String $default$locale() {
        return Locale.getDefault().getLanguage();
    }

    /* access modifiers changed from: private */
    public static Boolean $default$sentry() {
        return Boolean.TRUE;
    }

    /* access modifiers changed from: private */
    public static j70 $default$size() {
        return j70.INVISIBLE;
    }

    /* access modifiers changed from: private */
    public static k70 $default$theme() {
        return k70.LIGHT;
    }

    public HCaptchaConfig(@NonNull String str, Boolean bool, Boolean bool2, String str2, String str3, String str4, String str5, String str6, String str7, String str8, j70 j70, k70 k70, String str9, String str10) {
        Objects.requireNonNull(str, "siteKey is marked non-null but is null");
        this.siteKey = str;
        this.sentry = bool;
        this.loading = bool2;
        this.rqdata = str2;
        this.apiEndpoint = str3;
        this.endpoint = str4;
        this.reportapi = str5;
        this.assethost = str6;
        this.imghost = str7;
        this.locale = str8;
        this.size = j70;
        this.theme = k70;
        this.host = str9;
        this.customTheme = str10;
    }

    public static C0418a builder() {
        return new C0418a();
    }

    public boolean canEqual(Object obj) {
        return obj instanceof HCaptchaConfig;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof HCaptchaConfig)) {
            return false;
        }
        HCaptchaConfig hCaptchaConfig = (HCaptchaConfig) obj;
        if (!hCaptchaConfig.canEqual(this)) {
            return false;
        }
        Boolean sentry2 = getSentry();
        Boolean sentry3 = hCaptchaConfig.getSentry();
        if (sentry2 != null ? !sentry2.equals(sentry3) : sentry3 != null) {
            return false;
        }
        Boolean loading2 = getLoading();
        Boolean loading3 = hCaptchaConfig.getLoading();
        if (loading2 != null ? !loading2.equals(loading3) : loading3 != null) {
            return false;
        }
        String siteKey2 = getSiteKey();
        String siteKey3 = hCaptchaConfig.getSiteKey();
        if (siteKey2 != null ? !siteKey2.equals(siteKey3) : siteKey3 != null) {
            return false;
        }
        String rqdata2 = getRqdata();
        String rqdata3 = hCaptchaConfig.getRqdata();
        if (rqdata2 != null ? !rqdata2.equals(rqdata3) : rqdata3 != null) {
            return false;
        }
        String apiEndpoint2 = getApiEndpoint();
        String apiEndpoint3 = hCaptchaConfig.getApiEndpoint();
        if (apiEndpoint2 != null ? !apiEndpoint2.equals(apiEndpoint3) : apiEndpoint3 != null) {
            return false;
        }
        String endpoint2 = getEndpoint();
        String endpoint3 = hCaptchaConfig.getEndpoint();
        if (endpoint2 != null ? !endpoint2.equals(endpoint3) : endpoint3 != null) {
            return false;
        }
        String reportapi2 = getReportapi();
        String reportapi3 = hCaptchaConfig.getReportapi();
        if (reportapi2 != null ? !reportapi2.equals(reportapi3) : reportapi3 != null) {
            return false;
        }
        String assethost2 = getAssethost();
        String assethost3 = hCaptchaConfig.getAssethost();
        if (assethost2 != null ? !assethost2.equals(assethost3) : assethost3 != null) {
            return false;
        }
        String imghost2 = getImghost();
        String imghost3 = hCaptchaConfig.getImghost();
        if (imghost2 != null ? !imghost2.equals(imghost3) : imghost3 != null) {
            return false;
        }
        String locale2 = getLocale();
        String locale3 = hCaptchaConfig.getLocale();
        if (locale2 != null ? !locale2.equals(locale3) : locale3 != null) {
            return false;
        }
        j70 size2 = getSize();
        j70 size3 = hCaptchaConfig.getSize();
        if (size2 != null ? !size2.equals(size3) : size3 != null) {
            return false;
        }
        k70 theme2 = getTheme();
        k70 theme3 = hCaptchaConfig.getTheme();
        if (theme2 != null ? !theme2.equals(theme3) : theme3 != null) {
            return false;
        }
        String host2 = getHost();
        String host3 = hCaptchaConfig.getHost();
        if (host2 != null ? !host2.equals(host3) : host3 != null) {
            return false;
        }
        String customTheme2 = getCustomTheme();
        String customTheme3 = hCaptchaConfig.getCustomTheme();
        return customTheme2 != null ? customTheme2.equals(customTheme3) : customTheme3 == null;
    }

    public String getApiEndpoint() {
        return this.apiEndpoint;
    }

    public String getAssethost() {
        return this.assethost;
    }

    public String getCustomTheme() {
        return this.customTheme;
    }

    public String getEndpoint() {
        return this.endpoint;
    }

    public String getHost() {
        return this.host;
    }

    public String getImghost() {
        return this.imghost;
    }

    public Boolean getLoading() {
        return this.loading;
    }

    public String getLocale() {
        return this.locale;
    }

    public String getReportapi() {
        return this.reportapi;
    }

    public String getRqdata() {
        return this.rqdata;
    }

    public Boolean getSentry() {
        return this.sentry;
    }

    @NonNull
    public String getSiteKey() {
        return this.siteKey;
    }

    public j70 getSize() {
        return this.size;
    }

    public k70 getTheme() {
        return this.theme;
    }

    public int hashCode() {
        Boolean sentry2 = getSentry();
        int i = 43;
        int hashCode = sentry2 == null ? 43 : sentry2.hashCode();
        Boolean loading2 = getLoading();
        int hashCode2 = ((hashCode + 59) * 59) + (loading2 == null ? 43 : loading2.hashCode());
        String siteKey2 = getSiteKey();
        int hashCode3 = (hashCode2 * 59) + (siteKey2 == null ? 43 : siteKey2.hashCode());
        String rqdata2 = getRqdata();
        int hashCode4 = (hashCode3 * 59) + (rqdata2 == null ? 43 : rqdata2.hashCode());
        String apiEndpoint2 = getApiEndpoint();
        int hashCode5 = (hashCode4 * 59) + (apiEndpoint2 == null ? 43 : apiEndpoint2.hashCode());
        String endpoint2 = getEndpoint();
        int hashCode6 = (hashCode5 * 59) + (endpoint2 == null ? 43 : endpoint2.hashCode());
        String reportapi2 = getReportapi();
        int hashCode7 = (hashCode6 * 59) + (reportapi2 == null ? 43 : reportapi2.hashCode());
        String assethost2 = getAssethost();
        int hashCode8 = (hashCode7 * 59) + (assethost2 == null ? 43 : assethost2.hashCode());
        String imghost2 = getImghost();
        int hashCode9 = (hashCode8 * 59) + (imghost2 == null ? 43 : imghost2.hashCode());
        String locale2 = getLocale();
        int hashCode10 = (hashCode9 * 59) + (locale2 == null ? 43 : locale2.hashCode());
        j70 size2 = getSize();
        int hashCode11 = (hashCode10 * 59) + (size2 == null ? 43 : size2.hashCode());
        k70 theme2 = getTheme();
        int hashCode12 = (hashCode11 * 59) + (theme2 == null ? 43 : theme2.hashCode());
        String host2 = getHost();
        int hashCode13 = (hashCode12 * 59) + (host2 == null ? 43 : host2.hashCode());
        String customTheme2 = getCustomTheme();
        int i2 = hashCode13 * 59;
        if (customTheme2 != null) {
            i = customTheme2.hashCode();
        }
        return i2 + i;
    }

    public void setApiEndpoint(String str) {
        this.apiEndpoint = str;
    }

    public void setAssethost(String str) {
        this.assethost = str;
    }

    public void setCustomTheme(String str) {
        this.customTheme = str;
    }

    public void setEndpoint(String str) {
        this.endpoint = str;
    }

    public void setHost(String str) {
        this.host = str;
    }

    public void setImghost(String str) {
        this.imghost = str;
    }

    public void setLoading(Boolean bool) {
        this.loading = bool;
    }

    public void setLocale(String str) {
        this.locale = str;
    }

    public void setReportapi(String str) {
        this.reportapi = str;
    }

    public void setRqdata(String str) {
        this.rqdata = str;
    }

    public void setSentry(Boolean bool) {
        this.sentry = bool;
    }

    public void setSiteKey(@NonNull String str) {
        Objects.requireNonNull(str, "siteKey is marked non-null but is null");
        this.siteKey = str;
    }

    public void setSize(j70 j70) {
        this.size = j70;
    }

    public void setTheme(k70 k70) {
        this.theme = k70;
    }

    public C0418a toBuilder() {
        C0418a aVar = new C0418a();
        String str = this.siteKey;
        Objects.requireNonNull(str, "siteKey is marked non-null but is null");
        aVar.f1898a = str;
        aVar.f1900c = this.sentry;
        aVar.f1899b = true;
        aVar.f1902e = this.loading;
        aVar.f1901d = true;
        aVar.f1903f = this.rqdata;
        aVar.f1905h = this.apiEndpoint;
        aVar.f1904g = true;
        aVar.f1906i = this.endpoint;
        aVar.f1907j = this.reportapi;
        aVar.f1908k = this.assethost;
        aVar.f1909l = this.imghost;
        aVar.f1911n = this.locale;
        aVar.f1910m = true;
        aVar.f1913p = this.size;
        aVar.f1912o = true;
        aVar.f1915r = this.theme;
        aVar.f1914q = true;
        aVar.f1917t = this.host;
        aVar.f1916s = true;
        aVar.f1919v = this.customTheme;
        aVar.f1918u = true;
        return aVar;
    }

    public String toString() {
        StringBuilder d = C1012kd.m3195d("HCaptchaConfig(siteKey=");
        d.append(getSiteKey());
        d.append(", sentry=");
        d.append(getSentry());
        d.append(", loading=");
        d.append(getLoading());
        d.append(", rqdata=");
        d.append(getRqdata());
        d.append(", apiEndpoint=");
        d.append(getApiEndpoint());
        d.append(", endpoint=");
        d.append(getEndpoint());
        d.append(", reportapi=");
        d.append(getReportapi());
        d.append(", assethost=");
        d.append(getAssethost());
        d.append(", imghost=");
        d.append(getImghost());
        d.append(", locale=");
        d.append(getLocale());
        d.append(", size=");
        d.append(getSize());
        d.append(", theme=");
        d.append(getTheme());
        d.append(", host=");
        d.append(getHost());
        d.append(", customTheme=");
        d.append(getCustomTheme());
        d.append(")");
        return d.toString();
    }
}
