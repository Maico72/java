package com.bumptech.glide;

import java.util.Set;

public abstract class GeneratedAppGlideModule extends C2158ym {
    /* renamed from: c */
    public abstract Set<Class<?>> mo1974c();
}
