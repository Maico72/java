package com.bumptech.glide.load;

import java.io.InputStream;
import java.nio.ByteBuffer;

public interface ImageHeaderParser {

    public enum ImageType {
        GIF(true),
        JPEG(false),
        RAW(false),
        PNG_A(true),
        PNG(false),
        WEBP_A(true),
        WEBP(false),
        UNKNOWN(false);
        

        /* renamed from: d */
        public final boolean f1632d;

        /* access modifiers changed from: public */
        ImageType(boolean z) {
            this.f1632d = z;
        }

        public boolean hasAlpha() {
            return this.f1632d;
        }
    }

    /* renamed from: a */
    ImageType mo1975a(ByteBuffer byteBuffer);

    /* renamed from: b */
    int mo1976b(InputStream inputStream, C2152yh yhVar);

    /* renamed from: c */
    ImageType mo1977c(InputStream inputStream);
}
