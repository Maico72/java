package com.bumptech.glide.load.data;

import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.IOException;
import p000.C0833hg;

public final class ParcelFileDescriptorRewinder implements C0833hg<ParcelFileDescriptor> {

    /* renamed from: a */
    public final InternalRewinder f1633a;

    public static final class InternalRewinder {

        /* renamed from: a */
        public final ParcelFileDescriptor f1634a;

        public InternalRewinder(ParcelFileDescriptor parcelFileDescriptor) {
            this.f1634a = parcelFileDescriptor;
        }

        public ParcelFileDescriptor rewind() {
            try {
                Os.lseek(this.f1634a.getFileDescriptor(), 0, OsConstants.SEEK_SET);
                return this.f1634a;
            } catch (ErrnoException e) {
                throw new IOException(e);
            }
        }
    }

    /* renamed from: com.bumptech.glide.load.data.ParcelFileDescriptorRewinder$a */
    public static final class C0382a implements C0833hg.C0834a<ParcelFileDescriptor> {
        /* renamed from: a */
        public Class<ParcelFileDescriptor> mo1983a() {
            return ParcelFileDescriptor.class;
        }

        /* renamed from: b */
        public C0833hg mo1984b(Object obj) {
            return new ParcelFileDescriptorRewinder((ParcelFileDescriptor) obj);
        }
    }

    public ParcelFileDescriptorRewinder(ParcelFileDescriptor parcelFileDescriptor) {
        this.f1633a = new InternalRewinder(parcelFileDescriptor);
    }

    /* renamed from: c */
    public static boolean m1385c() {
        return Build.VERSION.SDK_INT >= 21;
    }

    /* renamed from: b */
    public void mo1980b() {
    }

    /* renamed from: d */
    public ParcelFileDescriptor mo1979a() {
        return this.f1633a.rewind();
    }
}
