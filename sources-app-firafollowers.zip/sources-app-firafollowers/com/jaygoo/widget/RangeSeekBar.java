package com.jaygoo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RangeSeekBar extends View {

    /* renamed from: A */
    public float f1920A;

    /* renamed from: B */
    public float f1921B;

    /* renamed from: C */
    public float f1922C;

    /* renamed from: D */
    public int f1923D;

    /* renamed from: E */
    public boolean f1924E;

    /* renamed from: F */
    public int f1925F;

    /* renamed from: G */
    public float f1926G;

    /* renamed from: H */
    public float f1927H;

    /* renamed from: I */
    public boolean f1928I = true;

    /* renamed from: J */
    public float f1929J;

    /* renamed from: K */
    public float f1930K;

    /* renamed from: L */
    public boolean f1931L = false;

    /* renamed from: M */
    public Paint f1932M = new Paint();

    /* renamed from: N */
    public RectF f1933N = new RectF();

    /* renamed from: O */
    public RectF f1934O = new RectF();

    /* renamed from: P */
    public Rect f1935P = new Rect();

    /* renamed from: Q */
    public RectF f1936Q = new RectF();

    /* renamed from: R */
    public Rect f1937R = new Rect();

    /* renamed from: S */
    public t70 f1938S;

    /* renamed from: T */
    public t70 f1939T;

    /* renamed from: U */
    public t70 f1940U;

    /* renamed from: V */
    public Bitmap f1941V;

    /* renamed from: W */
    public Bitmap f1942W;

    /* renamed from: a0 */
    public List<Bitmap> f1943a0 = new ArrayList();

    /* renamed from: b0 */
    public int f1944b0;

    /* renamed from: c0 */
    public q70 f1945c0;

    /* renamed from: d */
    public int f1946d;

    /* renamed from: e */
    public int f1947e;

    /* renamed from: f */
    public int f1948f;

    /* renamed from: g */
    public int f1949g;

    /* renamed from: h */
    public int f1950h;

    /* renamed from: i */
    public int f1951i;

    /* renamed from: j */
    public int f1952j;

    /* renamed from: k */
    public int f1953k;

    /* renamed from: l */
    public int f1954l;

    /* renamed from: m */
    public int f1955m;

    /* renamed from: n */
    public int f1956n;

    /* renamed from: o */
    public int f1957o;

    /* renamed from: p */
    public CharSequence[] f1958p;

    /* renamed from: q */
    public float f1959q;

    /* renamed from: r */
    public int f1960r;

    /* renamed from: s */
    public int f1961s;

    /* renamed from: t */
    public int f1962t;

    /* renamed from: u */
    public int f1963u;

    /* renamed from: v */
    public int f1964v;

    /* renamed from: w */
    public int f1965w;

    /* renamed from: x */
    public float f1966x;

    /* renamed from: y */
    public int f1967y;

    /* renamed from: z */
    public int f1968z;

    public RangeSeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        boolean z = true;
        try {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, r70.f5447a);
            this.f1950h = obtainStyledAttributes.getInt(18, 2);
            this.f1926G = obtainStyledAttributes.getFloat(16, 0.0f);
            this.f1927H = obtainStyledAttributes.getFloat(15, 100.0f);
            this.f1966x = obtainStyledAttributes.getFloat(17, 0.0f);
            this.f1967y = obtainStyledAttributes.getInt(0, 0);
            this.f1960r = obtainStyledAttributes.getColor(19, -11806366);
            this.f1959q = (float) ((int) obtainStyledAttributes.getDimension(24, -1.0f));
            this.f1961s = obtainStyledAttributes.getColor(20, -2631721);
            this.f1962t = obtainStyledAttributes.getResourceId(21, 0);
            this.f1963u = obtainStyledAttributes.getResourceId(22, 0);
            this.f1964v = (int) obtainStyledAttributes.getDimension(23, (float) n10.m3811g(getContext(), 2.0f));
            this.f1951i = obtainStyledAttributes.getInt(40, 0);
            this.f1954l = obtainStyledAttributes.getInt(37, 1);
            this.f1955m = obtainStyledAttributes.getInt(39, 0);
            this.f1958p = obtainStyledAttributes.getTextArray(42);
            this.f1952j = (int) obtainStyledAttributes.getDimension(44, (float) n10.m3811g(getContext(), 7.0f));
            this.f1953k = (int) obtainStyledAttributes.getDimension(45, (float) n10.m3811g(getContext(), 12.0f));
            this.f1956n = obtainStyledAttributes.getColor(43, this.f1961s);
            this.f1957o = obtainStyledAttributes.getColor(43, this.f1960r);
            this.f1923D = obtainStyledAttributes.getInt(31, 0);
            this.f1968z = obtainStyledAttributes.getColor(26, -6447715);
            this.f1922C = obtainStyledAttributes.getDimension(29, 0.0f);
            this.f1920A = obtainStyledAttributes.getDimension(30, 0.0f);
            this.f1921B = obtainStyledAttributes.getDimension(28, 0.0f);
            this.f1925F = obtainStyledAttributes.getResourceId(27, 0);
            this.f1924E = obtainStyledAttributes.getBoolean(25, true);
            obtainStyledAttributes.recycle();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.f1932M.setStyle(Paint.Style.FILL);
        this.f1932M.setColor(this.f1961s);
        this.f1932M.setTextSize((float) this.f1953k);
        this.f1938S = new t70(this, attributeSet, true);
        t70 t70 = new t70(this, attributeSet, false);
        this.f1939T = t70;
        t70.f5848H = this.f1950h == 1 ? false : z;
        mo2391d();
    }

    /* renamed from: a */
    public float mo2388a(float f) {
        float f2 = 0.0f;
        if (this.f1940U == null) {
            return 0.0f;
        }
        float progressLeft = ((f - ((float) getProgressLeft())) * 1.0f) / ((float) this.f1965w);
        if (f >= ((float) getProgressLeft())) {
            f2 = f > ((float) getProgressRight()) ? 1.0f : progressLeft;
        }
        if (this.f1950h != 2) {
            return f2;
        }
        t70 t70 = this.f1940U;
        t70 t702 = this.f1938S;
        if (t70 == t702) {
            float f3 = this.f1939T.f5881x;
            float f4 = this.f1930K;
            return f2 > f3 - f4 ? f3 - f4 : f2;
        } else if (t70 != this.f1939T) {
            return f2;
        } else {
            float f5 = t702.f5881x;
            float f6 = this.f1930K;
            return f2 < f5 + f6 ? f5 + f6 : f2;
        }
    }

    /* renamed from: b */
    public final void mo2389b(boolean z) {
        t70 t70;
        boolean z2 = false;
        if (!z || (t70 = this.f1940U) == null) {
            this.f1938S.f5847G = false;
            if (this.f1950h == 2) {
                this.f1939T.f5847G = false;
                return;
            }
            return;
        }
        t70 t702 = this.f1938S;
        if (t70 == t702) {
            z2 = true;
        }
        t702.f5847G = z2;
        if (this.f1950h == 2) {
            this.f1939T.f5847G = !z2;
        }
    }

    /* renamed from: c */
    public final void mo2390c() {
        if (this.f1941V == null) {
            this.f1941V = n10.m3813i(getContext(), this.f1965w, this.f1964v, this.f1962t);
        }
        if (this.f1942W == null) {
            this.f1942W = n10.m3813i(getContext(), this.f1965w, this.f1964v, this.f1963u);
        }
    }

    /* renamed from: d */
    public final void mo2391d() {
        if (mo2433i() && this.f1925F != 0 && this.f1943a0.isEmpty()) {
            Bitmap i = n10.m3813i(getContext(), (int) this.f1920A, (int) this.f1921B, this.f1925F);
            for (int i2 = 0; i2 <= this.f1923D; i2++) {
                this.f1943a0.add(i);
            }
        }
    }

    /* renamed from: e */
    public final void mo2392e() {
        t70 t70 = this.f1940U;
        if (t70 != null && t70.f5876s > 1.0f && this.f1931L) {
            this.f1931L = false;
            t70.f5856P = t70.f5874q;
            t70.f5857Q = t70.f5875r;
            int progressBottom = t70.f5849I.getProgressBottom();
            int i = t70.f5857Q;
            int i2 = i / 2;
            t70.f5879v = progressBottom - i2;
            t70.f5880w = i2 + progressBottom;
            t70.mo5974o(t70.f5872o, t70.f5856P, i);
        }
    }

    /* renamed from: f */
    public final void mo2393f() {
        t70 t70 = this.f1940U;
        if (t70 != null && t70.f5876s > 1.0f && !this.f1931L) {
            this.f1931L = true;
            t70.f5856P = (int) t70.mo5968i();
            t70.f5857Q = (int) t70.mo5967h();
            int progressBottom = t70.f5849I.getProgressBottom();
            int i = t70.f5857Q;
            int i2 = i / 2;
            t70.f5879v = progressBottom - i2;
            t70.f5880w = i2 + progressBottom;
            t70.mo5974o(t70.f5872o, t70.f5856P, i);
        }
    }

    /* renamed from: g */
    public void mo2394g(float f, float f2) {
        float min = Math.min(f, f2);
        float max = Math.max(min, f2);
        float f3 = this.f1966x;
        if (max - min < f3) {
            min = max - f3;
        }
        float f4 = this.f1926G;
        if (min >= f4) {
            float f5 = this.f1927H;
            if (max <= f5) {
                float f6 = f5 - f4;
                this.f1938S.f5881x = Math.abs(min - f4) / f6;
                if (this.f1950h == 2) {
                    this.f1939T.f5881x = Math.abs(max - this.f1926G) / f6;
                }
                q70 q70 = this.f1945c0;
                if (q70 != null) {
                    q70.mo3794c(this, min, max, false);
                }
                invalidate();
                return;
            }
            throw new IllegalArgumentException("setProgress() max > (preset max - offsetValue) . #max:" + max + " #preset max:" + max);
        }
        throw new IllegalArgumentException("setProgress() min < (preset min - offsetValue) . #min:" + min + " #preset min:" + max);
    }

    public int getGravity() {
        return this.f1967y;
    }

    public t70 getLeftSeekBar() {
        return this.f1938S;
    }

    public float getMaxProgress() {
        return this.f1927H;
    }

    public float getMinInterval() {
        return this.f1966x;
    }

    public float getMinProgress() {
        return this.f1926G;
    }

    public int getProgressBottom() {
        return this.f1947e;
    }

    public int getProgressColor() {
        return this.f1960r;
    }

    public int getProgressDefaultColor() {
        return this.f1961s;
    }

    public int getProgressDefaultDrawableId() {
        return this.f1963u;
    }

    public int getProgressDrawableId() {
        return this.f1962t;
    }

    public int getProgressHeight() {
        return this.f1964v;
    }

    public int getProgressLeft() {
        return this.f1948f;
    }

    public int getProgressPaddingRight() {
        return this.f1944b0;
    }

    public float getProgressRadius() {
        return this.f1959q;
    }

    public int getProgressRight() {
        return this.f1949g;
    }

    public int getProgressTop() {
        return this.f1946d;
    }

    public int getProgressWidth() {
        return this.f1965w;
    }

    public u70[] getRangeSeekBarState() {
        u70 u70 = new u70();
        float e = this.f1938S.mo5964e();
        u70.f6124b = e;
        u70.f6123a = String.valueOf(e);
        if (n10.m3806b(u70.f6124b, this.f1926G) == 0) {
            u70.f6125c = true;
        } else if (n10.m3806b(u70.f6124b, this.f1927H) == 0) {
            u70.f6126d = true;
        }
        u70 u702 = new u70();
        if (this.f1950h == 2) {
            float e2 = this.f1939T.mo5964e();
            u702.f6124b = e2;
            u702.f6123a = String.valueOf(e2);
            if (n10.m3806b(this.f1939T.f5881x, this.f1926G) == 0) {
                u702.f6125c = true;
            } else if (n10.m3806b(this.f1939T.f5881x, this.f1927H) == 0) {
                u702.f6126d = true;
            }
        }
        return new u70[]{u70, u702};
    }

    public float getRawHeight() {
        if (this.f1950h == 1) {
            float f = this.f1938S.mo5965f();
            if (this.f1955m != 1 || this.f1958p == null) {
                return f;
            }
            return (((float) this.f1964v) / 2.0f) + (f - (this.f1938S.mo5967h() / 2.0f)) + Math.max((this.f1938S.mo5967h() - ((float) this.f1964v)) / 2.0f, (float) getTickMarkRawHeight());
        }
        float max = Math.max(this.f1938S.mo5965f(), this.f1939T.mo5965f());
        if (this.f1955m != 1 || this.f1958p == null) {
            return max;
        }
        float max2 = Math.max(this.f1938S.mo5967h(), this.f1939T.mo5967h());
        return (((float) this.f1964v) / 2.0f) + (max - (max2 / 2.0f)) + Math.max((max2 - ((float) this.f1964v)) / 2.0f, (float) getTickMarkRawHeight());
    }

    public t70 getRightSeekBar() {
        return this.f1939T;
    }

    public int getSeekBarMode() {
        return this.f1950h;
    }

    public int getSteps() {
        return this.f1923D;
    }

    public List<Bitmap> getStepsBitmaps() {
        return this.f1943a0;
    }

    public int getStepsColor() {
        return this.f1968z;
    }

    public int getStepsDrawableId() {
        return this.f1925F;
    }

    public float getStepsHeight() {
        return this.f1921B;
    }

    public float getStepsRadius() {
        return this.f1922C;
    }

    public float getStepsWidth() {
        return this.f1920A;
    }

    public int getTickMarkGravity() {
        return this.f1954l;
    }

    public int getTickMarkInRangeTextColor() {
        return this.f1957o;
    }

    public int getTickMarkLayoutGravity() {
        return this.f1955m;
    }

    public int getTickMarkMode() {
        return this.f1951i;
    }

    public int getTickMarkRawHeight() {
        CharSequence[] charSequenceArr = this.f1958p;
        if (charSequenceArr == null || charSequenceArr.length <= 0) {
            return 0;
        }
        return n10.m3820p(String.valueOf(charSequenceArr[0]), (float) this.f1953k).height() + this.f1952j + 3;
    }

    public CharSequence[] getTickMarkTextArray() {
        return this.f1958p;
    }

    public int getTickMarkTextColor() {
        return this.f1956n;
    }

    public int getTickMarkTextMargin() {
        return this.f1952j;
    }

    public int getTickMarkTextSize() {
        return this.f1953k;
    }

    /* renamed from: h */
    public void mo2432h(float f, float f2, float f3) {
        if (f2 <= f) {
            throw new IllegalArgumentException("setRange() max must be greater than min ! #max:" + f2 + " #min:" + f);
        } else if (f3 >= 0.0f) {
            float f4 = f2 - f;
            if (f3 < f4) {
                this.f1927H = f2;
                this.f1926G = f;
                this.f1966x = f3;
                float f5 = f3 / f4;
                this.f1930K = f5;
                if (this.f1950h == 2) {
                    t70 t70 = this.f1938S;
                    float f6 = t70.f5881x;
                    if (f6 + f5 <= 1.0f) {
                        t70 t702 = this.f1939T;
                        if (f6 + f5 > t702.f5881x) {
                            t702.f5881x = f6 + f5;
                        }
                    }
                    float f7 = this.f1939T.f5881x;
                    if (f7 - f5 >= 0.0f && f7 - f5 < f6) {
                        t70.f5881x = f7 - f5;
                    }
                }
                invalidate();
                return;
            }
            throw new IllegalArgumentException("setRange() interval must be less than (max - min) ! #minInterval:" + f3 + " #max - min:" + f4);
        } else {
            throw new IllegalArgumentException("setRange() interval must be greater than zero ! #minInterval:" + f3);
        }
    }

    /* renamed from: i */
    public final boolean mo2433i() {
        return this.f1923D >= 1 && this.f1921B > 0.0f && this.f1920A > 0.0f;
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x00a7  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00b0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(android.graphics.Canvas r14) {
        /*
            r13 = this;
            super.onDraw(r14)
            android.graphics.Paint r0 = r13.f1932M
            java.lang.CharSequence[] r1 = r13.f1958p
            r2 = 2
            r3 = 1073741824(0x40000000, float:2.0)
            r4 = 0
            r5 = 1
            if (r1 == 0) goto L_0x00c6
            int r6 = r13.f1965w
            int r1 = r1.length
            int r1 = r1 - r5
            int r6 = r6 / r1
            r1 = 0
        L_0x0014:
            java.lang.CharSequence[] r7 = r13.f1958p
            int r8 = r7.length
            if (r1 >= r8) goto L_0x00c6
            r7 = r7[r1]
            java.lang.String r7 = r7.toString()
            boolean r8 = android.text.TextUtils.isEmpty(r7)
            if (r8 == 0) goto L_0x0027
            goto L_0x00c2
        L_0x0027:
            int r8 = r7.length()
            android.graphics.Rect r9 = r13.f1937R
            r0.getTextBounds(r7, r4, r8, r9)
            int r8 = r13.f1956n
            r0.setColor(r8)
            int r8 = r13.f1951i
            if (r8 != r5) goto L_0x0060
            int r8 = r13.f1954l
            if (r8 != r2) goto L_0x004c
            int r8 = r13.getProgressLeft()
            int r9 = r1 * r6
            int r9 = r9 + r8
            android.graphics.Rect r8 = r13.f1937R
            int r8 = r8.width()
            int r9 = r9 - r8
            goto L_0x005e
        L_0x004c:
            if (r8 != r5) goto L_0x0057
            int r8 = r13.getProgressLeft()
            int r9 = r1 * r6
            int r9 = r9 + r8
            float r8 = (float) r9
            goto L_0x009a
        L_0x0057:
            int r8 = r13.getProgressLeft()
            int r9 = r1 * r6
            int r9 = r9 + r8
        L_0x005e:
            float r8 = (float) r9
            goto L_0x00a3
        L_0x0060:
            float r8 = java.lang.Float.parseFloat(r7)     // Catch:{ NumberFormatException -> 0x0065 }
            goto L_0x0066
        L_0x0065:
            r8 = 0
        L_0x0066:
            u70[] r9 = r13.getRangeSeekBarState()
            r10 = r9[r4]
            float r10 = r10.f6124b
            int r10 = p000.n10.m3806b(r8, r10)
            r11 = -1
            if (r10 == r11) goto L_0x0088
            r9 = r9[r5]
            float r9 = r9.f6124b
            int r9 = p000.n10.m3806b(r8, r9)
            if (r9 == r5) goto L_0x0088
            int r9 = r13.f1950h
            if (r9 != r2) goto L_0x0088
            int r9 = r13.f1957o
            r0.setColor(r9)
        L_0x0088:
            int r9 = r13.getProgressLeft()
            float r9 = (float) r9
            int r10 = r13.f1965w
            float r10 = (float) r10
            float r11 = r13.f1926G
            float r8 = r8 - r11
            float r8 = r8 * r10
            float r10 = r13.f1927H
            float r10 = r10 - r11
            float r8 = r8 / r10
            float r8 = r8 + r9
        L_0x009a:
            android.graphics.Rect r9 = r13.f1937R
            int r9 = r9.width()
            float r9 = (float) r9
            float r9 = r9 / r3
            float r8 = r8 - r9
        L_0x00a3:
            int r9 = r13.f1955m
            if (r9 != 0) goto L_0x00b0
            int r9 = r13.getProgressTop()
            int r10 = r13.f1952j
            int r9 = r9 - r10
            float r9 = (float) r9
            goto L_0x00bf
        L_0x00b0:
            int r9 = r13.getProgressBottom()
            int r10 = r13.f1952j
            int r9 = r9 + r10
            android.graphics.Rect r10 = r13.f1937R
            int r10 = r10.height()
            int r10 = r10 + r9
            float r9 = (float) r10
        L_0x00bf:
            r14.drawText(r7, r8, r9, r0)
        L_0x00c2:
            int r1 = r1 + 1
            goto L_0x0014
        L_0x00c6:
            android.graphics.Paint r0 = r13.f1932M
            android.graphics.Bitmap r1 = r13.f1942W
            boolean r1 = p000.n10.m3828x(r1)
            r6 = 0
            if (r1 == 0) goto L_0x00d9
            android.graphics.Bitmap r1 = r13.f1942W
            android.graphics.RectF r7 = r13.f1933N
            r14.drawBitmap(r1, r6, r7, r0)
            goto L_0x00e5
        L_0x00d9:
            int r1 = r13.f1961s
            r0.setColor(r1)
            android.graphics.RectF r1 = r13.f1933N
            float r7 = r13.f1959q
            r14.drawRoundRect(r1, r7, r7, r0)
        L_0x00e5:
            int r1 = r13.f1950h
            if (r1 != r2) goto L_0x011e
            android.graphics.RectF r1 = r13.f1934O
            int r7 = r13.getProgressTop()
            float r7 = (float) r7
            r1.top = r7
            android.graphics.RectF r1 = r13.f1934O
            t70 r7 = r13.f1938S
            int r8 = r7.f5877t
            float r8 = (float) r8
            float r7 = r7.mo5968i()
            float r7 = r7 / r3
            float r7 = r7 + r8
            int r8 = r13.f1965w
            float r8 = (float) r8
            t70 r9 = r13.f1938S
            float r9 = r9.f5881x
            float r8 = r8 * r9
            float r8 = r8 + r7
            r1.left = r8
            android.graphics.RectF r1 = r13.f1934O
            t70 r7 = r13.f1939T
            int r8 = r7.f5877t
            float r8 = (float) r8
            float r7 = r7.mo5968i()
            float r7 = r7 / r3
            float r7 = r7 + r8
            int r8 = r13.f1965w
            float r8 = (float) r8
            t70 r9 = r13.f1939T
            goto L_0x0148
        L_0x011e:
            android.graphics.RectF r1 = r13.f1934O
            int r7 = r13.getProgressTop()
            float r7 = (float) r7
            r1.top = r7
            android.graphics.RectF r1 = r13.f1934O
            t70 r7 = r13.f1938S
            int r8 = r7.f5877t
            float r8 = (float) r8
            float r7 = r7.mo5968i()
            float r7 = r7 / r3
            float r7 = r7 + r8
            r1.left = r7
            android.graphics.RectF r1 = r13.f1934O
            t70 r7 = r13.f1938S
            int r8 = r7.f5877t
            float r8 = (float) r8
            float r7 = r7.mo5968i()
            float r7 = r7 / r3
            float r7 = r7 + r8
            int r8 = r13.f1965w
            float r8 = (float) r8
            t70 r9 = r13.f1938S
        L_0x0148:
            float r9 = r9.f5881x
            float r8 = r8 * r9
            float r8 = r8 + r7
            r1.right = r8
            android.graphics.RectF r1 = r13.f1934O
            int r7 = r13.getProgressBottom()
            float r7 = (float) r7
            r1.bottom = r7
            android.graphics.Bitmap r1 = r13.f1941V
            boolean r1 = p000.n10.m3828x(r1)
            if (r1 == 0) goto L_0x019d
            android.graphics.Rect r0 = r13.f1935P
            r0.top = r4
            android.graphics.Bitmap r1 = r13.f1941V
            int r1 = r1.getHeight()
            r0.bottom = r1
            android.graphics.Bitmap r0 = r13.f1941V
            int r0 = r0.getWidth()
            int r1 = r13.f1950h
            if (r1 != r2) goto L_0x0185
            android.graphics.Rect r1 = r13.f1935P
            float r0 = (float) r0
            t70 r7 = r13.f1938S
            float r7 = r7.f5881x
            float r7 = r7 * r0
            int r7 = (int) r7
            r1.left = r7
            t70 r7 = r13.f1939T
            goto L_0x018c
        L_0x0185:
            android.graphics.Rect r1 = r13.f1935P
            r1.left = r4
            float r0 = (float) r0
            t70 r7 = r13.f1938S
        L_0x018c:
            float r7 = r7.f5881x
            float r0 = r0 * r7
            int r0 = (int) r0
            r1.right = r0
            android.graphics.Bitmap r0 = r13.f1941V
            android.graphics.Rect r1 = r13.f1935P
            android.graphics.RectF r7 = r13.f1934O
            r14.drawBitmap(r0, r1, r7, r6)
            goto L_0x01a9
        L_0x019d:
            int r1 = r13.f1960r
            r0.setColor(r1)
            android.graphics.RectF r1 = r13.f1934O
            float r7 = r13.f1959q
            r14.drawRoundRect(r1, r7, r7, r0)
        L_0x01a9:
            android.graphics.Paint r0 = r13.f1932M
            boolean r1 = r13.mo2433i()
            if (r1 != 0) goto L_0x01b2
            goto L_0x0214
        L_0x01b2:
            int r1 = r13.getProgressWidth()
            int r7 = r13.f1923D
            int r1 = r1 / r7
            float r7 = r13.f1921B
            int r8 = r13.getProgressHeight()
            float r8 = (float) r8
            float r7 = r7 - r8
            float r7 = r7 / r3
        L_0x01c2:
            int r8 = r13.f1923D
            if (r4 > r8) goto L_0x0214
            int r8 = r13.getProgressLeft()
            int r9 = r4 * r1
            int r9 = r9 + r8
            float r8 = (float) r9
            float r9 = r13.f1920A
            float r9 = r9 / r3
            float r8 = r8 - r9
            android.graphics.RectF r9 = r13.f1936Q
            int r10 = r13.getProgressTop()
            float r10 = (float) r10
            float r10 = r10 - r7
            float r11 = r13.f1920A
            float r11 = r11 + r8
            int r12 = r13.getProgressBottom()
            float r12 = (float) r12
            float r12 = r12 + r7
            r9.set(r8, r10, r11, r12)
            java.util.List<android.graphics.Bitmap> r8 = r13.f1943a0
            boolean r8 = r8.isEmpty()
            if (r8 != 0) goto L_0x0205
            java.util.List<android.graphics.Bitmap> r8 = r13.f1943a0
            int r8 = r8.size()
            if (r8 > r4) goto L_0x01f7
            goto L_0x0205
        L_0x01f7:
            java.util.List<android.graphics.Bitmap> r8 = r13.f1943a0
            java.lang.Object r8 = r8.get(r4)
            android.graphics.Bitmap r8 = (android.graphics.Bitmap) r8
            android.graphics.RectF r9 = r13.f1936Q
            r14.drawBitmap(r8, r6, r9, r0)
            goto L_0x0211
        L_0x0205:
            int r8 = r13.f1968z
            r0.setColor(r8)
            android.graphics.RectF r8 = r13.f1936Q
            float r9 = r13.f1922C
            r14.drawRoundRect(r8, r9, r9, r0)
        L_0x0211:
            int r4 = r4 + 1
            goto L_0x01c2
        L_0x0214:
            t70 r0 = r13.f1938S
            int r1 = r0.f5858a
            r3 = 3
            if (r1 != r3) goto L_0x021e
            r0.mo5973n(r5)
        L_0x021e:
            t70 r0 = r13.f1938S
            r0.mo5961b(r14)
            int r0 = r13.f1950h
            if (r0 != r2) goto L_0x0235
            t70 r0 = r13.f1939T
            int r1 = r0.f5858a
            if (r1 != r3) goto L_0x0230
            r0.mo5973n(r5)
        L_0x0230:
            t70 r0 = r13.f1939T
            r0.mo5961b(r14)
        L_0x0235:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.jaygoo.widget.RangeSeekBar.onDraw(android.graphics.Canvas):void");
    }

    public void onMeasure(int i, int i2) {
        int i3;
        float f;
        float f2;
        float f3;
        int size = View.MeasureSpec.getSize(i2);
        int mode = View.MeasureSpec.getMode(i2);
        if (mode == 1073741824) {
            i3 = View.MeasureSpec.makeMeasureSpec(size, 1073741824);
        } else if (mode == Integer.MIN_VALUE && (getParent() instanceof ViewGroup) && size == -1) {
            i3 = View.MeasureSpec.makeMeasureSpec(((ViewGroup) getParent()).getMeasuredHeight(), Integer.MIN_VALUE);
        } else {
            if (this.f1967y == 2) {
                if (this.f1958p == null || this.f1955m != 1) {
                    f2 = getRawHeight();
                    f3 = Math.max(this.f1938S.mo5967h(), this.f1939T.mo5967h()) / 2.0f;
                } else {
                    f2 = getRawHeight();
                    f3 = (float) getTickMarkRawHeight();
                }
                f = (f2 - f3) * 2.0f;
            } else {
                f = getRawHeight();
            }
            i3 = View.MeasureSpec.makeMeasureSpec((int) f, 1073741824);
        }
        super.onMeasure(i, i3);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        try {
            s70 s70 = (s70) parcelable;
            super.onRestoreInstanceState(s70.getSuperState());
            mo2432h(s70.f5683d, s70.f5684e, s70.f5685f);
            mo2394g(s70.f5687h, s70.f5688i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Parcelable onSaveInstanceState() {
        s70 s70 = new s70(super.onSaveInstanceState());
        s70.f5683d = this.f1926G;
        s70.f5684e = this.f1927H;
        s70.f5685f = this.f1966x;
        u70[] rangeSeekBarState = getRangeSeekBarState();
        s70.f5687h = rangeSeekBarState[0].f6124b;
        s70.f5688i = rangeSeekBarState[1].f6124b;
        return s70;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        float f;
        super.onSizeChanged(i, i2, i3, i4);
        int paddingBottom = (i2 - getPaddingBottom()) - getPaddingTop();
        if (i2 > 0) {
            int i5 = this.f1967y;
            if (i5 == 0) {
                t70 t70 = this.f1938S;
                if (t70.f5858a == 1 && this.f1939T.f5858a == 1) {
                    f = 0.0f;
                } else {
                    f = (float) Math.max(t70.mo5963d(), this.f1939T.mo5963d());
                }
                float max = Math.max(this.f1938S.mo5967h(), this.f1939T.mo5967h());
                float f2 = (float) this.f1964v;
                float f3 = max - (f2 / 2.0f);
                this.f1946d = (int) (((f3 - f2) / 2.0f) + f);
                if (this.f1958p != null && this.f1955m == 0) {
                    this.f1946d = (int) Math.max((float) getTickMarkRawHeight(), ((f3 - ((float) this.f1964v)) / 2.0f) + f);
                }
                this.f1947e = this.f1946d + this.f1964v;
            } else if (i5 == 1) {
                if (this.f1958p == null || this.f1955m != 1) {
                    this.f1947e = (int) ((((float) this.f1964v) / 2.0f) + (((float) paddingBottom) - (Math.max(this.f1938S.mo5967h(), this.f1939T.mo5967h()) / 2.0f)));
                } else {
                    this.f1947e = paddingBottom - getTickMarkRawHeight();
                }
                this.f1946d = this.f1947e - this.f1964v;
            } else {
                int i6 = this.f1964v;
                int i7 = (paddingBottom - i6) / 2;
                this.f1946d = i7;
                this.f1947e = i7 + i6;
            }
            int max2 = ((int) Math.max(this.f1938S.mo5968i(), this.f1939T.mo5968i())) / 2;
            this.f1948f = getPaddingLeft() + max2;
            int paddingRight = (i - max2) - getPaddingRight();
            this.f1949g = paddingRight;
            this.f1965w = paddingRight - this.f1948f;
            this.f1933N.set((float) getProgressLeft(), (float) getProgressTop(), (float) getProgressRight(), (float) getProgressBottom());
            this.f1944b0 = i - this.f1949g;
            if (this.f1959q <= 0.0f) {
                this.f1959q = (float) ((int) (((float) (getProgressBottom() - getProgressTop())) * 0.45f));
            }
            mo2390c();
        }
        mo2432h(this.f1926G, this.f1927H, this.f1966x);
        int progressTop = (getProgressTop() + getProgressBottom()) / 2;
        this.f1938S.mo5972m(getProgressLeft(), progressTop);
        if (this.f1950h == 2) {
            this.f1939T.mo5972m(getProgressLeft(), progressTop);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:101:0x0200  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x020b  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00af  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r9) {
        /*
            r8 = this;
            boolean r0 = r8.f1928I
            r1 = 1
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            int r0 = r9.getAction()
            r2 = 1065353216(0x3f800000, float:1.0)
            r3 = 2
            r4 = 0
            if (r0 == 0) goto L_0x0183
            if (r0 == r1) goto L_0x0105
            if (r0 == r3) goto L_0x005a
            r2 = 3
            if (r0 == r2) goto L_0x0019
            goto L_0x017e
        L_0x0019:
            int r0 = r8.f1950h
            if (r0 != r3) goto L_0x0022
            t70 r0 = r8.f1939T
            r0.mo5973n(r4)
        L_0x0022:
            t70 r0 = r8.f1940U
            t70 r2 = r8.f1938S
            if (r0 != r2) goto L_0x002c
        L_0x0028:
            r8.mo2392e()
            goto L_0x0031
        L_0x002c:
            t70 r2 = r8.f1939T
            if (r0 != r2) goto L_0x0031
            goto L_0x0028
        L_0x0031:
            t70 r0 = r8.f1938S
            r0.mo5973n(r4)
            q70 r0 = r8.f1945c0
            if (r0 == 0) goto L_0x004b
            u70[] r0 = r8.getRangeSeekBarState()
            q70 r2 = r8.f1945c0
            r3 = r0[r4]
            float r3 = r3.f6124b
            r0 = r0[r1]
            float r0 = r0.f6124b
            r2.mo3794c(r8, r3, r0, r4)
        L_0x004b:
            android.view.ViewParent r0 = r8.getParent()
            if (r0 == 0) goto L_0x017b
            android.view.ViewParent r0 = r8.getParent()
            r0.requestDisallowInterceptTouchEvent(r1)
            goto L_0x017b
        L_0x005a:
            float r0 = r9.getX()
            int r5 = r8.f1950h
            if (r5 != r3) goto L_0x00bb
            t70 r3 = r8.f1938S
            float r3 = r3.f5881x
            t70 r5 = r8.f1939T
            float r5 = r5.f5881x
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 != 0) goto L_0x00bb
            t70 r3 = r8.f1940U
            r3.mo5971l()
            q70 r3 = r8.f1945c0
            if (r3 == 0) goto L_0x0083
            t70 r5 = r8.f1940U
            t70 r6 = r8.f1938S
            if (r5 != r6) goto L_0x007f
            r5 = 1
            goto L_0x0080
        L_0x007f:
            r5 = 0
        L_0x0080:
            r3.mo3793b(r8, r5)
        L_0x0083:
            float r3 = r8.f1929J
            float r3 = r0 - r3
            r5 = 0
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 <= 0) goto L_0x009b
            t70 r3 = r8.f1940U
            t70 r5 = r8.f1939T
            if (r3 == r5) goto L_0x00ab
            r3.mo5973n(r4)
            r8.mo2392e()
            t70 r3 = r8.f1939T
            goto L_0x00a9
        L_0x009b:
            t70 r3 = r8.f1940U
            t70 r5 = r8.f1938S
            if (r3 == r5) goto L_0x00ab
            r3.mo5973n(r4)
            r8.mo2392e()
            t70 r3 = r8.f1938S
        L_0x00a9:
            r8.f1940U = r3
        L_0x00ab:
            q70 r3 = r8.f1945c0
            if (r3 == 0) goto L_0x00bb
            t70 r5 = r8.f1940U
            t70 r6 = r8.f1938S
            if (r5 != r6) goto L_0x00b7
            r5 = 1
            goto L_0x00b8
        L_0x00b7:
            r5 = 0
        L_0x00b8:
            r3.mo3792a(r8, r5)
        L_0x00bb:
            r8.mo2393f()
            t70 r3 = r8.f1940U
            float r5 = r3.f5882y
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 < 0) goto L_0x00c7
            goto L_0x00cb
        L_0x00c7:
            r2 = 1036831949(0x3dcccccd, float:0.1)
            float r2 = r2 + r5
        L_0x00cb:
            r3.f5882y = r2
            r8.f1929J = r0
            float r0 = r8.mo2388a(r0)
            r3.mo5975p(r0)
            t70 r0 = r8.f1940U
            r0.mo5973n(r1)
            q70 r0 = r8.f1945c0
            if (r0 == 0) goto L_0x00f0
            u70[] r0 = r8.getRangeSeekBarState()
            q70 r2 = r8.f1945c0
            r3 = r0[r4]
            float r3 = r3.f6124b
            r0 = r0[r1]
            float r0 = r0.f6124b
            r2.mo3794c(r8, r3, r0, r1)
        L_0x00f0:
            r8.invalidate()
            android.view.ViewParent r0 = r8.getParent()
            if (r0 == 0) goto L_0x0100
            android.view.ViewParent r0 = r8.getParent()
            r0.requestDisallowInterceptTouchEvent(r1)
        L_0x0100:
            r8.mo2389b(r1)
            goto L_0x017e
        L_0x0105:
            boolean r0 = r8.mo2433i()
            if (r0 == 0) goto L_0x0134
            boolean r0 = r8.f1924E
            if (r0 == 0) goto L_0x0134
            float r0 = r9.getX()
            float r0 = r8.mo2388a(r0)
            int r5 = r8.f1923D
            float r5 = (float) r5
            float r2 = r2 / r5
            java.math.BigDecimal r5 = new java.math.BigDecimal
            float r0 = r0 / r2
            double r6 = (double) r0
            r5.<init>(r6)
            java.math.RoundingMode r0 = java.math.RoundingMode.HALF_UP
            java.math.BigDecimal r0 = r5.setScale(r4, r0)
            int r0 = r0.intValue()
            t70 r5 = r8.f1940U
            float r0 = (float) r0
            float r0 = r0 * r2
            r5.mo5975p(r0)
        L_0x0134:
            int r0 = r8.f1950h
            if (r0 != r3) goto L_0x013d
            t70 r0 = r8.f1939T
            r0.mo5973n(r4)
        L_0x013d:
            t70 r0 = r8.f1938S
            r0.mo5973n(r4)
            t70 r0 = r8.f1940U
            r0.mo5971l()
            r8.mo2392e()
            q70 r0 = r8.f1945c0
            if (r0 == 0) goto L_0x015f
            u70[] r0 = r8.getRangeSeekBarState()
            q70 r2 = r8.f1945c0
            r3 = r0[r4]
            float r3 = r3.f6124b
            r0 = r0[r1]
            float r0 = r0.f6124b
            r2.mo3794c(r8, r3, r0, r4)
        L_0x015f:
            android.view.ViewParent r0 = r8.getParent()
            if (r0 == 0) goto L_0x016c
            android.view.ViewParent r0 = r8.getParent()
            r0.requestDisallowInterceptTouchEvent(r1)
        L_0x016c:
            q70 r0 = r8.f1945c0
            if (r0 == 0) goto L_0x017b
            t70 r2 = r8.f1940U
            t70 r3 = r8.f1938S
            if (r2 != r3) goto L_0x0177
            goto L_0x0178
        L_0x0177:
            r1 = 0
        L_0x0178:
            r0.mo3793b(r8, r1)
        L_0x017b:
            r8.mo2389b(r4)
        L_0x017e:
            boolean r9 = super.onTouchEvent(r9)
            return r9
        L_0x0183:
            float r0 = r9.getX()
            r8.f1929J = r0
            r9.getY()
            int r0 = r8.f1950h
            if (r0 != r3) goto L_0x01f3
            t70 r0 = r8.f1939T
            float r0 = r0.f5881x
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 < 0) goto L_0x01a9
            t70 r0 = r8.f1938S
            float r3 = r9.getX()
            float r5 = r9.getY()
            boolean r0 = r0.mo5960a(r3, r5)
            if (r0 == 0) goto L_0x01a9
            goto L_0x01f3
        L_0x01a9:
            t70 r0 = r8.f1939T
            float r3 = r9.getX()
            float r9 = r9.getY()
            boolean r9 = r0.mo5960a(r3, r9)
            if (r9 == 0) goto L_0x01bc
            t70 r9 = r8.f1939T
            goto L_0x01f5
        L_0x01bc:
            float r9 = r8.f1929J
            int r0 = r8.getProgressLeft()
            float r0 = (float) r0
            float r9 = r9 - r0
            float r9 = r9 * r2
            int r0 = r8.f1965w
            float r0 = (float) r0
            float r9 = r9 / r0
            t70 r0 = r8.f1938S
            float r0 = r0.f5881x
            float r0 = r0 - r9
            float r0 = java.lang.Math.abs(r0)
            t70 r2 = r8.f1939T
            float r2 = r2.f5881x
            float r2 = r2 - r9
            float r9 = java.lang.Math.abs(r2)
            int r9 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r9 >= 0) goto L_0x01e3
            t70 r9 = r8.f1938S
            goto L_0x01e5
        L_0x01e3:
            t70 r9 = r8.f1939T
        L_0x01e5:
            r8.f1940U = r9
            float r9 = r8.f1929J
            float r9 = r8.mo2388a(r9)
            t70 r0 = r8.f1940U
            r0.mo5975p(r9)
            goto L_0x01fa
        L_0x01f3:
            t70 r9 = r8.f1938S
        L_0x01f5:
            r8.f1940U = r9
            r8.mo2393f()
        L_0x01fa:
            android.view.ViewParent r9 = r8.getParent()
            if (r9 == 0) goto L_0x0207
            android.view.ViewParent r9 = r8.getParent()
            r9.requestDisallowInterceptTouchEvent(r1)
        L_0x0207:
            q70 r9 = r8.f1945c0
            if (r9 == 0) goto L_0x0215
            t70 r0 = r8.f1940U
            t70 r2 = r8.f1938S
            if (r0 != r2) goto L_0x0212
            r4 = 1
        L_0x0212:
            r9.mo3792a(r8, r4)
        L_0x0215:
            r8.mo2389b(r1)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.jaygoo.widget.RangeSeekBar.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setEnableThumbOverlap(boolean z) {
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        this.f1928I = z;
    }

    public void setGravity(int i) {
        this.f1967y = i;
    }

    public void setIndicatorText(String str) {
        this.f1938S.f5846F = str;
        if (this.f1950h == 2) {
            this.f1939T.f5846F = str;
        }
    }

    public void setIndicatorTextDecimalFormat(String str) {
        t70 t70 = this.f1938S;
        Objects.requireNonNull(t70);
        t70.f5855O = new DecimalFormat(str);
        if (this.f1950h == 2) {
            t70 t702 = this.f1939T;
            Objects.requireNonNull(t702);
            t702.f5855O = new DecimalFormat(str);
        }
    }

    public void setIndicatorTextStringFormat(String str) {
        this.f1938S.f5850J = str;
        if (this.f1950h == 2) {
            this.f1939T.f5850J = str;
        }
    }

    public void setOnRangeChangedListener(q70 q70) {
        this.f1945c0 = q70;
    }

    public void setProgress(float f) {
        mo2394g(f, this.f1927H);
    }

    public void setProgressBottom(int i) {
        this.f1947e = i;
    }

    public void setProgressColor(int i) {
        this.f1960r = i;
    }

    public void setProgressDefaultColor(int i) {
        this.f1961s = i;
    }

    public void setProgressDefaultDrawableId(int i) {
        this.f1963u = i;
        this.f1942W = null;
        mo2390c();
    }

    public void setProgressDrawableId(int i) {
        this.f1962t = i;
        this.f1941V = null;
        mo2390c();
    }

    public void setProgressHeight(int i) {
        this.f1964v = i;
    }

    public void setProgressLeft(int i) {
        this.f1948f = i;
    }

    public void setProgressRadius(float f) {
        this.f1959q = f;
    }

    public void setProgressRight(int i) {
        this.f1949g = i;
    }

    public void setProgressTop(int i) {
        this.f1946d = i;
    }

    public void setProgressWidth(int i) {
        this.f1965w = i;
    }

    public void setSeekBarMode(int i) {
        this.f1950h = i;
        t70 t70 = this.f1939T;
        boolean z = true;
        if (i == 1) {
            z = false;
        }
        t70.f5848H = z;
    }

    public void setSteps(int i) {
        this.f1923D = i;
    }

    public void setStepsAutoBonding(boolean z) {
        this.f1924E = z;
    }

    public void setStepsBitmaps(List<Bitmap> list) {
        if (list == null || list.isEmpty() || list.size() <= this.f1923D) {
            throw new IllegalArgumentException("stepsBitmaps must > steps !");
        }
        this.f1943a0.clear();
        this.f1943a0.addAll(list);
    }

    public void setStepsColor(int i) {
        this.f1968z = i;
    }

    public void setStepsDrawable(List<Integer> list) {
        if (list == null || list.isEmpty() || list.size() <= this.f1923D) {
            throw new IllegalArgumentException("stepsDrawableIds must > steps !");
        } else if (mo2433i()) {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < list.size(); i++) {
                arrayList.add(n10.m3813i(getContext(), (int) this.f1920A, (int) this.f1921B, list.get(i).intValue()));
            }
            setStepsBitmaps(arrayList);
        } else {
            throw new IllegalArgumentException("stepsWidth must > 0, stepsHeight must > 0,steps must > 0 First!!");
        }
    }

    public void setStepsDrawableId(int i) {
        this.f1943a0.clear();
        this.f1925F = i;
        mo2391d();
    }

    public void setStepsHeight(float f) {
        this.f1921B = f;
    }

    public void setStepsRadius(float f) {
        this.f1922C = f;
    }

    public void setStepsWidth(float f) {
        this.f1920A = f;
    }

    public void setTickMarkGravity(int i) {
        this.f1954l = i;
    }

    public void setTickMarkInRangeTextColor(int i) {
        this.f1957o = i;
    }

    public void setTickMarkLayoutGravity(int i) {
        this.f1955m = i;
    }

    public void setTickMarkMode(int i) {
        this.f1951i = i;
    }

    public void setTickMarkTextArray(CharSequence[] charSequenceArr) {
        this.f1958p = charSequenceArr;
    }

    public void setTickMarkTextColor(int i) {
        this.f1956n = i;
    }

    public void setTickMarkTextMargin(int i) {
        this.f1952j = i;
    }

    public void setTickMarkTextSize(int i) {
        this.f1953k = i;
    }

    public void setTypeface(Typeface typeface) {
        this.f1932M.setTypeface(typeface);
    }
}
