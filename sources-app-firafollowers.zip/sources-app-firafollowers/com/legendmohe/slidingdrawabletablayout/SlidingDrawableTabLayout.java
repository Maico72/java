package com.legendmohe.slidingdrawabletablayout;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.viewpager.widget.ViewPager;
import com.roughike.bottombar.C0446R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import org.fasaroid.fira.R;
import p000.C0657f;
import p000.y70;

public class SlidingDrawableTabLayout extends HorizontalScrollView {

    /* renamed from: D */
    public static final C0940j6<C0426f> f1969D = new C1063l6(16);

    /* renamed from: A */
    public DataSetObserver f1970A;

    /* renamed from: B */
    public C0420b f1971B;

    /* renamed from: C */
    public final C0940j6<C0427g> f1972C = new C1001k6(12);

    /* renamed from: d */
    public final ArrayList<C0426f> f1973d = new ArrayList<>();

    /* renamed from: e */
    public C0426f f1974e;

    /* renamed from: f */
    public final C0423e f1975f;

    /* renamed from: g */
    public int f1976g;

    /* renamed from: h */
    public int f1977h;

    /* renamed from: i */
    public int f1978i;

    /* renamed from: j */
    public int f1979j;

    /* renamed from: k */
    public int f1980k;

    /* renamed from: l */
    public ColorStateList f1981l;

    /* renamed from: m */
    public float f1982m;

    /* renamed from: n */
    public float f1983n;

    /* renamed from: o */
    public final int f1984o;

    /* renamed from: p */
    public int f1985p = Integer.MAX_VALUE;

    /* renamed from: q */
    public final int f1986q;

    /* renamed from: r */
    public final int f1987r;

    /* renamed from: s */
    public final int f1988s;

    /* renamed from: t */
    public int f1989t;

    /* renamed from: u */
    public int f1990u;

    /* renamed from: v */
    public int f1991v;

    /* renamed from: w */
    public C0421c f1992w;

    /* renamed from: x */
    public y70 f1993x;

    /* renamed from: y */
    public ViewPager f1994y;

    /* renamed from: z */
    public C0885id f1995z;

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$a */
    public class C0419a implements y70.C2123d {
        public C0419a() {
        }

        /* renamed from: a */
        public void mo2512a(y70 y70) {
            SlidingDrawableTabLayout.this.scrollTo(((Integer) ((c80) y70.f6863a).f1538a.getAnimatedValue()).intValue(), 0);
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$b */
    public static class C0420b implements ViewPager.C0209h {

        /* renamed from: a */
        public final WeakReference<SlidingDrawableTabLayout> f1997a;

        /* renamed from: b */
        public int f1998b;

        /* renamed from: c */
        public int f1999c;

        public C0420b(SlidingDrawableTabLayout slidingDrawableTabLayout) {
            this.f1997a = new WeakReference<>(slidingDrawableTabLayout);
        }

        /* renamed from: a */
        public void mo124a(int i, float f, int i2) {
            SlidingDrawableTabLayout slidingDrawableTabLayout = (SlidingDrawableTabLayout) this.f1997a.get();
            if (slidingDrawableTabLayout != null) {
                int i3 = this.f1999c;
                boolean z = false;
                boolean z2 = i3 != 2 || this.f1998b == 1;
                if (!(i3 == 2 && this.f1998b == 0)) {
                    z = true;
                }
                C0940j6<C0426f> j6Var = SlidingDrawableTabLayout.f1969D;
                slidingDrawableTabLayout.mo2499m(i, f, z2, z);
            }
        }

        /* renamed from: b */
        public void mo125b(int i) {
            this.f1998b = this.f1999c;
            this.f1999c = i;
        }

        /* renamed from: c */
        public void mo126c(int i) {
            SlidingDrawableTabLayout slidingDrawableTabLayout = (SlidingDrawableTabLayout) this.f1997a.get();
            if (slidingDrawableTabLayout != null && slidingDrawableTabLayout.getSelectedTabPosition() != i) {
                int i2 = this.f1999c;
                slidingDrawableTabLayout.mo2497k(slidingDrawableTabLayout.f1973d.get(i), i2 == 0 || (i2 == 2 && this.f1998b == 0));
            }
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$c */
    public interface C0421c {
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$d */
    public class C0422d extends DataSetObserver {
        public C0422d(C0419a aVar) {
        }

        public void onChanged() {
            SlidingDrawableTabLayout slidingDrawableTabLayout = SlidingDrawableTabLayout.this;
            C0940j6<C0426f> j6Var = SlidingDrawableTabLayout.f1969D;
            slidingDrawableTabLayout.mo2495i();
        }

        public void onInvalidated() {
            SlidingDrawableTabLayout slidingDrawableTabLayout = SlidingDrawableTabLayout.this;
            C0940j6<C0426f> j6Var = SlidingDrawableTabLayout.f1969D;
            slidingDrawableTabLayout.mo2495i();
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$e */
    public class C0423e extends LinearLayout {

        /* renamed from: d */
        public int f2001d;

        /* renamed from: e */
        public final Paint f2002e;

        /* renamed from: f */
        public Drawable f2003f;

        /* renamed from: g */
        public int f2004g = -1;

        /* renamed from: h */
        public float f2005h;

        /* renamed from: i */
        public int f2006i = -1;

        /* renamed from: j */
        public int f2007j = -1;

        /* renamed from: k */
        public y70 f2008k;

        /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$e$a */
        public class C0424a implements y70.C2123d {

            /* renamed from: a */
            public final /* synthetic */ int f2010a;

            /* renamed from: b */
            public final /* synthetic */ int f2011b;

            /* renamed from: c */
            public final /* synthetic */ int f2012c;

            /* renamed from: d */
            public final /* synthetic */ int f2013d;

            public C0424a(int i, int i2, int i3, int i4) {
                this.f2010a = i;
                this.f2011b = i2;
                this.f2012c = i3;
                this.f2013d = i4;
            }

            /* renamed from: a */
            public void mo2512a(y70 y70) {
                float animatedFraction = ((c80) y70.f6863a).f1538a.getAnimatedFraction();
                C0423e eVar = C0423e.this;
                int a = v70.m5367a(this.f2010a, this.f2011b, animatedFraction);
                int a2 = v70.m5367a(this.f2012c, this.f2013d, animatedFraction);
                if (a != eVar.f2006i || a2 != eVar.f2007j) {
                    eVar.f2006i = a;
                    eVar.f2007j = a2;
                    WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                    eVar.postInvalidateOnAnimation();
                }
            }
        }

        /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$e$b */
        public class C0425b extends y70.C2122c {

            /* renamed from: a */
            public final /* synthetic */ int f2015a;

            public C0425b(int i) {
                this.f2015a = i;
            }
        }

        public C0423e(Context context, AttributeSet attributeSet, int i) {
            super(context);
            setWillNotDraw(false);
            this.f2002e = new Paint();
            Drawable drawable = context.obtainStyledAttributes(attributeSet, w70.f6592a, i, -1).getDrawable(0);
            this.f2003f = drawable;
            if (drawable == null) {
                this.f2003f = C1901v4.m5334c(getContext(), 17170445);
            }
        }

        /* renamed from: a */
        public void mo2515a(int i, int i2) {
            y70 y70 = this.f2008k;
            if (y70 != null && y70.mo6647b()) {
                this.f2008k.mo6646a();
            }
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            getLayoutDirection();
            View childAt = getChildAt(i);
            if (childAt == null) {
                mo2516b();
                return;
            }
            int left = childAt.getLeft();
            int right = childAt.getRight();
            int i3 = this.f2006i;
            int i4 = this.f2007j;
            if (i3 != left || i4 != right) {
                c80 c80 = new c80();
                y70 y702 = new y70(c80);
                this.f2008k = y702;
                c80.f1538a.setInterpolator(v70.f6268a);
                ((c80) y702.f6863a).f1538a.setDuration((long) i2);
                ((c80) y702.f6863a).f1538a.setFloatValues(new float[]{0.0f, 1.0f});
                y702.mo6648c(new C0424a(i3, left, i4, right));
                C0425b bVar = new C0425b(i);
                y70.C2124e eVar = y702.f6863a;
                c80 c802 = (c80) eVar;
                c802.f1538a.addListener(new b80(c802, new z70(y702, bVar)));
                ((c80) y702.f6863a).f1538a.start();
            }
        }

        /* renamed from: b */
        public final void mo2516b() {
            int i;
            View childAt = getChildAt(this.f2004g);
            int i2 = -1;
            if (childAt == null || childAt.getWidth() <= 0) {
                i = -1;
            } else {
                int left = childAt.getLeft();
                i = childAt.getRight();
                if (this.f2005h > 0.0f && this.f2004g < getChildCount() - 1) {
                    View childAt2 = getChildAt(this.f2004g + 1);
                    float left2 = this.f2005h * ((float) childAt2.getLeft());
                    float f = this.f2005h;
                    left = (int) (((1.0f - f) * ((float) left)) + left2);
                    i = (int) (((1.0f - this.f2005h) * ((float) i)) + (f * ((float) childAt2.getRight())));
                }
                i2 = left;
            }
            if (i2 != this.f2006i || i != this.f2007j) {
                this.f2006i = i2;
                this.f2007j = i;
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                postInvalidateOnAnimation();
            }
        }

        public void onDraw(Canvas canvas) {
            int i;
            int i2;
            super.onDraw(canvas);
            Drawable drawable = this.f2003f;
            if (drawable != null && (i = this.f2006i) >= 0 && (i2 = this.f2007j) > i) {
                drawable.setBounds(i, 0, i2, getHeight());
                this.f2003f.draw(canvas);
            }
        }

        public void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            y70 y70 = this.f2008k;
            if (y70 == null || !y70.mo6647b()) {
                mo2516b();
                return;
            }
            this.f2008k.mo6646a();
            mo2515a(this.f2004g, Math.round((1.0f - ((c80) this.f2008k.f6863a).f1538a.getAnimatedFraction()) * ((float) ((c80) this.f2008k.f6863a).f1538a.getDuration())));
        }

        public void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (View.MeasureSpec.getMode(i) == 1073741824) {
                SlidingDrawableTabLayout slidingDrawableTabLayout = SlidingDrawableTabLayout.this;
                boolean z = true;
                if (slidingDrawableTabLayout.f1991v == 1 && slidingDrawableTabLayout.f1990u == 1) {
                    int childCount = getChildCount();
                    int i3 = 0;
                    for (int i4 = 0; i4 < childCount; i4++) {
                        View childAt = getChildAt(i4);
                        if (childAt.getVisibility() == 0) {
                            i3 = Math.max(i3, childAt.getMeasuredWidth());
                        }
                    }
                    if (i3 > 0) {
                        if (i3 * childCount <= getMeasuredWidth() - (SlidingDrawableTabLayout.this.mo2487g(16) * 2)) {
                            boolean z2 = false;
                            for (int i5 = 0; i5 < childCount; i5++) {
                                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(i5).getLayoutParams();
                                if (layoutParams.width != i3 || layoutParams.weight != 0.0f) {
                                    layoutParams.width = i3;
                                    layoutParams.weight = 0.0f;
                                    z2 = true;
                                }
                            }
                            z = z2;
                        } else {
                            SlidingDrawableTabLayout slidingDrawableTabLayout2 = SlidingDrawableTabLayout.this;
                            slidingDrawableTabLayout2.f1990u = 0;
                            slidingDrawableTabLayout2.mo2501o(false);
                        }
                        if (z) {
                            super.onMeasure(i, i2);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$f */
    public static final class C0426f {

        /* renamed from: a */
        public Drawable f2017a;

        /* renamed from: b */
        public CharSequence f2018b;

        /* renamed from: c */
        public int f2019c = -1;

        /* renamed from: d */
        public View f2020d;

        /* renamed from: e */
        public SlidingDrawableTabLayout f2021e;

        /* renamed from: f */
        public C0427g f2022f;

        public C0426f() {
        }

        public C0426f(C0419a aVar) {
        }

        /* renamed from: a */
        public final void mo2520a() {
            C0427g gVar = this.f2022f;
            if (gVar != null) {
                gVar.mo2521a();
            }
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$g */
    public class C0427g extends LinearLayout implements View.OnLongClickListener {

        /* renamed from: d */
        public C0426f f2023d;

        /* renamed from: e */
        public TextView f2024e;

        /* renamed from: f */
        public ImageView f2025f;

        /* renamed from: g */
        public View f2026g;

        /* renamed from: h */
        public TextView f2027h;

        /* renamed from: i */
        public ImageView f2028i;

        /* renamed from: j */
        public int f2029j = 2;

        public C0427g(Context context) {
            super(context);
            if (SlidingDrawableTabLayout.this.f1984o != 0) {
                setBackgroundDrawable(C1391p1.m4299a().mo5155b(context, SlidingDrawableTabLayout.this.f1984o));
            }
            int i = SlidingDrawableTabLayout.this.f1976g;
            int i2 = SlidingDrawableTabLayout.this.f1977h;
            int i3 = SlidingDrawableTabLayout.this.f1978i;
            int i4 = SlidingDrawableTabLayout.this.f1979j;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            setPaddingRelative(i, i2, i3, i4);
            setGravity(17);
            setOrientation(1);
            setClickable(true);
        }

        /* renamed from: a */
        public final void mo2521a() {
            ImageView imageView;
            TextView textView;
            C0426f fVar = this.f2023d;
            View view = fVar != null ? fVar.f2020d : null;
            if (view != null) {
                ViewParent parent = view.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(view);
                    }
                    addView(view);
                }
                this.f2026g = view;
                TextView textView2 = this.f2024e;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                }
                ImageView imageView2 = this.f2025f;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f2025f.setImageDrawable((Drawable) null);
                }
                TextView textView3 = (TextView) view.findViewById(16908308);
                this.f2027h = textView3;
                if (textView3 != null) {
                    this.f2029j = textView3.getMaxLines();
                }
                this.f2028i = (ImageView) view.findViewById(16908294);
            } else {
                View view2 = this.f2026g;
                if (view2 != null) {
                    removeView(view2);
                    this.f2026g = null;
                }
                this.f2027h = null;
                this.f2028i = null;
            }
            if (this.f2026g == null) {
                if (this.f2025f == null) {
                    ImageView imageView3 = (ImageView) LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_icon, this, false);
                    addView(imageView3, 0);
                    this.f2025f = imageView3;
                }
                if (this.f2024e == null) {
                    TextView textView4 = (TextView) LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_text, this, false);
                    addView(textView4);
                    this.f2024e = textView4;
                    this.f2029j = textView4.getMaxLines();
                }
                this.f2024e.setTextAppearance(getContext(), SlidingDrawableTabLayout.this.f1980k);
                ColorStateList colorStateList = SlidingDrawableTabLayout.this.f1981l;
                if (colorStateList != null) {
                    this.f2024e.setTextColor(colorStateList);
                }
                textView = this.f2024e;
                imageView = this.f2025f;
            } else {
                textView = this.f2027h;
                if (textView != null || this.f2028i != null) {
                    imageView = this.f2028i;
                } else {
                    return;
                }
            }
            mo2522b(textView, imageView);
        }

        /* renamed from: b */
        public final void mo2522b(TextView textView, ImageView imageView) {
            int i;
            C0426f fVar = this.f2023d;
            Drawable drawable = fVar != null ? fVar.f2017a : null;
            CharSequence charSequence = fVar != null ? fVar.f2018b : null;
            if (imageView != null) {
                if (drawable != null) {
                    imageView.setImageDrawable(drawable);
                    imageView.setVisibility(0);
                    setVisibility(0);
                } else {
                    imageView.setVisibility(8);
                    imageView.setImageDrawable((Drawable) null);
                }
                imageView.setContentDescription((CharSequence) null);
            }
            boolean z = !TextUtils.isEmpty(charSequence);
            if (textView != null) {
                if (z) {
                    textView.setText(charSequence);
                    textView.setVisibility(0);
                    setVisibility(0);
                } else {
                    textView.setVisibility(8);
                    textView.setText((CharSequence) null);
                }
                textView.setContentDescription((CharSequence) null);
            }
            if (imageView != null) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) imageView.getLayoutParams();
                if (!z || imageView.getVisibility() != 0) {
                    i = 0;
                } else {
                    SlidingDrawableTabLayout slidingDrawableTabLayout = SlidingDrawableTabLayout.this;
                    C0940j6<C0426f> j6Var = SlidingDrawableTabLayout.f1969D;
                    i = slidingDrawableTabLayout.mo2487g(8);
                }
                if (i != marginLayoutParams.bottomMargin) {
                    marginLayoutParams.bottomMargin = i;
                    imageView.requestLayout();
                }
            }
            if (z || TextUtils.isEmpty((CharSequence) null)) {
                setOnLongClickListener((View.OnLongClickListener) null);
                setLongClickable(false);
                return;
            }
            setOnLongClickListener(this);
        }

        @TargetApi(14)
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName(C0657f.C0660c.class.getName());
        }

        @TargetApi(14)
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName(C0657f.C0660c.class.getName());
        }

        public boolean onLongClick(View view) {
            int[] iArr = new int[2];
            getLocationOnScreen(iArr);
            Context context = getContext();
            int width = getWidth();
            int height = getHeight();
            int i = context.getResources().getDisplayMetrics().widthPixels;
            Objects.requireNonNull(this.f2023d);
            Toast makeText = Toast.makeText(context, (CharSequence) null, 0);
            makeText.setGravity(49, ((width / 2) + iArr[0]) - (i / 2), height);
            makeText.show();
            return true;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:29:0x008f, code lost:
            if (((r0 / r2.getPaint().getTextSize()) * r2.getLineWidth(0)) > ((float) r2.getWidth())) goto L_0x0091;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onMeasure(int r8, int r9) {
            /*
                r7 = this;
                int r0 = android.view.View.MeasureSpec.getSize(r8)
                int r1 = android.view.View.MeasureSpec.getMode(r8)
                com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout r2 = com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.this
                int r2 = r2.getTabMaxWidth()
                if (r2 <= 0) goto L_0x001e
                if (r1 == 0) goto L_0x0014
                if (r0 <= r2) goto L_0x001e
            L_0x0014:
                com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout r8 = com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.this
                int r8 = r8.f1985p
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r0)
            L_0x001e:
                super.onMeasure(r8, r9)
                android.widget.TextView r0 = r7.f2024e
                if (r0 == 0) goto L_0x00a1
                r7.getResources()
                com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout r0 = com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.this
                float r0 = r0.f1982m
                int r1 = r7.f2029j
                android.widget.ImageView r2 = r7.f2025f
                r3 = 1
                if (r2 == 0) goto L_0x003b
                int r2 = r2.getVisibility()
                if (r2 != 0) goto L_0x003b
                r1 = 1
                goto L_0x0049
            L_0x003b:
                android.widget.TextView r2 = r7.f2024e
                if (r2 == 0) goto L_0x0049
                int r2 = r2.getLineCount()
                if (r2 <= r3) goto L_0x0049
                com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout r0 = com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.this
                float r0 = r0.f1983n
            L_0x0049:
                android.widget.TextView r2 = r7.f2024e
                float r2 = r2.getTextSize()
                android.widget.TextView r4 = r7.f2024e
                int r4 = r4.getLineCount()
                android.widget.TextView r5 = r7.f2024e
                int r5 = r5.getMaxLines()
                int r6 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
                if (r6 != 0) goto L_0x0063
                if (r5 < 0) goto L_0x00a1
                if (r1 == r5) goto L_0x00a1
            L_0x0063:
                com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout r5 = com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.this
                int r5 = r5.f1991v
                r6 = 0
                if (r5 != r3) goto L_0x0092
                int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
                if (r2 <= 0) goto L_0x0092
                if (r4 != r3) goto L_0x0092
                android.widget.TextView r2 = r7.f2024e
                android.text.Layout r2 = r2.getLayout()
                if (r2 == 0) goto L_0x0091
                float r4 = r2.getLineWidth(r6)
                android.text.TextPaint r5 = r2.getPaint()
                float r5 = r5.getTextSize()
                float r5 = r0 / r5
                float r5 = r5 * r4
                int r2 = r2.getWidth()
                float r2 = (float) r2
                int r2 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
                if (r2 <= 0) goto L_0x0092
            L_0x0091:
                r3 = 0
            L_0x0092:
                if (r3 == 0) goto L_0x00a1
                android.widget.TextView r2 = r7.f2024e
                r2.setTextSize(r6, r0)
                android.widget.TextView r0 = r7.f2024e
                r0.setMaxLines(r1)
                super.onMeasure(r8, r9)
            L_0x00a1:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.C0427g.onMeasure(int, int):void");
        }

        public boolean performClick() {
            boolean performClick = super.performClick();
            C0426f fVar = this.f2023d;
            if (fVar == null) {
                return performClick;
            }
            SlidingDrawableTabLayout slidingDrawableTabLayout = fVar.f2021e;
            if (slidingDrawableTabLayout != null) {
                slidingDrawableTabLayout.mo2497k(fVar, true);
                return true;
            }
            throw new IllegalArgumentException("Tab not attached to a MyTabLayout");
        }

        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                sendAccessibilityEvent(4);
                TextView textView = this.f2024e;
                if (textView != null) {
                    textView.setSelected(z);
                }
                ImageView imageView = this.f2025f;
                if (imageView != null) {
                    imageView.setSelected(z);
                }
            }
        }
    }

    /* renamed from: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout$h */
    public static class C0428h implements C0421c {

        /* renamed from: a */
        public final ViewPager f2031a;

        public C0428h(ViewPager viewPager) {
            this.f2031a = viewPager;
        }
    }

    /* JADX INFO: finally extract failed */
    public SlidingDrawableTabLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setHorizontalScrollBarEnabled(false);
        C0423e eVar = new C0423e(context, attributeSet, 0);
        this.f1975f = eVar;
        super.addView(eVar, 0, new FrameLayout.LayoutParams(-2, -1));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, w70.f6593b, 0, C0446R.style.Widget_Design_TabLayout);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(10, 0);
        if (eVar.f2001d != dimensionPixelSize) {
            eVar.f2001d = dimensionPixelSize;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            eVar.postInvalidateOnAnimation();
        }
        int color = obtainStyledAttributes.getColor(7, 0);
        if (eVar.f2002e.getColor() != color) {
            eVar.f2002e.setColor(color);
            WeakHashMap<View, String> weakHashMap2 = C0010a7.f28a;
            eVar.postInvalidateOnAnimation();
        }
        int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(15, 0);
        this.f1979j = dimensionPixelSize2;
        this.f1978i = dimensionPixelSize2;
        this.f1977h = dimensionPixelSize2;
        this.f1976g = dimensionPixelSize2;
        this.f1976g = obtainStyledAttributes.getDimensionPixelSize(18, dimensionPixelSize2);
        this.f1977h = obtainStyledAttributes.getDimensionPixelSize(19, this.f1977h);
        this.f1978i = obtainStyledAttributes.getDimensionPixelSize(17, this.f1978i);
        this.f1979j = obtainStyledAttributes.getDimensionPixelSize(16, this.f1979j);
        int resourceId = obtainStyledAttributes.getResourceId(22, C0446R.style.TextAppearance_Design_Tab);
        this.f1980k = resourceId;
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(resourceId, w70.f6594c);
        try {
            this.f1982m = (float) obtainStyledAttributes2.getDimensionPixelSize(0, 0);
            this.f1981l = obtainStyledAttributes2.getColorStateList(3);
            obtainStyledAttributes2.recycle();
            if (obtainStyledAttributes.hasValue(23)) {
                this.f1981l = obtainStyledAttributes.getColorStateList(23);
            }
            if (obtainStyledAttributes.hasValue(21)) {
                int color2 = obtainStyledAttributes.getColor(21, 0);
                int defaultColor = this.f1981l.getDefaultColor();
                this.f1981l = new ColorStateList(new int[][]{HorizontalScrollView.SELECTED_STATE_SET, HorizontalScrollView.EMPTY_STATE_SET}, new int[]{color2, defaultColor});
            }
            this.f1986q = obtainStyledAttributes.getDimensionPixelSize(13, -1);
            this.f1987r = obtainStyledAttributes.getDimensionPixelSize(12, -1);
            this.f1984o = obtainStyledAttributes.getResourceId(0, 0);
            this.f1989t = obtainStyledAttributes.getDimensionPixelSize(1, 0);
            this.f1991v = obtainStyledAttributes.getInt(14, 1);
            this.f1990u = obtainStyledAttributes.getInt(2, 0);
            obtainStyledAttributes.recycle();
            Resources resources = getResources();
            this.f1983n = (float) resources.getDimensionPixelSize(R.dimen.design_tab_text_size_2line);
            this.f1988s = resources.getDimensionPixelSize(R.dimen.design_tab_scrollable_min_width);
            mo2485e();
        } catch (Throwable th) {
            obtainStyledAttributes2.recycle();
            throw th;
        }
    }

    private int getDefaultHeight() {
        int size = this.f1973d.size();
        boolean z = false;
        int i = 0;
        while (true) {
            if (i < size) {
                C0426f fVar = this.f1973d.get(i);
                if (fVar != null && fVar.f2017a != null && !TextUtils.isEmpty(fVar.f2018b)) {
                    z = true;
                    break;
                }
                i++;
            } else {
                break;
            }
        }
        return z ? 72 : 48;
    }

    private float getScrollPosition() {
        C0423e eVar = this.f1975f;
        return ((float) eVar.f2004g) + eVar.f2005h;
    }

    /* access modifiers changed from: private */
    public int getTabMaxWidth() {
        return this.f1985p;
    }

    private int getTabMinWidth() {
        int i = this.f1986q;
        if (i != -1) {
            return i;
        }
        if (this.f1991v == 0) {
            return this.f1988s;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.f1975f.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    private void setSelectedTabView(int i) {
        int childCount = this.f1975f.getChildCount();
        if (i < childCount && !this.f1975f.getChildAt(i).isSelected()) {
            int i2 = 0;
            while (i2 < childCount) {
                this.f1975f.getChildAt(i2).setSelected(i2 == i);
                i2++;
            }
        }
    }

    public void addView(View view) {
        mo2483c(view);
    }

    public void addView(View view, int i) {
        mo2483c(view);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        mo2483c(view);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        mo2483c(view);
    }

    /* renamed from: b */
    public void mo2482b(C0426f fVar, boolean z) {
        if (fVar.f2021e == this) {
            C0427g gVar = fVar.f2022f;
            C0423e eVar = this.f1975f;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
            mo2500n(layoutParams);
            eVar.addView(gVar, layoutParams);
            if (z) {
                gVar.setSelected(true);
            }
            int size = this.f1973d.size();
            fVar.f2019c = size;
            this.f1973d.add(size, fVar);
            int size2 = this.f1973d.size();
            while (true) {
                size++;
                if (size >= size2) {
                    break;
                }
                this.f1973d.get(size).f2019c = size;
            }
            if (z) {
                SlidingDrawableTabLayout slidingDrawableTabLayout = fVar.f2021e;
                if (slidingDrawableTabLayout != null) {
                    slidingDrawableTabLayout.mo2497k(fVar, true);
                    return;
                }
                throw new IllegalArgumentException("Tab not attached to a MyTabLayout");
            }
            return;
        }
        throw new IllegalArgumentException("Tab belongs to a different MyTabLayout.");
    }

    /* renamed from: c */
    public final void mo2483c(View view) {
        if (view instanceof x70) {
            C0426f h = mo2494h();
            Objects.requireNonNull((x70) view);
            mo2482b(h, this.f1973d.isEmpty());
            return;
        }
        throw new IllegalArgumentException("Only TabItem instances can be added to MyTabLayout");
    }

    /* renamed from: d */
    public final void mo2484d(int i) {
        boolean z;
        if (i != -1) {
            if (getWindowToken() != null) {
                WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
                if (isLaidOut()) {
                    C0423e eVar = this.f1975f;
                    int childCount = eVar.getChildCount();
                    int i2 = 0;
                    while (true) {
                        if (i2 >= childCount) {
                            z = false;
                            break;
                        } else if (eVar.getChildAt(i2).getWidth() <= 0) {
                            z = true;
                            break;
                        } else {
                            i2++;
                        }
                    }
                    if (!z) {
                        int scrollX = getScrollX();
                        int f = mo2486f(i, 0.0f);
                        if (scrollX != f) {
                            if (this.f1993x == null) {
                                c80 c80 = new c80();
                                this.f1993x = new y70(c80);
                                c80.f1538a.setInterpolator(v70.f6268a);
                                ((c80) this.f1993x.f6863a).f1538a.setDuration((long) 300);
                                this.f1993x.mo6648c(new C0419a());
                            }
                            ((c80) this.f1993x.f6863a).f1538a.setIntValues(new int[]{scrollX, f});
                            ((c80) this.f1993x.f6863a).f1538a.start();
                        }
                        this.f1975f.mo2515a(i, 300);
                        return;
                    }
                }
            }
            mo2499m(i, 0.0f, true, true);
        }
    }

    /* renamed from: e */
    public final void mo2485e() {
        int max = this.f1991v == 0 ? Math.max(0, this.f1989t - this.f1976g) : 0;
        C0423e eVar = this.f1975f;
        WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
        eVar.setPaddingRelative(max, 0, 0, 0);
        int i = this.f1991v;
        if (i == 0) {
            this.f1975f.setGravity(8388611);
        } else if (i == 1) {
            this.f1975f.setGravity(1);
        }
        mo2501o(true);
    }

    /* renamed from: f */
    public final int mo2486f(int i, float f) {
        int i2 = 0;
        if (this.f1991v != 0) {
            return 0;
        }
        View childAt = this.f1975f.getChildAt(i);
        int i3 = i + 1;
        View childAt2 = i3 < this.f1975f.getChildCount() ? this.f1975f.getChildAt(i3) : null;
        int width = childAt != null ? childAt.getWidth() : 0;
        if (childAt2 != null) {
            i2 = childAt2.getWidth();
        }
        return ((childAt.getWidth() / 2) + (childAt.getLeft() + ((int) ((((float) (width + i2)) * f) * 0.5f)))) - (getWidth() / 2);
    }

    /* renamed from: g */
    public final int mo2487g(int i) {
        return Math.round(getResources().getDisplayMetrics().density * ((float) i));
    }

    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    public int getSelectedTabPosition() {
        C0426f fVar = this.f1974e;
        if (fVar != null) {
            return fVar.f2019c;
        }
        return -1;
    }

    public int getTabCount() {
        return this.f1973d.size();
    }

    public int getTabGravity() {
        return this.f1990u;
    }

    public int getTabMode() {
        return this.f1991v;
    }

    public ColorStateList getTabTextColors() {
        return this.f1981l;
    }

    /* renamed from: h */
    public C0426f mo2494h() {
        C0426f b = f1969D.mo4124b();
        C0427g gVar = null;
        if (b == null) {
            b = new C0426f((C0419a) null);
        }
        b.f2021e = this;
        C0940j6<C0427g> j6Var = this.f1972C;
        if (j6Var != null) {
            gVar = j6Var.mo4124b();
        }
        if (gVar == null) {
            gVar = new C0427g(getContext());
        }
        if (b != gVar.f2023d) {
            gVar.f2023d = b;
            gVar.mo2521a();
        }
        gVar.setFocusable(true);
        gVar.setMinimumWidth(getTabMinWidth());
        b.f2022f = gVar;
        return b;
    }

    /* renamed from: i */
    public final void mo2495i() {
        int currentItem;
        mo2496j();
        C0885id idVar = this.f1995z;
        if (idVar != null) {
            int c = idVar.mo4027c();
            for (int i = 0; i < c; i++) {
                C0426f h = mo2494h();
                h.f2018b = this.f1995z.mo4028d(i);
                h.mo2520a();
                mo2482b(h, false);
            }
            ViewPager viewPager = this.f1994y;
            if (viewPager != null && c > 0 && (currentItem = viewPager.getCurrentItem()) != getSelectedTabPosition() && currentItem < getTabCount()) {
                mo2497k(this.f1973d.get(currentItem), true);
                return;
            }
            return;
        }
        mo2496j();
    }

    /* renamed from: j */
    public void mo2496j() {
        for (int childCount = this.f1975f.getChildCount() - 1; childCount >= 0; childCount--) {
            C0427g gVar = (C0427g) this.f1975f.getChildAt(childCount);
            this.f1975f.removeViewAt(childCount);
            if (gVar != null) {
                if (gVar.f2023d != null) {
                    gVar.f2023d = null;
                    gVar.mo2521a();
                }
                gVar.setSelected(false);
                this.f1972C.mo4123a(gVar);
            }
            requestLayout();
        }
        Iterator<C0426f> it = this.f1973d.iterator();
        while (it.hasNext()) {
            C0426f next = it.next();
            it.remove();
            next.f2021e = null;
            next.f2022f = null;
            next.f2017a = null;
            next.f2018b = null;
            next.f2019c = -1;
            next.f2020d = null;
            f1969D.mo4123a(next);
        }
        this.f1974e = null;
    }

    /* renamed from: k */
    public void mo2497k(C0426f fVar, boolean z) {
        C0421c cVar;
        C0421c cVar2;
        C0426f fVar2 = this.f1974e;
        if (fVar2 != fVar) {
            if (z) {
                int i = fVar != null ? fVar.f2019c : -1;
                if (i != -1) {
                    setSelectedTabView(i);
                }
                C0426f fVar3 = this.f1974e;
                if ((fVar3 == null || fVar3.f2019c == -1) && i != -1) {
                    mo2499m(i, 0.0f, true, true);
                } else {
                    mo2484d(i);
                }
            }
            if (!(this.f1974e == null || (cVar2 = this.f1992w) == null)) {
                C0428h hVar = (C0428h) cVar2;
            }
            this.f1974e = fVar;
            if (fVar != null && (cVar = this.f1992w) != null) {
                ((C0428h) cVar).f2031a.setCurrentItem(fVar.f2019c);
            }
        } else if (fVar2 != null) {
            C0421c cVar3 = this.f1992w;
            if (cVar3 != null) {
                C0428h hVar2 = (C0428h) cVar3;
            }
            mo2484d(fVar.f2019c);
        }
    }

    /* renamed from: l */
    public final void mo2498l(C0885id idVar, boolean z) {
        DataSetObserver dataSetObserver;
        C0885id idVar2 = this.f1995z;
        if (!(idVar2 == null || (dataSetObserver = this.f1970A) == null)) {
            idVar2.f3249a.unregisterObserver(dataSetObserver);
        }
        this.f1995z = idVar;
        if (z && idVar != null) {
            if (this.f1970A == null) {
                this.f1970A = new C0422d((C0419a) null);
            }
            idVar.f3249a.registerObserver(this.f1970A);
        }
        mo2495i();
    }

    /* renamed from: m */
    public final void mo2499m(int i, float f, boolean z, boolean z2) {
        int round = Math.round(((float) i) + f);
        if (round >= 0 && round < this.f1975f.getChildCount()) {
            if (z2) {
                C0423e eVar = this.f1975f;
                y70 y70 = eVar.f2008k;
                if (y70 != null && y70.mo6647b()) {
                    eVar.f2008k.mo6646a();
                }
                eVar.f2004g = i;
                eVar.f2005h = f;
                eVar.mo2516b();
            }
            y70 y702 = this.f1993x;
            if (y702 != null && y702.mo6647b()) {
                this.f1993x.mo6646a();
            }
            scrollTo(mo2486f(i, f), 0);
            if (z) {
                setSelectedTabView(round);
            }
        }
    }

    /* renamed from: n */
    public final void mo2500n(LinearLayout.LayoutParams layoutParams) {
        float f;
        if (this.f1991v == 1 && this.f1990u == 0) {
            layoutParams.width = 0;
            f = 1.0f;
        } else {
            layoutParams.width = -2;
            f = 0.0f;
        }
        layoutParams.weight = f;
    }

    /* renamed from: o */
    public final void mo2501o(boolean z) {
        for (int i = 0; i < this.f1975f.getChildCount(); i++) {
            View childAt = this.f1975f.getChildAt(i);
            childAt.setMinimumWidth(getTabMinWidth());
            mo2500n((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z) {
                childAt.requestLayout();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0067, code lost:
        if (r1.getMeasuredWidth() != getMeasuredWidth()) goto L_0x0076;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0072, code lost:
        if (r1.getMeasuredWidth() < getMeasuredWidth()) goto L_0x0076;
     */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r6, int r7) {
        /*
            r5 = this;
            int r0 = r5.getDefaultHeight()
            int r0 = r5.mo2487g(r0)
            int r1 = r5.getPaddingTop()
            int r1 = r1 + r0
            int r0 = r5.getPaddingBottom()
            int r0 = r0 + r1
            int r1 = android.view.View.MeasureSpec.getMode(r7)
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            if (r1 == r2) goto L_0x0024
            if (r1 == 0) goto L_0x001f
            goto L_0x0030
        L_0x001f:
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            goto L_0x0030
        L_0x0024:
            int r7 = android.view.View.MeasureSpec.getSize(r7)
            int r7 = java.lang.Math.min(r0, r7)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r3)
        L_0x0030:
            int r0 = android.view.View.MeasureSpec.getSize(r6)
            int r1 = android.view.View.MeasureSpec.getMode(r6)
            if (r1 == 0) goto L_0x0049
            int r1 = r5.f1987r
            if (r1 <= 0) goto L_0x003f
            goto L_0x0047
        L_0x003f:
            r1 = 56
            int r1 = r5.mo2487g(r1)
            int r1 = r0 - r1
        L_0x0047:
            r5.f1985p = r1
        L_0x0049:
            super.onMeasure(r6, r7)
            int r6 = r5.getChildCount()
            r0 = 1
            if (r6 != r0) goto L_0x0097
            r6 = 0
            android.view.View r1 = r5.getChildAt(r6)
            int r2 = r5.f1991v
            if (r2 == 0) goto L_0x006a
            if (r2 == r0) goto L_0x005f
            goto L_0x0077
        L_0x005f:
            int r2 = r1.getMeasuredWidth()
            int r4 = r5.getMeasuredWidth()
            if (r2 == r4) goto L_0x0075
            goto L_0x0076
        L_0x006a:
            int r2 = r1.getMeasuredWidth()
            int r4 = r5.getMeasuredWidth()
            if (r2 >= r4) goto L_0x0075
            goto L_0x0076
        L_0x0075:
            r0 = 0
        L_0x0076:
            r6 = r0
        L_0x0077:
            if (r6 == 0) goto L_0x0097
            int r6 = r5.getPaddingTop()
            int r0 = r5.getPaddingBottom()
            int r0 = r0 + r6
            android.view.ViewGroup$LayoutParams r6 = r1.getLayoutParams()
            int r6 = r6.height
            int r6 = android.widget.HorizontalScrollView.getChildMeasureSpec(r7, r0, r6)
            int r7 = r5.getMeasuredWidth()
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r3)
            r1.measure(r7, r6)
        L_0x0097:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.legendmohe.slidingdrawabletablayout.SlidingDrawableTabLayout.onMeasure(int, int):void");
    }

    public void setOnTabSelectedListener(C0421c cVar) {
        this.f1992w = cVar;
    }

    public void setSelectedTabIndicatorColor(int i) {
        C0423e eVar = this.f1975f;
        if (eVar.f2002e.getColor() != i) {
            eVar.f2002e.setColor(i);
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            eVar.postInvalidateOnAnimation();
        }
    }

    public void setSelectedTabIndicatorHeight(int i) {
        C0423e eVar = this.f1975f;
        if (eVar.f2001d != i) {
            eVar.f2001d = i;
            WeakHashMap<View, String> weakHashMap = C0010a7.f28a;
            eVar.postInvalidateOnAnimation();
        }
    }

    public void setTabGravity(int i) {
        if (this.f1990u != i) {
            this.f1990u = i;
            mo2485e();
        }
    }

    public void setTabMode(int i) {
        if (i != this.f1991v) {
            this.f1991v = i;
            mo2485e();
        }
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.f1981l != colorStateList) {
            this.f1981l = colorStateList;
            int size = this.f1973d.size();
            for (int i = 0; i < size; i++) {
                this.f1973d.get(i).mo2520a();
            }
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(C0885id idVar) {
        mo2498l(idVar, false);
    }

    public void setupWithViewPager(ViewPager viewPager) {
        C0420b bVar;
        List<ViewPager.C0209h> list;
        ViewPager viewPager2 = this.f1994y;
        if (!(viewPager2 == null || (bVar = this.f1971B) == null || (list = viewPager2.f1076U) == null)) {
            list.remove(bVar);
        }
        if (viewPager != null) {
            C0885id adapter = viewPager.getAdapter();
            if (adapter != null) {
                this.f1994y = viewPager;
                if (this.f1971B == null) {
                    this.f1971B = new C0420b(this);
                }
                C0420b bVar2 = this.f1971B;
                bVar2.f1999c = 0;
                bVar2.f1998b = 0;
                if (viewPager.f1076U == null) {
                    viewPager.f1076U = new ArrayList();
                }
                viewPager.f1076U.add(bVar2);
                setOnTabSelectedListener(new C0428h(viewPager));
                mo2498l(adapter, true);
                return;
            }
            throw new IllegalArgumentException("ViewPager does not have a PagerAdapter set");
        }
        this.f1994y = null;
        setOnTabSelectedListener((C0421c) null);
        mo2498l((C0885id) null, true);
    }

    public boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }
}
