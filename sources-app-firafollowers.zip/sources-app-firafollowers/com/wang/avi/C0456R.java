package com.wang.avi;

import org.fasaroid.fira.R;

/* renamed from: com.wang.avi.R */
public final class C0456R {

    /* renamed from: com.wang.avi.R$attr */
    public static final class attr {
        public static final int indicatorColor = 2130903320;
        public static final int indicatorName = 2130903321;
        public static final int maxHeight = 2130903387;
        public static final int maxWidth = 2130903390;
        public static final int minHeight = 2130903393;
        public static final int minWidth = 2130903394;

        private attr() {
        }
    }

    /* renamed from: com.wang.avi.R$string */
    public static final class string {
        public static final int app_name = 2131623977;

        private string() {
        }
    }

    /* renamed from: com.wang.avi.R$style */
    public static final class style {
        public static final int AVLoadingIndicatorView = 2131689472;
        public static final int AVLoadingIndicatorView_Large = 2131689473;
        public static final int AVLoadingIndicatorView_Small = 2131689474;

        private style() {
        }
    }

    /* renamed from: com.wang.avi.R$styleable */
    public static final class styleable {
        public static final int[] AVLoadingIndicatorView = {R.attr.indicatorColor, R.attr.indicatorName, R.attr.maxHeight, R.attr.maxWidth, R.attr.minHeight, R.attr.minWidth};
        public static final int AVLoadingIndicatorView_indicatorColor = 0;
        public static final int AVLoadingIndicatorView_indicatorName = 1;
        public static final int AVLoadingIndicatorView_maxHeight = 2;
        public static final int AVLoadingIndicatorView_maxWidth = 3;
        public static final int AVLoadingIndicatorView_minHeight = 4;
        public static final int AVLoadingIndicatorView_minWidth = 5;

        private styleable() {
        }
    }

    private C0456R() {
    }
}
