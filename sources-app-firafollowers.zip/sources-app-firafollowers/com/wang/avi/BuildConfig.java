package com.wang.avi;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.wang.avi";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 33;
    public static final String VERSION_NAME = "2.1.3";
}
